import { appendErrors, get, set } from "/ERP-Project/node_modules/.vite/deps/react-hook-form.js?v=9f27e63f";
//#region node_modules/@hookform/resolvers/dist/resolvers.mjs
var t = (r, t, s) => {
	if (r && "reportValidity" in r) {
		const o = get(s, t);
		r.setCustomValidity(o && o.message || ""), r.reportValidity();
	}
};
var s = (e, r) => {
	for (const s in r.fields) {
		const o = r.fields[s];
		o && o.ref && "reportValidity" in o.ref ? t(o.ref, s, e) : o && o.refs && o.refs.forEach((r) => t(r, s, e));
	}
};
var o$1 = (t, o) => {
	o.shouldUseNativeValidation && s(t, o);
	const n = {};
	for (const s in t) {
		const f = get(o.fields, s), c = Object.assign(t[s] || {}, { ref: f && f.refs ? f.refs[0] : f && f.ref });
		if (i(o.names || Object.keys(t), s)) {
			const t = Object.assign({}, get(n, s));
			set(t, "root", c), set(n, s, t);
		} else set(n, s, c);
	}
	return n;
};
var i = (e, r) => {
	const t = n(r).replace(/[.*+?^${}()|\\]/g, "\\$&");
	return e.some((e) => n(e).match(`^${t}\\.\\d+`));
};
function n(e) {
	return e.replace(/\[(\d+)]/g, ".$1").replace(/[[\]]/g, "");
}
//#endregion
//#region node_modules/@hookform/resolvers/yup/dist/yup.mjs
function o(o, n, a) {
	return void 0 === a && (a = {}), function(s$1, i, c) {
		try {
			return Promise.resolve(function(t, r) {
				try {
					var u = (null != n && n.context && console.warn("You should not used the yup options context. Please, use the 'useForm' context object instead"), Promise.resolve(o["sync" === a.mode ? "validateSync" : "validate"](s$1, Object.assign({ abortEarly: !1 }, n, { context: i }))).then(function(t) {
						return c.shouldUseNativeValidation && s({}, c), {
							values: a.raw ? Object.assign({}, s$1) : t,
							errors: {}
						};
					}));
				} catch (e) {
					return r(e);
				}
				return u && u.then ? u.then(void 0, r) : u;
			}(0, function(e) {
				if (!e.inner) throw e;
				return {
					values: {},
					errors: o$1((o = e, n = !c.shouldUseNativeValidation && "all" === c.criteriaMode, (o.inner || []).reduce(function(e, t) {
						if (e[t.path] || (e[t.path] = {
							message: t.message,
							type: t.type
						}), n) {
							var o = e[t.path].types, a = o && o[t.type];
							e[t.path] = appendErrors(t.path, n, e, t.type, a ? [].concat(a, t.message) : t.message);
						}
						return e;
					}, Object.create(null))), c)
				};
				var o, n;
			}));
		} catch (e) {
			return Promise.reject(e);
		}
	};
}
//#endregion
export { o as yupResolver };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGhvb2tmb3JtX3Jlc29sdmVyc195dXAuanMiLCJuYW1lcyI6WyJlIiwibyIsInIiLCJzIiwiZSIsInQiLCJyIl0sInNvdXJjZXMiOlsiLi4vLi4vQGhvb2tmb3JtL3Jlc29sdmVycy9kaXN0L3Jlc29sdmVycy5tanMiLCIuLi8uLi9AaG9va2Zvcm0vcmVzb2x2ZXJzL3l1cC9kaXN0L3l1cC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0e2dldCBhcyBlLHNldCBhcyByfWZyb21cInJlYWN0LWhvb2stZm9ybVwiO2NvbnN0IHQ9KHIsdCxzKT0+e2lmKHImJlwicmVwb3J0VmFsaWRpdHlcImluIHIpe2NvbnN0IG89ZShzLHQpO3Iuc2V0Q3VzdG9tVmFsaWRpdHkobyYmby5tZXNzYWdlfHxcIlwiKSxyLnJlcG9ydFZhbGlkaXR5KCl9fSxzPShlLHIpPT57Zm9yKGNvbnN0IHMgaW4gci5maWVsZHMpe2NvbnN0IG89ci5maWVsZHNbc107byYmby5yZWYmJlwicmVwb3J0VmFsaWRpdHlcImluIG8ucmVmP3Qoby5yZWYscyxlKTpvJiZvLnJlZnMmJm8ucmVmcy5mb3JFYWNoKHI9PnQocixzLGUpKX19LG89KHQsbyk9PntvLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24mJnModCxvKTtjb25zdCBuPXt9O2Zvcihjb25zdCBzIGluIHQpe2NvbnN0IGY9ZShvLmZpZWxkcyxzKSxjPU9iamVjdC5hc3NpZ24odFtzXXx8e30se3JlZjpmJiZmLnJlZnM/Zi5yZWZzWzBdOmYmJmYucmVmfSk7aWYoaShvLm5hbWVzfHxPYmplY3Qua2V5cyh0KSxzKSl7Y29uc3QgdD1PYmplY3QuYXNzaWduKHt9LGUobixzKSk7cih0LFwicm9vdFwiLGMpLHIobixzLHQpfWVsc2UgcihuLHMsYyl9cmV0dXJuIG59LGk9KGUscik9Pntjb25zdCB0PW4ocikucmVwbGFjZSgvWy4qKz9eJHt9KCl8XFxcXF0vZyxcIlxcXFwkJlwiKTtyZXR1cm4gZS5zb21lKGU9Pm4oZSkubWF0Y2goYF4ke3R9XFxcXC5cXFxcZCtgKSl9O2Z1bmN0aW9uIG4oZSl7cmV0dXJuIGUucmVwbGFjZSgvXFxbKFxcZCspXS9nLFwiLiQxXCIpLnJlcGxhY2UoL1tbXFxdXS9nLFwiXCIpfWV4cG9ydHtvIGFzIHRvTmVzdEVycm9ycyxzIGFzIHZhbGlkYXRlRmllbGRzTmF0aXZlbHl9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVzb2x2ZXJzLm1qcy5tYXBcbiIsImltcG9ydHt2YWxpZGF0ZUZpZWxkc05hdGl2ZWx5IGFzIGUsdG9OZXN0RXJyb3JzIGFzIHR9ZnJvbVwiQGhvb2tmb3JtL3Jlc29sdmVyc1wiO2ltcG9ydHthcHBlbmRFcnJvcnMgYXMgcn1mcm9tXCJyZWFjdC1ob29rLWZvcm1cIjtmdW5jdGlvbiBvKG8sbixhKXtyZXR1cm4gdm9pZCAwPT09YSYmKGE9e30pLGZ1bmN0aW9uKHMsaSxjKXt0cnl7cmV0dXJuIFByb21pc2UucmVzb2x2ZShmdW5jdGlvbih0LHIpe3RyeXt2YXIgdT0obnVsbCE9biYmbi5jb250ZXh0JiZcImRldmVsb3BtZW50XCI9PT1wcm9jZXNzLmVudi5OT0RFX0VOViYmY29uc29sZS53YXJuKFwiWW91IHNob3VsZCBub3QgdXNlZCB0aGUgeXVwIG9wdGlvbnMgY29udGV4dC4gUGxlYXNlLCB1c2UgdGhlICd1c2VGb3JtJyBjb250ZXh0IG9iamVjdCBpbnN0ZWFkXCIpLFByb21pc2UucmVzb2x2ZShvW1wic3luY1wiPT09YS5tb2RlP1widmFsaWRhdGVTeW5jXCI6XCJ2YWxpZGF0ZVwiXShzLE9iamVjdC5hc3NpZ24oe2Fib3J0RWFybHk6ITF9LG4se2NvbnRleHQ6aX0pKSkudGhlbihmdW5jdGlvbih0KXtyZXR1cm4gYy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uJiZlKHt9LGMpLHt2YWx1ZXM6YS5yYXc/T2JqZWN0LmFzc2lnbih7fSxzKTp0LGVycm9yczp7fX19KSl9Y2F0Y2goZSl7cmV0dXJuIHIoZSl9cmV0dXJuIHUmJnUudGhlbj91LnRoZW4odm9pZCAwLHIpOnV9KDAsZnVuY3Rpb24oZSl7aWYoIWUuaW5uZXIpdGhyb3cgZTtyZXR1cm57dmFsdWVzOnt9LGVycm9yczp0KChvPWUsbj0hYy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uJiZcImFsbFwiPT09Yy5jcml0ZXJpYU1vZGUsKG8uaW5uZXJ8fFtdKS5yZWR1Y2UoZnVuY3Rpb24oZSx0KXtpZihlW3QucGF0aF18fChlW3QucGF0aF09e21lc3NhZ2U6dC5tZXNzYWdlLHR5cGU6dC50eXBlfSksbil7dmFyIG89ZVt0LnBhdGhdLnR5cGVzLGE9byYmb1t0LnR5cGVdO2VbdC5wYXRoXT1yKHQucGF0aCxuLGUsdC50eXBlLGE/W10uY29uY2F0KGEsdC5tZXNzYWdlKTp0Lm1lc3NhZ2UpfXJldHVybiBlfSxPYmplY3QuY3JlYXRlKG51bGwpKSksYyl9O3ZhciBvLG59KSl9Y2F0Y2goZSl7cmV0dXJuIFByb21pc2UucmVqZWN0KGUpfX19ZXhwb3J0e28gYXMgeXVwUmVzb2x2ZXJ9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9eXVwLm1vZHVsZS5qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBK0MsSUFBTSxLQUFHLEdBQUUsR0FBRSxNQUFJO0NBQUMsSUFBRyxLQUFHLG9CQUFtQixHQUFFO0VBQUMsTUFBTSxJQUFFQSxJQUFFLEdBQUUsQ0FBQztFQUFFLEVBQUUsa0JBQWtCLEtBQUcsRUFBRSxXQUFTLEVBQUUsR0FBRSxFQUFFLGVBQWU7Q0FBQztBQUFDO0lBQUUsS0FBRyxHQUFFLE1BQUk7Q0FBQyxLQUFJLE1BQU0sS0FBSyxFQUFFLFFBQU87RUFBQyxNQUFNLElBQUUsRUFBRSxPQUFPO0VBQUcsS0FBRyxFQUFFLE9BQUssb0JBQW1CLEVBQUUsTUFBSSxFQUFFLEVBQUUsS0FBSSxHQUFFLENBQUMsSUFBRSxLQUFHLEVBQUUsUUFBTSxFQUFFLEtBQUssU0FBUSxNQUFHLEVBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQztDQUFDO0FBQUM7SUFBRUMsT0FBRyxHQUFFLE1BQUk7Q0FBQyxFQUFFLDZCQUEyQixFQUFFLEdBQUUsQ0FBQztDQUFFLE1BQU0sSUFBRSxDQUFDO0NBQUUsS0FBSSxNQUFNLEtBQUssR0FBRTtFQUFDLE1BQU0sSUFBRUQsSUFBRSxFQUFFLFFBQU8sQ0FBQyxHQUFFLElBQUUsT0FBTyxPQUFPLEVBQUUsTUFBSSxDQUFDLEdBQUUsRUFBQyxLQUFJLEtBQUcsRUFBRSxPQUFLLEVBQUUsS0FBSyxLQUFHLEtBQUcsRUFBRSxJQUFHLENBQUM7RUFBRSxJQUFHLEVBQUUsRUFBRSxTQUFPLE9BQU8sS0FBSyxDQUFDLEdBQUUsQ0FBQyxHQUFFO0dBQUMsTUFBTSxJQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUVBLElBQUUsR0FBRSxDQUFDLENBQUM7R0FBRSxJQUFFLEdBQUUsUUFBTyxDQUFDLEdBQUVFLElBQUUsR0FBRSxHQUFFLENBQUM7RUFBQyxPQUFNLElBQUUsR0FBRSxHQUFFLENBQUM7Q0FBQztDQUFDLE9BQU87QUFBQztJQUFFLEtBQUcsR0FBRSxNQUFJO0NBQUMsTUFBTSxJQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxvQkFBbUIsTUFBTTtDQUFFLE9BQU8sRUFBRSxNQUFLLE1BQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUksRUFBRSxRQUFRLENBQUM7QUFBQztBQUFFLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLFFBQVEsYUFBWSxLQUFLLENBQUMsQ0FBQyxRQUFRLFVBQVMsRUFBRTtBQUFDOzs7QUNBdG5CLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRTtDQUFDLE9BQU8sS0FBSyxNQUFJLE1BQUksSUFBRSxDQUFDLElBQUcsU0FBUyxLQUFFLEdBQUUsR0FBRTtFQUFDLElBQUc7R0FBQyxPQUFPLFFBQVEsUUFBUSxTQUFTLEdBQUUsR0FBRTtJQUFDLElBQUc7S0FBQyxJQUFJLEtBQUcsUUFBTSxLQUFHLEVBQUUsV0FBK0MsUUFBUSxLQUFLLCtGQUErRixHQUFFLFFBQVEsUUFBUSxFQUFFLFdBQVMsRUFBRSxPQUFLLGlCQUFlLFdBQVcsQ0FBQ0MsS0FBRSxPQUFPLE9BQU8sRUFBQyxZQUFXLENBQUMsRUFBQyxHQUFFLEdBQUUsRUFBQyxTQUFRLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxHQUFFO01BQUMsT0FBTyxFQUFFLDZCQUEyQkMsRUFBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFO09BQUMsUUFBTyxFQUFFLE1BQUksT0FBTyxPQUFPLENBQUMsR0FBRUQsR0FBQyxJQUFFO09BQUUsUUFBTyxDQUFDO01BQUM7S0FBQyxDQUFDO0lBQUUsU0FBTyxHQUFFO0tBQUMsT0FBTyxFQUFFLENBQUM7SUFBQztJQUFDLE9BQU8sS0FBRyxFQUFFLE9BQUssRUFBRSxLQUFLLEtBQUssR0FBRSxDQUFDLElBQUU7R0FBQyxFQUFFLEdBQUUsU0FBUyxHQUFFO0lBQUMsSUFBRyxDQUFDLEVBQUUsT0FBTSxNQUFNO0lBQUUsT0FBTTtLQUFDLFFBQU8sQ0FBQztLQUFFLFFBQU9FLEtBQUcsSUFBRSxHQUFFLElBQUUsQ0FBQyxFQUFFLDZCQUEyQixVQUFRLEVBQUUsZUFBYyxFQUFFLFNBQU8sQ0FBQyxFQUFBLENBQUcsT0FBTyxTQUFTLEdBQUUsR0FBRTtNQUFDLElBQUcsRUFBRSxFQUFFLFVBQVEsRUFBRSxFQUFFLFFBQU07T0FBQyxTQUFRLEVBQUU7T0FBUSxNQUFLLEVBQUU7TUFBSSxJQUFHLEdBQUU7T0FBQyxJQUFJLElBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxPQUFNLElBQUUsS0FBRyxFQUFFLEVBQUU7T0FBTSxFQUFFLEVBQUUsUUFBTUMsYUFBRSxFQUFFLE1BQUssR0FBRSxHQUFFLEVBQUUsTUFBSyxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRSxFQUFFLE9BQU8sSUFBRSxFQUFFLE9BQU87TUFBQztNQUFDLE9BQU87S0FBQyxHQUFFLE9BQU8sT0FBTyxJQUFJLENBQUMsSUFBRyxDQUFDO0lBQUM7UUFBTSxHQUFFO0dBQUMsQ0FBQyxDQUFDO0VBQUMsU0FBTyxHQUFFO0dBQUMsT0FBTyxRQUFRLE9BQU8sQ0FBQztFQUFDO0NBQUM7QUFBQyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDFdfQ==