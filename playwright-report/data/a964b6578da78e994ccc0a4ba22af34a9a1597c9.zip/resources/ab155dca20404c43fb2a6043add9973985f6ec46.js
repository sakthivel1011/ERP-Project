export const Data = {
	customers: [
		{
			customerId: "CUS0001",
			customerCode: "C0001",
			companyName: "ABC Engineering Pvt Ltd",
			gstNumber: "33ABCDE1234F1Z5",
			panNumber: "ABCDE1234F",
			customerType: "Corporate",
			creditLimit: 1e6,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0001",
				name: "Rajesh Kumar",
				designation: "Purchase Manager",
				email: "rajesh@abcengineering.com",
				mobile: "9876543210"
			}],
			billingAddress: {
				address1: "No.12 SIDCO Industrial Estate",
				city: "Chennai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "600098"
			},
			shippingAddress: {
				address1: "Plant 2, SIPCOT",
				city: "Chennai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "600058"
			}
		},
		{
			customerId: "CUS0002",
			customerCode: "C0002",
			companyName: "Precision Industries India",
			gstNumber: "22PQRS5678G1Z2",
			panNumber: "PQRS5678G",
			customerType: "Corporate",
			creditLimit: 75e4,
			paymentTerms: "45 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0002",
				name: "Priya Srinivasan",
				designation: "Procurement Head",
				email: "priya@precision.ind.in",
				mobile: "9823456789"
			}],
			billingAddress: {
				address1: "Plot 7, Phase II, Electronic City",
				city: "Bengaluru",
				state: "Karnataka",
				country: "India",
				pincode: "560100"
			},
			shippingAddress: {
				address1: "Warehouse 4, Bommasandra",
				city: "Bengaluru",
				state: "Karnataka",
				country: "India",
				pincode: "560099"
			}
		},
		{
			customerId: "CUS0003",
			customerCode: "C0003",
			companyName: "Sarang Trading Corporation",
			gstNumber: "27STUV9012H1Z6",
			panNumber: "STUV9012H",
			customerType: "Trader",
			creditLimit: 5e5,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0003",
				name: "Manoj Shah",
				designation: "Proprietor",
				email: "manoj@sarangtrading.com",
				mobile: "9812345670"
			}],
			billingAddress: {
				address1: "Shop 8, Lohar Chawl",
				city: "Mumbai",
				state: "Maharashtra",
				country: "India",
				pincode: "400002"
			},
			shippingAddress: {
				address1: "Shop 8, Lohar Chawl",
				city: "Mumbai",
				state: "Maharashtra",
				country: "India",
				pincode: "400002"
			}
		},
		{
			customerId: "CUS0004",
			customerCode: "C0004",
			companyName: "Reliance Heat Exchangers Ltd",
			gstNumber: "24LMNO3456A1Z3",
			panNumber: "LMNO3456A",
			customerType: "Corporate",
			creditLimit: 25e5,
			paymentTerms: "60 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0004",
				name: "Sunil Reddy",
				designation: "Vice President - Procurement",
				email: "sunil@reliancehe.in",
				mobile: "9988776655"
			}],
			billingAddress: {
				address1: "H Block, MIDC, Patalganga",
				city: "Raigad",
				state: "Maharashtra",
				country: "India",
				pincode: "410206"
			},
			shippingAddress: {
				address1: "Patalganga Works, H Block",
				city: "Raigad",
				state: "Maharashtra",
				country: "India",
				pincode: "410206"
			}
		},
		{
			customerId: "CUS0005",
			customerCode: "C0005",
			companyName: "Thermal Engineering Solutions",
			gstNumber: "29WXYZ7890C1Z7",
			panNumber: "WXYZ7890C",
			customerType: "Corporate",
			creditLimit: 12e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0005",
				name: "Ananya Patel",
				designation: "Manager - Supply Chain",
				email: "ananya@thermalengg.com",
				mobile: "9876501234"
			}],
			billingAddress: {
				address1: "Plot 22, GIDC, Vatva",
				city: "Ahmedabad",
				state: "Gujarat",
				country: "India",
				pincode: "382445"
			},
			shippingAddress: {
				address1: "GIDC Vatva, Unit 2",
				city: "Ahmedabad",
				state: "Gujarat",
				country: "India",
				pincode: "382445"
			}
		},
		{
			customerId: "CUS0006",
			customerCode: "C0006",
			companyName: "Kerala Industrial Supplies",
			gstNumber: "32ABCD4321F1Z2",
			panNumber: "ABCD4321F",
			customerType: "Corporate",
			creditLimit: 6e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0006",
				name: "Thomas George",
				designation: "Purchase Manager",
				email: "thomas@kis.in",
				mobile: "9876123456"
			}],
			billingAddress: {
				address1: "Near KSRTC Depot, Palarivattom",
				city: "Kochi",
				state: "Kerala",
				country: "India",
				pincode: "682025"
			},
			shippingAddress: {
				address1: "Industrial Zone, Ambalamugal",
				city: "Kochi",
				state: "Kerala",
				country: "India",
				pincode: "682302"
			}
		},
		{
			customerId: "CUS0007",
			customerCode: "C0007",
			companyName: "Aditya Refrigeration Works",
			gstNumber: "08GHIJ5678D1Z4",
			panNumber: "GHIJ5678D",
			customerType: "SME",
			creditLimit: 35e4,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0007",
				name: "Ravi Gupta",
				designation: "Owner",
				email: "ravi@adityaref.in",
				mobile: "9786543210"
			}],
			billingAddress: {
				address1: "A-45, Mahipalpur Extension",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110037"
			},
			shippingAddress: {
				address1: "B-12, Badarpur Industrial Area",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110044"
			}
		},
		{
			customerId: "CUS0008",
			customerCode: "C0008",
			companyName: "Bharat Piping Solutions",
			gstNumber: "19MNOP3456B1Z1",
			panNumber: "MNOP3456B",
			customerType: "Corporate",
			creditLimit: 9e5,
			paymentTerms: "45 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0008",
				name: "Harish Nair",
				designation: "Senior Purchase Officer",
				email: "harish@bharatpiping.com",
				mobile: "9834567891"
			}],
			billingAddress: {
				address1: "56, Sector 27, MIDC",
				city: "Pune",
				state: "Maharashtra",
				country: "India",
				pincode: "411028"
			},
			shippingAddress: {
				address1: "Plot 7, Chakan MIDC",
				city: "Pune",
				state: "Maharashtra",
				country: "India",
				pincode: "410501"
			}
		},
		{
			customerId: "CUS0009",
			customerCode: "C0009",
			companyName: "S.R. Enterprises",
			gstNumber: "07QRST6789E1Z6",
			panNumber: "QRST6789E",
			customerType: "Trader",
			creditLimit: 3e5,
			paymentTerms: "7 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0009",
				name: "Sunder Ramaswamy",
				designation: "Partner",
				email: "sunder@srenterprises.in",
				mobile: "9845678901"
			}],
			billingAddress: {
				address1: "Ward 36, Nehru Market",
				city: "Coimbatore",
				state: "Tamil Nadu",
				country: "India",
				pincode: "641001"
			},
			shippingAddress: {
				address1: "Ward 36, Nehru Market",
				city: "Coimbatore",
				state: "Tamil Nadu",
				country: "India",
				pincode: "641001"
			}
		},
		{
			customerId: "CUS0010",
			customerCode: "C0010",
			companyName: "AquaCool Technologies",
			gstNumber: "36UVWX1234K1Z5",
			panNumber: "UVWX1234K",
			customerType: "Corporate",
			creditLimit: 8e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0010",
				name: "Naresh Gupta",
				designation: "VP, Procurement",
				email: "naresh@aquacooltech.com",
				mobile: "9654321876"
			}],
			billingAddress: {
				address1: "Plot 89, Phase III, Panki",
				city: "Kanpur",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "208020"
			},
			shippingAddress: {
				address1: "Panki Industrial Area, Unit 3",
				city: "Kanpur",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "208020"
			}
		},
		{
			customerId: "CUS0011",
			customerCode: "C0011",
			companyName: "Eastern Trading Co.",
			gstNumber: "19YZAB4567M1Z3",
			panNumber: "YZAB4567M",
			customerType: "Trader",
			creditLimit: 45e4,
			paymentTerms: "20 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0011",
				name: "Debjit Mukherjee",
				designation: "Proprietor",
				email: "debjit@easterntrading.com",
				mobile: "9876512345"
			}],
			billingAddress: {
				address1: "15, Ganesh Chandra Avenue",
				city: "Kolkata",
				state: "West Bengal",
				country: "India",
				pincode: "700013"
			},
			shippingAddress: {
				address1: "10, Strand Road",
				city: "Kolkata",
				state: "West Bengal",
				country: "India",
				pincode: "700001"
			}
		},
		{
			customerId: "CUS0012",
			customerCode: "C0012",
			companyName: "Surya Heat Systems",
			gstNumber: "29BCDE7890N1Z8",
			panNumber: "BCDE7890N",
			customerType: "Corporate",
			creditLimit: 11e5,
			paymentTerms: "60 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0012",
				name: "Ramesh Sharma",
				designation: "General Manager - SCM",
				email: "ramesh@suryaheat.com",
				mobile: "9898989898"
			}],
			billingAddress: {
				address1: "K-15, IDA, Uppal",
				city: "Hyderabad",
				state: "Telangana",
				country: "India",
				pincode: "500039"
			},
			shippingAddress: {
				address1: "IDA Uppal, Unit 9",
				city: "Hyderabad",
				state: "Telangana",
				country: "India",
				pincode: "500039"
			}
		},
		{
			customerId: "CUS0013",
			customerCode: "C0013",
			companyName: "Cool Flow Industries",
			gstNumber: "08FGHI4567P1Z2",
			panNumber: "FGHI4567P",
			customerType: "SME",
			creditLimit: 4e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0013",
				name: "Vijay Kashyap",
				designation: "Director",
				email: "vijay@coolflow.in",
				mobile: "9811112222"
			}],
			billingAddress: {
				address1: "C-9, Mayapuri Indl Area",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110064"
			},
			shippingAddress: {
				address1: "C-9, Mayapuri Indl Area",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110064"
			}
		},
		{
			customerId: "CUS0014",
			customerCode: "C0014",
			companyName: "M/s. Krishna Fabrications",
			gstNumber: "33JKLM1234Q1Z5",
			panNumber: "JKLM1234Q",
			customerType: "SME",
			creditLimit: 25e4,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0014",
				name: "Krishna Moorthy",
				designation: "Proprietor",
				email: "krishna@krishfab.in",
				mobile: "9845098450"
			}],
			billingAddress: {
				address1: "5A, Mettupalayam Road",
				city: "Tiruppur",
				state: "Tamil Nadu",
				country: "India",
				pincode: "641604"
			},
			shippingAddress: {
				address1: "5A, Mettupalayam Road",
				city: "Tiruppur",
				state: "Tamil Nadu",
				country: "India",
				pincode: "641604"
			}
		},
		{
			customerId: "CUS0015",
			customerCode: "C0015",
			companyName: "Gujarat Boiler & Heat Exchangers",
			gstNumber: "24NOPQ5678R1Z6",
			panNumber: "NOPQ5678R",
			customerType: "Corporate",
			creditLimit: 2e6,
			paymentTerms: "45 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0015",
				name: "Ketan Shah",
				designation: "Director - Procurement",
				email: "ketan@gbhe.in",
				mobile: "9925001234"
			}],
			billingAddress: {
				address1: "Plot 1/2, GIDC, Ankleshwar",
				city: "Bharuch",
				state: "Gujarat",
				country: "India",
				pincode: "393002"
			},
			shippingAddress: {
				address1: "GIDC Ankleshwar, Unit 4",
				city: "Bharuch",
				state: "Gujarat",
				country: "India",
				pincode: "393002"
			}
		},
		{
			customerId: "CUS0016",
			customerCode: "C0016",
			companyName: "Pristine Cooling Systems",
			gstNumber: "29STUV3456S1Z7",
			panNumber: "STUV3456S",
			customerType: "Corporate",
			creditLimit: 95e4,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0016",
				name: "Amit Jain",
				designation: "Manager - Supply Chain",
				email: "amit@pristinecool.in",
				mobile: "9876547891"
			}],
			billingAddress: {
				address1: "Plot 6, Noida Special Economic Zone",
				city: "Noida",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "201305"
			},
			shippingAddress: {
				address1: "NSEDZ, Unit 2B",
				city: "Noida",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "201305"
			}
		},
		{
			customerId: "CUS0017",
			customerCode: "C0017",
			companyName: "Southern Pipe Industries",
			gstNumber: "33WXYZ2345T1Z1",
			panNumber: "WXYZ2345T",
			customerType: "Corporate",
			creditLimit: 7e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0017",
				name: "Murali Krishnan",
				designation: "Purchase Manager",
				email: "murali@southernpipe.in",
				mobile: "9444012345"
			}],
			billingAddress: {
				address1: "18, Thiruvalluvar Street",
				city: "Madurai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "625001"
			},
			shippingAddress: {
				address1: "Industrial Estate, Kappalur",
				city: "Madurai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "625008"
			}
		},
		{
			customerId: "CUS0018",
			customerCode: "C0018",
			companyName: "Apex Engineering & Supplies",
			gstNumber: "08ABCD6789U1Z9",
			panNumber: "ABCD6789U",
			customerType: "SME",
			creditLimit: 38e4,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0018",
				name: "Sanjay Bansal",
				designation: "Proprietor",
				email: "sanjay@apexengg.com",
				mobile: "9812345678"
			}],
			billingAddress: {
				address1: "A-79, DSIDC Complex, Bawana",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110039"
			},
			shippingAddress: {
				address1: "A-79, DSIDC Complex, Bawana",
				city: "New Delhi",
				state: "Delhi",
				country: "India",
				pincode: "110039"
			}
		},
		{
			customerId: "CUS0019",
			customerCode: "C0019",
			companyName: "Tamil Nadu Refrigeration Co.",
			gstNumber: "33EFGH7890V1Z3",
			panNumber: "EFGH7890V",
			customerType: "Corporate",
			creditLimit: 55e4,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0019",
				name: "Sivakumar Rajan",
				designation: "Manager, Purchase",
				email: "sivakumar@tnref.co.in",
				mobile: "9790912345"
			}],
			billingAddress: {
				address1: "21, Greams Road",
				city: "Chennai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "600006"
			},
			shippingAddress: {
				address1: "Perungudi Industrial Estate",
				city: "Chennai",
				state: "Tamil Nadu",
				country: "India",
				pincode: "600096"
			}
		},
		{
			customerId: "CUS0020",
			customerCode: "C0020",
			companyName: "Raj Process Equipment",
			gstNumber: "27JKLM4567W1Z8",
			panNumber: "JKLM4567W",
			customerType: "SME",
			creditLimit: 45e4,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0020",
				name: "Rajendra Patil",
				designation: "Director",
				email: "raj@rajprocess.com",
				mobile: "9765234567"
			}],
			billingAddress: {
				address1: "Plot 45, MIDC, Bhosari",
				city: "Pune",
				state: "Maharashtra",
				country: "India",
				pincode: "411026"
			},
			shippingAddress: {
				address1: "MIDC Bhosari, Unit 12",
				city: "Pune",
				state: "Maharashtra",
				country: "India",
				pincode: "411026"
			}
		},
		{
			customerId: "CUS0021",
			customerCode: "C0021",
			companyName: "Evergreen Heat Transfer LLP",
			gstNumber: "24NOPQ2345X1Z2",
			panNumber: "NOPQ2345X",
			customerType: "Corporate",
			creditLimit: 13e5,
			paymentTerms: "60 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0021",
				name: "Rajesh Menon",
				designation: "Partner",
				email: "rajesh@evergreenht.com",
				mobile: "9876540011"
			}],
			billingAddress: {
				address1: "B-12, Vile Parle East",
				city: "Mumbai",
				state: "Maharashtra",
				country: "India",
				pincode: "400057"
			},
			shippingAddress: {
				address1: "Unit 5, TTC, Navi Mumbai",
				city: "Mumbai",
				state: "Maharashtra",
				country: "India",
				pincode: "400706"
			}
		},
		{
			customerId: "CUS0022",
			customerCode: "C0022",
			companyName: "Surabhi Industrial Corporation",
			gstNumber: "29QRST8901Y1Z4",
			panNumber: "QRST8901Y",
			customerType: "Trader",
			creditLimit: 28e4,
			paymentTerms: "10 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0022",
				name: "Girish Sharma",
				designation: "Proprietor",
				email: "girish@surabhiind.com",
				mobile: "9822223333"
			}],
			billingAddress: {
				address1: "G-9, R.K. Puram, Sector 5",
				city: "Jaipur",
				state: "Rajasthan",
				country: "India",
				pincode: "302018"
			},
			shippingAddress: {
				address1: "G-9, R.K. Puram, Sector 5",
				city: "Jaipur",
				state: "Rajasthan",
				country: "India",
				pincode: "302018"
			}
		},
		{
			customerId: "CUS0023",
			customerCode: "C0023",
			companyName: "Indus Precision Components",
			gstNumber: "36UVWX6789Z1Z5",
			panNumber: "UVWX6789Z",
			customerType: "Corporate",
			creditLimit: 82e4,
			paymentTerms: "45 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0023",
				name: "Alok Verma",
				designation: "Purchase Manager",
				email: "alok@indusprecision.in",
				mobile: "7896541230"
			}],
			billingAddress: {
				address1: "A-18, Sector 65, Noida",
				city: "Noida",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "201301"
			},
			shippingAddress: {
				address1: "A-18, Sector 65, Noida",
				city: "Noida",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "201301"
			}
		},
		{
			customerId: "CUS0024",
			customerCode: "C0024",
			companyName: "Coastal Cooling Products",
			gstNumber: "32ABCD1234A1Z6",
			panNumber: "ABCD1234A",
			customerType: "SME",
			creditLimit: 42e4,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0024",
				name: "Joseph Antony",
				designation: "Managing Partner",
				email: "joseph@coastalcool.in",
				mobile: "9447123456"
			}],
			billingAddress: {
				address1: "32, Kaloor-Kadavanthra Road",
				city: "Kochi",
				state: "Kerala",
				country: "India",
				pincode: "682017"
			},
			shippingAddress: {
				address1: "KINFRA Industrial Park",
				city: "Kochi",
				state: "Kerala",
				country: "India",
				pincode: "683501"
			}
		},
		{
			customerId: "CUS0025",
			customerCode: "C0025",
			companyName: "Hindalco Heat Exchangers Division",
			gstNumber: "09EFGH3456B1Z8",
			panNumber: "EFGH3456B",
			customerType: "Corporate",
			creditLimit: 3e6,
			paymentTerms: "60 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0025",
				name: "Prakash Singh",
				designation: "Head - Raw Materials",
				email: "prakash.singh@hindalco.in",
				mobile: "9966332211"
			}],
			billingAddress: {
				address1: "Renukoot Works, Sonebhadra",
				city: "Renukoot",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "231217"
			},
			shippingAddress: {
				address1: "Renukoot Plant",
				city: "Renukoot",
				state: "Uttar Pradesh",
				country: "India",
				pincode: "231217"
			}
		},
		{
			customerId: "CUS0026",
			customerCode: "C0026",
			companyName: "Srinivasa Refrigeration & AC",
			gstNumber: "37IJKL7890C1Z2",
			panNumber: "IJKL7890C",
			customerType: "SME",
			creditLimit: 2e5,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0026",
				name: "Srinivas Rao",
				designation: "Proprietor",
				email: "srinivas@srac.in",
				mobile: "9393939393"
			}],
			billingAddress: {
				address1: "3-4-102, Kothapet",
				city: "Hyderabad",
				state: "Telangana",
				country: "India",
				pincode: "500035"
			},
			shippingAddress: {
				address1: "3-4-102, Kothapet",
				city: "Hyderabad",
				state: "Telangana",
				country: "India",
				pincode: "500035"
			}
		},
		{
			customerId: "CUS0027",
			customerCode: "C0027",
			companyName: "Atlas Piping & Equipment",
			gstNumber: "08MNOP4567D1Z3",
			panNumber: "MNOP4567D",
			customerType: "Corporate",
			creditLimit: 6e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0027",
				name: "Vivek Bhatia",
				designation: "Manager Purchase",
				email: "vivek@atlaspiping.com",
				mobile: "9812345670"
			}],
			billingAddress: {
				address1: "Plot 14, Udyog Vihar, Phase IV",
				city: "Gurugram",
				state: "Haryana",
				country: "India",
				pincode: "122015"
			},
			shippingAddress: {
				address1: "Plot 14, Udyog Vihar",
				city: "Gurugram",
				state: "Haryana",
				country: "India",
				pincode: "122015"
			}
		},
		{
			customerId: "CUS0028",
			customerCode: "C0028",
			companyName: "Om Sai Refrigeration",
			gstNumber: "27QRST5678E1Z4",
			panNumber: "QRST5678E",
			customerType: "SME",
			creditLimit: 3e5,
			paymentTerms: "15 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0028",
				name: "Ravi Shankar",
				designation: "Partner",
				email: "ravi@omsairef.in",
				mobile: "9834567890"
			}],
			billingAddress: {
				address1: "S-7, M.I.D.C, Satpur",
				city: "Nashik",
				state: "Maharashtra",
				country: "India",
				pincode: "422007"
			},
			shippingAddress: {
				address1: "S-7, M.I.D.C, Satpur",
				city: "Nashik",
				state: "Maharashtra",
				country: "India",
				pincode: "422007"
			}
		},
		{
			customerId: "CUS0029",
			customerCode: "C0029",
			companyName: "Cosmos Heat Exchanger Technologies",
			gstNumber: "33UVWX7890F1Z5",
			panNumber: "UVWX7890F",
			customerType: "Corporate",
			creditLimit: 18e5,
			paymentTerms: "60 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0029",
				name: "Raj Kumar",
				designation: "VP - Supply Chain",
				email: "raj.kumar@cosmosht.in",
				mobile: "9876544444"
			}],
			billingAddress: {
				address1: "No. 7, Electronics City Phase 2",
				city: "Bengaluru",
				state: "Karnataka",
				country: "India",
				pincode: "560100"
			},
			shippingAddress: {
				address1: "Electronics City Phase 2, Unit 5",
				city: "Bengaluru",
				state: "Karnataka",
				country: "India",
				pincode: "560100"
			}
		},
		{
			customerId: "CUS0030",
			customerCode: "C0030",
			companyName: "Kalinga Industrial Equipment",
			gstNumber: "21YZAB2345G1Z6",
			panNumber: "YZAB2345G",
			customerType: "SME",
			creditLimit: 5e5,
			paymentTerms: "30 Days",
			currency: "INR",
			contacts: [{
				contactId: "CNT0030",
				name: "Santosh Nayak",
				designation: "Director",
				email: "santosh@kalingaind.in",
				mobile: "9861123456"
			}],
			billingAddress: {
				address1: "Plot 3, Industrial Estate, Mancheswar",
				city: "Bhubaneswar",
				state: "Odisha",
				country: "India",
				pincode: "751010"
			},
			shippingAddress: {
				address1: "Mancheswar Industrial Estate",
				city: "Bhubaneswar",
				state: "Odisha",
				country: "India",
				pincode: "751010"
			}
		}
	],
	quotations: [
		{
			quotationId: "QUO0002",
			quotationNumber: "QTN-2026-0002",
			customerId: "CUS0002",
			quotationDate: "2026-04-10",
			expiryDate: "2026-05-10",
			status: "Sent",
			items: [{
				itemCode: "PRD003",
				description: "Aluminum Fin Tube",
				qty: 500,
				rate: 850,
				discount: 3,
				gst: 18,
				amount: 412250
			}, {
				itemCode: "PRD004",
				description: "Aluminum Fin Tube 1",
				qty: 500,
				rate: 850,
				discount: 3,
				gst: 18,
				amount: 412250
			}],
			subtotal: 412250,
			tax: 74205,
			grandTotal: 486455
		},
		{
			quotationId: "QUO0004",
			quotationNumber: "QTN-2026-0004",
			customerId: "CUS0004",
			quotationDate: "2026-04-20",
			expiryDate: "2026-05-20",
			status: "Converted",
			items: [{
				itemCode: "PRD002",
				description: "Carbon Steel Fin Tube",
				qty: 1e3,
				rate: 950,
				discount: 10,
				gst: 18,
				amount: 855e3
			}],
			subtotal: 855e3,
			tax: 153900,
			grandTotal: 1008900
		},
		{
			quotationId: "QUO0010",
			quotationNumber: "QTN-2026-0010",
			customerId: "CUS0010",
			quotationDate: "2026-05-05",
			expiryDate: "2026-06-05",
			status: "Converted",
			items: [{
				itemCode: "PRD017",
				description: "Carbon Steel Fin Tube, 20 ft",
				qty: 1500,
				rate: 780,
				discount: 12,
				gst: 18,
				amount: 1029600
			}],
			subtotal: 102600,
			tax: 185328,
			grandTotal: 1214928
		},
		{
			quotationId: "QUO0013",
			quotationNumber: "QTN-2026-0013",
			customerId: "CUS0013",
			quotationDate: "2026-05-10",
			expiryDate: "2026-06-10",
			status: "Converted",
			items: [{
				itemCode: "PRD023",
				description: "Extruded Copper Fin Tube",
				qty: 85,
				rate: 2600,
				discount: 5,
				gst: 18,
				amount: 209950
			}],
			subtotal: 209950,
			tax: 37791,
			grandTotal: 247741
		},
		{
			quotationId: "QUO0017",
			quotationNumber: "QTN-2026-0017",
			customerId: "CUS0017",
			quotationDate: "2026-05-16",
			expiryDate: "2026-06-16",
			status: "Converted",
			items: [{
				itemCode: "PRD031",
				description: "SS Fin Tube, 304L",
				qty: 110,
				rate: 3350,
				discount: 8,
				gst: 18,
				amount: 339020
			}],
			subtotal: 339020,
			tax: 61023.6,
			grandTotal: 400043.6
		},
		{
			quotationId: "QUO0020",
			quotationNumber: "QTN-2026-0020",
			customerId: "CUS0020",
			quotationDate: "2026-05-21",
			expiryDate: "2026-06-21",
			status: "Converted",
			items: [{
				itemCode: "PRD037",
				description: "Aluminum Fin Tube, High Density",
				qty: 350,
				rate: 1050,
				discount: 10,
				gst: 18,
				amount: 330750
			}],
			subtotal: 330750,
			tax: 59535,
			grandTotal: 390285
		}
	],
	invoices: [
		{
			invoiceId: "INV0002",
			invoiceNumber: "INV-2026-0002",
			quotationId: "QUO0004",
			customerId: "CUS0004",
			invoiceDate: "2026-04-25",
			paymentTerms: "60 Days",
			status: "Unpaid",
			items: [{
				itemCode: "PRD002",
				description: "Carbon Steel Fin Tube",
				qty: 1e3,
				rate: 950,
				discount: 10,
				gst: 18,
				amount: 855e3
			}],
			subtotal: 855e3,
			gstAmount: 153900,
			grandTotal: 1008900,
			payments: []
		},
		{
			invoiceId: "INV0003",
			invoiceNumber: "INV-2026-0003",
			quotationId: "QUO0010",
			customerId: "CUS0010",
			invoiceDate: "2026-05-08",
			paymentTerms: "30 Days",
			status: "Partially Paid",
			items: [{
				itemCode: "PRD017",
				description: "Carbon Steel Fin Tube, 20 ft",
				qty: 1500,
				rate: 780,
				discount: 12,
				gst: 18,
				amount: 1029600
			}],
			subtotal: 1029600,
			gstAmount: 185328,
			grandTotal: 1214928,
			payments: [{
				paymentId: "PAY0003",
				date: "2026-05-20",
				mode: "RTGS",
				amount: 5e5,
				reference: "RTGS123456"
			}]
		},
		{
			invoiceId: "INV0004",
			invoiceNumber: "INV-2026-0004",
			quotationId: "QUO0013",
			customerId: "CUS0013",
			invoiceDate: "2026-05-15",
			paymentTerms: "30 Days",
			status: "Paid",
			items: [{
				itemCode: "PRD023",
				description: "Extruded Copper Fin Tube",
				qty: 85,
				rate: 2600,
				discount: 5,
				gst: 18,
				amount: 209950
			}],
			subtotal: 209950,
			gstAmount: 37791,
			grandTotal: 247741,
			payments: [{
				paymentId: "PAY0004",
				date: "2026-06-01",
				mode: "NEFT",
				amount: 247741,
				reference: "UTR987654321"
			}]
		},
		{
			invoiceId: "INV0005",
			invoiceNumber: "INV-2026-0005",
			quotationId: "QUO0017",
			customerId: "CUS0017",
			invoiceDate: "2026-05-22",
			paymentTerms: "45 Days",
			status: "Overdue",
			items: [{
				itemCode: "PRD031",
				description: "SS Fin Tube, 304L",
				qty: 110,
				rate: 3350,
				discount: 8,
				gst: 18,
				amount: 339020
			}],
			subtotal: 339020,
			gstAmount: 61023.6,
			grandTotal: 400043.6,
			payments: []
		},
		{
			invoiceId: "INV0006",
			invoiceNumber: "INV-2026-0006",
			quotationId: "QUO0020",
			customerId: "CUS0020",
			invoiceDate: "2026-05-25",
			paymentTerms: "30 Days",
			status: "Unpaid",
			items: [{
				itemCode: "PRD037",
				description: "Aluminum Fin Tube, High Density",
				qty: 350,
				rate: 1050,
				discount: 10,
				gst: 18,
				amount: 330750
			}],
			subtotal: 330750,
			gstAmount: 59535,
			grandTotal: 390285,
			payments: []
		},
		{
			invoiceId: "INV0007",
			invoiceNumber: "INV-2026-0007",
			quotationId: "QUO0011",
			customerId: "CUS0011",
			invoiceDate: "2026-05-10",
			paymentTerms: "15 Days",
			status: "Partially Paid",
			items: [{
				itemCode: "PRD019",
				description: "Aluminum Fin Tube, Corrosion Resistant",
				qty: 400,
				rate: 990,
				discount: 7,
				gst: 18,
				amount: 368280
			}],
			subtotal: 368280,
			gstAmount: 66290.4,
			grandTotal: 434570.4,
			payments: [{
				paymentId: "PAY0007",
				date: "2026-05-25",
				mode: "Cheque",
				amount: 2e5,
				reference: "CHQ12345"
			}]
		},
		{
			invoiceId: "INV0009",
			invoiceNumber: "INV-2026-0009",
			quotationId: "QUO0008",
			customerId: "CUS0008",
			invoiceDate: "2026-05-05",
			paymentTerms: "30 Days",
			status: "Paid",
			items: [{
				itemCode: "PRD013",
				description: "SS Fin Tube, 304 Grade",
				qty: 90,
				rate: 3100,
				discount: 5,
				gst: 18,
				amount: 265050
			}],
			subtotal: 265050,
			gstAmount: 47709,
			grandTotal: 312759,
			payments: [{
				paymentId: "PAY0009",
				date: "2026-05-28",
				mode: "NEFT",
				amount: 312759,
				reference: "UTR1122334455"
			}]
		},
		{
			invoiceId: "INV0010",
			invoiceNumber: "INV-2026-0010",
			quotationId: "QUO0006",
			customerId: "CUS0006",
			invoiceDate: "2026-04-30",
			paymentTerms: "30 Days",
			status: "Paid",
			items: [{
				itemCode: "PRD009",
				description: "Extruded Aluminum Fin Tube",
				qty: 300,
				rate: 1450,
				discount: 8,
				gst: 18,
				amount: 400200
			}],
			subtotal: 400200,
			gstAmount: 72036,
			grandTotal: 472236,
			payments: [{
				paymentId: "PAY0010",
				date: "2026-05-15",
				mode: "RTGS",
				amount: 472236,
				reference: "RTGS987654"
			}]
		},
		{
			invoiceId: "INV0011",
			invoiceNumber: "INV-2026-0011",
			quotationId: "QUO0002",
			customerId: "CUS0002",
			invoiceDate: "2026-04-15",
			paymentTerms: "45 Days",
			status: "Unpaid",
			items: [{
				itemCode: "PRD003",
				description: "Aluminum Fin Tube",
				qty: 500,
				rate: 850,
				discount: 3,
				gst: 18,
				amount: 412250
			}],
			subtotal: 412250,
			gstAmount: 74205,
			grandTotal: 486455,
			payments: []
		}
	]
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxNQUFNLE9BQU87Q0FDbEIsV0FBVztFQUNUO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtFQUNBO0dBQ0UsWUFBWTtHQUNaLGNBQWM7R0FDZCxhQUFhO0dBQ2IsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsYUFBYTtHQUNiLGNBQWM7R0FDZCxVQUFVO0dBQ1YsVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixhQUFhO0lBQ2IsT0FBTztJQUNQLFFBQVE7R0FDVixDQUNGO0dBQ0EsZ0JBQWdCO0lBQ2QsVUFBVTtJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLGlCQUFpQjtJQUNmLFVBQVU7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFNBQVM7SUFDVCxTQUFTO0dBQ1g7RUFDRjtDQUNGO0NBQ0EsWUFBWTtFQUNWO0dBQ0UsYUFBYTtHQUNiLGlCQUFpQjtHQUNqQixZQUFZO0dBQ1osZUFBZTtHQUNmLFlBQVk7R0FDWixRQUFRO0dBQ1IsT0FBTyxDQUNMO0lBQ0UsVUFBVTtJQUNWLGFBQWE7SUFDYixLQUFLO0lBQ0wsTUFBTTtJQUNOLFVBQVU7SUFDVixLQUFLO0lBQ0wsUUFBUTtHQUNWLEdBQ0M7SUFDQyxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0VBQ0E7R0FDRSxhQUFhO0dBQ2IsaUJBQWlCO0dBQ2pCLFlBQVk7R0FDWixlQUFlO0dBQ2YsWUFBWTtHQUNaLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0VBQ0E7R0FDRSxhQUFhO0dBQ2IsaUJBQWlCO0dBQ2pCLFlBQVk7R0FDWixlQUFlO0dBQ2YsWUFBWTtHQUNaLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0VBQ0E7R0FDRSxhQUFhO0dBQ2IsaUJBQWlCO0dBQ2pCLFlBQVk7R0FDWixlQUFlO0dBQ2YsWUFBWTtHQUNaLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0VBQ0E7R0FDRSxhQUFhO0dBQ2IsaUJBQWlCO0dBQ2pCLFlBQVk7R0FDWixlQUFlO0dBQ2YsWUFBWTtHQUNaLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0VBQ0E7R0FDRSxhQUFhO0dBQ2IsaUJBQWlCO0dBQ2pCLFlBQVk7R0FDWixlQUFlO0dBQ2YsWUFBWTtHQUNaLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixLQUFLO0dBQ0wsWUFBWTtFQUNkO0NBQ0Y7Q0FDQSxVQUFVO0VBQ1I7R0FDRSxXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixZQUFZO0dBQ1osYUFBYTtHQUNiLGNBQWM7R0FDZCxRQUFRO0dBQ1IsT0FBTyxDQUNMO0lBQ0UsVUFBVTtJQUNWLGFBQWE7SUFDYixLQUFLO0lBQ0wsTUFBTTtJQUNOLFVBQVU7SUFDVixLQUFLO0lBQ0wsUUFBUTtHQUNWLENBQ0Y7R0FDQSxVQUFVO0dBQ1YsV0FBVztHQUNYLFlBQVk7R0FDWixVQUFVLENBQUM7RUFDYjtFQUNBO0dBQ0UsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsWUFBWTtHQUNaLGFBQWE7R0FDYixjQUFjO0dBQ2QsUUFBUTtHQUNSLE9BQU8sQ0FDTDtJQUNFLFVBQVU7SUFDVixhQUFhO0lBQ2IsS0FBSztJQUNMLE1BQU07SUFDTixVQUFVO0lBQ1YsS0FBSztJQUNMLFFBQVE7R0FDVixDQUNGO0dBQ0EsVUFBVTtHQUNWLFdBQVc7R0FDWCxZQUFZO0dBQ1osVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFdBQVc7R0FDYixDQUNGO0VBQ0Y7RUFDQTtHQUNFLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLFlBQVk7R0FDWixhQUFhO0dBQ2IsY0FBYztHQUNkLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixXQUFXO0dBQ1gsWUFBWTtHQUNaLFVBQVUsQ0FDUjtJQUNFLFdBQVc7SUFDWCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixXQUFXO0dBQ2IsQ0FDRjtFQUNGO0VBQ0E7R0FDRSxXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixZQUFZO0dBQ1osYUFBYTtHQUNiLGNBQWM7R0FDZCxRQUFRO0dBQ1IsT0FBTyxDQUNMO0lBQ0UsVUFBVTtJQUNWLGFBQWE7SUFDYixLQUFLO0lBQ0wsTUFBTTtJQUNOLFVBQVU7SUFDVixLQUFLO0lBQ0wsUUFBUTtHQUNWLENBQ0Y7R0FDQSxVQUFVO0dBQ1YsV0FBVztHQUNYLFlBQVk7R0FDWixVQUFVLENBQUM7RUFDYjtFQUNBO0dBQ0UsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsWUFBWTtHQUNaLGFBQWE7R0FDYixjQUFjO0dBQ2QsUUFBUTtHQUNSLE9BQU8sQ0FDTDtJQUNFLFVBQVU7SUFDVixhQUFhO0lBQ2IsS0FBSztJQUNMLE1BQU07SUFDTixVQUFVO0lBQ1YsS0FBSztJQUNMLFFBQVE7R0FDVixDQUNGO0dBQ0EsVUFBVTtHQUNWLFdBQVc7R0FDWCxZQUFZO0dBQ1osVUFBVSxDQUFDO0VBQ2I7RUFDQTtHQUNFLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLFlBQVk7R0FDWixhQUFhO0dBQ2IsY0FBYztHQUNkLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixXQUFXO0dBQ1gsWUFBWTtHQUNaLFVBQVUsQ0FDUjtJQUNFLFdBQVc7SUFDWCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixXQUFXO0dBQ2IsQ0FDRjtFQUNGO0VBQ0E7R0FDRSxXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixZQUFZO0dBQ1osYUFBYTtHQUNiLGNBQWM7R0FDZCxRQUFRO0dBQ1IsT0FBTyxDQUNMO0lBQ0UsVUFBVTtJQUNWLGFBQWE7SUFDYixLQUFLO0lBQ0wsTUFBTTtJQUNOLFVBQVU7SUFDVixLQUFLO0lBQ0wsUUFBUTtHQUNWLENBQ0Y7R0FDQSxVQUFVO0dBQ1YsV0FBVztHQUNYLFlBQVk7R0FDWixVQUFVLENBQ1I7SUFDRSxXQUFXO0lBQ1gsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsV0FBVztHQUNiLENBQ0Y7RUFDRjtFQUNBO0dBQ0UsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsWUFBWTtHQUNaLGFBQWE7R0FDYixjQUFjO0dBQ2QsUUFBUTtHQUNSLE9BQU8sQ0FDTDtJQUNFLFVBQVU7SUFDVixhQUFhO0lBQ2IsS0FBSztJQUNMLE1BQU07SUFDTixVQUFVO0lBQ1YsS0FBSztJQUNMLFFBQVE7R0FDVixDQUNGO0dBQ0EsVUFBVTtHQUNWLFdBQVc7R0FDWCxZQUFZO0dBQ1osVUFBVSxDQUNSO0lBQ0UsV0FBVztJQUNYLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFdBQVc7R0FDYixDQUNGO0VBQ0Y7RUFDQTtHQUNFLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLFlBQVk7R0FDWixhQUFhO0dBQ2IsY0FBYztHQUNkLFFBQVE7R0FDUixPQUFPLENBQ0w7SUFDRSxVQUFVO0lBQ1YsYUFBYTtJQUNiLEtBQUs7SUFDTCxNQUFNO0lBQ04sVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0dBQ1YsQ0FDRjtHQUNBLFVBQVU7R0FDVixXQUFXO0dBQ1gsWUFBWTtHQUNaLFVBQVUsQ0FBQztFQUNiO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXRhLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBEYXRhID0ge1xyXG4gIGN1c3RvbWVyczogW1xyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMDFcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDAxXCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkFCQyBFbmdpbmVlcmluZyBQdnQgTHRkXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIzM0FCQ0RFMTIzNEYxWjVcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIkFCQ0RFMTIzNEZcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMTAwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMDFcIixcclxuICAgICAgICAgIG5hbWU6IFwiUmFqZXNoIEt1bWFyXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJQdXJjaGFzZSBNYW5hZ2VyXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJyYWplc2hAYWJjZW5naW5lZXJpbmcuY29tXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTg3NjU0MzIxMFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiTm8uMTIgU0lEQ08gSW5kdXN0cmlhbCBFc3RhdGVcIixcclxuICAgICAgICBjaXR5OiBcIkNoZW5uYWlcIixcclxuICAgICAgICBzdGF0ZTogXCJUYW1pbCBOYWR1XCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNjAwMDk4XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlBsYW50IDIsIFNJUENPVFwiLFxyXG4gICAgICAgIGNpdHk6IFwiQ2hlbm5haVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRhbWlsIE5hZHVcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2MDAwNThcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAwMlwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMDJcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiUHJlY2lzaW9uIEluZHVzdHJpZXMgSW5kaWFcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjIyUFFSUzU2NzhHMVoyXCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJQUVJTNTY3OEdcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogNzUwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiNDUgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAwMlwiLFxyXG4gICAgICAgICAgbmFtZTogXCJQcml5YSBTcmluaXZhc2FuXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJQcm9jdXJlbWVudCBIZWFkXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJwcml5YUBwcmVjaXNpb24uaW5kLmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTgyMzQ1Njc4OVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiUGxvdCA3LCBQaGFzZSBJSSwgRWxlY3Ryb25pYyBDaXR5XCIsXHJcbiAgICAgICAgY2l0eTogXCJCZW5nYWx1cnVcIixcclxuICAgICAgICBzdGF0ZTogXCJLYXJuYXRha2FcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI1NjAxMDBcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiV2FyZWhvdXNlIDQsIEJvbW1hc2FuZHJhXCIsXHJcbiAgICAgICAgY2l0eTogXCJCZW5nYWx1cnVcIixcclxuICAgICAgICBzdGF0ZTogXCJLYXJuYXRha2FcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI1NjAwOTlcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAwM1wiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMDNcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiU2FyYW5nIFRyYWRpbmcgQ29ycG9yYXRpb25cIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjI3U1RVVjkwMTJIMVo2XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJTVFVWOTAxMkhcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIlRyYWRlclwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogNTAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMTUgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAwM1wiLFxyXG4gICAgICAgICAgbmFtZTogXCJNYW5vaiBTaGFoXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJQcm9wcmlldG9yXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJtYW5vakBzYXJhbmd0cmFkaW5nLmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4MTIzNDU2NzBcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlNob3AgOCwgTG9oYXIgQ2hhd2xcIixcclxuICAgICAgICBjaXR5OiBcIk11bWJhaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDAwMDAyXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlNob3AgOCwgTG9oYXIgQ2hhd2xcIixcclxuICAgICAgICBjaXR5OiBcIk11bWJhaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDAwMDAyXCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMDRcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDA0XCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIlJlbGlhbmNlIEhlYXQgRXhjaGFuZ2VycyBMdGRcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjI0TE1OTzM0NTZBMVozXCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJMTU5PMzQ1NkFcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMjUwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjYwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMDRcIixcclxuICAgICAgICAgIG5hbWU6IFwiU3VuaWwgUmVkZHlcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlZpY2UgUHJlc2lkZW50IC0gUHJvY3VyZW1lbnRcIixcclxuICAgICAgICAgIGVtYWlsOiBcInN1bmlsQHJlbGlhbmNlaGUuaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5OTg4Nzc2NjU1XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJIIEJsb2NrLCBNSURDLCBQYXRhbGdhbmdhXCIsXHJcbiAgICAgICAgY2l0eTogXCJSYWlnYWRcIixcclxuICAgICAgICBzdGF0ZTogXCJNYWhhcmFzaHRyYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjQxMDIwNlwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQYXRhbGdhbmdhIFdvcmtzLCBIIEJsb2NrXCIsXHJcbiAgICAgICAgY2l0eTogXCJSYWlnYWRcIixcclxuICAgICAgICBzdGF0ZTogXCJNYWhhcmFzaHRyYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjQxMDIwNlwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDA1XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAwNVwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJUaGVybWFsIEVuZ2luZWVyaW5nIFNvbHV0aW9uc1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMjlXWFlaNzg5MEMxWjdcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIldYWVo3ODkwQ1wiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiQ29ycG9yYXRlXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiAxMjAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAwNVwiLFxyXG4gICAgICAgICAgbmFtZTogXCJBbmFueWEgUGF0ZWxcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIk1hbmFnZXIgLSBTdXBwbHkgQ2hhaW5cIixcclxuICAgICAgICAgIGVtYWlsOiBcImFuYW55YUB0aGVybWFsZW5nZy5jb21cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5ODc2NTAxMjM0XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQbG90IDIyLCBHSURDLCBWYXR2YVwiLFxyXG4gICAgICAgIGNpdHk6IFwiQWhtZWRhYmFkXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiR3VqYXJhdFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjM4MjQ0NVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJHSURDIFZhdHZhLCBVbml0IDJcIixcclxuICAgICAgICBjaXR5OiBcIkFobWVkYWJhZFwiLFxyXG4gICAgICAgIHN0YXRlOiBcIkd1amFyYXRcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIzODI0NDVcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAwNlwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMDZcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiS2VyYWxhIEluZHVzdHJpYWwgU3VwcGxpZXNcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjMyQUJDRDQzMjFGMVoyXCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJBQkNENDMyMUZcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogNjAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAwNlwiLFxyXG4gICAgICAgICAgbmFtZTogXCJUaG9tYXMgR2VvcmdlXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJQdXJjaGFzZSBNYW5hZ2VyXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJ0aG9tYXNAa2lzLmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTg3NjEyMzQ1NlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiTmVhciBLU1JUQyBEZXBvdCwgUGFsYXJpdmF0dG9tXCIsXHJcbiAgICAgICAgY2l0eTogXCJLb2NoaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIktlcmFsYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjY4MjAyNVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJJbmR1c3RyaWFsIFpvbmUsIEFtYmFsYW11Z2FsXCIsXHJcbiAgICAgICAgY2l0eTogXCJLb2NoaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIktlcmFsYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjY4MjMwMlwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDA3XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAwN1wiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJBZGl0eWEgUmVmcmlnZXJhdGlvbiBXb3Jrc1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMDhHSElKNTY3OEQxWjRcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIkdISUo1Njc4RFwiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiU01FXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiAzNTAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIxNSBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDA3XCIsXHJcbiAgICAgICAgICBuYW1lOiBcIlJhdmkgR3VwdGFcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIk93bmVyXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJyYXZpQGFkaXR5YXJlZi5pblwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk3ODY1NDMyMTBcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkEtNDUsIE1haGlwYWxwdXIgRXh0ZW5zaW9uXCIsXHJcbiAgICAgICAgY2l0eTogXCJOZXcgRGVsaGlcIixcclxuICAgICAgICBzdGF0ZTogXCJEZWxoaVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjExMDAzN1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJCLTEyLCBCYWRhcnB1ciBJbmR1c3RyaWFsIEFyZWFcIixcclxuICAgICAgICBjaXR5OiBcIk5ldyBEZWxoaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIkRlbGhpXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMTEwMDQ0XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMDhcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDA4XCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkJoYXJhdCBQaXBpbmcgU29sdXRpb25zXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIxOU1OT1AzNDU2QjFaMVwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiTU5PUDM0NTZCXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJDb3Jwb3JhdGVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDkwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjQ1IERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMDhcIixcclxuICAgICAgICAgIG5hbWU6IFwiSGFyaXNoIE5haXJcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlNlbmlvciBQdXJjaGFzZSBPZmZpY2VyXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJoYXJpc2hAYmhhcmF0cGlwaW5nLmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4MzQ1Njc4OTFcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIjU2LCBTZWN0b3IgMjcsIE1JRENcIixcclxuICAgICAgICBjaXR5OiBcIlB1bmVcIixcclxuICAgICAgICBzdGF0ZTogXCJNYWhhcmFzaHRyYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjQxMTAyOFwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQbG90IDcsIENoYWthbiBNSURDXCIsXHJcbiAgICAgICAgY2l0eTogXCJQdW5lXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiTWFoYXJhc2h0cmFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI0MTA1MDFcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAwOVwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMDlcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiUy5SLiBFbnRlcnByaXNlc1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMDdRUlNUNjc4OUUxWjZcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIlFSU1Q2Nzg5RVwiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiVHJhZGVyXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiAzMDAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCI3IERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMDlcIixcclxuICAgICAgICAgIG5hbWU6IFwiU3VuZGVyIFJhbWFzd2FteVwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiUGFydG5lclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwic3VuZGVyQHNyZW50ZXJwcmlzZXMuaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5ODQ1Njc4OTAxXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJXYXJkIDM2LCBOZWhydSBNYXJrZXRcIixcclxuICAgICAgICBjaXR5OiBcIkNvaW1iYXRvcmVcIixcclxuICAgICAgICBzdGF0ZTogXCJUYW1pbCBOYWR1XCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNjQxMDAxXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIldhcmQgMzYsIE5laHJ1IE1hcmtldFwiLFxyXG4gICAgICAgIGNpdHk6IFwiQ29pbWJhdG9yZVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRhbWlsIE5hZHVcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2NDEwMDFcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxMFwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMTBcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiQXF1YUNvb2wgVGVjaG5vbG9naWVzXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIzNlVWV1gxMjM0SzFaNVwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiVVZXWDEyMzRLXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJDb3Jwb3JhdGVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDgwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTBcIixcclxuICAgICAgICAgIG5hbWU6IFwiTmFyZXNoIEd1cHRhXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJWUCwgUHJvY3VyZW1lbnRcIixcclxuICAgICAgICAgIGVtYWlsOiBcIm5hcmVzaEBhcXVhY29vbHRlY2guY29tXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTY1NDMyMTg3NlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiUGxvdCA4OSwgUGhhc2UgSUlJLCBQYW5raVwiLFxyXG4gICAgICAgIGNpdHk6IFwiS2FucHVyXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiVXR0YXIgUHJhZGVzaFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjIwODAyMFwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQYW5raSBJbmR1c3RyaWFsIEFyZWEsIFVuaXQgM1wiLFxyXG4gICAgICAgIGNpdHk6IFwiS2FucHVyXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiVXR0YXIgUHJhZGVzaFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjIwODAyMFwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDExXCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAxMVwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJFYXN0ZXJuIFRyYWRpbmcgQ28uXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIxOVlaQUI0NTY3TTFaM1wiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiWVpBQjQ1NjdNXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJUcmFkZXJcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDQ1MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjIwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTFcIixcclxuICAgICAgICAgIG5hbWU6IFwiRGViaml0IE11a2hlcmplZVwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiUHJvcHJpZXRvclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwiZGViaml0QGVhc3Rlcm50cmFkaW5nLmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4NzY1MTIzNDVcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIjE1LCBHYW5lc2ggQ2hhbmRyYSBBdmVudWVcIixcclxuICAgICAgICBjaXR5OiBcIktvbGthdGFcIixcclxuICAgICAgICBzdGF0ZTogXCJXZXN0IEJlbmdhbFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjcwMDAxM1wiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCIxMCwgU3RyYW5kIFJvYWRcIixcclxuICAgICAgICBjaXR5OiBcIktvbGthdGFcIixcclxuICAgICAgICBzdGF0ZTogXCJXZXN0IEJlbmdhbFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjcwMDAwMVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDEyXCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAxMlwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJTdXJ5YSBIZWF0IFN5c3RlbXNcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjI5QkNERTc4OTBOMVo4XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJCQ0RFNzg5ME5cIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMTEwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjYwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTJcIixcclxuICAgICAgICAgIG5hbWU6IFwiUmFtZXNoIFNoYXJtYVwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiR2VuZXJhbCBNYW5hZ2VyIC0gU0NNXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJyYW1lc2hAc3VyeWFoZWF0LmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4OTg5ODk4OThcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkstMTUsIElEQSwgVXBwYWxcIixcclxuICAgICAgICBjaXR5OiBcIkh5ZGVyYWJhZFwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRlbGFuZ2FuYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjUwMDAzOVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJJREEgVXBwYWwsIFVuaXQgOVwiLFxyXG4gICAgICAgIGNpdHk6IFwiSHlkZXJhYmFkXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiVGVsYW5nYW5hXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNTAwMDM5XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMTNcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDEzXCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkNvb2wgRmxvdyBJbmR1c3RyaWVzXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIwOEZHSEk0NTY3UDFaMlwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiRkdISTQ1NjdQXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJTTUVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDQwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTNcIixcclxuICAgICAgICAgIG5hbWU6IFwiVmlqYXkgS2FzaHlhcFwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiRGlyZWN0b3JcIixcclxuICAgICAgICAgIGVtYWlsOiBcInZpamF5QGNvb2xmbG93LmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTgxMTExMjIyMlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiQy05LCBNYXlhcHVyaSBJbmRsIEFyZWFcIixcclxuICAgICAgICBjaXR5OiBcIk5ldyBEZWxoaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIkRlbGhpXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMTEwMDY0XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkMtOSwgTWF5YXB1cmkgSW5kbCBBcmVhXCIsXHJcbiAgICAgICAgY2l0eTogXCJOZXcgRGVsaGlcIixcclxuICAgICAgICBzdGF0ZTogXCJEZWxoaVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjExMDA2NFwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDE0XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAxNFwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJNL3MuIEtyaXNobmEgRmFicmljYXRpb25zXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIzM0pLTE0xMjM0UTFaNVwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiSktMTTEyMzRRXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJTTUVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDI1MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjE1IERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTRcIixcclxuICAgICAgICAgIG5hbWU6IFwiS3Jpc2huYSBNb29ydGh5XCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJQcm9wcmlldG9yXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJrcmlzaG5hQGtyaXNoZmFiLmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTg0NTA5ODQ1MFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiNUEsIE1ldHR1cGFsYXlhbSBSb2FkXCIsXHJcbiAgICAgICAgY2l0eTogXCJUaXJ1cHB1clwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRhbWlsIE5hZHVcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2NDE2MDRcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiNUEsIE1ldHR1cGFsYXlhbSBSb2FkXCIsXHJcbiAgICAgICAgY2l0eTogXCJUaXJ1cHB1clwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRhbWlsIE5hZHVcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2NDE2MDRcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxNVwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMTVcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiR3VqYXJhdCBCb2lsZXIgJiBIZWF0IEV4Y2hhbmdlcnNcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjI0Tk9QUTU2NzhSMVo2XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJOT1BRNTY3OFJcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMjAwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjQ1IERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTVcIixcclxuICAgICAgICAgIG5hbWU6IFwiS2V0YW4gU2hhaFwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiRGlyZWN0b3IgLSBQcm9jdXJlbWVudFwiLFxyXG4gICAgICAgICAgZW1haWw6IFwia2V0YW5AZ2JoZS5pblwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk5MjUwMDEyMzRcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlBsb3QgMS8yLCBHSURDLCBBbmtsZXNod2FyXCIsXHJcbiAgICAgICAgY2l0eTogXCJCaGFydWNoXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiR3VqYXJhdFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjM5MzAwMlwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJHSURDIEFua2xlc2h3YXIsIFVuaXQgNFwiLFxyXG4gICAgICAgIGNpdHk6IFwiQmhhcnVjaFwiLFxyXG4gICAgICAgIHN0YXRlOiBcIkd1amFyYXRcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIzOTMwMDJcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxNlwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMTZcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiUHJpc3RpbmUgQ29vbGluZyBTeXN0ZW1zXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIyOVNUVVYzNDU2UzFaN1wiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiU1RVVjM0NTZTXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJDb3Jwb3JhdGVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDk1MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTZcIixcclxuICAgICAgICAgIG5hbWU6IFwiQW1pdCBKYWluXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJNYW5hZ2VyIC0gU3VwcGx5IENoYWluXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJhbWl0QHByaXN0aW5lY29vbC5pblwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4NzY1NDc4OTFcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlBsb3QgNiwgTm9pZGEgU3BlY2lhbCBFY29ub21pYyBab25lXCIsXHJcbiAgICAgICAgY2l0eTogXCJOb2lkYVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlV0dGFyIFByYWRlc2hcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIyMDEzMDVcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiTlNFRFosIFVuaXQgMkJcIixcclxuICAgICAgICBjaXR5OiBcIk5vaWRhXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiVXR0YXIgUHJhZGVzaFwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjIwMTMwNVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDE3XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAxN1wiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJTb3V0aGVybiBQaXBlIEluZHVzdHJpZXNcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjMzV1hZWjIzNDVUMVoxXCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJXWFlaMjM0NVRcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogNzAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAxN1wiLFxyXG4gICAgICAgICAgbmFtZTogXCJNdXJhbGkgS3Jpc2huYW5cIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlB1cmNoYXNlIE1hbmFnZXJcIixcclxuICAgICAgICAgIGVtYWlsOiBcIm11cmFsaUBzb3V0aGVybnBpcGUuaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5NDQ0MDEyMzQ1XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCIxOCwgVGhpcnV2YWxsdXZhciBTdHJlZXRcIixcclxuICAgICAgICBjaXR5OiBcIk1hZHVyYWlcIixcclxuICAgICAgICBzdGF0ZTogXCJUYW1pbCBOYWR1XCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNjI1MDAxXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkluZHVzdHJpYWwgRXN0YXRlLCBLYXBwYWx1clwiLFxyXG4gICAgICAgIGNpdHk6IFwiTWFkdXJhaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRhbWlsIE5hZHVcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2MjUwMDhcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxOFwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMThcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiQXBleCBFbmdpbmVlcmluZyAmIFN1cHBsaWVzXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIwOEFCQ0Q2Nzg5VTFaOVwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiQUJDRDY3ODlVXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJTTUVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDM4MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjE1IERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMThcIixcclxuICAgICAgICAgIG5hbWU6IFwiU2FuamF5IEJhbnNhbFwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiUHJvcHJpZXRvclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwic2FuamF5QGFwZXhlbmdnLmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4MTIzNDU2NzhcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkEtNzksIERTSURDIENvbXBsZXgsIEJhd2FuYVwiLFxyXG4gICAgICAgIGNpdHk6IFwiTmV3IERlbGhpXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiRGVsaGlcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIxMTAwMzlcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiQS03OSwgRFNJREMgQ29tcGxleCwgQmF3YW5hXCIsXHJcbiAgICAgICAgY2l0eTogXCJOZXcgRGVsaGlcIixcclxuICAgICAgICBzdGF0ZTogXCJEZWxoaVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjExMDAzOVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDE5XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAxOVwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJUYW1pbCBOYWR1IFJlZnJpZ2VyYXRpb24gQ28uXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIzM0VGR0g3ODkwVjFaM1wiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiRUZHSDc4OTBWXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJDb3Jwb3JhdGVcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDU1MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMTlcIixcclxuICAgICAgICAgIG5hbWU6IFwiU2l2YWt1bWFyIFJhamFuXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJNYW5hZ2VyLCBQdXJjaGFzZVwiLFxyXG4gICAgICAgICAgZW1haWw6IFwic2l2YWt1bWFyQHRucmVmLmNvLmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTc5MDkxMjM0NVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiMjEsIEdyZWFtcyBSb2FkXCIsXHJcbiAgICAgICAgY2l0eTogXCJDaGVubmFpXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiVGFtaWwgTmFkdVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjYwMDAwNlwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQZXJ1bmd1ZGkgSW5kdXN0cmlhbCBFc3RhdGVcIixcclxuICAgICAgICBjaXR5OiBcIkNoZW5uYWlcIixcclxuICAgICAgICBzdGF0ZTogXCJUYW1pbCBOYWR1XCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNjAwMDk2XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMjBcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDIwXCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIlJhaiBQcm9jZXNzIEVxdWlwbWVudFwiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMjdKS0xNNDU2N1cxWjhcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIkpLTE00NTY3V1wiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiU01FXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiA0NTAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIzMCBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDIwXCIsXHJcbiAgICAgICAgICBuYW1lOiBcIlJhamVuZHJhIFBhdGlsXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJEaXJlY3RvclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwicmFqQHJhanByb2Nlc3MuY29tXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTc2NTIzNDU2N1wiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiUGxvdCA0NSwgTUlEQywgQmhvc2FyaVwiLFxyXG4gICAgICAgIGNpdHk6IFwiUHVuZVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDExMDI2XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIk1JREMgQmhvc2FyaSwgVW5pdCAxMlwiLFxyXG4gICAgICAgIGNpdHk6IFwiUHVuZVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDExMDI2XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMjFcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDIxXCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkV2ZXJncmVlbiBIZWF0IFRyYW5zZmVyIExMUFwiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMjROT1BRMjM0NVgxWjJcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIk5PUFEyMzQ1WFwiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiQ29ycG9yYXRlXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiAxMzAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiNjAgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAyMVwiLFxyXG4gICAgICAgICAgbmFtZTogXCJSYWplc2ggTWVub25cIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlBhcnRuZXJcIixcclxuICAgICAgICAgIGVtYWlsOiBcInJhamVzaEBldmVyZ3JlZW5odC5jb21cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5ODc2NTQwMDExXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJCLTEyLCBWaWxlIFBhcmxlIEVhc3RcIixcclxuICAgICAgICBjaXR5OiBcIk11bWJhaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDAwMDU3XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlVuaXQgNSwgVFRDLCBOYXZpIE11bWJhaVwiLFxyXG4gICAgICAgIGNpdHk6IFwiTXVtYmFpXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiTWFoYXJhc2h0cmFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI0MDA3MDZcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAyMlwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMjJcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiU3VyYWJoaSBJbmR1c3RyaWFsIENvcnBvcmF0aW9uXCIsXHJcbiAgICAgIGdzdE51bWJlcjogXCIyOVFSU1Q4OTAxWTFaNFwiLFxyXG4gICAgICBwYW5OdW1iZXI6IFwiUVJTVDg5MDFZXCIsXHJcbiAgICAgIGN1c3RvbWVyVHlwZTogXCJUcmFkZXJcIixcclxuICAgICAgY3JlZGl0TGltaXQ6IDI4MDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjEwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMjJcIixcclxuICAgICAgICAgIG5hbWU6IFwiR2lyaXNoIFNoYXJtYVwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiUHJvcHJpZXRvclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwiZ2lyaXNoQHN1cmFiaGlpbmQuY29tXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTgyMjIyMzMzM1wiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiRy05LCBSLksuIFB1cmFtLCBTZWN0b3IgNVwiLFxyXG4gICAgICAgIGNpdHk6IFwiSmFpcHVyXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiUmFqYXN0aGFuXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMzAyMDE4XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkctOSwgUi5LLiBQdXJhbSwgU2VjdG9yIDVcIixcclxuICAgICAgICBjaXR5OiBcIkphaXB1clwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlJhamFzdGhhblwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjMwMjAxOFwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDIzXCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAyM1wiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJJbmR1cyBQcmVjaXNpb24gQ29tcG9uZW50c1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMzZVVldYNjc4OVoxWjVcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIlVWV1g2Nzg5WlwiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiQ29ycG9yYXRlXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiA4MjAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCI0NSBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDIzXCIsXHJcbiAgICAgICAgICBuYW1lOiBcIkFsb2sgVmVybWFcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlB1cmNoYXNlIE1hbmFnZXJcIixcclxuICAgICAgICAgIGVtYWlsOiBcImFsb2tAaW5kdXNwcmVjaXNpb24uaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI3ODk2NTQxMjMwXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJBLTE4LCBTZWN0b3IgNjUsIE5vaWRhXCIsXHJcbiAgICAgICAgY2l0eTogXCJOb2lkYVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlV0dGFyIFByYWRlc2hcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIyMDEzMDFcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiQS0xOCwgU2VjdG9yIDY1LCBOb2lkYVwiLFxyXG4gICAgICAgIGNpdHk6IFwiTm9pZGFcIixcclxuICAgICAgICBzdGF0ZTogXCJVdHRhciBQcmFkZXNoXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMjAxMzAxXCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMjRcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDI0XCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkNvYXN0YWwgQ29vbGluZyBQcm9kdWN0c1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMzJBQkNEMTIzNEExWjZcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIkFCQ0QxMjM0QVwiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiU01FXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiA0MjAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIzMCBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDI0XCIsXHJcbiAgICAgICAgICBuYW1lOiBcIkpvc2VwaCBBbnRvbnlcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIk1hbmFnaW5nIFBhcnRuZXJcIixcclxuICAgICAgICAgIGVtYWlsOiBcImpvc2VwaEBjb2FzdGFsY29vbC5pblwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk0NDcxMjM0NTZcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIjMyLCBLYWxvb3ItS2FkYXZhbnRocmEgUm9hZFwiLFxyXG4gICAgICAgIGNpdHk6IFwiS29jaGlcIixcclxuICAgICAgICBzdGF0ZTogXCJLZXJhbGFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI2ODIwMTdcIiwgIFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJLSU5GUkEgSW5kdXN0cmlhbCBQYXJrXCIsXHJcbiAgICAgICAgY2l0eTogXCJLb2NoaVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIktlcmFsYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjY4MzUwMVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDI1XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAyNVwiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJIaW5kYWxjbyBIZWF0IEV4Y2hhbmdlcnMgRGl2aXNpb25cIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjA5RUZHSDM0NTZCMVo4XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJFRkdIMzQ1NkJcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMzAwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjYwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMjVcIixcclxuICAgICAgICAgIG5hbWU6IFwiUHJha2FzaCBTaW5naFwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiSGVhZCAtIFJhdyBNYXRlcmlhbHNcIixcclxuICAgICAgICAgIGVtYWlsOiBcInByYWthc2guc2luZ2hAaGluZGFsY28uaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5OTY2MzMyMjExXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJSZW51a29vdCBXb3JrcywgU29uZWJoYWRyYVwiLFxyXG4gICAgICAgIGNpdHk6IFwiUmVudWtvb3RcIixcclxuICAgICAgICBzdGF0ZTogXCJVdHRhciBQcmFkZXNoXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMjMxMjE3XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlJlbnVrb290IFBsYW50XCIsXHJcbiAgICAgICAgY2l0eTogXCJSZW51a29vdFwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlV0dGFyIFByYWRlc2hcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIyMzEyMTdcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAyNlwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMjZcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiU3Jpbml2YXNhIFJlZnJpZ2VyYXRpb24gJiBBQ1wiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMzdJSktMNzg5MEMxWjJcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIklKS0w3ODkwQ1wiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiU01FXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiAyMDAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIxNSBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDI2XCIsXHJcbiAgICAgICAgICBuYW1lOiBcIlNyaW5pdmFzIFJhb1wiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiUHJvcHJpZXRvclwiLFxyXG4gICAgICAgICAgZW1haWw6IFwic3Jpbml2YXNAc3JhYy5pblwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjkzOTM5MzkzOTNcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIjMtNC0xMDIsIEtvdGhhcGV0XCIsXHJcbiAgICAgICAgY2l0eTogXCJIeWRlcmFiYWRcIixcclxuICAgICAgICBzdGF0ZTogXCJUZWxhbmdhbmFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI1MDAwMzVcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiMy00LTEwMiwgS290aGFwZXRcIixcclxuICAgICAgICBjaXR5OiBcIkh5ZGVyYWJhZFwiLFxyXG4gICAgICAgIHN0YXRlOiBcIlRlbGFuZ2FuYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjUwMDAzNVwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDI3XCIsXHJcbiAgICAgIGN1c3RvbWVyQ29kZTogXCJDMDAyN1wiLFxyXG4gICAgICBjb21wYW55TmFtZTogXCJBdGxhcyBQaXBpbmcgJiBFcXVpcG1lbnRcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjA4TU5PUDQ1NjdEMVozXCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJNTk9QNDU2N0RcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogNjAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAyN1wiLFxyXG4gICAgICAgICAgbmFtZTogXCJWaXZlayBCaGF0aWFcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIk1hbmFnZXIgUHVyY2hhc2VcIixcclxuICAgICAgICAgIGVtYWlsOiBcInZpdmVrQGF0bGFzcGlwaW5nLmNvbVwiLFxyXG4gICAgICAgICAgbW9iaWxlOiBcIjk4MTIzNDU2NzBcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBiaWxsaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlBsb3QgMTQsIFVkeW9nIFZpaGFyLCBQaGFzZSBJVlwiLFxyXG4gICAgICAgIGNpdHk6IFwiR3VydWdyYW1cIixcclxuICAgICAgICBzdGF0ZTogXCJIYXJ5YW5hXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiMTIyMDE1XCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIlBsb3QgMTQsIFVkeW9nIFZpaGFyXCIsXHJcbiAgICAgICAgY2l0eTogXCJHdXJ1Z3JhbVwiLFxyXG4gICAgICAgIHN0YXRlOiBcIkhhcnlhbmFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCIxMjIwMTVcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAyOFwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMjhcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiT20gU2FpIFJlZnJpZ2VyYXRpb25cIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjI3UVJTVDU2NzhFMVo0XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJRUlNUNTY3OEVcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIlNNRVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMzAwMDAwLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMTUgRGF5c1wiLFxyXG4gICAgICBjdXJyZW5jeTogXCJJTlJcIixcclxuICAgICAgY29udGFjdHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBjb250YWN0SWQ6IFwiQ05UMDAyOFwiLFxyXG4gICAgICAgICAgbmFtZTogXCJSYXZpIFNoYW5rYXJcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIlBhcnRuZXJcIixcclxuICAgICAgICAgIGVtYWlsOiBcInJhdmlAb21zYWlyZWYuaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5ODM0NTY3ODkwXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJTLTcsIE0uSS5ELkMsIFNhdHB1clwiLFxyXG4gICAgICAgIGNpdHk6IFwiTmFzaGlrXCIsXHJcbiAgICAgICAgc3RhdGU6IFwiTWFoYXJhc2h0cmFcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI0MjIwMDdcIixcclxuICAgICAgfSxcclxuICAgICAgc2hpcHBpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiUy03LCBNLkkuRC5DLCBTYXRwdXJcIixcclxuICAgICAgICBjaXR5OiBcIk5hc2hpa1wiLFxyXG4gICAgICAgIHN0YXRlOiBcIk1haGFyYXNodHJhXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNDIyMDA3XCIsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMjlcIixcclxuICAgICAgY3VzdG9tZXJDb2RlOiBcIkMwMDI5XCIsXHJcbiAgICAgIGNvbXBhbnlOYW1lOiBcIkNvc21vcyBIZWF0IEV4Y2hhbmdlciBUZWNobm9sb2dpZXNcIixcclxuICAgICAgZ3N0TnVtYmVyOiBcIjMzVVZXWDc4OTBGMVo1XCIsXHJcbiAgICAgIHBhbk51bWJlcjogXCJVVldYNzg5MEZcIixcclxuICAgICAgY3VzdG9tZXJUeXBlOiBcIkNvcnBvcmF0ZVwiLFxyXG4gICAgICBjcmVkaXRMaW1pdDogMTgwMDAwMCxcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjYwIERheXNcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIGNvbnRhY3RzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29udGFjdElkOiBcIkNOVDAwMjlcIixcclxuICAgICAgICAgIG5hbWU6IFwiUmFqIEt1bWFyXCIsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogXCJWUCAtIFN1cHBseSBDaGFpblwiLFxyXG4gICAgICAgICAgZW1haWw6IFwicmFqLmt1bWFyQGNvc21vc2h0LmluXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IFwiOTg3NjU0NDQ0NFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIGJpbGxpbmdBZGRyZXNzOiB7XHJcbiAgICAgICAgYWRkcmVzczE6IFwiTm8uIDcsIEVsZWN0cm9uaWNzIENpdHkgUGhhc2UgMlwiLFxyXG4gICAgICAgIGNpdHk6IFwiQmVuZ2FsdXJ1XCIsXHJcbiAgICAgICAgc3RhdGU6IFwiS2FybmF0YWthXCIsXHJcbiAgICAgICAgY291bnRyeTogXCJJbmRpYVwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiNTYwMTAwXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHNoaXBwaW5nQWRkcmVzczoge1xyXG4gICAgICAgIGFkZHJlc3MxOiBcIkVsZWN0cm9uaWNzIENpdHkgUGhhc2UgMiwgVW5pdCA1XCIsXHJcbiAgICAgICAgY2l0eTogXCJCZW5nYWx1cnVcIixcclxuICAgICAgICBzdGF0ZTogXCJLYXJuYXRha2FcIixcclxuICAgICAgICBjb3VudHJ5OiBcIkluZGlhXCIsXHJcbiAgICAgICAgcGluY29kZTogXCI1NjAxMDBcIixcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAzMFwiLFxyXG4gICAgICBjdXN0b21lckNvZGU6IFwiQzAwMzBcIixcclxuICAgICAgY29tcGFueU5hbWU6IFwiS2FsaW5nYSBJbmR1c3RyaWFsIEVxdWlwbWVudFwiLFxyXG4gICAgICBnc3ROdW1iZXI6IFwiMjFZWkFCMjM0NUcxWjZcIixcclxuICAgICAgcGFuTnVtYmVyOiBcIllaQUIyMzQ1R1wiLFxyXG4gICAgICBjdXN0b21lclR5cGU6IFwiU01FXCIsXHJcbiAgICAgIGNyZWRpdExpbWl0OiA1MDAwMDAsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIzMCBEYXlzXCIsXHJcbiAgICAgIGN1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgICBjb250YWN0czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvbnRhY3RJZDogXCJDTlQwMDMwXCIsXHJcbiAgICAgICAgICBuYW1lOiBcIlNhbnRvc2ggTmF5YWtcIixcclxuICAgICAgICAgIGRlc2lnbmF0aW9uOiBcIkRpcmVjdG9yXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJzYW50b3NoQGthbGluZ2FpbmQuaW5cIixcclxuICAgICAgICAgIG1vYmlsZTogXCI5ODYxMTIzNDU2XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgYmlsbGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJQbG90IDMsIEluZHVzdHJpYWwgRXN0YXRlLCBNYW5jaGVzd2FyXCIsXHJcbiAgICAgICAgY2l0eTogXCJCaHViYW5lc3dhclwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk9kaXNoYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjc1MTAxMFwiLFxyXG4gICAgICB9LFxyXG4gICAgICBzaGlwcGluZ0FkZHJlc3M6IHtcclxuICAgICAgICBhZGRyZXNzMTogXCJNYW5jaGVzd2FyIEluZHVzdHJpYWwgRXN0YXRlXCIsXHJcbiAgICAgICAgY2l0eTogXCJCaHViYW5lc3dhclwiLFxyXG4gICAgICAgIHN0YXRlOiBcIk9kaXNoYVwiLFxyXG4gICAgICAgIGNvdW50cnk6IFwiSW5kaWFcIixcclxuICAgICAgICBwaW5jb2RlOiBcIjc1MTAxMFwiLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICBdLFxyXG4gIHF1b3RhdGlvbnM6IFtcclxuICAgIHtcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAwMlwiLFxyXG4gICAgICBxdW90YXRpb25OdW1iZXI6IFwiUVROLTIwMjYtMDAwMlwiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMDJcIixcclxuICAgICAgcXVvdGF0aW9uRGF0ZTogXCIyMDI2LTA0LTEwXCIsXHJcbiAgICAgIGV4cGlyeURhdGU6IFwiMjAyNi0wNS0xMFwiLFxyXG4gICAgICBzdGF0dXM6IFwiU2VudFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAwM1wiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiQWx1bWludW0gRmluIFR1YmVcIixcclxuICAgICAgICAgIHF0eTogNTAwLFxyXG4gICAgICAgICAgcmF0ZTogODUwLFxyXG4gICAgICAgICAgZGlzY291bnQ6IDMsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiA0MTIyNTAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAge1xyXG4gICAgICAgICAgaXRlbUNvZGU6IFwiUFJEMDA0XCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJBbHVtaW51bSBGaW4gVHViZSAxXCIsXHJcbiAgICAgICAgICBxdHk6IDUwMCxcclxuICAgICAgICAgIHJhdGU6IDg1MCxcclxuICAgICAgICAgIGRpc2NvdW50OiAzLFxyXG4gICAgICAgICAgZ3N0OiAxOCxcclxuICAgICAgICAgIGFtb3VudDogNDEyMjUwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YnRvdGFsOiA0MTIyNTAsXHJcbiAgICAgIHRheDogNzQyMDUsXHJcbiAgICAgIGdyYW5kVG90YWw6IDQ4NjQ1NSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHF1b3RhdGlvbklkOiBcIlFVTzAwMDRcIixcclxuICAgICAgcXVvdGF0aW9uTnVtYmVyOiBcIlFUTi0yMDI2LTAwMDRcIixcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDA0XCIsXHJcbiAgICAgIHF1b3RhdGlvbkRhdGU6IFwiMjAyNi0wNC0yMFwiLFxyXG4gICAgICBleHBpcnlEYXRlOiBcIjIwMjYtMDUtMjBcIixcclxuICAgICAgc3RhdHVzOiBcIkNvbnZlcnRlZFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAwMlwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiQ2FyYm9uIFN0ZWVsIEZpbiBUdWJlXCIsXHJcbiAgICAgICAgICBxdHk6IDEwMDAsXHJcbiAgICAgICAgICByYXRlOiA5NTAsXHJcbiAgICAgICAgICBkaXNjb3VudDogMTAsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiA4NTUwMDAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDg1NTAwMCxcclxuICAgICAgdGF4OiAxNTM5MDAsXHJcbiAgICAgIGdyYW5kVG90YWw6IDEwMDg5MDAsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDEwXCIsXHJcbiAgICAgIHF1b3RhdGlvbk51bWJlcjogXCJRVE4tMjAyNi0wMDEwXCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxMFwiLFxyXG4gICAgICBxdW90YXRpb25EYXRlOiBcIjIwMjYtMDUtMDVcIixcclxuICAgICAgZXhwaXJ5RGF0ZTogXCIyMDI2LTA2LTA1XCIsXHJcbiAgICAgIHN0YXR1czogXCJDb252ZXJ0ZWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMTdcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkNhcmJvbiBTdGVlbCBGaW4gVHViZSwgMjAgZnRcIixcclxuICAgICAgICAgIHF0eTogMTUwMCxcclxuICAgICAgICAgIHJhdGU6IDc4MCxcclxuICAgICAgICAgIGRpc2NvdW50OiAxMixcclxuICAgICAgICAgIGdzdDogMTgsXHJcbiAgICAgICAgICBhbW91bnQ6IDEwMjk2MDAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDEwMjYwMCxcclxuICAgICAgdGF4OiAxODUzMjgsXHJcbiAgICAgIGdyYW5kVG90YWw6IDEyMTQ5MjgsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDEzXCIsXHJcbiAgICAgIHF1b3RhdGlvbk51bWJlcjogXCJRVE4tMjAyNi0wMDEzXCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxM1wiLFxyXG4gICAgICBxdW90YXRpb25EYXRlOiBcIjIwMjYtMDUtMTBcIixcclxuICAgICAgZXhwaXJ5RGF0ZTogXCIyMDI2LTA2LTEwXCIsXHJcbiAgICAgIHN0YXR1czogXCJDb252ZXJ0ZWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMjNcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkV4dHJ1ZGVkIENvcHBlciBGaW4gVHViZVwiLFxyXG4gICAgICAgICAgcXR5OiA4NSxcclxuICAgICAgICAgIHJhdGU6IDI2MDAsXHJcbiAgICAgICAgICBkaXNjb3VudDogNSxcclxuICAgICAgICAgIGdzdDogMTgsXHJcbiAgICAgICAgICBhbW91bnQ6IDIwOTk1MCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBzdWJ0b3RhbDogMjA5OTUwLFxyXG4gICAgICB0YXg6IDM3NzkxLFxyXG4gICAgICBncmFuZFRvdGFsOiAyNDc3NDEsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDE3XCIsXHJcbiAgICAgIHF1b3RhdGlvbk51bWJlcjogXCJRVE4tMjAyNi0wMDE3XCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxN1wiLFxyXG4gICAgICBxdW90YXRpb25EYXRlOiBcIjIwMjYtMDUtMTZcIixcclxuICAgICAgZXhwaXJ5RGF0ZTogXCIyMDI2LTA2LTE2XCIsXHJcbiAgICAgIHN0YXR1czogXCJDb252ZXJ0ZWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMzFcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNTIEZpbiBUdWJlLCAzMDRMXCIsXHJcbiAgICAgICAgICBxdHk6IDExMCxcclxuICAgICAgICAgIHJhdGU6IDMzNTAsXHJcbiAgICAgICAgICBkaXNjb3VudDogOCxcclxuICAgICAgICAgIGdzdDogMTgsXHJcbiAgICAgICAgICBhbW91bnQ6IDMzOTAyMCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBzdWJ0b3RhbDogMzM5MDIwLFxyXG4gICAgICB0YXg6IDYxMDIzLjYsXHJcbiAgICAgIGdyYW5kVG90YWw6IDQwMDA0My42LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAyMFwiLFxyXG4gICAgICBxdW90YXRpb25OdW1iZXI6IFwiUVROLTIwMjYtMDAyMFwiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMjBcIixcclxuICAgICAgcXVvdGF0aW9uRGF0ZTogXCIyMDI2LTA1LTIxXCIsXHJcbiAgICAgIGV4cGlyeURhdGU6IFwiMjAyNi0wNi0yMVwiLFxyXG4gICAgICBzdGF0dXM6IFwiQ29udmVydGVkXCIsXHJcbiAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaXRlbUNvZGU6IFwiUFJEMDM3XCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJBbHVtaW51bSBGaW4gVHViZSwgSGlnaCBEZW5zaXR5XCIsXHJcbiAgICAgICAgICBxdHk6IDM1MCxcclxuICAgICAgICAgIHJhdGU6IDEwNTAsXHJcbiAgICAgICAgICBkaXNjb3VudDogMTAsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiAzMzA3NTAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDMzMDc1MCxcclxuICAgICAgdGF4OiA1OTUzNSxcclxuICAgICAgZ3JhbmRUb3RhbDogMzkwMjg1LFxyXG4gICAgfSxcclxuICBdLFxyXG4gIGludm9pY2VzOiBbXHJcbiAgICB7XHJcbiAgICAgIGludm9pY2VJZDogXCJJTlYwMDAyXCIsXHJcbiAgICAgIGludm9pY2VOdW1iZXI6IFwiSU5WLTIwMjYtMDAwMlwiLFxyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDA0XCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAwNFwiLFxyXG4gICAgICBpbnZvaWNlRGF0ZTogXCIyMDI2LTA0LTI1XCIsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCI2MCBEYXlzXCIsXHJcbiAgICAgIHN0YXR1czogXCJVbnBhaWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMDJcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkNhcmJvbiBTdGVlbCBGaW4gVHViZVwiLFxyXG4gICAgICAgICAgcXR5OiAxMDAwLFxyXG4gICAgICAgICAgcmF0ZTogOTUwLFxyXG4gICAgICAgICAgZGlzY291bnQ6IDEwLFxyXG4gICAgICAgICAgZ3N0OiAxOCxcclxuICAgICAgICAgIGFtb3VudDogODU1MDAwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YnRvdGFsOiA4NTUwMDAsXHJcbiAgICAgIGdzdEFtb3VudDogMTUzOTAwLFxyXG4gICAgICBncmFuZFRvdGFsOiAxMDA4OTAwLFxyXG4gICAgICBwYXltZW50czogW10sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpbnZvaWNlSWQ6IFwiSU5WMDAwM1wiLFxyXG4gICAgICBpbnZvaWNlTnVtYmVyOiBcIklOVi0yMDI2LTAwMDNcIixcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAxMFwiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMTBcIixcclxuICAgICAgaW52b2ljZURhdGU6IFwiMjAyNi0wNS0wOFwiLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBzdGF0dXM6IFwiUGFydGlhbGx5IFBhaWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMTdcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkNhcmJvbiBTdGVlbCBGaW4gVHViZSwgMjAgZnRcIixcclxuICAgICAgICAgIHF0eTogMTUwMCxcclxuICAgICAgICAgIHJhdGU6IDc4MCxcclxuICAgICAgICAgIGRpc2NvdW50OiAxMixcclxuICAgICAgICAgIGdzdDogMTgsXHJcbiAgICAgICAgICBhbW91bnQ6IDEwMjk2MDAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDEwMjk2MDAsXHJcbiAgICAgIGdzdEFtb3VudDogMTg1MzI4LFxyXG4gICAgICBncmFuZFRvdGFsOiAxMjE0OTI4LFxyXG4gICAgICBwYXltZW50czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBheW1lbnRJZDogXCJQQVkwMDAzXCIsXHJcbiAgICAgICAgICBkYXRlOiBcIjIwMjYtMDUtMjBcIixcclxuICAgICAgICAgIG1vZGU6IFwiUlRHU1wiLFxyXG4gICAgICAgICAgYW1vdW50OiA1MDAwMDAsXHJcbiAgICAgICAgICByZWZlcmVuY2U6IFwiUlRHUzEyMzQ1NlwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpbnZvaWNlSWQ6IFwiSU5WMDAwNFwiLFxyXG4gICAgICBpbnZvaWNlTnVtYmVyOiBcIklOVi0yMDI2LTAwMDRcIixcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAxM1wiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMTNcIixcclxuICAgICAgaW52b2ljZURhdGU6IFwiMjAyNi0wNS0xNVwiLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBzdGF0dXM6IFwiUGFpZFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAyM1wiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiRXh0cnVkZWQgQ29wcGVyIEZpbiBUdWJlXCIsXHJcbiAgICAgICAgICBxdHk6IDg1LFxyXG4gICAgICAgICAgcmF0ZTogMjYwMCxcclxuICAgICAgICAgIGRpc2NvdW50OiA1LFxyXG4gICAgICAgICAgZ3N0OiAxOCxcclxuICAgICAgICAgIGFtb3VudDogMjA5OTUwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YnRvdGFsOiAyMDk5NTAsXHJcbiAgICAgIGdzdEFtb3VudDogMzc3OTEsXHJcbiAgICAgIGdyYW5kVG90YWw6IDI0Nzc0MSxcclxuICAgICAgcGF5bWVudHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXltZW50SWQ6IFwiUEFZMDAwNFwiLFxyXG4gICAgICAgICAgZGF0ZTogXCIyMDI2LTA2LTAxXCIsXHJcbiAgICAgICAgICBtb2RlOiBcIk5FRlRcIixcclxuICAgICAgICAgIGFtb3VudDogMjQ3NzQxLFxyXG4gICAgICAgICAgcmVmZXJlbmNlOiBcIlVUUjk4NzY1NDMyMVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpbnZvaWNlSWQ6IFwiSU5WMDAwNVwiLFxyXG4gICAgICBpbnZvaWNlTnVtYmVyOiBcIklOVi0yMDI2LTAwMDVcIixcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAxN1wiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMTdcIixcclxuICAgICAgaW52b2ljZURhdGU6IFwiMjAyNi0wNS0yMlwiLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiNDUgRGF5c1wiLFxyXG4gICAgICBzdGF0dXM6IFwiT3ZlcmR1ZVwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAzMVwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiU1MgRmluIFR1YmUsIDMwNExcIixcclxuICAgICAgICAgIHF0eTogMTEwLFxyXG4gICAgICAgICAgcmF0ZTogMzM1MCxcclxuICAgICAgICAgIGRpc2NvdW50OiA4LFxyXG4gICAgICAgICAgZ3N0OiAxOCxcclxuICAgICAgICAgIGFtb3VudDogMzM5MDIwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YnRvdGFsOiAzMzkwMjAsXHJcbiAgICAgIGdzdEFtb3VudDogNjEwMjMuNixcclxuICAgICAgZ3JhbmRUb3RhbDogNDAwMDQzLjYsXHJcbiAgICAgIHBheW1lbnRzOiBbXSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGludm9pY2VJZDogXCJJTlYwMDA2XCIsXHJcbiAgICAgIGludm9pY2VOdW1iZXI6IFwiSU5WLTIwMjYtMDAwNlwiLFxyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDIwXCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAyMFwiLFxyXG4gICAgICBpbnZvaWNlRGF0ZTogXCIyMDI2LTA1LTI1XCIsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIzMCBEYXlzXCIsXHJcbiAgICAgIHN0YXR1czogXCJVbnBhaWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMzdcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkFsdW1pbnVtIEZpbiBUdWJlLCBIaWdoIERlbnNpdHlcIixcclxuICAgICAgICAgIHF0eTogMzUwLFxyXG4gICAgICAgICAgcmF0ZTogMTA1MCxcclxuICAgICAgICAgIGRpc2NvdW50OiAxMCxcclxuICAgICAgICAgIGdzdDogMTgsXHJcbiAgICAgICAgICBhbW91bnQ6IDMzMDc1MCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBzdWJ0b3RhbDogMzMwNzUwLFxyXG4gICAgICBnc3RBbW91bnQ6IDU5NTM1LFxyXG4gICAgICBncmFuZFRvdGFsOiAzOTAyODUsXHJcbiAgICAgIHBheW1lbnRzOiBbXSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGludm9pY2VJZDogXCJJTlYwMDA3XCIsXHJcbiAgICAgIGludm9pY2VOdW1iZXI6IFwiSU5WLTIwMjYtMDAwN1wiLFxyXG4gICAgICBxdW90YXRpb25JZDogXCJRVU8wMDExXCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiQ1VTMDAxMVwiLFxyXG4gICAgICBpbnZvaWNlRGF0ZTogXCIyMDI2LTA1LTEwXCIsXHJcbiAgICAgIHBheW1lbnRUZXJtczogXCIxNSBEYXlzXCIsXHJcbiAgICAgIHN0YXR1czogXCJQYXJ0aWFsbHkgUGFpZFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAxOVwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiQWx1bWludW0gRmluIFR1YmUsIENvcnJvc2lvbiBSZXNpc3RhbnRcIixcclxuICAgICAgICAgIHF0eTogNDAwLFxyXG4gICAgICAgICAgcmF0ZTogOTkwLFxyXG4gICAgICAgICAgZGlzY291bnQ6IDcsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiAzNjgyODAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDM2ODI4MCxcclxuICAgICAgZ3N0QW1vdW50OiA2NjI5MC40LFxyXG4gICAgICBncmFuZFRvdGFsOiA0MzQ1NzAuNCxcclxuICAgICAgcGF5bWVudHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXltZW50SWQ6IFwiUEFZMDAwN1wiLFxyXG4gICAgICAgICAgZGF0ZTogXCIyMDI2LTA1LTI1XCIsXHJcbiAgICAgICAgICBtb2RlOiBcIkNoZXF1ZVwiLFxyXG4gICAgICAgICAgYW1vdW50OiAyMDAwMDAsXHJcbiAgICAgICAgICByZWZlcmVuY2U6IFwiQ0hRMTIzNDVcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaW52b2ljZUlkOiBcIklOVjAwMDlcIixcclxuICAgICAgaW52b2ljZU51bWJlcjogXCJJTlYtMjAyNi0wMDA5XCIsXHJcbiAgICAgIHF1b3RhdGlvbklkOiBcIlFVTzAwMDhcIixcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDA4XCIsXHJcbiAgICAgIGludm9pY2VEYXRlOiBcIjIwMjYtMDUtMDVcIixcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjMwIERheXNcIixcclxuICAgICAgc3RhdHVzOiBcIlBhaWRcIixcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpdGVtQ29kZTogXCJQUkQwMTNcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNTIEZpbiBUdWJlLCAzMDQgR3JhZGVcIixcclxuICAgICAgICAgIHF0eTogOTAsXHJcbiAgICAgICAgICByYXRlOiAzMTAwLFxyXG4gICAgICAgICAgZGlzY291bnQ6IDUsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiAyNjUwNTAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDI2NTA1MCxcclxuICAgICAgZ3N0QW1vdW50OiA0NzcwOSxcclxuICAgICAgZ3JhbmRUb3RhbDogMzEyNzU5LFxyXG4gICAgICBwYXltZW50czogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBheW1lbnRJZDogXCJQQVkwMDA5XCIsXHJcbiAgICAgICAgICBkYXRlOiBcIjIwMjYtMDUtMjhcIixcclxuICAgICAgICAgIG1vZGU6IFwiTkVGVFwiLFxyXG4gICAgICAgICAgYW1vdW50OiAzMTI3NTksXHJcbiAgICAgICAgICByZWZlcmVuY2U6IFwiVVRSMTEyMjMzNDQ1NVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpbnZvaWNlSWQ6IFwiSU5WMDAxMFwiLFxyXG4gICAgICBpbnZvaWNlTnVtYmVyOiBcIklOVi0yMDI2LTAwMTBcIixcclxuICAgICAgcXVvdGF0aW9uSWQ6IFwiUVVPMDAwNlwiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIkNVUzAwMDZcIixcclxuICAgICAgaW52b2ljZURhdGU6IFwiMjAyNi0wNC0zMFwiLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBzdGF0dXM6IFwiUGFpZFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAwOVwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiRXh0cnVkZWQgQWx1bWludW0gRmluIFR1YmVcIixcclxuICAgICAgICAgIHF0eTogMzAwLFxyXG4gICAgICAgICAgcmF0ZTogMTQ1MCxcclxuICAgICAgICAgIGRpc2NvdW50OiA4LFxyXG4gICAgICAgICAgZ3N0OiAxOCxcclxuICAgICAgICAgIGFtb3VudDogNDAwMjAwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YnRvdGFsOiA0MDAyMDAsXHJcbiAgICAgIGdzdEFtb3VudDogNzIwMzYsXHJcbiAgICAgIGdyYW5kVG90YWw6IDQ3MjIzNixcclxuICAgICAgcGF5bWVudHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXltZW50SWQ6IFwiUEFZMDAxMFwiLFxyXG4gICAgICAgICAgZGF0ZTogXCIyMDI2LTA1LTE1XCIsXHJcbiAgICAgICAgICBtb2RlOiBcIlJUR1NcIixcclxuICAgICAgICAgIGFtb3VudDogNDcyMjM2LFxyXG4gICAgICAgICAgcmVmZXJlbmNlOiBcIlJUR1M5ODc2NTRcIixcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaW52b2ljZUlkOiBcIklOVjAwMTFcIixcclxuICAgICAgaW52b2ljZU51bWJlcjogXCJJTlYtMjAyNi0wMDExXCIsXHJcbiAgICAgIHF1b3RhdGlvbklkOiBcIlFVTzAwMDJcIixcclxuICAgICAgY3VzdG9tZXJJZDogXCJDVVMwMDAyXCIsXHJcbiAgICAgIGludm9pY2VEYXRlOiBcIjIwMjYtMDQtMTVcIixcclxuICAgICAgcGF5bWVudFRlcm1zOiBcIjQ1IERheXNcIixcclxuICAgICAgc3RhdHVzOiBcIlVucGFpZFwiLFxyXG4gICAgICBpdGVtczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGl0ZW1Db2RlOiBcIlBSRDAwM1wiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiQWx1bWludW0gRmluIFR1YmVcIixcclxuICAgICAgICAgIHF0eTogNTAwLFxyXG4gICAgICAgICAgcmF0ZTogODUwLFxyXG4gICAgICAgICAgZGlzY291bnQ6IDMsXHJcbiAgICAgICAgICBnc3Q6IDE4LFxyXG4gICAgICAgICAgYW1vdW50OiA0MTIyNTAsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgc3VidG90YWw6IDQxMjI1MCxcclxuICAgICAgZ3N0QW1vdW50OiA3NDIwNSxcclxuICAgICAgZ3JhbmRUb3RhbDogNDg2NDU1LFxyXG4gICAgICBwYXltZW50czogW10sXHJcbiAgICB9LFxyXG4gIF0sXHJcbn07XHJcbiJdfQ==