import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Layout/Layout.jsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { Link, Outlet, useNavigate } from "/ERP-Project/node_modules/.vite/deps/react-router.js?v=f348e97d";
import __vite__cjsImport1_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import "/ERP-Project/src/Pages/Layout/layout.scss";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Pages/Layout/Layout.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
var _s = $RefreshSig$();
export default function Layout() {
	_s();
	const [open, setOpen] = useState(false);
	const [purchase, setPurchase] = useState(false);
	const [inventory, setInventory] = useState(false);
	const [manufacturing, setManufacturing] = useState(false);
	const [finance, setFinance] = useState(false);
	const [hr, setHr] = useState(false);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("div", {
		className: "main",
		children: [/* @__PURE__ */ _jsxDEV("nav", {
			className: "sidebar",
			children: [
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "Erp-admin",
					children: "ERP ADMIN "
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					children: /* @__PURE__ */ _jsxDEV("button", {
						className: "b1",
						children: "Dashboard"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 24
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setOpen(!open),
					children: [" ", /* @__PURE__ */ _jsxDEV("b", { children: "Sales" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 13
				}, this), open && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "div",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								className: "link-color",
								to: "/sales/customer",
								children: "Customer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 26,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								className: "link-color",
								to: "/sales/invoice",
								children: "Invoice"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 29,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 28,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								className: "link-color",
								to: "/sales/quotations",
								children: "Quottions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								className: "link-color",
								to: "/sales/salesorder",
								children: "Salesorder"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setPurchase(!purchase),
					children: "Purchase"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 13
				}, this), purchase && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Purchase/Good receipt",
							children: "Good Receipt"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Purchase/Purchase order",
							children: "Purchase Order"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Purchase/Vendors",
							children: "Vendors"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setInventory(!inventory),
					children: "Inventory"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 13
				}, this), inventory && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/inventory/product",
							children: "Product"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/inventory/Stock",
							children: "Stock"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/inventory/Transfer",
							children: "Transfer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/inventory/Warehouse",
							children: "Warehouse"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setManufacturing(!manufacturing),
					children: "Manufacturing"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 13
				}, this), manufacturing && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Manufacturing/BOM",
							children: "BOM"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Manufacturing/Productionorder",
							children: "Productionorder"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Manufacturing/Workorder",
							children: "Workorders"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setFinance(!finance),
					children: "Finance"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 13
				}, this), finance && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Finance/Accounts",
							children: "Accounts"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Finance/Expenses",
							children: "Expenses"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Finance/Payments",
							children: "Payments"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/Finance/Repots",
							children: "Reports"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "b1",
					onClick: () => setHr(!hr),
					children: "HR"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 13
				}, this), hr && /* @__PURE__ */ _jsxDEV("ul", {
					className: "bullet",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/HR/Attendence",
							children: "Attendence"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/HR/Employess",
							children: "Employess"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/HR/Leave",
							children: "Leave"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							className: "link-color",
							to: "/HR/Payroll",
							children: "Payroll"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "right",
			children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 150,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_s(Layout, "BWJqp1LzfHtbhvpJfFfjEru0vro=");
_c = Layout;
var _c;
$RefreshReg$(_c, "Layout");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Pages/Layout/Layout.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Pages/Layout/Layout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Pages/Layout/Layout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Pages/Layout/Layout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLFFBQVEsbUJBQW1CO0FBQzFDLFNBQVMsZ0JBQWdCO0FBQ3pCLE9BQU87Ozs7QUFDUCxlQUFlLFNBQVMsU0FBUzs7Q0FDL0IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsU0FBUyxLQUFLO0NBQ2xDLE9BQ0UsK0NBQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFZO0lBQWM7Ozs7O0lBQ3hDLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO2VBQUksd0JBQUMsVUFBRDtNQUFRLFdBQVU7Z0JBQUs7S0FBaUI7Ozs7O0lBQU87Ozs7O0lBQzVELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFLLGVBQWUsUUFBUSxDQUFDLElBQUk7ZUFBbkQsQ0FDRyxLQUNELHdCQUFDLEtBQUQsWUFBRyxRQUFROzs7O2FBQ0w7Ozs7O2NBQ1AsUUFDQyx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNaLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Esd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBTSxXQUFVO1FBQWEsSUFBRztrQkFBa0I7T0FBYzs7OztnQkFDOUQ7Ozs7O09BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBTSxXQUFVO1FBQWEsSUFBRztrQkFBaUI7T0FBYTs7OztnQkFDNUQ7Ozs7O09BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBTSxXQUFVO1FBQWEsSUFBRztrQkFBb0I7T0FBZTs7OztnQkFDakU7Ozs7O09BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBTSxXQUFVO1FBQWEsSUFBRztrQkFBb0I7T0FBZ0I7Ozs7Z0JBQ2xFOzs7OztNQUNDOzs7Ozs7SUFDSDs7OztZQUVIOzs7OztJQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFLLGVBQWUsWUFBWSxDQUFDLFFBQVE7ZUFBRztJQUV0RDs7OztjQUNQLFlBQ0Msd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZDtNQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQXlCO01BQWtCOzs7O2VBQ3pFOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQTJCO01BQW9COzs7O2VBQzdFOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQW9CO01BQWE7Ozs7ZUFDL0Q7Ozs7O0tBQ0Y7Ozs7O1lBRUg7Ozs7O0lBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQUssZUFBZSxhQUFhLENBQUMsU0FBUztlQUFHO0lBRXhEOzs7O2NBQ1AsYUFDQyx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQWEsSUFBRztpQkFBcUI7TUFBYTs7OztlQUNoRTs7Ozs7TUFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFtQjtNQUFXOzs7O2VBQzVEOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQXNCO01BQWM7Ozs7ZUFDbEU7Ozs7O01BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQWEsSUFBRztpQkFBdUI7TUFBZTs7OztlQUNwRTs7Ozs7S0FDRjs7Ozs7WUFFSDs7Ozs7SUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRDtLQUNFLFdBQVU7S0FDVixlQUFlLGlCQUFpQixDQUFDLGFBQWE7ZUFDL0M7SUFFTzs7OztjQUNQLGlCQUNDLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFxQjtNQUFTOzs7O2VBQzVEOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQWlDO01BRTNEOzs7O2VBQ0o7Ozs7O01BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQWEsSUFBRztpQkFBMkI7TUFBZ0I7Ozs7ZUFDekU7Ozs7O0tBQ0Y7Ozs7O1lBRUg7Ozs7O0lBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQUssZUFBZSxXQUFXLENBQUMsT0FBTztlQUFHO0lBRXBEOzs7O2NBQ1AsV0FDQyx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQWEsSUFBRztpQkFBb0I7TUFBYzs7OztlQUNoRTs7Ozs7TUFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFvQjtNQUFjOzs7O2VBQ2hFOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQW9CO01BQWM7Ozs7ZUFDaEU7Ozs7O01BQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQWEsSUFBRztpQkFBa0I7TUFBYTs7OztlQUM3RDs7Ozs7S0FDRjs7Ozs7WUFFSDs7Ozs7SUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBSyxlQUFlLE1BQU0sQ0FBQyxFQUFFO2VBQUc7SUFFMUM7Ozs7Y0FDUCxNQUNDLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFpQjtNQUFnQjs7OztlQUMvRDs7Ozs7TUFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFnQjtNQUFlOzs7O2VBQzdEOzs7OztNQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUFhLElBQUc7aUJBQVk7TUFBVzs7OztlQUNyRDs7Ozs7TUFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBYSxJQUFHO2lCQUFjO01BQWE7Ozs7ZUFDekQ7Ozs7O0tBQ0Y7Ozs7O1lBRUg7Ozs7O0dBQ0Y7Ozs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxRQUFELENBQVM7Ozs7O0VBQ047Ozs7VUFDRjs7Ozs7VUFDTDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMYXlvdXQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIE91dGxldCwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4vbGF5b3V0LnNjc3NcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0KCkge1xyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcHVyY2hhc2UsIHNldFB1cmNoYXNlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaW52ZW50b3J5LCBzZXRJbnZlbnRvcnldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttYW51ZmFjdHVyaW5nLCBzZXRNYW51ZmFjdHVyaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmluYW5jZSwgc2V0RmluYW5jZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2hyLCBzZXRIcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFpblwiPlxyXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic2lkZWJhclwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIkVycC1hZG1pblwiPkVSUCBBRE1JTiA8L2gyPlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJiMVwiPkRhc2hib2FyZDwvYnV0dG9uPjwvTGluaz5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYjFcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX0+XHJcbiAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgIDxiPlNhbGVzPC9iPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAge29wZW4gJiYgKFxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJidWxsZXRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2XCI+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImxpbmstY29sb3JcIiB0bz1cIi9zYWxlcy9jdXN0b21lclwiPkN1c3RvbWVyPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL3NhbGVzL2ludm9pY2VcIj5JbnZvaWNlPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL3NhbGVzL3F1b3RhdGlvbnNcIj5RdW90dGlvbnM8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvc2FsZXMvc2FsZXNvcmRlclwiPlNhbGVzb3JkZXI8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYjFcIiBvbkNsaWNrPXsoKSA9PiBzZXRQdXJjaGFzZSghcHVyY2hhc2UpfT5cclxuICAgICAgICAgICAgICAgUHVyY2hhc2VcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIHtwdXJjaGFzZSAmJiAoXHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImJ1bGxldFwiPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvUHVyY2hhc2UvR29vZCByZWNlaXB0XCI+R29vZCBSZWNlaXB0PC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL1B1cmNoYXNlL1B1cmNoYXNlIG9yZGVyXCI+UHVyY2hhc2UgT3JkZXI8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvUHVyY2hhc2UvVmVuZG9yc1wiPlZlbmRvcnM8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImIxXCIgb25DbGljaz17KCkgPT4gc2V0SW52ZW50b3J5KCFpbnZlbnRvcnkpfT5cclxuICAgICAgICAgICAgICAgSW52ZW50b3J5XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICB7aW52ZW50b3J5ICYmIChcclxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiYnVsbGV0XCI+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImxpbmstY29sb3JcIiB0bz1cIi9pbnZlbnRvcnkvcHJvZHVjdFwiPlByb2R1Y3Q8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvaW52ZW50b3J5L1N0b2NrXCI+U3RvY2s8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvaW52ZW50b3J5L1RyYW5zZmVyXCI+VHJhbnNmZXI8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvaW52ZW50b3J5L1dhcmVob3VzZVwiPldhcmVob3VzZTwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiMVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWFudWZhY3R1cmluZyghbWFudWZhY3R1cmluZyl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgTWFudWZhY3R1cmluZ1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAge21hbnVmYWN0dXJpbmcgJiYgKFxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJidWxsZXRcIj5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL01hbnVmYWN0dXJpbmcvQk9NXCI+Qk9NPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL01hbnVmYWN0dXJpbmcvUHJvZHVjdGlvbm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUHJvZHVjdGlvbm9yZGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImxpbmstY29sb3JcIiB0bz1cIi9NYW51ZmFjdHVyaW5nL1dvcmtvcmRlclwiPldvcmtvcmRlcnM8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImIxXCIgb25DbGljaz17KCkgPT4gc2V0RmluYW5jZSghZmluYW5jZSl9PlxyXG4gICAgICAgICAgICAgICBGaW5hbmNlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICB7ZmluYW5jZSAmJiAoXHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImJ1bGxldFwiPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvRmluYW5jZS9BY2NvdW50c1wiPkFjY291bnRzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL0ZpbmFuY2UvRXhwZW5zZXNcIj5FeHBlbnNlczwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImxpbmstY29sb3JcIiB0bz1cIi9GaW5hbmNlL1BheW1lbnRzXCI+UGF5bWVudHM8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsaW5rLWNvbG9yXCIgdG89XCIvRmluYW5jZS9SZXBvdHNcIj5SZXBvcnRzPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImIxXCIgb25DbGljaz17KCkgPT4gc2V0SHIoIWhyKX0+XHJcbiAgICAgICAgICAgICAgIEhSXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICB7aHIgJiYgKFxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJidWxsZXRcIj5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL0hSL0F0dGVuZGVuY2VcIj5BdHRlbmRlbmNlPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL0hSL0VtcGxveWVzc1wiPkVtcGxveWVzczwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImxpbmstY29sb3JcIiB0bz1cIi9IUi9MZWF2ZVwiPkxlYXZlPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwibGluay1jb2xvclwiIHRvPVwiL0hSL1BheXJvbGxcIj5QYXlyb2xsPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaWdodFwiPlxyXG4gICAgICAgICAgPE91dGxldCAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl19