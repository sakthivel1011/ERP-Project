import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Components/CustomButton.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Button, CircularProgress } from "/ERP-Project/node_modules/.vite/deps/@mui_material.js?v=6e54c40b";
import "/ERP-Project/src/components/CustomButton.scss";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Components/CustomButton.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
export default function CustomButton({ children, variant = "contained", buttonType = "primary", size = "medium", loading = false, type = "button", startIcon, endIcon, disabled = false, ...props }) {
	return /* @__PURE__ */ _jsxDEV(Button, {
		className: `custom-button ${buttonType}`,
		variant,
		size,
		startIcon: !loading ? startIcon : null,
		endIcon: !loading ? endIcon : null,
		disabled: loading || disabled,
		type,
		...props,
		children: loading ? /* @__PURE__ */ _jsxDEV(CircularProgress, {
			size: 20,
			color: "inherit"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 18
		}, this) : children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_c = CustomButton;
var _c;
$RefreshReg$(_c, "CustomButton");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Components/CustomButton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Components/CustomButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Components/CustomButton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Components/CustomButton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLHdCQUF3QjtBQUN6QyxPQUFPOzs7QUFFUCxlQUFlLFNBQVMsYUFBYSxFQUNuQyxVQUNBLFVBQVUsYUFDVixhQUFhLFdBQ2IsT0FBTyxVQUNQLFVBQVUsT0FDVixPQUFPLFVBQ1AsV0FDQSxTQUNBLFdBQVMsT0FDVCxHQUFHLFNBRUY7Q0FDRCxPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLGlCQUFpQjtFQUNuQjtFQUNIO0VBQ04sV0FBVyxDQUFDLFVBQVUsWUFBWTtFQUNsQyxTQUFTLENBQUMsVUFBVSxVQUFVO0VBQzlCLFVBQVUsV0FBVztFQUNmO0VBQ04sR0FBSTtZQUVILFVBQVUsd0JBQUMsa0JBQUQ7R0FBa0IsTUFBTTtHQUFJLE9BQU07RUFBVzs7OzthQUFJO0NBQ3REOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkN1c3RvbUJ1dHRvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uLCBDaXJjdWxhclByb2dyZXNzIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IFwiLi4vY29tcG9uZW50cy9DdXN0b21CdXR0b24uc2Nzc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3VzdG9tQnV0dG9uKHtcclxuICBjaGlsZHJlbixcclxuICB2YXJpYW50ID0gXCJjb250YWluZWRcIixcclxuICBidXR0b25UeXBlID0gXCJwcmltYXJ5XCIsXHJcbiAgc2l6ZSA9IFwibWVkaXVtXCIsXHJcbiAgbG9hZGluZyA9IGZhbHNlLFxyXG4gIHR5cGUgPSBcImJ1dHRvblwiLFxyXG4gIHN0YXJ0SWNvbixcclxuICBlbmRJY29uLFxyXG4gIGRpc2FibGVkPWZhbHNlLFxyXG4gIC4uLnByb3BzXHJcbiAgXHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPEJ1dHRvblxyXG4gICAgICBjbGFzc05hbWU9e2BjdXN0b20tYnV0dG9uICR7YnV0dG9uVHlwZX1gfVxyXG4gICAgICB2YXJpYW50PXt2YXJpYW50fVxyXG4gICAgICBzaXplPXtzaXplfVxyXG4gICAgICBzdGFydEljb249eyFsb2FkaW5nID8gc3RhcnRJY29uIDogbnVsbH1cclxuICAgICAgZW5kSWNvbj17IWxvYWRpbmcgPyBlbmRJY29uIDogbnVsbH1cclxuICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgZGlzYWJsZWR9XHJcbiAgICAgIHR5cGU9e3R5cGV9XHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgID5cclxuICAgICAge2xvYWRpbmcgPyA8Q2lyY3VsYXJQcm9ncmVzcyBzaXplPXsyMH0gY29sb3I9XCJpbmhlcml0XCIgLz4gOiBjaGlsZHJlbn1cclxuICAgIDwvQnV0dG9uPlxyXG4gICk7XHJcbn1cclxuIl19