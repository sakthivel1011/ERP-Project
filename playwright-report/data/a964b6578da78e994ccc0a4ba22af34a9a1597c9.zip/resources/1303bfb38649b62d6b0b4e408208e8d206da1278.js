import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Components/CustomField.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { TextField, MenuItem } from "/ERP-Project/node_modules/.vite/deps/@mui_material.js?v=6e54c40b";
import "/ERP-Project/src/Components/CustomField.scss";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Components/CustomField.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
function CustomTextField({ label, value, onChange, type = "text", placeholder, select = false, options = [], error, helperText, width, height = "38px", ...props }) {
	return /* @__PURE__ */ _jsxDEV(TextField, {
		...props,
		className: "custom-textfield-wrapper",
		select,
		variant: "outlined",
		label,
		size: "small",
		placeholder,
		type,
		error,
		helperText,
		value: value ?? "",
		onChange,
		sx: {
			width: width || "200px",
			height,
			"& .MuiInputBase-root": { height },
			"& .MuiOutlinedInput-input": {
				padding: "0 14px",
				height,
				boxSizing: "border-box",
				display: "flex",
				alignItems: "center"
			},
			"& .MuiSelect-select": {
				padding: "0 14px !important",
				lineHeight: height,
				display: "flex",
				alignItems: "center",
				height: "100%"
			},
			"& .MuiInputLabel-root": { transform: "translate(14px, 6px) scale(1)" },
			"& .MuiInputLabel-shrink": { transform: "translate(14px, -6px) scale(0.75)" },
			...props.sx
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_c = CustomTextField;
export default CustomTextField;
var _c;
$RefreshReg$(_c, "CustomTextField");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Components/CustomField.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Components/CustomField.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Components/CustomField.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Components/CustomField.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsV0FBVyxnQkFBZ0I7QUFDcEMsT0FBTzs7O0FBRVAsU0FBUyxnQkFBZ0IsRUFDdkIsT0FDQSxPQUNBLFVBQ0EsT0FBTyxRQUNQLGFBQ0EsU0FBUyxPQUNULFVBQVUsQ0FBQyxHQUNYLE9BQ0EsWUFDQSxPQUNBLFNBQVMsUUFDVCxHQUFHLFNBQ0Y7Q0FDRCxPQUNFLHdCQUFDLFdBQUQ7RUFDRSxHQUFJO0VBQ0osV0FBVTtFQUNGO0VBQ1IsU0FBUTtFQUNEO0VBQ1AsTUFBSztFQUNRO0VBQ1A7RUFDQztFQUNLO0VBQ1osT0FBTyxTQUFTO0VBQ047RUFDVixJQUFJO0dBQ0YsT0FBTyxTQUFTO0dBQ1I7R0FFUix3QkFBd0IsRUFDZCxPQUNWO0dBRUEsNkJBQTZCO0lBQzNCLFNBQVM7SUFDRDtJQUNSLFdBQVc7SUFDWCxTQUFTO0lBQ1QsWUFBWTtHQUNkO0dBRUEsdUJBQXVCO0lBQ3JCLFNBQVM7SUFDVCxZQUFZO0lBQ1osU0FBUztJQUNULFlBQVk7SUFDWixRQUFRO0dBQ1Y7R0FFQSx5QkFBeUIsRUFDdkIsV0FBVyxnQ0FDYjtHQUNBLDJCQUEyQixFQUN6QixXQUFXLG9DQUNiO0dBQ0EsR0FBRyxNQUFNO0VBQ1g7Q0FFUzs7Ozs7QUFFZjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkN1c3RvbUZpZWxkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCwgTWVudUl0ZW0gfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgJy4uLy4uL3NyYy9Db21wb25lbnRzL0N1c3RvbUZpZWxkLnNjc3MnO1xyXG5cclxuZnVuY3Rpb24gQ3VzdG9tVGV4dEZpZWxkKHtcclxuICBsYWJlbCxcclxuICB2YWx1ZSxcclxuICBvbkNoYW5nZSxcclxuICB0eXBlID0gXCJ0ZXh0XCIsXHJcbiAgcGxhY2Vob2xkZXIsXHJcbiAgc2VsZWN0ID0gZmFsc2UsXHJcbiAgb3B0aW9ucyA9IFtdLFxyXG4gIGVycm9yLFxyXG4gIGhlbHBlclRleHQsXHJcbiAgd2lkdGgsXHJcbiAgaGVpZ2h0ID0gXCIzOHB4XCIsIFxyXG4gIC4uLnByb3BzXHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFRleHRGaWVsZFxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICAgIGNsYXNzTmFtZT1cImN1c3RvbS10ZXh0ZmllbGQtd3JhcHBlclwiXHJcbiAgICAgIHNlbGVjdD17c2VsZWN0fVxyXG4gICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICBsYWJlbD17bGFiZWx9XHJcbiAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cclxuICAgICAgdHlwZT17dHlwZX1cclxuICAgICAgZXJyb3I9e2Vycm9yfVxyXG4gICAgICBoZWxwZXJUZXh0PXtoZWxwZXJUZXh0fVxyXG4gICAgICB2YWx1ZT17dmFsdWUgPz8gJyd9XHJcbiAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX1cclxuICAgICAgc3g9e3tcclxuICAgICAgICB3aWR0aDogd2lkdGggfHwgXCIyMDBweFwiLCAvLyBEZWZhdWx0IHdpZHRoXHJcbiAgICAgICAgaGVpZ2h0OiBoZWlnaHQsIFxyXG4gICAgICAgIFxyXG4gICAgICAgIFwiJiAuTXVpSW5wdXRCYXNlLXJvb3RcIjoge1xyXG4gICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICBcclxuICAgICAgICBcIiYgLk11aU91dGxpbmVkSW5wdXQtaW5wdXRcIjoge1xyXG4gICAgICAgICAgcGFkZGluZzogXCIwIDE0cHhcIiwgXHJcbiAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcclxuICAgICAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXHJcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgXHJcbiAgICAgICAgXCImIC5NdWlTZWxlY3Qtc2VsZWN0XCI6IHtcclxuICAgICAgICAgIHBhZGRpbmc6IFwiMCAxNHB4ICFpbXBvcnRhbnRcIixcclxuICAgICAgICAgIGxpbmVIZWlnaHQ6IGhlaWdodCxcclxuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgIGhlaWdodDogXCIxMDAlXCJcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBcIiYgLk11aUlucHV0TGFiZWwtcm9vdFwiOiB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDE0cHgsIDZweCkgc2NhbGUoMSlcIiwgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcIiYgLk11aUlucHV0TGFiZWwtc2hyaW5rXCI6IHtcclxuICAgICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMTRweCwgLTZweCkgc2NhbGUoMC43NSlcIiwgXHJcbiAgICAgICAgfSxcclxuICAgICAgICAuLi5wcm9wcy5zeCxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgIDwvVGV4dEZpZWxkPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbVRleHRGaWVsZDtcclxuIl19