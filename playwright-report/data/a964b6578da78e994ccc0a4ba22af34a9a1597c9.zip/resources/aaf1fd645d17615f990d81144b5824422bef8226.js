import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/chart/Saleschart.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "/ERP-Project/node_modules/.vite/deps/recharts.js?v=fd357623";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Pages/chart/Saleschart.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
export default function Saleschart({ chartData }) {
	return /* @__PURE__ */ _jsxDEV(BarChart, {
		className: "barchart",
		width: 600,
		height: 300,
		margin: {
			top: 20,
			right: 30,
			left: 200,
			bottom: 5
		},
		data: chartData,
		children: [
			/* @__PURE__ */ _jsxDEV(XAxis, { dataKey: "month" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(YAxis, { dataKey: "sales" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Bar, {
				dataKey: "sales",
				fill: "blue",
				radius: [
					6,
					6,
					0,
					0
				]
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 4
	}, this);
}
_c = Saleschart;
var _c;
$RefreshReg$(_c, "Saleschart");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Pages/chart/Saleschart.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Pages/chart/Saleschart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Pages/chart/Saleschart.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Pages/chart/Saleschart.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsVUFBVSxLQUFLLE9BQU8sT0FBTyxlQUFlLFNBQVMsMkJBQTJCOzs7QUFFekYsZUFBZSxTQUFTLFdBQVcsRUFBQyxhQUFZO0NBQzlDLE9BRUMsd0JBQUMsVUFBRDtFQUFVLFdBQVU7RUFBVyxPQUFPO0VBQUssUUFBUTtFQUFLLFFBQVE7R0FBQyxLQUFJO0dBQUcsT0FBTTtHQUFHLE1BQUs7R0FBSSxRQUFPO0VBQUM7RUFBRyxNQUFNO1lBQTNHO0dBQ0csd0JBQUMsT0FBRCxFQUFPLFNBQVEsUUFBUzs7Ozs7R0FDeEIsd0JBQUMsT0FBRCxFQUFPLFNBQVEsUUFBUTs7Ozs7R0FDdkIsd0JBQUMsS0FBRDtJQUFLLFNBQVE7SUFBUSxNQUFLO0lBQU8sUUFBUTtLQUFDO0tBQUU7S0FBRTtLQUFFO0lBQUM7R0FBRzs7Ozs7RUFDNUM7Ozs7OztBQUdkIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNhbGVzY2hhcnQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgQmFyQ2hhcnQsIEJhciwgWEF4aXMsIFlBeGlzLCBDYXJ0ZXNpYW5HcmlkLCBUb29sdGlwLCBSZXNwb25zaXZlQ29udGFpbmVyIH0gZnJvbSAncmVjaGFydHMnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2FsZXNjaGFydCh7Y2hhcnREYXRhfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICBcclxuICAgPEJhckNoYXJ0IGNsYXNzTmFtZT0nYmFyY2hhcnQnIHdpZHRoPXs2MDB9IGhlaWdodD17MzAwfSBtYXJnaW49e3t0b3A6MjAscmlnaHQ6MzAsbGVmdDoyMDAsYm90dG9tOjV9fSBkYXRhPXtjaGFydERhdGF9PlxyXG4gICAgICA8WEF4aXMgZGF0YUtleT1cIm1vbnRoXCIgLz5cclxuICAgICAgPFlBeGlzIGRhdGFLZXk9XCJzYWxlc1wiLz4gICAgICAgICAgICAgICAgIFxyXG4gICAgICA8QmFyIGRhdGFLZXk9XCJzYWxlc1wiIGZpbGw9XCJibHVlXCIgcmFkaXVzPXtbNiw2LDAsMF19Lz4gXHJcbiAgICA8L0JhckNoYXJ0PlxyXG5cclxuICApXHJcbn1cclxuIl19