import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Sales/invoice/Invoice.jsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport18_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { MaterialReactTable, useMaterialReactTable } from "/ERP-Project/node_modules/.vite/deps/material-react-table.js?v=ec3a5688";
import { Data } from "/ERP-Project/src/Data/Data.js";
import { Grid, Box, Typography, Stack } from "/ERP-Project/node_modules/.vite/deps/@mui_material.js?v=6e54c40b";
import SearchIcon from "/ERP-Project/node_modules/.vite/deps/@mui_icons-material_Search.js?v=270d4aab";
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Paper, InputBase, IconButton } from "/ERP-Project/node_modules/.vite/deps/@mui_material.js?v=6e54c40b";
import "/ERP-Project/src/Pages/Sales/invoice/invoice.scss";
import CustomButton from "/ERP-Project/src/Components/CustomButton.jsx";
// 📦 React Hook Form packages for standard JavaScript state handling
import { useForm, useFieldArray, Controller } from "/ERP-Project/node_modules/.vite/deps/react-hook-form.js?v=9f27e63f";
import { yupResolver } from "/ERP-Project/node_modules/.vite/deps/@hookform_resolvers_yup.js?v=ce9e98f2";
import CommonButton from "/ERP-Project/src/Components/CustomButton.jsx";
import PaymentsIcon from "/ERP-Project/node_modules/.vite/deps/@mui_icons-material_Payments.js?v=70abf526";
import ListIcon from "/ERP-Project/node_modules/.vite/deps/@mui_icons-material_List.js?v=1859222b";
import { DatePicker } from "/ERP-Project/node_modules/.vite/deps/@mui_x-date-pickers.js?v=3fbcc6b5";
import { LocalizationProvider } from "/ERP-Project/node_modules/.vite/deps/@mui_x-date-pickers.js?v=3fbcc6b5";
import { AdapterDayjs } from "/ERP-Project/node_modules/.vite/deps/@mui_x-date-pickers_AdapterDayjs.js?v=9cebc6d8";
import { TRUE } from "/ERP-Project/node_modules/.vite/deps/sass.js?v=8d602cf4";
import CustomTextField from "/ERP-Project/src/Components/CustomField.jsx";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx";
import __vite__cjsImport18_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
var _s = $RefreshSig$();
export default function Invoice() {
	_s();
	const [modalOpen, setModalOpen] = useState(false);
	const [modalType, setModalType] = useState("");
	const [selectedInvoice, setSelectedInvoice] = useState(null);
	const [statusfilter, setStatusFilter] = useState("all");
	const [searchQuery, setSearchQuery] = useState("");
	// ⚡ Master useForm configuration with standard default layouts properties matching ungal matrix keys
	const { handleSubmit, control, reset, getValues, formState: { errors } } = useForm({ defaultValues: {
		invoiceNumber: "",
		customerId: "",
		invoiceDate: "",
		paymentTerms: "30 Days",
		status: "Unpaid",
		// Multiple items deep nested object templates schema tracking array
		items: [{
			description: "",
			itemCode: "",
			qty: 1,
			rate: 0,
			discount: 0,
			gst: 0
		}],
		// Multiple payments nested array list templates schemas tracking tracking references
		payments: [{
			paymentId: `PAY-${Math.floor(1e3 + Math.random() * 9e3)}`,
			amountPaid: 0,
			paymentDate: "",
			paymentMode: "Bank Transfer"
		}]
	} });
	console.log("getValues", getValues());
	// Dynamic loops tracking hooks parameters mapping inputs variables live
	const { fields: itemFields, append: appendItem, remove: removeItem } = useFieldArray({
		control,
		name: "items"
	});
	const { fields: paymentFields, append: appendPayment, remove: removePayment } = useFieldArray({
		control,
		name: "payments"
	});
	const invoiceData = Data?.invoices;
	const handleDropDownChange = (event) => {
		setStatusFilter(event.target.value);
	};
	const filterStatusData = useMemo(() => {
		const rawInvoices = Array.isArray(invoiceData) ? invoiceData : [];
		const customerList = Data?.customers || [];
		const formatted = rawInvoices.map((invoice) => {
			const matchedCustomer = customerList.find((cust) => cust.customerId === invoice?.customerId);
			return {
				rawInvoice: invoice,
				invoiceNumber: invoice?.quotationNumber || invoice?.invoiceNumber || "-",
				companyName: matchedCustomer ? matchedCustomer.companyName : "-",
				invoiceDate: invoice?.quotationDate || invoice?.invoiceDate || "-",
				paymentTerms: matchedCustomer?.paymentTerms || "-",
				amount: invoice?.grandTotal || invoice?.subtotal || 0,
				status: invoice?.status || "-"
			};
		});
		let result = formatted;
		if (statusfilter?.toLowerCase() !== "all" && statusfilter) {
			result = result.filter((invoice) => invoice?.status?.toLowerCase() === statusfilter?.toLowerCase());
		}
		if (searchQuery.trim() !== "") {
			const query = searchQuery.toLowerCase();
			result = result.filter((invoice) => {
				return invoice.invoiceNumber.toLowerCase().includes(query) || invoice.companyName.toLowerCase().includes(query) || invoice.invoiceDate.toLowerCase().includes(query) || invoice.paymentTerms.toLowerCase().includes(query) || invoice.status.toLowerCase().includes(query) || String(invoice.amount).toLowerCase().includes(query);
			});
		}
		return result;
	}, [
		invoiceData,
		statusfilter,
		searchQuery,
		Data?.customers
	]);
	const handleActionClick = (type, rowData) => {
		setModalOpen(true);
		setModalType(type);
		setSelectedInvoice(rowData);
	};
	const handleCloseModal = () => {
		setModalOpen(false);
		setSelectedInvoice(null);
		reset();
	};
	const onFormSubmit = (formData) => {
		console.log("SUCCESS! React Hook Form - Invoice Payload Object Data:", formData);
		alert("Invoice Form Saved Successfully! No: " + formData.invoiceNumber);
		handleCloseModal();
	};
	const kpiData = useMemo(() => {
		const invoiceList = Data?.invoices || [];
		const totalInvoices = invoiceList.length;
		const paidCount = invoiceList.filter((inv) => inv.status?.toLowerCase() === "paid").length;
		const unPaidCount = invoiceList.filter((inv) => inv.status?.toLowerCase() === "unpaid").length;
		const overDueCount = invoiceList.filter((inv) => inv.status?.toLowerCase() === "overdue").length;
		return {
			totalInvoices,
			paidCount,
			unPaidCount,
			overDueCount
		};
	}, [Data?.invoices]);
	const columns = useMemo(() => [
		{
			accessorKey: "invoiceNumber",
			header: "Invoice No"
		},
		{
			accessorKey: "companyName",
			header: "Company Name"
		},
		{
			accessorKey: "invoiceDate",
			header: "Invoice Date"
		},
		{
			accessorKey: "paymentTerms",
			header: "Payment Terms"
		},
		{
			accessorKey: "amount",
			header: "Amount"
		},
		{
			accessorKey: "status",
			header: "Status"
		},
		{
			accessorKey: "actions",
			header: "Action",
			enableSorting: false,
			Cell: ({ row }) => /* @__PURE__ */ _jsxDEV(Stack, {
				direction: "row",
				spacing: 2,
				sx: { width: "auto" },
				children: [/* @__PURE__ */ _jsxDEV(CustomButton, {
					buttonType: "primary",
					startIcon: /* @__PURE__ */ _jsxDEV(ListIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 26
					}, this),
					onClick: () => handleActionClick("items", row.original),
					children: "Items"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 203,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(CustomButton, {
					buttonType: "purple",
					startIcon: /* @__PURE__ */ _jsxDEV(PaymentsIcon, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 26
					}, this),
					onClick: () => handleActionClick("payments", row.original),
					children: "Payments"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 210,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 11
			}, this)
		}
	], []);
	const table = useMaterialReactTable({
		columns,
		data: filterStatusData,
		enableGlobalFilter: false,
		enableTopToolbar: false,
		enableFilters: false,
		enablePagination: true,
		enableHiding: false,
		enableColumnActions: false,
		enableFullScreenToggle: false,
		enableDensityToggle: false,
		paginationDisplayMode: "pages",
		layoutMode: "semantic",
		initialState: {
			density: "compact",
			pagination: {
				pageIndex: 0,
				pageSize: 10
			}
		},
		muiTableHeadCellProps: { className: "tableheader" },
		muiTableProps: { className: "mrt-gapped-table" },
		muiTableBodyRowProps: { className: "tablebody" },
		muiTableContainerProps: { className: "scroll" },
		muiTablePaperProps: { className: "custom table" }
	});
	const renderPopupcontent = () => {
		if (modalType === "addInvoice") {
			return /* @__PURE__ */ _jsxDEV("form", {
				id: "add-invoice-form",
				onSubmit: handleSubmit(onFormSubmit),
				children: [/* @__PURE__ */ _jsxDEV(Grid, {
					container: true,
					spacing: 2,
					sx: { pt: 1 },
					children: [
						/* @__PURE__ */ _jsxDEV(Grid, {
							item: true,
							xs: 12,
							sm: 6,
							children: /* @__PURE__ */ _jsxDEV(Controller, {
								name: "invoiceNumber",
								control,
								rules: { required: "Invoice Number required" },
								render: ({ field }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
									...field,
									label: "Invoice Number",
									size: "small",
									fullWidth: true,
									error: !!errors.invoiceNumber,
									helperText: errors.invoiceNumber?.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 253,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Grid, {
							item: true,
							xs: 8,
							sm: 10,
							children: /* @__PURE__ */ _jsxDEV(CustomTextField, {
								select: true,
								label: "Select Company Customer",
								size: "small",
								width: "220px",
								...control.register("customerId", { required: true }),
								children: (Data?.customers || []).map((c) => /* @__PURE__ */ _jsxDEV(MenuItem, {
									value: c.customerId,
									children: c.companyName
								}, c.customerId, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 271,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 270,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(LocalizationProvider, {
							dateAdapter: AdapterDayjs,
							children: /* @__PURE__ */ _jsxDEV(Controller, {
								name: "invoiceDate",
								control,
								render: ({ field }) => /* @__PURE__ */ _jsxDEV(DatePicker, {
									value: field.value ? dayj(field.value) : null,
									onChange: (date) => field.onChange(date ? date.format("YYYY-MM-DD") : ""),
									label: "Invoice Date",
									slotProps: { textField: {
										size: "small",
										fullWidth: false
									} }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 7
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 3
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 285,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Grid, {
							item: true,
							xs: 12,
							sm: 6,
							children: /* @__PURE__ */ _jsxDEV(CustomTextField, {
								select: true,
								label: "Payment Terms",
								size: "small",
								"fullWidth:true": true,
								...control.register("paymentTerms"),
								children: [
									/* @__PURE__ */ _jsxDEV(MenuItem, {
										value: "15 Days",
										children: "15 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(MenuItem, {
										value: "30 Days",
										children: "30 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 315,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(MenuItem, {
										value: "45 Days",
										children: "45 Days"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 306,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Box, {
					sx: { mt: 3 },
					children: [
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "subtitle2",
							sx: {
								fontWeight: "bold",
								mb: 1
							},
							children: "Invoice Items List"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 13
						}, this),
						itemFields.map((field, index) => /* @__PURE__ */ _jsxDEV(Box, {
							sx: {
								p: 2,
								border: "1px solid #e0e0e0",
								borderRadius: 1,
								mb: 2,
								bgcolor: "#fafafa"
							},
							children: [/* @__PURE__ */ _jsxDEV(Stack, {
								direction: "row",
								sx: {
									justifyContent: "space-between",
									alignItems: "center",
									mb: 1
								},
								children: [/* @__PURE__ */ _jsxDEV(Typography, {
									variant: "body2",
									sx: { fontWeight: 500 },
									children: ["Product Row #", index + 1]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 345,
									columnNumber: 19
								}, this), itemFields.length > 1 && /* @__PURE__ */ _jsxDEV(CustomButton, {
									buttonType: "outlined",
									variant: "red",
									onClick: () => removeItem(index),
									children: "Remove"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Grid, {
								container: true,
								spacing: 2,
								children: [
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 6,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.description`,
											control,
											rules: { required: true },
											render: ({ field: d }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...d,
												label: "Description Name",
												size: "small",
												fullWidth: true
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 365,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 359,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 6,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.itemCode`,
											control,
											render: ({ field: c }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...c,
												label: "Item Code",
												size: "small",
												fullWidth: true
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 379,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 375,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 4,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.qty`,
											control,
											render: ({ field: q }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...q,
												type: "number",
												label: "Qty",
												size: "small",
												fullWidth: true,
												onChange: (e) => q.onChange(Number(e.target.value))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 393,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 389,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 388,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 4,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.rate`,
											control,
											render: ({ field: r }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...r,
												type: "number",
												label: "Rate Price",
												size: "small",
												fullWidth: true,
												onChange: (e) => r.onChange(Number(e.target.value))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 409,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 405,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 2,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.discount`,
											control,
											render: ({ field: ds }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...ds,
												type: "number",
												label: "Disc %",
												size: "small",
												fullWidth: true,
												onChange: (e) => ds.onChange(Number(e.target.value))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 425,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 421,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 420,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Grid, {
										item: true,
										xs: 12,
										sm: 2,
										children: /* @__PURE__ */ _jsxDEV(Controller, {
											name: `items.${index}.gst`,
											control,
											render: ({ field: g }) => /* @__PURE__ */ _jsxDEV(CustomTextField, {
												...g,
												type: "number",
												label: "GST %",
												size: "small",
												fullWidth: true,
												onChange: (e) => g.onChange(Number(e.target.value))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 441,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 437,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 358,
								columnNumber: 17
							}, this)]
						}, field.id, true, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 15
						}, this)),
						/* @__PURE__ */ _jsxDEV(CustomButton, {
							buttonType: "purple",
							onClick: () => appendItem({
								description: "",
								itemCode: "",
								qty: 1,
								rate: 0,
								discount: 0,
								gst: 0
							}),
							children: "+ Add Item"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 455,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 322,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 9
			}, this);
		}
		if (!selectedInvoice) return null;
		// 💡 B) Items Details Viewing Block Setup
		if (modalType === "items") {
			return /* @__PURE__ */ _jsxDEV(Box, { children: selectedInvoice.rawInvoice?.items && selectedInvoice.rawInvoice?.items?.length > 0 ? selectedInvoice.rawInvoice?.items?.map((item, index) => /* @__PURE__ */ _jsxDEV(Box, {
				sx: {
					mb: 2,
					p: 2,
					bgcolor: "#f9f9f9",
					border: "1px solid #e5e7eb",
					borderRadius: 1
				},
				children: [/* @__PURE__ */ _jsxDEV(Typography, {
					variant: "subtitle1",
					sx: {
						fontWeight: "bold",
						color: "primary.main"
					},
					children: item.description || "Product Item"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 495,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV(Stack, {
					spacing: .5,
					sx: { mt: 1 },
					children: [
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Item Code:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 21
								}, this),
								" ",
								item.itemCode || "-"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 502,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Quantity:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 21
								}, this),
								" ",
								item.qty || 0
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 505,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Rate:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 21
								}, this),
								" ₹",
								item.rate || 0
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 508,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Discount:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 512,
									columnNumber: 21
								}, this),
								" ",
								item.discount || 0,
								"%"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 511,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "GST:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 21
								}, this),
								" ",
								item.gst || 0,
								"%"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 514,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "subtitle2",
							sx: {
								mt: 1,
								fontWeight: "bold"
							},
							children: ["Line Amount: ₹", item.amount?.toLocaleString("en-IN") || 0]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 517,
							columnNumber: 19
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 501,
					columnNumber: 17
				}, this)]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 485,
				columnNumber: 15
			}, this)) : /* @__PURE__ */ _jsxDEV(Typography, {
				color: "text.secondary",
				children: "No items found for this Invoice."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 527,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 481,
				columnNumber: 9
			}, this);
		}
		//  C) Payments Ledger Viewing Block Setup
		if (modalType === "payments") {
			return /* @__PURE__ */ _jsxDEV(Box, { children: [selectedInvoice.rawInvoice?.payments && selectedInvoice.rawInvoice?.payments?.length > 0 ? selectedInvoice.rawInvoice?.payments?.map((payment, index) => /* @__PURE__ */ _jsxDEV(Box, {
				sx: {
					mb: 2,
					p: 2,
					bgcolor: "#f0fdf4",
					border: "1px solid #bbf7d0",
					borderRadius: 1
				},
				children: [/* @__PURE__ */ _jsxDEV(Typography, {
					variant: "subtitle2",
					color: "green",
					sx: { fontWeight: "bold" },
					children: ["Payment Receipt #", index + 1]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 552,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV(Stack, {
					spacing: .5,
					sx: { mt: 1 },
					children: [
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Payment Id:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 561,
									columnNumber: 21
								}, this),
								" ",
								payment.paymentId || "-"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 560,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Date:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 564,
									columnNumber: 21
								}, this),
								" ",
								payment.date || "-"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 563,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Mode:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 567,
									columnNumber: 21
								}, this),
								" ",
								payment.mode || "-"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 566,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "body2",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", { children: "Reference:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 570,
									columnNumber: 21
								}, this),
								" ",
								payment.reference || "-"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 569,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Typography, {
							variant: "subtitle2",
							sx: {
								mt: .5,
								fontWeight: "bold",
								color: "green"
							},
							children: ["Amount Credited: ₹", payment.amount?.toLocaleString("en-IN") || 0]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 572,
							columnNumber: 19
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 559,
					columnNumber: 17
				}, this)]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 542,
				columnNumber: 15
			}, this)) : /* @__PURE__ */ _jsxDEV(Box, {
				sx: {
					p: 2,
					bgcolor: "#fef2f2",
					border: "1px solid #fecaca",
					borderRadius: 1
				},
				children: /* @__PURE__ */ _jsxDEV(Typography, {
					variant: "body2",
					color: "error.main",
					children: "No transactions recorded. This invoice remains completely unpaid."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 591,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 583,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(Box, {
				sx: {
					mt: 2,
					pt: 2,
					borderTop: "1px solid #e0e0e0"
				},
				children: /* @__PURE__ */ _jsxDEV(Typography, {
					variant: "body2",
					children: ["Current Standing Status: ", /* @__PURE__ */ _jsxDEV("strong", { children: selectedInvoice.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 599,
						columnNumber: 40
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 598,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 597,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 538,
				columnNumber: 9
			}, this);
		}
		return null;
	};
	return /* @__PURE__ */ _jsxDEV(Box, {
		className: "Table",
		children: [
			/* @__PURE__ */ _jsxDEV(Typography, {
				className: "invoiceName",
				children: "Invoice Management"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 609,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Grid, {
				container: true,
				spacing: 2,
				className: "kpi-container",
				sx: { mb: 3 },
				children: [
					/* @__PURE__ */ _jsxDEV(Grid, {
						item: true,
						xs: 12,
						sm: 3,
						children: /* @__PURE__ */ _jsxDEV(Box, {
							className: "total",
							children: [/* @__PURE__ */ _jsxDEV(Typography, {
								className: "status",
								children: "Total Invoices"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 615,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Typography, { children: kpiData.totalInvoices }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 616,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 614,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 613,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Grid, {
						item: true,
						xs: 12,
						sm: 3,
						children: /* @__PURE__ */ _jsxDEV(Box, {
							className: "kpi-paid",
							children: [/* @__PURE__ */ _jsxDEV(Typography, {
								className: "status",
								children: "Paid Amount"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 621,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Typography, { children: kpiData.paidCount }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 622,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 620,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 619,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Grid, {
						item: true,
						xs: 12,
						sm: 3,
						children: /* @__PURE__ */ _jsxDEV(Box, {
							className: "kpi-unpaid",
							children: [/* @__PURE__ */ _jsxDEV(Typography, {
								className: "status",
								children: "Unpaid Amount"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 627,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Typography, { children: kpiData.unPaidCount }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 628,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 626,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 625,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Grid, {
						item: true,
						xs: 12,
						sm: 3,
						children: /* @__PURE__ */ _jsxDEV(Box, {
							className: "kpi-over",
							children: [/* @__PURE__ */ _jsxDEV(Typography, {
								className: "status",
								children: "Over Due"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 633,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Typography, { children: kpiData.overDueCount }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 634,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 632,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 631,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 612,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Box, {
				className: "NewInv",
				children: /* @__PURE__ */ _jsxDEV(Box, {
					sx: {
						display: "flex",
						justifyContent: "space-between",
						alignItems: "center",
						mb: 1,
						width: "100%"
					},
					children: [/* @__PURE__ */ _jsxDEV(Paper, {
						className: "search",
						variant: "outlined",
						children: [/* @__PURE__ */ _jsxDEV(InputBase, {
							placeholder: "Search Invoice",
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 655,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(IconButton, { sx: {
							p: "6px",
							color: "#6b6375"
						} }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 660,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 650,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Stack, {
						direction: "row",
						spacing: 1.5,
						sx: { alignItems: "center" },
						children: [/* @__PURE__ */ _jsxDEV(CustomTextField, {
							select: true,
							variant: "outlined",
							label: "Filter Status",
							size: "small",
							value: statusfilter,
							onChange: (e) => setStatusFilter(e.target.value),
							className: "Dropdown",
							sx: { minWidth: "140px" },
							children: [
								/* @__PURE__ */ _jsxDEV(MenuItem, {
									value: "all",
									children: "All Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(MenuItem, {
									value: "paid",
									children: "Paid"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 675,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(MenuItem, {
									value: "unpaid",
									children: "UnPaid"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 676,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(MenuItem, {
									value: "overdue",
									children: "Overdue"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 677,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(MenuItem, {
									value: "partially Paid",
									children: "Partially Paid"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 678,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 664,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(CustomButton, {
							variant: "contained",
							onClick: () => handleActionClick("addInvoice", null),
							children: "Add Invoice"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 681,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 663,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 641,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 640,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Box, {
				className: "table-wrapper",
				children: /* @__PURE__ */ _jsxDEV(MaterialReactTable, { table }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 693,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 692,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: modalOpen,
				onClose: handleCloseModal,
				slots: { backdrop: () => null },
				fullWidth: true,
				maxWidth: modalType === "addInvoice" ? "md" : "xs",
				children: [
					/* @__PURE__ */ _jsxDEV(DialogTitle, {
						sx: { fontWeight: "bold" },
						children: [
							modalType === "addInvoice" && "Add New Invoice",
							modalType === "items" && "Invoice Item Details",
							modalType === "payments" && "Payment Ledger"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DialogContent, {
						dividers: true,
						children: renderPopupcontent()
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 710,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DialogActions, {
						sx: {
							p: 2,
							gap: 1.5
						},
						children: [/* @__PURE__ */ _jsxDEV(CustomButton, {
							buttonType: "outlined",
							onClick: handleCloseModal,
							variant: "outlined",
							color: "inherit",
							children: "Close"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 713,
							columnNumber: 11
						}, this), modalType === "addInvoice" && /* @__PURE__ */ _jsxDEV(CustomButton, {
							onClick: () => {
								console.log(`Button clicked! Target Invoice Number value is: ${FormData}`);
							},
							children: "Save Invoice"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 723,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 712,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 697,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 608,
		columnNumber: 5
	}, this);
}
_s(Invoice, "viR540Ud4AUF6xO9s2wa0dNaVIE=", false, function() {
	return [
		useForm,
		useFieldArray,
		useFieldArray,
		useMaterialReactTable
	];
});
_c = Invoice;
var _c;
$RefreshReg$(_c, "Invoice");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFNBQVMsZ0JBQWdCO0FBQ3pDLFNBQ0Usb0JBQ0EsNkJBQ0s7QUFDUCxTQUFTLFlBQVk7QUFDckIsU0FBUyxNQUFNLEtBQUssWUFBWSxhQUFhO0FBQzdDLE9BQU8sZ0JBQWdCO0FBQ3ZCLFNBQ0UsUUFDQSxRQUNBLGFBQ0EsZUFDQSxlQUNBLFdBQ0EsVUFDQSxPQUNBLFdBQ0Esa0JBQ0s7QUFDUCxPQUFPO0FBQ1AsT0FBTyxrQkFBa0I7O0FBR3pCLFNBQVMsU0FBUyxlQUFlLGtCQUFrQjtBQUVuRCxTQUFTLG1CQUFtQjtBQUM1QixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGNBQWM7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyw0QkFBNEI7QUFDckMsU0FBUSxvQkFBbUI7QUFDM0IsU0FBUyxZQUFZO0FBQ3JCLE9BQU8scUJBQXFCOzs7O0FBSTVCLGVBQWUsU0FBUyxVQUFVOztDQUNoQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxJQUFJO0NBQzNELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTs7Q0FHakQsTUFBTSxFQUNKLGNBQ0EsU0FDQSxPQUNBLFdBQ0EsV0FBVyxFQUFFLGFBQ1gsUUFBUSxFQUNWLGVBQWU7RUFDYixlQUFlO0VBQ2YsWUFBWTtFQUNaLGFBQWE7RUFDYixjQUFjO0VBQ2QsUUFBUTs7RUFFUixPQUFPLENBQ0w7R0FBRSxhQUFhO0dBQUksVUFBVTtHQUFJLEtBQUs7R0FBRyxNQUFNO0dBQUcsVUFBVTtHQUFHLEtBQUs7RUFBRSxDQUN4RTs7RUFFQSxVQUFVLENBQ1I7R0FDRSxXQUFXLE9BQU8sS0FBSyxNQUFNLE1BQU8sS0FBSyxPQUFPLElBQUksR0FBSTtHQUN4RCxZQUFZO0dBQ1osYUFBYTtHQUNiLGFBQWE7RUFDZixDQUNGO0NBQ0YsRUFDRixDQUFDO0NBRUQsUUFBUSxJQUFJLGFBQWEsVUFBVSxDQUFDOztDQUdwQyxNQUFNLEVBQ0osUUFBUSxZQUNSLFFBQVEsWUFDUixRQUFRLGVBQ04sY0FBYztFQUNoQjtFQUNBLE1BQU07Q0FDUixDQUFDO0NBRUQsTUFBTSxFQUNKLFFBQVEsZUFDUixRQUFRLGVBQ1IsUUFBUSxrQkFDTixjQUFjO0VBQ2hCO0VBQ0EsTUFBTTtDQUNSLENBQUM7Q0FFRCxNQUFNLGNBQWMsTUFBTTtDQUUxQixNQUFNLHdCQUF3QixVQUFVO0VBQ3RDLGdCQUFnQixNQUFNLE9BQU8sS0FBSztDQUNwQztDQUNBLE1BQU0sbUJBQW1CLGNBQWM7RUFDckMsTUFBTSxjQUFjLE1BQU0sUUFBUSxXQUFXLElBQUksY0FBYyxDQUFDO0VBQ2hFLE1BQU0sZUFBZSxNQUFNLGFBQWEsQ0FBQztFQUV6QyxNQUFNLFlBQVksWUFBWSxLQUFLLFlBQVk7R0FDN0MsTUFBTSxrQkFBa0IsYUFBYSxNQUNsQyxTQUFTLEtBQUssZUFBZSxTQUFTLFVBQ3pDO0dBRUEsT0FBTztJQUNMLFlBQVk7SUFDWixlQUNFLFNBQVMsbUJBQW1CLFNBQVMsaUJBQWlCO0lBQ3hELGFBQWEsa0JBQWtCLGdCQUFnQixjQUFjO0lBQzdELGFBQWEsU0FBUyxpQkFBaUIsU0FBUyxlQUFlO0lBQy9ELGNBQWMsaUJBQWlCLGdCQUFnQjtJQUMvQyxRQUFRLFNBQVMsY0FBYyxTQUFTLFlBQVk7SUFDcEQsUUFBUSxTQUFTLFVBQVU7R0FDN0I7RUFDRixDQUFDO0VBRUQsSUFBSSxTQUFTO0VBQ2IsSUFBSSxjQUFjLFlBQVksTUFBTSxTQUFTLGNBQWM7R0FDekQsU0FBUyxPQUFPLFFBQ2IsWUFDQyxTQUFTLFFBQVEsWUFBWSxNQUFNLGNBQWMsWUFBWSxDQUNqRTtFQUNGO0VBRUEsSUFBSSxZQUFZLEtBQUssTUFBTSxJQUFJO0dBQzdCLE1BQU0sUUFBUSxZQUFZLFlBQVk7R0FDdEMsU0FBUyxPQUFPLFFBQVEsWUFBWTtJQUNsQyxPQUNFLFFBQVEsY0FBYyxZQUFZLENBQUMsQ0FBQyxTQUFTLEtBQUssS0FDbEQsUUFBUSxZQUFZLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUNoRCxRQUFRLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQ2hELFFBQVEsYUFBYSxZQUFZLENBQUMsQ0FBQyxTQUFTLEtBQUssS0FDakQsUUFBUSxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUMzQyxPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLO0dBRXZELENBQUM7RUFDSDtFQUVBLE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBYTtFQUFjO0VBQWEsTUFBTTtDQUFTLENBQUM7Q0FFNUQsTUFBTSxxQkFBcUIsTUFBTSxZQUFZO0VBQzNDLGFBQWEsSUFBSTtFQUNqQixhQUFhLElBQUk7RUFDakIsbUJBQW1CLE9BQU87Q0FDNUI7Q0FFQSxNQUFNLHlCQUF5QjtFQUM3QixhQUFhLEtBQUs7RUFDbEIsbUJBQW1CLElBQUk7RUFDdkIsTUFBTTtDQUNSO0NBRUEsTUFBTSxnQkFBZ0IsYUFBYTtFQUNqQyxRQUFRLElBQ04sMkRBQ0EsUUFDRjtFQUNBLE1BQU0sMENBQTBDLFNBQVMsYUFBYTtFQUN0RSxpQkFBaUI7Q0FDbkI7Q0FFQSxNQUFNLFVBQVUsY0FBYztFQUM1QixNQUFNLGNBQWMsTUFBTSxZQUFZLENBQUM7RUFDdkMsTUFBTSxnQkFBZ0IsWUFBWTtFQUNsQyxNQUFNLFlBQVksWUFBWSxRQUMzQixRQUFRLElBQUksUUFBUSxZQUFZLE1BQU0sTUFDekMsQ0FBQyxDQUFDO0VBQ0YsTUFBTSxjQUFjLFlBQVksUUFDN0IsUUFBUSxJQUFJLFFBQVEsWUFBWSxNQUFNLFFBQ3pDLENBQUMsQ0FBQztFQUNGLE1BQU0sZUFBZSxZQUFZLFFBQzlCLFFBQVEsSUFBSSxRQUFRLFlBQVksTUFBTSxTQUN6QyxDQUFDLENBQUM7RUFDRixPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGLEdBQUcsQ0FBQyxNQUFNLFFBQVEsQ0FBQztDQUVuQixNQUFNLFVBQVUsY0FDUjtFQUNKO0dBQUUsYUFBYTtHQUFpQixRQUFRO0VBQWE7RUFDckQ7R0FBRSxhQUFhO0dBQWUsUUFBUTtFQUFlO0VBQ3JEO0dBQUUsYUFBYTtHQUFlLFFBQVE7RUFBZTtFQUNyRDtHQUFFLGFBQWE7R0FBZ0IsUUFBUTtFQUFnQjtFQUN2RDtHQUFFLGFBQWE7R0FBVSxRQUFRO0VBQVM7RUFDMUM7R0FBRSxhQUFhO0dBQVUsUUFBUTtFQUFTO0VBQzFDO0dBQ0UsYUFBYTtHQUNiLFFBQVE7R0FDUixlQUFlO0dBQ2YsT0FBTyxFQUFFLFVBQ1Asd0JBQUMsT0FBRDtJQUFPLFdBQVU7SUFBTSxTQUFTO0lBQUcsSUFBSSxFQUFFLE9BQU8sT0FBTztjQUF2RCxDQUNFLHdCQUFDLGNBQUQ7S0FDRSxZQUFXO0tBQ1gsV0FBVyx3QkFBQyxVQUFELENBQVc7Ozs7O0tBQ3RCLGVBQWUsa0JBQWtCLFNBQVMsSUFBSSxRQUFRO2VBQ3ZEO0lBRWE7Ozs7Y0FDZCx3QkFBQyxjQUFEO0tBQ0UsWUFBVztLQUNYLFdBQVcsd0JBQUMsY0FBRCxDQUFlOzs7OztLQUMxQixlQUFlLGtCQUFrQixZQUFZLElBQUksUUFBUTtlQUMxRDtJQUVhOzs7O1lBQ1Q7Ozs7OztFQUVYO0NBQ0YsR0FDQSxDQUFDLENBQ0g7Q0FFQSxNQUFNLFFBQVEsc0JBQXNCO0VBQ2xDO0VBQ0EsTUFBTTtFQUNOLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2QscUJBQXFCO0VBQ3JCLHdCQUF3QjtFQUN4QixxQkFBcUI7RUFDckIsdUJBQXVCO0VBQ3ZCLFlBQVk7RUFDWixjQUFjO0dBQ1osU0FBUztHQUNULFlBQVk7SUFBRSxXQUFXO0lBQUcsVUFBVTtHQUFHO0VBQzNDO0VBQ0EsdUJBQXVCLEVBQUUsV0FBVyxjQUFjO0VBQ2xELGVBQWUsRUFBRSxXQUFXLG1CQUFtQjtFQUMvQyxzQkFBc0IsRUFBRSxXQUFXLFlBQVk7RUFDL0Msd0JBQXdCLEVBQUUsV0FBVyxTQUFTO0VBQzlDLG9CQUFvQixFQUFFLFdBQVcsZUFBZTtDQUNsRCxDQUFDO0NBQ0QsTUFDQSwyQkFBMkI7RUFDekIsSUFBSSxjQUFjLGNBQWM7R0FDOUIsT0FDRSx3QkFBQyxRQUFEO0lBQU0sSUFBRztJQUFtQixVQUFVLGFBQWEsWUFBWTtjQUEvRCxDQUNFLHdCQUFDLE1BQUQ7S0FBTTtLQUFVLFNBQVM7S0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO2VBQXhDO01BQ0Usd0JBQUMsTUFBRDtPQUFNO09BQUssSUFBSTtPQUFJLElBQUk7aUJBQ3JCLHdCQUFDLFlBQUQ7UUFDRSxNQUFLO1FBQ0k7UUFDVCxPQUFPLEVBQUUsVUFBVSwwQkFBMEI7UUFDN0MsU0FBUyxFQUFFLFlBQ1Qsd0JBQUMsaUJBQUQ7U0FDRSxHQUFJO1NBQ0osT0FBTTtTQUNOLE1BQUs7U0FDTDtTQUNBLE9BQU8sQ0FBQyxDQUFDLE9BQU87U0FDaEIsWUFBWSxPQUFPLGVBQWU7UUFDbkM7Ozs7O09BRUo7Ozs7O01BQ0c7Ozs7O01BQ04sd0JBQUMsTUFBRDtPQUFNO09BQUssSUFBSTtPQUFHLElBQUk7aUJBQ3BCLHdCQUFDLGlCQUFEO1FBQ0U7UUFDQSxPQUFNO1FBQ04sTUFBSztRQUNMLE9BQU07UUFDTixHQUFJLFFBQVEsU0FBUyxjQUFjLEVBQUUsVUFBVSxLQUFLLENBQUM7bUJBRW5ELE1BQU0sYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQzVCLHdCQUFDLFVBQUQ7U0FBNkIsT0FBTyxFQUFFO21CQUNuQyxFQUFFO1FBQ0ssR0FGSyxFQUFFOzs7O2VBRVAsQ0FDWDtPQUNjOzs7OztNQUNiOzs7OztNQUNOLHdCQUFDLHNCQUFEO09BQXNCLGFBQWE7aUJBQzdDLHdCQUFDLFlBQUQ7UUFDRSxNQUFLO1FBQ0k7UUFDVCxTQUFTLEVBQUUsWUFDVCx3QkFBQyxZQUFEO1NBQ0UsT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtTQUN6QyxXQUFXLFNBQ1QsTUFBTSxTQUFTLE9BQU8sS0FBSyxPQUFPLFlBQVksSUFBSSxFQUFFO1NBRXRELE9BQU07U0FDTixXQUFXLEVBQ1QsV0FBVztVQUNULE1BQU07VUFDTixXQUFXO1NBQ2IsRUFDRjtRQUNEOzs7OztPQUVKOzs7OztNQUNtQjs7Ozs7TUFDVix3QkFBQyxNQUFEO09BQU07T0FBSyxJQUFJO09BQUksSUFBSTtpQkFDckIsd0JBQUMsaUJBQUQ7UUFDRTtRQUNBLE9BQU07UUFDTixNQUFLO1FBQ0w7UUFDQSxHQUFJLFFBQVEsU0FBUyxjQUFjO2tCQUxyQztTQU9FLHdCQUFDLFVBQUQ7VUFBVSxPQUFNO29CQUFVO1NBQWlCOzs7OztTQUMzQyx3QkFBQyxVQUFEO1VBQVUsT0FBTTtvQkFBVTtTQUFpQjs7Ozs7U0FDM0Msd0JBQUMsVUFBRDtVQUFVLE9BQU07b0JBQVU7U0FBaUI7Ozs7O1FBQzVCOzs7Ozs7TUFDYjs7Ozs7S0FDRjs7Ozs7Y0FHTix3QkFBQyxLQUFEO0tBQUssSUFBSSxFQUFFLElBQUksRUFBRTtlQUFqQjtNQUNFLHdCQUFDLFlBQUQ7T0FBWSxTQUFRO09BQVksSUFBSTtRQUFFLFlBQVk7UUFBUSxJQUFJO09BQUU7aUJBQUc7TUFFdkQ7Ozs7O01BQ1gsV0FBVyxLQUFLLE9BQU8sVUFDdEIsd0JBQUMsS0FBRDtPQUVFLElBQUk7UUFDRixHQUFHO1FBQ0gsUUFBUTtRQUNSLGNBQWM7UUFDZCxJQUFJO1FBQ0osU0FBUztPQUNYO2lCQVJGLENBVUUsd0JBQUMsT0FBRDtRQUNFLFdBQVU7UUFDVixJQUFJO1NBQ0YsZ0JBQWdCO1NBQ2hCLFlBQVk7U0FDWixJQUFJO1FBQ047a0JBTkYsQ0FRRSx3QkFBQyxZQUFEO1NBQVksU0FBUTtTQUFRLElBQUksRUFBRSxZQUFZLElBQUk7bUJBQWxELENBQXFELGlCQUNyQyxRQUFRLENBQ1o7Ozs7O2tCQUNYLFdBQVcsU0FBUyxLQUNuQix3QkFBQyxjQUFEO1NBQ0UsWUFBVztTQUNYLFNBQVE7U0FDUixlQUFlLFdBQVcsS0FBSzttQkFDaEM7UUFFYTs7OztnQkFFWDs7Ozs7aUJBQ1Asd0JBQUMsTUFBRDtRQUFNO1FBQVUsU0FBUztrQkFBekI7U0FDRSx3QkFBQyxNQUFEO1VBQU07VUFBSyxJQUFJO1VBQUksSUFBSTtvQkFDckIsd0JBQUMsWUFBRDtXQUNFLE1BQU0sU0FBUyxNQUFNO1dBQ1o7V0FDVCxPQUFPLEVBQUUsVUFBVSxLQUFLO1dBQ3hCLFNBQVMsRUFBRSxPQUFPLFFBQ2hCLHdCQUFDLGlCQUFEO1lBQ0UsR0FBSTtZQUNKLE9BQU07WUFDTixNQUFLO1lBQ0w7V0FDRDs7Ozs7VUFFSjs7Ozs7U0FDRzs7Ozs7U0FDTix3QkFBQyxNQUFEO1VBQU07VUFBSyxJQUFJO1VBQUksSUFBSTtvQkFDckIsd0JBQUMsWUFBRDtXQUNFLE1BQU0sU0FBUyxNQUFNO1dBQ1o7V0FDVCxTQUFTLEVBQUUsT0FBTyxRQUNoQix3QkFBQyxpQkFBRDtZQUNFLEdBQUk7WUFDSixPQUFNO1lBQ04sTUFBSztZQUNMO1dBQ0Q7Ozs7O1VBRUo7Ozs7O1NBQ0c7Ozs7O1NBQ04sd0JBQUMsTUFBRDtVQUFNO1VBQUssSUFBSTtVQUFJLElBQUk7b0JBQ3JCLHdCQUFDLFlBQUQ7V0FDRSxNQUFNLFNBQVMsTUFBTTtXQUNaO1dBQ1QsU0FBUyxFQUFFLE9BQU8sUUFDaEIsd0JBQUMsaUJBQUQ7WUFDRSxHQUFJO1lBQ0osTUFBSztZQUNMLE9BQU07WUFDTixNQUFLO1lBQ0w7WUFDQSxXQUFXLE1BQU0sRUFBRSxTQUFTLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztXQUNuRDs7Ozs7VUFFSjs7Ozs7U0FDRzs7Ozs7U0FDTix3QkFBQyxNQUFEO1VBQU07VUFBSyxJQUFJO1VBQUksSUFBSTtvQkFDckIsd0JBQUMsWUFBRDtXQUNFLE1BQU0sU0FBUyxNQUFNO1dBQ1o7V0FDVCxTQUFTLEVBQUUsT0FBTyxRQUNoQix3QkFBQyxpQkFBRDtZQUNFLEdBQUk7WUFDSixNQUFLO1lBQ0wsT0FBTTtZQUNOLE1BQUs7WUFDTDtZQUNBLFdBQVcsTUFBTSxFQUFFLFNBQVMsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1dBQ25EOzs7OztVQUVKOzs7OztTQUNHOzs7OztTQUNOLHdCQUFDLE1BQUQ7VUFBTTtVQUFLLElBQUk7VUFBSSxJQUFJO29CQUNyQix3QkFBQyxZQUFEO1dBQ0UsTUFBTSxTQUFTLE1BQU07V0FDWjtXQUNULFNBQVMsRUFBRSxPQUFPLFNBQ2hCLHdCQUFDLGlCQUFEO1lBQ0UsR0FBSTtZQUNKLE1BQUs7WUFDTCxPQUFNO1lBQ04sTUFBSztZQUNMO1lBQ0EsV0FBVyxNQUFNLEdBQUcsU0FBUyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7V0FDcEQ7Ozs7O1VBRUo7Ozs7O1NBQ0c7Ozs7O1NBQ04sd0JBQUMsTUFBRDtVQUFNO1VBQUssSUFBSTtVQUFJLElBQUk7b0JBQ3JCLHdCQUFDLFlBQUQ7V0FDRSxNQUFNLFNBQVMsTUFBTTtXQUNaO1dBQ1QsU0FBUyxFQUFFLE9BQU8sUUFDaEIsd0JBQUMsaUJBQUQ7WUFDRSxHQUFJO1lBQ0osTUFBSztZQUNMLE9BQU07WUFDTixNQUFLO1lBQ0w7WUFDQSxXQUFXLE1BQU0sRUFBRSxTQUFTLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztXQUNuRDs7Ozs7VUFFSjs7Ozs7U0FDRzs7Ozs7UUFDRjs7Ozs7ZUFDSDtTQTdIRSxNQUFNOzs7O2FBNkhSLENBQ047TUFDRCx3QkFBQyxjQUFEO09BQ0MsWUFBVztPQUVWLGVBQ0UsV0FBVztRQUNULGFBQWE7UUFDYixVQUFVO1FBQ1YsS0FBSztRQUNMLE1BQU07UUFDTixVQUFVO1FBQ1YsS0FBSztPQUNQLENBQUM7aUJBRUo7TUFFYTs7Ozs7S0FDWDs7Ozs7WUFDRDs7Ozs7O0VBRVY7RUFFQSxJQUFJLENBQUMsaUJBQWlCLE9BQU87O0VBRzdCLElBQUksY0FBYyxTQUFTO0dBQ3pCLE9BQ0Usd0JBQUMsS0FBRCxZQUNHLGdCQUFnQixZQUFZLFNBQzdCLGdCQUFnQixZQUFZLE9BQU8sU0FBUyxJQUMxQyxnQkFBZ0IsWUFBWSxPQUFPLEtBQUssTUFBTSxVQUM1Qyx3QkFBQyxLQUFEO0lBRUUsSUFBSTtLQUNGLElBQUk7S0FDSixHQUFHO0tBQ0gsU0FBUztLQUNULFFBQVE7S0FDUixjQUFjO0lBQ2hCO2NBUkYsQ0FVRSx3QkFBQyxZQUFEO0tBQ0UsU0FBUTtLQUNSLElBQUk7TUFBRSxZQUFZO01BQVEsT0FBTztLQUFlO2VBRS9DLEtBQUssZUFBZTtJQUNYOzs7O2NBQ1osd0JBQUMsT0FBRDtLQUFPLFNBQVM7S0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFO2VBQWpDO01BQ0Usd0JBQUMsWUFBRDtPQUFZLFNBQVE7aUJBQXBCO1FBQ0Usd0JBQUMsVUFBRCxZQUFRLGFBQWtCOzs7OztRQUFDO1FBQUUsS0FBSyxZQUFZO09BQ3BDOzs7Ozs7TUFDWix3QkFBQyxZQUFEO09BQVksU0FBUTtpQkFBcEI7UUFDRSx3QkFBQyxVQUFELFlBQVEsWUFBaUI7Ozs7O1FBQUM7UUFBRSxLQUFLLE9BQU87T0FDOUI7Ozs7OztNQUNaLHdCQUFDLFlBQUQ7T0FBWSxTQUFRO2lCQUFwQjtRQUNFLHdCQUFDLFVBQUQsWUFBUSxRQUFhOzs7OztRQUFDO1FBQUcsS0FBSyxRQUFRO09BQzVCOzs7Ozs7TUFDWix3QkFBQyxZQUFEO09BQVksU0FBUTtpQkFBcEI7UUFDRSx3QkFBQyxVQUFELFlBQVEsWUFBaUI7Ozs7O1FBQUM7UUFBRSxLQUFLLFlBQVk7UUFBRTtPQUNyQzs7Ozs7O01BQ1osd0JBQUMsWUFBRDtPQUFZLFNBQVE7aUJBQXBCO1FBQ0Usd0JBQUMsVUFBRCxZQUFRLE9BQVk7Ozs7O1FBQUM7UUFBRSxLQUFLLE9BQU87UUFBRTtPQUMzQjs7Ozs7O01BQ1osd0JBQUMsWUFBRDtPQUNFLFNBQVE7T0FDUixJQUFJO1FBQUUsSUFBSTtRQUFHLFlBQVk7T0FBTztpQkFGbEMsQ0FHQyxrQkFDZ0IsS0FBSyxRQUFRLGVBQWUsT0FBTyxLQUFLLENBQzdDOzs7Ozs7S0FDUDs7Ozs7WUFDSjtNQXRDRTs7OztVQXNDRixDQUNOLElBRUQsd0JBQUMsWUFBRDtJQUFZLE9BQU07Y0FBaUI7R0FFdkI7Ozs7WUFFWDs7Ozs7RUFFVDs7RUFHQSxJQUFJLGNBQWMsWUFBWTtHQUM1QixPQUNFLHdCQUFDLEtBQUQsYUFDRyxnQkFBZ0IsWUFBWSxZQUM3QixnQkFBZ0IsWUFBWSxVQUFVLFNBQVMsSUFDN0MsZ0JBQWdCLFlBQVksVUFBVSxLQUFLLFNBQVMsVUFDbEQsd0JBQUMsS0FBRDtJQUVFLElBQUk7S0FDRixJQUFJO0tBQ0osR0FBRztLQUNILFNBQVM7S0FDVCxRQUFRO0tBQ1IsY0FBYztJQUNoQjtjQVJGLENBVUUsd0JBQUMsWUFBRDtLQUNFLFNBQVE7S0FDUixPQUFNO0tBQ04sSUFBSSxFQUFFLFlBQVksT0FBTztlQUgzQixDQUlDLHFCQUNtQixRQUFRLENBQ2hCOzs7OztjQUNaLHdCQUFDLE9BQUQ7S0FBTyxTQUFTO0tBQUssSUFBSSxFQUFFLElBQUksRUFBRTtlQUFqQztNQUNFLHdCQUFDLFlBQUQ7T0FBWSxTQUFRO2lCQUFwQjtRQUNFLHdCQUFDLFVBQUQsWUFBUSxjQUFtQjs7Ozs7UUFBQztRQUFFLFFBQVEsYUFBYTtPQUN6Qzs7Ozs7O01BQ1osd0JBQUMsWUFBRDtPQUFZLFNBQVE7aUJBQXBCO1FBQ0Usd0JBQUMsVUFBRCxZQUFRLFFBQWE7Ozs7O1FBQUM7UUFBRSxRQUFRLFFBQVE7T0FDOUI7Ozs7OztNQUNaLHdCQUFDLFlBQUQ7T0FBWSxTQUFRO2lCQUFwQjtRQUNFLHdCQUFDLFVBQUQsWUFBUSxRQUFhOzs7OztRQUFDO1FBQUUsUUFBUSxRQUFRO09BQzlCOzs7Ozs7TUFDWix3QkFBQyxZQUFEO09BQVksU0FBUTtpQkFBcEI7UUFDRSx3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7O1FBQUM7UUFBRSxRQUFRLGFBQWE7T0FDeEM7Ozs7OztNQUNaLHdCQUFDLFlBQUQ7T0FDRSxTQUFRO09BQ1IsSUFBSTtRQUFFLElBQUk7UUFBSyxZQUFZO1FBQVEsT0FBTztPQUFRO2lCQUZwRCxDQUdDLHNCQUVFLFFBQVEsUUFBUSxlQUFlLE9BQU8sS0FBSyxDQUNsQzs7Ozs7O0tBQ1A7Ozs7O1lBQ0o7TUFyQ0U7Ozs7VUFxQ0YsQ0FDTixJQUVELHdCQUFDLEtBQUQ7SUFDRSxJQUFJO0tBQ0YsR0FBRztLQUNILFNBQVM7S0FDVCxRQUFRO0tBQ1IsY0FBYztJQUNoQjtjQUVBLHdCQUFDLFlBQUQ7S0FBWSxTQUFRO0tBQVEsT0FBTTtlQUFhO0lBR25DOzs7OztHQUNUOzs7O2FBRVAsd0JBQUMsS0FBRDtJQUFLLElBQUk7S0FBRSxJQUFJO0tBQUcsSUFBSTtLQUFHLFdBQVc7SUFBb0I7Y0FDdEQsd0JBQUMsWUFBRDtLQUFZLFNBQVE7ZUFBcEIsQ0FBNEIsNkJBQ0Qsd0JBQUMsVUFBRCxZQUFTLGdCQUFnQixPQUFlOzs7O2FBQ3ZEOzs7Ozs7R0FDVDs7OztXQUNGOzs7OztFQUVUO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FDRSx3QkFBQyxLQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsWUFBRDtJQUFZLFdBQVU7Y0FBYztHQUE4Qjs7Ozs7R0FHbEUsd0JBQUMsTUFBRDtJQUFNO0lBQVUsU0FBUztJQUFHLFdBQVU7SUFBZ0IsSUFBSSxFQUFFLElBQUksRUFBRTtjQUFsRTtLQUNFLHdCQUFDLE1BQUQ7TUFBTTtNQUFLLElBQUk7TUFBSSxJQUFJO2dCQUNyQix3QkFBQyxLQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFlBQUQ7UUFBWSxXQUFVO2tCQUFTO09BQTBCOzs7O2lCQUN6RCx3QkFBQyxZQUFELFlBQWEsUUFBUSxjQUEwQjs7OztlQUM1Qzs7Ozs7O0tBQ0Q7Ozs7O0tBQ04sd0JBQUMsTUFBRDtNQUFNO01BQUssSUFBSTtNQUFJLElBQUk7Z0JBQ3JCLHdCQUFDLEtBQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsWUFBRDtRQUFZLFdBQVU7a0JBQVM7T0FBdUI7Ozs7aUJBQ3RELHdCQUFDLFlBQUQsWUFBYSxRQUFRLFVBQXNCOzs7O2VBQ3hDOzs7Ozs7S0FDRDs7Ozs7S0FDTix3QkFBQyxNQUFEO01BQU07TUFBSyxJQUFJO01BQUksSUFBSTtnQkFDckIsd0JBQUMsS0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxZQUFEO1FBQVksV0FBVTtrQkFBUztPQUF5Qjs7OztpQkFDeEQsd0JBQUMsWUFBRCxZQUFhLFFBQVEsWUFBd0I7Ozs7ZUFDMUM7Ozs7OztLQUNEOzs7OztLQUNOLHdCQUFDLE1BQUQ7TUFBTTtNQUFLLElBQUk7TUFBSSxJQUFJO2dCQUNyQix3QkFBQyxLQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFlBQUQ7UUFBWSxXQUFVO2tCQUFTO09BQW9COzs7O2lCQUNuRCx3QkFBQyxZQUFELFlBQWEsUUFBUSxhQUF5Qjs7OztlQUMzQzs7Ozs7O0tBQ0Q7Ozs7O0lBQ0Y7Ozs7OztHQUdOLHdCQUFDLEtBQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsS0FBRDtLQUNFLElBQUk7TUFDRixTQUFTO01BQ1QsZ0JBQWdCO01BQ2hCLFlBQVk7TUFDWixJQUFJO01BQ0osT0FBTztLQUNUO2VBUEYsQ0FTRSx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLFNBQVE7Z0JBRlYsQ0FLRSx3QkFBQyxXQUFEO09BQ0UsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztNQUMvQzs7OztnQkFDRCx3QkFBQyxZQUFELEVBQVksSUFBSTtPQUFFLEdBQUc7T0FBTyxPQUFPO01BQVUsRUFBZTs7OztjQUN2RDs7Ozs7ZUFFUCx3QkFBQyxPQUFEO01BQU8sV0FBVTtNQUFNLFNBQVM7TUFBSyxJQUFJLEVBQUUsWUFBWSxTQUFTO2dCQUFoRSxDQUNFLHdCQUFDLGlCQUFEO09BQ0U7T0FDQSxTQUFRO09BQ1IsT0FBTTtPQUNOLE1BQUs7T0FDTCxPQUFPO09BQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztPQUMvQyxXQUFVO09BQ1YsSUFBSSxFQUFFLFVBQVUsUUFBUTtpQkFSMUI7UUFVRSx3QkFBQyxVQUFEO1NBQVUsT0FBTTttQkFBTTtRQUFvQjs7Ozs7UUFDMUMsd0JBQUMsVUFBRDtTQUFVLE9BQU07bUJBQU87UUFBYzs7Ozs7UUFDckMsd0JBQUMsVUFBRDtTQUFVLE9BQU07bUJBQVM7UUFBZ0I7Ozs7O1FBQ3pDLHdCQUFDLFVBQUQ7U0FBVSxPQUFNO21CQUFVO1FBQWlCOzs7OztRQUMzQyx3QkFBQyxVQUFEO1NBQVUsT0FBTTttQkFBaUI7UUFBd0I7Ozs7O09BQzFDOzs7OztnQkFFakIsd0JBQUMsY0FBRDtPQUNFLFNBQVE7T0FDUixlQUFlLGtCQUFrQixjQUFjLElBQUk7aUJBQ3BEO01BRWE7Ozs7Y0FDVDs7Ozs7YUFDSjs7Ozs7O0dBQ0Y7Ozs7O0dBR0wsd0JBQUMsS0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxvQkFBRCxFQUEyQixNQUFROzs7OztHQUNoQzs7Ozs7R0FHTCx3QkFBQyxRQUFEO0lBQ0UsTUFBTTtJQUNOLFNBQVM7SUFDVCxPQUFPLEVBQUUsZ0JBQWdCLEtBQUs7SUFDOUI7SUFDQSxVQUFVLGNBQWMsZUFBZSxPQUFPO2NBTGhEO0tBT0Usd0JBQUMsYUFBRDtNQUFhLElBQUksRUFBRSxZQUFZLE9BQU87Z0JBQXRDO09BQ0csY0FBYyxnQkFBZ0I7T0FDOUIsY0FBYyxXQUFXO09BQ3pCLGNBQWMsY0FBYztNQUNsQjs7Ozs7O0tBRWIsd0JBQUMsZUFBRDtNQUFlO2dCQUFVLG1CQUFtQjtLQUFpQjs7Ozs7S0FFN0Qsd0JBQUMsZUFBRDtNQUFlLElBQUk7T0FBRSxHQUFHO09BQUcsS0FBSztNQUFJO2dCQUFwQyxDQUNFLHdCQUFDLGNBQUQ7T0FDRSxZQUFXO09BQ1gsU0FBUztPQUNULFNBQVE7T0FDUixPQUFNO2lCQUNQO01BRWE7Ozs7Z0JBRWIsY0FBYyxnQkFDYix3QkFBQyxjQUFEO09BQ0UsZUFBZTtRQUNiLFFBQVEsSUFDTixtREFBbUQsVUFDckQ7T0FDRjtpQkFDRDtNQUVhOzs7O2NBRUg7Ozs7OztJQUNUOzs7Ozs7RUFDTDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW52b2ljZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgTWF0ZXJpYWxSZWFjdFRhYmxlLFxyXG4gIHVzZU1hdGVyaWFsUmVhY3RUYWJsZSxcclxufSBmcm9tIFwibWF0ZXJpYWwtcmVhY3QtdGFibGVcIjtcclxuaW1wb3J0IHsgRGF0YSB9IGZyb20gXCIuLi8uLi8uLi9EYXRhL0RhdGFcIjtcclxuaW1wb3J0IHsgR3JpZCwgQm94LCBUeXBvZ3JhcGh5LCBTdGFjayB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBTZWFyY2hJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL1NlYXJjaFwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBEaWFsb2csXHJcbiAgRGlhbG9nVGl0bGUsXHJcbiAgRGlhbG9nQ29udGVudCxcclxuICBEaWFsb2dBY3Rpb25zLFxyXG4gIFRleHRGaWVsZCxcclxuICBNZW51SXRlbSxcclxuICBQYXBlcixcclxuICBJbnB1dEJhc2UsXHJcbiAgSWNvbkJ1dHRvbixcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgXCIuLi9pbnZvaWNlL2ludm9pY2Uuc2Nzc1wiO1xyXG5pbXBvcnQgQ3VzdG9tQnV0dG9uIGZyb20gXCIuLi8uLi8uLi9Db21wb25lbnRzL0N1c3RvbUJ1dHRvblwiO1xyXG5cclxuLy8g8J+TpiBSZWFjdCBIb29rIEZvcm0gcGFja2FnZXMgZm9yIHN0YW5kYXJkIEphdmFTY3JpcHQgc3RhdGUgaGFuZGxpbmdcclxuaW1wb3J0IHsgdXNlRm9ybSwgdXNlRmllbGRBcnJheSwgQ29udHJvbGxlciB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuXHJcbmltcG9ydCB7IHl1cFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMveXVwXCI7XHJcbmltcG9ydCBDb21tb25CdXR0b24gZnJvbSBcIi4uLy4uLy4uL0NvbXBvbmVudHMvQ3VzdG9tQnV0dG9uXCI7XHJcbmltcG9ydCBQYXltZW50c0ljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvUGF5bWVudHNcIjtcclxuaW1wb3J0IExpc3RJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0xpc3RcIjtcclxuaW1wb3J0IHsgRGF0ZVBpY2tlciB9IGZyb20gXCJAbXVpL3gtZGF0ZS1waWNrZXJzXCI7XHJcbmltcG9ydCB7IExvY2FsaXphdGlvblByb3ZpZGVyIH0gZnJvbSBcIkBtdWkveC1kYXRlLXBpY2tlcnNcIjtcclxuaW1wb3J0IHtBZGFwdGVyRGF5anN9IGZyb20gXCJAbXVpL3gtZGF0ZS1waWNrZXJzL0FkYXB0ZXJEYXlqc1wiO1xyXG5pbXBvcnQgeyBUUlVFIH0gZnJvbSBcInNhc3NcIjtcclxuaW1wb3J0IEN1c3RvbVRleHRGaWVsZCBmcm9tIFwiLi4vLi4vLi4vQ29tcG9uZW50cy9DdXN0b21GaWVsZFwiO1xyXG5cclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbnZvaWNlKCkge1xyXG4gIGNvbnN0IFttb2RhbE9wZW4sIHNldE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21vZGFsVHlwZSwgc2V0TW9kYWxUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEludm9pY2UsIHNldFNlbGVjdGVkSW52b2ljZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc3RhdHVzZmlsdGVyLCBzZXRTdGF0dXNGaWx0ZXJdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgLy8g4pqhIE1hc3RlciB1c2VGb3JtIGNvbmZpZ3VyYXRpb24gd2l0aCBzdGFuZGFyZCBkZWZhdWx0IGxheW91dHMgcHJvcGVydGllcyBtYXRjaGluZyB1bmdhbCBtYXRyaXgga2V5c1xyXG4gIGNvbnN0IHtcclxuICAgIGhhbmRsZVN1Ym1pdCxcclxuICAgIGNvbnRyb2wsXHJcbiAgICByZXNldCxcclxuICAgIGdldFZhbHVlcyxcclxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSxcclxuICB9ID0gdXNlRm9ybSh7XHJcbiAgICBkZWZhdWx0VmFsdWVzOiB7XHJcbiAgICAgIGludm9pY2VOdW1iZXI6IFwiXCIsXHJcbiAgICAgIGN1c3RvbWVySWQ6IFwiXCIsXHJcbiAgICAgIGludm9pY2VEYXRlOiBcIlwiLFxyXG4gICAgICBwYXltZW50VGVybXM6IFwiMzAgRGF5c1wiLFxyXG4gICAgICBzdGF0dXM6IFwiVW5wYWlkXCIsXHJcbiAgICAgIC8vIE11bHRpcGxlIGl0ZW1zIGRlZXAgbmVzdGVkIG9iamVjdCB0ZW1wbGF0ZXMgc2NoZW1hIHRyYWNraW5nIGFycmF5XHJcbiAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgeyBkZXNjcmlwdGlvbjogXCJcIiwgaXRlbUNvZGU6IFwiXCIsIHF0eTogMSwgcmF0ZTogMCwgZGlzY291bnQ6IDAsIGdzdDogMCB9LFxyXG4gICAgICBdLFxyXG4gICAgICAvLyBNdWx0aXBsZSBwYXltZW50cyBuZXN0ZWQgYXJyYXkgbGlzdCB0ZW1wbGF0ZXMgc2NoZW1hcyB0cmFja2luZyB0cmFja2luZyByZWZlcmVuY2VzXHJcbiAgICAgIHBheW1lbnRzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcGF5bWVudElkOiBgUEFZLSR7TWF0aC5mbG9vcigxMDAwICsgTWF0aC5yYW5kb20oKSAqIDkwMDApfWAsXHJcbiAgICAgICAgICBhbW91bnRQYWlkOiAwLFxyXG4gICAgICAgICAgcGF5bWVudERhdGU6IFwiXCIsXHJcbiAgICAgICAgICBwYXltZW50TW9kZTogXCJCYW5rIFRyYW5zZmVyXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnNvbGUubG9nKFwiZ2V0VmFsdWVzXCIsIGdldFZhbHVlcygpKTtcclxuXHJcbiAgLy8gRHluYW1pYyBsb29wcyB0cmFja2luZyBob29rcyBwYXJhbWV0ZXJzIG1hcHBpbmcgaW5wdXRzIHZhcmlhYmxlcyBsaXZlXHJcbiAgY29uc3Qge1xyXG4gICAgZmllbGRzOiBpdGVtRmllbGRzLFxyXG4gICAgYXBwZW5kOiBhcHBlbmRJdGVtLFxyXG4gICAgcmVtb3ZlOiByZW1vdmVJdGVtLFxyXG4gIH0gPSB1c2VGaWVsZEFycmF5KHtcclxuICAgIGNvbnRyb2wsXHJcbiAgICBuYW1lOiBcIml0ZW1zXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGZpZWxkczogcGF5bWVudEZpZWxkcyxcclxuICAgIGFwcGVuZDogYXBwZW5kUGF5bWVudCxcclxuICAgIHJlbW92ZTogcmVtb3ZlUGF5bWVudCxcclxuICB9ID0gdXNlRmllbGRBcnJheSh7XHJcbiAgICBjb250cm9sLFxyXG4gICAgbmFtZTogXCJwYXltZW50c1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBpbnZvaWNlRGF0YSA9IERhdGE/Lmludm9pY2VzO1xyXG5cclxuICBjb25zdCBoYW5kbGVEcm9wRG93bkNoYW5nZSA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0U3RhdHVzRmlsdGVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBmaWx0ZXJTdGF0dXNEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCByYXdJbnZvaWNlcyA9IEFycmF5LmlzQXJyYXkoaW52b2ljZURhdGEpID8gaW52b2ljZURhdGEgOiBbXTtcclxuICAgIGNvbnN0IGN1c3RvbWVyTGlzdCA9IERhdGE/LmN1c3RvbWVycyB8fCBbXTtcclxuXHJcbiAgICBjb25zdCBmb3JtYXR0ZWQgPSByYXdJbnZvaWNlcy5tYXAoKGludm9pY2UpID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hlZEN1c3RvbWVyID0gY3VzdG9tZXJMaXN0LmZpbmQoXHJcbiAgICAgICAgKGN1c3QpID0+IGN1c3QuY3VzdG9tZXJJZCA9PT0gaW52b2ljZT8uY3VzdG9tZXJJZCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgcmF3SW52b2ljZTogaW52b2ljZSxcclxuICAgICAgICBpbnZvaWNlTnVtYmVyOlxyXG4gICAgICAgICAgaW52b2ljZT8ucXVvdGF0aW9uTnVtYmVyIHx8IGludm9pY2U/Lmludm9pY2VOdW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgY29tcGFueU5hbWU6IG1hdGNoZWRDdXN0b21lciA/IG1hdGNoZWRDdXN0b21lci5jb21wYW55TmFtZSA6IFwiLVwiLFxyXG4gICAgICAgIGludm9pY2VEYXRlOiBpbnZvaWNlPy5xdW90YXRpb25EYXRlIHx8IGludm9pY2U/Lmludm9pY2VEYXRlIHx8IFwiLVwiLFxyXG4gICAgICAgIHBheW1lbnRUZXJtczogbWF0Y2hlZEN1c3RvbWVyPy5wYXltZW50VGVybXMgfHwgXCItXCIsXHJcbiAgICAgICAgYW1vdW50OiBpbnZvaWNlPy5ncmFuZFRvdGFsIHx8IGludm9pY2U/LnN1YnRvdGFsIHx8IDAsXHJcbiAgICAgICAgc3RhdHVzOiBpbnZvaWNlPy5zdGF0dXMgfHwgXCItXCIsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICBsZXQgcmVzdWx0ID0gZm9ybWF0dGVkO1xyXG4gICAgaWYgKHN0YXR1c2ZpbHRlcj8udG9Mb3dlckNhc2UoKSAhPT0gXCJhbGxcIiAmJiBzdGF0dXNmaWx0ZXIpIHtcclxuICAgICAgcmVzdWx0ID0gcmVzdWx0LmZpbHRlcihcclxuICAgICAgICAoaW52b2ljZSkgPT5cclxuICAgICAgICAgIGludm9pY2U/LnN0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gc3RhdHVzZmlsdGVyPy50b0xvd2VyQ2FzZSgpLFxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZWFyY2hRdWVyeS50cmltKCkgIT09IFwiXCIpIHtcclxuICAgICAgY29uc3QgcXVlcnkgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICByZXN1bHQgPSByZXN1bHQuZmlsdGVyKChpbnZvaWNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIGludm9pY2UuaW52b2ljZU51bWJlci50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxyXG4gICAgICAgICAgaW52b2ljZS5jb21wYW55TmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxyXG4gICAgICAgICAgaW52b2ljZS5pbnZvaWNlRGF0ZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxyXG4gICAgICAgICAgaW52b2ljZS5wYXltZW50VGVybXMudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxdWVyeSkgfHxcclxuICAgICAgICAgIGludm9pY2Uuc3RhdHVzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpIHx8XHJcbiAgICAgICAgICBTdHJpbmcoaW52b2ljZS5hbW91bnQpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpXHJcbiAgICAgICAgKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9LCBbaW52b2ljZURhdGEsIHN0YXR1c2ZpbHRlciwgc2VhcmNoUXVlcnksIERhdGE/LmN1c3RvbWVyc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBY3Rpb25DbGljayA9ICh0eXBlLCByb3dEYXRhKSA9PiB7XHJcbiAgICBzZXRNb2RhbE9wZW4odHJ1ZSk7XHJcbiAgICBzZXRNb2RhbFR5cGUodHlwZSk7XHJcbiAgICBzZXRTZWxlY3RlZEludm9pY2Uocm93RGF0YSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcclxuICAgIHNldE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICBzZXRTZWxlY3RlZEludm9pY2UobnVsbCk7XHJcbiAgICByZXNldCgpOyAvLyBDb3JlIGZvcm0gY2xlYW51cCBmdW5jdGlvbiB0cmlnZ2VyZWQgc21vb3RobHkgb24gZXhpdFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uRm9ybVN1Ym1pdCA9IChmb3JtRGF0YSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXHJcbiAgICAgIFwiU1VDQ0VTUyEgUmVhY3QgSG9vayBGb3JtIC0gSW52b2ljZSBQYXlsb2FkIE9iamVjdCBEYXRhOlwiLFxyXG4gICAgICBmb3JtRGF0YSxcclxuICAgICk7XHJcbiAgICBhbGVydChcIkludm9pY2UgRm9ybSBTYXZlZCBTdWNjZXNzZnVsbHkhIE5vOiBcIiArIGZvcm1EYXRhLmludm9pY2VOdW1iZXIpO1xyXG4gICAgaGFuZGxlQ2xvc2VNb2RhbCgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGtwaURhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGludm9pY2VMaXN0ID0gRGF0YT8uaW52b2ljZXMgfHwgW107XHJcbiAgICBjb25zdCB0b3RhbEludm9pY2VzID0gaW52b2ljZUxpc3QubGVuZ3RoO1xyXG4gICAgY29uc3QgcGFpZENvdW50ID0gaW52b2ljZUxpc3QuZmlsdGVyKFxyXG4gICAgICAoaW52KSA9PiBpbnYuc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcInBhaWRcIixcclxuICAgICkubGVuZ3RoO1xyXG4gICAgY29uc3QgdW5QYWlkQ291bnQgPSBpbnZvaWNlTGlzdC5maWx0ZXIoXHJcbiAgICAgIChpbnYpID0+IGludi5zdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09IFwidW5wYWlkXCIsXHJcbiAgICApLmxlbmd0aDtcclxuICAgIGNvbnN0IG92ZXJEdWVDb3VudCA9IGludm9pY2VMaXN0LmZpbHRlcihcclxuICAgICAgKGludikgPT4gaW52LnN0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gXCJvdmVyZHVlXCIsXHJcbiAgICApLmxlbmd0aDtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsSW52b2ljZXMsXHJcbiAgICAgIHBhaWRDb3VudCxcclxuICAgICAgdW5QYWlkQ291bnQsXHJcbiAgICAgIG92ZXJEdWVDb3VudCxcclxuICAgIH07XHJcbiAgfSwgW0RhdGE/Lmludm9pY2VzXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gW1xyXG4gICAgICB7IGFjY2Vzc29yS2V5OiBcImludm9pY2VOdW1iZXJcIiwgaGVhZGVyOiBcIkludm9pY2UgTm9cIiB9LFxyXG4gICAgICB7IGFjY2Vzc29yS2V5OiBcImNvbXBhbnlOYW1lXCIsIGhlYWRlcjogXCJDb21wYW55IE5hbWVcIiB9LFxyXG4gICAgICB7IGFjY2Vzc29yS2V5OiBcImludm9pY2VEYXRlXCIsIGhlYWRlcjogXCJJbnZvaWNlIERhdGVcIiB9LFxyXG4gICAgICB7IGFjY2Vzc29yS2V5OiBcInBheW1lbnRUZXJtc1wiLCBoZWFkZXI6IFwiUGF5bWVudCBUZXJtc1wiIH0sXHJcbiAgICAgIHsgYWNjZXNzb3JLZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgICB7IGFjY2Vzc29yS2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgICAge1xyXG4gICAgICAgIGFjY2Vzc29yS2V5OiBcImFjdGlvbnNcIixcclxuICAgICAgICBoZWFkZXI6IFwiQWN0aW9uXCIsXHJcbiAgICAgICAgZW5hYmxlU29ydGluZzogZmFsc2UsXHJcbiAgICAgICAgQ2VsbDogKHsgcm93IH0pID0+IChcclxuICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBzcGFjaW5nPXsyfSBzeD17eyB3aWR0aDogXCJhdXRvXCIgfX0+XHJcbiAgICAgICAgICAgIDxDdXN0b21CdXR0b25cclxuICAgICAgICAgICAgICBidXR0b25UeXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgc3RhcnRJY29uPXs8TGlzdEljb24gLz59XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQWN0aW9uQ2xpY2soXCJpdGVtc1wiLCByb3cub3JpZ2luYWwpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgSXRlbXNcclxuICAgICAgICAgICAgPC9DdXN0b21CdXR0b24+XHJcbiAgICAgICAgICAgIDxDdXN0b21CdXR0b25cclxuICAgICAgICAgICAgICBidXR0b25UeXBlPVwicHVycGxlXCJcclxuICAgICAgICAgICAgICBzdGFydEljb249ezxQYXltZW50c0ljb24gLz59XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQWN0aW9uQ2xpY2soXCJwYXltZW50c1wiLCByb3cub3JpZ2luYWwpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUGF5bWVudHNcclxuICAgICAgICAgICAgPC9DdXN0b21CdXR0b24+XHJcbiAgICAgICAgICA8L1N0YWNrPlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgW10sXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgdGFibGUgPSB1c2VNYXRlcmlhbFJlYWN0VGFibGUoe1xyXG4gICAgY29sdW1ucyxcclxuICAgIGRhdGE6IGZpbHRlclN0YXR1c0RhdGEsXHJcbiAgICBlbmFibGVHbG9iYWxGaWx0ZXI6IGZhbHNlLFxyXG4gICAgZW5hYmxlVG9wVG9vbGJhcjogZmFsc2UsXHJcbiAgICBlbmFibGVGaWx0ZXJzOiBmYWxzZSxcclxuICAgIGVuYWJsZVBhZ2luYXRpb246IHRydWUsXHJcbiAgICBlbmFibGVIaWRpbmc6IGZhbHNlLFxyXG4gICAgZW5hYmxlQ29sdW1uQWN0aW9uczogZmFsc2UsXHJcbiAgICBlbmFibGVGdWxsU2NyZWVuVG9nZ2xlOiBmYWxzZSxcclxuICAgIGVuYWJsZURlbnNpdHlUb2dnbGU6IGZhbHNlLFxyXG4gICAgcGFnaW5hdGlvbkRpc3BsYXlNb2RlOiBcInBhZ2VzXCIsXHJcbiAgICBsYXlvdXRNb2RlOiBcInNlbWFudGljXCIsXHJcbiAgICBpbml0aWFsU3RhdGU6IHtcclxuICAgICAgZGVuc2l0eTogXCJjb21wYWN0XCIsXHJcbiAgICAgIHBhZ2luYXRpb246IHsgcGFnZUluZGV4OiAwLCBwYWdlU2l6ZTogMTAgfSxcclxuICAgIH0sXHJcbiAgICBtdWlUYWJsZUhlYWRDZWxsUHJvcHM6IHsgY2xhc3NOYW1lOiBcInRhYmxlaGVhZGVyXCIgfSxcclxuICAgIG11aVRhYmxlUHJvcHM6IHsgY2xhc3NOYW1lOiBcIm1ydC1nYXBwZWQtdGFibGVcIiB9LFxyXG4gICAgbXVpVGFibGVCb2R5Um93UHJvcHM6IHsgY2xhc3NOYW1lOiBcInRhYmxlYm9keVwiIH0sXHJcbiAgICBtdWlUYWJsZUNvbnRhaW5lclByb3BzOiB7IGNsYXNzTmFtZTogXCJzY3JvbGxcIiB9LFxyXG4gICAgbXVpVGFibGVQYXBlclByb3BzOiB7IGNsYXNzTmFtZTogXCJjdXN0b20gdGFibGVcIiB9LFxyXG4gIH0pO1xyXG4gIGNvbnN0IFxyXG4gIHJlbmRlclBvcHVwY29udGVudCA9ICgpID0+IHtcclxuICAgIGlmIChtb2RhbFR5cGUgPT09IFwiYWRkSW52b2ljZVwiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGZvcm0gaWQ9XCJhZGQtaW52b2ljZS1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvbkZvcm1TdWJtaXQpfT5cclxuICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXsyfSBzeD17eyBwdDogMSB9fT5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT5cclxuICAgICAgICAgICAgICA8Q29udHJvbGxlclxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImludm9pY2VOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgY29udHJvbD17Y29udHJvbH1cclxuICAgICAgICAgICAgICAgIHJ1bGVzPXt7IHJlcXVpcmVkOiBcIkludm9pY2UgTnVtYmVyIHJlcXVpcmVkXCIgfX1cclxuICAgICAgICAgICAgICAgIHJlbmRlcj17KHsgZmllbGQgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8Q3VzdG9tVGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiSW52b2ljZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I9eyEhZXJyb3JzLmludm9pY2VOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17ZXJyb3JzLmludm9pY2VOdW1iZXI/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17OH0gc209ezEwfT5cclxuICAgICAgICAgICAgICA8Q3VzdG9tVGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiU2VsZWN0IENvbXBhbnkgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgIHdpZHRoPVwiMjIwcHhcIlxyXG4gICAgICAgICAgICAgICAgey4uLmNvbnRyb2wucmVnaXN0ZXIoXCJjdXN0b21lcklkXCIsIHsgcmVxdWlyZWQ6IHRydWUgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgeyhEYXRhPy5jdXN0b21lcnMgfHwgW10pLm1hcCgoYykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8TWVudUl0ZW0ga2V5PXtjLmN1c3RvbWVySWR9IHZhbHVlPXtjLmN1c3RvbWVySWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjLmNvbXBhbnlOYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9DdXN0b21UZXh0RmllbGQ+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPExvY2FsaXphdGlvblByb3ZpZGVyIGRhdGVBZGFwdGVyPXtBZGFwdGVyRGF5anN9PlxyXG4gIDxDb250cm9sbGVyXHJcbiAgICBuYW1lPVwiaW52b2ljZURhdGVcIlxyXG4gICAgY29udHJvbD17Y29udHJvbH1cclxuICAgIHJlbmRlcj17KHsgZmllbGQgfSkgPT4gKFxyXG4gICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgIHZhbHVlPXtmaWVsZC52YWx1ZSA/IGRheWooZmllbGQudmFsdWUpIDogbnVsbH1cclxuICAgICAgICBvbkNoYW5nZT17KGRhdGUpID0+XHJcbiAgICAgICAgICBmaWVsZC5vbkNoYW5nZShkYXRlID8gZGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogXCJcIilcclxuICAgICAgICB9XHJcbiAgICAgICAgbGFiZWw9XCJJbnZvaWNlIERhdGVcIlxyXG4gICAgICAgIHNsb3RQcm9wcz17e1xyXG4gICAgICAgICAgdGV4dEZpZWxkOiB7XHJcbiAgICAgICAgICAgIHNpemU6IFwic21hbGxcIixcclxuICAgICAgICAgICAgZnVsbFdpZHRoOiBmYWxzZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuICAgICl9XHJcbiAgLz5cclxuPC9Mb2NhbGl6YXRpb25Qcm92aWRlcj5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT5cclxuICAgICAgICAgICAgICA8Q3VzdG9tVGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiUGF5bWVudCBUZXJtc1wiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoOnRydWVcclxuICAgICAgICAgICAgICAgIHsuLi5jb250cm9sLnJlZ2lzdGVyKFwicGF5bWVudFRlcm1zXCIpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIjE1IERheXNcIj4xNSBEYXlzPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIjMwIERheXNcIj4zMCBEYXlzPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cIjQ1IERheXNcIj40NSBEYXlzPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICA8L0N1c3RvbVRleHRGaWVsZD5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG5cclxuICAgICAgICAgIHsvKiBDb3JlIEludm9pY2UgUHJvZHVjdHMgSXRlbXMgRHluYW1pYyBMaXN0IExvb3AgU2VnbWVudCAqL31cclxuICAgICAgICAgIDxCb3ggc3g9e3sgbXQ6IDMgfX0+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIiBzeD17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgbWI6IDEgfX0+XHJcbiAgICAgICAgICAgICAgSW52b2ljZSBJdGVtcyBMaXN0XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAge2l0ZW1GaWVsZHMubWFwKChmaWVsZCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICBrZXk9e2ZpZWxkLmlkfVxyXG4gICAgICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICAgICAgcDogMixcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZTBlMGUwXCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMSxcclxuICAgICAgICAgICAgICAgICAgbWI6IDIsXHJcbiAgICAgICAgICAgICAgICAgIGJnY29sb3I6IFwiI2ZhZmFmYVwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U3RhY2tcclxuICAgICAgICAgICAgICAgICAgZGlyZWN0aW9uPVwicm93XCJcclxuICAgICAgICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICBtYjogMSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgc3g9e3sgZm9udFdlaWdodDogNTAwIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIFByb2R1Y3QgUm93ICN7aW5kZXggKyAxfVxyXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtRmllbGRzLmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDdXN0b21CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvblR5cGU9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwicmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZUl0ZW0oaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ3VzdG9tQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9TdGFjaz5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXsyfT5cclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29udHJvbGxlclxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGl0ZW1zLiR7aW5kZXh9LmRlc2NyaXB0aW9uYH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XHJcbiAgICAgICAgICAgICAgICAgICAgICBydWxlcz17eyByZXF1aXJlZDogdHJ1ZSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZDogZCB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDdXN0b21UZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4uZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRlc2NyaXB0aW9uIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29udHJvbGxlclxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGl0ZW1zLiR7aW5kZXh9Lml0ZW1Db2RlYH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyh7IGZpZWxkOiBjIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEN1c3RvbVRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5jfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiSXRlbSBDb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbnRyb2xsZXJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2BpdGVtcy4ke2luZGV4fS5xdHlgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17Y29udHJvbH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcj17KHsgZmllbGQ6IHEgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3VzdG9tVGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLnF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJRdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBxLm9uQ2hhbmdlKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbnRyb2xsZXJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2BpdGVtcy4ke2luZGV4fS5yYXRlYH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyh7IGZpZWxkOiByIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEN1c3RvbVRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUmF0ZSBQcmljZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHIub25DaGFuZ2UoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29udHJvbGxlclxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGl0ZW1zLiR7aW5kZXh9LmRpc2NvdW50YH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyh7IGZpZWxkOiBkcyB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDdXN0b21UZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4uZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEaXNjICVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBkcy5vbkNoYW5nZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb250cm9sbGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtgaXRlbXMuJHtpbmRleH0uZ3N0YH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9eyh7IGZpZWxkOiBnIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEN1c3RvbVRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiR1NUICVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBnLm9uQ2hhbmdlKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8Q3VzdG9tQnV0dG9uXHJcbiAgICAgICAgICAgICBidXR0b25UeXBlPVwicHVycGxlXCJcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgYXBwZW5kSXRlbSh7XHJcbiAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICBpdGVtQ29kZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgcXR5OiAxLFxyXG4gICAgICAgICAgICAgICAgICByYXRlOiAwLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudDogMCxcclxuICAgICAgICAgICAgICAgICAgZ3N0OiAwLFxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICArIEFkZCBJdGVtXHJcbiAgICAgICAgICAgIDwvQ3VzdG9tQnV0dG9uPlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghc2VsZWN0ZWRJbnZvaWNlKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICAvLyDwn5KhIEIpIEl0ZW1zIERldGFpbHMgVmlld2luZyBCbG9jayBTZXR1cFxyXG4gICAgaWYgKG1vZGFsVHlwZSA9PT0gXCJpdGVtc1wiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveD5cclxuICAgICAgICAgIHtzZWxlY3RlZEludm9pY2UucmF3SW52b2ljZT8uaXRlbXMgJiZcclxuICAgICAgICAgIHNlbGVjdGVkSW52b2ljZS5yYXdJbnZvaWNlPy5pdGVtcz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbnZvaWNlLnJhd0ludm9pY2U/Lml0ZW1zPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgICAgIG1iOiAyLFxyXG4gICAgICAgICAgICAgICAgICBwOiAyLFxyXG4gICAgICAgICAgICAgICAgICBiZ2NvbG9yOiBcIiNmOWY5ZjlcIixcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZTVlN2ViXCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN1YnRpdGxlMVwiXHJcbiAgICAgICAgICAgICAgICAgIHN4PXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBjb2xvcjogXCJwcmltYXJ5Lm1haW5cIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjcmlwdGlvbiB8fCBcIlByb2R1Y3QgSXRlbVwifVxyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgPFN0YWNrIHNwYWNpbmc9ezAuNX0gc3g9e3sgbXQ6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+SXRlbSBDb2RlOjwvc3Ryb25nPiB7aXRlbS5pdGVtQ29kZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlF1YW50aXR5Ojwvc3Ryb25nPiB7aXRlbS5xdHkgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlJhdGU6PC9zdHJvbmc+IOKCuXtpdGVtLnJhdGUgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkRpc2NvdW50Ojwvc3Ryb25nPiB7aXRlbS5kaXNjb3VudCB8fCAwfSVcclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkdTVDo8L3N0cm9uZz4ge2l0ZW0uZ3N0IHx8IDB9JVxyXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN1YnRpdGxlMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3g9e3sgbXQ6IDEsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBMaW5lIEFtb3VudDog4oK5e2l0ZW0uYW1vdW50Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvU3RhY2s+XHJcbiAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICkpXHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgTm8gaXRlbXMgZm91bmQgZm9yIHRoaXMgSW52b2ljZS5cclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0JveD5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyAgQykgUGF5bWVudHMgTGVkZ2VyIFZpZXdpbmcgQmxvY2sgU2V0dXBcclxuICAgIGlmIChtb2RhbFR5cGUgPT09IFwicGF5bWVudHNcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3g+XHJcbiAgICAgICAgICB7c2VsZWN0ZWRJbnZvaWNlLnJhd0ludm9pY2U/LnBheW1lbnRzICYmXHJcbiAgICAgICAgICBzZWxlY3RlZEludm9pY2UucmF3SW52b2ljZT8ucGF5bWVudHM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIHNlbGVjdGVkSW52b2ljZS5yYXdJbnZvaWNlPy5wYXltZW50cz8ubWFwKChwYXltZW50LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgICAgICBtYjogMixcclxuICAgICAgICAgICAgICAgICAgcDogMixcclxuICAgICAgICAgICAgICAgICAgYmdjb2xvcjogXCIjZjBmZGY0XCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI2JiZjdkMFwiLFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIlxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImdyZWVuXCJcclxuICAgICAgICAgICAgICAgICAgc3g9e3sgZm9udFdlaWdodDogXCJib2xkXCIgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUGF5bWVudCBSZWNlaXB0ICN7aW5kZXggKyAxfVxyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgPFN0YWNrIHNwYWNpbmc9ezAuNX0gc3g9e3sgbXQ6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+UGF5bWVudCBJZDo8L3N0cm9uZz4ge3BheW1lbnQucGF5bWVudElkIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGF0ZTo8L3N0cm9uZz4ge3BheW1lbnQuZGF0ZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk1vZGU6PC9zdHJvbmc+IHtwYXltZW50Lm1vZGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5SZWZlcmVuY2U6PC9zdHJvbmc+IHtwYXltZW50LnJlZmVyZW5jZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN4PXt7IG10OiAwLjUsIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLCBjb2xvcjogXCJncmVlblwiIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBbW91bnQgQ3JlZGl0ZWQ6IOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHtwYXltZW50LmFtb3VudD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICA8L1N0YWNrPlxyXG4gICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApKVxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgICBwOiAyLFxyXG4gICAgICAgICAgICAgICAgYmdjb2xvcjogXCIjZmVmMmYyXCIsXHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNmZWNhY2FcIixcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJlcnJvci5tYWluXCI+XHJcbiAgICAgICAgICAgICAgICBObyB0cmFuc2FjdGlvbnMgcmVjb3JkZWQuIFRoaXMgaW52b2ljZSByZW1haW5zIGNvbXBsZXRlbHlcclxuICAgICAgICAgICAgICAgIHVucGFpZC5cclxuICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxCb3ggc3g9e3sgbXQ6IDIsIHB0OiAyLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNlMGUwZTBcIiB9fT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+XHJcbiAgICAgICAgICAgICAgQ3VycmVudCBTdGFuZGluZyBTdGF0dXM6IDxzdHJvbmc+e3NlbGVjdGVkSW52b2ljZS5zdGF0dXN9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPEJveCBjbGFzc05hbWU9XCJUYWJsZVwiPlxyXG4gICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9XCJpbnZvaWNlTmFtZVwiPkludm9pY2UgTWFuYWdlbWVudDwvVHlwb2dyYXBoeT5cclxuXHJcbiAgICAgIHsvKiBLUEkgRGlzcGxheSBNZXRyaWNzIFBhbmVscyBCbG9ja3MgKi99XHJcbiAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXsyfSBjbGFzc05hbWU9XCJrcGktY29udGFpbmVyXCIgc3g9e3sgbWI6IDMgfX0+XHJcbiAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXszfT5cclxuICAgICAgICAgIDxCb3ggY2xhc3NOYW1lPVwidG90YWxcIj5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPVwic3RhdHVzXCI+VG90YWwgSW52b2ljZXM8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5PntrcGlEYXRhLnRvdGFsSW52b2ljZXN9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17M30+XHJcbiAgICAgICAgICA8Qm94IGNsYXNzTmFtZT1cImtwaS1wYWlkXCI+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT1cInN0YXR1c1wiPlBhaWQgQW1vdW50PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeT57a3BpRGF0YS5wYWlkQ291bnR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17M30+XHJcbiAgICAgICAgICA8Qm94IGNsYXNzTmFtZT1cImtwaS11bnBhaWRcIj5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPVwic3RhdHVzXCI+VW5wYWlkIEFtb3VudDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHk+e2twaURhdGEudW5QYWlkQ291bnR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17M30+XHJcbiAgICAgICAgICA8Qm94IGNsYXNzTmFtZT1cImtwaS1vdmVyXCI+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT1cInN0YXR1c1wiPk92ZXIgRHVlPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeT57a3BpRGF0YS5vdmVyRHVlQ291bnR9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0dyaWQ+XHJcblxyXG4gICAgICB7LyogQWN0aW9uIENvbnRyb2xsZXJzIGFuZCBGaWx0ZXIgU3RhdHVzIERyb3Bkb3ducyAqL31cclxuICAgICAgPEJveCBjbGFzc05hbWU9XCJOZXdJbnZcIj5cclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICBtYjogMSxcclxuICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8UGFwZXJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJbnB1dEJhc2VcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBJbnZvaWNlXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxJY29uQnV0dG9uIHN4PXt7IHA6IFwiNnB4XCIsIGNvbG9yOiBcIiM2YjYzNzVcIiB9fT48L0ljb25CdXR0b24+XHJcbiAgICAgICAgICA8L1BhcGVyPlxyXG5cclxuICAgICAgICAgIDxTdGFjayBkaXJlY3Rpb249XCJyb3dcIiBzcGFjaW5nPXsxLjV9IHN4PXt7IGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgIDxDdXN0b21UZXh0RmllbGRcclxuICAgICAgICAgICAgICBzZWxlY3RcclxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRmlsdGVyIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c3RhdHVzZmlsdGVyfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhdHVzRmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJEcm9wZG93blwiXHJcbiAgICAgICAgICAgICAgc3g9e3sgbWluV2lkdGg6IFwiMTQwcHhcIiB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFN0YXR1czwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwicGFpZFwiPlBhaWQ8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cInVucGFpZFwiPlVuUGFpZDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPVwib3ZlcmR1ZVwiPk92ZXJkdWU8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT1cInBhcnRpYWxseSBQYWlkXCI+UGFydGlhbGx5IFBhaWQ8L01lbnVJdGVtPlxyXG4gICAgICAgICAgICA8L0N1c3RvbVRleHRGaWVsZD5cclxuXHJcbiAgICAgICAgICAgIDxDdXN0b21CdXR0b25cclxuICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBY3Rpb25DbGljayhcImFkZEludm9pY2VcIiwgbnVsbCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBZGQgSW52b2ljZVxyXG4gICAgICAgICAgICA8L0N1c3RvbUJ1dHRvbj5cclxuICAgICAgICAgIDwvU3RhY2s+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQm94PlxyXG5cclxuICAgICAgey8qIE1haW4gRGF0YWdyaWQgQ29yZSBWaWV3IFRhYmxlIFdyYXBwZXIgKi99XHJcbiAgICAgIDxCb3ggY2xhc3NOYW1lPVwidGFibGUtd3JhcHBlclwiPlxyXG4gICAgICAgIDxNYXRlcmlhbFJlYWN0VGFibGUgdGFibGU9e3RhYmxlfSAvPlxyXG4gICAgICA8L0JveD5cclxuXHJcbiAgICAgIHsvKiBTaGFyZWQgUG9wdXAgV2luZG93IERpYWxvZyBMYXlvdXQgQ29tcG9uZW50ICovfVxyXG4gICAgICA8RGlhbG9nXHJcbiAgICAgICAgb3Blbj17bW9kYWxPcGVufVxyXG4gICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9XHJcbiAgICAgICAgc2xvdHM9e3sgYmFja2Ryb3A6ICgpID0+IG51bGwgfX1cclxuICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICBtYXhXaWR0aD17bW9kYWxUeXBlID09PSBcImFkZEludm9pY2VcIiA/IFwibWRcIiA6IFwieHNcIn0gLy8gRm9ybSBleHBhbmRpbmcgc2l6ZSBhZGp1c3RtZW50IHBhcmFtZXRlcnMgbGl2ZVxyXG4gICAgICA+XHJcbiAgICAgICAgPERpYWxvZ1RpdGxlIHN4PXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwiIH19PlxyXG4gICAgICAgICAge21vZGFsVHlwZSA9PT0gXCJhZGRJbnZvaWNlXCIgJiYgXCJBZGQgTmV3IEludm9pY2VcIn1cclxuICAgICAgICAgIHttb2RhbFR5cGUgPT09IFwiaXRlbXNcIiAmJiBcIkludm9pY2UgSXRlbSBEZXRhaWxzXCJ9XHJcbiAgICAgICAgICB7bW9kYWxUeXBlID09PSBcInBheW1lbnRzXCIgJiYgXCJQYXltZW50IExlZGdlclwifVxyXG4gICAgICAgIDwvRGlhbG9nVGl0bGU+XHJcblxyXG4gICAgICAgIDxEaWFsb2dDb250ZW50IGRpdmlkZXJzPntyZW5kZXJQb3B1cGNvbnRlbnQoKX08L0RpYWxvZ0NvbnRlbnQ+XHJcblxyXG4gICAgICAgIDxEaWFsb2dBY3Rpb25zIHN4PXt7IHA6IDIsIGdhcDogMS41IH19PlxyXG4gICAgICAgICAgPEN1c3RvbUJ1dHRvblxyXG4gICAgICAgICAgICBidXR0b25UeXBlPVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbG9zZU1vZGFsfVxyXG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgPC9DdXN0b21CdXR0b24+XHJcbiAgICAgICAgICB7LyogTGlua2VkIEZvcm0gU2F2ZSBUcmlnZ2VyIGJ1dHRvbiBtYXBwZWQgc2FmZWx5IHV0aWxpemluZyBmb3JtIHN0cnVjdHVyYWwgaWRlbnRpZmljYXRpb24ga2V5cyAqL31cclxuICAgICAgICAgIHttb2RhbFR5cGUgPT09IFwiYWRkSW52b2ljZVwiICYmIChcclxuICAgICAgICAgICAgPEN1c3RvbUJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxyXG4gICAgICAgICAgICAgICAgICBgQnV0dG9uIGNsaWNrZWQhIFRhcmdldCBJbnZvaWNlIE51bWJlciB2YWx1ZSBpczogJHtGb3JtRGF0YX1gLFxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU2F2ZSBJbnZvaWNlXHJcbiAgICAgICAgICAgIDwvQ3VzdG9tQnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0RpYWxvZ0FjdGlvbnM+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC9Cb3g+XHJcbiAgKTtcclxufVxyXG4iXX0=