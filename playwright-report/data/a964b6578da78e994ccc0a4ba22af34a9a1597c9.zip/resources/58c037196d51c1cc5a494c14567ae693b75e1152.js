const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const React = __vite__cjsImport4_react;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import __vite__cjsImport1_reactDom_client from "/ERP-Project/node_modules/.vite/deps/react-dom_client.js?v=2e25152d";
import "/ERP-Project/src/index.css";
import App from "/ERP-Project/src/App.jsx";
import __vite__cjsImport4_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { BrowserRouter, Routes, Route, Link } from "/ERP-Project/node_modules/.vite/deps/react-router-dom.js?v=1f423380";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/main.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 10,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 9,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTztBQUNQLE9BQU8sU0FBUztBQUNoQixPQUFPLFdBQVc7QUFDbEIsU0FBUyxlQUFlLFFBQVEsT0FBTyxZQUFZOzs7QUFFbkQsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUMxQyx3QkFBQyxZQUFELFlBQ0Usd0JBQUMsS0FBRCxDQUFNOzs7O1NBQ0k7Ozs7UUFDZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdHJpY3RNb2RlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xyXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xyXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLmpzeCdcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQnJvd3NlclJvdXRlciwgUm91dGVzLCBSb3V0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5cclxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKS5yZW5kZXIoXHJcbiAgPFN0cmljdE1vZGU+XHJcbiAgICA8QXBwIC8+XHJcbiAgPC9TdHJpY3RNb2RlPixcclxuKVxyXG4iXX0=