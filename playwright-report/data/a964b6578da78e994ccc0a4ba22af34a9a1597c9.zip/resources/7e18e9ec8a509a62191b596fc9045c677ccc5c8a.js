import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import reactLogo from "/ERP-Project/src/assets/react.svg?import";
import viteLogo from "/ERP-Project/src/assets/vite.svg?import";
import heroImg from "/ERP-Project/src/assets/hero.png?import";
import "/ERP-Project/src/App.scss";
import Layout from "/ERP-Project/src/Pages/Layout/Layout.jsx";
import PrivateRouter from "/ERP-Project/src/Routes/privaterouter.jsx";
import { BrowserRouter, Routes, Route } from "/ERP-Project/node_modules/.vite/deps/react-router-dom.js?v=1f423380";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/App.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
function App() {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, {
		basename: "/ERP-Project",
		children: [/* @__PURE__ */ _jsxDEV(Layout, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(PrivateRouter, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sY0FBYztBQUNyQixPQUFPLGFBQWE7QUFDcEIsT0FBTztBQUNQLE9BQU8sWUFBWTtBQUNuQixPQUFPLG1CQUFtQjtBQUMxQixTQUFTLGVBQWUsUUFBUSxhQUFhOzs7QUFFN0MsU0FBUyxNQUFNO0NBQ2IsT0FDRSwrQ0FDQSx3QkFBQyxlQUFEO0VBQWUsVUFBUztZQUF4QixDQUNFLHdCQUFDLFFBQUQsQ0FBUzs7OztZQUNULHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7VUFDRDs7Ozs7VUFDZjs7Ozs7QUFFTjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHJlYWN0TG9nbyBmcm9tIFwiLi9hc3NldHMvcmVhY3Quc3ZnXCI7XHJcbmltcG9ydCB2aXRlTG9nbyBmcm9tIFwiLi9hc3NldHMvdml0ZS5zdmdcIjtcclxuaW1wb3J0IGhlcm9JbWcgZnJvbSBcIi4vYXNzZXRzL2hlcm8ucG5nXCI7XHJcbmltcG9ydCBcIi4vQXBwLnNjc3NcIjtcclxuaW1wb3J0IExheW91dCBmcm9tIFwiLi9QYWdlcy9MYXlvdXQvTGF5b3V0XCI7XHJcbmltcG9ydCBQcml2YXRlUm91dGVyIGZyb20gXCIuL1JvdXRlcy9wcml2YXRlcm91dGVyXCI7XHJcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgPEJyb3dzZXJSb3V0ZXIgYmFzZW5hbWU9XCIvRVJQLVByb2plY3RcIj5cclxuICAgICAgPExheW91dCAvPlxyXG4gICAgICA8UHJpdmF0ZVJvdXRlciAvPlxyXG4gICAgICA8L0Jyb3dzZXJSb3V0ZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdfQ==