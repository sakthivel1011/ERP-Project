import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Routes/privaterouter.jsx");const React = __vite__cjsImport0_react; const Suspense = __vite__cjsImport0_react["Suspense"]; const lazy = __vite__cjsImport0_react["lazy"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { Route, Routes } from "/ERP-Project/node_modules/.vite/deps/react-router.js?v=f348e97d";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Routes/privaterouter.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
const styles = { loader: {
	display: "flex",
	justifyContent: "center",
	alignItems: "center",
	height: "80vh",
	fontSize: "18px",
	fontWeight: "600",
	fontFamily: "sans-serif",
	color: "#003366"
} };
const DynamicPage = ({ component: Component }) => /* @__PURE__ */ _jsxDEV(Suspense, {
	fallback: /* @__PURE__ */ _jsxDEV("div", { style: styles.loader }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 23
	}, this),
	children: /* @__PURE__ */ _jsxDEV(Component, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 18,
	columnNumber: 3
}, this);
_c = DynamicPage;
// Dashboard & Layout
const Dashboard = lazy(_c2 = () => import("/ERP-Project/src/Pages/Dashboard/Dashboard.jsx"));
_c3 = Dashboard;
const Layout = lazy(_c4 = () => import("/ERP-Project/src/Pages/Layout/Layout.jsx"));
_c5 = Layout;
// Sales Components
const Customer = lazy(_c6 = () => import("/ERP-Project/src/Pages/Sales/Customer/Customer.jsx"));
_c7 = Customer;
const Quotations = lazy(_c8 = () => import("/ERP-Project/src/Pages/Sales/Quotation/Quotations.jsx"));
_c9 = Quotations;
const Salesorder = lazy(_c10 = () => import("/ERP-Project/src/Pages/Sales/Salesorder.jsx"));
_c11 = Salesorder;
const Invoice = lazy(_c12 = () => import("/ERP-Project/src/Pages/Sales/invoice/Invoice.jsx"));
_c13 = Invoice;
// Purchase Components
const Vendor = lazy(_c14 = () => import("/ERP-Project/src/Pages/Purchase/Vendors.jsx"));
_c15 = Vendor;
const Purchaseorder = lazy(_c16 = () => import("/ERP-Project/src/Pages/Purchase/Purchaseorder.jsx"));
_c17 = Purchaseorder;
const Goodreceipt = lazy(_c18 = () => import("/ERP-Project/src/Pages/Purchase/Goodreceipt.jsx"));
_c19 = Goodreceipt;
// Inventory Components
const Product = lazy(_c20 = () => import("/ERP-Project/src/Pages/Inventory/Product.jsx"));
_c21 = Product;
const Stock = lazy(_c22 = () => import("/ERP-Project/src/Pages/Inventory/Stock.jsx"));
_c23 = Stock;
const Warehouse = lazy(_c24 = () => import("/ERP-Project/src/Pages/Inventory/Warehouse.jsx"));
_c25 = Warehouse;
const Transfer = lazy(_c26 = () => import("/ERP-Project/src/Pages/Inventory/Transfer.jsx"));
_c27 = Transfer;
// Manufacturing Components
const Bom = lazy(_c28 = () => import("/ERP-Project/src/Pages/Manufacturing/BOM.jsx"));
_c29 = Bom;
const Productionorders = lazy(_c30 = () => import("/ERP-Project/src/Pages/Manufacturing/Productionorder.jsx"));
_c31 = Productionorders;
const Workorder = lazy(_c32 = () => import("/ERP-Project/src/Pages/Manufacturing/Workorders.jsx"));
_c33 = Workorder;
// Finance Components
const Accounts = lazy(_c34 = () => import("/ERP-Project/src/Pages/Finance/Accounts.jsx"));
_c35 = Accounts;
const Payments = lazy(_c36 = () => import("/ERP-Project/src/Pages/Finance/Payments.jsx"));
_c37 = Payments;
const Expenses = lazy(_c38 = () => import("/ERP-Project/src/Pages/Finance/Expenses.jsx"));
_c39 = Expenses;
const Reports = lazy(_c40 = () => import("/ERP-Project/src/Pages/Finance/Reports.jsx"));
_c41 = Reports;
// HR Components
const Employees = lazy(_c42 = () => import("/ERP-Project/src/Pages/HR/Employess.jsx"));
_c43 = Employees;
const Attendence = lazy(_c44 = () => import("/ERP-Project/src/Pages/HR/Attendence.jsx"));
_c45 = Attendence;
const Leave = lazy(_c46 = () => import("/ERP-Project/src/Pages/HR/Leave.jsx"));
_c47 = Leave;
const Payroll = lazy(_c48 = () => import("/ERP-Project/src/Pages/HR/Payroll.jsx"));
_c49 = Payroll;
export default function PrivateRouter() {
	return /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "dashboard",
			element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Dashboard }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 40
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			index: true,
			element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Dashboard }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 29
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "sales",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "customer",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Customer }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "invoice",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Invoice }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "quotations",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Quotations }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "salesorder",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Salesorder }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "purchase",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "good receipt",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Goodreceipt }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "purchase order",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Purchaseorder }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "vendors",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Vendor }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "inventory",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "product",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Product }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "stock",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Stock }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 38
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "warehouse",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Warehouse }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "transfer",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Transfer }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "manufacturing",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "BOM",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Bom }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 36
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "productionorder",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Productionorders }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "workorder",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Workorder }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "finance",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "accounts",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Accounts }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "expenses",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Expenses }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "payments",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Payments }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "repots",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Reports }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 39
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "hr",
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "attendence",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Attendence }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "employess",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Employees }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 20
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "leave",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Leave }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 38
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "payroll",
					element: /* @__PURE__ */ _jsxDEV(DynamicPage, { component: Payroll }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
}
_c50 = PrivateRouter;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32, _c33, _c34, _c35, _c36, _c37, _c38, _c39, _c40, _c41, _c42, _c43, _c44, _c45, _c46, _c47, _c48, _c49, _c50;
$RefreshReg$(_c, "DynamicPage");
$RefreshReg$(_c2, "Dashboard$lazy");
$RefreshReg$(_c3, "Dashboard");
$RefreshReg$(_c4, "Layout$lazy");
$RefreshReg$(_c5, "Layout");
$RefreshReg$(_c6, "Customer$lazy");
$RefreshReg$(_c7, "Customer");
$RefreshReg$(_c8, "Quotations$lazy");
$RefreshReg$(_c9, "Quotations");
$RefreshReg$(_c10, "Salesorder$lazy");
$RefreshReg$(_c11, "Salesorder");
$RefreshReg$(_c12, "Invoice$lazy");
$RefreshReg$(_c13, "Invoice");
$RefreshReg$(_c14, "Vendor$lazy");
$RefreshReg$(_c15, "Vendor");
$RefreshReg$(_c16, "Purchaseorder$lazy");
$RefreshReg$(_c17, "Purchaseorder");
$RefreshReg$(_c18, "Goodreceipt$lazy");
$RefreshReg$(_c19, "Goodreceipt");
$RefreshReg$(_c20, "Product$lazy");
$RefreshReg$(_c21, "Product");
$RefreshReg$(_c22, "Stock$lazy");
$RefreshReg$(_c23, "Stock");
$RefreshReg$(_c24, "Warehouse$lazy");
$RefreshReg$(_c25, "Warehouse");
$RefreshReg$(_c26, "Transfer$lazy");
$RefreshReg$(_c27, "Transfer");
$RefreshReg$(_c28, "Bom$lazy");
$RefreshReg$(_c29, "Bom");
$RefreshReg$(_c30, "Productionorders$lazy");
$RefreshReg$(_c31, "Productionorders");
$RefreshReg$(_c32, "Workorder$lazy");
$RefreshReg$(_c33, "Workorder");
$RefreshReg$(_c34, "Accounts$lazy");
$RefreshReg$(_c35, "Accounts");
$RefreshReg$(_c36, "Payments$lazy");
$RefreshReg$(_c37, "Payments");
$RefreshReg$(_c38, "Expenses$lazy");
$RefreshReg$(_c39, "Expenses");
$RefreshReg$(_c40, "Reports$lazy");
$RefreshReg$(_c41, "Reports");
$RefreshReg$(_c42, "Employees$lazy");
$RefreshReg$(_c43, "Employees");
$RefreshReg$(_c44, "Attendence$lazy");
$RefreshReg$(_c45, "Attendence");
$RefreshReg$(_c46, "Leave$lazy");
$RefreshReg$(_c47, "Leave");
$RefreshReg$(_c48, "Payroll$lazy");
$RefreshReg$(_c49, "Payroll");
$RefreshReg$(_c50, "PrivateRouter");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Routes/privaterouter.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Routes/privaterouter.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Routes/privaterouter.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Routes/privaterouter.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsWUFBWTtBQUN0QyxTQUFTLE9BQU8sY0FBYzs7O0FBRTlCLE1BQU0sU0FBUyxFQUNiLFFBQVE7Q0FDTixTQUFTO0NBQ1QsZ0JBQWdCO0NBQ2hCLFlBQVk7Q0FDWixRQUFRO0NBQ1IsVUFBVTtDQUNWLFlBQVk7Q0FDWixZQUFZO0NBQ1osT0FBTztBQUNULEVBQ0Y7QUFFQSxNQUFNLGVBQWUsRUFBRSxXQUFXLGdCQUNoQyx3QkFBQyxVQUFEO0NBQVUsVUFBVSx3QkFBQyxPQUFELEVBQUssT0FBTyxPQUFPLE9BRWxDOzs7OztXQUNILHdCQUFDLFdBQUQsQ0FBWTs7Ozs7QUFDSjs7Ozs7OztBQUlaLE1BQU0sWUFBWSxpQkFBVyxPQUFPLCtCQUErQjs7QUFDbkUsTUFBTSxTQUFTLGlCQUFXLE9BQU8seUJBQXlCOzs7QUFHMUQsTUFBTSxXQUFXLGlCQUFXLE9BQU8sbUNBQW1DOztBQUN0RSxNQUFNLGFBQWEsaUJBQVcsT0FBTyxzQ0FBc0M7O0FBQzNFLE1BQU0sYUFBYSxrQkFBVyxPQUFPLDRCQUE0Qjs7QUFDakUsTUFBTSxVQUFVLGtCQUFXLE9BQU8saUNBQWlDOzs7QUFHbkUsTUFBTSxTQUFTLGtCQUFXLE9BQU8sNEJBQTRCOztBQUM3RCxNQUFNLGdCQUFnQixrQkFBVyxPQUFPLGtDQUFrQzs7QUFDMUUsTUFBTSxjQUFjLGtCQUFXLE9BQU8sZ0NBQWdDOzs7QUFHdEUsTUFBTSxVQUFVLGtCQUFXLE9BQU8sNkJBQTZCOztBQUMvRCxNQUFNLFFBQVEsa0JBQVcsT0FBTywyQkFBMkI7O0FBQzNELE1BQU0sWUFBWSxrQkFBVyxPQUFPLCtCQUErQjs7QUFDbkUsTUFBTSxXQUFXLGtCQUFXLE9BQU8sOEJBQThCOzs7QUFHakUsTUFBTSxNQUFNLGtCQUFXLE9BQU8sNkJBQTZCOztBQUMzRCxNQUFNLG1CQUFtQixrQkFDakIsT0FBTyx5Q0FDZjs7QUFDQSxNQUFNLFlBQVksa0JBQVcsT0FBTyxvQ0FBb0M7OztBQUd4RSxNQUFNLFdBQVcsa0JBQVcsT0FBTyw0QkFBNEI7O0FBQy9ELE1BQU0sV0FBVyxrQkFBVyxPQUFPLDRCQUE0Qjs7QUFDL0QsTUFBTSxXQUFXLGtCQUFXLE9BQU8sNEJBQTRCOztBQUMvRCxNQUFNLFVBQVUsa0JBQVcsT0FBTywyQkFBMkI7OztBQUc3RCxNQUFNLFlBQVksa0JBQVcsT0FBTyx3QkFBd0I7O0FBQzVELE1BQU0sYUFBYSxrQkFBVyxPQUFPLHlCQUF5Qjs7QUFDOUQsTUFBTSxRQUFRLGtCQUFXLE9BQU8sb0JBQW9COztBQUNwRCxNQUFNLFVBQVUsa0JBQVcsT0FBTyxzQkFBc0I7O0FBRXhELGVBQWUsU0FBUyxnQkFBZ0I7Q0FDdEMsT0FDRSx3QkFBQyxRQUFEO0VBQ0Usd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBWSxTQUFTLHdCQUFDLGFBQUQsRUFBYSxXQUFXLFVBQVk7Ozs7O0VBQUk7Ozs7O0VBQ3pFLHdCQUFDLE9BQUQ7R0FBTztHQUFNLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsVUFBWTs7Ozs7RUFBSTs7Ozs7RUFHOUQsd0JBQUMsT0FBRDtHQUFPLE1BQUs7YUFBWjtJQUNFLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVcsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxTQUFXOzs7OztJQUFJOzs7OztJQUN2RSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFVLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsUUFBVTs7Ozs7SUFBSTs7Ozs7SUFDckUsd0JBQUMsT0FBRDtLQUNFLE1BQUs7S0FDTCxTQUFTLHdCQUFDLGFBQUQsRUFBYSxXQUFXLFdBQWE7Ozs7O0lBQy9DOzs7OztJQUNELHdCQUFDLE9BQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxXQUFhOzs7OztJQUMvQzs7Ozs7R0FDSTs7Ozs7O0VBR1Asd0JBQUMsT0FBRDtHQUFPLE1BQUs7YUFBWjtJQUNFLHdCQUFDLE9BQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxZQUFjOzs7OztJQUNoRDs7Ozs7SUFDRCx3QkFBQyxPQUFEO0tBQ0UsTUFBSztLQUNMLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsY0FBZ0I7Ozs7O0lBQ2xEOzs7OztJQUNELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVUsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxPQUFTOzs7OztJQUFJOzs7OztHQUMvRDs7Ozs7O0VBR1Asd0JBQUMsT0FBRDtHQUFPLE1BQUs7YUFBWjtJQUNFLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVUsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxRQUFVOzs7OztJQUFJOzs7OztJQUNyRSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFRLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsTUFBUTs7Ozs7SUFBSTs7Ozs7SUFDakUsd0JBQUMsT0FBRDtLQUNFLE1BQUs7S0FDTCxTQUFTLHdCQUFDLGFBQUQsRUFBYSxXQUFXLFVBQVk7Ozs7O0lBQzlDOzs7OztJQUNELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVcsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxTQUFXOzs7OztJQUFJOzs7OztHQUNsRTs7Ozs7O0VBR1Asd0JBQUMsT0FBRDtHQUFPLE1BQUs7YUFBWjtJQUNFLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQU0sU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxJQUFNOzs7OztJQUFJOzs7OztJQUM3RCx3QkFBQyxPQUFEO0tBQ0UsTUFBSztLQUNMLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsaUJBQW1COzs7OztJQUNyRDs7Ozs7SUFDRCx3QkFBQyxPQUFEO0tBQ0UsTUFBSztLQUNMLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsVUFBWTs7Ozs7SUFDOUM7Ozs7O0dBQ0k7Ozs7OztFQUdQLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO2FBQVo7SUFDRSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFXLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsU0FBVzs7Ozs7SUFBSTs7Ozs7SUFDdkUsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBVyxTQUFTLHdCQUFDLGFBQUQsRUFBYSxXQUFXLFNBQVc7Ozs7O0lBQUk7Ozs7O0lBQ3ZFLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVcsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxTQUFXOzs7OztJQUFJOzs7OztJQUN2RSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFTLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsUUFBVTs7Ozs7SUFBSTs7Ozs7R0FDL0Q7Ozs7OztFQUdQLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO2FBQVo7SUFDRSx3QkFBQyxPQUFEO0tBQ0UsTUFBSztLQUNMLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsV0FBYTs7Ozs7SUFDL0M7Ozs7O0lBQ0Qsd0JBQUMsT0FBRDtLQUNFLE1BQUs7S0FDTCxTQUFTLHdCQUFDLGFBQUQsRUFBYSxXQUFXLFVBQVk7Ozs7O0lBQzlDOzs7OztJQUNELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVEsU0FBUyx3QkFBQyxhQUFELEVBQWEsV0FBVyxNQUFROzs7OztJQUFJOzs7OztJQUNqRSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFVLFNBQVMsd0JBQUMsYUFBRCxFQUFhLFdBQVcsUUFBVTs7Ozs7SUFBSTs7Ozs7R0FDaEU7Ozs7OztDQUNEOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInByaXZhdGVyb3V0ZXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBTdXNwZW5zZSwgbGF6eSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBSb3V0ZSwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlclwiO1xyXG5cclxuY29uc3Qgc3R5bGVzID0ge1xyXG4gIGxvYWRlcjoge1xyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICBoZWlnaHQ6IFwiODB2aFwiLFxyXG4gICAgZm9udFNpemU6IFwiMThweFwiLFxyXG4gICAgZm9udFdlaWdodDogXCI2MDBcIixcclxuICAgIGZvbnRGYW1pbHk6IFwic2Fucy1zZXJpZlwiLFxyXG4gICAgY29sb3I6IFwiIzAwMzM2NlwiLFxyXG4gIH0sXHJcbn07XHJcblxyXG5jb25zdCBEeW5hbWljUGFnZSA9ICh7IGNvbXBvbmVudDogQ29tcG9uZW50IH0pID0+IChcclxuICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxkaXYgc3R5bGU9e3N0eWxlcy5sb2FkZXJ9PlxyXG4gICAgXHJcbiAgPC9kaXY+fT5cclxuICAgIDxDb21wb25lbnQgLz5cclxuICA8L1N1c3BlbnNlPlxyXG4pO1xyXG5cclxuLy8gRGFzaGJvYXJkICYgTGF5b3V0XHJcbmNvbnN0IERhc2hib2FyZCA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvRGFzaGJvYXJkL0Rhc2hib2FyZFwiKSk7XHJcbmNvbnN0IExheW91dCA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvTGF5b3V0L0xheW91dFwiKSk7XHJcblxyXG4vLyBTYWxlcyBDb21wb25lbnRzXHJcbmNvbnN0IEN1c3RvbWVyID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9TYWxlcy9DdXN0b21lci9DdXN0b21lclwiKSk7XHJcbmNvbnN0IFF1b3RhdGlvbnMgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL1NhbGVzL1F1b3RhdGlvbi9RdW90YXRpb25zXCIpKTtcclxuY29uc3QgU2FsZXNvcmRlciA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvU2FsZXMvU2FsZXNvcmRlclwiKSk7XHJcbmNvbnN0IEludm9pY2UgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL1NhbGVzL2ludm9pY2UvSW52b2ljZVwiKSk7XHJcblxyXG4vLyBQdXJjaGFzZSBDb21wb25lbnRzXHJcbmNvbnN0IFZlbmRvciA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvUHVyY2hhc2UvVmVuZG9yc1wiKSk7XHJcbmNvbnN0IFB1cmNoYXNlb3JkZXIgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL1B1cmNoYXNlL1B1cmNoYXNlb3JkZXJcIikpO1xyXG5jb25zdCBHb29kcmVjZWlwdCA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvUHVyY2hhc2UvR29vZHJlY2VpcHRcIikpO1xyXG5cclxuLy8gSW52ZW50b3J5IENvbXBvbmVudHNcclxuY29uc3QgUHJvZHVjdCA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvSW52ZW50b3J5L1Byb2R1Y3RcIikpO1xyXG5jb25zdCBTdG9jayA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvSW52ZW50b3J5L1N0b2NrXCIpKTtcclxuY29uc3QgV2FyZWhvdXNlID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9JbnZlbnRvcnkvV2FyZWhvdXNlXCIpKTtcclxuY29uc3QgVHJhbnNmZXIgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL0ludmVudG9yeS9UcmFuc2ZlclwiKSk7XHJcblxyXG4vLyBNYW51ZmFjdHVyaW5nIENvbXBvbmVudHNcclxuY29uc3QgQm9tID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9NYW51ZmFjdHVyaW5nL0JPTVwiKSk7XHJcbmNvbnN0IFByb2R1Y3Rpb25vcmRlcnMgPSBsYXp5KFxyXG4gICgpID0+IGltcG9ydChcIi4uL1BhZ2VzL01hbnVmYWN0dXJpbmcvUHJvZHVjdGlvbm9yZGVyXCIpLFxyXG4pO1xyXG5jb25zdCBXb3Jrb3JkZXIgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL01hbnVmYWN0dXJpbmcvV29ya29yZGVyc1wiKSk7XHJcblxyXG4vLyBGaW5hbmNlIENvbXBvbmVudHNcclxuY29uc3QgQWNjb3VudHMgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL0ZpbmFuY2UvQWNjb3VudHNcIikpO1xyXG5jb25zdCBQYXltZW50cyA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvRmluYW5jZS9QYXltZW50c1wiKSk7XHJcbmNvbnN0IEV4cGVuc2VzID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9GaW5hbmNlL0V4cGVuc2VzXCIpKTtcclxuY29uc3QgUmVwb3J0cyA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvRmluYW5jZS9SZXBvcnRzXCIpKTtcclxuXHJcbi8vIEhSIENvbXBvbmVudHNcclxuY29uc3QgRW1wbG95ZWVzID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9IUi9FbXBsb3llc3NcIikpO1xyXG5jb25zdCBBdHRlbmRlbmNlID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuLi9QYWdlcy9IUi9BdHRlbmRlbmNlXCIpKTtcclxuY29uc3QgTGVhdmUgPSBsYXp5KCgpID0+IGltcG9ydChcIi4uL1BhZ2VzL0hSL0xlYXZlXCIpKTtcclxuY29uc3QgUGF5cm9sbCA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi4vUGFnZXMvSFIvUGF5cm9sbFwiKSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcml2YXRlUm91dGVyKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Um91dGVzPlxyXG4gICAgICA8Um91dGUgcGF0aD1cImRhc2hib2FyZFwiIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e0Rhc2hib2FyZH0gLz59IC8+XHJcbiAgICAgIDxSb3V0ZSBpbmRleCBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtEYXNoYm9hcmR9IC8+fSAvPlxyXG5cclxuICAgICAgey8qIFNhbGVzIEdyb3VwICovfVxyXG4gICAgICA8Um91dGUgcGF0aD1cInNhbGVzXCI+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJjdXN0b21lclwiIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e0N1c3RvbWVyfSAvPn0gLz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cImludm9pY2VcIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtJbnZvaWNlfSAvPn0gLz5cclxuICAgICAgICA8Um91dGVcclxuICAgICAgICAgIHBhdGg9XCJxdW90YXRpb25zXCJcclxuICAgICAgICAgIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e1F1b3RhdGlvbnN9IC8+fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICBwYXRoPVwic2FsZXNvcmRlclwiXHJcbiAgICAgICAgICBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtTYWxlc29yZGVyfSAvPn1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1JvdXRlPlxyXG5cclxuICAgICAgey8qIFB1cmNoYXNlIEdyb3VwICovfVxyXG4gICAgICA8Um91dGUgcGF0aD1cInB1cmNoYXNlXCI+XHJcbiAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICBwYXRoPVwiZ29vZCByZWNlaXB0XCJcclxuICAgICAgICAgIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e0dvb2RyZWNlaXB0fSAvPn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgcGF0aD1cInB1cmNoYXNlIG9yZGVyXCJcclxuICAgICAgICAgIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e1B1cmNoYXNlb3JkZXJ9IC8+fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJ2ZW5kb3JzXCIgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17VmVuZG9yfSAvPn0gLz5cclxuICAgICAgPC9Sb3V0ZT5cclxuXHJcbiAgICAgIHsvKiBJbnZlbnRvcnkgR3JvdXAgKi99XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiaW52ZW50b3J5XCI+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJwcm9kdWN0XCIgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17UHJvZHVjdH0gLz59IC8+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJzdG9ja1wiIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e1N0b2NrfSAvPn0gLz5cclxuICAgICAgICA8Um91dGVcclxuICAgICAgICAgIHBhdGg9XCJ3YXJlaG91c2VcIlxyXG4gICAgICAgICAgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17V2FyZWhvdXNlfSAvPn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwidHJhbnNmZXJcIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtUcmFuc2Zlcn0gLz59IC8+XHJcbiAgICAgIDwvUm91dGU+XHJcblxyXG4gICAgICB7LyogTWFudWZhY3R1cmluZyBHcm91cCAqL31cclxuICAgICAgPFJvdXRlIHBhdGg9XCJtYW51ZmFjdHVyaW5nXCI+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJCT01cIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtCb219IC8+fSAvPlxyXG4gICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgcGF0aD1cInByb2R1Y3Rpb25vcmRlclwiXHJcbiAgICAgICAgICBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtQcm9kdWN0aW9ub3JkZXJzfSAvPn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgcGF0aD1cIndvcmtvcmRlclwiXHJcbiAgICAgICAgICBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtXb3Jrb3JkZXJ9IC8+fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvUm91dGU+XHJcblxyXG4gICAgICB7LyogRmluYW5jZSBHcm91cCAqL31cclxuICAgICAgPFJvdXRlIHBhdGg9XCJmaW5hbmNlXCI+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJhY2NvdW50c1wiIGVsZW1lbnQ9ezxEeW5hbWljUGFnZSBjb21wb25lbnQ9e0FjY291bnRzfSAvPn0gLz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cImV4cGVuc2VzXCIgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17RXhwZW5zZXN9IC8+fSAvPlxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwicGF5bWVudHNcIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtQYXltZW50c30gLz59IC8+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJyZXBvdHNcIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtSZXBvcnRzfSAvPn0gLz5cclxuICAgICAgPC9Sb3V0ZT5cclxuXHJcbiAgICAgIHsvKiBIUiBHcm91cCAqL31cclxuICAgICAgPFJvdXRlIHBhdGg9XCJoclwiPlxyXG4gICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgcGF0aD1cImF0dGVuZGVuY2VcIlxyXG4gICAgICAgICAgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17QXR0ZW5kZW5jZX0gLz59XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8Um91dGVcclxuICAgICAgICAgIHBhdGg9XCJlbXBsb3llc3NcIlxyXG4gICAgICAgICAgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17RW1wbG95ZWVzfSAvPn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwibGVhdmVcIiBlbGVtZW50PXs8RHluYW1pY1BhZ2UgY29tcG9uZW50PXtMZWF2ZX0gLz59IC8+XHJcbiAgICAgICAgPFJvdXRlIHBhdGg9XCJwYXlyb2xsXCIgZWxlbWVudD17PER5bmFtaWNQYWdlIGNvbXBvbmVudD17UGF5cm9sbH0gLz59IC8+XHJcbiAgICAgIDwvUm91dGU+XHJcbiAgICA8L1JvdXRlcz5cclxuICApO1xyXG59XHJcbiJdfQ==