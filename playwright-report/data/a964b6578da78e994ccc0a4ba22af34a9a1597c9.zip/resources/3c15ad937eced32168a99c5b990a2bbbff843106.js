import { i as __toESM, t as __commonJSMin } from "/ERP-Project/node_modules/.vite/deps/rolldown-runtime-B4lejLz5.js?v=15f5f1b8";
import { t as require_react } from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { t as require_jsx_runtime } from "/ERP-Project/node_modules/.vite/deps/react_jsx-runtime.js?v=f54b3fc7";
import { n as clsx, t as require_react_is$2 } from "/ERP-Project/node_modules/.vite/deps/react-is-D18V6qXv.js?v=15f5f1b8";
import { t as _extends } from "/ERP-Project/node_modules/.vite/deps/extends-DrH2PCIy.js?v=15f5f1b8";
//#region node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js
/** @license React v16.13.1
* react-is.development.js
*
* Copyright (c) Facebook, Inc. and its affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_is_development$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		"use strict";
		var hasSymbol = typeof Symbol === "function" && Symbol.for;
		var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for("react.element") : 60103;
		var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for("react.portal") : 60106;
		var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for("react.fragment") : 60107;
		var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for("react.strict_mode") : 60108;
		var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for("react.profiler") : 60114;
		var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for("react.provider") : 60109;
		var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for("react.context") : 60110;
		var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for("react.async_mode") : 60111;
		var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for("react.concurrent_mode") : 60111;
		var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for("react.forward_ref") : 60112;
		var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for("react.suspense") : 60113;
		var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for("react.suspense_list") : 60120;
		var REACT_MEMO_TYPE = hasSymbol ? Symbol.for("react.memo") : 60115;
		var REACT_LAZY_TYPE = hasSymbol ? Symbol.for("react.lazy") : 60116;
		var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for("react.block") : 60121;
		var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for("react.fundamental") : 60117;
		var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for("react.responder") : 60118;
		var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for("react.scope") : 60119;
		function isValidElementType(type) {
			return typeof type === "string" || typeof type === "function" || type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
		}
		function typeOf(object) {
			if (typeof object === "object" && object !== null) {
				var $$typeof = object.$$typeof;
				switch ($$typeof) {
					case REACT_ELEMENT_TYPE:
						var type = object.type;
						switch (type) {
							case REACT_ASYNC_MODE_TYPE:
							case REACT_CONCURRENT_MODE_TYPE:
							case REACT_FRAGMENT_TYPE:
							case REACT_PROFILER_TYPE:
							case REACT_STRICT_MODE_TYPE:
							case REACT_SUSPENSE_TYPE: return type;
							default:
								var $$typeofType = type && type.$$typeof;
								switch ($$typeofType) {
									case REACT_CONTEXT_TYPE:
									case REACT_FORWARD_REF_TYPE:
									case REACT_LAZY_TYPE:
									case REACT_MEMO_TYPE:
									case REACT_PROVIDER_TYPE: return $$typeofType;
									default: return $$typeof;
								}
						}
					case REACT_PORTAL_TYPE: return $$typeof;
				}
			}
		}
		var AsyncMode = REACT_ASYNC_MODE_TYPE;
		var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
		var ContextConsumer = REACT_CONTEXT_TYPE;
		var ContextProvider = REACT_PROVIDER_TYPE;
		var Element = REACT_ELEMENT_TYPE;
		var ForwardRef = REACT_FORWARD_REF_TYPE;
		var Fragment = REACT_FRAGMENT_TYPE;
		var Lazy = REACT_LAZY_TYPE;
		var Memo = REACT_MEMO_TYPE;
		var Portal = REACT_PORTAL_TYPE;
		var Profiler = REACT_PROFILER_TYPE;
		var StrictMode = REACT_STRICT_MODE_TYPE;
		var Suspense = REACT_SUSPENSE_TYPE;
		var hasWarnedAboutDeprecatedIsAsyncMode = false;
		function isAsyncMode(object) {
			if (!hasWarnedAboutDeprecatedIsAsyncMode) {
				hasWarnedAboutDeprecatedIsAsyncMode = true;
				console["warn"]("The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API.");
			}
			return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
		}
		function isConcurrentMode(object) {
			return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
		}
		function isContextConsumer(object) {
			return typeOf(object) === REACT_CONTEXT_TYPE;
		}
		function isContextProvider(object) {
			return typeOf(object) === REACT_PROVIDER_TYPE;
		}
		function isElement(object) {
			return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
		}
		function isForwardRef(object) {
			return typeOf(object) === REACT_FORWARD_REF_TYPE;
		}
		function isFragment(object) {
			return typeOf(object) === REACT_FRAGMENT_TYPE;
		}
		function isLazy(object) {
			return typeOf(object) === REACT_LAZY_TYPE;
		}
		function isMemo(object) {
			return typeOf(object) === REACT_MEMO_TYPE;
		}
		function isPortal(object) {
			return typeOf(object) === REACT_PORTAL_TYPE;
		}
		function isProfiler(object) {
			return typeOf(object) === REACT_PROFILER_TYPE;
		}
		function isStrictMode(object) {
			return typeOf(object) === REACT_STRICT_MODE_TYPE;
		}
		function isSuspense(object) {
			return typeOf(object) === REACT_SUSPENSE_TYPE;
		}
		exports.AsyncMode = AsyncMode;
		exports.ConcurrentMode = ConcurrentMode;
		exports.ContextConsumer = ContextConsumer;
		exports.ContextProvider = ContextProvider;
		exports.Element = Element;
		exports.ForwardRef = ForwardRef;
		exports.Fragment = Fragment;
		exports.Lazy = Lazy;
		exports.Memo = Memo;
		exports.Portal = Portal;
		exports.Profiler = Profiler;
		exports.StrictMode = StrictMode;
		exports.Suspense = Suspense;
		exports.isAsyncMode = isAsyncMode;
		exports.isConcurrentMode = isConcurrentMode;
		exports.isContextConsumer = isContextConsumer;
		exports.isContextProvider = isContextProvider;
		exports.isElement = isElement;
		exports.isForwardRef = isForwardRef;
		exports.isFragment = isFragment;
		exports.isLazy = isLazy;
		exports.isMemo = isMemo;
		exports.isPortal = isPortal;
		exports.isProfiler = isProfiler;
		exports.isStrictMode = isStrictMode;
		exports.isSuspense = isSuspense;
		exports.isValidElementType = isValidElementType;
		exports.typeOf = typeOf;
	})();
}));
//#endregion
//#region node_modules/prop-types/node_modules/react-is/index.js
var require_react_is$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_is_development$1();
}));
//#endregion
//#region node_modules/object-assign/index.js
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
var require_object_assign = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var getOwnPropertySymbols = Object.getOwnPropertySymbols;
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	var propIsEnumerable = Object.prototype.propertyIsEnumerable;
	function toObject(val) {
		if (val === null || val === void 0) throw new TypeError("Object.assign cannot be called with null or undefined");
		return Object(val);
	}
	function shouldUseNative() {
		try {
			if (!Object.assign) return false;
			var test1 = /* @__PURE__ */ new String("abc");
			test1[5] = "de";
			if (Object.getOwnPropertyNames(test1)[0] === "5") return false;
			var test2 = {};
			for (var i = 0; i < 10; i++) test2["_" + String.fromCharCode(i)] = i;
			if (Object.getOwnPropertyNames(test2).map(function(n) {
				return test2[n];
			}).join("") !== "0123456789") return false;
			var test3 = {};
			"abcdefghijklmnopqrst".split("").forEach(function(letter) {
				test3[letter] = letter;
			});
			if (Object.keys(Object.assign({}, test3)).join("") !== "abcdefghijklmnopqrst") return false;
			return true;
		} catch (err) {
			return false;
		}
	}
	module.exports = shouldUseNative() ? Object.assign : function(target, source) {
		var from;
		var to = toObject(target);
		var symbols;
		for (var s = 1; s < arguments.length; s++) {
			from = Object(arguments[s]);
			for (var key in from) if (hasOwnProperty.call(from, key)) to[key] = from[key];
			if (getOwnPropertySymbols) {
				symbols = getOwnPropertySymbols(from);
				for (var i = 0; i < symbols.length; i++) if (propIsEnumerable.call(from, symbols[i])) to[symbols[i]] = from[symbols[i]];
			}
		}
		return to;
	};
}));
//#endregion
//#region node_modules/prop-types/lib/ReactPropTypesSecret.js
/**
* Copyright (c) 2013-present, Facebook, Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_ReactPropTypesSecret = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
}));
//#endregion
//#region node_modules/prop-types/lib/has.js
var require_has = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = Function.call.bind(Object.prototype.hasOwnProperty);
}));
//#endregion
//#region node_modules/prop-types/checkPropTypes.js
/**
* Copyright (c) 2013-present, Facebook, Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_checkPropTypes = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var printWarning = function() {};
	var ReactPropTypesSecret = require_ReactPropTypesSecret();
	var loggedTypeFailures = {};
	var has = require_has();
	printWarning = function(text) {
		var message = "Warning: " + text;
		if (typeof console !== "undefined") console.error(message);
		try {
			throw new Error(message);
		} catch (x) {}
	};
	/**
	* Assert that the values match with the type specs.
	* Error messages are memorized and will only be shown once.
	*
	* @param {object} typeSpecs Map of name to a ReactPropType
	* @param {object} values Runtime values that need to be type-checked
	* @param {string} location e.g. "prop", "context", "child context"
	* @param {string} componentName Name of the component for error messages.
	* @param {?Function} getStack Returns the component stack.
	* @private
	*/
	function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
		for (var typeSpecName in typeSpecs) if (has(typeSpecs, typeSpecName)) {
			var error;
			try {
				if (typeof typeSpecs[typeSpecName] !== "function") {
					var err = Error((componentName || "React class") + ": " + location + " type `" + typeSpecName + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof typeSpecs[typeSpecName] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
					err.name = "Invariant Violation";
					throw err;
				}
				error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
			} catch (ex) {
				error = ex;
			}
			if (error && !(error instanceof Error)) printWarning((componentName || "React class") + ": type specification of " + location + " `" + typeSpecName + "` is invalid; the type checker function must return `null` or an `Error` but returned a " + typeof error + ". You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).");
			if (error instanceof Error && !(error.message in loggedTypeFailures)) {
				loggedTypeFailures[error.message] = true;
				var stack = getStack ? getStack() : "";
				printWarning("Failed " + location + " type: " + error.message + (stack != null ? stack : ""));
			}
		}
	}
	/**
	* Resets warning cache when testing.
	*
	* @private
	*/
	checkPropTypes.resetWarningCache = function() {
		loggedTypeFailures = {};
	};
	module.exports = checkPropTypes;
}));
//#endregion
//#region node_modules/prop-types/factoryWithTypeCheckers.js
/**
* Copyright (c) 2013-present, Facebook, Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_factoryWithTypeCheckers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactIs = require_react_is$1();
	var assign = require_object_assign();
	var ReactPropTypesSecret = require_ReactPropTypesSecret();
	var has = require_has();
	var checkPropTypes = require_checkPropTypes();
	var printWarning = function() {};
	printWarning = function(text) {
		var message = "Warning: " + text;
		if (typeof console !== "undefined") console.error(message);
		try {
			throw new Error(message);
		} catch (x) {}
	};
	function emptyFunctionThatReturnsNull() {
		return null;
	}
	module.exports = function(isValidElement, throwOnDirectAccess) {
		var ITERATOR_SYMBOL = typeof Symbol === "function" && Symbol.iterator;
		var FAUX_ITERATOR_SYMBOL = "@@iterator";
		/**
		* Returns the iterator method function contained on the iterable object.
		*
		* Be sure to invoke the function with the iterable as context:
		*
		*     var iteratorFn = getIteratorFn(myIterable);
		*     if (iteratorFn) {
		*       var iterator = iteratorFn.call(myIterable);
		*       ...
		*     }
		*
		* @param {?object} maybeIterable
		* @return {?function}
		*/
		function getIteratorFn(maybeIterable) {
			var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
			if (typeof iteratorFn === "function") return iteratorFn;
		}
		/**
		* Collection of methods that allow declaration and validation of props that are
		* supplied to React components. Example usage:
		*
		*   var Props = require('ReactPropTypes');
		*   var MyArticle = React.createClass({
		*     propTypes: {
		*       // An optional string prop named "description".
		*       description: Props.string,
		*
		*       // A required enum prop named "category".
		*       category: Props.oneOf(['News','Photos']).isRequired,
		*
		*       // A prop named "dialog" that requires an instance of Dialog.
		*       dialog: Props.instanceOf(Dialog).isRequired
		*     },
		*     render: function() { ... }
		*   });
		*
		* A more formal specification of how these methods are used:
		*
		*   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
		*   decl := ReactPropTypes.{type}(.isRequired)?
		*
		* Each and every declaration produces a function with the same signature. This
		* allows the creation of custom validation functions. For example:
		*
		*  var MyLink = React.createClass({
		*    propTypes: {
		*      // An optional string or URI prop named "href".
		*      href: function(props, propName, componentName) {
		*        var propValue = props[propName];
		*        if (propValue != null && typeof propValue !== 'string' &&
		*            !(propValue instanceof URI)) {
		*          return new Error(
		*            'Expected a string or an URI for ' + propName + ' in ' +
		*            componentName
		*          );
		*        }
		*      }
		*    },
		*    render: function() {...}
		*  });
		*
		* @internal
		*/
		var ANONYMOUS = "<<anonymous>>";
		var ReactPropTypes = {
			array: createPrimitiveTypeChecker("array"),
			bigint: createPrimitiveTypeChecker("bigint"),
			bool: createPrimitiveTypeChecker("boolean"),
			func: createPrimitiveTypeChecker("function"),
			number: createPrimitiveTypeChecker("number"),
			object: createPrimitiveTypeChecker("object"),
			string: createPrimitiveTypeChecker("string"),
			symbol: createPrimitiveTypeChecker("symbol"),
			any: createAnyTypeChecker(),
			arrayOf: createArrayOfTypeChecker,
			element: createElementTypeChecker(),
			elementType: createElementTypeTypeChecker(),
			instanceOf: createInstanceTypeChecker,
			node: createNodeChecker(),
			objectOf: createObjectOfTypeChecker,
			oneOf: createEnumTypeChecker,
			oneOfType: createUnionTypeChecker,
			shape: createShapeTypeChecker,
			exact: createStrictShapeTypeChecker
		};
		/**
		* inlined Object.is polyfill to avoid requiring consumers ship their own
		* https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
		*/
		function is(x, y) {
			if (x === y) return x !== 0 || 1 / x === 1 / y;
			else return x !== x && y !== y;
		}
		/**
		* We use an Error-like object for backward compatibility as people may call
		* PropTypes directly and inspect their output. However, we don't use real
		* Errors anymore. We don't inspect their stack anyway, and creating them
		* is prohibitively expensive if they are created too often, such as what
		* happens in oneOfType() for any type before the one that matched.
		*/
		function PropTypeError(message, data) {
			this.message = message;
			this.data = data && typeof data === "object" ? data : {};
			this.stack = "";
		}
		PropTypeError.prototype = Error.prototype;
		function createChainableTypeChecker(validate) {
			var manualPropTypeCallCache = {};
			var manualPropTypeWarningCount = 0;
			function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
				componentName = componentName || ANONYMOUS;
				propFullName = propFullName || propName;
				if (secret !== ReactPropTypesSecret) {
					if (throwOnDirectAccess) {
						var err = /* @__PURE__ */ new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
						err.name = "Invariant Violation";
						throw err;
					} else if (typeof console !== "undefined") {
						var cacheKey = componentName + ":" + propName;
						if (!manualPropTypeCallCache[cacheKey] && manualPropTypeWarningCount < 3) {
							printWarning("You are manually calling a React.PropTypes validation function for the `" + propFullName + "` prop on `" + componentName + "`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.");
							manualPropTypeCallCache[cacheKey] = true;
							manualPropTypeWarningCount++;
						}
					}
				}
				if (props[propName] == null) {
					if (isRequired) {
						if (props[propName] === null) return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required " + ("in `" + componentName + "`, but its value is `null`."));
						return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required in " + ("`" + componentName + "`, but its value is `undefined`."));
					}
					return null;
				} else return validate(props, propName, componentName, location, propFullName);
			}
			var chainedCheckType = checkType.bind(null, false);
			chainedCheckType.isRequired = checkType.bind(null, true);
			return chainedCheckType;
		}
		function createPrimitiveTypeChecker(expectedType) {
			function validate(props, propName, componentName, location, propFullName, secret) {
				var propValue = props[propName];
				if (getPropType(propValue) !== expectedType) {
					var preciseType = getPreciseType(propValue);
					return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + preciseType + "` supplied to `" + componentName + "`, expected ") + ("`" + expectedType + "`."), { expectedType });
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createAnyTypeChecker() {
			return createChainableTypeChecker(emptyFunctionThatReturnsNull);
		}
		function createArrayOfTypeChecker(typeChecker) {
			function validate(props, propName, componentName, location, propFullName) {
				if (typeof typeChecker !== "function") return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside arrayOf.");
				var propValue = props[propName];
				if (!Array.isArray(propValue)) {
					var propType = getPropType(propValue);
					return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an array."));
				}
				for (var i = 0; i < propValue.length; i++) {
					var error = typeChecker(propValue, i, componentName, location, propFullName + "[" + i + "]", ReactPropTypesSecret);
					if (error instanceof Error) return error;
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createElementTypeChecker() {
			function validate(props, propName, componentName, location, propFullName) {
				var propValue = props[propName];
				if (!isValidElement(propValue)) {
					var propType = getPropType(propValue);
					return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement."));
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createElementTypeTypeChecker() {
			function validate(props, propName, componentName, location, propFullName) {
				var propValue = props[propName];
				if (!ReactIs.isValidElementType(propValue)) {
					var propType = getPropType(propValue);
					return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement type."));
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createInstanceTypeChecker(expectedClass) {
			function validate(props, propName, componentName, location, propFullName) {
				if (!(props[propName] instanceof expectedClass)) {
					var expectedClassName = expectedClass.name || ANONYMOUS;
					var actualClassName = getClassName(props[propName]);
					return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + actualClassName + "` supplied to `" + componentName + "`, expected ") + ("instance of `" + expectedClassName + "`."));
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createEnumTypeChecker(expectedValues) {
			if (!Array.isArray(expectedValues)) {
				if (arguments.length > 1) printWarning("Invalid arguments supplied to oneOf, expected an array, got " + arguments.length + " arguments. A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).");
				else printWarning("Invalid argument supplied to oneOf, expected an array.");
				return emptyFunctionThatReturnsNull;
			}
			function validate(props, propName, componentName, location, propFullName) {
				var propValue = props[propName];
				for (var i = 0; i < expectedValues.length; i++) if (is(propValue, expectedValues[i])) return null;
				var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
					if (getPreciseType(value) === "symbol") return String(value);
					return value;
				});
				return new PropTypeError("Invalid " + location + " `" + propFullName + "` of value `" + String(propValue) + "` " + ("supplied to `" + componentName + "`, expected one of " + valuesString + "."));
			}
			return createChainableTypeChecker(validate);
		}
		function createObjectOfTypeChecker(typeChecker) {
			function validate(props, propName, componentName, location, propFullName) {
				if (typeof typeChecker !== "function") return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside objectOf.");
				var propValue = props[propName];
				var propType = getPropType(propValue);
				if (propType !== "object") return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an object."));
				for (var key in propValue) if (has(propValue, key)) {
					var error = typeChecker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
					if (error instanceof Error) return error;
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createUnionTypeChecker(arrayOfTypeCheckers) {
			if (!Array.isArray(arrayOfTypeCheckers)) {
				printWarning("Invalid argument supplied to oneOfType, expected an instance of array.");
				return emptyFunctionThatReturnsNull;
			}
			for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
				var checker = arrayOfTypeCheckers[i];
				if (typeof checker !== "function") {
					printWarning("Invalid argument supplied to oneOfType. Expected an array of check functions, but received " + getPostfixForTypeWarning(checker) + " at index " + i + ".");
					return emptyFunctionThatReturnsNull;
				}
			}
			function validate(props, propName, componentName, location, propFullName) {
				var expectedTypes = [];
				for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
					var checker = arrayOfTypeCheckers[i];
					var checkerResult = checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
					if (checkerResult == null) return null;
					if (checkerResult.data && has(checkerResult.data, "expectedType")) expectedTypes.push(checkerResult.data.expectedType);
				}
				var expectedTypesMessage = expectedTypes.length > 0 ? ", expected one of type [" + expectedTypes.join(", ") + "]" : "";
				return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`" + expectedTypesMessage + "."));
			}
			return createChainableTypeChecker(validate);
		}
		function createNodeChecker() {
			function validate(props, propName, componentName, location, propFullName) {
				if (!isNode(props[propName])) return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`, expected a ReactNode."));
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function invalidValidatorError(componentName, location, propFullName, key, type) {
			return new PropTypeError((componentName || "React class") + ": " + location + " type `" + propFullName + "." + key + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + type + "`.");
		}
		function createShapeTypeChecker(shapeTypes) {
			function validate(props, propName, componentName, location, propFullName) {
				var propValue = props[propName];
				var propType = getPropType(propValue);
				if (propType !== "object") return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
				for (var key in shapeTypes) {
					var checker = shapeTypes[key];
					if (typeof checker !== "function") return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
					var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
					if (error) return error;
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function createStrictShapeTypeChecker(shapeTypes) {
			function validate(props, propName, componentName, location, propFullName) {
				var propValue = props[propName];
				var propType = getPropType(propValue);
				if (propType !== "object") return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
				for (var key in assign({}, props[propName], shapeTypes)) {
					var checker = shapeTypes[key];
					if (has(shapeTypes, key) && typeof checker !== "function") return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
					if (!checker) return new PropTypeError("Invalid " + location + " `" + propFullName + "` key `" + key + "` supplied to `" + componentName + "`.\nBad object: " + JSON.stringify(props[propName], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(shapeTypes), null, "  "));
					var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
					if (error) return error;
				}
				return null;
			}
			return createChainableTypeChecker(validate);
		}
		function isNode(propValue) {
			switch (typeof propValue) {
				case "number":
				case "string":
				case "undefined": return true;
				case "boolean": return !propValue;
				case "object":
					if (Array.isArray(propValue)) return propValue.every(isNode);
					if (propValue === null || isValidElement(propValue)) return true;
					var iteratorFn = getIteratorFn(propValue);
					if (iteratorFn) {
						var iterator = iteratorFn.call(propValue);
						var step;
						if (iteratorFn !== propValue.entries) {
							while (!(step = iterator.next()).done) if (!isNode(step.value)) return false;
						} else while (!(step = iterator.next()).done) {
							var entry = step.value;
							if (entry) {
								if (!isNode(entry[1])) return false;
							}
						}
					} else return false;
					return true;
				default: return false;
			}
		}
		function isSymbol(propType, propValue) {
			if (propType === "symbol") return true;
			if (!propValue) return false;
			if (propValue["@@toStringTag"] === "Symbol") return true;
			if (typeof Symbol === "function" && propValue instanceof Symbol) return true;
			return false;
		}
		function getPropType(propValue) {
			var propType = typeof propValue;
			if (Array.isArray(propValue)) return "array";
			if (propValue instanceof RegExp) return "object";
			if (isSymbol(propType, propValue)) return "symbol";
			return propType;
		}
		function getPreciseType(propValue) {
			if (typeof propValue === "undefined" || propValue === null) return "" + propValue;
			var propType = getPropType(propValue);
			if (propType === "object") {
				if (propValue instanceof Date) return "date";
				else if (propValue instanceof RegExp) return "regexp";
			}
			return propType;
		}
		function getPostfixForTypeWarning(value) {
			var type = getPreciseType(value);
			switch (type) {
				case "array":
				case "object": return "an " + type;
				case "boolean":
				case "date":
				case "regexp": return "a " + type;
				default: return type;
			}
		}
		function getClassName(propValue) {
			if (!propValue.constructor || !propValue.constructor.name) return ANONYMOUS;
			return propValue.constructor.name;
		}
		ReactPropTypes.checkPropTypes = checkPropTypes;
		ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
		ReactPropTypes.PropTypes = ReactPropTypes;
		return ReactPropTypes;
	};
}));
//#endregion
//#region node_modules/prop-types/index.js
var require_prop_types = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var ReactIs = require_react_is$1();
	module.exports = require_factoryWithTypeCheckers()(ReactIs.isElement, true);
}));
//#endregion
//#region node_modules/@mui/utils/composeClasses/composeClasses.mjs
/**
* Compose classes from multiple sources.
*
* @example
* ```tsx
* const slots = {
*  root: ['root', 'primary'],
*  label: ['label'],
* };
*
* const getUtilityClass = (slot) => `MuiButton-${slot}`;
*
* const classes = {
*   root: 'my-root-class',
* };
*
* const output = composeClasses(slots, getUtilityClass, classes);
* // {
* //   root: 'MuiButton-root MuiButton-primary my-root-class',
* //   label: 'MuiButton-label',
* // }
* ```
*
* @param slots a list of classes for each possible slot
* @param getUtilityClass a function to resolve the class based on the slot name
* @param classes the input classes from props
* @returns the resolved classes for all slots
*/
function composeClasses(slots, getUtilityClass, classes = void 0) {
	const output = {};
	for (const slotName in slots) {
		const slot = slots[slotName];
		let buffer = "";
		let start = true;
		for (let i = 0; i < slot.length; i += 1) {
			const value = slot[i];
			if (value) {
				buffer += (start === true ? "" : " ") + getUtilityClass(value);
				start = false;
				if (classes && classes[value]) buffer += " " + classes[value];
			}
		}
		output[slotName] = buffer;
	}
	return output;
}
//#endregion
//#region node_modules/@mui/utils/capitalize/capitalize.mjs
function capitalize(string) {
	if (typeof string !== "string") throw new Error("MUI: `capitalize(string)` expects a string argument.");
	return string.charAt(0).toUpperCase() + string.slice(1);
}
//#endregion
//#region node_modules/@mui/material/utils/capitalize.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var import_prop_types = /* @__PURE__ */ __toESM(require_prop_types(), 1);
var capitalize_default = capitalize;
//#endregion
//#region node_modules/@mui/utils/fastDeepAssign/fastDeepAssign.mjs
/**
* Assigns props from one object to another. Focused on performance, only normal objects with no
* prototype are supported.
*/
function fastDeepAssign(target, source) {
	const sourceIsArray = Array.isArray(source);
	const targetIsArray = Array.isArray(target);
	if (isPrimitive(source)) return source;
	else if (isPrimitiveOrBuiltIn(target)) return clone(source);
	else if (sourceIsArray && targetIsArray) return mergeArray(target, source);
	else if (sourceIsArray !== targetIsArray) return clone(source);
	else return mergeObject(target, source);
}
function cloneArray(value) {
	let i = 0;
	const il = value.length;
	const result = new Array(il);
	for (i = 0; i < il; i += 1) result[i] = clone(value[i]);
	return result;
}
function cloneObject(target) {
	const result = {};
	for (const key in target) {
		if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
		result[key] = clone(target[key]);
	}
	return result;
}
function mergeArray(target, source) {
	const tl = target.length;
	for (let i = 0; i < source.length; i += 1) target[tl + i] = clone(source[i]);
	return target;
}
function isMergeableObject(value) {
	return typeof value === "object" && value !== null && !(value instanceof RegExp) && !(value instanceof Date);
}
function isPrimitive(value) {
	return typeof value !== "object" || value === null;
}
function isPrimitiveOrBuiltIn(value) {
	return typeof value !== "object" || value === null || value instanceof RegExp || value instanceof Date;
}
function clone(entry) {
	return isMergeableObject(entry) ? Array.isArray(entry) ? cloneArray(entry) : cloneObject(entry) : entry;
}
function mergeObject(target, source) {
	for (const key in source) {
		if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
		if (key in target) target[key] = fastDeepAssign(target[key], source[key]);
		else target[key] = clone(source[key]);
	}
	return target;
}
//#endregion
//#region node_modules/@mui/system/responsivePropType/responsivePropType.mjs
var responsivePropType = import_prop_types.default.oneOfType([
	import_prop_types.default.number,
	import_prop_types.default.string,
	import_prop_types.default.object,
	import_prop_types.default.array
]);
//#endregion
//#region node_modules/@mui/utils/isObjectEmpty/isObjectEmpty.mjs
function isObjectEmpty(object) {
	if (object == null) return true;
	for (const _ in object) return false;
	return true;
}
//#endregion
//#region node_modules/@mui/utils/deepmerge/deepmerge.mjs
var import_react_is = require_react_is$2();
function isPlainObject(item) {
	if (typeof item !== "object" || item === null) return false;
	const prototype = Object.getPrototypeOf(item);
	return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in item) && !(Symbol.iterator in item);
}
function deepClone(source) {
	if (/*#__PURE__*/ import_react.isValidElement(source) || (0, import_react_is.isValidElementType)(source) || !isPlainObject(source)) return source;
	const output = {};
	Object.keys(source).forEach((key) => {
		output[key] = deepClone(source[key]);
	});
	return output;
}
/**
* Merge objects deeply.
* It will shallow copy React elements.
*
* If `options.clone` is set to `false` the source object will be merged directly into the target object.
*
* @example
* ```ts
* deepmerge({ a: { b: 1 }, d: 2 }, { a: { c: 2 }, d: 4 });
* // => { a: { b: 1, c: 2 }, d: 4 }
* ````
*
* @param target The target object.
* @param source The source object.
* @param options The merge options.
* @param options.clone Set to `false` to merge the source object directly into the target object.
* @returns The merged object.
*/
function deepmerge(target, source, options = { clone: true }) {
	const output = options.clone ? { ...target } : target;
	if (isPlainObject(target) && isPlainObject(source)) Object.keys(source).forEach((key) => {
		if (/*#__PURE__*/ import_react.isValidElement(source[key]) || (0, import_react_is.isValidElementType)(source[key])) output[key] = source[key];
		else if (isPlainObject(source[key]) && Object.prototype.hasOwnProperty.call(target, key) && isPlainObject(target[key])) output[key] = deepmerge(target[key], source[key], options);
		else if (options.clone) output[key] = isPlainObject(source[key]) ? deepClone(source[key]) : source[key];
		else output[key] = source[key];
	});
	return output;
}
//#endregion
//#region node_modules/@mui/system/cssContainerQueries/cssContainerQueries.mjs
var MIN_WIDTH_PATTERN = /min-width:\s*([0-9.]+)/;
/**
* WARN: Mutably updates the `css` object.
* For using in `sx` prop to sort the breakpoint from low to high.
* Note: this function does not work and will not support multiple units.
*       e.g. input: { '@container (min-width:300px)': '1rem', '@container (min-width:40rem)': '2rem' }
*            output: { '@container (min-width:40rem)': '2rem', '@container (min-width:300px)': '1rem' } // since 40 < 300 even though 40rem > 300px
*/
function sortContainerQueries(theme, css) {
	if (!theme.containerQueries || !hasContainerQuery(css)) return css;
	const keys = [];
	for (const key in css) if (key.startsWith("@container")) keys.push(key);
	keys.sort((a, b) => {
		return +(a.match(MIN_WIDTH_PATTERN)?.[1] || 0) - +(b.match(MIN_WIDTH_PATTERN)?.[1] || 0);
	});
	const result = css;
	for (let i = 0; i < keys.length; i += 1) {
		const key = keys[i];
		const value = result[key];
		delete result[key];
		result[key] = value;
	}
	return result;
}
function hasContainerQuery(css) {
	for (const key in css) if (key.startsWith("@container")) return true;
	return false;
}
function isCqShorthand(breakpointKeys, value) {
	return value === "@" || value.startsWith("@") && (breakpointKeys.some((key) => value.startsWith(`@${key}`)) || !!value.match(/^@\d/));
}
function getContainerQuery(theme, shorthand) {
	const matches = shorthand.match(/^@([^/]+)?\/?(.+)?$/);
	if (!matches) throw new Error(`MUI: The provided shorthand ${`(${shorthand})`} is invalid. The format should be \`@<breakpoint | number>\` or \`@<breakpoint | number>/<container>\`.\nFor example, \`@sm\` or \`@600\` or \`@40rem/sidebar\`.`);
	const [, containerQuery, containerName] = matches;
	const value = Number.isNaN(+containerQuery) ? containerQuery || 0 : +containerQuery;
	return theme.containerQueries(containerName).up(value);
}
function cssContainerQueries(themeInput) {
	const toContainerQuery = (mediaQuery, name) => mediaQuery.replace("@media", name ? `@container ${name}` : "@container");
	function attachCq(node, name) {
		node.up = (...args) => toContainerQuery(themeInput.breakpoints.up(...args), name);
		node.down = (...args) => toContainerQuery(themeInput.breakpoints.down(...args), name);
		node.between = (...args) => toContainerQuery(themeInput.breakpoints.between(...args), name);
		node.only = (...args) => toContainerQuery(themeInput.breakpoints.only(...args), name);
		node.not = (...args) => {
			const result = toContainerQuery(themeInput.breakpoints.not(...args), name);
			if (result.includes("not all and")) return result.replace("not all and ", "").replace("min-width:", "width<").replace("max-width:", "width>").replace("and", "or");
			return result;
		};
	}
	const node = {};
	const containerQueries = (name) => {
		attachCq(node, name);
		return node;
	};
	attachCq(containerQueries);
	return {
		...themeInput,
		containerQueries
	};
}
//#endregion
//#region node_modules/@mui/system/createBreakpoints/createBreakpoints.mjs
var sortBreakpointsValues = (values) => {
	const breakpointsAsArray = Object.keys(values).map((key) => ({
		key,
		val: values[key]
	})) || [];
	breakpointsAsArray.sort((breakpoint1, breakpoint2) => breakpoint1.val - breakpoint2.val);
	return breakpointsAsArray.reduce((acc, obj) => {
		return {
			...acc,
			[obj.key]: obj.val
		};
	}, {});
};
function createBreakpoints(breakpoints) {
	const { values = {
		xs: 0,
		sm: 600,
		md: 900,
		lg: 1200,
		xl: 1536
	}, unit = "px", step = 5, ...other } = breakpoints;
	const sortedValues = sortBreakpointsValues(values);
	const keys = Object.keys(sortedValues);
	function up(key) {
		return `@media (min-width:${typeof values[key] === "number" ? values[key] : key}${unit})`;
	}
	function down(key) {
		return `@media (max-width:${(typeof values[key] === "number" ? values[key] : key) - step / 100}${unit})`;
	}
	function between(start, end) {
		const endIndex = keys.indexOf(end);
		return `@media (min-width:${typeof values[start] === "number" ? values[start] : start}${unit}) and (max-width:${(endIndex !== -1 && typeof values[keys[endIndex]] === "number" ? values[keys[endIndex]] : end) - step / 100}${unit})`;
	}
	function only(key) {
		if (keys.indexOf(key) + 1 < keys.length) return between(key, keys[keys.indexOf(key) + 1]);
		return up(key);
	}
	function not(key) {
		const keyIndex = keys.indexOf(key);
		if (keyIndex === 0) return up(keys[1]);
		if (keyIndex === keys.length - 1) return down(keys[keyIndex]);
		return between(key, keys[keys.indexOf(key) + 1]).replace("@media", "@media not all and");
	}
	const mediaKeys = [];
	for (let i = 0; i < keys.length; i += 1) mediaKeys.push(up(keys[i]));
	return {
		keys,
		values: sortedValues,
		up,
		down,
		between,
		only,
		not,
		unit,
		internal_mediaKeys: mediaKeys,
		...other
	};
}
//#endregion
//#region node_modules/@mui/system/breakpoints/breakpoints.mjs
var EMPTY_THEME$2 = {};
/** @internal */
var values = {
	xs: 0,
	sm: 600,
	md: 900,
	lg: 1200,
	xl: 1536
};
var DEFAULT_BREAKPOINTS = createBreakpoints({ values });
var defaultContainerQueries = { containerQueries: (containerName) => ({ up: (key) => {
	let result = typeof key === "number" ? key : values[key] || key;
	if (typeof result === "number") result = `${result}px`;
	return containerName ? `@container ${containerName} (min-width:${result})` : `@container (min-width:${result})`;
} }) };
function handleBreakpoints(props, propValue, styleFromPropValue) {
	const result = {};
	return iterateBreakpoints(result, props.theme, propValue, (mediaKey, value, initialKey) => {
		const finalValue = styleFromPropValue(value, initialKey);
		if (mediaKey) result[mediaKey] = finalValue;
		else fastDeepAssign(result, finalValue);
	});
}
function iterateBreakpoints(target, theme, propValue, callback) {
	theme ??= EMPTY_THEME$2;
	if (Array.isArray(propValue)) {
		const breakpoints = theme.breakpoints ?? DEFAULT_BREAKPOINTS;
		for (let i = 0; i < propValue.length; i += 1) buildBreakpoint(target, breakpoints.up(breakpoints.keys[i]), propValue[i], void 0, callback);
		return target;
	}
	if (typeof propValue === "object") {
		const breakpoints = theme.breakpoints ?? DEFAULT_BREAKPOINTS;
		const breakpointValues = breakpoints.values ?? values;
		for (const key in propValue) if (isCqShorthand(breakpoints.keys, key)) {
			const containerKey = getContainerQuery(theme.containerQueries ? theme : defaultContainerQueries, key);
			if (containerKey) buildBreakpoint(target, containerKey, propValue[key], key, callback);
		} else if (key in breakpointValues) buildBreakpoint(target, breakpoints.up(key), propValue[key], key, callback);
		else {
			const cssKey = key;
			target[cssKey] = propValue[cssKey];
		}
		return target;
	}
	callback(void 0, propValue);
	return target;
}
function buildBreakpoint(target, mediaKey, value, initialKey, callback) {
	target[mediaKey] ??= {};
	callback(mediaKey, value, initialKey);
}
/** @internal */
function createEmptyBreakpointObject(breakpoints = DEFAULT_BREAKPOINTS) {
	const { internal_mediaKeys: mediaKeys } = breakpoints;
	const result = {};
	for (let i = 0; i < mediaKeys.length; i += 1) result[mediaKeys[i]] = {};
	return result;
}
/** @internal */
function removeUnusedBreakpoints(breakpoints, style) {
	const breakpointKeys = breakpoints.internal_mediaKeys;
	for (let i = 0; i < breakpointKeys.length; i += 1) {
		const key = breakpointKeys[i];
		if (isObjectEmpty(style[key])) delete style[key];
	}
	return style;
}
function mergeBreakpointsInOrder(breakpoints, ...styles) {
	return removeUnusedBreakpoints(breakpoints, [createEmptyBreakpointObject(breakpoints), ...styles].reduce((prev, next) => deepmerge(prev, next), {}));
}
/** @internal */
function computeBreakpointsBase(breakpointValues, themeBreakpoints) {
	if (typeof breakpointValues !== "object") return {};
	const base = {};
	const breakpointsKeys = Object.keys(themeBreakpoints);
	if (Array.isArray(breakpointValues)) breakpointsKeys.forEach((breakpoint, i) => {
		if (i < breakpointValues.length) base[breakpoint] = true;
	});
	else breakpointsKeys.forEach((breakpoint) => {
		if (breakpointValues[breakpoint] != null) base[breakpoint] = true;
	});
	return base;
}
function resolveBreakpointValues(options) {
	const { values: breakpointValues, breakpoints: themeBreakpoints, base: customBase } = options;
	const base = customBase || computeBreakpointsBase(breakpointValues, themeBreakpoints);
	const keys = Object.keys(base);
	if (keys.length === 0) return breakpointValues;
	let previous;
	return keys.reduce((acc, breakpoint, i) => {
		if (Array.isArray(breakpointValues)) {
			acc[breakpoint] = breakpointValues[i] != null ? breakpointValues[i] : breakpointValues[previous];
			previous = i;
		} else if (typeof breakpointValues === "object" && breakpointValues) {
			const bv = breakpointValues;
			acc[breakpoint] = bv[breakpoint] != null ? bv[breakpoint] : bv[previous];
			previous = breakpoint;
		} else acc[breakpoint] = breakpointValues;
		return acc;
	}, {});
}
function hasBreakpoint(breakpoints, value) {
	if (Array.isArray(value)) return true;
	if (typeof value === "object" && value !== null) {
		for (let i = 0; i < breakpoints.keys.length; i += 1) if (breakpoints.keys[i] in value) return true;
		const valueKeys = Object.keys(value);
		for (let i = 0; i < valueKeys.length; i += 1) if (isCqShorthand(breakpoints.keys, valueKeys[i])) return true;
	}
	return false;
}
//#endregion
//#region node_modules/@mui/system/style/style.mjs
/**
* HACK: The `alternateProp` logic is there because our theme looks like this:
* {
*   typography: {
*     fontFamily: 'comic sans',
*     fontFamilyCode: 'courrier new',
*   }
* }
* And we support targetting:
* - `typography.fontFamily`     with `sx={{ fontFamily: 'default' }}`
* - `typography.fontFamilyCode` with `sx={{ fontFamily: 'code' }}`
*
* TODO(v7): Refactor our theme to look like this and remove the horrendous logic:
* {
*   typography: {
*     fontFamily: {
*       default: 'comic sans',
*       code: 'courrier new',
*     }
*   }
* }
*/
function getStyleValue2(themeMapping, transform, userValue, alternateProp) {
	let value;
	if (typeof themeMapping === "function") value = themeMapping(userValue);
	else if (Array.isArray(themeMapping)) value = themeMapping[userValue] || userValue;
	else if (typeof userValue === "string") value = getPath(themeMapping, userValue, true, alternateProp) || userValue;
	else value = userValue;
	if (transform) value = transform(value, userValue, themeMapping);
	return value;
}
function getPath(obj, pathInput, checkVars = true, alternateProp = void 0) {
	if (!obj || !pathInput) return null;
	const path = pathInput.split(".");
	if (obj.vars && checkVars) {
		const val = getPathImpl(obj.vars, path, alternateProp);
		if (val != null) return val;
	}
	return getPathImpl(obj, path, alternateProp);
}
function getPathImpl(object, path, alternateProp = void 0) {
	let lastResult = void 0;
	let result = object;
	let index = 0;
	while (index < path.length) {
		if (result === null || result === void 0) return result;
		lastResult = result;
		result = result[path[index]];
		index += 1;
	}
	if (alternateProp && result === void 0) {
		const lastKey = path[path.length - 1];
		const alternateKey = `${alternateProp}${lastKey === "default" ? "" : capitalize(lastKey)}`;
		return lastResult?.[alternateKey];
	}
	return result;
}
function style$1(options) {
	const { prop, cssProperty = options.prop, themeKey, transform } = options;
	const fn = (props) => {
		if (props[prop] == null) return null;
		const propValue = props[prop];
		const theme = props.theme;
		const themeMapping = getPath(theme, themeKey) || {};
		const styleFromPropValue = (valueFinal) => {
			const value = getStyleValue2(themeMapping, transform, valueFinal, prop);
			return cssProperty === false ? value : { [cssProperty]: value };
		};
		return handleBreakpoints(props, propValue, styleFromPropValue);
	};
	fn.propTypes = { [prop]: responsivePropType };
	fn.filterProps = [prop];
	return fn;
}
//#endregion
//#region node_modules/@mui/system/spacing/spacing.mjs
var EMPTY_THEME$1 = { internal_cache: {} };
var properties = {
	m: "margin",
	p: "padding"
};
var directions = {
	t: "Top",
	r: "Right",
	b: "Bottom",
	l: "Left",
	x: ["Left", "Right"],
	y: ["Top", "Bottom"]
};
var aliases = {
	marginX: "mx",
	marginY: "my",
	paddingX: "px",
	paddingY: "py"
};
var CSS_PROPERTIES = {};
for (const key in properties) CSS_PROPERTIES[key] = [properties[key]];
for (const keyProperty in properties) for (const keyDirection in directions) {
	const property = properties[keyProperty];
	const direction = directions[keyDirection];
	const value = Array.isArray(direction) ? direction.map((dir) => property + dir) : [property + direction];
	CSS_PROPERTIES[keyProperty + keyDirection] = value;
}
for (const key in aliases) CSS_PROPERTIES[key] = CSS_PROPERTIES[aliases[key]];
/** @internal */
var marginKeys = /* @__PURE__ */ new Set([
	"m",
	"mt",
	"mr",
	"mb",
	"ml",
	"mx",
	"my",
	"margin",
	"marginTop",
	"marginRight",
	"marginBottom",
	"marginLeft",
	"marginX",
	"marginY",
	"marginInline",
	"marginInlineStart",
	"marginInlineEnd",
	"marginBlock",
	"marginBlockStart",
	"marginBlockEnd"
]);
/** @internal */
var paddingKeys = /* @__PURE__ */ new Set([
	"p",
	"pt",
	"pr",
	"pb",
	"pl",
	"px",
	"py",
	"padding",
	"paddingTop",
	"paddingRight",
	"paddingBottom",
	"paddingLeft",
	"paddingX",
	"paddingY",
	"paddingInline",
	"paddingInlineStart",
	"paddingInlineEnd",
	"paddingBlock",
	"paddingBlockStart",
	"paddingBlockEnd"
]);
var spacingKeys = /* @__PURE__ */ new Set([...marginKeys, ...paddingKeys]);
function createUnaryUnit(theme, themeKey, defaultValue, propName) {
	const themeSpacing = getPath(theme, themeKey, true) ?? defaultValue;
	if (typeof themeSpacing === "number" || typeof themeSpacing === "string") return (val) => {
		if (typeof val === "string") return val;
		if (typeof val !== "number") console.error(`MUI: Expected ${propName} argument to be a number or a string, got ${val}.`);
		if (typeof themeSpacing === "string") {
			if (themeSpacing.startsWith("var(") && val === 0) return 0;
			if (themeSpacing.startsWith("var(") && val === 1) return themeSpacing;
			return `calc(${val} * ${themeSpacing})`;
		}
		return themeSpacing * val;
	};
	if (Array.isArray(themeSpacing)) return (val) => {
		if (typeof val === "string") return val;
		const abs = Math.abs(val);
		if (!Number.isInteger(abs)) console.error([`MUI: The \`theme.${themeKey}\` array type cannot be combined with non integer values.You should either use an integer value that can be used as index, or define the \`theme.${themeKey}\` as a number.`].join("\n"));
		else if (abs > themeSpacing.length - 1) console.error([
			`MUI: The value provided (${abs}) overflows.`,
			`The supported values are: ${JSON.stringify(themeSpacing)}.`,
			`${abs} > ${themeSpacing.length - 1}, you need to add the missing values.`
		].join("\n"));
		const transformed = themeSpacing[abs];
		if (val >= 0) return transformed;
		if (typeof transformed === "number") return -transformed;
		if (typeof transformed === "string" && transformed.startsWith("var(")) return `calc(-1 * ${transformed})`;
		return `-${transformed}`;
	};
	if (typeof themeSpacing === "function") return themeSpacing;
	console.error([`MUI: The \`theme.${themeKey}\` value (${themeSpacing}) is invalid.`, "It should be a number, an array or a function."].join("\n"));
	return () => void 0;
}
function createUnarySpacing(theme) {
	return createUnaryUnit(theme, "spacing", 8, "spacing");
}
function getValue(transformer, propValue) {
	if (typeof propValue === "string" || propValue == null) return propValue;
	return transformer(propValue);
}
var container = [""];
function style(props, keys) {
	const theme = props.theme ?? EMPTY_THEME$1;
	const transformer = theme?.internal_cache?.unarySpacing ?? createUnarySpacing(theme);
	const result = {};
	for (const prop in props) {
		if (!keys.has(prop)) continue;
		const cssProperties = CSS_PROPERTIES[prop] ?? (container[0] = prop, container);
		const propValue = props[prop];
		iterateBreakpoints(result, props.theme, propValue, (mediaKey, value) => {
			const target = mediaKey ? result[mediaKey] : result;
			for (let i = 0; i < cssProperties.length; i += 1) target[cssProperties[i]] = getValue(transformer, value);
		});
	}
	return result;
}
function marginFn(props) {
	return style(props, marginKeys);
}
marginFn.propTypes = Array.from(marginKeys).reduce((obj, key) => {
	obj[key] = responsivePropType;
	return obj;
}, {});
marginFn.filterProps = marginKeys;
var margin = marginFn;
function paddingFn(props) {
	return style(props, paddingKeys);
}
paddingFn.propTypes = Array.from(paddingKeys).reduce((obj, key) => {
	obj[key] = responsivePropType;
	return obj;
}, {});
paddingFn.filterProps = paddingKeys;
var padding = paddingFn;
function spacingFn(props) {
	return style(props, spacingKeys);
}
spacingFn.propTypes = Array.from(spacingKeys).reduce((obj, key) => {
	obj[key] = responsivePropType;
	return obj;
}, {});
spacingFn.filterProps = spacingKeys;
//#endregion
//#region node_modules/@mui/system/compose/compose.mjs
function compose(...styles) {
	const handlers = styles.reduce((acc, style) => {
		style.filterProps.forEach((prop) => {
			acc[prop] = style;
		});
		return acc;
	}, {});
	const fn = (props) => {
		const result = {};
		for (const prop in props) if (handlers[prop]) fastDeepAssign(result, handlers[prop](props));
		return result;
	};
	fn.propTypes = styles.reduce((acc, style) => Object.assign(acc, style.propTypes), {});
	fn.filterProps = styles.reduce((acc, style) => acc.concat(style.filterProps), []);
	return fn;
}
//#endregion
//#region node_modules/@mui/system/borders/borders.mjs
/** @internal */
function borderTransform(value) {
	if (typeof value !== "number") return value;
	return `${value}px solid`;
}
function createBorderStyle(prop, transform) {
	return style$1({
		prop,
		themeKey: "borders",
		transform
	});
}
var border = createBorderStyle("border", borderTransform);
var borderTop = createBorderStyle("borderTop", borderTransform);
var borderRight = createBorderStyle("borderRight", borderTransform);
var borderBottom = createBorderStyle("borderBottom", borderTransform);
var borderLeft = createBorderStyle("borderLeft", borderTransform);
var borderColor = createBorderStyle("borderColor");
var borderTopColor = createBorderStyle("borderTopColor");
var borderRightColor = createBorderStyle("borderRightColor");
var borderBottomColor = createBorderStyle("borderBottomColor");
var borderLeftColor = createBorderStyle("borderLeftColor");
var outline = createBorderStyle("outline", borderTransform);
var outlineColor = createBorderStyle("outlineColor");
var borderRadius = (props) => {
	if (props.borderRadius !== void 0 && props.borderRadius !== null) {
		const transformer = createUnaryUnit(props.theme, "shape.borderRadius", 4, "borderRadius");
		const styleFromPropValue = (propValue) => ({ borderRadius: getValue(transformer, propValue) });
		return handleBreakpoints(props, props.borderRadius, styleFromPropValue);
	}
	return null;
};
borderRadius.propTypes = { borderRadius: responsivePropType };
borderRadius.filterProps = ["borderRadius"];
compose(border, borderTop, borderRight, borderBottom, borderLeft, borderColor, borderTopColor, borderRightColor, borderBottomColor, borderLeftColor, borderRadius, outline, outlineColor);
//#endregion
//#region node_modules/@mui/system/cssGrid/cssGrid.mjs
var gap = (props) => {
	if (props.gap !== void 0 && props.gap !== null) {
		const transformer = createUnaryUnit(props.theme, "spacing", 8, "gap");
		const styleFromPropValue = (propValue) => ({ gap: getValue(transformer, propValue) });
		return handleBreakpoints(props, props.gap, styleFromPropValue);
	}
	return null;
};
gap.propTypes = { gap: responsivePropType };
gap.filterProps = ["gap"];
var columnGap = (props) => {
	if (props.columnGap !== void 0 && props.columnGap !== null) {
		const transformer = createUnaryUnit(props.theme, "spacing", 8, "columnGap");
		const styleFromPropValue = (propValue) => ({ columnGap: getValue(transformer, propValue) });
		return handleBreakpoints(props, props.columnGap, styleFromPropValue);
	}
	return null;
};
columnGap.propTypes = { columnGap: responsivePropType };
columnGap.filterProps = ["columnGap"];
var rowGap = (props) => {
	if (props.rowGap !== void 0 && props.rowGap !== null) {
		const transformer = createUnaryUnit(props.theme, "spacing", 8, "rowGap");
		const styleFromPropValue = (propValue) => ({ rowGap: getValue(transformer, propValue) });
		return handleBreakpoints(props, props.rowGap, styleFromPropValue);
	}
	return null;
};
rowGap.propTypes = { rowGap: responsivePropType };
rowGap.filterProps = ["rowGap"];
compose(gap, columnGap, rowGap, style$1({ prop: "gridColumn" }), style$1({ prop: "gridRow" }), style$1({ prop: "gridAutoFlow" }), style$1({ prop: "gridAutoColumns" }), style$1({ prop: "gridAutoRows" }), style$1({ prop: "gridTemplateColumns" }), style$1({ prop: "gridTemplateRows" }), style$1({ prop: "gridTemplateAreas" }), style$1({ prop: "gridArea" }));
//#endregion
//#region node_modules/@mui/system/palette/palette.mjs
/** @internal */
function paletteTransform(value, userValue) {
	if (userValue === "grey") return userValue;
	return value;
}
compose(style$1({
	prop: "color",
	themeKey: "palette",
	transform: paletteTransform
}), style$1({
	prop: "bgcolor",
	cssProperty: "backgroundColor",
	themeKey: "palette",
	transform: paletteTransform
}), style$1({
	prop: "backgroundColor",
	themeKey: "palette",
	transform: paletteTransform
}));
//#endregion
//#region node_modules/@mui/system/sizing/sizing.mjs
var breakpointsValues = values;
/** @internal */
function sizingTransform(value) {
	return value <= 1 && value !== 0 ? `${value * 100}%` : value;
}
var width = style$1({
	prop: "width",
	transform: sizingTransform
});
var maxWidth = (props) => {
	if (props.maxWidth !== void 0 && props.maxWidth !== null) {
		const styleFromPropValue = (propValue) => {
			const breakpoint = props.theme?.breakpoints?.values?.[propValue] || breakpointsValues[propValue];
			if (!breakpoint) return { maxWidth: sizingTransform(propValue) };
			if (props.theme?.breakpoints?.unit !== "px") return { maxWidth: `${breakpoint}${props.theme.breakpoints.unit}` };
			return { maxWidth: breakpoint };
		};
		return handleBreakpoints(props, props.maxWidth, styleFromPropValue);
	}
	return null;
};
maxWidth.filterProps = ["maxWidth"];
var minWidth = style$1({
	prop: "minWidth",
	transform: sizingTransform
});
var height = style$1({
	prop: "height",
	transform: sizingTransform
});
var maxHeight = style$1({
	prop: "maxHeight",
	transform: sizingTransform
});
var minHeight = style$1({
	prop: "minHeight",
	transform: sizingTransform
});
style$1({
	prop: "size",
	cssProperty: "width",
	transform: sizingTransform
});
style$1({
	prop: "size",
	cssProperty: "height",
	transform: sizingTransform
});
compose(width, maxWidth, minWidth, height, maxHeight, minHeight, style$1({ prop: "boxSizing" }));
//#endregion
//#region node_modules/@mui/system/styleFunctionSx/defaultSxConfig.mjs
var defaultSxConfig = {
	border: {
		themeKey: "borders",
		transform: borderTransform
	},
	borderTop: {
		themeKey: "borders",
		transform: borderTransform
	},
	borderRight: {
		themeKey: "borders",
		transform: borderTransform
	},
	borderBottom: {
		themeKey: "borders",
		transform: borderTransform
	},
	borderLeft: {
		themeKey: "borders",
		transform: borderTransform
	},
	borderColor: { themeKey: "palette" },
	borderTopColor: { themeKey: "palette" },
	borderRightColor: { themeKey: "palette" },
	borderBottomColor: { themeKey: "palette" },
	borderLeftColor: { themeKey: "palette" },
	outline: {
		themeKey: "borders",
		transform: borderTransform
	},
	outlineColor: { themeKey: "palette" },
	borderRadius: {
		themeKey: "shape.borderRadius",
		style: borderRadius
	},
	color: {
		themeKey: "palette",
		transform: paletteTransform
	},
	bgcolor: {
		themeKey: "palette",
		cssProperty: "backgroundColor",
		transform: paletteTransform
	},
	backgroundColor: {
		themeKey: "palette",
		transform: paletteTransform
	},
	p: { style: padding },
	pt: { style: padding },
	pr: { style: padding },
	pb: { style: padding },
	pl: { style: padding },
	px: { style: padding },
	py: { style: padding },
	padding: { style: padding },
	paddingTop: { style: padding },
	paddingRight: { style: padding },
	paddingBottom: { style: padding },
	paddingLeft: { style: padding },
	paddingX: { style: padding },
	paddingY: { style: padding },
	paddingInline: { style: padding },
	paddingInlineStart: { style: padding },
	paddingInlineEnd: { style: padding },
	paddingBlock: { style: padding },
	paddingBlockStart: { style: padding },
	paddingBlockEnd: { style: padding },
	m: { style: margin },
	mt: { style: margin },
	mr: { style: margin },
	mb: { style: margin },
	ml: { style: margin },
	mx: { style: margin },
	my: { style: margin },
	margin: { style: margin },
	marginTop: { style: margin },
	marginRight: { style: margin },
	marginBottom: { style: margin },
	marginLeft: { style: margin },
	marginX: { style: margin },
	marginY: { style: margin },
	marginInline: { style: margin },
	marginInlineStart: { style: margin },
	marginInlineEnd: { style: margin },
	marginBlock: { style: margin },
	marginBlockStart: { style: margin },
	marginBlockEnd: { style: margin },
	displayPrint: {
		cssProperty: false,
		transform: (value) => ({ "@media print": { display: value } })
	},
	display: {},
	overflow: {},
	textOverflow: {},
	visibility: {},
	whiteSpace: {},
	flexBasis: {},
	flexDirection: {},
	flexWrap: {},
	justifyContent: {},
	alignItems: {},
	alignContent: {},
	order: {},
	flex: {},
	flexGrow: {},
	flexShrink: {},
	alignSelf: {},
	justifyItems: {},
	justifySelf: {},
	gap: { style: gap },
	rowGap: { style: rowGap },
	columnGap: { style: columnGap },
	gridColumn: {},
	gridRow: {},
	gridAutoFlow: {},
	gridAutoColumns: {},
	gridAutoRows: {},
	gridTemplateColumns: {},
	gridTemplateRows: {},
	gridTemplateAreas: {},
	gridArea: {},
	position: {},
	zIndex: { themeKey: "zIndex" },
	top: {},
	right: {},
	bottom: {},
	left: {},
	boxShadow: { themeKey: "shadows" },
	width: { transform: sizingTransform },
	maxWidth: { style: maxWidth },
	minWidth: { transform: sizingTransform },
	height: { transform: sizingTransform },
	maxHeight: { transform: sizingTransform },
	minHeight: { transform: sizingTransform },
	boxSizing: {},
	font: { themeKey: "font" },
	fontFamily: { themeKey: "typography" },
	fontSize: { themeKey: "typography" },
	fontStyle: { themeKey: "typography" },
	fontWeight: { themeKey: "typography" },
	letterSpacing: {},
	textTransform: {},
	lineHeight: {},
	textAlign: {},
	typography: {
		cssProperty: false,
		themeKey: "typography"
	}
};
//#endregion
//#region node_modules/@mui/system/styleFunctionSx/styleFunctionSx.mjs
var EMPTY_THEME = {};
function unstable_createStyleFunctionSx() {
	function styleFunctionSx(props) {
		if (!props.sx) return null;
		const { sx, theme = EMPTY_THEME, nested } = props;
		const config = theme.unstable_sxConfig ?? defaultSxConfig;
		const wrapper = {
			sx: null,
			theme,
			nested: true
		};
		function process(sxInput) {
			let sxObject = sxInput;
			if (typeof sxInput === "function") sxObject = sxInput(theme);
			else if (typeof sxInput !== "object") return sxInput;
			if (!sxObject) return null;
			const breakpoints = theme.breakpoints ?? DEFAULT_BREAKPOINTS;
			const css = createEmptyBreakpointObject(breakpoints);
			for (const styleKey in sxObject) {
				const value = callIfFn(sxObject[styleKey], theme);
				if (value === null || value === void 0) continue;
				if (typeof value !== "object") {
					setThemeValue(css, styleKey, value, theme, config);
					continue;
				}
				if (config[styleKey]) {
					setThemeValue(css, styleKey, value, theme, config);
					continue;
				}
				if (hasBreakpoint(breakpoints, value)) iterateBreakpoints(css, props.theme, value, (mediaKey, finalValue) => {
					css[mediaKey][styleKey] = finalValue;
				});
				else {
					wrapper.sx = value;
					css[styleKey] = styleFunctionSx(wrapper);
				}
			}
			if (!nested && theme.modularCssLayers) return { "@layer sx": sortContainerQueries(theme, removeUnusedBreakpoints(breakpoints, css)) };
			return sortContainerQueries(theme, removeUnusedBreakpoints(breakpoints, css));
		}
		return Array.isArray(sx) ? sx.map(process) : process(sx);
	}
	styleFunctionSx.filterProps = ["sx"];
	return styleFunctionSx;
}
var styleFunctionSx_default = unstable_createStyleFunctionSx();
function setThemeValue(css, prop, value, theme, config) {
	const options = config[prop];
	if (!options) {
		css[prop] = value;
		return;
	}
	if (value == null) return;
	const { themeKey } = options;
	if (themeKey === "typography" && value === "inherit") {
		css[prop] = value;
		return;
	}
	const { style } = options;
	if (style) {
		fastDeepAssign(css, style({
			[prop]: value,
			theme
		}));
		return;
	}
	const { cssProperty = prop, transform } = options;
	const themeMapping = getPath(theme, themeKey);
	iterateBreakpoints(css, theme, value, (mediaKey, valueFinal) => {
		const finalValue = getStyleValue2(themeMapping, transform, valueFinal, prop);
		if (cssProperty === false) if (mediaKey) fastDeepAssign(css[mediaKey], finalValue);
		else fastDeepAssign(css, finalValue);
		else if (mediaKey) css[mediaKey][cssProperty] = finalValue;
		else css[cssProperty] = finalValue;
	});
}
function callIfFn(maybeFn, arg) {
	return typeof maybeFn === "function" ? maybeFn(arg) : maybeFn;
}
//#endregion
//#region node_modules/@emotion/sheet/dist/emotion-sheet.development.esm.js
function sheetForTag(tag) {
	if (tag.sheet) return tag.sheet;
	/* istanbul ignore next */
	for (var i = 0; i < document.styleSheets.length; i++) if (document.styleSheets[i].ownerNode === tag) return document.styleSheets[i];
}
function createStyleElement(options) {
	var tag = document.createElement("style");
	tag.setAttribute("data-emotion", options.key);
	if (options.nonce !== void 0) tag.setAttribute("nonce", options.nonce);
	tag.appendChild(document.createTextNode(""));
	tag.setAttribute("data-s", "");
	return tag;
}
var StyleSheet = /*#__PURE__*/ function() {
	function StyleSheet(options) {
		var _this = this;
		this._insertTag = function(tag) {
			var before;
			if (_this.tags.length === 0) if (_this.insertionPoint) before = _this.insertionPoint.nextSibling;
			else if (_this.prepend) before = _this.container.firstChild;
			else before = _this.before;
			else before = _this.tags[_this.tags.length - 1].nextSibling;
			_this.container.insertBefore(tag, before);
			_this.tags.push(tag);
		};
		this.isSpeedy = options.speedy === void 0 ? false : options.speedy;
		this.tags = [];
		this.ctr = 0;
		this.nonce = options.nonce;
		this.key = options.key;
		this.container = options.container;
		this.prepend = options.prepend;
		this.insertionPoint = options.insertionPoint;
		this.before = null;
	}
	var _proto = StyleSheet.prototype;
	_proto.hydrate = function hydrate(nodes) {
		nodes.forEach(this._insertTag);
	};
	_proto.insert = function insert(rule) {
		if (this.ctr % (this.isSpeedy ? 65e3 : 1) === 0) this._insertTag(createStyleElement(this));
		var tag = this.tags[this.tags.length - 1];
		var isImportRule = rule.charCodeAt(0) === 64 && rule.charCodeAt(1) === 105;
		if (isImportRule && this._alreadyInsertedOrderInsensitiveRule) console.error("You're attempting to insert the following rule:\n" + rule + "\n\n`@import` rules must be before all other types of rules in a stylesheet but other rules have already been inserted. Please ensure that `@import` rules are before all other rules.");
		this._alreadyInsertedOrderInsensitiveRule = this._alreadyInsertedOrderInsensitiveRule || !isImportRule;
		if (this.isSpeedy) {
			var sheet = sheetForTag(tag);
			try {
				sheet.insertRule(rule, sheet.cssRules.length);
			} catch (e) {
				if (!/:(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only|-ms-clear|-ms-expand|-ms-reveal){/.test(rule)) console.error("There was a problem inserting the following rule: \"" + rule + "\"", e);
			}
		} else tag.appendChild(document.createTextNode(rule));
		this.ctr++;
	};
	_proto.flush = function flush() {
		this.tags.forEach(function(tag) {
			var _tag$parentNode;
			return (_tag$parentNode = tag.parentNode) == null ? void 0 : _tag$parentNode.removeChild(tag);
		});
		this.tags = [];
		this.ctr = 0;
		this._alreadyInsertedOrderInsensitiveRule = false;
	};
	return StyleSheet;
}();
//#endregion
//#region node_modules/stylis/src/Enum.js
var MS = "-ms-";
var MOZ = "-moz-";
var WEBKIT = "-webkit-";
var COMMENT = "comm";
var RULESET = "rule";
var DECLARATION = "decl";
var IMPORT = "@import";
var KEYFRAMES = "@keyframes";
var LAYER = "@layer";
//#endregion
//#region node_modules/stylis/src/Utility.js
/**
* @param {number}
* @return {number}
*/
var abs = Math.abs;
/**
* @param {number}
* @return {string}
*/
var from = String.fromCharCode;
/**
* @param {object}
* @return {object}
*/
var assign = Object.assign;
/**
* @param {string} value
* @param {number} length
* @return {number}
*/
function hash(value, length) {
	return charat(value, 0) ^ 45 ? (((length << 2 ^ charat(value, 0)) << 2 ^ charat(value, 1)) << 2 ^ charat(value, 2)) << 2 ^ charat(value, 3) : 0;
}
/**
* @param {string} value
* @return {string}
*/
function trim(value) {
	return value.trim();
}
/**
* @param {string} value
* @param {RegExp} pattern
* @return {string?}
*/
function match(value, pattern) {
	return (value = pattern.exec(value)) ? value[0] : value;
}
/**
* @param {string} value
* @param {(string|RegExp)} pattern
* @param {string} replacement
* @return {string}
*/
function replace(value, pattern, replacement) {
	return value.replace(pattern, replacement);
}
/**
* @param {string} value
* @param {string} search
* @return {number}
*/
function indexof(value, search) {
	return value.indexOf(search);
}
/**
* @param {string} value
* @param {number} index
* @return {number}
*/
function charat(value, index) {
	return value.charCodeAt(index) | 0;
}
/**
* @param {string} value
* @param {number} begin
* @param {number} end
* @return {string}
*/
function substr(value, begin, end) {
	return value.slice(begin, end);
}
/**
* @param {string} value
* @return {number}
*/
function strlen(value) {
	return value.length;
}
/**
* @param {any[]} value
* @return {number}
*/
function sizeof(value) {
	return value.length;
}
/**
* @param {any} value
* @param {any[]} array
* @return {any}
*/
function append(value, array) {
	return array.push(value), value;
}
/**
* @param {string[]} array
* @param {function} callback
* @return {string}
*/
function combine(array, callback) {
	return array.map(callback).join("");
}
//#endregion
//#region node_modules/stylis/src/Tokenizer.js
var line = 1;
var column = 1;
var length = 0;
var position = 0;
var character = 0;
var characters = "";
/**
* @param {string} value
* @param {object | null} root
* @param {object | null} parent
* @param {string} type
* @param {string[] | string} props
* @param {object[] | string} children
* @param {number} length
*/
function node(value, root, parent, type, props, children, length) {
	return {
		value,
		root,
		parent,
		type,
		props,
		children,
		line,
		column,
		length,
		return: ""
	};
}
/**
* @param {object} root
* @param {object} props
* @return {object}
*/
function copy(root, props) {
	return assign(node("", null, null, "", null, null, 0), root, { length: -root.length }, props);
}
/**
* @return {number}
*/
function char() {
	return character;
}
/**
* @return {number}
*/
function prev() {
	character = position > 0 ? charat(characters, --position) : 0;
	if (column--, character === 10) column = 1, line--;
	return character;
}
/**
* @return {number}
*/
function next() {
	character = position < length ? charat(characters, position++) : 0;
	if (column++, character === 10) column = 1, line++;
	return character;
}
/**
* @return {number}
*/
function peek() {
	return charat(characters, position);
}
/**
* @return {number}
*/
function caret() {
	return position;
}
/**
* @param {number} begin
* @param {number} end
* @return {string}
*/
function slice(begin, end) {
	return substr(characters, begin, end);
}
/**
* @param {number} type
* @return {number}
*/
function token(type) {
	switch (type) {
		case 0:
		case 9:
		case 10:
		case 13:
		case 32: return 5;
		case 33:
		case 43:
		case 44:
		case 47:
		case 62:
		case 64:
		case 126:
		case 59:
		case 123:
		case 125: return 4;
		case 58: return 3;
		case 34:
		case 39:
		case 40:
		case 91: return 2;
		case 41:
		case 93: return 1;
	}
	return 0;
}
/**
* @param {string} value
* @return {any[]}
*/
function alloc(value) {
	return line = column = 1, length = strlen(characters = value), position = 0, [];
}
/**
* @param {any} value
* @return {any}
*/
function dealloc(value) {
	return characters = "", value;
}
/**
* @param {number} type
* @return {string}
*/
function delimit(type) {
	return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
/**
* @param {number} type
* @return {string}
*/
function whitespace(type) {
	while (character = peek()) if (character < 33) next();
	else break;
	return token(type) > 2 || token(character) > 3 ? "" : " ";
}
/**
* @param {number} index
* @param {number} count
* @return {string}
*/
function escaping(index, count) {
	while (--count && next()) if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97) break;
	return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
}
/**
* @param {number} type
* @return {number}
*/
function delimiter(type) {
	while (next()) switch (character) {
		case type: return position;
		case 34:
		case 39:
			if (type !== 34 && type !== 39) delimiter(character);
			break;
		case 40:
			if (type === 41) delimiter(type);
			break;
		case 92:
			next();
			break;
	}
	return position;
}
/**
* @param {number} type
* @param {number} index
* @return {number}
*/
function commenter(type, index) {
	while (next()) if (type + character === 57) break;
	else if (type + character === 84 && peek() === 47) break;
	return "/*" + slice(index, position - 1) + "*" + from(type === 47 ? type : next());
}
/**
* @param {number} index
* @return {string}
*/
function identifier(index) {
	while (!token(peek())) next();
	return slice(index, position);
}
//#endregion
//#region node_modules/stylis/src/Parser.js
/**
* @param {string} value
* @return {object[]}
*/
function compile(value) {
	return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {string[]} rule
* @param {string[]} rules
* @param {string[]} rulesets
* @param {number[]} pseudo
* @param {number[]} points
* @param {string[]} declarations
* @return {object}
*/
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
	var index = 0;
	var offset = 0;
	var length = pseudo;
	var atrule = 0;
	var property = 0;
	var previous = 0;
	var variable = 1;
	var scanning = 1;
	var ampersand = 1;
	var character = 0;
	var type = "";
	var props = rules;
	var children = rulesets;
	var reference = rule;
	var characters = type;
	while (scanning) switch (previous = character, character = next()) {
		case 40: if (previous != 108 && charat(characters, length - 1) == 58) {
			if (indexof(characters += replace(delimit(character), "&", "&\f"), "&\f") != -1) ampersand = -1;
			break;
		}
		case 34:
		case 39:
		case 91:
			characters += delimit(character);
			break;
		case 9:
		case 10:
		case 13:
		case 32:
			characters += whitespace(previous);
			break;
		case 92:
			characters += escaping(caret() - 1, 7);
			continue;
		case 47:
			switch (peek()) {
				case 42:
				case 47:
					append(comment(commenter(next(), caret()), root, parent), declarations);
					break;
				default: characters += "/";
			}
			break;
		case 123 * variable: points[index++] = strlen(characters) * ampersand;
		case 125 * variable:
		case 59:
		case 0:
			switch (character) {
				case 0:
				case 125: scanning = 0;
				case 59 + offset:
					if (ampersand == -1) characters = replace(characters, /\f/g, "");
					if (property > 0 && strlen(characters) - length) append(property > 32 ? declaration(characters + ";", rule, parent, length - 1) : declaration(replace(characters, " ", "") + ";", rule, parent, length - 2), declarations);
					break;
				case 59: characters += ";";
				default:
					append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length), rulesets);
					if (character === 123) if (offset === 0) parse(characters, root, reference, reference, props, rulesets, length, points, children);
					else switch (atrule === 99 && charat(characters, 3) === 110 ? 100 : atrule) {
						case 100:
						case 108:
						case 109:
						case 115:
							parse(value, reference, reference, rule && append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length), children), rules, children, length, points, rule ? props : children);
							break;
						default: parse(characters, reference, reference, reference, [""], children, 0, points, children);
					}
			}
			index = offset = property = 0, variable = ampersand = 1, type = characters = "", length = pseudo;
			break;
		case 58: length = 1 + strlen(characters), property = previous;
		default:
			if (variable < 1) {
				if (character == 123) --variable;
				else if (character == 125 && variable++ == 0 && prev() == 125) continue;
			}
			switch (characters += from(character), character * variable) {
				case 38:
					ampersand = offset > 0 ? 1 : (characters += "\f", -1);
					break;
				case 44:
					points[index++] = (strlen(characters) - 1) * ampersand, ampersand = 1;
					break;
				case 64:
					if (peek() === 45) characters += delimit(next());
					atrule = peek(), offset = length = strlen(type = characters += identifier(caret())), character++;
					break;
				case 45: if (previous === 45 && strlen(characters) == 2) variable = 0;
			}
	}
	return rulesets;
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} index
* @param {number} offset
* @param {string[]} rules
* @param {number[]} points
* @param {string} type
* @param {string[]} props
* @param {string[]} children
* @param {number} length
* @return {object}
*/
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length) {
	var post = offset - 1;
	var rule = offset === 0 ? rules : [""];
	var size = sizeof(rule);
	for (var i = 0, j = 0, k = 0; i < index; ++i) for (var x = 0, y = substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x) if (z = trim(j > 0 ? rule[x] + " " + y : replace(y, /&\f/g, rule[x]))) props[k++] = z;
	return node(value, root, parent, offset === 0 ? RULESET : type, props, children, length);
}
/**
* @param {number} value
* @param {object} root
* @param {object?} parent
* @return {object}
*/
function comment(value, root, parent) {
	return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0);
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} length
* @return {object}
*/
function declaration(value, root, parent, length) {
	return node(value, root, parent, DECLARATION, substr(value, 0, length), substr(value, length + 1, -1), length);
}
//#endregion
//#region node_modules/stylis/src/Serializer.js
/**
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function serialize(children, callback) {
	var output = "";
	var length = sizeof(children);
	for (var i = 0; i < length; i++) output += callback(children[i], i, children, callback) || "";
	return output;
}
/**
* @param {object} element
* @param {number} index
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function stringify(element, index, children, callback) {
	switch (element.type) {
		case LAYER: if (element.children.length) break;
		case IMPORT:
		case DECLARATION: return element.return = element.return || element.value;
		case COMMENT: return "";
		case KEYFRAMES: return element.return = element.value + "{" + serialize(element.children, callback) + "}";
		case RULESET: element.value = element.props.join(",");
	}
	return strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
}
//#endregion
//#region node_modules/stylis/src/Middleware.js
/**
* @param {function[]} collection
* @return {function}
*/
function middleware(collection) {
	var length = sizeof(collection);
	return function(element, index, children, callback) {
		var output = "";
		for (var i = 0; i < length; i++) output += collection[i](element, index, children, callback) || "";
		return output;
	};
}
//#endregion
//#region node_modules/@emotion/memoize/dist/emotion-memoize.esm.js
function memoize(fn) {
	var cache = Object.create(null);
	return function(arg) {
		if (cache[arg] === void 0) cache[arg] = fn(arg);
		return cache[arg];
	};
}
//#endregion
//#region node_modules/@emotion/cache/dist/emotion-cache.browser.development.esm.js
var identifierWithPointTracking = function identifierWithPointTracking(begin, points, index) {
	var previous = 0;
	var character = 0;
	while (true) {
		previous = character;
		character = peek();
		if (previous === 38 && character === 12) points[index] = 1;
		if (token(character)) break;
		next();
	}
	return slice(begin, position);
};
var toRules = function toRules(parsed, points) {
	var index = -1;
	var character = 44;
	do
		switch (token(character)) {
			case 0:
				if (character === 38 && peek() === 12) points[index] = 1;
				parsed[index] += identifierWithPointTracking(position - 1, points, index);
				break;
			case 2:
				parsed[index] += delimit(character);
				break;
			case 4: if (character === 44) {
				parsed[++index] = peek() === 58 ? "&\f" : "";
				points[index] = parsed[index].length;
				break;
			}
			default: parsed[index] += from(character);
		}
	while (character = next());
	return parsed;
};
var getRules = function getRules(value, points) {
	return dealloc(toRules(alloc(value), points));
};
var fixedElements = /* #__PURE__ */ new WeakMap();
var compat = function compat(element) {
	if (element.type !== "rule" || !element.parent || element.length < 1) return;
	var value = element.value;
	var parent = element.parent;
	var isImplicitRule = element.column === parent.column && element.line === parent.line;
	while (parent.type !== "rule") {
		parent = parent.parent;
		if (!parent) return;
	}
	if (element.props.length === 1 && value.charCodeAt(0) !== 58 && !fixedElements.get(parent)) return;
	if (isImplicitRule) return;
	fixedElements.set(element, true);
	var points = [];
	var rules = getRules(value, points);
	var parentRules = parent.props;
	for (var i = 0, k = 0; i < rules.length; i++) for (var j = 0; j < parentRules.length; j++, k++) element.props[k] = points[i] ? rules[i].replace(/&\f/g, parentRules[j]) : parentRules[j] + " " + rules[i];
};
var removeLabel = function removeLabel(element) {
	if (element.type === "decl") {
		var value = element.value;
		if (value.charCodeAt(0) === 108 && value.charCodeAt(2) === 98) {
			element["return"] = "";
			element.value = "";
		}
	}
};
var ignoreFlag = "emotion-disable-server-rendering-unsafe-selector-warning-please-do-not-use-this-the-warning-exists-for-a-reason";
var isIgnoringComment = function isIgnoringComment(element) {
	return element.type === "comm" && element.children.indexOf(ignoreFlag) > -1;
};
var createUnsafeSelectorsAlarm = function createUnsafeSelectorsAlarm(cache) {
	return function(element, index, children) {
		if (element.type !== "rule" || cache.compat) return;
		var unsafePseudoClasses = element.value.match(/(:first|:nth|:nth-last)-child/g);
		if (unsafePseudoClasses) {
			var commentContainer = !!element.parent ? element.parent.children : children;
			for (var i = commentContainer.length - 1; i >= 0; i--) {
				var node = commentContainer[i];
				if (node.line < element.line) break;
				if (node.column < element.column) {
					if (isIgnoringComment(node)) return;
					break;
				}
			}
			unsafePseudoClasses.forEach(function(unsafePseudoClass) {
				console.error("The pseudo class \"" + unsafePseudoClass + "\" is potentially unsafe when doing server-side rendering. Try changing it to \"" + unsafePseudoClass.split("-child")[0] + "-of-type\".");
			});
		}
	};
};
var isImportRule = function isImportRule(element) {
	return element.type.charCodeAt(1) === 105 && element.type.charCodeAt(0) === 64;
};
var isPrependedWithRegularRules = function isPrependedWithRegularRules(index, children) {
	for (var i = index - 1; i >= 0; i--) if (!isImportRule(children[i])) return true;
	return false;
};
var nullifyElement = function nullifyElement(element) {
	element.type = "";
	element.value = "";
	element["return"] = "";
	element.children = "";
	element.props = "";
};
var incorrectImportAlarm = function incorrectImportAlarm(element, index, children) {
	if (!isImportRule(element)) return;
	if (element.parent) {
		console.error("`@import` rules can't be nested inside other rules. Please move it to the top level and put it before regular rules. Keep in mind that they can only be used within global styles.");
		nullifyElement(element);
	} else if (isPrependedWithRegularRules(index, children)) {
		console.error("`@import` rules can't be after other rules. Please put your `@import` rules before your other rules.");
		nullifyElement(element);
	}
};
function prefix(value, length) {
	switch (hash(value, length)) {
		case 5103: return WEBKIT + "print-" + value + value;
		case 5737:
		case 4201:
		case 3177:
		case 3433:
		case 1641:
		case 4457:
		case 2921:
		case 5572:
		case 6356:
		case 5844:
		case 3191:
		case 6645:
		case 3005:
		case 6391:
		case 5879:
		case 5623:
		case 6135:
		case 4599:
		case 4855:
		case 4215:
		case 6389:
		case 5109:
		case 5365:
		case 5621:
		case 3829: return WEBKIT + value + value;
		case 5349:
		case 4246:
		case 4810:
		case 6968:
		case 2756: return WEBKIT + value + MOZ + value + MS + value + value;
		case 6828:
		case 4268: return WEBKIT + value + MS + value + value;
		case 6165: return WEBKIT + value + MS + "flex-" + value + value;
		case 5187: return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + "box-$1$2" + MS + "flex-$1$2") + value;
		case 5443: return WEBKIT + value + MS + "flex-item-" + replace(value, /flex-|-self/, "") + value;
		case 4675: return WEBKIT + value + MS + "flex-line-pack" + replace(value, /align-content|flex-|-self/, "") + value;
		case 5548: return WEBKIT + value + MS + replace(value, "shrink", "negative") + value;
		case 5292: return WEBKIT + value + MS + replace(value, "basis", "preferred-size") + value;
		case 6060: return WEBKIT + "box-" + replace(value, "-grow", "") + WEBKIT + value + MS + replace(value, "grow", "positive") + value;
		case 4554: return WEBKIT + replace(value, /([^-])(transform)/g, "$1" + WEBKIT + "$2") + value;
		case 6187: return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + "$1"), /(image-set)/, WEBKIT + "$1"), value, "") + value;
		case 5495:
		case 3959: return replace(value, /(image-set\([^]*)/, WEBKIT + "$1$`$1");
		case 4968: return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + "box-pack:$3" + MS + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + WEBKIT + value + value;
		case 4095:
		case 3583:
		case 4068:
		case 2532: return replace(value, /(.+)-inline(.+)/, WEBKIT + "$1$2") + value;
		case 8116:
		case 7059:
		case 5753:
		case 5535:
		case 5445:
		case 5701:
		case 4933:
		case 4677:
		case 5533:
		case 5789:
		case 5021:
		case 4765:
			if (strlen(value) - 1 - length > 6) switch (charat(value, length + 1)) {
				case 109: if (charat(value, length + 4) !== 45) break;
				case 102: return replace(value, /(.+:)(.+)-([^]+)/, "$1" + WEBKIT + "$2-$3$1" + MOZ + (charat(value, length + 3) == 108 ? "$3" : "$2-$3")) + value;
				case 115: return ~indexof(value, "stretch") ? prefix(replace(value, "stretch", "fill-available"), length) + value : value;
			}
			break;
		case 4949: if (charat(value, length + 1) !== 115) break;
		case 6444:
			switch (charat(value, strlen(value) - 3 - (~indexof(value, "!important") && 10))) {
				case 107: return replace(value, ":", ":" + WEBKIT) + value;
				case 101: return replace(value, /(.+:)([^;!]+)(;|!.+)?/, "$1" + WEBKIT + (charat(value, 14) === 45 ? "inline-" : "") + "box$3$1" + WEBKIT + "$2$3$1" + MS + "$2box$3") + value;
			}
			break;
		case 5936:
			switch (charat(value, length + 11)) {
				case 114: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb") + value;
				case 108: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb-rl") + value;
				case 45: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "lr") + value;
			}
			return WEBKIT + value + MS + value + value;
	}
	return value;
}
var defaultStylisPlugins = [function prefixer(element, index, children, callback) {
	if (element.length > -1) {
		if (!element["return"]) switch (element.type) {
			case DECLARATION:
				element["return"] = prefix(element.value, element.length);
				break;
			case KEYFRAMES: return serialize([copy(element, { value: replace(element.value, "@", "@" + WEBKIT) })], callback);
			case RULESET: if (element.length) return combine(element.props, function(value) {
				switch (match(value, /(::plac\w+|:read-\w+)/)) {
					case ":read-only":
					case ":read-write": return serialize([copy(element, { props: [replace(value, /:(read-\w+)/, ":" + MOZ + "$1")] })], callback);
					case "::placeholder": return serialize([
						copy(element, { props: [replace(value, /:(plac\w+)/, ":" + WEBKIT + "input-$1")] }),
						copy(element, { props: [replace(value, /:(plac\w+)/, ":" + MOZ + "$1")] }),
						copy(element, { props: [replace(value, /:(plac\w+)/, MS + "input-$1")] })
					], callback);
				}
				return "";
			});
		}
	}
}];
var getSourceMap;
var sourceMapPattern = /\/\*#\ssourceMappingURL=data:application\/json;\S+\s+\*\//g;
getSourceMap = function getSourceMap(styles) {
	var matches = styles.match(sourceMapPattern);
	if (!matches) return;
	return matches[matches.length - 1];
};
var createCache = function createCache(options) {
	var key = options.key;
	if (!key) throw new Error("You have to configure `key` for your cache. Please make sure it's unique (and not equal to 'css') as it's used for linking styles to your cache.\nIf multiple caches share the same key they might \"fight\" for each other's style elements.");
	if (key === "css") {
		var ssrStyles = document.querySelectorAll("style[data-emotion]:not([data-s])");
		Array.prototype.forEach.call(ssrStyles, function(node) {
			if (node.getAttribute("data-emotion").indexOf(" ") === -1) return;
			document.head.appendChild(node);
			node.setAttribute("data-s", "");
		});
	}
	var stylisPlugins = options.stylisPlugins || defaultStylisPlugins;
	if (/[^a-z-]/.test(key)) throw new Error("Emotion key must only contain lower case alphabetical characters and - but \"" + key + "\" was passed");
	var inserted = {};
	var container;
	var nodesToHydrate = [];
	container = options.container || document.head;
	Array.prototype.forEach.call(document.querySelectorAll("style[data-emotion^=\"" + key + " \"]"), function(node) {
		var attrib = node.getAttribute("data-emotion").split(" ");
		for (var i = 1; i < attrib.length; i++) inserted[attrib[i]] = true;
		nodesToHydrate.push(node);
	});
	var _insert;
	var omnipresentPlugins = [compat, removeLabel];
	omnipresentPlugins.push(createUnsafeSelectorsAlarm({ get compat() {
		return cache.compat;
	} }), incorrectImportAlarm);
	var currentSheet;
	var finalizingPlugins = [stringify, function(element) {
		if (!element.root) {
			if (element["return"]) currentSheet.insert(element["return"]);
			else if (element.value && element.type !== "comm") currentSheet.insert(element.value + "{}");
		}
	}];
	var serializer = middleware(omnipresentPlugins.concat(stylisPlugins, finalizingPlugins));
	var stylis = function stylis(styles) {
		return serialize(compile(styles), serializer);
	};
	_insert = function insert(selector, serialized, sheet, shouldCache) {
		currentSheet = sheet;
		if (getSourceMap) {
			var sourceMap = getSourceMap(serialized.styles);
			if (sourceMap) currentSheet = { insert: function insert(rule) {
				sheet.insert(rule + sourceMap);
			} };
		}
		stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);
		if (shouldCache) cache.inserted[serialized.name] = true;
	};
	var cache = {
		key,
		sheet: new StyleSheet({
			key,
			container,
			nonce: options.nonce,
			speedy: options.speedy,
			prepend: options.prepend,
			insertionPoint: options.insertionPoint
		}),
		nonce: options.nonce,
		inserted,
		registered: {},
		insert: _insert
	};
	cache.sheet.hydrate(nodesToHydrate);
	return cache;
};
//#endregion
//#region node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js
/** @license React v16.13.1
* react-is.development.js
*
* Copyright (c) Facebook, Inc. and its affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_is_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		"use strict";
		var hasSymbol = typeof Symbol === "function" && Symbol.for;
		var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for("react.element") : 60103;
		var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for("react.portal") : 60106;
		var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for("react.fragment") : 60107;
		var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for("react.strict_mode") : 60108;
		var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for("react.profiler") : 60114;
		var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for("react.provider") : 60109;
		var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for("react.context") : 60110;
		var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for("react.async_mode") : 60111;
		var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for("react.concurrent_mode") : 60111;
		var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for("react.forward_ref") : 60112;
		var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for("react.suspense") : 60113;
		var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for("react.suspense_list") : 60120;
		var REACT_MEMO_TYPE = hasSymbol ? Symbol.for("react.memo") : 60115;
		var REACT_LAZY_TYPE = hasSymbol ? Symbol.for("react.lazy") : 60116;
		var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for("react.block") : 60121;
		var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for("react.fundamental") : 60117;
		var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for("react.responder") : 60118;
		var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for("react.scope") : 60119;
		function isValidElementType(type) {
			return typeof type === "string" || typeof type === "function" || type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
		}
		function typeOf(object) {
			if (typeof object === "object" && object !== null) {
				var $$typeof = object.$$typeof;
				switch ($$typeof) {
					case REACT_ELEMENT_TYPE:
						var type = object.type;
						switch (type) {
							case REACT_ASYNC_MODE_TYPE:
							case REACT_CONCURRENT_MODE_TYPE:
							case REACT_FRAGMENT_TYPE:
							case REACT_PROFILER_TYPE:
							case REACT_STRICT_MODE_TYPE:
							case REACT_SUSPENSE_TYPE: return type;
							default:
								var $$typeofType = type && type.$$typeof;
								switch ($$typeofType) {
									case REACT_CONTEXT_TYPE:
									case REACT_FORWARD_REF_TYPE:
									case REACT_LAZY_TYPE:
									case REACT_MEMO_TYPE:
									case REACT_PROVIDER_TYPE: return $$typeofType;
									default: return $$typeof;
								}
						}
					case REACT_PORTAL_TYPE: return $$typeof;
				}
			}
		}
		var AsyncMode = REACT_ASYNC_MODE_TYPE;
		var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
		var ContextConsumer = REACT_CONTEXT_TYPE;
		var ContextProvider = REACT_PROVIDER_TYPE;
		var Element = REACT_ELEMENT_TYPE;
		var ForwardRef = REACT_FORWARD_REF_TYPE;
		var Fragment = REACT_FRAGMENT_TYPE;
		var Lazy = REACT_LAZY_TYPE;
		var Memo = REACT_MEMO_TYPE;
		var Portal = REACT_PORTAL_TYPE;
		var Profiler = REACT_PROFILER_TYPE;
		var StrictMode = REACT_STRICT_MODE_TYPE;
		var Suspense = REACT_SUSPENSE_TYPE;
		var hasWarnedAboutDeprecatedIsAsyncMode = false;
		function isAsyncMode(object) {
			if (!hasWarnedAboutDeprecatedIsAsyncMode) {
				hasWarnedAboutDeprecatedIsAsyncMode = true;
				console["warn"]("The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API.");
			}
			return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
		}
		function isConcurrentMode(object) {
			return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
		}
		function isContextConsumer(object) {
			return typeOf(object) === REACT_CONTEXT_TYPE;
		}
		function isContextProvider(object) {
			return typeOf(object) === REACT_PROVIDER_TYPE;
		}
		function isElement(object) {
			return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
		}
		function isForwardRef(object) {
			return typeOf(object) === REACT_FORWARD_REF_TYPE;
		}
		function isFragment(object) {
			return typeOf(object) === REACT_FRAGMENT_TYPE;
		}
		function isLazy(object) {
			return typeOf(object) === REACT_LAZY_TYPE;
		}
		function isMemo(object) {
			return typeOf(object) === REACT_MEMO_TYPE;
		}
		function isPortal(object) {
			return typeOf(object) === REACT_PORTAL_TYPE;
		}
		function isProfiler(object) {
			return typeOf(object) === REACT_PROFILER_TYPE;
		}
		function isStrictMode(object) {
			return typeOf(object) === REACT_STRICT_MODE_TYPE;
		}
		function isSuspense(object) {
			return typeOf(object) === REACT_SUSPENSE_TYPE;
		}
		exports.AsyncMode = AsyncMode;
		exports.ConcurrentMode = ConcurrentMode;
		exports.ContextConsumer = ContextConsumer;
		exports.ContextProvider = ContextProvider;
		exports.Element = Element;
		exports.ForwardRef = ForwardRef;
		exports.Fragment = Fragment;
		exports.Lazy = Lazy;
		exports.Memo = Memo;
		exports.Portal = Portal;
		exports.Profiler = Profiler;
		exports.StrictMode = StrictMode;
		exports.Suspense = Suspense;
		exports.isAsyncMode = isAsyncMode;
		exports.isConcurrentMode = isConcurrentMode;
		exports.isContextConsumer = isContextConsumer;
		exports.isContextProvider = isContextProvider;
		exports.isElement = isElement;
		exports.isForwardRef = isForwardRef;
		exports.isFragment = isFragment;
		exports.isLazy = isLazy;
		exports.isMemo = isMemo;
		exports.isPortal = isPortal;
		exports.isProfiler = isProfiler;
		exports.isStrictMode = isStrictMode;
		exports.isSuspense = isSuspense;
		exports.isValidElementType = isValidElementType;
		exports.typeOf = typeOf;
	})();
}));
//#endregion
//#region node_modules/hoist-non-react-statics/node_modules/react-is/index.js
var require_react_is = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_is_development();
}));
//#endregion
//#region node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js
var require_hoist_non_react_statics_cjs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var reactIs = require_react_is();
	/**
	* Copyright 2015, Yahoo! Inc.
	* Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
	*/
	var REACT_STATICS = {
		childContextTypes: true,
		contextType: true,
		contextTypes: true,
		defaultProps: true,
		displayName: true,
		getDefaultProps: true,
		getDerivedStateFromError: true,
		getDerivedStateFromProps: true,
		mixins: true,
		propTypes: true,
		type: true
	};
	var KNOWN_STATICS = {
		name: true,
		length: true,
		prototype: true,
		caller: true,
		callee: true,
		arguments: true,
		arity: true
	};
	var FORWARD_REF_STATICS = {
		"$$typeof": true,
		render: true,
		defaultProps: true,
		displayName: true,
		propTypes: true
	};
	var MEMO_STATICS = {
		"$$typeof": true,
		compare: true,
		defaultProps: true,
		displayName: true,
		propTypes: true,
		type: true
	};
	var TYPE_STATICS = {};
	TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
	TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;
	function getStatics(component) {
		if (reactIs.isMemo(component)) return MEMO_STATICS;
		return TYPE_STATICS[component["$$typeof"]] || REACT_STATICS;
	}
	var defineProperty = Object.defineProperty;
	var getOwnPropertyNames = Object.getOwnPropertyNames;
	var getOwnPropertySymbols = Object.getOwnPropertySymbols;
	var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
	var getPrototypeOf = Object.getPrototypeOf;
	var objectPrototype = Object.prototype;
	function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
		if (typeof sourceComponent !== "string") {
			if (objectPrototype) {
				var inheritedComponent = getPrototypeOf(sourceComponent);
				if (inheritedComponent && inheritedComponent !== objectPrototype) hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
			}
			var keys = getOwnPropertyNames(sourceComponent);
			if (getOwnPropertySymbols) keys = keys.concat(getOwnPropertySymbols(sourceComponent));
			var targetStatics = getStatics(targetComponent);
			var sourceStatics = getStatics(sourceComponent);
			for (var i = 0; i < keys.length; ++i) {
				var key = keys[i];
				if (!KNOWN_STATICS[key] && !(blacklist && blacklist[key]) && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
					var descriptor = getOwnPropertyDescriptor(sourceComponent, key);
					try {
						defineProperty(targetComponent, key, descriptor);
					} catch (e) {}
				}
			}
		}
		return targetComponent;
	}
	module.exports = hoistNonReactStatics;
}));
//#endregion
//#region node_modules/@emotion/utils/dist/emotion-utils.browser.esm.js
function getRegisteredStyles(registered, registeredStyles, classNames) {
	var rawClassName = "";
	classNames.split(" ").forEach(function(className) {
		if (registered[className] !== void 0) registeredStyles.push(registered[className] + ";");
		else if (className) rawClassName += className + " ";
	});
	return rawClassName;
}
var registerStyles = function registerStyles(cache, serialized, isStringTag) {
	var className = cache.key + "-" + serialized.name;
	if ((isStringTag === false || false) && cache.registered[className] === void 0) cache.registered[className] = serialized.styles;
};
var insertStyles = function insertStyles(cache, serialized, isStringTag) {
	registerStyles(cache, serialized, isStringTag);
	var className = cache.key + "-" + serialized.name;
	if (cache.inserted[serialized.name] === void 0) {
		var current = serialized;
		do {
			cache.insert(serialized === current ? "." + className : "", current, cache.sheet, true);
			current = current.next;
		} while (current !== void 0);
	}
};
//#endregion
//#region node_modules/@emotion/hash/dist/emotion-hash.esm.js
function murmur2(str) {
	var h = 0;
	var k, i = 0, len = str.length;
	for (; len >= 4; ++i, len -= 4) {
		k = str.charCodeAt(i) & 255 | (str.charCodeAt(++i) & 255) << 8 | (str.charCodeAt(++i) & 255) << 16 | (str.charCodeAt(++i) & 255) << 24;
		k = (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16);
		k ^= k >>> 24;
		h = (k & 65535) * 1540483477 + ((k >>> 16) * 59797 << 16) ^ (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
	}
	switch (len) {
		case 3: h ^= (str.charCodeAt(i + 2) & 255) << 16;
		case 2: h ^= (str.charCodeAt(i + 1) & 255) << 8;
		case 1:
			h ^= str.charCodeAt(i) & 255;
			h = (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
	}
	h ^= h >>> 13;
	h = (h & 65535) * 1540483477 + ((h >>> 16) * 59797 << 16);
	return ((h ^ h >>> 15) >>> 0).toString(36);
}
//#endregion
//#region node_modules/@emotion/unitless/dist/emotion-unitless.esm.js
var unitlessKeys = {
	animationIterationCount: 1,
	aspectRatio: 1,
	borderImageOutset: 1,
	borderImageSlice: 1,
	borderImageWidth: 1,
	boxFlex: 1,
	boxFlexGroup: 1,
	boxOrdinalGroup: 1,
	columnCount: 1,
	columns: 1,
	flex: 1,
	flexGrow: 1,
	flexPositive: 1,
	flexShrink: 1,
	flexNegative: 1,
	flexOrder: 1,
	gridRow: 1,
	gridRowEnd: 1,
	gridRowSpan: 1,
	gridRowStart: 1,
	gridColumn: 1,
	gridColumnEnd: 1,
	gridColumnSpan: 1,
	gridColumnStart: 1,
	msGridRow: 1,
	msGridRowSpan: 1,
	msGridColumn: 1,
	msGridColumnSpan: 1,
	fontWeight: 1,
	lineHeight: 1,
	opacity: 1,
	order: 1,
	orphans: 1,
	scale: 1,
	tabSize: 1,
	widows: 1,
	zIndex: 1,
	zoom: 1,
	WebkitLineClamp: 1,
	fillOpacity: 1,
	floodOpacity: 1,
	stopOpacity: 1,
	strokeDasharray: 1,
	strokeDashoffset: 1,
	strokeMiterlimit: 1,
	strokeOpacity: 1,
	strokeWidth: 1
};
//#endregion
//#region node_modules/@emotion/serialize/dist/emotion-serialize.development.esm.js
var isDevelopment$2 = true;
var ILLEGAL_ESCAPE_SEQUENCE_ERROR$1 = "You have illegal escape sequence in your template literal, most likely inside content's property value.\nBecause you write your CSS inside a JavaScript string you actually have to do double escaping, so for example \"content: '\\00d7';\" should become \"content: '\\\\00d7';\".\nYou can read more about this here:\nhttps://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#ES2018_revision_of_illegal_escape_sequences";
var UNDEFINED_AS_OBJECT_KEY_ERROR = "You have passed in falsy value as style object's key (can happen when in example you pass unexported component as computed key).";
var hyphenateRegex = /[A-Z]|^ms/g;
var animationRegex = /_EMO_([^_]+?)_([^]*?)_EMO_/g;
var isCustomProperty = function isCustomProperty(property) {
	return property.charCodeAt(1) === 45;
};
var isProcessableValue = function isProcessableValue(value) {
	return value != null && typeof value !== "boolean";
};
var processStyleName = /* #__PURE__ */ memoize(function(styleName) {
	return isCustomProperty(styleName) ? styleName : styleName.replace(hyphenateRegex, "-$&").toLowerCase();
});
var processStyleValue = function processStyleValue(key, value) {
	switch (key) {
		case "animation":
		case "animationName": if (typeof value === "string") return value.replace(animationRegex, function(match, p1, p2) {
			cursor = {
				name: p1,
				styles: p2,
				next: cursor
			};
			return p1;
		});
	}
	if (unitlessKeys[key] !== 1 && !isCustomProperty(key) && typeof value === "number" && value !== 0) return value + "px";
	return value;
};
var contentValuePattern = /(var|attr|counters?|url|element|(((repeating-)?(linear|radial))|conic)-gradient)\(|(no-)?(open|close)-quote/;
var contentValues = [
	"normal",
	"none",
	"initial",
	"inherit",
	"unset"
];
var oldProcessStyleValue = processStyleValue;
var msPattern = /^-ms-/;
var hyphenPattern = /-(.)/g;
var hyphenatedCache = {};
processStyleValue = function processStyleValue(key, value) {
	if (key === "content") {
		if (typeof value !== "string" || contentValues.indexOf(value) === -1 && !contentValuePattern.test(value) && (value.charAt(0) !== value.charAt(value.length - 1) || value.charAt(0) !== "\"" && value.charAt(0) !== "'")) throw new Error("You seem to be using a value for 'content' without quotes, try replacing it with `content: '\"" + value + "\"'`");
	}
	var processed = oldProcessStyleValue(key, value);
	if (processed !== "" && !isCustomProperty(key) && key.indexOf("-") !== -1 && hyphenatedCache[key] === void 0) {
		hyphenatedCache[key] = true;
		console.error("Using kebab-case for css properties in objects is not supported. Did you mean " + key.replace(msPattern, "ms-").replace(hyphenPattern, function(str, _char) {
			return _char.toUpperCase();
		}) + "?");
	}
	return processed;
};
var noComponentSelectorMessage = "Component selectors can only be used in conjunction with @emotion/babel-plugin, the swc Emotion plugin, or another Emotion-aware compiler transform.";
function handleInterpolation(mergedProps, registered, interpolation) {
	if (interpolation == null) return "";
	var componentSelector = interpolation;
	if (componentSelector.__emotion_styles !== void 0) {
		if (String(componentSelector) === "NO_COMPONENT_SELECTOR") throw new Error(noComponentSelectorMessage);
		return componentSelector;
	}
	switch (typeof interpolation) {
		case "boolean": return "";
		case "object":
			var keyframes = interpolation;
			if (keyframes.anim === 1) {
				cursor = {
					name: keyframes.name,
					styles: keyframes.styles,
					next: cursor
				};
				return keyframes.name;
			}
			var serializedStyles = interpolation;
			if (serializedStyles.styles !== void 0) {
				var next = serializedStyles.next;
				if (next !== void 0) while (next !== void 0) {
					cursor = {
						name: next.name,
						styles: next.styles,
						next: cursor
					};
					next = next.next;
				}
				return serializedStyles.styles + ";";
			}
			return createStringFromObject(mergedProps, registered, interpolation);
		case "function":
			if (mergedProps !== void 0) {
				var previousCursor = cursor;
				var result = interpolation(mergedProps);
				cursor = previousCursor;
				return handleInterpolation(mergedProps, registered, result);
			} else console.error("Functions that are interpolated in css calls will be stringified.\nIf you want to have a css call based on props, create a function that returns a css call like this\nlet dynamicStyle = (props) => css`color: ${props.color}`\nIt can be called directly with props or interpolated in a styled call like this\nlet SomeComponent = styled('div')`${dynamicStyle}`");
			break;
		case "string":
			var matched = [];
			var replaced = interpolation.replace(animationRegex, function(_match, _p1, p2) {
				var fakeVarName = "animation" + matched.length;
				matched.push("const " + fakeVarName + " = keyframes`" + p2.replace(/^@keyframes animation-\w+/, "") + "`");
				return "${" + fakeVarName + "}";
			});
			if (matched.length) console.error("`keyframes` output got interpolated into plain string, please wrap it with `css`.\n\nInstead of doing this:\n\n" + [].concat(matched, ["`" + replaced + "`"]).join("\n") + "\n\nYou should wrap it with `css` like this:\n\ncss`" + replaced + "`");
			break;
	}
	var asString = interpolation;
	if (registered == null) return asString;
	var cached = registered[asString];
	return cached !== void 0 ? cached : asString;
}
function createStringFromObject(mergedProps, registered, obj) {
	var string = "";
	if (Array.isArray(obj)) for (var i = 0; i < obj.length; i++) string += handleInterpolation(mergedProps, registered, obj[i]) + ";";
	else for (var key in obj) {
		var value = obj[key];
		if (typeof value !== "object") {
			var asString = value;
			if (registered != null && registered[asString] !== void 0) string += key + "{" + registered[asString] + "}";
			else if (isProcessableValue(asString)) string += processStyleName(key) + ":" + processStyleValue(key, asString) + ";";
		} else {
			if (key === "NO_COMPONENT_SELECTOR" && isDevelopment$2) throw new Error(noComponentSelectorMessage);
			if (Array.isArray(value) && typeof value[0] === "string" && (registered == null || registered[value[0]] === void 0)) {
				for (var _i = 0; _i < value.length; _i++) if (isProcessableValue(value[_i])) string += processStyleName(key) + ":" + processStyleValue(key, value[_i]) + ";";
			} else {
				var interpolated = handleInterpolation(mergedProps, registered, value);
				switch (key) {
					case "animation":
					case "animationName":
						string += processStyleName(key) + ":" + interpolated + ";";
						break;
					default:
						if (key === "undefined") console.error(UNDEFINED_AS_OBJECT_KEY_ERROR);
						string += key + "{" + interpolated + "}";
				}
			}
		}
	}
	return string;
}
var labelPattern = /label:\s*([^\s;{]+)\s*(;|$)/g;
var cursor;
function serializeStyles(args, registered, mergedProps) {
	if (args.length === 1 && typeof args[0] === "object" && args[0] !== null && args[0].styles !== void 0) return args[0];
	var stringMode = true;
	var styles = "";
	cursor = void 0;
	var strings = args[0];
	if (strings == null || strings.raw === void 0) {
		stringMode = false;
		styles += handleInterpolation(mergedProps, registered, strings);
	} else {
		var asTemplateStringsArr = strings;
		if (asTemplateStringsArr[0] === void 0) console.error(ILLEGAL_ESCAPE_SEQUENCE_ERROR$1);
		styles += asTemplateStringsArr[0];
	}
	for (var i = 1; i < args.length; i++) {
		styles += handleInterpolation(mergedProps, registered, args[i]);
		if (stringMode) {
			var templateStringsArr = strings;
			if (templateStringsArr[i] === void 0) console.error(ILLEGAL_ESCAPE_SEQUENCE_ERROR$1);
			styles += templateStringsArr[i];
		}
	}
	labelPattern.lastIndex = 0;
	var identifierName = "";
	var match;
	while ((match = labelPattern.exec(styles)) !== null) identifierName += "-" + match[1];
	return {
		name: murmur2(styles) + identifierName,
		styles,
		next: cursor,
		toString: function toString() {
			return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop).";
		}
	};
}
//#endregion
//#region node_modules/@emotion/use-insertion-effect-with-fallbacks/dist/emotion-use-insertion-effect-with-fallbacks.browser.esm.js
var syncFallback = function syncFallback(create) {
	return create();
};
var useInsertionEffect = import_react.useInsertionEffect ? import_react.useInsertionEffect : false;
var useInsertionEffectAlwaysWithSyncFallback = useInsertionEffect || syncFallback;
var useInsertionEffectWithLayoutFallback = useInsertionEffect || import_react.useLayoutEffect;
//#endregion
//#region node_modules/@emotion/react/dist/emotion-element-489459f2.browser.development.esm.js
var EmotionCacheContext = /* #__PURE__ */ import_react.createContext(typeof HTMLElement !== "undefined" ? /* #__PURE__ */ createCache({ key: "css" }) : null);
EmotionCacheContext.displayName = "EmotionCacheContext";
var CacheProvider = EmotionCacheContext.Provider;
var withEmotionCache = function withEmotionCache(func) {
	return /*#__PURE__*/ (0, import_react.forwardRef)(function(props, ref) {
		return func(props, (0, import_react.useContext)(EmotionCacheContext), ref);
	});
};
var ThemeContext = /* #__PURE__ */ import_react.createContext({});
ThemeContext.displayName = "EmotionThemeContext";
var hasOwn = {}.hasOwnProperty;
var getLastPart = function getLastPart(functionName) {
	var parts = functionName.split(".");
	return parts[parts.length - 1];
};
var getFunctionNameFromStackTraceLine = function getFunctionNameFromStackTraceLine(line) {
	var match = /^\s+at\s+([A-Za-z0-9$.]+)\s/.exec(line);
	if (match) return getLastPart(match[1]);
	match = /^([A-Za-z0-9$.]+)@/.exec(line);
	if (match) return getLastPart(match[1]);
};
var internalReactFunctionNames = /* #__PURE__ */ new Set([
	"renderWithHooks",
	"processChild",
	"finishClassComponent",
	"renderToString"
]);
var sanitizeIdentifier = function sanitizeIdentifier(identifier) {
	return identifier.replace(/\$/g, "-");
};
var getLabelFromStackTrace = function getLabelFromStackTrace(stackTrace) {
	if (!stackTrace) return void 0;
	var lines = stackTrace.split("\n");
	for (var i = 0; i < lines.length; i++) {
		var functionName = getFunctionNameFromStackTraceLine(lines[i]);
		if (!functionName) continue;
		if (internalReactFunctionNames.has(functionName)) break;
		if (/^[A-Z]/.test(functionName)) return sanitizeIdentifier(functionName);
	}
};
var typePropName = "__EMOTION_TYPE_PLEASE_DO_NOT_USE__";
var labelPropName = "__EMOTION_LABEL_PLEASE_DO_NOT_USE__";
var createEmotionProps = function createEmotionProps(type, props) {
	if (typeof props.css === "string" && props.css.indexOf(":") !== -1) throw new Error("Strings are not allowed as css prop values, please wrap it in a css template literal from '@emotion/react' like this: css`" + props.css + "`");
	var newProps = {};
	for (var _key in props) if (hasOwn.call(props, _key)) newProps[_key] = props[_key];
	newProps[typePropName] = type;
	if (typeof globalThis !== "undefined" && !!globalThis.EMOTION_RUNTIME_AUTO_LABEL && !!props.css && (typeof props.css !== "object" || !("name" in props.css) || typeof props.css.name !== "string" || props.css.name.indexOf("-") === -1)) {
		var label = getLabelFromStackTrace((/* @__PURE__ */ new Error()).stack);
		if (label) newProps[labelPropName] = label;
	}
	return newProps;
};
var Insertion$2 = function Insertion(_ref) {
	var cache = _ref.cache, serialized = _ref.serialized, isStringTag = _ref.isStringTag;
	registerStyles(cache, serialized, isStringTag);
	useInsertionEffectAlwaysWithSyncFallback(function() {
		return insertStyles(cache, serialized, isStringTag);
	});
	return null;
};
var Emotion = /* #__PURE__ */ withEmotionCache(function(props, cache, ref) {
	var cssProp = props.css;
	if (typeof cssProp === "string" && cache.registered[cssProp] !== void 0) cssProp = cache.registered[cssProp];
	var WrappedComponent = props[typePropName];
	var registeredStyles = [cssProp];
	var className = "";
	if (typeof props.className === "string") className = getRegisteredStyles(cache.registered, registeredStyles, props.className);
	else if (props.className != null) className = props.className + " ";
	var serialized = serializeStyles(registeredStyles, void 0, import_react.useContext(ThemeContext));
	if (serialized.name.indexOf("-") === -1) {
		var labelFromStack = props[labelPropName];
		if (labelFromStack) serialized = serializeStyles([serialized, "label:" + labelFromStack + ";"]);
	}
	className += cache.key + "-" + serialized.name;
	var newProps = {};
	for (var _key2 in props) if (hasOwn.call(props, _key2) && _key2 !== "css" && _key2 !== typePropName && _key2 !== labelPropName) newProps[_key2] = props[_key2];
	newProps.className = className;
	if (ref) newProps.ref = ref;
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(Insertion$2, {
		cache,
		serialized,
		isStringTag: typeof WrappedComponent === "string"
	}), /*#__PURE__*/ import_react.createElement(WrappedComponent, newProps));
});
Emotion.displayName = "EmotionCssPropInternal";
var Emotion$1 = Emotion;
require_hoist_non_react_statics_cjs();
var isDevelopment$1 = true;
var pkg = {
	name: "@emotion/react",
	version: "11.14.0",
	main: "dist/emotion-react.cjs.js",
	module: "dist/emotion-react.esm.js",
	types: "dist/emotion-react.cjs.d.ts",
	exports: {
		".": {
			types: {
				"import": "./dist/emotion-react.cjs.mjs",
				"default": "./dist/emotion-react.cjs.js"
			},
			development: {
				"edge-light": {
					module: "./dist/emotion-react.development.edge-light.esm.js",
					"import": "./dist/emotion-react.development.edge-light.cjs.mjs",
					"default": "./dist/emotion-react.development.edge-light.cjs.js"
				},
				worker: {
					module: "./dist/emotion-react.development.edge-light.esm.js",
					"import": "./dist/emotion-react.development.edge-light.cjs.mjs",
					"default": "./dist/emotion-react.development.edge-light.cjs.js"
				},
				workerd: {
					module: "./dist/emotion-react.development.edge-light.esm.js",
					"import": "./dist/emotion-react.development.edge-light.cjs.mjs",
					"default": "./dist/emotion-react.development.edge-light.cjs.js"
				},
				browser: {
					module: "./dist/emotion-react.browser.development.esm.js",
					"import": "./dist/emotion-react.browser.development.cjs.mjs",
					"default": "./dist/emotion-react.browser.development.cjs.js"
				},
				module: "./dist/emotion-react.development.esm.js",
				"import": "./dist/emotion-react.development.cjs.mjs",
				"default": "./dist/emotion-react.development.cjs.js"
			},
			"edge-light": {
				module: "./dist/emotion-react.edge-light.esm.js",
				"import": "./dist/emotion-react.edge-light.cjs.mjs",
				"default": "./dist/emotion-react.edge-light.cjs.js"
			},
			worker: {
				module: "./dist/emotion-react.edge-light.esm.js",
				"import": "./dist/emotion-react.edge-light.cjs.mjs",
				"default": "./dist/emotion-react.edge-light.cjs.js"
			},
			workerd: {
				module: "./dist/emotion-react.edge-light.esm.js",
				"import": "./dist/emotion-react.edge-light.cjs.mjs",
				"default": "./dist/emotion-react.edge-light.cjs.js"
			},
			browser: {
				module: "./dist/emotion-react.browser.esm.js",
				"import": "./dist/emotion-react.browser.cjs.mjs",
				"default": "./dist/emotion-react.browser.cjs.js"
			},
			module: "./dist/emotion-react.esm.js",
			"import": "./dist/emotion-react.cjs.mjs",
			"default": "./dist/emotion-react.cjs.js"
		},
		"./jsx-runtime": {
			types: {
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.cjs.js"
			},
			development: {
				"edge-light": {
					module: "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.esm.js",
					"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.js"
				},
				worker: {
					module: "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.esm.js",
					"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.js"
				},
				workerd: {
					module: "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.esm.js",
					"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.edge-light.cjs.js"
				},
				browser: {
					module: "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.development.esm.js",
					"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.development.cjs.mjs",
					"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.development.cjs.js"
				},
				module: "./jsx-runtime/dist/emotion-react-jsx-runtime.development.esm.js",
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.development.cjs.js"
			},
			"edge-light": {
				module: "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.esm.js",
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.js"
			},
			worker: {
				module: "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.esm.js",
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.js"
			},
			workerd: {
				module: "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.esm.js",
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.edge-light.cjs.js"
			},
			browser: {
				module: "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.esm.js",
				"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.cjs.mjs",
				"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.browser.cjs.js"
			},
			module: "./jsx-runtime/dist/emotion-react-jsx-runtime.esm.js",
			"import": "./jsx-runtime/dist/emotion-react-jsx-runtime.cjs.mjs",
			"default": "./jsx-runtime/dist/emotion-react-jsx-runtime.cjs.js"
		},
		"./_isolated-hnrs": {
			types: {
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.cjs.js"
			},
			development: {
				"edge-light": {
					module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.esm.js",
					"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.mjs",
					"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.js"
				},
				worker: {
					module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.esm.js",
					"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.mjs",
					"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.js"
				},
				workerd: {
					module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.esm.js",
					"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.mjs",
					"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.edge-light.cjs.js"
				},
				browser: {
					module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.development.esm.js",
					"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.development.cjs.mjs",
					"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.development.cjs.js"
				},
				module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.esm.js",
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.development.cjs.js"
			},
			"edge-light": {
				module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.esm.js",
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.js"
			},
			worker: {
				module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.esm.js",
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.js"
			},
			workerd: {
				module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.esm.js",
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.edge-light.cjs.js"
			},
			browser: {
				module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.esm.js",
				"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.cjs.mjs",
				"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.browser.cjs.js"
			},
			module: "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.esm.js",
			"import": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.cjs.mjs",
			"default": "./_isolated-hnrs/dist/emotion-react-_isolated-hnrs.cjs.js"
		},
		"./jsx-dev-runtime": {
			types: {
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.cjs.js"
			},
			development: {
				"edge-light": {
					module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.esm.js",
					"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.js"
				},
				worker: {
					module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.esm.js",
					"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.js"
				},
				workerd: {
					module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.esm.js",
					"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.mjs",
					"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.edge-light.cjs.js"
				},
				browser: {
					module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.development.esm.js",
					"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.development.cjs.mjs",
					"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.development.cjs.js"
				},
				module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.esm.js",
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.development.cjs.js"
			},
			"edge-light": {
				module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.esm.js",
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.js"
			},
			worker: {
				module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.esm.js",
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.js"
			},
			workerd: {
				module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.esm.js",
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.edge-light.cjs.js"
			},
			browser: {
				module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.esm.js",
				"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.cjs.mjs",
				"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.cjs.js"
			},
			module: "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.esm.js",
			"import": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.cjs.mjs",
			"default": "./jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.cjs.js"
		},
		"./package.json": "./package.json",
		"./types/css-prop": "./types/css-prop.d.ts",
		"./macro": {
			types: {
				"import": "./macro.d.mts",
				"default": "./macro.d.ts"
			},
			"default": "./macro.js"
		}
	},
	imports: {
		"#is-development": {
			development: "./src/conditions/true.ts",
			"default": "./src/conditions/false.ts"
		},
		"#is-browser": {
			"edge-light": "./src/conditions/false.ts",
			workerd: "./src/conditions/false.ts",
			worker: "./src/conditions/false.ts",
			browser: "./src/conditions/true.ts",
			"default": "./src/conditions/is-browser.ts"
		}
	},
	files: [
		"src",
		"dist",
		"jsx-runtime",
		"jsx-dev-runtime",
		"_isolated-hnrs",
		"types/css-prop.d.ts",
		"macro.*"
	],
	sideEffects: false,
	author: "Emotion Contributors",
	license: "MIT",
	scripts: { "test:typescript": "dtslint types" },
	dependencies: {
		"@babel/runtime": "^7.18.3",
		"@emotion/babel-plugin": "^11.13.5",
		"@emotion/cache": "^11.14.0",
		"@emotion/serialize": "^1.3.3",
		"@emotion/use-insertion-effect-with-fallbacks": "^1.2.0",
		"@emotion/utils": "^1.4.2",
		"@emotion/weak-memoize": "^0.4.0",
		"hoist-non-react-statics": "^3.3.1"
	},
	peerDependencies: { react: ">=16.8.0" },
	peerDependenciesMeta: { "@types/react": { optional: true } },
	devDependencies: {
		"@definitelytyped/dtslint": "0.0.112",
		"@emotion/css": "11.13.5",
		"@emotion/css-prettifier": "1.2.0",
		"@emotion/server": "11.11.0",
		"@emotion/styled": "11.14.0",
		"@types/hoist-non-react-statics": "^3.3.5",
		"html-tag-names": "^1.1.2",
		react: "16.14.0",
		"svg-tag-names": "^1.1.1",
		typescript: "^5.4.5"
	},
	repository: "https://github.com/emotion-js/emotion/tree/main/packages/react",
	publishConfig: { access: "public" },
	"umd:main": "dist/emotion-react.umd.min.js",
	preconstruct: {
		entrypoints: [
			"./index.ts",
			"./jsx-runtime.ts",
			"./jsx-dev-runtime.ts",
			"./_isolated-hnrs.ts"
		],
		umdName: "emotionReact",
		exports: { extra: {
			"./types/css-prop": "./types/css-prop.d.ts",
			"./macro": {
				types: {
					"import": "./macro.d.mts",
					"default": "./macro.d.ts"
				},
				"default": "./macro.js"
			}
		} }
	}
};
var jsx = function jsx(type, props) {
	var args = arguments;
	if (props == null || !hasOwn.call(props, "css")) return import_react.createElement.apply(void 0, args);
	var argsLength = args.length;
	var createElementArgArray = new Array(argsLength);
	createElementArgArray[0] = Emotion$1;
	createElementArgArray[1] = createEmotionProps(type, props);
	for (var i = 2; i < argsLength; i++) createElementArgArray[i] = args[i];
	return import_react.createElement.apply(null, createElementArgArray);
};
(function(_jsx) {
	var JSX;
	JSX || (JSX = _jsx.JSX || (_jsx.JSX = {}));
})(jsx || (jsx = {}));
var warnedAboutCssPropForGlobal = false;
var Global = /* #__PURE__ */ withEmotionCache(function(props, cache) {
	if (!warnedAboutCssPropForGlobal && ("className" in props && props.className || "css" in props && props.css)) {
		console.error("It looks like you're using the css prop on Global, did you mean to use the styles prop instead?");
		warnedAboutCssPropForGlobal = true;
	}
	var styles = props.styles;
	var serialized = serializeStyles([styles], void 0, import_react.useContext(ThemeContext));
	var sheetRef = import_react.useRef();
	useInsertionEffectWithLayoutFallback(function() {
		var key = cache.key + "-global";
		var sheet = new cache.sheet.constructor({
			key,
			nonce: cache.sheet.nonce,
			container: cache.sheet.container,
			speedy: cache.sheet.isSpeedy
		});
		var rehydrating = false;
		var node = document.querySelector("style[data-emotion=\"" + key + " " + serialized.name + "\"]");
		if (cache.sheet.tags.length) sheet.before = cache.sheet.tags[0];
		if (node !== null) {
			rehydrating = true;
			node.setAttribute("data-emotion", key);
			sheet.hydrate([node]);
		}
		sheetRef.current = [sheet, rehydrating];
		return function() {
			sheet.flush();
		};
	}, [cache]);
	useInsertionEffectWithLayoutFallback(function() {
		var sheetRefCurrent = sheetRef.current;
		var sheet = sheetRefCurrent[0];
		if (sheetRefCurrent[1]) {
			sheetRefCurrent[1] = false;
			return;
		}
		if (serialized.next !== void 0) insertStyles(cache, serialized.next, true);
		if (sheet.tags.length) {
			sheet.before = sheet.tags[sheet.tags.length - 1].nextElementSibling;
			sheet.flush();
		}
		cache.insert("", serialized, sheet, false);
	}, [cache, serialized.name]);
	return null;
});
Global.displayName = "EmotionGlobal";
function css() {
	for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
	return serializeStyles(args);
}
function keyframes() {
	var insertable = css.apply(void 0, arguments);
	var name = "animation-" + insertable.name;
	return {
		name,
		styles: "@keyframes " + name + "{" + insertable.styles + "}",
		anim: 1,
		toString: function toString() {
			return "_EMO_" + this.name + "_" + this.styles + "_EMO_";
		}
	};
}
var classnames = function classnames(args) {
	var len = args.length;
	var i = 0;
	var cls = "";
	for (; i < len; i++) {
		var arg = args[i];
		if (arg == null) continue;
		var toAdd = void 0;
		switch (typeof arg) {
			case "boolean": break;
			case "object":
				if (Array.isArray(arg)) toAdd = classnames(arg);
				else {
					if (arg.styles !== void 0 && arg.name !== void 0) console.error("You have passed styles created with `css` from `@emotion/react` package to the `cx`.\n`cx` is meant to compose class names (strings) so you should convert those styles to a class name by passing them to the `css` received from <ClassNames/> component.");
					toAdd = "";
					for (var k in arg) if (arg[k] && k) {
						toAdd && (toAdd += " ");
						toAdd += k;
					}
				}
				break;
			default: toAdd = arg;
		}
		if (toAdd) {
			cls && (cls += " ");
			cls += toAdd;
		}
	}
	return cls;
};
function merge(registered, css, className) {
	var registeredStyles = [];
	var rawClassName = getRegisteredStyles(registered, registeredStyles, className);
	if (registeredStyles.length < 2) return className;
	return rawClassName + css(registeredStyles);
}
var Insertion$1 = function Insertion(_ref) {
	var cache = _ref.cache, serializedArr = _ref.serializedArr;
	useInsertionEffectAlwaysWithSyncFallback(function() {
		for (var i = 0; i < serializedArr.length; i++) insertStyles(cache, serializedArr[i], false);
	});
	return null;
};
var ClassNames = /* #__PURE__ */ withEmotionCache(function(props, cache) {
	var hasRendered = false;
	var serializedArr = [];
	var css = function css() {
		if (hasRendered && isDevelopment$1) throw new Error("css can only be used during render");
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		var serialized = serializeStyles(args, cache.registered);
		serializedArr.push(serialized);
		registerStyles(cache, serialized, false);
		return cache.key + "-" + serialized.name;
	};
	var content = {
		css,
		cx: function cx() {
			if (hasRendered && isDevelopment$1) throw new Error("cx can only be used during render");
			for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
			return merge(cache.registered, css, classnames(args));
		},
		theme: import_react.useContext(ThemeContext)
	};
	var ele = props.children(content);
	hasRendered = true;
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(Insertion$1, {
		cache,
		serializedArr
	}), ele);
});
ClassNames.displayName = "EmotionClassNames";
var isBrowser = typeof document !== "undefined";
if (isBrowser && !(typeof jest !== "undefined" || typeof vi !== "undefined")) {
	var globalContext = typeof globalThis !== "undefined" ? globalThis : isBrowser ? window : global;
	var globalKey = "__EMOTION_REACT_" + pkg.version.split(".")[0] + "__";
	if (globalContext[globalKey]) console.warn("You are loading @emotion/react when it is already loaded. Running multiple instances may cause problems. This can happen if multiple versions are used, or if multiple builds of the same version are used.");
	globalContext[globalKey] = true;
}
//#endregion
//#region node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js
var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;
var isPropValid = /* #__PURE__ */ memoize(function(prop) {
	return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110 && prop.charCodeAt(2) < 91;
});
//#endregion
//#region node_modules/@emotion/styled/base/dist/emotion-styled-base.browser.development.esm.js
var isDevelopment = true;
var testOmitPropsOnStringTag = isPropValid;
var testOmitPropsOnComponent = function testOmitPropsOnComponent(key) {
	return key !== "theme";
};
var getDefaultShouldForwardProp = function getDefaultShouldForwardProp(tag) {
	return typeof tag === "string" && tag.charCodeAt(0) > 96 ? testOmitPropsOnStringTag : testOmitPropsOnComponent;
};
var composeShouldForwardProps = function composeShouldForwardProps(tag, options, isReal) {
	var shouldForwardProp;
	if (options) {
		var optionsShouldForwardProp = options.shouldForwardProp;
		shouldForwardProp = tag.__emotion_forwardProp && optionsShouldForwardProp ? function(propName) {
			return tag.__emotion_forwardProp(propName) && optionsShouldForwardProp(propName);
		} : optionsShouldForwardProp;
	}
	if (typeof shouldForwardProp !== "function" && isReal) shouldForwardProp = tag.__emotion_forwardProp;
	return shouldForwardProp;
};
var ILLEGAL_ESCAPE_SEQUENCE_ERROR = "You have illegal escape sequence in your template literal, most likely inside content's property value.\nBecause you write your CSS inside a JavaScript string you actually have to do double escaping, so for example \"content: '\\00d7';\" should become \"content: '\\\\00d7';\".\nYou can read more about this here:\nhttps://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals#ES2018_revision_of_illegal_escape_sequences";
var Insertion = function Insertion(_ref) {
	var cache = _ref.cache, serialized = _ref.serialized, isStringTag = _ref.isStringTag;
	registerStyles(cache, serialized, isStringTag);
	useInsertionEffectAlwaysWithSyncFallback(function() {
		return insertStyles(cache, serialized, isStringTag);
	});
	return null;
};
var createStyled$1 = function createStyled(tag, options) {
	if (tag === void 0) throw new Error("You are trying to create a styled element with an undefined component.\nYou may have forgotten to import it.");
	var isReal = tag.__emotion_real === tag;
	var baseTag = isReal && tag.__emotion_base || tag;
	var identifierName;
	var targetClassName;
	if (options !== void 0) {
		identifierName = options.label;
		targetClassName = options.target;
	}
	var shouldForwardProp = composeShouldForwardProps(tag, options, isReal);
	var defaultShouldForwardProp = shouldForwardProp || getDefaultShouldForwardProp(baseTag);
	var shouldUseAs = !defaultShouldForwardProp("as");
	return function() {
		var args = arguments;
		var styles = isReal && tag.__emotion_styles !== void 0 ? tag.__emotion_styles.slice(0) : [];
		if (identifierName !== void 0) styles.push("label:" + identifierName + ";");
		if (args[0] == null || args[0].raw === void 0) styles.push.apply(styles, args);
		else {
			var templateStringsArr = args[0];
			if (templateStringsArr[0] === void 0) console.error(ILLEGAL_ESCAPE_SEQUENCE_ERROR);
			styles.push(templateStringsArr[0]);
			var len = args.length;
			var i = 1;
			for (; i < len; i++) {
				if (templateStringsArr[i] === void 0) console.error(ILLEGAL_ESCAPE_SEQUENCE_ERROR);
				styles.push(args[i], templateStringsArr[i]);
			}
		}
		var Styled = withEmotionCache(function(props, cache, ref) {
			var FinalTag = shouldUseAs && props.as || baseTag;
			var className = "";
			var classInterpolations = [];
			var mergedProps = props;
			if (props.theme == null) {
				mergedProps = {};
				for (var key in props) mergedProps[key] = props[key];
				mergedProps.theme = import_react.useContext(ThemeContext);
			}
			if (typeof props.className === "string") className = getRegisteredStyles(cache.registered, classInterpolations, props.className);
			else if (props.className != null) className = props.className + " ";
			var serialized = serializeStyles(styles.concat(classInterpolations), cache.registered, mergedProps);
			className += cache.key + "-" + serialized.name;
			if (targetClassName !== void 0) className += " " + targetClassName;
			var finalShouldForwardProp = shouldUseAs && shouldForwardProp === void 0 ? getDefaultShouldForwardProp(FinalTag) : defaultShouldForwardProp;
			var newProps = {};
			for (var _key in props) {
				if (shouldUseAs && _key === "as") continue;
				if (finalShouldForwardProp(_key)) newProps[_key] = props[_key];
			}
			newProps.className = className;
			if (ref) newProps.ref = ref;
			return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(Insertion, {
				cache,
				serialized,
				isStringTag: typeof FinalTag === "string"
			}), /*#__PURE__*/ import_react.createElement(FinalTag, newProps));
		});
		Styled.displayName = identifierName !== void 0 ? identifierName : "Styled(" + (typeof baseTag === "string" ? baseTag : baseTag.displayName || baseTag.name || "Component") + ")";
		Styled.defaultProps = tag.defaultProps;
		Styled.__emotion_real = Styled;
		Styled.__emotion_base = baseTag;
		Styled.__emotion_styles = styles;
		Styled.__emotion_forwardProp = shouldForwardProp;
		Object.defineProperty(Styled, "toString", { value: function value() {
			if (targetClassName === void 0 && isDevelopment) return "NO_COMPONENT_SELECTOR";
			return "." + targetClassName;
		} });
		Styled.withComponent = function(nextTag, nextOptions) {
			return createStyled(nextTag, _extends({}, options, nextOptions, { shouldForwardProp: composeShouldForwardProps(Styled, nextOptions, true) })).apply(void 0, styles);
		};
		return Styled;
	};
};
//#endregion
//#region node_modules/@emotion/styled/dist/emotion-styled.browser.development.esm.js
var tags = [
	"a",
	"abbr",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"base",
	"bdi",
	"bdo",
	"big",
	"blockquote",
	"body",
	"br",
	"button",
	"canvas",
	"caption",
	"cite",
	"code",
	"col",
	"colgroup",
	"data",
	"datalist",
	"dd",
	"del",
	"details",
	"dfn",
	"dialog",
	"div",
	"dl",
	"dt",
	"em",
	"embed",
	"fieldset",
	"figcaption",
	"figure",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"head",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"iframe",
	"img",
	"input",
	"ins",
	"kbd",
	"keygen",
	"label",
	"legend",
	"li",
	"link",
	"main",
	"map",
	"mark",
	"marquee",
	"menu",
	"menuitem",
	"meta",
	"meter",
	"nav",
	"noscript",
	"object",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"param",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"script",
	"section",
	"select",
	"small",
	"source",
	"span",
	"strong",
	"style",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"title",
	"tr",
	"track",
	"u",
	"ul",
	"var",
	"video",
	"wbr",
	"circle",
	"clipPath",
	"defs",
	"ellipse",
	"foreignObject",
	"g",
	"image",
	"line",
	"linearGradient",
	"mask",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"stop",
	"svg",
	"text",
	"tspan"
];
var styled$2 = createStyled$1.bind(null);
tags.forEach(function(tagName) {
	styled$2[tagName] = styled$2(tagName);
});
//#endregion
//#region node_modules/@mui/styled-engine/index.mjs
/**
* @mui/styled-engine v9.3.0
*
* @license MIT
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
function styled$1(tag, options) {
	const stylesFactory = styled$2(tag, options);
	return (...styles) => {
		const component = typeof tag === "string" ? `"${tag}"` : "component";
		if (styles.length === 0) console.error([`MUI: Seems like you called \`styled(${component})()\` without a \`style\` argument.`, "You must provide a `styles` argument: `styled(\"div\")(styleYouForgotToPass)`."].join("\n"));
		else if (styles.some((style) => style === void 0)) console.error(`MUI: the styled(${component})(...args) API requires all its args to be defined.`);
		return stylesFactory(...styles);
	};
}
/**
* For internal usage in `@mui/system` package
*/
function internal_mutateStyles(tag, processor) {
	if (Array.isArray(tag.__emotion_styles)) tag.__emotion_styles = processor(tag.__emotion_styles);
}
var wrapper = [];
function internal_serializeStyles(styles) {
	wrapper[0] = styles;
	return serializeStyles(wrapper);
}
/** Same as StyledOptions but shouldForwardProp must be a type guard */
/**
* @typeparam ComponentProps  Props which will be included when withComponent is called
* @typeparam SpecificComponentProps  Props which will *not* be included when withComponent is called
*/
//#endregion
//#region node_modules/@mui/system/createTheme/shape.mjs
var shape = { borderRadius: 4 };
//#endregion
//#region node_modules/@mui/system/createTheme/createSpacing.mjs
function createSpacing(spacingInput = 8, transform = createUnarySpacing({ spacing: spacingInput })) {
	if (spacingInput.mui) return spacingInput;
	const spacing = (...argsInput) => {
		if (!(argsInput.length <= 4)) console.error(`MUI: Too many arguments provided, expected between 0 and 4, got ${argsInput.length}`);
		return (argsInput.length === 0 ? [1] : argsInput).map((argument) => {
			const output = transform(argument);
			return typeof output === "number" ? `${output}px` : output;
		}).join(" ");
	};
	spacing.mui = true;
	return spacing;
}
//#endregion
//#region node_modules/@mui/system/createTheme/applyStyles.mjs
/**
* A universal utility to style components with multiple color modes. Always use it from the theme object.
* It works with:
*  - [Basic theme](https://mui.com/material-ui/customization/dark-mode/)
*  - [CSS theme variables](https://mui.com/material-ui/customization/css-theme-variables/overview/)
*  - Zero-runtime engine
*
* Tips: Use an array over object spread and place `theme.applyStyles()` last.
*
* With the styled function:
* ✅ [{ background: '#e5e5e5' }, theme.applyStyles('dark', { background: '#1c1c1c' })]
* 🚫 { background: '#e5e5e5', ...theme.applyStyles('dark', { background: '#1c1c1c' })}
*
* With the sx prop:
* ✅ [{ background: '#e5e5e5' }, theme => theme.applyStyles('dark', { background: '#1c1c1c' })]
* 🚫 { background: '#e5e5e5', ...theme => theme.applyStyles('dark', { background: '#1c1c1c' })}
*
* @example
* 1. using with `styled`:
* ```jsx
*   const Component = styled('div')(({ theme }) => [
*     { background: '#e5e5e5' },
*     theme.applyStyles('dark', {
*       background: '#1c1c1c',
*       color: '#fff',
*     }),
*   ]);
* ```
*
* @example
* 2. using with `sx` prop:
* ```jsx
*   <Box sx={[
*     { background: '#e5e5e5' },
*     theme => theme.applyStyles('dark', {
*        background: '#1c1c1c',
*        color: '#fff',
*      }),
*     ]}
*   />
* ```
*
* @example
* 3. theming a component:
* ```jsx
*   extendTheme({
*     components: {
*       MuiButton: {
*         styleOverrides: {
*           root: ({ theme }) => [
*             { background: '#e5e5e5' },
*             theme.applyStyles('dark', {
*               background: '#1c1c1c',
*               color: '#fff',
*             }),
*           ],
*         },
*       }
*     }
*   })
*```
*/
function applyStyles(key, styles) {
	const theme = this;
	if (theme.vars) {
		if (!theme.colorSchemes?.[key] || typeof theme.getColorSchemeSelector !== "function") return {};
		let selector = theme.getColorSchemeSelector(key);
		if (selector === "&") return styles;
		if (selector.includes("data-") || selector.includes(".")) selector = `*:where(${selector.replace(/\s*&$/, "")}) &`;
		return { [selector]: styles };
	}
	if (theme.palette.mode === key) return styles;
	return {};
}
//#endregion
//#region node_modules/@mui/system/createTheme/createTheme.mjs
function createTheme$1(options = {}, ...args) {
	const { breakpoints: breakpointsInput = {}, palette: paletteInput = {}, spacing: spacingInput, shape: shapeInput = {}, ...other } = options;
	const breakpoints = createBreakpoints(breakpointsInput);
	const spacing = createSpacing(spacingInput);
	let muiTheme = deepmerge({
		breakpoints,
		direction: "ltr",
		components: {},
		palette: {
			mode: "light",
			...paletteInput
		},
		spacing,
		shape: {
			...shape,
			...shapeInput
		}
	}, other);
	muiTheme = cssContainerQueries(muiTheme);
	muiTheme.applyStyles = applyStyles;
	muiTheme = args.reduce((acc, argument) => deepmerge(acc, argument), muiTheme);
	muiTheme.unstable_sxConfig = {
		...defaultSxConfig,
		...other?.unstable_sxConfig
	};
	muiTheme.unstable_sx = function sx(props) {
		return styleFunctionSx_default({
			sx: props,
			theme: this
		});
	};
	muiTheme.internal_cache = {};
	return muiTheme;
}
//#endregion
//#region node_modules/@mui/utils/ClassNameGenerator/ClassNameGenerator.mjs
var defaultGenerator = (componentName) => componentName;
var createClassNameGenerator = () => {
	let generate = defaultGenerator;
	return {
		configure(generator) {
			generate = generator;
		},
		generate(componentName) {
			return generate(componentName);
		},
		reset() {
			generate = defaultGenerator;
		}
	};
};
var ClassNameGenerator = createClassNameGenerator();
//#endregion
//#region node_modules/@mui/utils/generateUtilityClass/generateUtilityClass.mjs
var globalStateClasses = {
	active: "active",
	checked: "checked",
	completed: "completed",
	disabled: "disabled",
	error: "error",
	expanded: "expanded",
	focused: "focused",
	focusVisible: "focusVisible",
	open: "open",
	readOnly: "readOnly",
	required: "required",
	selected: "selected"
};
function generateUtilityClass(componentName, slot, globalStatePrefix = "Mui") {
	const globalStateClass = globalStateClasses[slot];
	return globalStateClass ? `${globalStatePrefix}-${globalStateClass}` : `${ClassNameGenerator.generate(componentName)}-${slot}`;
}
//#endregion
//#region node_modules/@mui/utils/generateUtilityClasses/generateUtilityClasses.mjs
function generateUtilityClasses(componentName, slots, globalStatePrefix = "Mui") {
	const result = {};
	slots.forEach((slot) => {
		result[slot] = generateUtilityClass(componentName, slot, globalStatePrefix);
	});
	return result;
}
//#endregion
//#region node_modules/@mui/utils/getDisplayName/getDisplayName.mjs
function getFunctionComponentName(Component, fallback = "") {
	return Component.displayName || Component.name || fallback;
}
function getWrappedName(outerType, innerType, wrapperName) {
	const functionName = getFunctionComponentName(innerType);
	return outerType.displayName || (functionName !== "" ? `${wrapperName}(${functionName})` : wrapperName);
}
/**
* cherry-pick from
* https://github.com/react/react/blob/769b1f270e1251d9dbdce0fcbd9e92e502d059b8/packages/shared/getComponentName.js
* originally forked from recompose/getDisplayName
*/
function getDisplayName(Component) {
	if (Component == null) return;
	if (typeof Component === "string") return Component;
	if (typeof Component === "function") return getFunctionComponentName(Component, "Component");
	if (typeof Component === "object") switch (Component.$$typeof) {
		case import_react_is.ForwardRef: return getWrappedName(Component, Component.render, "ForwardRef");
		case import_react_is.Memo: return getWrappedName(Component, Component.type, "memo");
		default: return;
	}
}
//#endregion
//#region node_modules/@mui/system/preprocessStyles.mjs
function preprocessStyles(input) {
	const { variants, ...style } = input;
	const result = {
		variants,
		style: internal_serializeStyles(style),
		isProcessed: true
	};
	if (result.style === style) return result;
	if (variants) variants.forEach((variant) => {
		if (typeof variant.style !== "function") variant.style = internal_serializeStyles(variant.style);
	});
	return result;
}
//#endregion
//#region node_modules/@mui/system/createStyled/createStyled.mjs
var systemDefaultTheme = createTheme$1();
function shouldForwardProp(prop) {
	return prop !== "ownerState" && prop !== "theme" && prop !== "sx" && prop !== "as";
}
function shallowLayer(serialized, layerName) {
	if (layerName && serialized && typeof serialized === "object" && serialized.styles && !serialized.styles.startsWith("@layer")) serialized.styles = `@layer ${layerName}{${String(serialized.styles)}}`;
	return serialized;
}
function defaultOverridesResolver(slot) {
	if (!slot) return null;
	return (_props, styles) => styles[slot];
}
function attachTheme(props, themeId, defaultTheme) {
	props.theme = isObjectEmpty(props.theme) ? defaultTheme : props.theme[themeId] || props.theme;
}
function processStyle(props, style, layerName) {
	const resolvedStyle = typeof style === "function" ? style(props) : style;
	if (Array.isArray(resolvedStyle)) return resolvedStyle.flatMap((subStyle) => processStyle(props, subStyle, layerName));
	if (Array.isArray(resolvedStyle?.variants)) {
		let rootStyle;
		if (resolvedStyle.isProcessed) rootStyle = layerName ? shallowLayer(resolvedStyle.style, layerName) : resolvedStyle.style;
		else {
			const { variants, ...otherStyles } = resolvedStyle;
			rootStyle = layerName ? shallowLayer(internal_serializeStyles(otherStyles), layerName) : otherStyles;
		}
		return processStyleVariants(props, resolvedStyle.variants, [rootStyle], layerName);
	}
	if (resolvedStyle?.isProcessed) return layerName ? shallowLayer(internal_serializeStyles(resolvedStyle.style), layerName) : resolvedStyle.style;
	return layerName ? shallowLayer(internal_serializeStyles(resolvedStyle), layerName) : resolvedStyle;
}
function processStyleVariants(props, variants, results = [], layerName = void 0) {
	let mergedState;
	variantLoop: for (let i = 0; i < variants.length; i += 1) {
		const variant = variants[i];
		if (typeof variant.props === "function") {
			mergedState ??= {
				...props,
				...props.ownerState,
				ownerState: props.ownerState
			};
			if (!variant.props(mergedState)) continue;
		} else for (const key in variant.props) if (props[key] !== variant.props[key] && props.ownerState?.[key] !== variant.props[key]) continue variantLoop;
		if (typeof variant.style === "function") {
			mergedState ??= {
				...props,
				...props.ownerState,
				ownerState: props.ownerState
			};
			results.push(layerName ? shallowLayer(internal_serializeStyles(variant.style(mergedState)), layerName) : variant.style(mergedState));
		} else results.push(layerName ? shallowLayer(internal_serializeStyles(variant.style), layerName) : variant.style);
	}
	return results;
}
function createStyled(input = {}) {
	const { themeId, defaultTheme = systemDefaultTheme, rootShouldForwardProp = shouldForwardProp, slotShouldForwardProp = shouldForwardProp } = input;
	function styleAttachTheme(props) {
		attachTheme(props, themeId, defaultTheme);
	}
	const styled = (tag, inputOptions = {}) => {
		internal_mutateStyles(tag, (styles) => styles.filter((style) => style !== styleFunctionSx_default));
		const { name: componentName, slot: componentSlot, skipVariantsResolver: inputSkipVariantsResolver, skipSx: inputSkipSx, overridesResolver = defaultOverridesResolver(lowercaseFirstLetter(componentSlot)), ...options } = inputOptions;
		const layerName = componentName && componentName.startsWith("Mui") || !!componentSlot ? "components" : "custom";
		const skipVariantsResolver = inputSkipVariantsResolver !== void 0 ? inputSkipVariantsResolver : componentSlot && componentSlot !== "Root" && componentSlot !== "root" || false;
		const skipSx = inputSkipSx || false;
		let shouldForwardPropOption = shouldForwardProp;
		if (componentSlot === "Root" || componentSlot === "root") shouldForwardPropOption = rootShouldForwardProp;
		else if (componentSlot) shouldForwardPropOption = slotShouldForwardProp;
		else if (isStringTag(tag)) shouldForwardPropOption = void 0;
		const defaultStyledResolver = styled$1(tag, {
			shouldForwardProp: shouldForwardPropOption,
			label: generateStyledLabel(componentName, componentSlot),
			...options
		});
		const transformStyle = (style) => {
			if (style.__emotion_real === style) return style;
			if (typeof style === "function") return function styleFunctionProcessor(props) {
				return processStyle(props, style, props.theme.modularCssLayers ? layerName : void 0);
			};
			if (isPlainObject(style)) {
				const serialized = preprocessStyles(style);
				return function styleObjectProcessor(props) {
					if (!serialized.variants) return props.theme.modularCssLayers ? shallowLayer(serialized.style, layerName) : serialized.style;
					return processStyle(props, serialized, props.theme.modularCssLayers ? layerName : void 0);
				};
			}
			return style;
		};
		const muiStyledResolver = (...expressionsInput) => {
			const expressionsHead = [];
			const expressionsBody = expressionsInput.map(transformStyle);
			const expressionsTail = [];
			expressionsHead.push(styleAttachTheme);
			if (componentName && overridesResolver) expressionsTail.push(function styleThemeOverrides(props) {
				const styleOverrides = props.theme.components?.[componentName]?.styleOverrides;
				if (!styleOverrides) return null;
				const resolvedStyleOverrides = {};
				for (const slotKey in styleOverrides) resolvedStyleOverrides[slotKey] = processStyle(props, styleOverrides[slotKey], props.theme.modularCssLayers ? "theme" : void 0);
				return overridesResolver(props, resolvedStyleOverrides);
			});
			if (componentName && !skipVariantsResolver) expressionsTail.push(function styleThemeVariants(props) {
				const themeVariants = props.theme?.components?.[componentName]?.variants;
				if (!themeVariants) return null;
				return processStyleVariants(props, themeVariants, [], props.theme.modularCssLayers ? "theme" : void 0);
			});
			if (!skipSx) expressionsTail.push(styleFunctionSx_default);
			if (Array.isArray(expressionsBody[0])) {
				const inputStrings = expressionsBody.shift();
				const placeholdersHead = new Array(expressionsHead.length).fill("");
				const placeholdersTail = new Array(expressionsTail.length).fill("");
				let outputStrings;
				outputStrings = [
					...placeholdersHead,
					...inputStrings,
					...placeholdersTail
				];
				outputStrings.raw = [
					...placeholdersHead,
					...inputStrings.raw,
					...placeholdersTail
				];
				expressionsHead.unshift(outputStrings);
			}
			const expressions = [
				...expressionsHead,
				...expressionsBody,
				...expressionsTail
			];
			const Component = defaultStyledResolver(...expressions);
			if (tag.muiName) Component.muiName = tag.muiName;
			Component.displayName = generateDisplayName(componentName, componentSlot, tag);
			return Component;
		};
		if (defaultStyledResolver.withConfig) muiStyledResolver.withConfig = defaultStyledResolver.withConfig;
		return muiStyledResolver;
	};
	return styled;
}
function generateDisplayName(componentName, componentSlot, tag) {
	if (componentName) return `${componentName}${capitalize(componentSlot || "")}`;
	return `Styled(${getDisplayName(tag)})`;
}
function generateStyledLabel(componentName, componentSlot) {
	let label;
	if (componentName) label = `${componentName}-${lowercaseFirstLetter(componentSlot || "Root")}`;
	return label;
}
function isStringTag(tag) {
	return typeof tag === "string" && tag.charCodeAt(0) > 96;
}
function lowercaseFirstLetter(string) {
	if (!string) return string;
	return string.charAt(0).toLowerCase() + string.slice(1);
}
//#endregion
//#region node_modules/@mui/utils/resolveProps/resolveProps.mjs
/**
* Add keys, values of `defaultProps` that does not exist in `props`
* @param defaultProps
* @param props
* @param mergeClassNameAndStyle If `true`, merges `className` and `style` props instead of overriding them.
*   When `false` (default), props override defaultProps. When `true`, `className` values are concatenated
*   and `style` objects are merged with props taking precedence.
* @returns resolved props
*/
function resolveProps(defaultProps, props, mergeClassNameAndStyle = false) {
	const output = { ...props };
	for (const key in defaultProps) if (Object.prototype.hasOwnProperty.call(defaultProps, key)) {
		const propName = key;
		if (propName === "components" || propName === "slots") output[propName] = {
			...defaultProps[propName],
			...output[propName]
		};
		else if (propName === "componentsProps" || propName === "slotProps") {
			const defaultSlotProps = defaultProps[propName];
			const slotProps = props[propName];
			if (!slotProps) output[propName] = defaultSlotProps || {};
			else if (!defaultSlotProps) output[propName] = slotProps;
			else {
				output[propName] = { ...slotProps };
				for (const slotKey in defaultSlotProps) if (Object.prototype.hasOwnProperty.call(defaultSlotProps, slotKey)) {
					const slotPropName = slotKey;
					output[propName][slotPropName] = resolveProps(defaultSlotProps[slotPropName], slotProps[slotPropName], mergeClassNameAndStyle);
				}
			}
		} else if (propName === "className" && mergeClassNameAndStyle && props.className !== void 0) output.className = clsx(defaultProps?.className, props?.className);
		else if (propName === "style" && mergeClassNameAndStyle && props.style) output.style = {
			...defaultProps?.style,
			...props?.style
		};
		else if (output[propName] === void 0) output[propName] = defaultProps[propName];
	}
	return output;
}
//#endregion
//#region node_modules/@mui/utils/clamp/clamp.mjs
function clamp(val, min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER) {
	return Math.max(min, Math.min(val, max));
}
//#endregion
//#region node_modules/@mui/system/colorManipulator/colorManipulator.mjs
/**
* Returns a number whose value is limited to the given range.
* @param {number} value The value to be clamped
* @param {number} min The lower boundary of the output range
* @param {number} max The upper boundary of the output range
* @returns {number} A number in the range [min, max]
*/
function clampWrapper(value, min = 0, max = 1) {
	if (value < min || value > max) console.error(`MUI: The value provided ${value} is out of range [${min}, ${max}].`);
	return clamp(value, min, max);
}
/**
* Converts a color from CSS hex format to CSS rgb format.
* @param {string} color - Hex color, i.e. #nnn or #nnnnnn
* @returns {string} A CSS rgb color string
*/
function hexToRgb(color) {
	color = color.slice(1);
	const re = new RegExp(`.{1,${color.length >= 6 ? 2 : 1}}`, "g");
	let colors = color.match(re);
	if (colors && colors[0].length === 1) colors = colors.map((n) => n + n);
	if (color.length !== color.trim().length) console.error(`MUI: The color: "${color}" is invalid. Make sure the color input doesn't contain leading/trailing space.`);
	return colors ? `rgb${colors.length === 4 ? "a" : ""}(${colors.map((n, index) => {
		return index < 3 ? parseInt(n, 16) : Math.round(parseInt(n, 16) / 255 * 1e3) / 1e3;
	}).join(", ")})` : "";
}
function intToHex(int) {
	const hex = int.toString(16);
	return hex.length === 1 ? `0${hex}` : hex;
}
/**
* Returns an object with the type and values of a color.
*
* Note: Does not support rgb % values.
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @returns {object} - A MUI color object: {type: string, values: number[]}
*/
function decomposeColor(color) {
	if (color.type) return color;
	if (color.charAt(0) === "#") return decomposeColor(hexToRgb(color));
	const marker = color.indexOf("(");
	const type = color.substring(0, marker);
	if (![
		"rgb",
		"rgba",
		"hsl",
		"hsla",
		"color"
	].includes(type)) throw new Error(`MUI: Unsupported \`${color}\` color.\nThe following formats are supported: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color().`);
	let values = color.substring(marker + 1, color.length - 1);
	let colorSpace;
	if (type === "color") {
		values = values.split(" ");
		colorSpace = values.shift();
		if (values.length === 4 && values[3].charAt(0) === "/") values[3] = values[3].slice(1);
		if (![
			"srgb",
			"display-p3",
			"a98-rgb",
			"prophoto-rgb",
			"rec-2020"
		].includes(colorSpace)) throw new Error(`MUI: unsupported \`${colorSpace}\` color space.\nThe following color spaces are supported: srgb, display-p3, a98-rgb, prophoto-rgb, rec-2020.`);
	} else values = values.split(",");
	values = values.map((value) => parseFloat(value));
	return {
		type,
		values,
		colorSpace
	};
}
/**
* Returns a channel created from the input color.
*
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @returns {string} - The channel for the color, that can be used in rgba or hsla colors
*/
var colorChannel = (color) => {
	const decomposedColor = decomposeColor(color);
	return decomposedColor.values.slice(0, 3).map((val, idx) => decomposedColor.type.includes("hsl") && idx !== 0 ? `${val}%` : val).join(" ");
};
var private_safeColorChannel = (color, warning) => {
	try {
		return colorChannel(color);
	} catch (error) {
		if (warning && true) console.warn(warning);
		return color;
	}
};
/**
* Converts a color object with type and values to a string.
* @param {object} color - Decomposed color
* @param {string} color.type - One of: 'rgb', 'rgba', 'hsl', 'hsla', 'color'
* @param {array} color.values - [n,n,n] or [n,n,n,n]
* @returns {string} A CSS color string
*/
function recomposeColor(color) {
	const { type, colorSpace } = color;
	let { values } = color;
	if (type.includes("rgb")) values = values.map((n, i) => i < 3 ? parseInt(n, 10) : n);
	else if (type.includes("hsl")) {
		values[1] = `${values[1]}%`;
		values[2] = `${values[2]}%`;
	}
	if (type.includes("color")) values = `${colorSpace} ${values.join(" ")}`;
	else values = `${values.join(", ")}`;
	return `${type}(${values})`;
}
/**
* Converts a color from CSS rgb format to CSS hex format.
* @param {string} color - RGB color, i.e. rgb(n, n, n)
* @returns {string} A CSS rgb color string, i.e. #nnnnnn
*/
function rgbToHex(color) {
	if (color.startsWith("#")) return color;
	const { values } = decomposeColor(color);
	return `#${values.map((n, i) => intToHex(i === 3 ? Math.round(255 * n) : n)).join("")}`;
}
/**
* Converts a color from hsl format to rgb format.
* @param {string} color - HSL color values
* @returns {string} rgb color values
*/
function hslToRgb(color) {
	color = decomposeColor(color);
	const { values } = color;
	const h = values[0];
	const s = values[1] / 100;
	const l = values[2] / 100;
	const a = s * Math.min(l, 1 - l);
	const f = (n, k = (n + h / 30) % 12) => l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
	let type = "rgb";
	const rgb = [
		Math.round(f(0) * 255),
		Math.round(f(8) * 255),
		Math.round(f(4) * 255)
	];
	if (color.type === "hsla") {
		type += "a";
		rgb.push(values[3]);
	}
	return recomposeColor({
		type,
		values: rgb
	});
}
/**
* The relative brightness of any point in a color space,
* normalized to 0 for darkest black and 1 for lightest white.
*
* Formula: https://www.w3.org/TR/WCAG20-TECHS/G17.html#G17-tests
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @returns {number} The relative brightness of the color in the range 0 - 1
*/
function getLuminance(color) {
	color = decomposeColor(color);
	let rgb = color.type === "hsl" || color.type === "hsla" ? decomposeColor(hslToRgb(color)).values : color.values;
	rgb = rgb.map((val) => {
		if (color.type !== "color") val /= 255;
		return val <= .03928 ? val / 12.92 : ((val + .055) / 1.055) ** 2.4;
	});
	return Number((.2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2]).toFixed(3));
}
/**
* Calculates the contrast ratio between two colors.
*
* Formula: https://www.w3.org/TR/WCAG20-TECHS/G17.html#G17-tests
* @param {string} foreground - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla()
* @param {string} background - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla()
* @returns {number} A contrast ratio value in the range 0 - 21.
*/
function getContrastRatio(foreground, background) {
	const lumA = getLuminance(foreground);
	const lumB = getLuminance(background);
	return (Math.max(lumA, lumB) + .05) / (Math.min(lumA, lumB) + .05);
}
/**
* Sets the absolute transparency of a color.
* Any existing alpha values are overwritten.
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @param {number} value - value to set the alpha channel to in the range 0 - 1
* @returns {string} A CSS color string. Hex input values are returned as rgb
*/
function alpha(color, value) {
	color = decomposeColor(color);
	value = clampWrapper(value);
	if (color.type === "rgb" || color.type === "hsl") color.type += "a";
	if (color.type === "color") color.values[3] = `/${value}`;
	else color.values[3] = value;
	return recomposeColor(color);
}
function private_safeAlpha(color, value, warning) {
	try {
		return alpha(color, value);
	} catch (error) {
		if (warning && true) console.warn(warning);
		return color;
	}
}
/**
* Darkens a color.
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @param {number} coefficient - multiplier in the range 0 - 1
* @returns {string} A CSS color string. Hex input values are returned as rgb
*/
function darken(color, coefficient) {
	color = decomposeColor(color);
	coefficient = clampWrapper(coefficient);
	if (color.type.includes("hsl")) color.values[2] *= 1 - coefficient;
	else if (color.type.includes("rgb") || color.type.includes("color")) for (let i = 0; i < 3; i += 1) color.values[i] *= 1 - coefficient;
	return recomposeColor(color);
}
function private_safeDarken(color, coefficient, warning) {
	try {
		return darken(color, coefficient);
	} catch (error) {
		if (warning && true) console.warn(warning);
		return color;
	}
}
/**
* Lightens a color.
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @param {number} coefficient - multiplier in the range 0 - 1
* @returns {string} A CSS color string. Hex input values are returned as rgb
*/
function lighten(color, coefficient) {
	color = decomposeColor(color);
	coefficient = clampWrapper(coefficient);
	if (color.type.includes("hsl")) color.values[2] += (100 - color.values[2]) * coefficient;
	else if (color.type.includes("rgb")) for (let i = 0; i < 3; i += 1) color.values[i] += (255 - color.values[i]) * coefficient;
	else if (color.type.includes("color")) for (let i = 0; i < 3; i += 1) color.values[i] += (1 - color.values[i]) * coefficient;
	return recomposeColor(color);
}
function private_safeLighten(color, coefficient, warning) {
	try {
		return lighten(color, coefficient);
	} catch (error) {
		if (warning && true) console.warn(warning);
		return color;
	}
}
/**
* Darken or lighten a color, depending on its luminance.
* Light colors are darkened, dark colors are lightened.
* @param {string} color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color()
* @param {number} coefficient=0.15 - multiplier in the range 0 - 1
* @returns {string} A CSS color string. Hex input values are returned as rgb
*/
function emphasize(color, coefficient = .15) {
	return getLuminance(color) > .5 ? darken(color, coefficient) : lighten(color, coefficient);
}
function private_safeEmphasize(color, coefficient, warning) {
	try {
		return emphasize(color, coefficient);
	} catch (error) {
		if (warning && true) console.warn(warning);
		return color;
	}
}
//#endregion
//#region node_modules/@mui/system/RtlProvider/index.mjs
var RtlContext = /*#__PURE__*/ import_react.createContext();
function RtlProvider({ value, ...props }) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(RtlContext.Provider, {
		value: value ?? true,
		...props
	});
}
RtlProvider.propTypes = {
	children: import_prop_types.default.node,
	value: import_prop_types.default.bool
};
var useRtl = () => {
	return import_react.useContext(RtlContext) ?? false;
};
//#endregion
//#region node_modules/@mui/system/DefaultPropsProvider/DefaultPropsProvider.mjs
var PropsContext = /*#__PURE__*/ import_react.createContext(void 0);
function DefaultPropsProvider$1({ value, children }) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PropsContext.Provider, {
		value,
		children
	});
}
DefaultPropsProvider$1.propTypes = {
	/**
	* @ignore
	*/
	children: import_prop_types.default.node,
	/**
	* @ignore
	*/
	value: import_prop_types.default.object
};
function getThemeProps(params) {
	const { theme, name, props } = params;
	if (!theme || !theme.components || !theme.components[name]) return props;
	const config = theme.components[name];
	if (config.defaultProps) return resolveProps(config.defaultProps, props, theme.components.mergeClassNameAndStyle);
	if (!config.styleOverrides && !config.variants) return resolveProps(config, props, theme.components.mergeClassNameAndStyle);
	return props;
}
function useDefaultProps$1({ props, name }) {
	return getThemeProps({
		props,
		name,
		theme: { components: import_react.useContext(PropsContext) }
	});
}
//#endregion
//#region node_modules/@mui/system/memoTheme.mjs
var arg = { theme: void 0 };
/**
* Memoize style function on theme.
* Intended to be used in styled() calls that only need access to the theme.
*/
function unstable_memoTheme(styleFn) {
	let lastValue;
	let lastTheme;
	return function styleMemoized(props) {
		let value = lastValue;
		if (value === void 0 || props.theme !== lastTheme) {
			arg.theme = props.theme;
			value = preprocessStyles(styleFn(arg));
			lastValue = value;
			lastTheme = props.theme;
		}
		return value;
	};
}
//#endregion
//#region node_modules/@mui/system/cssVars/createGetCssVar.mjs
/**
* The benefit of this function is to help developers get CSS var from theme without specifying the whole variable
* and they does not need to remember the prefix (defined once).
*/
function createGetCssVar$1(prefix = "") {
	function appendVar(...vars) {
		if (!vars.length) return "";
		const value = vars[0];
		if (typeof value === "string" && !value.match(/(#|\(|\)|(-?(\d*\.)?\d+)(px|em|%|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc))|^(-?(\d*\.)?\d+)$|(\d+ \d+ \d+)/)) return `, var(--${prefix ? `${prefix}-` : ""}${value}${appendVar(...vars.slice(1))})`;
		return `, ${value}`;
	}
	const getCssVar = (field, ...fallbacks) => {
		return `var(--${prefix ? `${prefix}-` : ""}${field}${appendVar(...fallbacks)})`;
	};
	return getCssVar;
}
//#endregion
//#region node_modules/@mui/system/cssVars/cssVarsParser.mjs
var prototypePollutingKeys = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
/**
* This function create an object from keys, value and then assign to target
*
* @param {Object} obj : the target object to be assigned
* @param {string[]} keys
* @param {string | number} value
*
* @example
* const source = {}
* assignNestedKeys(source, ['palette', 'primary'], 'var(--palette-primary)')
* console.log(source) // { palette: { primary: 'var(--palette-primary)' } }
*
* @example
* const source = { palette: { primary: 'var(--palette-primary)' } }
* assignNestedKeys(source, ['palette', 'secondary'], 'var(--palette-secondary)')
* console.log(source) // { palette: { primary: 'var(--palette-primary)', secondary: 'var(--palette-secondary)' } }
*/
var assignNestedKeys = (obj, keys, value, arrayKeys = []) => {
	let temp = obj;
	for (let index = 0; index < keys.length; index += 1) {
		const k = keys[index];
		if (prototypePollutingKeys.has(k)) break;
		if (index === keys.length - 1) {
			if (Array.isArray(temp)) temp[Number(k)] = value;
			else if (temp && typeof temp === "object") temp[k] = value;
		} else if (temp && typeof temp === "object") {
			if (!temp[k]) temp[k] = arrayKeys.includes(k) ? [] : {};
			temp = temp[k];
		}
	}
};
/**
*
* @param {Object} obj : source object
* @param {Function} callback : a function that will be called when
*                   - the deepest key in source object is reached
*                   - the value of the deepest key is NOT `undefined` | `null`
*
* @example
* walkObjectDeep({ palette: { primary: { main: '#000000' } } }, console.log)
* // ['palette', 'primary', 'main'] '#000000'
*/
var walkObjectDeep = (obj, callback, shouldSkipPaths) => {
	function recurse(object, parentKeys = [], arrayKeys = []) {
		Object.entries(object).forEach(([key, value]) => {
			if (!shouldSkipPaths || shouldSkipPaths && !shouldSkipPaths([...parentKeys, key])) {
				if (value !== void 0 && value !== null) if (typeof value === "object" && Object.keys(value).length > 0) recurse(value, [...parentKeys, key], Array.isArray(value) ? [...arrayKeys, key] : arrayKeys);
				else callback([...parentKeys, key], value, arrayKeys);
			}
		});
	}
	recurse(obj);
};
var getCssValue = (keys, value) => {
	if (typeof value === "number") {
		if ([
			"lineHeight",
			"fontWeight",
			"opacity",
			"zIndex"
		].some((prop) => keys.includes(prop))) return value;
		if (keys[keys.length - 1].toLowerCase().includes("opacity")) return value;
		return `${value}px`;
	}
	return value;
};
/**
* a function that parse theme and return { css, vars }
*
* @param {Object} theme
* @param {{
*  prefix?: string,
*  shouldSkipGeneratingVar?: (objectPathKeys: Array<string>, value: string | number) => boolean
* }} options.
*  `prefix`: The prefix of the generated CSS variables. This function does not change the value.
*
* @returns {{ css: Object, vars: Object }} `css` is the stylesheet, `vars` is an object to get css variable (same structure as theme).
*
* @example
* const { css, vars } = parser({
*   fontSize: 12,
*   lineHeight: 1.2,
*   palette: { primary: { 500: 'var(--color)' } }
* }, { prefix: 'foo' })
*
* console.log(css) // { '--foo-fontSize': '12px', '--foo-lineHeight': 1.2, '--foo-palette-primary-500': 'var(--color)' }
* console.log(vars) // { fontSize: 'var(--foo-fontSize)', lineHeight: 'var(--foo-lineHeight)', palette: { primary: { 500: 'var(--foo-palette-primary-500)' } } }
*/
function cssVarsParser(theme, options) {
	const { prefix, shouldSkipGeneratingVar } = options || {};
	const css = {};
	const vars = {};
	const varsWithDefaults = {};
	walkObjectDeep(theme, (keys, value, arrayKeys) => {
		if (typeof value === "string" || typeof value === "number") {
			if (!shouldSkipGeneratingVar || !shouldSkipGeneratingVar(keys, value)) {
				const cssVar = `--${prefix ? `${prefix}-` : ""}${keys.join("-")}`;
				const resolvedValue = getCssValue(keys, value);
				Object.assign(css, { [cssVar]: resolvedValue });
				assignNestedKeys(vars, keys, `var(${cssVar})`, arrayKeys);
				assignNestedKeys(varsWithDefaults, keys, `var(${cssVar}, ${resolvedValue})`, arrayKeys);
			}
		}
	}, (keys) => keys[0] === "vars");
	return {
		css,
		vars,
		varsWithDefaults
	};
}
//#endregion
//#region node_modules/@mui/system/cssVars/prepareCssVars.mjs
function prepareCssVars(theme, parserConfig = {}) {
	const { getSelector = defaultGetSelector, disableCssColorScheme, colorSchemeSelector: selector, enableContrastVars } = parserConfig;
	const { colorSchemes = {}, components, defaultColorScheme = "light", ...otherTheme } = theme;
	const { vars: rootVars, css: rootCss, varsWithDefaults: rootVarsWithDefaults } = cssVarsParser(otherTheme, parserConfig);
	let themeVars = rootVarsWithDefaults;
	const colorSchemesMap = {};
	const { [defaultColorScheme]: defaultScheme, ...otherColorSchemes } = colorSchemes;
	Object.entries(otherColorSchemes || {}).forEach(([key, scheme]) => {
		const { vars, css, varsWithDefaults } = cssVarsParser(scheme, parserConfig);
		themeVars = deepmerge(themeVars, varsWithDefaults);
		colorSchemesMap[key] = {
			css,
			vars
		};
	});
	if (defaultScheme) {
		const { css, vars, varsWithDefaults } = cssVarsParser(defaultScheme, parserConfig);
		themeVars = deepmerge(themeVars, varsWithDefaults);
		colorSchemesMap[defaultColorScheme] = {
			css,
			vars
		};
	}
	function defaultGetSelector(colorScheme, cssObject) {
		let rule = selector;
		if (selector === "class") rule = ".%s";
		if (selector === "data") rule = "[data-%s]";
		if (selector?.startsWith("data-") && !selector.includes("%s")) rule = `[${selector}="%s"]`;
		if (colorScheme) {
			if (rule === "media") {
				if (theme.defaultColorScheme === colorScheme) return ":root";
				return { [`@media (prefers-color-scheme: ${colorSchemes[colorScheme]?.palette?.mode || colorScheme})`]: { ":root": cssObject } };
			}
			if (rule) {
				if (theme.defaultColorScheme === colorScheme) return `:root, ${rule.replace("%s", String(colorScheme))}`;
				return rule.replace("%s", String(colorScheme));
			}
		}
		return ":root";
	}
	const generateThemeVars = () => {
		let vars = { ...rootVars };
		Object.entries(colorSchemesMap).forEach(([, { vars: schemeVars }]) => {
			vars = deepmerge(vars, schemeVars);
		});
		return vars;
	};
	const generateStyleSheets = () => {
		const stylesheets = [];
		const colorScheme = theme.defaultColorScheme || "light";
		function insertStyleSheet(key, css) {
			if (Object.keys(css).length) stylesheets.push(typeof key === "string" ? { [key]: { ...css } } : key);
		}
		insertStyleSheet(getSelector(void 0, { ...rootCss }), rootCss);
		const { [colorScheme]: defaultSchemeVal, ...other } = colorSchemesMap;
		if (defaultSchemeVal) {
			const { css } = defaultSchemeVal;
			const cssColorSheme = colorSchemes[colorScheme]?.palette?.mode;
			const finalCss = !disableCssColorScheme && cssColorSheme ? {
				colorScheme: cssColorSheme,
				...css
			} : { ...css };
			insertStyleSheet(getSelector(colorScheme, { ...finalCss }), finalCss);
		}
		Object.entries(other).forEach(([key, { css }]) => {
			const cssColorSheme = colorSchemes[key]?.palette?.mode;
			const finalCss = !disableCssColorScheme && cssColorSheme ? {
				colorScheme: cssColorSheme,
				...css
			} : { ...css };
			insertStyleSheet(getSelector(key, { ...finalCss }), finalCss);
		});
		if (enableContrastVars) stylesheets.push({ ":root": {
			"--__l-threshold": "0.7",
			"--__l": "clamp(0, (l / var(--__l-threshold) - 1) * -infinity, 1)",
			"--__a": "clamp(0.87, (l / var(--__l-threshold) - 1) * -infinity, 1)"
		} });
		return stylesheets;
	};
	return {
		vars: themeVars,
		generateThemeVars,
		generateStyleSheets
	};
}
//#endregion
//#region node_modules/@mui/system/cssVars/getColorSchemeSelector.mjs
function createGetColorSchemeSelector(selector) {
	return function getColorSchemeSelector(colorScheme) {
		if (selector === "media") {
			if (colorScheme !== "light" && colorScheme !== "dark") console.error(`MUI: @media (prefers-color-scheme) supports only 'light' or 'dark', but receive '${colorScheme}'.`);
			return `@media (prefers-color-scheme: ${colorScheme})`;
		}
		if (selector) {
			if (selector.startsWith("data-") && !selector.includes("%s")) return `[${selector}="${colorScheme}"] &`;
			if (selector === "class") return `.${colorScheme} &`;
			if (selector === "data") return `[data-${colorScheme}] &`;
			return `${selector.replace("%s", colorScheme)} &`;
		}
		return "&";
	};
}
//#endregion
//#region node_modules/@mui/system/index.mjs
/**
* @mui/system v9.3.0
*
* @license MIT
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
//#endregion
//#region node_modules/@mui/material/colors/common.mjs
var common = {
	black: "#000",
	white: "#fff"
};
//#endregion
//#region node_modules/@mui/material/colors/grey.mjs
var grey = {
	50: "#fafafa",
	100: "#f5f5f5",
	200: "#eeeeee",
	300: "#e0e0e0",
	400: "#bdbdbd",
	500: "#9e9e9e",
	600: "#757575",
	700: "#616161",
	800: "#424242",
	900: "#212121",
	A100: "#f5f5f5",
	A200: "#eeeeee",
	A400: "#bdbdbd",
	A700: "#616161"
};
//#endregion
//#region node_modules/@mui/material/colors/purple.mjs
var purple = {
	50: "#f3e5f5",
	100: "#e1bee7",
	200: "#ce93d8",
	300: "#ba68c8",
	400: "#ab47bc",
	500: "#9c27b0",
	600: "#8e24aa",
	700: "#7b1fa2",
	800: "#6a1b9a",
	900: "#4a148c",
	A100: "#ea80fc",
	A200: "#e040fb",
	A400: "#d500f9",
	A700: "#aa00ff"
};
//#endregion
//#region node_modules/@mui/material/colors/red.mjs
var red = {
	50: "#ffebee",
	100: "#ffcdd2",
	200: "#ef9a9a",
	300: "#e57373",
	400: "#ef5350",
	500: "#f44336",
	600: "#e53935",
	700: "#d32f2f",
	800: "#c62828",
	900: "#b71c1c",
	A100: "#ff8a80",
	A200: "#ff5252",
	A400: "#ff1744",
	A700: "#d50000"
};
//#endregion
//#region node_modules/@mui/material/colors/orange.mjs
var orange = {
	50: "#fff3e0",
	100: "#ffe0b2",
	200: "#ffcc80",
	300: "#ffb74d",
	400: "#ffa726",
	500: "#ff9800",
	600: "#fb8c00",
	700: "#f57c00",
	800: "#ef6c00",
	900: "#e65100",
	A100: "#ffd180",
	A200: "#ffab40",
	A400: "#ff9100",
	A700: "#ff6d00"
};
//#endregion
//#region node_modules/@mui/material/colors/blue.mjs
var blue = {
	50: "#e3f2fd",
	100: "#bbdefb",
	200: "#90caf9",
	300: "#64b5f6",
	400: "#42a5f5",
	500: "#2196f3",
	600: "#1e88e5",
	700: "#1976d2",
	800: "#1565c0",
	900: "#0d47a1",
	A100: "#82b1ff",
	A200: "#448aff",
	A400: "#2979ff",
	A700: "#2962ff"
};
//#endregion
//#region node_modules/@mui/material/colors/lightBlue.mjs
var lightBlue = {
	50: "#e1f5fe",
	100: "#b3e5fc",
	200: "#81d4fa",
	300: "#4fc3f7",
	400: "#29b6f6",
	500: "#03a9f4",
	600: "#039be5",
	700: "#0288d1",
	800: "#0277bd",
	900: "#01579b",
	A100: "#80d8ff",
	A200: "#40c4ff",
	A400: "#00b0ff",
	A700: "#0091ea"
};
//#endregion
//#region node_modules/@mui/material/colors/green.mjs
var green = {
	50: "#e8f5e9",
	100: "#c8e6c9",
	200: "#a5d6a7",
	300: "#81c784",
	400: "#66bb6a",
	500: "#4caf50",
	600: "#43a047",
	700: "#388e3c",
	800: "#2e7d32",
	900: "#1b5e20",
	A100: "#b9f6ca",
	A200: "#69f0ae",
	A400: "#00e676",
	A700: "#00c853"
};
//#endregion
//#region node_modules/@mui/material/styles/createPalette.mjs
function getLight() {
	return {
		text: {
			primary: "rgba(0, 0, 0, 0.87)",
			secondary: "rgba(0, 0, 0, 0.6)",
			disabled: "rgba(0, 0, 0, 0.38)"
		},
		divider: "rgba(0, 0, 0, 0.12)",
		background: {
			paper: common.white,
			default: common.white
		},
		action: {
			active: "rgba(0, 0, 0, 0.54)",
			hover: "rgba(0, 0, 0, 0.04)",
			hoverOpacity: .04,
			selected: "rgba(0, 0, 0, 0.08)",
			selectedOpacity: .08,
			disabled: "rgba(0, 0, 0, 0.26)",
			disabledBackground: "rgba(0, 0, 0, 0.12)",
			disabledOpacity: .38,
			focus: "rgba(0, 0, 0, 0.12)",
			focusOpacity: .12,
			activatedOpacity: .12
		}
	};
}
var light = getLight();
function getDark() {
	return {
		text: {
			primary: common.white,
			secondary: "rgba(255, 255, 255, 0.7)",
			disabled: "rgba(255, 255, 255, 0.5)",
			icon: "rgba(255, 255, 255, 0.5)"
		},
		divider: "rgba(255, 255, 255, 0.12)",
		background: {
			paper: "#121212",
			default: "#121212"
		},
		action: {
			active: common.white,
			hover: "rgba(255, 255, 255, 0.08)",
			hoverOpacity: .08,
			selected: "rgba(255, 255, 255, 0.16)",
			selectedOpacity: .16,
			disabled: "rgba(255, 255, 255, 0.3)",
			disabledBackground: "rgba(255, 255, 255, 0.12)",
			disabledOpacity: .38,
			focus: "rgba(255, 255, 255, 0.12)",
			focusOpacity: .12,
			activatedOpacity: .24
		}
	};
}
var dark = getDark();
function addLightOrDark(intent, direction, shade, tonalOffset) {
	const tonalOffsetLight = tonalOffset.light || tonalOffset;
	const tonalOffsetDark = tonalOffset.dark || tonalOffset * 1.5;
	if (!intent[direction]) {
		if (intent.hasOwnProperty(shade)) intent[direction] = intent[shade];
		else if (direction === "light") intent.light = lighten(intent.main, tonalOffsetLight);
		else if (direction === "dark") intent.dark = darken(intent.main, tonalOffsetDark);
	}
}
function mixLightOrDark(colorSpace, intent, direction, shade, tonalOffset) {
	const tonalOffsetLight = tonalOffset.light || tonalOffset;
	const tonalOffsetDark = tonalOffset.dark || tonalOffset * 1.5;
	if (!intent[direction]) {
		if (intent.hasOwnProperty(shade)) intent[direction] = intent[shade];
		else if (direction === "light") intent.light = `color-mix(in ${colorSpace}, ${intent.main}, #fff ${(tonalOffsetLight * 100).toFixed(0)}%)`;
		else if (direction === "dark") intent.dark = `color-mix(in ${colorSpace}, ${intent.main}, #000 ${(tonalOffsetDark * 100).toFixed(0)}%)`;
	}
}
function getDefaultPrimary(mode = "light") {
	if (mode === "dark") return {
		main: blue[200],
		light: blue[50],
		dark: blue[400]
	};
	return {
		main: blue[700],
		light: blue[400],
		dark: blue[800]
	};
}
function getDefaultSecondary(mode = "light") {
	if (mode === "dark") return {
		main: purple[200],
		light: purple[50],
		dark: purple[400]
	};
	return {
		main: purple[500],
		light: purple[300],
		dark: purple[700]
	};
}
function getDefaultError(mode = "light") {
	if (mode === "dark") return {
		main: red[500],
		light: red[300],
		dark: red[700]
	};
	return {
		main: red[700],
		light: red[400],
		dark: red[800]
	};
}
function getDefaultInfo(mode = "light") {
	if (mode === "dark") return {
		main: lightBlue[400],
		light: lightBlue[300],
		dark: lightBlue[700]
	};
	return {
		main: lightBlue[700],
		light: lightBlue[500],
		dark: lightBlue[900]
	};
}
function getDefaultSuccess(mode = "light") {
	if (mode === "dark") return {
		main: green[400],
		light: green[300],
		dark: green[700]
	};
	return {
		main: green[800],
		light: green[500],
		dark: green[900]
	};
}
function getDefaultWarning(mode = "light") {
	if (mode === "dark") return {
		main: orange[400],
		light: orange[300],
		dark: orange[700]
	};
	return {
		main: "#ed6c02",
		light: orange[500],
		dark: orange[900]
	};
}
function contrastColor(background) {
	return `oklch(from ${background} var(--__l) 0 h / var(--__a))`;
}
function createPalette(palette) {
	const { mode = "light", contrastThreshold = 3, tonalOffset = .2, colorSpace, ...other } = palette;
	const primary = palette.primary || getDefaultPrimary(mode);
	const secondary = palette.secondary || getDefaultSecondary(mode);
	const error = palette.error || getDefaultError(mode);
	const info = palette.info || getDefaultInfo(mode);
	const success = palette.success || getDefaultSuccess(mode);
	const warning = palette.warning || getDefaultWarning(mode);
	function getContrastText(background) {
		if (colorSpace) return contrastColor(background);
		const contrastText = getContrastRatio(background, dark.text.primary) >= contrastThreshold ? dark.text.primary : light.text.primary;
		{
			const contrast = getContrastRatio(background, contrastText);
			if (contrast < 3) console.error([
				`MUI: The contrast ratio of ${contrast}:1 for ${contrastText} on ${background}`,
				"falls below the WCAG recommended absolute minimum contrast ratio of 3:1.",
				"https://www.w3.org/TR/2008/REC-WCAG20-20081211/#visual-audio-contrast-contrast"
			].join("\n"));
		}
		return contrastText;
	}
	const augmentColor = ({ color, name, mainShade = 500, lightShade = 300, darkShade = 700 }) => {
		color = { ...color };
		if (!color.main && color[mainShade]) color.main = color[mainShade];
		if (!color.hasOwnProperty("main")) throw new Error(`MUI: The color${name ? ` (${name})` : ""} provided to augmentColor(color) is invalid.\nThe color object needs to have a \`main\` property or a \`${mainShade}\` property.`);
		if (typeof color.main !== "string") throw new Error(`MUI: The color${name ? ` (${name})` : ""} provided to augmentColor(color) is invalid.\n\`color.main\` should be a string, but \`${JSON.stringify(color.main)}\` was provided instead.\n
Did you intend to use one of the following approaches?

import { green } from "@mui/material/colors";

const theme1 = createTheme({ palette: {
  primary: green,
} });

const theme2 = createTheme({ palette: {
  primary: { main: green[500] },
} });`);
		if (colorSpace) {
			mixLightOrDark(colorSpace, color, "light", lightShade, tonalOffset);
			mixLightOrDark(colorSpace, color, "dark", darkShade, tonalOffset);
		} else {
			addLightOrDark(color, "light", lightShade, tonalOffset);
			addLightOrDark(color, "dark", darkShade, tonalOffset);
		}
		if (!color.contrastText) color.contrastText = getContrastText(color.main);
		return color;
	};
	let modeHydrated;
	if (mode === "light") modeHydrated = getLight();
	else if (mode === "dark") modeHydrated = getDark();
	if (!modeHydrated) console.error(`MUI: The palette mode \`${mode}\` is not supported.`);
	return deepmerge({
		common: { ...common },
		mode,
		primary: augmentColor({
			color: primary,
			name: "primary"
		}),
		secondary: augmentColor({
			color: secondary,
			name: "secondary",
			mainShade: "A400",
			lightShade: "A200",
			darkShade: "A700"
		}),
		error: augmentColor({
			color: error,
			name: "error"
		}),
		warning: augmentColor({
			color: warning,
			name: "warning"
		}),
		info: augmentColor({
			color: info,
			name: "info"
		}),
		success: augmentColor({
			color: success,
			name: "success"
		}),
		grey,
		contrastThreshold,
		getContrastText,
		augmentColor,
		tonalOffset,
		...modeHydrated
	}, other);
}
//#endregion
//#region node_modules/@mui/system/cssVars/prepareTypographyVars.mjs
function prepareTypographyVars(typography) {
	const vars = {};
	Object.entries(typography).forEach((entry) => {
		const [key, value] = entry;
		if (typeof value === "object") vars[key] = `${value.fontStyle ? `${value.fontStyle} ` : ""}${value.fontVariant ? `${value.fontVariant} ` : ""}${value.fontWeight ? `${value.fontWeight} ` : ""}${value.fontStretch ? `${value.fontStretch} ` : ""}${value.fontSize || ""}${value.lineHeight ? `/${value.lineHeight} ` : ""}${value.fontFamily || ""}`;
	});
	return vars;
}
//#endregion
//#region node_modules/@mui/material/styles/createMixins.mjs
function createMixins(breakpoints, mixins) {
	return {
		toolbar: {
			minHeight: 56,
			[breakpoints.up("xs")]: { "@media (orientation: landscape)": { minHeight: 48 } },
			[breakpoints.up("sm")]: { minHeight: 64 }
		},
		...mixins
	};
}
//#endregion
//#region node_modules/@mui/material/styles/createTypography.mjs
function round(value) {
	return Math.round(value * 1e5) / 1e5;
}
var caseAllCaps = { textTransform: "uppercase" };
var defaultFontFamily = "\"Roboto\", \"Helvetica\", \"Arial\", sans-serif";
/**
* @see @link{https://m2.material.io/design/typography/the-type-system.html}
* @see @link{https://m2.material.io/design/typography/understanding-typography.html}
*/
function createTypography(palette, typography) {
	const { fontFamily = defaultFontFamily, fontSize = 14, fontWeightLight = 300, fontWeightRegular = 400, fontWeightMedium = 500, fontWeightBold = 700, htmlFontSize = 16, allVariants, pxToRem: pxToRem2, ...other } = typeof typography === "function" ? typography(palette) : typography;
	if (typeof fontSize !== "number") console.error("MUI: `fontSize` is required to be a number.");
	if (typeof htmlFontSize !== "number") console.error("MUI: `htmlFontSize` is required to be a number.");
	const coef = fontSize / 14;
	const pxToRem = pxToRem2 || ((size) => `${size / htmlFontSize * coef}rem`);
	const buildVariant = (fontWeight, size, lineHeight, letterSpacing, casing) => ({
		fontFamily,
		fontWeight,
		fontSize: pxToRem(size),
		lineHeight,
		...fontFamily === defaultFontFamily ? { letterSpacing: `${round(letterSpacing / size)}em` } : {},
		...casing,
		...allVariants
	});
	return deepmerge({
		htmlFontSize,
		pxToRem,
		fontFamily,
		fontSize,
		fontWeightLight,
		fontWeightRegular,
		fontWeightMedium,
		fontWeightBold,
		h1: buildVariant(fontWeightLight, 96, 1.167, -1.5),
		h2: buildVariant(fontWeightLight, 60, 1.2, -.5),
		h3: buildVariant(fontWeightRegular, 48, 1.167, 0),
		h4: buildVariant(fontWeightRegular, 34, 1.235, .25),
		h5: buildVariant(fontWeightRegular, 24, 1.334, 0),
		h6: buildVariant(fontWeightMedium, 20, 1.6, .15),
		subtitle1: buildVariant(fontWeightRegular, 16, 1.75, .15),
		subtitle2: buildVariant(fontWeightMedium, 14, 1.57, .1),
		body1: buildVariant(fontWeightRegular, 16, 1.5, .15),
		body2: buildVariant(fontWeightRegular, 14, 1.43, .15),
		button: buildVariant(fontWeightMedium, 14, 1.75, .4, caseAllCaps),
		caption: buildVariant(fontWeightRegular, 12, 1.66, .4),
		overline: buildVariant(fontWeightRegular, 12, 2.66, 1, caseAllCaps),
		inherit: {
			fontFamily: "inherit",
			fontWeight: "inherit",
			fontSize: "inherit",
			lineHeight: "inherit",
			letterSpacing: "inherit"
		}
	}, other, { clone: false });
}
//#endregion
//#region node_modules/@mui/material/styles/shadows.mjs
var shadowKeyUmbraOpacity = .2;
var shadowKeyPenumbraOpacity = .14;
var shadowAmbientShadowOpacity = .12;
function createShadow(...px) {
	return [
		`${px[0]}px ${px[1]}px ${px[2]}px ${px[3]}px rgba(0,0,0,${shadowKeyUmbraOpacity})`,
		`${px[4]}px ${px[5]}px ${px[6]}px ${px[7]}px rgba(0,0,0,${shadowKeyPenumbraOpacity})`,
		`${px[8]}px ${px[9]}px ${px[10]}px ${px[11]}px rgba(0,0,0,${shadowAmbientShadowOpacity})`
	].join(",");
}
var shadows = [
	"none",
	createShadow(0, 2, 1, -1, 0, 1, 1, 0, 0, 1, 3, 0),
	createShadow(0, 3, 1, -2, 0, 2, 2, 0, 0, 1, 5, 0),
	createShadow(0, 3, 3, -2, 0, 3, 4, 0, 0, 1, 8, 0),
	createShadow(0, 2, 4, -1, 0, 4, 5, 0, 0, 1, 10, 0),
	createShadow(0, 3, 5, -1, 0, 5, 8, 0, 0, 1, 14, 0),
	createShadow(0, 3, 5, -1, 0, 6, 10, 0, 0, 1, 18, 0),
	createShadow(0, 4, 5, -2, 0, 7, 10, 1, 0, 2, 16, 1),
	createShadow(0, 5, 5, -3, 0, 8, 10, 1, 0, 3, 14, 2),
	createShadow(0, 5, 6, -3, 0, 9, 12, 1, 0, 3, 16, 2),
	createShadow(0, 6, 6, -3, 0, 10, 14, 1, 0, 4, 18, 3),
	createShadow(0, 6, 7, -4, 0, 11, 15, 1, 0, 4, 20, 3),
	createShadow(0, 7, 8, -4, 0, 12, 17, 2, 0, 5, 22, 4),
	createShadow(0, 7, 8, -4, 0, 13, 19, 2, 0, 5, 24, 4),
	createShadow(0, 7, 9, -4, 0, 14, 21, 2, 0, 5, 26, 4),
	createShadow(0, 8, 9, -5, 0, 15, 22, 2, 0, 6, 28, 5),
	createShadow(0, 8, 10, -5, 0, 16, 24, 2, 0, 6, 30, 5),
	createShadow(0, 8, 11, -5, 0, 17, 26, 2, 0, 6, 32, 5),
	createShadow(0, 9, 11, -5, 0, 18, 28, 2, 0, 7, 34, 6),
	createShadow(0, 9, 12, -6, 0, 19, 29, 2, 0, 7, 36, 6),
	createShadow(0, 10, 13, -6, 0, 20, 31, 3, 0, 8, 38, 7),
	createShadow(0, 10, 13, -6, 0, 21, 33, 3, 0, 8, 40, 7),
	createShadow(0, 10, 14, -6, 0, 22, 35, 3, 0, 8, 42, 7),
	createShadow(0, 11, 14, -7, 0, 23, 36, 3, 0, 9, 44, 8),
	createShadow(0, 11, 15, -7, 0, 24, 38, 3, 0, 9, 46, 8)
];
//#endregion
//#region node_modules/@mui/material/styles/createTransitions.mjs
var DEFAULT_TRANSITION_PROPS$1 = ["all"];
var EMPTY_OPTIONS$1 = {};
var easing = {
	easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
	easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
	easeIn: "cubic-bezier(0.4, 0, 1, 1)",
	sharp: "cubic-bezier(0.4, 0, 0.6, 1)"
};
var duration = {
	shortest: 150,
	shorter: 200,
	short: 250,
	standard: 300,
	complex: 375,
	enteringScreen: 225,
	leavingScreen: 195
};
function formatMs(milliseconds) {
	return `${Math.round(milliseconds)}ms`;
}
function getAutoHeightDuration(height) {
	if (!height) return 0;
	const constant = height / 36;
	return Math.min(Math.round((4 + 15 * constant ** .25 + constant / 5) * 10), 3e3);
}
function createTransitions(inputTransitions) {
	const transitions = { ...inputTransitions };
	delete transitions.reducedMotion;
	const mergedEasing = {
		...easing,
		...transitions.easing
	};
	const mergedDuration = {
		...duration,
		...transitions.duration
	};
	const createTransitionValue = (props = DEFAULT_TRANSITION_PROPS$1, options = EMPTY_OPTIONS$1) => {
		const { duration: durationOption = mergedDuration.standard, easing: easingOption = mergedEasing.easeInOut, delay = 0, ...other } = options;
		{
			const isString = (value) => typeof value === "string";
			const isNumber = (value) => !Number.isNaN(parseFloat(value));
			if (!isString(props) && !Array.isArray(props)) console.error("MUI: Argument \"props\" must be a string or Array.");
			if (!isNumber(durationOption) && !isString(durationOption)) console.error(`MUI: Argument "duration" must be a number or a string but found ${durationOption}.`);
			if (!isString(easingOption)) console.error("MUI: Argument \"easing\" must be a string.");
			if (!isNumber(delay) && !isString(delay)) console.error("MUI: Argument \"delay\" must be a number or a string.");
			if (typeof options !== "object") console.error(["MUI: Secong argument of transition.create must be an object.", "Arguments should be either `create('prop1', options)` or `create(['prop1', 'prop2'], options)`"].join("\n"));
			if (Object.keys(other).length !== 0) console.error(`MUI: Unrecognized argument(s) [${Object.keys(other).join(",")}].`);
		}
		return (Array.isArray(props) ? props : [props]).map((animatedProp) => `${animatedProp} ${typeof durationOption === "string" ? durationOption : formatMs(durationOption)} ${easingOption} ${typeof delay === "string" ? delay : formatMs(delay)}`).join(",");
	};
	return {
		getAutoHeightDuration,
		create: transitions.create ?? createTransitionValue,
		...transitions,
		easing: mergedEasing,
		duration: mergedDuration
	};
}
//#endregion
//#region node_modules/@mui/material/styles/createMotion.mjs
var EMPTY_MOTION = {};
function createMotion(inputMotion = EMPTY_MOTION) {
	return {
		reducedMotion: "never",
		...inputMotion
	};
}
//#endregion
//#region node_modules/@mui/material/styles/zIndex.mjs
var zIndex = {
	mobileStepper: 1e3,
	fab: 1050,
	speedDial: 1050,
	appBar: 1100,
	drawer: 1200,
	modal: 1300,
	snackbar: 1400,
	tooltip: 1500
};
//#endregion
//#region node_modules/@mui/material/styles/stringifyTheme.mjs
function isSerializable(val) {
	return isPlainObject(val) || typeof val === "undefined" || typeof val === "string" || typeof val === "boolean" || typeof val === "number" || Array.isArray(val);
}
/**
* `baseTheme` usually comes from `createTheme()` or `extendTheme()`.
*
* This function is intended to be used with zero-runtime CSS-in-JS like Pigment CSS
* For example, in a Next.js project:
*
* ```js
* // next.config.js
* const { extendTheme } = require('@mui/material/styles');
*
* const theme = extendTheme();
* // `.toRuntimeSource` is Pigment CSS specific to create a theme that is available at runtime.
* theme.toRuntimeSource = stringifyTheme;
*
* module.exports = withPigment({
*  theme,
* });
* ```
*/
function stringifyTheme(baseTheme = {}) {
	const serializableTheme = { ...baseTheme };
	function serializeTheme(object) {
		const array = Object.entries(object);
		for (let index = 0; index < array.length; index++) {
			const [key, value] = array[index];
			if (!isSerializable(value) || key.startsWith("unstable_") || key.startsWith("internal_")) delete object[key];
			else if (isPlainObject(value)) {
				object[key] = { ...value };
				serializeTheme(object[key]);
			}
		}
	}
	serializeTheme(serializableTheme);
	return `import { unstable_createBreakpoints as createBreakpoints, createTransitions } from '@mui/material/styles';

const theme = ${JSON.stringify(serializableTheme, null, 2)};

theme.breakpoints = createBreakpoints(theme.breakpoints || {});
theme.motion = { reducedMotion: 'never', ...theme.motion };
theme.transitions = createTransitions(theme.transitions || {});

export default theme;`;
}
//#endregion
//#region node_modules/@mui/material/styles/createThemeNoVars.mjs
function coefficientToPercentage(coefficient) {
	if (typeof coefficient === "number") return `${(coefficient * 100).toFixed(0)}%`;
	return `calc((${coefficient}) * 100%)`;
}
var parseAddition = (str) => {
	if (!Number.isNaN(+str)) return +str;
	const numbers = str.match(/\d*\.?\d+/g);
	if (!numbers) return 0;
	let sum = 0;
	for (let i = 0; i < numbers.length; i += 1) sum += +numbers[i];
	return sum;
};
function attachColorManipulators(theme) {
	Object.assign(theme, {
		alpha(color, coefficient) {
			const obj = this || theme;
			if (obj.colorSpace) return `oklch(from ${color} l c h / ${typeof coefficient === "string" ? `calc(${coefficient})` : coefficient})`;
			if (obj.vars) return `rgba(${color.replace(/var\(--([^,\s)]+)(?:,[^)]+)?\)+/g, "var(--$1Channel)")} / ${typeof coefficient === "string" ? `calc(${coefficient})` : coefficient})`;
			return alpha(color, parseAddition(coefficient));
		},
		lighten(color, coefficient) {
			const obj = this || theme;
			if (obj.colorSpace) return `color-mix(in ${obj.colorSpace}, ${color}, #fff ${coefficientToPercentage(coefficient)})`;
			return lighten(color, coefficient);
		},
		darken(color, coefficient) {
			const obj = this || theme;
			if (obj.colorSpace) return `color-mix(in ${obj.colorSpace}, ${color}, #000 ${coefficientToPercentage(coefficient)})`;
			return darken(color, coefficient);
		}
	});
}
function createThemeNoVars(options = {}, ...args) {
	const { breakpoints: breakpointsInput, mixins: mixinsInput = {}, spacing: spacingInput, palette: paletteInput = {}, motion: motionInput = {}, transitions: transitionsInput = {}, typography: typographyInput = {}, shape: shapeInput, colorSpace, ...other } = options;
	if (options.vars && options.generateThemeVars === void 0) throw new Error("MUI: `vars` is a private field used for CSS variables support.\nPlease use another name or follow the [docs](https://mui.com/material-ui/customization/css-theme-variables/usage/) to enable the feature.");
	const palette = createPalette({
		...paletteInput,
		colorSpace
	});
	const systemTheme = createTheme$1(options);
	let muiTheme = deepmerge(systemTheme, {
		mixins: createMixins(systemTheme.breakpoints, mixinsInput),
		palette,
		shadows: shadows.slice(),
		typography: createTypography(palette, typographyInput),
		motion: createMotion(motionInput),
		transitions: createTransitions(transitionsInput),
		zIndex: { ...zIndex }
	});
	muiTheme = deepmerge(muiTheme, other);
	muiTheme = args.reduce((acc, argument) => deepmerge(acc, argument), muiTheme);
	delete muiTheme.transitions.reducedMotion;
	{
		const stateClasses = [
			"active",
			"checked",
			"completed",
			"disabled",
			"error",
			"expanded",
			"focused",
			"focusVisible",
			"required",
			"selected"
		];
		const traverse = (node, component) => {
			let key;
			for (key in node) {
				const child = node[key];
				if (stateClasses.includes(key) && Object.keys(child).length > 0) {
					{
						const stateClass = generateUtilityClass("", key);
						console.error([
							`MUI: The \`${component}\` component increases the CSS specificity of the \`${key}\` internal state.`,
							"You can not override it like this: ",
							JSON.stringify(node, null, 2),
							"",
							`Instead, you need to use the '&.${stateClass}' syntax:`,
							JSON.stringify({ root: { [`&.${stateClass}`]: child } }, null, 2),
							"",
							"https://mui.com/r/state-classes-guide"
						].join("\n"));
					}
					node[key] = {};
				}
			}
		};
		Object.keys(muiTheme.components).forEach((component) => {
			const styleOverrides = muiTheme.components[component].styleOverrides;
			if (styleOverrides && component.startsWith("Mui")) traverse(styleOverrides, component);
		});
	}
	muiTheme.unstable_sxConfig = {
		...defaultSxConfig,
		...other?.unstable_sxConfig
	};
	muiTheme.unstable_sx = function sx(props) {
		return styleFunctionSx_default({
			sx: props,
			theme: this
		});
	};
	muiTheme.toRuntimeSource = stringifyTheme;
	attachColorManipulators(muiTheme);
	return muiTheme;
}
//#endregion
//#region node_modules/@mui/material/styles/getOverlayAlpha.mjs
function getOverlayAlpha(elevation) {
	let alphaValue;
	if (elevation < 1) alphaValue = 5.11916 * elevation ** 2;
	else alphaValue = 4.5 * Math.log(elevation + 1) + 2;
	return Math.round(alphaValue * 10) / 1e3;
}
//#endregion
//#region node_modules/@mui/material/styles/createColorScheme.mjs
var defaultDarkOverlays = [...Array(25)].map((_, index) => {
	if (index === 0) return "none";
	const overlay = getOverlayAlpha(index);
	return `linear-gradient(rgba(255 255 255 / ${overlay}), rgba(255 255 255 / ${overlay}))`;
});
function getOpacity(mode) {
	return {
		inputPlaceholder: mode === "dark" ? .5 : .42,
		inputUnderline: mode === "dark" ? .7 : .42,
		switchTrackDisabled: mode === "dark" ? .2 : .12,
		switchTrack: mode === "dark" ? .3 : .38
	};
}
function getOverlays(mode) {
	return mode === "dark" ? defaultDarkOverlays : [];
}
function createColorScheme(options) {
	const { palette: paletteInput = { mode: "light" }, opacity, overlays, colorSpace, ...other } = options;
	const palette = createPalette({
		...paletteInput,
		colorSpace
	});
	return {
		palette,
		opacity: {
			...getOpacity(palette.mode),
			...opacity
		},
		overlays: overlays || getOverlays(palette.mode),
		...other
	};
}
//#endregion
//#region node_modules/@mui/material/styles/shouldSkipGeneratingVar.mjs
function shouldSkipGeneratingVar(keys) {
	return keys[0] === "motion" || !!keys[0].match(/(cssVarPrefix|colorSchemeSelector|modularCssLayers|rootSelector|typography|mixins|breakpoints|direction|transitions)/) || !!keys[0].match(/sxConfig$/) || keys[0] === "palette" && !!keys[1]?.match(/(mode|contrastThreshold|tonalOffset)/);
}
//#endregion
//#region node_modules/@mui/material/styles/excludeVariablesFromRoot.mjs
/**
* @internal These variables should not appear in the :root stylesheet when the `defaultColorScheme="dark"`
*/
var excludeVariablesFromRoot = (cssVarPrefix) => [
	...[...Array(25)].map((_, index) => `--${cssVarPrefix ? `${cssVarPrefix}-` : ""}overlays-${index}`),
	`--${cssVarPrefix ? `${cssVarPrefix}-` : ""}palette-AppBar-darkBg`,
	`--${cssVarPrefix ? `${cssVarPrefix}-` : ""}palette-AppBar-darkColor`
];
//#endregion
//#region node_modules/@mui/material/styles/createGetSelector.mjs
var createGetSelector_default = (theme) => (colorScheme, css) => {
	const root = theme.rootSelector || ":root";
	const selector = theme.colorSchemeSelector;
	let rule = selector;
	if (selector === "class") rule = ".%s";
	if (selector === "data") rule = "[data-%s]";
	if (selector?.startsWith("data-") && !selector.includes("%s")) rule = `[${selector}="%s"]`;
	if (theme.defaultColorScheme === colorScheme) {
		if (colorScheme === "dark") {
			const excludedVariables = {};
			excludeVariablesFromRoot(theme.cssVarPrefix).forEach((cssVar) => {
				excludedVariables[cssVar] = css[cssVar];
				delete css[cssVar];
			});
			if (rule === "media") return {
				[root]: css,
				[`@media (prefers-color-scheme: dark)`]: { [root]: excludedVariables }
			};
			if (rule) return {
				[rule.replace("%s", colorScheme)]: excludedVariables,
				[`${root}, ${rule.replace("%s", colorScheme)}`]: css
			};
			return { [root]: {
				...css,
				...excludedVariables
			} };
		}
		if (rule && rule !== "media") return `${root}, ${rule.replace("%s", String(colorScheme))}`;
	} else if (colorScheme) {
		if (rule === "media") return { [`@media (prefers-color-scheme: ${String(colorScheme)})`]: { [root]: css } };
		if (rule) return rule.replace("%s", String(colorScheme));
	}
	return root;
};
//#endregion
//#region node_modules/@mui/material/styles/createThemeWithVars.mjs
function assignNode(obj, keys) {
	keys.forEach((k) => {
		if (!obj[k]) obj[k] = {};
	});
}
function setColor(obj, key, defaultValue) {
	if (!obj[key] && defaultValue) obj[key] = defaultValue;
}
function toRgb(color) {
	if (typeof color !== "string" || !color.startsWith("hsl")) return color;
	return hslToRgb(color);
}
function setColorChannel(obj, key) {
	if (!(`${key}Channel` in obj)) obj[`${key}Channel`] = private_safeColorChannel(toRgb(obj[key]), `MUI: Can't create \`palette.${key}Channel\` because \`palette.${key}\` is not one of these formats: #nnn, #nnnnnn, rgb(), rgba(), hsl(), hsla(), color().
To suppress this warning, you need to explicitly provide the \`palette.${key}Channel\` as a string (in rgb format, for example "12 12 12") or undefined if you want to remove the channel token.`);
}
function getSpacingVal(spacingInput) {
	if (typeof spacingInput === "number") return `${spacingInput}px`;
	if (typeof spacingInput === "string" || typeof spacingInput === "function" || Array.isArray(spacingInput)) return spacingInput;
	return "8px";
}
var silent = (fn) => {
	try {
		return fn();
	} catch (error) {}
};
var createGetCssVar = (cssVarPrefix = "mui") => createGetCssVar$1(cssVarPrefix);
function attachColorScheme$1(colorSpace, colorSchemes, scheme, restTheme, colorScheme) {
	if (!scheme) return;
	scheme = scheme === true ? {} : scheme;
	const mode = colorScheme === "dark" ? "dark" : "light";
	if (!restTheme) {
		colorSchemes[colorScheme] = createColorScheme({
			...scheme,
			palette: {
				mode,
				...scheme?.palette
			},
			colorSpace
		});
		return;
	}
	const { palette, ...muiTheme } = createThemeNoVars({
		...restTheme,
		palette: {
			mode,
			...scheme?.palette
		},
		colorSpace
	});
	colorSchemes[colorScheme] = {
		...scheme,
		palette,
		opacity: {
			...getOpacity(mode),
			...scheme?.opacity
		},
		overlays: scheme?.overlays || getOverlays(mode)
	};
	return muiTheme;
}
/**
* A default `createThemeWithVars` comes with a single color scheme, either `light` or `dark` based on the `defaultColorScheme`.
* This is better suited for apps that only need a single color scheme.
*
* To enable built-in `light` and `dark` color schemes, either:
* 1. provide a `colorSchemeSelector` to define how the color schemes will change.
* 2. provide `colorSchemes.dark` will set `colorSchemeSelector: 'media'` by default.
*/
function createThemeWithVars(options = {}, ...args) {
	const { colorSchemes: colorSchemesInput = { light: true }, defaultColorScheme: defaultColorSchemeInput, disableCssColorScheme = false, cssVarPrefix = "mui", nativeColor = false, shouldSkipGeneratingVar: shouldSkipGeneratingVar$1 = shouldSkipGeneratingVar, colorSchemeSelector: selector = colorSchemesInput.light && colorSchemesInput.dark ? "media" : void 0, rootSelector = ":root", ...input } = options;
	const firstColorScheme = Object.keys(colorSchemesInput)[0];
	const defaultColorScheme = defaultColorSchemeInput || (colorSchemesInput.light && firstColorScheme !== "light" ? "light" : firstColorScheme);
	const getCssVar = createGetCssVar(cssVarPrefix);
	const { [defaultColorScheme]: defaultSchemeInput, light: builtInLight, dark: builtInDark, ...customColorSchemes } = colorSchemesInput;
	const colorSchemes = { ...customColorSchemes };
	let defaultScheme = defaultSchemeInput;
	if (defaultColorScheme === "dark" && !("dark" in colorSchemesInput) || defaultColorScheme === "light" && !("light" in colorSchemesInput)) defaultScheme = true;
	if (!defaultScheme) throw new Error(`MUI: The \`colorSchemes.${defaultColorScheme}\` option is either missing or invalid.`);
	let colorSpace;
	if (nativeColor) colorSpace = "oklch";
	const muiTheme = attachColorScheme$1(colorSpace, colorSchemes, defaultScheme, input, defaultColorScheme);
	if (builtInLight && !colorSchemes.light) attachColorScheme$1(colorSpace, colorSchemes, builtInLight, void 0, "light");
	if (builtInDark && !colorSchemes.dark) attachColorScheme$1(colorSpace, colorSchemes, builtInDark, void 0, "dark");
	let theme = {
		defaultColorScheme,
		...muiTheme,
		cssVarPrefix,
		colorSchemeSelector: selector,
		rootSelector,
		getCssVar,
		colorSchemes,
		font: {
			...prepareTypographyVars(muiTheme.typography),
			...muiTheme.font
		},
		spacing: getSpacingVal(input.spacing)
	};
	Object.keys(theme.colorSchemes).forEach((key) => {
		const palette = theme.colorSchemes[key].palette;
		const setCssVarColor = (cssVar) => {
			const tokens = cssVar.split("-");
			const color = tokens[1];
			const colorToken = tokens[2];
			return getCssVar(cssVar, palette[color][colorToken]);
		};
		if (palette.mode === "light") {
			setColor(palette.common, "background", "#fff");
			setColor(palette.common, "onBackground", "#000");
		}
		if (palette.mode === "dark") {
			setColor(palette.common, "background", "#000");
			setColor(palette.common, "onBackground", "#fff");
		}
		function colorMix(method, color, coefficient) {
			if (colorSpace) {
				let mixer;
				if (method === private_safeAlpha) mixer = `transparent ${((1 - coefficient) * 100).toFixed(0)}%`;
				if (method === private_safeDarken) mixer = `#000 ${(coefficient * 100).toFixed(0)}%`;
				if (method === private_safeLighten) mixer = `#fff ${(coefficient * 100).toFixed(0)}%`;
				return `color-mix(in ${colorSpace}, ${color}, ${mixer})`;
			}
			return method(color, coefficient);
		}
		assignNode(palette, [
			"Alert",
			"AppBar",
			"Avatar",
			"Button",
			"Chip",
			"FilledInput",
			"LinearProgress",
			"Skeleton",
			"Slider",
			"SnackbarContent",
			"SpeedDialAction",
			"StepConnector",
			"StepContent",
			"Switch",
			"TableCell",
			"Tooltip"
		]);
		if (palette.mode === "light") {
			setColor(palette.Alert, "errorColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-error-light") : palette.error.light, .6));
			setColor(palette.Alert, "infoColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-info-light") : palette.info.light, .6));
			setColor(palette.Alert, "successColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-success-light") : palette.success.light, .6));
			setColor(palette.Alert, "warningColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-warning-light") : palette.warning.light, .6));
			setColor(palette.Alert, "errorFilledBg", setCssVarColor("palette-error-main"));
			setColor(palette.Alert, "infoFilledBg", setCssVarColor("palette-info-main"));
			setColor(palette.Alert, "successFilledBg", setCssVarColor("palette-success-main"));
			setColor(palette.Alert, "warningFilledBg", setCssVarColor("palette-warning-main"));
			setColor(palette.Alert, "errorFilledColor", silent(() => palette.getContrastText(palette.error.main)));
			setColor(palette.Alert, "infoFilledColor", silent(() => palette.getContrastText(palette.info.main)));
			setColor(palette.Alert, "successFilledColor", silent(() => palette.getContrastText(palette.success.main)));
			setColor(palette.Alert, "warningFilledColor", silent(() => palette.getContrastText(palette.warning.main)));
			setColor(palette.Alert, "errorStandardBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-error-light") : palette.error.light, .9));
			setColor(palette.Alert, "infoStandardBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-info-light") : palette.info.light, .9));
			setColor(palette.Alert, "successStandardBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-success-light") : palette.success.light, .9));
			setColor(palette.Alert, "warningStandardBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-warning-light") : palette.warning.light, .9));
			setColor(palette.Alert, "errorIconColor", setCssVarColor("palette-error-main"));
			setColor(palette.Alert, "infoIconColor", setCssVarColor("palette-info-main"));
			setColor(palette.Alert, "successIconColor", setCssVarColor("palette-success-main"));
			setColor(palette.Alert, "warningIconColor", setCssVarColor("palette-warning-main"));
			setColor(palette.AppBar, "defaultBg", setCssVarColor("palette-grey-100"));
			setColor(palette.Avatar, "defaultBg", setCssVarColor("palette-grey-400"));
			setColor(palette.Button, "inheritContainedBg", setCssVarColor("palette-grey-300"));
			setColor(palette.Button, "inheritContainedHoverBg", setCssVarColor("palette-grey-A100"));
			setColor(palette.Chip, "defaultBorder", setCssVarColor("palette-grey-400"));
			setColor(palette.Chip, "defaultAvatarColor", setCssVarColor("palette-grey-700"));
			setColor(palette.Chip, "defaultIconColor", setCssVarColor("palette-grey-700"));
			setColor(palette.FilledInput, "bg", "rgba(0, 0, 0, 0.06)");
			setColor(palette.FilledInput, "hoverBg", "rgba(0, 0, 0, 0.09)");
			setColor(palette.FilledInput, "disabledBg", "rgba(0, 0, 0, 0.12)");
			setColor(palette.LinearProgress, "primaryBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .62));
			setColor(palette.LinearProgress, "secondaryBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .62));
			setColor(palette.LinearProgress, "errorBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .62));
			setColor(palette.LinearProgress, "infoBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .62));
			setColor(palette.LinearProgress, "successBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .62));
			setColor(palette.LinearProgress, "warningBg", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-warning-light") : palette.warning.main, .62));
			setColor(palette.Skeleton, "bg", colorSpace ? colorMix(private_safeAlpha, nativeColor ? getCssVar("palette-text-primary") : palette.text.primary, .11) : `rgba(${setCssVarColor("palette-text-primaryChannel")} / 0.11)`);
			setColor(palette.Slider, "primaryTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .62));
			setColor(palette.Slider, "secondaryTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .62));
			setColor(palette.Slider, "errorTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .62));
			setColor(palette.Slider, "infoTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .62));
			setColor(palette.Slider, "successTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .62));
			setColor(palette.Slider, "warningTrack", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-warning-main") : palette.warning.main, .62));
			const snackbarContentBackground = colorSpace ? colorMix(private_safeDarken, nativeColor ? getCssVar("palette-background-default") : palette.background.default, .6825) : private_safeEmphasize(palette.background.default, .8);
			setColor(palette.SnackbarContent, "bg", snackbarContentBackground);
			setColor(palette.SnackbarContent, "color", silent(() => colorSpace ? dark.text.primary : palette.getContrastText(snackbarContentBackground)));
			setColor(palette.SpeedDialAction, "fabHoverBg", private_safeEmphasize(palette.background.paper, .15));
			setColor(palette.StepConnector, "border", setCssVarColor("palette-grey-400"));
			setColor(palette.StepContent, "border", setCssVarColor("palette-grey-400"));
			setColor(palette.Switch, "defaultColor", setCssVarColor("palette-common-white"));
			setColor(palette.Switch, "defaultDisabledColor", setCssVarColor("palette-grey-100"));
			setColor(palette.Switch, "primaryDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .62));
			setColor(palette.Switch, "secondaryDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .62));
			setColor(palette.Switch, "errorDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .62));
			setColor(palette.Switch, "infoDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .62));
			setColor(palette.Switch, "successDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .62));
			setColor(palette.Switch, "warningDisabledColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-warning-main") : palette.warning.main, .62));
			setColor(palette.TableCell, "border", colorMix(private_safeLighten, private_safeAlpha(nativeColor ? getCssVar("palette-divider") : palette.divider, 1), .88));
			setColor(palette.Tooltip, "bg", colorMix(private_safeAlpha, nativeColor ? getCssVar("palette-grey-700") : palette.grey[700], .92));
		}
		if (palette.mode === "dark") {
			setColor(palette.Alert, "errorColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-error-light") : palette.error.light, .6));
			setColor(palette.Alert, "infoColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-info-light") : palette.info.light, .6));
			setColor(palette.Alert, "successColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-success-light") : palette.success.light, .6));
			setColor(palette.Alert, "warningColor", colorMix(private_safeLighten, nativeColor ? getCssVar("palette-warning-light") : palette.warning.light, .6));
			setColor(palette.Alert, "errorFilledBg", setCssVarColor("palette-error-dark"));
			setColor(palette.Alert, "infoFilledBg", setCssVarColor("palette-info-dark"));
			setColor(palette.Alert, "successFilledBg", setCssVarColor("palette-success-dark"));
			setColor(palette.Alert, "warningFilledBg", setCssVarColor("palette-warning-dark"));
			setColor(palette.Alert, "errorFilledColor", silent(() => palette.getContrastText(palette.error.dark)));
			setColor(palette.Alert, "infoFilledColor", silent(() => palette.getContrastText(palette.info.dark)));
			setColor(palette.Alert, "successFilledColor", silent(() => palette.getContrastText(palette.success.dark)));
			setColor(palette.Alert, "warningFilledColor", silent(() => palette.getContrastText(palette.warning.dark)));
			setColor(palette.Alert, "errorStandardBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-error-light") : palette.error.light, .9));
			setColor(palette.Alert, "infoStandardBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-info-light") : palette.info.light, .9));
			setColor(palette.Alert, "successStandardBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-success-light") : palette.success.light, .9));
			setColor(palette.Alert, "warningStandardBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-warning-light") : palette.warning.light, .9));
			setColor(palette.Alert, "errorIconColor", setCssVarColor("palette-error-main"));
			setColor(palette.Alert, "infoIconColor", setCssVarColor("palette-info-main"));
			setColor(palette.Alert, "successIconColor", setCssVarColor("palette-success-main"));
			setColor(palette.Alert, "warningIconColor", setCssVarColor("palette-warning-main"));
			setColor(palette.AppBar, "defaultBg", setCssVarColor("palette-grey-900"));
			setColor(palette.AppBar, "darkBg", setCssVarColor("palette-background-paper"));
			setColor(palette.AppBar, "darkColor", setCssVarColor("palette-text-primary"));
			setColor(palette.Avatar, "defaultBg", setCssVarColor("palette-grey-600"));
			setColor(palette.Button, "inheritContainedBg", setCssVarColor("palette-grey-800"));
			setColor(palette.Button, "inheritContainedHoverBg", setCssVarColor("palette-grey-700"));
			setColor(palette.Chip, "defaultBorder", setCssVarColor("palette-grey-700"));
			setColor(palette.Chip, "defaultAvatarColor", setCssVarColor("palette-grey-300"));
			setColor(palette.Chip, "defaultIconColor", setCssVarColor("palette-grey-300"));
			setColor(palette.FilledInput, "bg", "rgba(255, 255, 255, 0.09)");
			setColor(palette.FilledInput, "hoverBg", "rgba(255, 255, 255, 0.13)");
			setColor(palette.FilledInput, "disabledBg", "rgba(255, 255, 255, 0.12)");
			setColor(palette.LinearProgress, "primaryBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .5));
			setColor(palette.LinearProgress, "secondaryBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .5));
			setColor(palette.LinearProgress, "errorBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .5));
			setColor(palette.LinearProgress, "infoBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .5));
			setColor(palette.LinearProgress, "successBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .5));
			setColor(palette.LinearProgress, "warningBg", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-warning-main") : palette.warning.main, .5));
			setColor(palette.Skeleton, "bg", colorSpace ? colorMix(private_safeAlpha, nativeColor ? getCssVar("palette-text-primary") : palette.text.primary, .13) : `rgba(${setCssVarColor("palette-text-primaryChannel")} / 0.13)`);
			setColor(palette.Slider, "primaryTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .5));
			setColor(palette.Slider, "secondaryTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .5));
			setColor(palette.Slider, "errorTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .5));
			setColor(palette.Slider, "infoTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .5));
			setColor(palette.Slider, "successTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .5));
			setColor(palette.Slider, "warningTrack", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-warning-light") : palette.warning.main, .5));
			const snackbarContentBackground = colorSpace ? colorMix(private_safeLighten, nativeColor ? getCssVar("palette-background-default") : palette.background.default, .985) : private_safeEmphasize(palette.background.default, .98);
			setColor(palette.SnackbarContent, "bg", snackbarContentBackground);
			setColor(palette.SnackbarContent, "color", silent(() => colorSpace ? light.text.primary : palette.getContrastText(snackbarContentBackground)));
			setColor(palette.SpeedDialAction, "fabHoverBg", private_safeEmphasize(palette.background.paper, .15));
			setColor(palette.StepConnector, "border", setCssVarColor("palette-grey-600"));
			setColor(palette.StepContent, "border", setCssVarColor("palette-grey-600"));
			setColor(palette.Switch, "defaultColor", setCssVarColor("palette-grey-300"));
			setColor(palette.Switch, "defaultDisabledColor", setCssVarColor("palette-grey-600"));
			setColor(palette.Switch, "primaryDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-primary-main") : palette.primary.main, .55));
			setColor(palette.Switch, "secondaryDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-secondary-main") : palette.secondary.main, .55));
			setColor(palette.Switch, "errorDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-error-main") : palette.error.main, .55));
			setColor(palette.Switch, "infoDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-info-main") : palette.info.main, .55));
			setColor(palette.Switch, "successDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-success-main") : palette.success.main, .55));
			setColor(palette.Switch, "warningDisabledColor", colorMix(private_safeDarken, nativeColor ? getCssVar("palette-warning-light") : palette.warning.main, .55));
			setColor(palette.TableCell, "border", colorMix(private_safeDarken, private_safeAlpha(nativeColor ? getCssVar("palette-divider") : palette.divider, 1), .68));
			setColor(palette.Tooltip, "bg", colorMix(private_safeAlpha, nativeColor ? getCssVar("palette-grey-700") : palette.grey[700], .92));
		}
		if (!nativeColor) {
			setColorChannel(palette.background, "default");
			setColorChannel(palette.background, "paper");
			setColorChannel(palette.common, "background");
			setColorChannel(palette.common, "onBackground");
			setColorChannel(palette, "divider");
		}
		Object.keys(palette).forEach((color) => {
			const colors = palette[color];
			if (color !== "tonalOffset" && !nativeColor && colors && typeof colors === "object") {
				if (colors.main) setColor(palette[color], "mainChannel", private_safeColorChannel(toRgb(colors.main)));
				if (colors.light) setColor(palette[color], "lightChannel", private_safeColorChannel(toRgb(colors.light)));
				if (colors.dark) setColor(palette[color], "darkChannel", private_safeColorChannel(toRgb(colors.dark)));
				if (colors.contrastText) setColor(palette[color], "contrastTextChannel", private_safeColorChannel(toRgb(colors.contrastText)));
				if (color === "text") {
					setColorChannel(palette[color], "primary");
					setColorChannel(palette[color], "secondary");
				}
				if (color === "action") {
					if (colors.active) setColorChannel(palette[color], "active");
					if (colors.selected) setColorChannel(palette[color], "selected");
				}
			}
		});
	});
	theme = args.reduce((acc, argument) => deepmerge(acc, argument), theme);
	const parserConfig = {
		prefix: cssVarPrefix,
		disableCssColorScheme,
		shouldSkipGeneratingVar: shouldSkipGeneratingVar$1,
		getSelector: createGetSelector_default(theme),
		enableContrastVars: nativeColor
	};
	const { vars, generateThemeVars, generateStyleSheets } = prepareCssVars(theme, parserConfig);
	theme.vars = vars;
	Object.entries(theme.colorSchemes[theme.defaultColorScheme]).forEach(([key, value]) => {
		theme[key] = value;
	});
	theme.generateThemeVars = generateThemeVars;
	theme.generateStyleSheets = generateStyleSheets;
	theme.generateSpacing = function generateSpacing() {
		return createSpacing(input.spacing, createUnarySpacing(this));
	};
	theme.getColorSchemeSelector = createGetColorSchemeSelector(selector);
	theme.spacing = theme.generateSpacing();
	theme.shouldSkipGeneratingVar = shouldSkipGeneratingVar$1;
	theme.unstable_sxConfig = {
		...defaultSxConfig,
		...input?.unstable_sxConfig
	};
	theme.unstable_sx = function sx(props) {
		return styleFunctionSx_default({
			sx: props,
			theme: this
		});
	};
	theme.internal_cache = {};
	theme.toRuntimeSource = stringifyTheme;
	return theme;
}
//#endregion
//#region node_modules/@mui/material/styles/createTheme.mjs
function attachColorScheme(theme, scheme, colorScheme) {
	if (!theme.colorSchemes) return;
	if (colorScheme) theme.colorSchemes[scheme] = {
		...colorScheme !== true && colorScheme,
		palette: createPalette({
			...colorScheme === true ? {} : colorScheme.palette,
			mode: scheme
		})
	};
}
/**
* Generate a theme base on the options received.
* @param options Takes an incomplete theme object and adds the missing parts.
* @param args Deep merge the arguments with the about to be returned theme.
* @returns A complete, ready-to-use theme object.
*/
function createTheme(options = {}, ...args) {
	const { palette, cssVariables = false, colorSchemes: initialColorSchemes = !palette ? { light: true } : void 0, defaultColorScheme: initialDefaultColorScheme = palette?.mode, ...other } = options;
	const defaultColorSchemeInput = initialDefaultColorScheme || "light";
	const defaultScheme = initialColorSchemes?.[defaultColorSchemeInput];
	const colorSchemesInput = {
		...initialColorSchemes,
		...palette ? { [defaultColorSchemeInput]: {
			...typeof defaultScheme !== "boolean" && defaultScheme,
			palette
		} } : void 0
	};
	if (cssVariables === false) {
		if (!("colorSchemes" in options)) return createThemeNoVars(options, ...args);
		let paletteOptions = palette;
		if (!("palette" in options)) {
			if (colorSchemesInput[defaultColorSchemeInput]) {
				if (colorSchemesInput[defaultColorSchemeInput] !== true) paletteOptions = colorSchemesInput[defaultColorSchemeInput].palette;
				else if (defaultColorSchemeInput === "dark") paletteOptions = { mode: "dark" };
			}
		}
		const theme = createThemeNoVars({
			...options,
			palette: paletteOptions
		}, ...args);
		theme.defaultColorScheme = defaultColorSchemeInput;
		theme.colorSchemes = colorSchemesInput;
		if (theme.palette.mode === "light") {
			theme.colorSchemes.light = {
				...colorSchemesInput.light !== true && colorSchemesInput.light,
				palette: theme.palette
			};
			attachColorScheme(theme, "dark", colorSchemesInput.dark);
		}
		if (theme.palette.mode === "dark") {
			theme.colorSchemes.dark = {
				...colorSchemesInput.dark !== true && colorSchemesInput.dark,
				palette: theme.palette
			};
			attachColorScheme(theme, "light", colorSchemesInput.light);
		}
		return theme;
	}
	if (!palette && !("light" in colorSchemesInput) && defaultColorSchemeInput === "light") colorSchemesInput.light = true;
	return createThemeWithVars({
		...other,
		colorSchemes: colorSchemesInput,
		defaultColorScheme: defaultColorSchemeInput,
		...typeof cssVariables !== "boolean" && cssVariables
	}, ...args);
}
//#endregion
//#region node_modules/@mui/material/styles/defaultTheme.mjs
var defaultTheme = createTheme();
//#endregion
//#region node_modules/@mui/material/styles/identifier.mjs
var identifier_default = "$$material";
//#endregion
//#region node_modules/@mui/material/styles/slotShouldForwardProp.mjs
function slotShouldForwardProp(prop) {
	return prop !== "ownerState" && prop !== "theme" && prop !== "sx" && prop !== "as";
}
//#endregion
//#region node_modules/@mui/material/styles/rootShouldForwardProp.mjs
var rootShouldForwardProp = (prop) => slotShouldForwardProp(prop) && prop !== "classes";
//#endregion
//#region node_modules/@mui/material/styles/styled.mjs
var styled = createStyled({
	themeId: identifier_default,
	defaultTheme,
	rootShouldForwardProp
});
//#endregion
//#region node_modules/@mui/material/utils/memoTheme.mjs
var memoTheme = unstable_memoTheme;
//#endregion
//#region node_modules/@mui/material/DefaultPropsProvider/DefaultPropsProvider.mjs
function DefaultPropsProvider(props) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DefaultPropsProvider$1, { ...props });
}
DefaultPropsProvider.propTypes = {
	/**
	* @ignore
	*/
	children: import_prop_types.default.node,
	/**
	* @ignore
	*/
	value: import_prop_types.default.object.isRequired
};
function useDefaultProps(params) {
	return useDefaultProps$1(params);
}
//#endregion
//#region node_modules/@mui/material/SvgIcon/svgIconClasses.mjs
function getSvgIconUtilityClass(slot) {
	return generateUtilityClass("MuiSvgIcon", slot);
}
var svgIconClasses = generateUtilityClasses("MuiSvgIcon", [
	"root",
	"colorPrimary",
	"colorSecondary",
	"colorAction",
	"colorError",
	"colorDisabled",
	"fontSizeInherit",
	"fontSizeSmall",
	"fontSizeMedium",
	"fontSizeLarge"
]);
//#endregion
//#region node_modules/@mui/material/styles/reducedMotion.mjs
var defaultStyles = { transition: "none" };
function resolveReducedMotionStyles(reducedMotion, styles) {
	if (reducedMotion === "always") return styles;
	if (reducedMotion === "system") return { "@media (prefers-reduced-motion: reduce)": styles };
	return null;
}
//#endregion
//#region node_modules/@mui/material/transitions/utils.mjs
var reflow = (node) => node.scrollTop;
var DEFAULT_TRANSLATE_OFFSET = {
	offsetX: 0,
	offsetY: 0
};
var EMPTY_STYLE = {};
var DEFAULT_TRANSITION_PROPS = ["all"];
var EMPTY_OPTIONS = {};
var transformOffsetIndexes = {
	matrix: [4, 5],
	matrix3d: [12, 13],
	translate: [0, 1],
	translate3d: [0, 1],
	translateX: [0, null],
	translateY: [null, 0]
};
function parseTranslateValue(value) {
	const parsedValue = parseFloat(value ?? "");
	return Number.isNaN(parsedValue) ? 0 : parsedValue;
}
function parseTransform(transform) {
	const match = transform.match(/^(matrix|matrix3d|translate|translate3d|translateX|translateY)\((.+)\)$/);
	if (!match) return null;
	return {
		type: match[1],
		values: match[2].split(",").map(parseTranslateValue)
	};
}
function getTranslateOffsetValue(values, index) {
	return index === null ? 0 : values[index] || 0;
}
/**
* Extracts the x/y translation from a CSS transform string.
*
* Transition components use these offsets when calculating off-screen positions:
* if an element is already translated, the distance needed to hide it must start
* from that visual position instead of its untransformed layout position.
*
* CSSOM commonly serializes translations as matrix() or matrix3d(), while inline
* gesture styles may use translate(), translate3d(), translateX(), or
* translateY(). This helper normalizes those supported forms into numeric pixel
* offsets and returns zero offsets for empty, none, or unsupported transforms.
*/
function getTranslateOffsets(transform) {
	if (!transform || transform === "none") return DEFAULT_TRANSLATE_OFFSET;
	const parsedTransform = parseTransform(transform);
	if (!parsedTransform) return DEFAULT_TRANSLATE_OFFSET;
	const { type, values } = parsedTransform;
	const offsetIndexes = transformOffsetIndexes[type];
	if (!offsetIndexes) return DEFAULT_TRANSLATE_OFFSET;
	return {
		offsetX: getTranslateOffsetValue(values, offsetIndexes[0]),
		offsetY: getTranslateOffsetValue(values, offsetIndexes[1])
	};
}
function normalizedTransitionCallback(nodeRef, callback) {
	return (maybeIsAppearing) => {
		if (callback) {
			const node = nodeRef.current;
			if (maybeIsAppearing === void 0) callback(node);
			else callback(node, maybeIsAppearing);
		}
	};
}
/**
* Return the child style for a transition. Reuse predefined style objects when
* no custom styles are present so memoized children see the same object.
*/
function getTransitionChildStyle(state, inProp, baseStyles, hiddenStyles, styleProp, childStyle) {
	const base = state === "exited" && !inProp ? hiddenStyles : baseStyles[state] || baseStyles.exited;
	return styleProp || childStyle ? {
		...base,
		...styleProp,
		...childStyle
	} : base;
}
function getTransitionProps(props, options) {
	const { timeout, easing, style = EMPTY_STYLE } = props;
	return {
		duration: style.transitionDuration ?? (typeof timeout === "number" ? timeout : timeout[options.mode] || 0),
		easing: style.transitionTimingFunction ?? (typeof easing === "object" ? easing[options.mode] : easing),
		delay: style.transitionDelay
	};
}
/**
* Returns CSS that disables component-owned transitions when reduced motion is active.
* Pass custom styles only when the default `transition: none` reset is not enough.
*/
function getReducedMotionStyles(theme, styles) {
	const resolvedStyles = styles ?? defaultStyles;
	return resolveReducedMotionStyles(theme.motion?.reducedMotion, resolvedStyles);
}
function getTransitionStyles(theme, props = DEFAULT_TRANSITION_PROPS, options = EMPTY_OPTIONS) {
	const transition = theme.transitions?.create?.(props, options);
	const reducedMotionStyles = getReducedMotionStyles(theme);
	if (transition === void 0) return reducedMotionStyles ?? EMPTY_STYLE;
	const transitionStyles = { transition };
	return reducedMotionStyles ? {
		...transitionStyles,
		...reducedMotionStyles
	} : transitionStyles;
}
//#endregion
//#region node_modules/@mui/material/SvgIcon/SvgIcon.mjs
var useUtilityClasses = (ownerState) => {
	const { color, fontSize, classes } = ownerState;
	return composeClasses({ root: [
		"root",
		color !== "inherit" && `color${capitalize_default(color)}`,
		`fontSize${capitalize_default(fontSize)}`
	] }, getSvgIconUtilityClass, classes);
};
var SvgIconRoot = styled("svg", {
	name: "MuiSvgIcon",
	slot: "Root",
	overridesResolver: (props, styles) => {
		const { ownerState } = props;
		return [
			styles.root,
			ownerState.color !== "inherit" && styles[`color${capitalize_default(ownerState.color)}`],
			styles[`fontSize${capitalize_default(ownerState.fontSize)}`]
		];
	}
})(memoTheme(({ theme }) => ({
	userSelect: "none",
	width: "1em",
	height: "1em",
	display: "inline-block",
	flexShrink: 0,
	...getTransitionStyles(theme, "fill", { duration: (theme.vars ?? theme).transitions?.duration?.shorter }),
	variants: [
		{
			props: (props) => !props.hasSvgAsChild,
			style: { fill: "currentColor" }
		},
		{
			props: { fontSize: "inherit" },
			style: { fontSize: "inherit" }
		},
		{
			props: { fontSize: "small" },
			style: { fontSize: theme.typography?.pxToRem?.(20) || "1.25rem" }
		},
		{
			props: { fontSize: "medium" },
			style: { fontSize: theme.typography?.pxToRem?.(24) || "1.5rem" }
		},
		{
			props: { fontSize: "large" },
			style: { fontSize: theme.typography?.pxToRem?.(35) || "2.1875rem" }
		},
		...Object.entries((theme.vars ?? theme).palette).filter(([, value]) => value && value.main).map(([color]) => ({
			props: { color },
			style: { color: (theme.vars ?? theme).palette?.[color]?.main }
		})),
		{
			props: { color: "action" },
			style: { color: (theme.vars ?? theme).palette?.action?.active }
		},
		{
			props: { color: "disabled" },
			style: { color: (theme.vars ?? theme).palette?.action?.disabled }
		},
		{
			props: { color: "inherit" },
			style: { color: void 0 }
		}
	]
})));
var SvgIcon = /*#__PURE__*/ import_react.forwardRef(function SvgIcon(inProps, ref) {
	const props = useDefaultProps({
		props: inProps,
		name: "MuiSvgIcon"
	});
	const { children, className, color = "inherit", component = "svg", fontSize = "medium", htmlColor, inheritViewBox = false, titleAccess, viewBox = "0 0 24 24", ...other } = props;
	const hasSvgAsChild = /*#__PURE__*/ import_react.isValidElement(children) && children.type === "svg";
	const ownerState = {
		...props,
		color,
		component,
		fontSize,
		instanceFontSize: inProps.fontSize,
		inheritViewBox,
		viewBox,
		hasSvgAsChild
	};
	const more = {};
	if (!inheritViewBox) more.viewBox = viewBox;
	const classes = useUtilityClasses(ownerState);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(SvgIconRoot, {
		as: component,
		className: clsx(classes.root, className),
		focusable: "false",
		color: htmlColor,
		"aria-hidden": titleAccess ? void 0 : true,
		role: titleAccess ? "img" : void 0,
		ref,
		...more,
		...other,
		...hasSvgAsChild && children.props,
		ownerState,
		children: [hasSvgAsChild ? children.props.children : children, titleAccess ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)("title", { children: titleAccess }) : null]
	});
});
SvgIcon.propTypes = {
	/**
	* Node passed into the SVG element.
	*/
	children: import_prop_types.default.node,
	/**
	* Override or extend the styles applied to the component.
	*/
	classes: import_prop_types.default.object,
	/**
	* @ignore
	*/
	className: import_prop_types.default.string,
	/**
	* The color of the component.
	* It supports both default and custom theme colors, which can be added as shown in the
	* [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
	* You can use the `htmlColor` prop to apply a color attribute to the SVG element.
	* @default 'inherit'
	*/
	color: import_prop_types.default.oneOfType([import_prop_types.default.oneOf([
		"inherit",
		"action",
		"disabled",
		"primary",
		"secondary",
		"error",
		"info",
		"success",
		"warning"
	]), import_prop_types.default.string]),
	/**
	* The component used for the root node.
	* Either a string to use a HTML element or a component.
	*/
	component: import_prop_types.default.elementType,
	/**
	* The fontSize applied to the icon. Defaults to 24px, but can be configure to inherit font size.
	* @default 'medium'
	*/
	fontSize: import_prop_types.default.oneOfType([import_prop_types.default.oneOf([
		"inherit",
		"large",
		"medium",
		"small"
	]), import_prop_types.default.string]),
	/**
	* Applies a color attribute to the SVG element.
	*/
	htmlColor: import_prop_types.default.string,
	/**
	* If `true`, the root node will inherit the custom `component`'s viewBox and the `viewBox`
	* prop will be ignored.
	* Useful when you want to reference a custom `component` and have `SvgIcon` pass that
	* `component`'s viewBox to the root node.
	* @default false
	*/
	inheritViewBox: import_prop_types.default.bool,
	/**
	* The shape-rendering attribute. The behavior of the different options is described on the
	* [MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Attribute/shape-rendering).
	* If you are having issues with blurry icons you should investigate this prop.
	*/
	shapeRendering: import_prop_types.default.string,
	/**
	* The system prop that allows defining system overrides as well as additional CSS styles.
	*/
	sx: import_prop_types.default.oneOfType([
		import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([
			import_prop_types.default.func,
			import_prop_types.default.object,
			import_prop_types.default.bool
		])),
		import_prop_types.default.func,
		import_prop_types.default.object
	]),
	/**
	* Provides a human-readable title for the element that contains it.
	* https://www.w3.org/TR/SVG-access/#Equivalent
	*/
	titleAccess: import_prop_types.default.string,
	/**
	* Allows you to redefine what the coordinates without units mean inside an SVG element.
	* For example, if the SVG element is 500 (width) by 200 (height),
	* and you pass viewBox="0 0 50 20",
	* this means that the coordinates inside the SVG will go from the top left corner (0,0)
	* to bottom right (50,20) and each unit will be worth 10px.
	* @default '0 0 24 24'
	*/
	viewBox: import_prop_types.default.string
};
SvgIcon.muiName = "SvgIcon";
//#endregion
//#region node_modules/@mui/material/SvgIcon/createSvgIcon.mjs
/**
* Private module reserved for @mui packages.
*/
function createSvgIcon(path, displayName) {
	function Component(props, ref) {
		return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SvgIcon, {
			"data-testid": `${displayName}Icon`,
			ref,
			...props,
			children: path
		});
	}
	Component.displayName = `${displayName}Icon`;
	Component.muiName = SvgIcon.muiName;
	return /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(Component));
}
//#endregion
export { resolveProps as $, green as A, useRtl as B, createColorScheme as C, createBreakpoints as Ct, easing as D, composeClasses as Dt, duration as E, capitalize as Et, purple as F, getContrastRatio as G, darken as H, grey as I, hslToRgb as J, getLuminance as K, common as L, blue as M, orange as N, createTypography as O, require_prop_types as Ot, red as P, clamp as Q, DefaultPropsProvider$1 as R, shouldSkipGeneratingVar as S, resolveBreakpointValues as St, createTransitions as T, capitalize_default as Tt, decomposeColor as U, alpha as V, emphasize as W, recomposeColor as X, lighten as Y, rgbToHex as Z, identifier_default as _, createUnarySpacing as _t, getTransitionProps as a, createTheme$1 as at, createThemeWithVars as b, handleBreakpoints as bt, normalizedTransitionCallback as c, styled$1 as ct, svgIconClasses as d, keyframes as dt, createStyled as et, useDefaultProps as f, CacheProvider as ft, slotShouldForwardProp as g, styleFunctionSx_default as gt, rootShouldForwardProp as h, StyleSheet as ht, getTransitionChildStyle as i, ClassNameGenerator as it, lightBlue as j, createMixins as k, reflow as l, Global as lt, styled as m, createCache as mt, SvgIcon as n, generateUtilityClasses as nt, getTransitionStyles as o, createSpacing as ot, memoTheme as p, ThemeContext as pt, hexToRgb as q, getReducedMotionStyles as r, generateUtilityClass as rt, getTranslateOffsets as s, internal_serializeStyles as st, createSvgIcon as t, shouldForwardProp as tt, getSvgIconUtilityClass as u, css as ut, defaultTheme as v, getValue as vt, getOverlayAlpha as w, deepmerge as wt, excludeVariablesFromRoot as x, mergeBreakpointsInOrder as xt, createTheme as y, getPath as yt, RtlProvider as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlU3ZnSWNvbi1CVnNjM3E0TS5qcyIsIm5hbWVzIjpbIlByb3BUeXBlcyIsIkVNUFRZX1RIRU1FIiwic3R5bGUiLCJFTVBUWV9USEVNRSIsInN0eWxlIiwic3R5bGUiLCJzdHlsZSIsImJyZWFrcG9pbnRzTW9kdWxlLnZhbHVlcyIsInN0eWxlIiwiaXNEZXZlbG9wbWVudCIsIklMTEVHQUxfRVNDQVBFX1NFUVVFTkNFX0VSUk9SIiwidW5pdGxlc3MiLCJoYXNoU3RyaW5nIiwiJ3VzZUluc2VydGlvbicgKyAnRWZmZWN0JyIsIkluc2VydGlvbiIsImlzRGV2ZWxvcG1lbnQiLCJFbW90aW9uIiwiSW5zZXJ0aW9uIiwiY3JlYXRlU3R5bGVkIiwic3R5bGVkIiwiY3JlYXRlU3R5bGVkIiwic3R5bGVkIiwiZW1TdHlsZWQiLCJlbVNlcmlhbGl6ZVN0eWxlcyIsImNyZWF0ZVRoZW1lIiwic3R5bGVGdW5jdGlvblN4IiwiRm9yd2FyZFJlZiIsIk1lbW8iLCJjcmVhdGVUaGVtZSIsInNlcmlhbGl6ZVN0eWxlcyIsInN0eWxlRnVuY3Rpb25TeCIsInN0eWxlZEVuZ2luZVN0eWxlZCIsIlByb3BUeXBlcyIsIkRlZmF1bHRQcm9wc1Byb3ZpZGVyIiwiUHJvcFR5cGVzIiwidXNlRGVmYXVsdFByb3BzIiwiY3JlYXRlR2V0Q3NzVmFyIiwiREVGQVVMVF9UUkFOU0lUSU9OX1BST1BTIiwiRU1QVFlfT1BUSU9OUyIsInN5c3RlbUFscGhhIiwic3lzdGVtTGlnaHRlbiIsInN5c3RlbURhcmtlbiIsInN5c3RlbUNyZWF0ZVRoZW1lIiwic3R5bGVGdW5jdGlvblN4Iiwic2FmZUNvbG9yQ2hhbm5lbCIsInN5c3RlbUNyZWF0ZUdldENzc1ZhciIsImF0dGFjaENvbG9yU2NoZW1lIiwiZGVmYXVsdFNob3VsZFNraXBHZW5lcmF0aW5nVmFyIiwic2FmZUFscGhhIiwic2FmZURhcmtlbiIsInNhZmVMaWdodGVuIiwic2FmZUVtcGhhc2l6ZSIsImRlZmF1bHRHZXRTZWxlY3RvciIsInNob3VsZFNraXBHZW5lcmF0aW5nVmFyIiwic3R5bGVGdW5jdGlvblN4IiwiVEhFTUVfSUQiLCJTeXN0ZW1EZWZhdWx0UHJvcHNQcm92aWRlciIsIlByb3BUeXBlcyIsInVzZVN5c3RlbURlZmF1bHRQcm9wcyIsImNhcGl0YWxpemUiLCJQcm9wVHlwZXMiXSwic291cmNlcyI6WyIuLi8uLi9wcm9wLXR5cGVzL25vZGVfbW9kdWxlcy9yZWFjdC1pcy9janMvcmVhY3QtaXMuZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi9wcm9wLXR5cGVzL25vZGVfbW9kdWxlcy9yZWFjdC1pcy9pbmRleC5qcyIsIi4uLy4uL29iamVjdC1hc3NpZ24vaW5kZXguanMiLCIuLi8uLi9wcm9wLXR5cGVzL2xpYi9SZWFjdFByb3BUeXBlc1NlY3JldC5qcyIsIi4uLy4uL3Byb3AtdHlwZXMvbGliL2hhcy5qcyIsIi4uLy4uL3Byb3AtdHlwZXMvY2hlY2tQcm9wVHlwZXMuanMiLCIuLi8uLi9wcm9wLXR5cGVzL2ZhY3RvcnlXaXRoVHlwZUNoZWNrZXJzLmpzIiwiLi4vLi4vcHJvcC10eXBlcy9pbmRleC5qcyIsIi4uLy4uL0BtdWkvdXRpbHMvY29tcG9zZUNsYXNzZXMvY29tcG9zZUNsYXNzZXMubWpzIiwiLi4vLi4vQG11aS91dGlscy9jYXBpdGFsaXplL2NhcGl0YWxpemUubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC91dGlscy9jYXBpdGFsaXplLm1qcyIsIi4uLy4uL0BtdWkvdXRpbHMvZmFzdERlZXBBc3NpZ24vZmFzdERlZXBBc3NpZ24ubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vcmVzcG9uc2l2ZVByb3BUeXBlL3Jlc3BvbnNpdmVQcm9wVHlwZS5tanMiLCIuLi8uLi9AbXVpL3V0aWxzL2lzT2JqZWN0RW1wdHkvaXNPYmplY3RFbXB0eS5tanMiLCIuLi8uLi9AbXVpL3V0aWxzL2RlZXBtZXJnZS9kZWVwbWVyZ2UubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vY3NzQ29udGFpbmVyUXVlcmllcy9jc3NDb250YWluZXJRdWVyaWVzLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2NyZWF0ZUJyZWFrcG9pbnRzL2NyZWF0ZUJyZWFrcG9pbnRzLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2JyZWFrcG9pbnRzL2JyZWFrcG9pbnRzLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL3N0eWxlL3N0eWxlLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL3NwYWNpbmcvc3BhY2luZy5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9jb21wb3NlL2NvbXBvc2UubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vYm9yZGVycy9ib3JkZXJzLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2Nzc0dyaWQvY3NzR3JpZC5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9wYWxldHRlL3BhbGV0dGUubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vc2l6aW5nL3NpemluZy5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9zdHlsZUZ1bmN0aW9uU3gvZGVmYXVsdFN4Q29uZmlnLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL3N0eWxlRnVuY3Rpb25TeC9zdHlsZUZ1bmN0aW9uU3gubWpzIiwiLi4vLi4vQGVtb3Rpb24vc2hlZXQvZGlzdC9lbW90aW9uLXNoZWV0LmRldmVsb3BtZW50LmVzbS5qcyIsIi4uLy4uL3N0eWxpcy9zcmMvRW51bS5qcyIsIi4uLy4uL3N0eWxpcy9zcmMvVXRpbGl0eS5qcyIsIi4uLy4uL3N0eWxpcy9zcmMvVG9rZW5pemVyLmpzIiwiLi4vLi4vc3R5bGlzL3NyYy9QYXJzZXIuanMiLCIuLi8uLi9zdHlsaXMvc3JjL1NlcmlhbGl6ZXIuanMiLCIuLi8uLi9zdHlsaXMvc3JjL01pZGRsZXdhcmUuanMiLCIuLi8uLi9AZW1vdGlvbi9tZW1vaXplL2Rpc3QvZW1vdGlvbi1tZW1vaXplLmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL2NhY2hlL2Rpc3QvZW1vdGlvbi1jYWNoZS5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qcyIsIi4uLy4uL2hvaXN0LW5vbi1yZWFjdC1zdGF0aWNzL25vZGVfbW9kdWxlcy9yZWFjdC1pcy9janMvcmVhY3QtaXMuZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi9ob2lzdC1ub24tcmVhY3Qtc3RhdGljcy9ub2RlX21vZHVsZXMvcmVhY3QtaXMvaW5kZXguanMiLCIuLi8uLi9ob2lzdC1ub24tcmVhY3Qtc3RhdGljcy9kaXN0L2hvaXN0LW5vbi1yZWFjdC1zdGF0aWNzLmNqcy5qcyIsIi4uLy4uL0BlbW90aW9uL3V0aWxzL2Rpc3QvZW1vdGlvbi11dGlscy5icm93c2VyLmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL2hhc2gvZGlzdC9lbW90aW9uLWhhc2guZXNtLmpzIiwiLi4vLi4vQGVtb3Rpb24vdW5pdGxlc3MvZGlzdC9lbW90aW9uLXVuaXRsZXNzLmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL3NlcmlhbGl6ZS9kaXN0L2Vtb3Rpb24tc2VyaWFsaXplLmRldmVsb3BtZW50LmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL3VzZS1pbnNlcnRpb24tZWZmZWN0LXdpdGgtZmFsbGJhY2tzL2Rpc3QvZW1vdGlvbi11c2UtaW5zZXJ0aW9uLWVmZmVjdC13aXRoLWZhbGxiYWNrcy5icm93c2VyLmVzbS5qcyIsIi4uLy4uL0BlbW90aW9uL3JlYWN0L2Rpc3QvZW1vdGlvbi1lbGVtZW50LTQ4OTQ1OWYyLmJyb3dzZXIuZGV2ZWxvcG1lbnQuZXNtLmpzIiwiLi4vLi4vQGVtb3Rpb24vcmVhY3QvZGlzdC9lbW90aW9uLXJlYWN0LmJyb3dzZXIuZGV2ZWxvcG1lbnQuZXNtLmpzIiwiLi4vLi4vQGVtb3Rpb24vaXMtcHJvcC12YWxpZC9kaXN0L2Vtb3Rpb24taXMtcHJvcC12YWxpZC5lc20uanMiLCIuLi8uLi9AZW1vdGlvbi9zdHlsZWQvYmFzZS9kaXN0L2Vtb3Rpb24tc3R5bGVkLWJhc2UuYnJvd3Nlci5kZXZlbG9wbWVudC5lc20uanMiLCIuLi8uLi9AZW1vdGlvbi9zdHlsZWQvZGlzdC9lbW90aW9uLXN0eWxlZC5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qcyIsIi4uLy4uL0BtdWkvc3R5bGVkLWVuZ2luZS9pbmRleC5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9jcmVhdGVUaGVtZS9zaGFwZS5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9jcmVhdGVUaGVtZS9jcmVhdGVTcGFjaW5nLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2NyZWF0ZVRoZW1lL2FwcGx5U3R5bGVzLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2NyZWF0ZVRoZW1lL2NyZWF0ZVRoZW1lLm1qcyIsIi4uLy4uL0BtdWkvdXRpbHMvQ2xhc3NOYW1lR2VuZXJhdG9yL0NsYXNzTmFtZUdlbmVyYXRvci5tanMiLCIuLi8uLi9AbXVpL3V0aWxzL2dlbmVyYXRlVXRpbGl0eUNsYXNzL2dlbmVyYXRlVXRpbGl0eUNsYXNzLm1qcyIsIi4uLy4uL0BtdWkvdXRpbHMvZ2VuZXJhdGVVdGlsaXR5Q2xhc3Nlcy9nZW5lcmF0ZVV0aWxpdHlDbGFzc2VzLm1qcyIsIi4uLy4uL0BtdWkvdXRpbHMvZ2V0RGlzcGxheU5hbWUvZ2V0RGlzcGxheU5hbWUubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vcHJlcHJvY2Vzc1N0eWxlcy5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9jcmVhdGVTdHlsZWQvY3JlYXRlU3R5bGVkLm1qcyIsIi4uLy4uL0BtdWkvdXRpbHMvcmVzb2x2ZVByb3BzL3Jlc29sdmVQcm9wcy5tanMiLCIuLi8uLi9AbXVpL3V0aWxzL2NsYW1wL2NsYW1wLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2NvbG9yTWFuaXB1bGF0b3IvY29sb3JNYW5pcHVsYXRvci5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9SdGxQcm92aWRlci9pbmRleC5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9EZWZhdWx0UHJvcHNQcm92aWRlci9EZWZhdWx0UHJvcHNQcm92aWRlci5tanMiLCIuLi8uLi9AbXVpL3N5c3RlbS9tZW1vVGhlbWUubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vY3NzVmFycy9jcmVhdGVHZXRDc3NWYXIubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vY3NzVmFycy9jc3NWYXJzUGFyc2VyLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2Nzc1ZhcnMvcHJlcGFyZUNzc1ZhcnMubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vY3NzVmFycy9nZXRDb2xvclNjaGVtZVNlbGVjdG9yLm1qcyIsIi4uLy4uL0BtdWkvc3lzdGVtL2luZGV4Lm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvY29sb3JzL2NvbW1vbi5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL2NvbG9ycy9ncmV5Lm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvY29sb3JzL3B1cnBsZS5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL2NvbG9ycy9yZWQubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9jb2xvcnMvb3JhbmdlLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvY29sb3JzL2JsdWUubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9jb2xvcnMvbGlnaHRCbHVlLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvY29sb3JzL2dyZWVuLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL2NyZWF0ZVBhbGV0dGUubWpzIiwiLi4vLi4vQG11aS9zeXN0ZW0vY3NzVmFycy9wcmVwYXJlVHlwb2dyYXBoeVZhcnMubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvY3JlYXRlTWl4aW5zLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL2NyZWF0ZVR5cG9ncmFwaHkubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvc2hhZG93cy5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9jcmVhdGVUcmFuc2l0aW9ucy5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9jcmVhdGVNb3Rpb24ubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvekluZGV4Lm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL3N0cmluZ2lmeVRoZW1lLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL2NyZWF0ZVRoZW1lTm9WYXJzLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL2dldE92ZXJsYXlBbHBoYS5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9jcmVhdGVDb2xvclNjaGVtZS5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9zaG91bGRTa2lwR2VuZXJhdGluZ1Zhci5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9leGNsdWRlVmFyaWFibGVzRnJvbVJvb3QubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvY3JlYXRlR2V0U2VsZWN0b3IubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvY3JlYXRlVGhlbWVXaXRoVmFycy5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9jcmVhdGVUaGVtZS5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9kZWZhdWx0VGhlbWUubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvaWRlbnRpZmllci5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9zbG90U2hvdWxkRm9yd2FyZFByb3AubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9zdHlsZXMvcm9vdFNob3VsZEZvcndhcmRQcm9wLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvc3R5bGVzL3N0eWxlZC5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3V0aWxzL21lbW9UaGVtZS5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL0RlZmF1bHRQcm9wc1Byb3ZpZGVyL0RlZmF1bHRQcm9wc1Byb3ZpZGVyLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvU3ZnSWNvbi9zdmdJY29uQ2xhc3Nlcy5tanMiLCIuLi8uLi9AbXVpL21hdGVyaWFsL3N0eWxlcy9yZWR1Y2VkTW90aW9uLm1qcyIsIi4uLy4uL0BtdWkvbWF0ZXJpYWwvdHJhbnNpdGlvbnMvdXRpbHMubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9TdmdJY29uL1N2Z0ljb24ubWpzIiwiLi4vLi4vQG11aS9tYXRlcmlhbC9TdmdJY29uL2NyZWF0ZVN2Z0ljb24ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBAbGljZW5zZSBSZWFjdCB2MTYuMTMuMVxuICogcmVhY3QtaXMuZGV2ZWxvcG1lbnQuanNcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIEZhY2Vib29rLCBJbmMuIGFuZCBpdHMgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG4ndXNlIHN0cmljdCc7XG5cblxuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gIChmdW5jdGlvbigpIHtcbid1c2Ugc3RyaWN0JztcblxuLy8gVGhlIFN5bWJvbCB1c2VkIHRvIHRhZyB0aGUgUmVhY3RFbGVtZW50LWxpa2UgdHlwZXMuIElmIHRoZXJlIGlzIG5vIG5hdGl2ZSBTeW1ib2xcbi8vIG5vciBwb2x5ZmlsbCwgdGhlbiBhIHBsYWluIG51bWJlciBpcyB1c2VkIGZvciBwZXJmb3JtYW5jZS5cbnZhciBoYXNTeW1ib2wgPSB0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nICYmIFN5bWJvbC5mb3I7XG52YXIgUkVBQ1RfRUxFTUVOVF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuZWxlbWVudCcpIDogMHhlYWM3O1xudmFyIFJFQUNUX1BPUlRBTF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QucG9ydGFsJykgOiAweGVhY2E7XG52YXIgUkVBQ1RfRlJBR01FTlRfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LmZyYWdtZW50JykgOiAweGVhY2I7XG52YXIgUkVBQ1RfU1RSSUNUX01PREVfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LnN0cmljdF9tb2RlJykgOiAweGVhY2M7XG52YXIgUkVBQ1RfUFJPRklMRVJfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LnByb2ZpbGVyJykgOiAweGVhZDI7XG52YXIgUkVBQ1RfUFJPVklERVJfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LnByb3ZpZGVyJykgOiAweGVhY2Q7XG52YXIgUkVBQ1RfQ09OVEVYVF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuY29udGV4dCcpIDogMHhlYWNlOyAvLyBUT0RPOiBXZSBkb24ndCB1c2UgQXN5bmNNb2RlIG9yIENvbmN1cnJlbnRNb2RlIGFueW1vcmUuIFRoZXkgd2VyZSB0ZW1wb3Jhcnlcbi8vICh1bnN0YWJsZSkgQVBJcyB0aGF0IGhhdmUgYmVlbiByZW1vdmVkLiBDYW4gd2UgcmVtb3ZlIHRoZSBzeW1ib2xzP1xuXG52YXIgUkVBQ1RfQVNZTkNfTU9ERV9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuYXN5bmNfbW9kZScpIDogMHhlYWNmO1xudmFyIFJFQUNUX0NPTkNVUlJFTlRfTU9ERV9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuY29uY3VycmVudF9tb2RlJykgOiAweGVhY2Y7XG52YXIgUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LmZvcndhcmRfcmVmJykgOiAweGVhZDA7XG52YXIgUkVBQ1RfU1VTUEVOU0VfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LnN1c3BlbnNlJykgOiAweGVhZDE7XG52YXIgUkVBQ1RfU1VTUEVOU0VfTElTVF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3Quc3VzcGVuc2VfbGlzdCcpIDogMHhlYWQ4O1xudmFyIFJFQUNUX01FTU9fVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0Lm1lbW8nKSA6IDB4ZWFkMztcbnZhciBSRUFDVF9MQVpZX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5sYXp5JykgOiAweGVhZDQ7XG52YXIgUkVBQ1RfQkxPQ0tfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LmJsb2NrJykgOiAweGVhZDk7XG52YXIgUkVBQ1RfRlVOREFNRU5UQUxfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LmZ1bmRhbWVudGFsJykgOiAweGVhZDU7XG52YXIgUkVBQ1RfUkVTUE9OREVSX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5yZXNwb25kZXInKSA6IDB4ZWFkNjtcbnZhciBSRUFDVF9TQ09QRV9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3Quc2NvcGUnKSA6IDB4ZWFkNztcblxuZnVuY3Rpb24gaXNWYWxpZEVsZW1lbnRUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIHR5cGVvZiB0eXBlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdHlwZSA9PT0gJ2Z1bmN0aW9uJyB8fCAvLyBOb3RlOiBpdHMgdHlwZW9mIG1pZ2h0IGJlIG90aGVyIHRoYW4gJ3N5bWJvbCcgb3IgJ251bWJlcicgaWYgaXQncyBhIHBvbHlmaWxsLlxuICB0eXBlID09PSBSRUFDVF9GUkFHTUVOVF9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX0NPTkNVUlJFTlRfTU9ERV9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX1BST0ZJTEVSX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfU1RSSUNUX01PREVfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9TVVNQRU5TRV9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRSB8fCB0eXBlb2YgdHlwZSA9PT0gJ29iamVjdCcgJiYgdHlwZSAhPT0gbnVsbCAmJiAodHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfTEFaWV9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX01FTU9fVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9QUk9WSURFUl9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0NPTlRFWFRfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0ZVTkRBTUVOVEFMX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfUkVTUE9OREVSX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfU0NPUEVfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9CTE9DS19UWVBFKTtcbn1cblxuZnVuY3Rpb24gdHlwZU9mKG9iamVjdCkge1xuICBpZiAodHlwZW9mIG9iamVjdCA9PT0gJ29iamVjdCcgJiYgb2JqZWN0ICE9PSBudWxsKSB7XG4gICAgdmFyICQkdHlwZW9mID0gb2JqZWN0LiQkdHlwZW9mO1xuXG4gICAgc3dpdGNoICgkJHR5cGVvZikge1xuICAgICAgY2FzZSBSRUFDVF9FTEVNRU5UX1RZUEU6XG4gICAgICAgIHZhciB0eXBlID0gb2JqZWN0LnR5cGU7XG5cbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgY2FzZSBSRUFDVF9BU1lOQ19NT0RFX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9DT05DVVJSRU5UX01PREVfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX0ZSQUdNRU5UX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9QUk9GSUxFUl9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfU1RSSUNUX01PREVfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX1NVU1BFTlNFX1RZUEU6XG4gICAgICAgICAgICByZXR1cm4gdHlwZTtcblxuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB2YXIgJCR0eXBlb2ZUeXBlID0gdHlwZSAmJiB0eXBlLiQkdHlwZW9mO1xuXG4gICAgICAgICAgICBzd2l0Y2ggKCQkdHlwZW9mVHlwZSkge1xuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0NPTlRFWFRfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFOlxuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0xBWllfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9NRU1PX1RZUEU6XG4gICAgICAgICAgICAgIGNhc2UgUkVBQ1RfUFJPVklERVJfVFlQRTpcbiAgICAgICAgICAgICAgICByZXR1cm4gJCR0eXBlb2ZUeXBlO1xuXG4gICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuICQkdHlwZW9mO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgIH1cblxuICAgICAgY2FzZSBSRUFDVF9QT1JUQUxfVFlQRTpcbiAgICAgICAgcmV0dXJuICQkdHlwZW9mO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB1bmRlZmluZWQ7XG59IC8vIEFzeW5jTW9kZSBpcyBkZXByZWNhdGVkIGFsb25nIHdpdGggaXNBc3luY01vZGVcblxudmFyIEFzeW5jTW9kZSA9IFJFQUNUX0FTWU5DX01PREVfVFlQRTtcbnZhciBDb25jdXJyZW50TW9kZSA9IFJFQUNUX0NPTkNVUlJFTlRfTU9ERV9UWVBFO1xudmFyIENvbnRleHRDb25zdW1lciA9IFJFQUNUX0NPTlRFWFRfVFlQRTtcbnZhciBDb250ZXh0UHJvdmlkZXIgPSBSRUFDVF9QUk9WSURFUl9UWVBFO1xudmFyIEVsZW1lbnQgPSBSRUFDVF9FTEVNRU5UX1RZUEU7XG52YXIgRm9yd2FyZFJlZiA9IFJFQUNUX0ZPUldBUkRfUkVGX1RZUEU7XG52YXIgRnJhZ21lbnQgPSBSRUFDVF9GUkFHTUVOVF9UWVBFO1xudmFyIExhenkgPSBSRUFDVF9MQVpZX1RZUEU7XG52YXIgTWVtbyA9IFJFQUNUX01FTU9fVFlQRTtcbnZhciBQb3J0YWwgPSBSRUFDVF9QT1JUQUxfVFlQRTtcbnZhciBQcm9maWxlciA9IFJFQUNUX1BST0ZJTEVSX1RZUEU7XG52YXIgU3RyaWN0TW9kZSA9IFJFQUNUX1NUUklDVF9NT0RFX1RZUEU7XG52YXIgU3VzcGVuc2UgPSBSRUFDVF9TVVNQRU5TRV9UWVBFO1xudmFyIGhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQXN5bmNNb2RlID0gZmFsc2U7IC8vIEFzeW5jTW9kZSBzaG91bGQgYmUgZGVwcmVjYXRlZFxuXG5mdW5jdGlvbiBpc0FzeW5jTW9kZShvYmplY3QpIHtcbiAge1xuICAgIGlmICghaGFzV2FybmVkQWJvdXREZXByZWNhdGVkSXNBc3luY01vZGUpIHtcbiAgICAgIGhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQXN5bmNNb2RlID0gdHJ1ZTsgLy8gVXNpbmcgY29uc29sZVsnd2FybiddIHRvIGV2YWRlIEJhYmVsIGFuZCBFU0xpbnRcblxuICAgICAgY29uc29sZVsnd2FybiddKCdUaGUgUmVhY3RJcy5pc0FzeW5jTW9kZSgpIGFsaWFzIGhhcyBiZWVuIGRlcHJlY2F0ZWQsICcgKyAnYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiBSZWFjdCAxNysuIFVwZGF0ZSB5b3VyIGNvZGUgdG8gdXNlICcgKyAnUmVhY3RJcy5pc0NvbmN1cnJlbnRNb2RlKCkgaW5zdGVhZC4gSXQgaGFzIHRoZSBleGFjdCBzYW1lIEFQSS4nKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gaXNDb25jdXJyZW50TW9kZShvYmplY3QpIHx8IHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9BU1lOQ19NT0RFX1RZUEU7XG59XG5mdW5jdGlvbiBpc0NvbmN1cnJlbnRNb2RlKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0NPTkNVUlJFTlRfTU9ERV9UWVBFO1xufVxuZnVuY3Rpb24gaXNDb250ZXh0Q29uc3VtZXIob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfQ09OVEVYVF9UWVBFO1xufVxuZnVuY3Rpb24gaXNDb250ZXh0UHJvdmlkZXIob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfUFJPVklERVJfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzRWxlbWVudChvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVvZiBvYmplY3QgPT09ICdvYmplY3QnICYmIG9iamVjdCAhPT0gbnVsbCAmJiBvYmplY3QuJCR0eXBlb2YgPT09IFJFQUNUX0VMRU1FTlRfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzRm9yd2FyZFJlZihvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFO1xufVxuZnVuY3Rpb24gaXNGcmFnbWVudChvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9GUkFHTUVOVF9UWVBFO1xufVxuZnVuY3Rpb24gaXNMYXp5KG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0xBWllfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzTWVtbyhvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9NRU1PX1RZUEU7XG59XG5mdW5jdGlvbiBpc1BvcnRhbChvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9QT1JUQUxfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzUHJvZmlsZXIob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfUFJPRklMRVJfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzU3RyaWN0TW9kZShvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFO1xufVxuZnVuY3Rpb24gaXNTdXNwZW5zZShvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9TVVNQRU5TRV9UWVBFO1xufVxuXG5leHBvcnRzLkFzeW5jTW9kZSA9IEFzeW5jTW9kZTtcbmV4cG9ydHMuQ29uY3VycmVudE1vZGUgPSBDb25jdXJyZW50TW9kZTtcbmV4cG9ydHMuQ29udGV4dENvbnN1bWVyID0gQ29udGV4dENvbnN1bWVyO1xuZXhwb3J0cy5Db250ZXh0UHJvdmlkZXIgPSBDb250ZXh0UHJvdmlkZXI7XG5leHBvcnRzLkVsZW1lbnQgPSBFbGVtZW50O1xuZXhwb3J0cy5Gb3J3YXJkUmVmID0gRm9yd2FyZFJlZjtcbmV4cG9ydHMuRnJhZ21lbnQgPSBGcmFnbWVudDtcbmV4cG9ydHMuTGF6eSA9IExhenk7XG5leHBvcnRzLk1lbW8gPSBNZW1vO1xuZXhwb3J0cy5Qb3J0YWwgPSBQb3J0YWw7XG5leHBvcnRzLlByb2ZpbGVyID0gUHJvZmlsZXI7XG5leHBvcnRzLlN0cmljdE1vZGUgPSBTdHJpY3RNb2RlO1xuZXhwb3J0cy5TdXNwZW5zZSA9IFN1c3BlbnNlO1xuZXhwb3J0cy5pc0FzeW5jTW9kZSA9IGlzQXN5bmNNb2RlO1xuZXhwb3J0cy5pc0NvbmN1cnJlbnRNb2RlID0gaXNDb25jdXJyZW50TW9kZTtcbmV4cG9ydHMuaXNDb250ZXh0Q29uc3VtZXIgPSBpc0NvbnRleHRDb25zdW1lcjtcbmV4cG9ydHMuaXNDb250ZXh0UHJvdmlkZXIgPSBpc0NvbnRleHRQcm92aWRlcjtcbmV4cG9ydHMuaXNFbGVtZW50ID0gaXNFbGVtZW50O1xuZXhwb3J0cy5pc0ZvcndhcmRSZWYgPSBpc0ZvcndhcmRSZWY7XG5leHBvcnRzLmlzRnJhZ21lbnQgPSBpc0ZyYWdtZW50O1xuZXhwb3J0cy5pc0xhenkgPSBpc0xhenk7XG5leHBvcnRzLmlzTWVtbyA9IGlzTWVtbztcbmV4cG9ydHMuaXNQb3J0YWwgPSBpc1BvcnRhbDtcbmV4cG9ydHMuaXNQcm9maWxlciA9IGlzUHJvZmlsZXI7XG5leHBvcnRzLmlzU3RyaWN0TW9kZSA9IGlzU3RyaWN0TW9kZTtcbmV4cG9ydHMuaXNTdXNwZW5zZSA9IGlzU3VzcGVuc2U7XG5leHBvcnRzLmlzVmFsaWRFbGVtZW50VHlwZSA9IGlzVmFsaWRFbGVtZW50VHlwZTtcbmV4cG9ydHMudHlwZU9mID0gdHlwZU9mO1xuICB9KSgpO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJykge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2pzL3JlYWN0LWlzLnByb2R1Y3Rpb24ubWluLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2pzL3JlYWN0LWlzLmRldmVsb3BtZW50LmpzJyk7XG59XG4iLCIvKlxub2JqZWN0LWFzc2lnblxuKGMpIFNpbmRyZSBTb3JodXNcbkBsaWNlbnNlIE1JVFxuKi9cblxuJ3VzZSBzdHJpY3QnO1xuLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cbnZhciBnZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xudmFyIGhhc093blByb3BlcnR5ID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBwcm9wSXNFbnVtZXJhYmxlID0gT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcblxuZnVuY3Rpb24gdG9PYmplY3QodmFsKSB7XG5cdGlmICh2YWwgPT09IG51bGwgfHwgdmFsID09PSB1bmRlZmluZWQpIHtcblx0XHR0aHJvdyBuZXcgVHlwZUVycm9yKCdPYmplY3QuYXNzaWduIGNhbm5vdCBiZSBjYWxsZWQgd2l0aCBudWxsIG9yIHVuZGVmaW5lZCcpO1xuXHR9XG5cblx0cmV0dXJuIE9iamVjdCh2YWwpO1xufVxuXG5mdW5jdGlvbiBzaG91bGRVc2VOYXRpdmUoKSB7XG5cdHRyeSB7XG5cdFx0aWYgKCFPYmplY3QuYXNzaWduKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXG5cdFx0Ly8gRGV0ZWN0IGJ1Z2d5IHByb3BlcnR5IGVudW1lcmF0aW9uIG9yZGVyIGluIG9sZGVyIFY4IHZlcnNpb25zLlxuXG5cdFx0Ly8gaHR0cHM6Ly9idWdzLmNocm9taXVtLm9yZy9wL3Y4L2lzc3Vlcy9kZXRhaWw/aWQ9NDExOFxuXHRcdHZhciB0ZXN0MSA9IG5ldyBTdHJpbmcoJ2FiYycpOyAgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1uZXctd3JhcHBlcnNcblx0XHR0ZXN0MVs1XSA9ICdkZSc7XG5cdFx0aWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRlc3QxKVswXSA9PT0gJzUnKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXG5cdFx0Ly8gaHR0cHM6Ly9idWdzLmNocm9taXVtLm9yZy9wL3Y4L2lzc3Vlcy9kZXRhaWw/aWQ9MzA1NlxuXHRcdHZhciB0ZXN0MiA9IHt9O1xuXHRcdGZvciAodmFyIGkgPSAwOyBpIDwgMTA7IGkrKykge1xuXHRcdFx0dGVzdDJbJ18nICsgU3RyaW5nLmZyb21DaGFyQ29kZShpKV0gPSBpO1xuXHRcdH1cblx0XHR2YXIgb3JkZXIyID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGVzdDIpLm1hcChmdW5jdGlvbiAobikge1xuXHRcdFx0cmV0dXJuIHRlc3QyW25dO1xuXHRcdH0pO1xuXHRcdGlmIChvcmRlcjIuam9pbignJykgIT09ICcwMTIzNDU2Nzg5Jykge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblxuXHRcdC8vIGh0dHBzOi8vYnVncy5jaHJvbWl1bS5vcmcvcC92OC9pc3N1ZXMvZGV0YWlsP2lkPTMwNTZcblx0XHR2YXIgdGVzdDMgPSB7fTtcblx0XHQnYWJjZGVmZ2hpamtsbW5vcHFyc3QnLnNwbGl0KCcnKS5mb3JFYWNoKGZ1bmN0aW9uIChsZXR0ZXIpIHtcblx0XHRcdHRlc3QzW2xldHRlcl0gPSBsZXR0ZXI7XG5cdFx0fSk7XG5cdFx0aWYgKE9iamVjdC5rZXlzKE9iamVjdC5hc3NpZ24oe30sIHRlc3QzKSkuam9pbignJykgIT09XG5cdFx0XHRcdCdhYmNkZWZnaGlqa2xtbm9wcXJzdCcpIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0Ly8gV2UgZG9uJ3QgZXhwZWN0IGFueSBvZiB0aGUgYWJvdmUgdG8gdGhyb3csIGJ1dCBiZXR0ZXIgdG8gYmUgc2FmZS5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBzaG91bGRVc2VOYXRpdmUoKSA/IE9iamVjdC5hc3NpZ24gOiBmdW5jdGlvbiAodGFyZ2V0LCBzb3VyY2UpIHtcblx0dmFyIGZyb207XG5cdHZhciB0byA9IHRvT2JqZWN0KHRhcmdldCk7XG5cdHZhciBzeW1ib2xzO1xuXG5cdGZvciAodmFyIHMgPSAxOyBzIDwgYXJndW1lbnRzLmxlbmd0aDsgcysrKSB7XG5cdFx0ZnJvbSA9IE9iamVjdChhcmd1bWVudHNbc10pO1xuXG5cdFx0Zm9yICh2YXIga2V5IGluIGZyb20pIHtcblx0XHRcdGlmIChoYXNPd25Qcm9wZXJ0eS5jYWxsKGZyb20sIGtleSkpIHtcblx0XHRcdFx0dG9ba2V5XSA9IGZyb21ba2V5XTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAoZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7XG5cdFx0XHRzeW1ib2xzID0gZ2V0T3duUHJvcGVydHlTeW1ib2xzKGZyb20pO1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBzeW1ib2xzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGlmIChwcm9wSXNFbnVtZXJhYmxlLmNhbGwoZnJvbSwgc3ltYm9sc1tpXSkpIHtcblx0XHRcdFx0XHR0b1tzeW1ib2xzW2ldXSA9IGZyb21bc3ltYm9sc1tpXV07XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gdG87XG59O1xuIiwiLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTMtcHJlc2VudCwgRmFjZWJvb2ssIEluYy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG4ndXNlIHN0cmljdCc7XG5cbnZhciBSZWFjdFByb3BUeXBlc1NlY3JldCA9ICdTRUNSRVRfRE9fTk9UX1BBU1NfVEhJU19PUl9ZT1VfV0lMTF9CRV9GSVJFRCc7XG5cbm1vZHVsZS5leHBvcnRzID0gUmVhY3RQcm9wVHlwZXNTZWNyZXQ7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IEZ1bmN0aW9uLmNhbGwuYmluZChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5KTtcbiIsIi8qKlxuICogQ29weXJpZ2h0IChjKSAyMDEzLXByZXNlbnQsIEZhY2Vib29rLCBJbmMuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxuJ3VzZSBzdHJpY3QnO1xuXG52YXIgcHJpbnRXYXJuaW5nID0gZnVuY3Rpb24oKSB7fTtcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgdmFyIFJlYWN0UHJvcFR5cGVzU2VjcmV0ID0gcmVxdWlyZSgnLi9saWIvUmVhY3RQcm9wVHlwZXNTZWNyZXQnKTtcbiAgdmFyIGxvZ2dlZFR5cGVGYWlsdXJlcyA9IHt9O1xuICB2YXIgaGFzID0gcmVxdWlyZSgnLi9saWIvaGFzJyk7XG5cbiAgcHJpbnRXYXJuaW5nID0gZnVuY3Rpb24odGV4dCkge1xuICAgIHZhciBtZXNzYWdlID0gJ1dhcm5pbmc6ICcgKyB0ZXh0O1xuICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IobWVzc2FnZSk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAvLyAtLS0gV2VsY29tZSB0byBkZWJ1Z2dpbmcgUmVhY3QgLS0tXG4gICAgICAvLyBUaGlzIGVycm9yIHdhcyB0aHJvd24gYXMgYSBjb252ZW5pZW5jZSBzbyB0aGF0IHlvdSBjYW4gdXNlIHRoaXMgc3RhY2tcbiAgICAgIC8vIHRvIGZpbmQgdGhlIGNhbGxzaXRlIHRoYXQgY2F1c2VkIHRoaXMgd2FybmluZyB0byBmaXJlLlxuICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgIH0gY2F0Y2ggKHgpIHsgLyoqLyB9XG4gIH07XG59XG5cbi8qKlxuICogQXNzZXJ0IHRoYXQgdGhlIHZhbHVlcyBtYXRjaCB3aXRoIHRoZSB0eXBlIHNwZWNzLlxuICogRXJyb3IgbWVzc2FnZXMgYXJlIG1lbW9yaXplZCBhbmQgd2lsbCBvbmx5IGJlIHNob3duIG9uY2UuXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IHR5cGVTcGVjcyBNYXAgb2YgbmFtZSB0byBhIFJlYWN0UHJvcFR5cGVcbiAqIEBwYXJhbSB7b2JqZWN0fSB2YWx1ZXMgUnVudGltZSB2YWx1ZXMgdGhhdCBuZWVkIHRvIGJlIHR5cGUtY2hlY2tlZFxuICogQHBhcmFtIHtzdHJpbmd9IGxvY2F0aW9uIGUuZy4gXCJwcm9wXCIsIFwiY29udGV4dFwiLCBcImNoaWxkIGNvbnRleHRcIlxuICogQHBhcmFtIHtzdHJpbmd9IGNvbXBvbmVudE5hbWUgTmFtZSBvZiB0aGUgY29tcG9uZW50IGZvciBlcnJvciBtZXNzYWdlcy5cbiAqIEBwYXJhbSB7P0Z1bmN0aW9ufSBnZXRTdGFjayBSZXR1cm5zIHRoZSBjb21wb25lbnQgc3RhY2suXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjaGVja1Byb3BUeXBlcyh0eXBlU3BlY3MsIHZhbHVlcywgbG9jYXRpb24sIGNvbXBvbmVudE5hbWUsIGdldFN0YWNrKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgZm9yICh2YXIgdHlwZVNwZWNOYW1lIGluIHR5cGVTcGVjcykge1xuICAgICAgaWYgKGhhcyh0eXBlU3BlY3MsIHR5cGVTcGVjTmFtZSkpIHtcbiAgICAgICAgdmFyIGVycm9yO1xuICAgICAgICAvLyBQcm9wIHR5cGUgdmFsaWRhdGlvbiBtYXkgdGhyb3cuIEluIGNhc2UgdGhleSBkbywgd2UgZG9uJ3Qgd2FudCB0b1xuICAgICAgICAvLyBmYWlsIHRoZSByZW5kZXIgcGhhc2Ugd2hlcmUgaXQgZGlkbid0IGZhaWwgYmVmb3JlLiBTbyB3ZSBsb2cgaXQuXG4gICAgICAgIC8vIEFmdGVyIHRoZXNlIGhhdmUgYmVlbiBjbGVhbmVkIHVwLCB3ZSdsbCBsZXQgdGhlbSB0aHJvdy5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBUaGlzIGlzIGludGVudGlvbmFsbHkgYW4gaW52YXJpYW50IHRoYXQgZ2V0cyBjYXVnaHQuIEl0J3MgdGhlIHNhbWVcbiAgICAgICAgICAvLyBiZWhhdmlvciBhcyB3aXRob3V0IHRoaXMgc3RhdGVtZW50IGV4Y2VwdCB3aXRoIGEgYmV0dGVyIG1lc3NhZ2UuXG4gICAgICAgICAgaWYgKHR5cGVvZiB0eXBlU3BlY3NbdHlwZVNwZWNOYW1lXSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdmFyIGVyciA9IEVycm9yKFxuICAgICAgICAgICAgICAoY29tcG9uZW50TmFtZSB8fCAnUmVhY3QgY2xhc3MnKSArICc6ICcgKyBsb2NhdGlvbiArICcgdHlwZSBgJyArIHR5cGVTcGVjTmFtZSArICdgIGlzIGludmFsaWQ7ICcgK1xuICAgICAgICAgICAgICAnaXQgbXVzdCBiZSBhIGZ1bmN0aW9uLCB1c3VhbGx5IGZyb20gdGhlIGBwcm9wLXR5cGVzYCBwYWNrYWdlLCBidXQgcmVjZWl2ZWQgYCcgKyB0eXBlb2YgdHlwZVNwZWNzW3R5cGVTcGVjTmFtZV0gKyAnYC4nICtcbiAgICAgICAgICAgICAgJ1RoaXMgb2Z0ZW4gaGFwcGVucyBiZWNhdXNlIG9mIHR5cG9zIHN1Y2ggYXMgYFByb3BUeXBlcy5mdW5jdGlvbmAgaW5zdGVhZCBvZiBgUHJvcFR5cGVzLmZ1bmNgLidcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBlcnIubmFtZSA9ICdJbnZhcmlhbnQgVmlvbGF0aW9uJztcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgZXJyb3IgPSB0eXBlU3BlY3NbdHlwZVNwZWNOYW1lXSh2YWx1ZXMsIHR5cGVTcGVjTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIG51bGwsIFJlYWN0UHJvcFR5cGVzU2VjcmV0KTtcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgICBlcnJvciA9IGV4O1xuICAgICAgICB9XG4gICAgICAgIGlmIChlcnJvciAmJiAhKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpKSB7XG4gICAgICAgICAgcHJpbnRXYXJuaW5nKFxuICAgICAgICAgICAgKGNvbXBvbmVudE5hbWUgfHwgJ1JlYWN0IGNsYXNzJykgKyAnOiB0eXBlIHNwZWNpZmljYXRpb24gb2YgJyArXG4gICAgICAgICAgICBsb2NhdGlvbiArICcgYCcgKyB0eXBlU3BlY05hbWUgKyAnYCBpcyBpbnZhbGlkOyB0aGUgdHlwZSBjaGVja2VyICcgK1xuICAgICAgICAgICAgJ2Z1bmN0aW9uIG11c3QgcmV0dXJuIGBudWxsYCBvciBhbiBgRXJyb3JgIGJ1dCByZXR1cm5lZCBhICcgKyB0eXBlb2YgZXJyb3IgKyAnLiAnICtcbiAgICAgICAgICAgICdZb3UgbWF5IGhhdmUgZm9yZ290dGVuIHRvIHBhc3MgYW4gYXJndW1lbnQgdG8gdGhlIHR5cGUgY2hlY2tlciAnICtcbiAgICAgICAgICAgICdjcmVhdG9yIChhcnJheU9mLCBpbnN0YW5jZU9mLCBvYmplY3RPZiwgb25lT2YsIG9uZU9mVHlwZSwgYW5kICcgK1xuICAgICAgICAgICAgJ3NoYXBlIGFsbCByZXF1aXJlIGFuIGFyZ3VtZW50KS4nXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiAhKGVycm9yLm1lc3NhZ2UgaW4gbG9nZ2VkVHlwZUZhaWx1cmVzKSkge1xuICAgICAgICAgIC8vIE9ubHkgbW9uaXRvciB0aGlzIGZhaWx1cmUgb25jZSBiZWNhdXNlIHRoZXJlIHRlbmRzIHRvIGJlIGEgbG90IG9mIHRoZVxuICAgICAgICAgIC8vIHNhbWUgZXJyb3IuXG4gICAgICAgICAgbG9nZ2VkVHlwZUZhaWx1cmVzW2Vycm9yLm1lc3NhZ2VdID0gdHJ1ZTtcblxuICAgICAgICAgIHZhciBzdGFjayA9IGdldFN0YWNrID8gZ2V0U3RhY2soKSA6ICcnO1xuXG4gICAgICAgICAgcHJpbnRXYXJuaW5nKFxuICAgICAgICAgICAgJ0ZhaWxlZCAnICsgbG9jYXRpb24gKyAnIHR5cGU6ICcgKyBlcnJvci5tZXNzYWdlICsgKHN0YWNrICE9IG51bGwgPyBzdGFjayA6ICcnKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBSZXNldHMgd2FybmluZyBjYWNoZSB3aGVuIHRlc3RpbmcuXG4gKlxuICogQHByaXZhdGVcbiAqL1xuY2hlY2tQcm9wVHlwZXMucmVzZXRXYXJuaW5nQ2FjaGUgPSBmdW5jdGlvbigpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBsb2dnZWRUeXBlRmFpbHVyZXMgPSB7fTtcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNoZWNrUHJvcFR5cGVzO1xuIiwiLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTMtcHJlc2VudCwgRmFjZWJvb2ssIEluYy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG4ndXNlIHN0cmljdCc7XG5cbnZhciBSZWFjdElzID0gcmVxdWlyZSgncmVhY3QtaXMnKTtcbnZhciBhc3NpZ24gPSByZXF1aXJlKCdvYmplY3QtYXNzaWduJyk7XG5cbnZhciBSZWFjdFByb3BUeXBlc1NlY3JldCA9IHJlcXVpcmUoJy4vbGliL1JlYWN0UHJvcFR5cGVzU2VjcmV0Jyk7XG52YXIgaGFzID0gcmVxdWlyZSgnLi9saWIvaGFzJyk7XG52YXIgY2hlY2tQcm9wVHlwZXMgPSByZXF1aXJlKCcuL2NoZWNrUHJvcFR5cGVzJyk7XG5cbnZhciBwcmludFdhcm5pbmcgPSBmdW5jdGlvbigpIHt9O1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICBwcmludFdhcm5pbmcgPSBmdW5jdGlvbih0ZXh0KSB7XG4gICAgdmFyIG1lc3NhZ2UgPSAnV2FybmluZzogJyArIHRleHQ7XG4gICAgaWYgKHR5cGVvZiBjb25zb2xlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgY29uc29sZS5lcnJvcihtZXNzYWdlKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIC8vIC0tLSBXZWxjb21lIHRvIGRlYnVnZ2luZyBSZWFjdCAtLS1cbiAgICAgIC8vIFRoaXMgZXJyb3Igd2FzIHRocm93biBhcyBhIGNvbnZlbmllbmNlIHNvIHRoYXQgeW91IGNhbiB1c2UgdGhpcyBzdGFja1xuICAgICAgLy8gdG8gZmluZCB0aGUgY2FsbHNpdGUgdGhhdCBjYXVzZWQgdGhpcyB3YXJuaW5nIHRvIGZpcmUuXG4gICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgfSBjYXRjaCAoeCkge31cbiAgfTtcbn1cblxuZnVuY3Rpb24gZW1wdHlGdW5jdGlvblRoYXRSZXR1cm5zTnVsbCgpIHtcbiAgcmV0dXJuIG51bGw7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24oaXNWYWxpZEVsZW1lbnQsIHRocm93T25EaXJlY3RBY2Nlc3MpIHtcbiAgLyogZ2xvYmFsIFN5bWJvbCAqL1xuICB2YXIgSVRFUkFUT1JfU1lNQk9MID0gdHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiBTeW1ib2wuaXRlcmF0b3I7XG4gIHZhciBGQVVYX0lURVJBVE9SX1NZTUJPTCA9ICdAQGl0ZXJhdG9yJzsgLy8gQmVmb3JlIFN5bWJvbCBzcGVjLlxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBpdGVyYXRvciBtZXRob2QgZnVuY3Rpb24gY29udGFpbmVkIG9uIHRoZSBpdGVyYWJsZSBvYmplY3QuXG4gICAqXG4gICAqIEJlIHN1cmUgdG8gaW52b2tlIHRoZSBmdW5jdGlvbiB3aXRoIHRoZSBpdGVyYWJsZSBhcyBjb250ZXh0OlxuICAgKlxuICAgKiAgICAgdmFyIGl0ZXJhdG9yRm4gPSBnZXRJdGVyYXRvckZuKG15SXRlcmFibGUpO1xuICAgKiAgICAgaWYgKGl0ZXJhdG9yRm4pIHtcbiAgICogICAgICAgdmFyIGl0ZXJhdG9yID0gaXRlcmF0b3JGbi5jYWxsKG15SXRlcmFibGUpO1xuICAgKiAgICAgICAuLi5cbiAgICogICAgIH1cbiAgICpcbiAgICogQHBhcmFtIHs/b2JqZWN0fSBtYXliZUl0ZXJhYmxlXG4gICAqIEByZXR1cm4gez9mdW5jdGlvbn1cbiAgICovXG4gIGZ1bmN0aW9uIGdldEl0ZXJhdG9yRm4obWF5YmVJdGVyYWJsZSkge1xuICAgIHZhciBpdGVyYXRvckZuID0gbWF5YmVJdGVyYWJsZSAmJiAoSVRFUkFUT1JfU1lNQk9MICYmIG1heWJlSXRlcmFibGVbSVRFUkFUT1JfU1lNQk9MXSB8fCBtYXliZUl0ZXJhYmxlW0ZBVVhfSVRFUkFUT1JfU1lNQk9MXSk7XG4gICAgaWYgKHR5cGVvZiBpdGVyYXRvckZuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICByZXR1cm4gaXRlcmF0b3JGbjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ29sbGVjdGlvbiBvZiBtZXRob2RzIHRoYXQgYWxsb3cgZGVjbGFyYXRpb24gYW5kIHZhbGlkYXRpb24gb2YgcHJvcHMgdGhhdCBhcmVcbiAgICogc3VwcGxpZWQgdG8gUmVhY3QgY29tcG9uZW50cy4gRXhhbXBsZSB1c2FnZTpcbiAgICpcbiAgICogICB2YXIgUHJvcHMgPSByZXF1aXJlKCdSZWFjdFByb3BUeXBlcycpO1xuICAgKiAgIHZhciBNeUFydGljbGUgPSBSZWFjdC5jcmVhdGVDbGFzcyh7XG4gICAqICAgICBwcm9wVHlwZXM6IHtcbiAgICogICAgICAgLy8gQW4gb3B0aW9uYWwgc3RyaW5nIHByb3AgbmFtZWQgXCJkZXNjcmlwdGlvblwiLlxuICAgKiAgICAgICBkZXNjcmlwdGlvbjogUHJvcHMuc3RyaW5nLFxuICAgKlxuICAgKiAgICAgICAvLyBBIHJlcXVpcmVkIGVudW0gcHJvcCBuYW1lZCBcImNhdGVnb3J5XCIuXG4gICAqICAgICAgIGNhdGVnb3J5OiBQcm9wcy5vbmVPZihbJ05ld3MnLCdQaG90b3MnXSkuaXNSZXF1aXJlZCxcbiAgICpcbiAgICogICAgICAgLy8gQSBwcm9wIG5hbWVkIFwiZGlhbG9nXCIgdGhhdCByZXF1aXJlcyBhbiBpbnN0YW5jZSBvZiBEaWFsb2cuXG4gICAqICAgICAgIGRpYWxvZzogUHJvcHMuaW5zdGFuY2VPZihEaWFsb2cpLmlzUmVxdWlyZWRcbiAgICogICAgIH0sXG4gICAqICAgICByZW5kZXI6IGZ1bmN0aW9uKCkgeyAuLi4gfVxuICAgKiAgIH0pO1xuICAgKlxuICAgKiBBIG1vcmUgZm9ybWFsIHNwZWNpZmljYXRpb24gb2YgaG93IHRoZXNlIG1ldGhvZHMgYXJlIHVzZWQ6XG4gICAqXG4gICAqICAgdHlwZSA6PSBhcnJheXxib29sfGZ1bmN8b2JqZWN0fG51bWJlcnxzdHJpbmd8b25lT2YoWy4uLl0pfGluc3RhbmNlT2YoLi4uKVxuICAgKiAgIGRlY2wgOj0gUmVhY3RQcm9wVHlwZXMue3R5cGV9KC5pc1JlcXVpcmVkKT9cbiAgICpcbiAgICogRWFjaCBhbmQgZXZlcnkgZGVjbGFyYXRpb24gcHJvZHVjZXMgYSBmdW5jdGlvbiB3aXRoIHRoZSBzYW1lIHNpZ25hdHVyZS4gVGhpc1xuICAgKiBhbGxvd3MgdGhlIGNyZWF0aW9uIG9mIGN1c3RvbSB2YWxpZGF0aW9uIGZ1bmN0aW9ucy4gRm9yIGV4YW1wbGU6XG4gICAqXG4gICAqICB2YXIgTXlMaW5rID0gUmVhY3QuY3JlYXRlQ2xhc3Moe1xuICAgKiAgICBwcm9wVHlwZXM6IHtcbiAgICogICAgICAvLyBBbiBvcHRpb25hbCBzdHJpbmcgb3IgVVJJIHByb3AgbmFtZWQgXCJocmVmXCIuXG4gICAqICAgICAgaHJlZjogZnVuY3Rpb24ocHJvcHMsIHByb3BOYW1lLCBjb21wb25lbnROYW1lKSB7XG4gICAqICAgICAgICB2YXIgcHJvcFZhbHVlID0gcHJvcHNbcHJvcE5hbWVdO1xuICAgKiAgICAgICAgaWYgKHByb3BWYWx1ZSAhPSBudWxsICYmIHR5cGVvZiBwcm9wVmFsdWUgIT09ICdzdHJpbmcnICYmXG4gICAqICAgICAgICAgICAgIShwcm9wVmFsdWUgaW5zdGFuY2VvZiBVUkkpKSB7XG4gICAqICAgICAgICAgIHJldHVybiBuZXcgRXJyb3IoXG4gICAqICAgICAgICAgICAgJ0V4cGVjdGVkIGEgc3RyaW5nIG9yIGFuIFVSSSBmb3IgJyArIHByb3BOYW1lICsgJyBpbiAnICtcbiAgICogICAgICAgICAgICBjb21wb25lbnROYW1lXG4gICAqICAgICAgICAgICk7XG4gICAqICAgICAgICB9XG4gICAqICAgICAgfVxuICAgKiAgICB9LFxuICAgKiAgICByZW5kZXI6IGZ1bmN0aW9uKCkgey4uLn1cbiAgICogIH0pO1xuICAgKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG5cbiAgdmFyIEFOT05ZTU9VUyA9ICc8PGFub255bW91cz4+JztcblxuICAvLyBJbXBvcnRhbnQhXG4gIC8vIEtlZXAgdGhpcyBsaXN0IGluIHN5bmMgd2l0aCBwcm9kdWN0aW9uIHZlcnNpb24gaW4gYC4vZmFjdG9yeVdpdGhUaHJvd2luZ1NoaW1zLmpzYC5cbiAgdmFyIFJlYWN0UHJvcFR5cGVzID0ge1xuICAgIGFycmF5OiBjcmVhdGVQcmltaXRpdmVUeXBlQ2hlY2tlcignYXJyYXknKSxcbiAgICBiaWdpbnQ6IGNyZWF0ZVByaW1pdGl2ZVR5cGVDaGVja2VyKCdiaWdpbnQnKSxcbiAgICBib29sOiBjcmVhdGVQcmltaXRpdmVUeXBlQ2hlY2tlcignYm9vbGVhbicpLFxuICAgIGZ1bmM6IGNyZWF0ZVByaW1pdGl2ZVR5cGVDaGVja2VyKCdmdW5jdGlvbicpLFxuICAgIG51bWJlcjogY3JlYXRlUHJpbWl0aXZlVHlwZUNoZWNrZXIoJ251bWJlcicpLFxuICAgIG9iamVjdDogY3JlYXRlUHJpbWl0aXZlVHlwZUNoZWNrZXIoJ29iamVjdCcpLFxuICAgIHN0cmluZzogY3JlYXRlUHJpbWl0aXZlVHlwZUNoZWNrZXIoJ3N0cmluZycpLFxuICAgIHN5bWJvbDogY3JlYXRlUHJpbWl0aXZlVHlwZUNoZWNrZXIoJ3N5bWJvbCcpLFxuXG4gICAgYW55OiBjcmVhdGVBbnlUeXBlQ2hlY2tlcigpLFxuICAgIGFycmF5T2Y6IGNyZWF0ZUFycmF5T2ZUeXBlQ2hlY2tlcixcbiAgICBlbGVtZW50OiBjcmVhdGVFbGVtZW50VHlwZUNoZWNrZXIoKSxcbiAgICBlbGVtZW50VHlwZTogY3JlYXRlRWxlbWVudFR5cGVUeXBlQ2hlY2tlcigpLFxuICAgIGluc3RhbmNlT2Y6IGNyZWF0ZUluc3RhbmNlVHlwZUNoZWNrZXIsXG4gICAgbm9kZTogY3JlYXRlTm9kZUNoZWNrZXIoKSxcbiAgICBvYmplY3RPZjogY3JlYXRlT2JqZWN0T2ZUeXBlQ2hlY2tlcixcbiAgICBvbmVPZjogY3JlYXRlRW51bVR5cGVDaGVja2VyLFxuICAgIG9uZU9mVHlwZTogY3JlYXRlVW5pb25UeXBlQ2hlY2tlcixcbiAgICBzaGFwZTogY3JlYXRlU2hhcGVUeXBlQ2hlY2tlcixcbiAgICBleGFjdDogY3JlYXRlU3RyaWN0U2hhcGVUeXBlQ2hlY2tlcixcbiAgfTtcblxuICAvKipcbiAgICogaW5saW5lZCBPYmplY3QuaXMgcG9seWZpbGwgdG8gYXZvaWQgcmVxdWlyaW5nIGNvbnN1bWVycyBzaGlwIHRoZWlyIG93blxuICAgKiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9PYmplY3QvaXNcbiAgICovXG4gIC8qZXNsaW50LWRpc2FibGUgbm8tc2VsZi1jb21wYXJlKi9cbiAgZnVuY3Rpb24gaXMoeCwgeSkge1xuICAgIC8vIFNhbWVWYWx1ZSBhbGdvcml0aG1cbiAgICBpZiAoeCA9PT0geSkge1xuICAgICAgLy8gU3RlcHMgMS01LCA3LTEwXG4gICAgICAvLyBTdGVwcyA2LmItNi5lOiArMCAhPSAtMFxuICAgICAgcmV0dXJuIHggIT09IDAgfHwgMSAvIHggPT09IDEgLyB5O1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBTdGVwIDYuYTogTmFOID09IE5hTlxuICAgICAgcmV0dXJuIHggIT09IHggJiYgeSAhPT0geTtcbiAgICB9XG4gIH1cbiAgLyplc2xpbnQtZW5hYmxlIG5vLXNlbGYtY29tcGFyZSovXG5cbiAgLyoqXG4gICAqIFdlIHVzZSBhbiBFcnJvci1saWtlIG9iamVjdCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eSBhcyBwZW9wbGUgbWF5IGNhbGxcbiAgICogUHJvcFR5cGVzIGRpcmVjdGx5IGFuZCBpbnNwZWN0IHRoZWlyIG91dHB1dC4gSG93ZXZlciwgd2UgZG9uJ3QgdXNlIHJlYWxcbiAgICogRXJyb3JzIGFueW1vcmUuIFdlIGRvbid0IGluc3BlY3QgdGhlaXIgc3RhY2sgYW55d2F5LCBhbmQgY3JlYXRpbmcgdGhlbVxuICAgKiBpcyBwcm9oaWJpdGl2ZWx5IGV4cGVuc2l2ZSBpZiB0aGV5IGFyZSBjcmVhdGVkIHRvbyBvZnRlbiwgc3VjaCBhcyB3aGF0XG4gICAqIGhhcHBlbnMgaW4gb25lT2ZUeXBlKCkgZm9yIGFueSB0eXBlIGJlZm9yZSB0aGUgb25lIHRoYXQgbWF0Y2hlZC5cbiAgICovXG4gIGZ1bmN0aW9uIFByb3BUeXBlRXJyb3IobWVzc2FnZSwgZGF0YSkge1xuICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG4gICAgdGhpcy5kYXRhID0gZGF0YSAmJiB0eXBlb2YgZGF0YSA9PT0gJ29iamVjdCcgPyBkYXRhOiB7fTtcbiAgICB0aGlzLnN0YWNrID0gJyc7XG4gIH1cbiAgLy8gTWFrZSBgaW5zdGFuY2VvZiBFcnJvcmAgc3RpbGwgd29yayBmb3IgcmV0dXJuZWQgZXJyb3JzLlxuICBQcm9wVHlwZUVycm9yLnByb3RvdHlwZSA9IEVycm9yLnByb3RvdHlwZTtcblxuICBmdW5jdGlvbiBjcmVhdGVDaGFpbmFibGVUeXBlQ2hlY2tlcih2YWxpZGF0ZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICB2YXIgbWFudWFsUHJvcFR5cGVDYWxsQ2FjaGUgPSB7fTtcbiAgICAgIHZhciBtYW51YWxQcm9wVHlwZVdhcm5pbmdDb3VudCA9IDA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNoZWNrVHlwZShpc1JlcXVpcmVkLCBwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUsIHNlY3JldCkge1xuICAgICAgY29tcG9uZW50TmFtZSA9IGNvbXBvbmVudE5hbWUgfHwgQU5PTllNT1VTO1xuICAgICAgcHJvcEZ1bGxOYW1lID0gcHJvcEZ1bGxOYW1lIHx8IHByb3BOYW1lO1xuXG4gICAgICBpZiAoc2VjcmV0ICE9PSBSZWFjdFByb3BUeXBlc1NlY3JldCkge1xuICAgICAgICBpZiAodGhyb3dPbkRpcmVjdEFjY2Vzcykge1xuICAgICAgICAgIC8vIE5ldyBiZWhhdmlvciBvbmx5IGZvciB1c2VycyBvZiBgcHJvcC10eXBlc2AgcGFja2FnZVxuICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoXG4gICAgICAgICAgICAnQ2FsbGluZyBQcm9wVHlwZXMgdmFsaWRhdG9ycyBkaXJlY3RseSBpcyBub3Qgc3VwcG9ydGVkIGJ5IHRoZSBgcHJvcC10eXBlc2AgcGFja2FnZS4gJyArXG4gICAgICAgICAgICAnVXNlIGBQcm9wVHlwZXMuY2hlY2tQcm9wVHlwZXMoKWAgdG8gY2FsbCB0aGVtLiAnICtcbiAgICAgICAgICAgICdSZWFkIG1vcmUgYXQgaHR0cDovL2ZiLm1lL3VzZS1jaGVjay1wcm9wLXR5cGVzJ1xuICAgICAgICAgICk7XG4gICAgICAgICAgZXJyLm5hbWUgPSAnSW52YXJpYW50IFZpb2xhdGlvbic7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9IGVsc2UgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgJiYgdHlwZW9mIGNvbnNvbGUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgLy8gT2xkIGJlaGF2aW9yIGZvciBwZW9wbGUgdXNpbmcgUmVhY3QuUHJvcFR5cGVzXG4gICAgICAgICAgdmFyIGNhY2hlS2V5ID0gY29tcG9uZW50TmFtZSArICc6JyArIHByb3BOYW1lO1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICFtYW51YWxQcm9wVHlwZUNhbGxDYWNoZVtjYWNoZUtleV0gJiZcbiAgICAgICAgICAgIC8vIEF2b2lkIHNwYW1taW5nIHRoZSBjb25zb2xlIGJlY2F1c2UgdGhleSBhcmUgb2Z0ZW4gbm90IGFjdGlvbmFibGUgZXhjZXB0IGZvciBsaWIgYXV0aG9yc1xuICAgICAgICAgICAgbWFudWFsUHJvcFR5cGVXYXJuaW5nQ291bnQgPCAzXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBwcmludFdhcm5pbmcoXG4gICAgICAgICAgICAgICdZb3UgYXJlIG1hbnVhbGx5IGNhbGxpbmcgYSBSZWFjdC5Qcm9wVHlwZXMgdmFsaWRhdGlvbiAnICtcbiAgICAgICAgICAgICAgJ2Z1bmN0aW9uIGZvciB0aGUgYCcgKyBwcm9wRnVsbE5hbWUgKyAnYCBwcm9wIG9uIGAnICsgY29tcG9uZW50TmFtZSArICdgLiBUaGlzIGlzIGRlcHJlY2F0ZWQgJyArXG4gICAgICAgICAgICAgICdhbmQgd2lsbCB0aHJvdyBpbiB0aGUgc3RhbmRhbG9uZSBgcHJvcC10eXBlc2AgcGFja2FnZS4gJyArXG4gICAgICAgICAgICAgICdZb3UgbWF5IGJlIHNlZWluZyB0aGlzIHdhcm5pbmcgZHVlIHRvIGEgdGhpcmQtcGFydHkgUHJvcFR5cGVzICcgK1xuICAgICAgICAgICAgICAnbGlicmFyeS4gU2VlIGh0dHBzOi8vZmIubWUvcmVhY3Qtd2FybmluZy1kb250LWNhbGwtcHJvcHR5cGVzICcgKyAnZm9yIGRldGFpbHMuJ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIG1hbnVhbFByb3BUeXBlQ2FsbENhY2hlW2NhY2hlS2V5XSA9IHRydWU7XG4gICAgICAgICAgICBtYW51YWxQcm9wVHlwZVdhcm5pbmdDb3VudCsrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHByb3BzW3Byb3BOYW1lXSA9PSBudWxsKSB7XG4gICAgICAgIGlmIChpc1JlcXVpcmVkKSB7XG4gICAgICAgICAgaWYgKHByb3BzW3Byb3BOYW1lXSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9wVHlwZUVycm9yKCdUaGUgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIGlzIG1hcmtlZCBhcyByZXF1aXJlZCAnICsgKCdpbiBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgYnV0IGl0cyB2YWx1ZSBpcyBgbnVsbGAuJykpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ1RoZSAnICsgbG9jYXRpb24gKyAnIGAnICsgcHJvcEZ1bGxOYW1lICsgJ2AgaXMgbWFya2VkIGFzIHJlcXVpcmVkIGluICcgKyAoJ2AnICsgY29tcG9uZW50TmFtZSArICdgLCBidXQgaXRzIHZhbHVlIGlzIGB1bmRlZmluZWRgLicpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiB2YWxpZGF0ZShwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZhciBjaGFpbmVkQ2hlY2tUeXBlID0gY2hlY2tUeXBlLmJpbmQobnVsbCwgZmFsc2UpO1xuICAgIGNoYWluZWRDaGVja1R5cGUuaXNSZXF1aXJlZCA9IGNoZWNrVHlwZS5iaW5kKG51bGwsIHRydWUpO1xuXG4gICAgcmV0dXJuIGNoYWluZWRDaGVja1R5cGU7XG4gIH1cblxuICBmdW5jdGlvbiBjcmVhdGVQcmltaXRpdmVUeXBlQ2hlY2tlcihleHBlY3RlZFR5cGUpIHtcbiAgICBmdW5jdGlvbiB2YWxpZGF0ZShwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUsIHNlY3JldCkge1xuICAgICAgdmFyIHByb3BWYWx1ZSA9IHByb3BzW3Byb3BOYW1lXTtcbiAgICAgIHZhciBwcm9wVHlwZSA9IGdldFByb3BUeXBlKHByb3BWYWx1ZSk7XG4gICAgICBpZiAocHJvcFR5cGUgIT09IGV4cGVjdGVkVHlwZSkge1xuICAgICAgICAvLyBgcHJvcFZhbHVlYCBiZWluZyBpbnN0YW5jZSBvZiwgc2F5LCBkYXRlL3JlZ2V4cCwgcGFzcyB0aGUgJ29iamVjdCdcbiAgICAgICAgLy8gY2hlY2ssIGJ1dCB3ZSBjYW4gb2ZmZXIgYSBtb3JlIHByZWNpc2UgZXJyb3IgbWVzc2FnZSBoZXJlIHJhdGhlciB0aGFuXG4gICAgICAgIC8vICdvZiB0eXBlIGBvYmplY3RgJy5cbiAgICAgICAgdmFyIHByZWNpc2VUeXBlID0gZ2V0UHJlY2lzZVR5cGUocHJvcFZhbHVlKTtcblxuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoXG4gICAgICAgICAgJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIHR5cGUgJyArICgnYCcgKyBwcmVjaXNlVHlwZSArICdgIHN1cHBsaWVkIHRvIGAnICsgY29tcG9uZW50TmFtZSArICdgLCBleHBlY3RlZCAnKSArICgnYCcgKyBleHBlY3RlZFR5cGUgKyAnYC4nKSxcbiAgICAgICAgICB7ZXhwZWN0ZWRUeXBlOiBleHBlY3RlZFR5cGV9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZUFueVR5cGVDaGVja2VyKCkge1xuICAgIHJldHVybiBjcmVhdGVDaGFpbmFibGVUeXBlQ2hlY2tlcihlbXB0eUZ1bmN0aW9uVGhhdFJldHVybnNOdWxsKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZUFycmF5T2ZUeXBlQ2hlY2tlcih0eXBlQ2hlY2tlcikge1xuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgaWYgKHR5cGVvZiB0eXBlQ2hlY2tlciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ1Byb3BlcnR5IGAnICsgcHJvcEZ1bGxOYW1lICsgJ2Agb2YgY29tcG9uZW50IGAnICsgY29tcG9uZW50TmFtZSArICdgIGhhcyBpbnZhbGlkIFByb3BUeXBlIG5vdGF0aW9uIGluc2lkZSBhcnJheU9mLicpO1xuICAgICAgfVxuICAgICAgdmFyIHByb3BWYWx1ZSA9IHByb3BzW3Byb3BOYW1lXTtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheShwcm9wVmFsdWUpKSB7XG4gICAgICAgIHZhciBwcm9wVHlwZSA9IGdldFByb3BUeXBlKHByb3BWYWx1ZSk7XG4gICAgICAgIHJldHVybiBuZXcgUHJvcFR5cGVFcnJvcignSW52YWxpZCAnICsgbG9jYXRpb24gKyAnIGAnICsgcHJvcEZ1bGxOYW1lICsgJ2Agb2YgdHlwZSAnICsgKCdgJyArIHByb3BUeXBlICsgJ2Agc3VwcGxpZWQgdG8gYCcgKyBjb21wb25lbnROYW1lICsgJ2AsIGV4cGVjdGVkIGFuIGFycmF5LicpKTtcbiAgICAgIH1cbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcFZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBlcnJvciA9IHR5cGVDaGVja2VyKHByb3BWYWx1ZSwgaSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSArICdbJyArIGkgKyAnXScsIFJlYWN0UHJvcFR5cGVzU2VjcmV0KTtcbiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlQ2hhaW5hYmxlVHlwZUNoZWNrZXIodmFsaWRhdGUpO1xuICB9XG5cbiAgZnVuY3Rpb24gY3JlYXRlRWxlbWVudFR5cGVDaGVja2VyKCkge1xuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgdmFyIHByb3BWYWx1ZSA9IHByb3BzW3Byb3BOYW1lXTtcbiAgICAgIGlmICghaXNWYWxpZEVsZW1lbnQocHJvcFZhbHVlKSkge1xuICAgICAgICB2YXIgcHJvcFR5cGUgPSBnZXRQcm9wVHlwZShwcm9wVmFsdWUpO1xuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIHR5cGUgJyArICgnYCcgKyBwcm9wVHlwZSArICdgIHN1cHBsaWVkIHRvIGAnICsgY29tcG9uZW50TmFtZSArICdgLCBleHBlY3RlZCBhIHNpbmdsZSBSZWFjdEVsZW1lbnQuJykpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiBjcmVhdGVDaGFpbmFibGVUeXBlQ2hlY2tlcih2YWxpZGF0ZSk7XG4gIH1cblxuICBmdW5jdGlvbiBjcmVhdGVFbGVtZW50VHlwZVR5cGVDaGVja2VyKCkge1xuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgdmFyIHByb3BWYWx1ZSA9IHByb3BzW3Byb3BOYW1lXTtcbiAgICAgIGlmICghUmVhY3RJcy5pc1ZhbGlkRWxlbWVudFR5cGUocHJvcFZhbHVlKSkge1xuICAgICAgICB2YXIgcHJvcFR5cGUgPSBnZXRQcm9wVHlwZShwcm9wVmFsdWUpO1xuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIHR5cGUgJyArICgnYCcgKyBwcm9wVHlwZSArICdgIHN1cHBsaWVkIHRvIGAnICsgY29tcG9uZW50TmFtZSArICdgLCBleHBlY3RlZCBhIHNpbmdsZSBSZWFjdEVsZW1lbnQgdHlwZS4nKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZUluc3RhbmNlVHlwZUNoZWNrZXIoZXhwZWN0ZWRDbGFzcykge1xuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgaWYgKCEocHJvcHNbcHJvcE5hbWVdIGluc3RhbmNlb2YgZXhwZWN0ZWRDbGFzcykpIHtcbiAgICAgICAgdmFyIGV4cGVjdGVkQ2xhc3NOYW1lID0gZXhwZWN0ZWRDbGFzcy5uYW1lIHx8IEFOT05ZTU9VUztcbiAgICAgICAgdmFyIGFjdHVhbENsYXNzTmFtZSA9IGdldENsYXNzTmFtZShwcm9wc1twcm9wTmFtZV0pO1xuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIHR5cGUgJyArICgnYCcgKyBhY3R1YWxDbGFzc05hbWUgKyAnYCBzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgZXhwZWN0ZWQgJykgKyAoJ2luc3RhbmNlIG9mIGAnICsgZXhwZWN0ZWRDbGFzc05hbWUgKyAnYC4nKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZUVudW1UeXBlQ2hlY2tlcihleHBlY3RlZFZhbHVlcykge1xuICAgIGlmICghQXJyYXkuaXNBcnJheShleHBlY3RlZFZhbHVlcykpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgICAgIHByaW50V2FybmluZyhcbiAgICAgICAgICAgICdJbnZhbGlkIGFyZ3VtZW50cyBzdXBwbGllZCB0byBvbmVPZiwgZXhwZWN0ZWQgYW4gYXJyYXksIGdvdCAnICsgYXJndW1lbnRzLmxlbmd0aCArICcgYXJndW1lbnRzLiAnICtcbiAgICAgICAgICAgICdBIGNvbW1vbiBtaXN0YWtlIGlzIHRvIHdyaXRlIG9uZU9mKHgsIHksIHopIGluc3RlYWQgb2Ygb25lT2YoW3gsIHksIHpdKS4nXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcmludFdhcm5pbmcoJ0ludmFsaWQgYXJndW1lbnQgc3VwcGxpZWQgdG8gb25lT2YsIGV4cGVjdGVkIGFuIGFycmF5LicpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gZW1wdHlGdW5jdGlvblRoYXRSZXR1cm5zTnVsbDtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiB2YWxpZGF0ZShwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUpIHtcbiAgICAgIHZhciBwcm9wVmFsdWUgPSBwcm9wc1twcm9wTmFtZV07XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGV4cGVjdGVkVmFsdWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChpcyhwcm9wVmFsdWUsIGV4cGVjdGVkVmFsdWVzW2ldKSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHZhciB2YWx1ZXNTdHJpbmcgPSBKU09OLnN0cmluZ2lmeShleHBlY3RlZFZhbHVlcywgZnVuY3Rpb24gcmVwbGFjZXIoa2V5LCB2YWx1ZSkge1xuICAgICAgICB2YXIgdHlwZSA9IGdldFByZWNpc2VUeXBlKHZhbHVlKTtcbiAgICAgICAgaWYgKHR5cGUgPT09ICdzeW1ib2wnKSB7XG4gICAgICAgICAgcmV0dXJuIFN0cmluZyh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIHZhbHVlIGAnICsgU3RyaW5nKHByb3BWYWx1ZSkgKyAnYCAnICsgKCdzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgZXhwZWN0ZWQgb25lIG9mICcgKyB2YWx1ZXNTdHJpbmcgKyAnLicpKTtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZU9iamVjdE9mVHlwZUNoZWNrZXIodHlwZUNoZWNrZXIpIHtcbiAgICBmdW5jdGlvbiB2YWxpZGF0ZShwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUpIHtcbiAgICAgIGlmICh0eXBlb2YgdHlwZUNoZWNrZXIgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9wVHlwZUVycm9yKCdQcm9wZXJ0eSBgJyArIHByb3BGdWxsTmFtZSArICdgIG9mIGNvbXBvbmVudCBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCBoYXMgaW52YWxpZCBQcm9wVHlwZSBub3RhdGlvbiBpbnNpZGUgb2JqZWN0T2YuJyk7XG4gICAgICB9XG4gICAgICB2YXIgcHJvcFZhbHVlID0gcHJvcHNbcHJvcE5hbWVdO1xuICAgICAgdmFyIHByb3BUeXBlID0gZ2V0UHJvcFR5cGUocHJvcFZhbHVlKTtcbiAgICAgIGlmIChwcm9wVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9wVHlwZUVycm9yKCdJbnZhbGlkICcgKyBsb2NhdGlvbiArICcgYCcgKyBwcm9wRnVsbE5hbWUgKyAnYCBvZiB0eXBlICcgKyAoJ2AnICsgcHJvcFR5cGUgKyAnYCBzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgZXhwZWN0ZWQgYW4gb2JqZWN0LicpKTtcbiAgICAgIH1cbiAgICAgIGZvciAodmFyIGtleSBpbiBwcm9wVmFsdWUpIHtcbiAgICAgICAgaWYgKGhhcyhwcm9wVmFsdWUsIGtleSkpIHtcbiAgICAgICAgICB2YXIgZXJyb3IgPSB0eXBlQ2hlY2tlcihwcm9wVmFsdWUsIGtleSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSArICcuJyArIGtleSwgUmVhY3RQcm9wVHlwZXNTZWNyZXQpO1xuICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZVVuaW9uVHlwZUNoZWNrZXIoYXJyYXlPZlR5cGVDaGVja2Vycykge1xuICAgIGlmICghQXJyYXkuaXNBcnJheShhcnJheU9mVHlwZUNoZWNrZXJzKSkge1xuICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IHByaW50V2FybmluZygnSW52YWxpZCBhcmd1bWVudCBzdXBwbGllZCB0byBvbmVPZlR5cGUsIGV4cGVjdGVkIGFuIGluc3RhbmNlIG9mIGFycmF5LicpIDogdm9pZCAwO1xuICAgICAgcmV0dXJuIGVtcHR5RnVuY3Rpb25UaGF0UmV0dXJuc051bGw7XG4gICAgfVxuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnJheU9mVHlwZUNoZWNrZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgY2hlY2tlciA9IGFycmF5T2ZUeXBlQ2hlY2tlcnNbaV07XG4gICAgICBpZiAodHlwZW9mIGNoZWNrZXIgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcHJpbnRXYXJuaW5nKFxuICAgICAgICAgICdJbnZhbGlkIGFyZ3VtZW50IHN1cHBsaWVkIHRvIG9uZU9mVHlwZS4gRXhwZWN0ZWQgYW4gYXJyYXkgb2YgY2hlY2sgZnVuY3Rpb25zLCBidXQgJyArXG4gICAgICAgICAgJ3JlY2VpdmVkICcgKyBnZXRQb3N0Zml4Rm9yVHlwZVdhcm5pbmcoY2hlY2tlcikgKyAnIGF0IGluZGV4ICcgKyBpICsgJy4nXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiBlbXB0eUZ1bmN0aW9uVGhhdFJldHVybnNOdWxsO1xuICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgdmFyIGV4cGVjdGVkVHlwZXMgPSBbXTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyYXlPZlR5cGVDaGVja2Vycy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgY2hlY2tlciA9IGFycmF5T2ZUeXBlQ2hlY2tlcnNbaV07XG4gICAgICAgIHZhciBjaGVja2VyUmVzdWx0ID0gY2hlY2tlcihwcm9wcywgcHJvcE5hbWUsIGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUsIFJlYWN0UHJvcFR5cGVzU2VjcmV0KTtcbiAgICAgICAgaWYgKGNoZWNrZXJSZXN1bHQgPT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGVja2VyUmVzdWx0LmRhdGEgJiYgaGFzKGNoZWNrZXJSZXN1bHQuZGF0YSwgJ2V4cGVjdGVkVHlwZScpKSB7XG4gICAgICAgICAgZXhwZWN0ZWRUeXBlcy5wdXNoKGNoZWNrZXJSZXN1bHQuZGF0YS5leHBlY3RlZFR5cGUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB2YXIgZXhwZWN0ZWRUeXBlc01lc3NhZ2UgPSAoZXhwZWN0ZWRUeXBlcy5sZW5ndGggPiAwKSA/ICcsIGV4cGVjdGVkIG9uZSBvZiB0eXBlIFsnICsgZXhwZWN0ZWRUeXBlcy5qb2luKCcsICcpICsgJ10nOiAnJztcbiAgICAgIHJldHVybiBuZXcgUHJvcFR5cGVFcnJvcignSW52YWxpZCAnICsgbG9jYXRpb24gKyAnIGAnICsgcHJvcEZ1bGxOYW1lICsgJ2Agc3VwcGxpZWQgdG8gJyArICgnYCcgKyBjb21wb25lbnROYW1lICsgJ2AnICsgZXhwZWN0ZWRUeXBlc01lc3NhZ2UgKyAnLicpKTtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZU5vZGVDaGVja2VyKCkge1xuICAgIGZ1bmN0aW9uIHZhbGlkYXRlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSkge1xuICAgICAgaWYgKCFpc05vZGUocHJvcHNbcHJvcE5hbWVdKSkge1xuICAgICAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoJ0ludmFsaWQgJyArIGxvY2F0aW9uICsgJyBgJyArIHByb3BGdWxsTmFtZSArICdgIHN1cHBsaWVkIHRvICcgKyAoJ2AnICsgY29tcG9uZW50TmFtZSArICdgLCBleHBlY3RlZCBhIFJlYWN0Tm9kZS4nKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUNoYWluYWJsZVR5cGVDaGVja2VyKHZhbGlkYXRlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGludmFsaWRWYWxpZGF0b3JFcnJvcihjb21wb25lbnROYW1lLCBsb2NhdGlvbiwgcHJvcEZ1bGxOYW1lLCBrZXksIHR5cGUpIHtcbiAgICByZXR1cm4gbmV3IFByb3BUeXBlRXJyb3IoXG4gICAgICAoY29tcG9uZW50TmFtZSB8fCAnUmVhY3QgY2xhc3MnKSArICc6ICcgKyBsb2NhdGlvbiArICcgdHlwZSBgJyArIHByb3BGdWxsTmFtZSArICcuJyArIGtleSArICdgIGlzIGludmFsaWQ7ICcgK1xuICAgICAgJ2l0IG11c3QgYmUgYSBmdW5jdGlvbiwgdXN1YWxseSBmcm9tIHRoZSBgcHJvcC10eXBlc2AgcGFja2FnZSwgYnV0IHJlY2VpdmVkIGAnICsgdHlwZSArICdgLidcbiAgICApO1xuICB9XG5cbiAgZnVuY3Rpb24gY3JlYXRlU2hhcGVUeXBlQ2hlY2tlcihzaGFwZVR5cGVzKSB7XG4gICAgZnVuY3Rpb24gdmFsaWRhdGUocHJvcHMsIHByb3BOYW1lLCBjb21wb25lbnROYW1lLCBsb2NhdGlvbiwgcHJvcEZ1bGxOYW1lKSB7XG4gICAgICB2YXIgcHJvcFZhbHVlID0gcHJvcHNbcHJvcE5hbWVdO1xuICAgICAgdmFyIHByb3BUeXBlID0gZ2V0UHJvcFR5cGUocHJvcFZhbHVlKTtcbiAgICAgIGlmIChwcm9wVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9wVHlwZUVycm9yKCdJbnZhbGlkICcgKyBsb2NhdGlvbiArICcgYCcgKyBwcm9wRnVsbE5hbWUgKyAnYCBvZiB0eXBlIGAnICsgcHJvcFR5cGUgKyAnYCAnICsgKCdzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgZXhwZWN0ZWQgYG9iamVjdGAuJykpO1xuICAgICAgfVxuICAgICAgZm9yICh2YXIga2V5IGluIHNoYXBlVHlwZXMpIHtcbiAgICAgICAgdmFyIGNoZWNrZXIgPSBzaGFwZVR5cGVzW2tleV07XG4gICAgICAgIGlmICh0eXBlb2YgY2hlY2tlciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIHJldHVybiBpbnZhbGlkVmFsaWRhdG9yRXJyb3IoY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSwga2V5LCBnZXRQcmVjaXNlVHlwZShjaGVja2VyKSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGVycm9yID0gY2hlY2tlcihwcm9wVmFsdWUsIGtleSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSArICcuJyArIGtleSwgUmVhY3RQcm9wVHlwZXNTZWNyZXQpO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlQ2hhaW5hYmxlVHlwZUNoZWNrZXIodmFsaWRhdGUpO1xuICB9XG5cbiAgZnVuY3Rpb24gY3JlYXRlU3RyaWN0U2hhcGVUeXBlQ2hlY2tlcihzaGFwZVR5cGVzKSB7XG4gICAgZnVuY3Rpb24gdmFsaWRhdGUocHJvcHMsIHByb3BOYW1lLCBjb21wb25lbnROYW1lLCBsb2NhdGlvbiwgcHJvcEZ1bGxOYW1lKSB7XG4gICAgICB2YXIgcHJvcFZhbHVlID0gcHJvcHNbcHJvcE5hbWVdO1xuICAgICAgdmFyIHByb3BUeXBlID0gZ2V0UHJvcFR5cGUocHJvcFZhbHVlKTtcbiAgICAgIGlmIChwcm9wVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9wVHlwZUVycm9yKCdJbnZhbGlkICcgKyBsb2NhdGlvbiArICcgYCcgKyBwcm9wRnVsbE5hbWUgKyAnYCBvZiB0eXBlIGAnICsgcHJvcFR5cGUgKyAnYCAnICsgKCdzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgZXhwZWN0ZWQgYG9iamVjdGAuJykpO1xuICAgICAgfVxuICAgICAgLy8gV2UgbmVlZCB0byBjaGVjayBhbGwga2V5cyBpbiBjYXNlIHNvbWUgYXJlIHJlcXVpcmVkIGJ1dCBtaXNzaW5nIGZyb20gcHJvcHMuXG4gICAgICB2YXIgYWxsS2V5cyA9IGFzc2lnbih7fSwgcHJvcHNbcHJvcE5hbWVdLCBzaGFwZVR5cGVzKTtcbiAgICAgIGZvciAodmFyIGtleSBpbiBhbGxLZXlzKSB7XG4gICAgICAgIHZhciBjaGVja2VyID0gc2hhcGVUeXBlc1trZXldO1xuICAgICAgICBpZiAoaGFzKHNoYXBlVHlwZXMsIGtleSkgJiYgdHlwZW9mIGNoZWNrZXIgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICByZXR1cm4gaW52YWxpZFZhbGlkYXRvckVycm9yKGNvbXBvbmVudE5hbWUsIGxvY2F0aW9uLCBwcm9wRnVsbE5hbWUsIGtleSwgZ2V0UHJlY2lzZVR5cGUoY2hlY2tlcikpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghY2hlY2tlcikge1xuICAgICAgICAgIHJldHVybiBuZXcgUHJvcFR5cGVFcnJvcihcbiAgICAgICAgICAgICdJbnZhbGlkICcgKyBsb2NhdGlvbiArICcgYCcgKyBwcm9wRnVsbE5hbWUgKyAnYCBrZXkgYCcgKyBrZXkgKyAnYCBzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYC4nICtcbiAgICAgICAgICAgICdcXG5CYWQgb2JqZWN0OiAnICsgSlNPTi5zdHJpbmdpZnkocHJvcHNbcHJvcE5hbWVdLCBudWxsLCAnICAnKSArXG4gICAgICAgICAgICAnXFxuVmFsaWQga2V5czogJyArIEpTT04uc3RyaW5naWZ5KE9iamVjdC5rZXlzKHNoYXBlVHlwZXMpLCBudWxsLCAnICAnKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGVycm9yID0gY2hlY2tlcihwcm9wVmFsdWUsIGtleSwgY29tcG9uZW50TmFtZSwgbG9jYXRpb24sIHByb3BGdWxsTmFtZSArICcuJyArIGtleSwgUmVhY3RQcm9wVHlwZXNTZWNyZXQpO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiBjcmVhdGVDaGFpbmFibGVUeXBlQ2hlY2tlcih2YWxpZGF0ZSk7XG4gIH1cblxuICBmdW5jdGlvbiBpc05vZGUocHJvcFZhbHVlKSB7XG4gICAgc3dpdGNoICh0eXBlb2YgcHJvcFZhbHVlKSB7XG4gICAgICBjYXNlICdudW1iZXInOlxuICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgIGNhc2UgJ3VuZGVmaW5lZCc6XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICAgIHJldHVybiAhcHJvcFZhbHVlO1xuICAgICAgY2FzZSAnb2JqZWN0JzpcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocHJvcFZhbHVlKSkge1xuICAgICAgICAgIHJldHVybiBwcm9wVmFsdWUuZXZlcnkoaXNOb2RlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJvcFZhbHVlID09PSBudWxsIHx8IGlzVmFsaWRFbGVtZW50KHByb3BWYWx1ZSkpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBpdGVyYXRvckZuID0gZ2V0SXRlcmF0b3JGbihwcm9wVmFsdWUpO1xuICAgICAgICBpZiAoaXRlcmF0b3JGbikge1xuICAgICAgICAgIHZhciBpdGVyYXRvciA9IGl0ZXJhdG9yRm4uY2FsbChwcm9wVmFsdWUpO1xuICAgICAgICAgIHZhciBzdGVwO1xuICAgICAgICAgIGlmIChpdGVyYXRvckZuICE9PSBwcm9wVmFsdWUuZW50cmllcykge1xuICAgICAgICAgICAgd2hpbGUgKCEoc3RlcCA9IGl0ZXJhdG9yLm5leHQoKSkuZG9uZSkge1xuICAgICAgICAgICAgICBpZiAoIWlzTm9kZShzdGVwLnZhbHVlKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBJdGVyYXRvciB3aWxsIHByb3ZpZGUgZW50cnkgW2ssdl0gdHVwbGVzIHJhdGhlciB0aGFuIHZhbHVlcy5cbiAgICAgICAgICAgIHdoaWxlICghKHN0ZXAgPSBpdGVyYXRvci5uZXh0KCkpLmRvbmUpIHtcbiAgICAgICAgICAgICAgdmFyIGVudHJ5ID0gc3RlcC52YWx1ZTtcbiAgICAgICAgICAgICAgaWYgKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc05vZGUoZW50cnlbMV0pKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGlzU3ltYm9sKHByb3BUeXBlLCBwcm9wVmFsdWUpIHtcbiAgICAvLyBOYXRpdmUgU3ltYm9sLlxuICAgIGlmIChwcm9wVHlwZSA9PT0gJ3N5bWJvbCcpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8vIGZhbHN5IHZhbHVlIGNhbid0IGJlIGEgU3ltYm9sXG4gICAgaWYgKCFwcm9wVmFsdWUpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyAxOS40LjMuNSBTeW1ib2wucHJvdG90eXBlW0BAdG9TdHJpbmdUYWddID09PSAnU3ltYm9sJ1xuICAgIGlmIChwcm9wVmFsdWVbJ0BAdG9TdHJpbmdUYWcnXSA9PT0gJ1N5bWJvbCcpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8vIEZhbGxiYWNrIGZvciBub24tc3BlYyBjb21wbGlhbnQgU3ltYm9scyB3aGljaCBhcmUgcG9seWZpbGxlZC5cbiAgICBpZiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiBwcm9wVmFsdWUgaW5zdGFuY2VvZiBTeW1ib2wpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8vIEVxdWl2YWxlbnQgb2YgYHR5cGVvZmAgYnV0IHdpdGggc3BlY2lhbCBoYW5kbGluZyBmb3IgYXJyYXkgYW5kIHJlZ2V4cC5cbiAgZnVuY3Rpb24gZ2V0UHJvcFR5cGUocHJvcFZhbHVlKSB7XG4gICAgdmFyIHByb3BUeXBlID0gdHlwZW9mIHByb3BWYWx1ZTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShwcm9wVmFsdWUpKSB7XG4gICAgICByZXR1cm4gJ2FycmF5JztcbiAgICB9XG4gICAgaWYgKHByb3BWYWx1ZSBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuICAgICAgLy8gT2xkIHdlYmtpdHMgKGF0IGxlYXN0IHVudGlsIEFuZHJvaWQgNC4wKSByZXR1cm4gJ2Z1bmN0aW9uJyByYXRoZXIgdGhhblxuICAgICAgLy8gJ29iamVjdCcgZm9yIHR5cGVvZiBhIFJlZ0V4cC4gV2UnbGwgbm9ybWFsaXplIHRoaXMgaGVyZSBzbyB0aGF0IC9ibGEvXG4gICAgICAvLyBwYXNzZXMgUHJvcFR5cGVzLm9iamVjdC5cbiAgICAgIHJldHVybiAnb2JqZWN0JztcbiAgICB9XG4gICAgaWYgKGlzU3ltYm9sKHByb3BUeXBlLCBwcm9wVmFsdWUpKSB7XG4gICAgICByZXR1cm4gJ3N5bWJvbCc7XG4gICAgfVxuICAgIHJldHVybiBwcm9wVHlwZTtcbiAgfVxuXG4gIC8vIFRoaXMgaGFuZGxlcyBtb3JlIHR5cGVzIHRoYW4gYGdldFByb3BUeXBlYC4gT25seSB1c2VkIGZvciBlcnJvciBtZXNzYWdlcy5cbiAgLy8gU2VlIGBjcmVhdGVQcmltaXRpdmVUeXBlQ2hlY2tlcmAuXG4gIGZ1bmN0aW9uIGdldFByZWNpc2VUeXBlKHByb3BWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgcHJvcFZhbHVlID09PSAndW5kZWZpbmVkJyB8fCBwcm9wVmFsdWUgPT09IG51bGwpIHtcbiAgICAgIHJldHVybiAnJyArIHByb3BWYWx1ZTtcbiAgICB9XG4gICAgdmFyIHByb3BUeXBlID0gZ2V0UHJvcFR5cGUocHJvcFZhbHVlKTtcbiAgICBpZiAocHJvcFR5cGUgPT09ICdvYmplY3QnKSB7XG4gICAgICBpZiAocHJvcFZhbHVlIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgICAgICByZXR1cm4gJ2RhdGUnO1xuICAgICAgfSBlbHNlIGlmIChwcm9wVmFsdWUgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAgICAgcmV0dXJuICdyZWdleHAnO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcHJvcFR5cGU7XG4gIH1cblxuICAvLyBSZXR1cm5zIGEgc3RyaW5nIHRoYXQgaXMgcG9zdGZpeGVkIHRvIGEgd2FybmluZyBhYm91dCBhbiBpbnZhbGlkIHR5cGUuXG4gIC8vIEZvciBleGFtcGxlLCBcInVuZGVmaW5lZFwiIG9yIFwib2YgdHlwZSBhcnJheVwiXG4gIGZ1bmN0aW9uIGdldFBvc3RmaXhGb3JUeXBlV2FybmluZyh2YWx1ZSkge1xuICAgIHZhciB0eXBlID0gZ2V0UHJlY2lzZVR5cGUodmFsdWUpO1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSAnYXJyYXknOlxuICAgICAgY2FzZSAnb2JqZWN0JzpcbiAgICAgICAgcmV0dXJuICdhbiAnICsgdHlwZTtcbiAgICAgIGNhc2UgJ2Jvb2xlYW4nOlxuICAgICAgY2FzZSAnZGF0ZSc6XG4gICAgICBjYXNlICdyZWdleHAnOlxuICAgICAgICByZXR1cm4gJ2EgJyArIHR5cGU7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gdHlwZTtcbiAgICB9XG4gIH1cblxuICAvLyBSZXR1cm5zIGNsYXNzIG5hbWUgb2YgdGhlIG9iamVjdCwgaWYgYW55LlxuICBmdW5jdGlvbiBnZXRDbGFzc05hbWUocHJvcFZhbHVlKSB7XG4gICAgaWYgKCFwcm9wVmFsdWUuY29uc3RydWN0b3IgfHwgIXByb3BWYWx1ZS5jb25zdHJ1Y3Rvci5uYW1lKSB7XG4gICAgICByZXR1cm4gQU5PTllNT1VTO1xuICAgIH1cbiAgICByZXR1cm4gcHJvcFZhbHVlLmNvbnN0cnVjdG9yLm5hbWU7XG4gIH1cblxuICBSZWFjdFByb3BUeXBlcy5jaGVja1Byb3BUeXBlcyA9IGNoZWNrUHJvcFR5cGVzO1xuICBSZWFjdFByb3BUeXBlcy5yZXNldFdhcm5pbmdDYWNoZSA9IGNoZWNrUHJvcFR5cGVzLnJlc2V0V2FybmluZ0NhY2hlO1xuICBSZWFjdFByb3BUeXBlcy5Qcm9wVHlwZXMgPSBSZWFjdFByb3BUeXBlcztcblxuICByZXR1cm4gUmVhY3RQcm9wVHlwZXM7XG59O1xuIiwiLyoqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTMtcHJlc2VudCwgRmFjZWJvb2ssIEluYy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICB2YXIgUmVhY3RJcyA9IHJlcXVpcmUoJ3JlYWN0LWlzJyk7XG5cbiAgLy8gQnkgZXhwbGljaXRseSB1c2luZyBgcHJvcC10eXBlc2AgeW91IGFyZSBvcHRpbmcgaW50byBuZXcgZGV2ZWxvcG1lbnQgYmVoYXZpb3IuXG4gIC8vIGh0dHA6Ly9mYi5tZS9wcm9wLXR5cGVzLWluLXByb2RcbiAgdmFyIHRocm93T25EaXJlY3RBY2Nlc3MgPSB0cnVlO1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZmFjdG9yeVdpdGhUeXBlQ2hlY2tlcnMnKShSZWFjdElzLmlzRWxlbWVudCwgdGhyb3dPbkRpcmVjdEFjY2Vzcyk7XG59IGVsc2Uge1xuICAvLyBCeSBleHBsaWNpdGx5IHVzaW5nIGBwcm9wLXR5cGVzYCB5b3UgYXJlIG9wdGluZyBpbnRvIG5ldyBwcm9kdWN0aW9uIGJlaGF2aW9yLlxuICAvLyBodHRwOi8vZmIubWUvcHJvcC10eXBlcy1pbi1wcm9kXG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9mYWN0b3J5V2l0aFRocm93aW5nU2hpbXMnKSgpO1xufVxuIiwiLyogZXNsaW50IG5vLXJlc3RyaWN0ZWQtc3ludGF4OiAwLCBwcmVmZXItdGVtcGxhdGU6IDAsIGd1YXJkLWZvci1pbjogMFxuICAgLS0tXG4gICBUaGVzZSBydWxlcyBhcmUgcHJldmVudGluZyB0aGUgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBiZWxvdy5cbiAqL1xuXG4vKipcbiAqIENvbXBvc2UgY2xhc3NlcyBmcm9tIG11bHRpcGxlIHNvdXJjZXMuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3Qgc2xvdHMgPSB7XG4gKiAgcm9vdDogWydyb290JywgJ3ByaW1hcnknXSxcbiAqICBsYWJlbDogWydsYWJlbCddLFxuICogfTtcbiAqXG4gKiBjb25zdCBnZXRVdGlsaXR5Q2xhc3MgPSAoc2xvdCkgPT4gYE11aUJ1dHRvbi0ke3Nsb3R9YDtcbiAqXG4gKiBjb25zdCBjbGFzc2VzID0ge1xuICogICByb290OiAnbXktcm9vdC1jbGFzcycsXG4gKiB9O1xuICpcbiAqIGNvbnN0IG91dHB1dCA9IGNvbXBvc2VDbGFzc2VzKHNsb3RzLCBnZXRVdGlsaXR5Q2xhc3MsIGNsYXNzZXMpO1xuICogLy8ge1xuICogLy8gICByb290OiAnTXVpQnV0dG9uLXJvb3QgTXVpQnV0dG9uLXByaW1hcnkgbXktcm9vdC1jbGFzcycsXG4gKiAvLyAgIGxhYmVsOiAnTXVpQnV0dG9uLWxhYmVsJyxcbiAqIC8vIH1cbiAqIGBgYFxuICpcbiAqIEBwYXJhbSBzbG90cyBhIGxpc3Qgb2YgY2xhc3NlcyBmb3IgZWFjaCBwb3NzaWJsZSBzbG90XG4gKiBAcGFyYW0gZ2V0VXRpbGl0eUNsYXNzIGEgZnVuY3Rpb24gdG8gcmVzb2x2ZSB0aGUgY2xhc3MgYmFzZWQgb24gdGhlIHNsb3QgbmFtZVxuICogQHBhcmFtIGNsYXNzZXMgdGhlIGlucHV0IGNsYXNzZXMgZnJvbSBwcm9wc1xuICogQHJldHVybnMgdGhlIHJlc29sdmVkIGNsYXNzZXMgZm9yIGFsbCBzbG90c1xuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjb21wb3NlQ2xhc3NlcyhzbG90cywgZ2V0VXRpbGl0eUNsYXNzLCBjbGFzc2VzID0gdW5kZWZpbmVkKSB7XG4gIGNvbnN0IG91dHB1dCA9IHt9O1xuICBmb3IgKGNvbnN0IHNsb3ROYW1lIGluIHNsb3RzKSB7XG4gICAgY29uc3Qgc2xvdCA9IHNsb3RzW3Nsb3ROYW1lXTtcbiAgICBsZXQgYnVmZmVyID0gJyc7XG4gICAgbGV0IHN0YXJ0ID0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNsb3QubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gc2xvdFtpXTtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICBidWZmZXIgKz0gKHN0YXJ0ID09PSB0cnVlID8gJycgOiAnICcpICsgZ2V0VXRpbGl0eUNsYXNzKHZhbHVlKTtcbiAgICAgICAgc3RhcnQgPSBmYWxzZTtcbiAgICAgICAgaWYgKGNsYXNzZXMgJiYgY2xhc3Nlc1t2YWx1ZV0pIHtcbiAgICAgICAgICBidWZmZXIgKz0gJyAnICsgY2xhc3Nlc1t2YWx1ZV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgb3V0cHV0W3Nsb3ROYW1lXSA9IGJ1ZmZlcjtcbiAgfVxuICByZXR1cm4gb3V0cHV0O1xufSIsImltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAbXVpL3V0aWxzL2Zvcm1hdE11aUVycm9yTWVzc2FnZVwiO1xuLy8gSXQgc2hvdWxkIHRvIGJlIG5vdGVkIHRoYXQgdGhpcyBmdW5jdGlvbiBpc24ndCBlcXVpdmFsZW50IHRvIGB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZWAuXG4vL1xuLy8gQSBzdHJpY3QgY2FwaXRhbGl6YXRpb24gc2hvdWxkIHVwcGVyY2FzZSB0aGUgZmlyc3QgbGV0dGVyIG9mIGVhY2ggd29yZCBpbiB0aGUgc2VudGVuY2UuXG4vLyBXZSBvbmx5IGhhbmRsZSB0aGUgZmlyc3Qgd29yZC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNhcGl0YWxpemUoc3RyaW5nKSB7XG4gIGlmICh0eXBlb2Ygc3RyaW5nICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnTVVJOiBgY2FwaXRhbGl6ZShzdHJpbmcpYCBleHBlY3RzIGEgc3RyaW5nIGFyZ3VtZW50LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDcpKTtcbiAgfVxuICByZXR1cm4gc3RyaW5nLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyaW5nLnNsaWNlKDEpO1xufSIsImltcG9ydCBjYXBpdGFsaXplIGZyb20gJ0BtdWkvdXRpbHMvY2FwaXRhbGl6ZSc7XG5leHBvcnQgZGVmYXVsdCBjYXBpdGFsaXplOyIsIi8vIEJhc2VkIG9uIGh0dHBzOi8vZ2l0aHViLmNvbS9UZWhTaHJpa2UvZGVlcG1lcmdlXG4vLyBCYXNlZCBvbiBodHRwczovL2dpdGh1Yi5jb20vZmFzdGlmeS9kZWVwbWVyZ2Vcbi8vIE1JVCBMaWNlbnNlXG4vLyBDb3B5cmlnaHQgKGMpIDIwMTIgLSAyMDIyIEphbWVzIEhhbGxpZGF5LCBKb3NoIER1ZmYsIGFuZCBvdGhlciBjb250cmlidXRvcnMgb2YgZGVlcG1lcmdlXG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLWVsc2UtcmV0dXJuICovXG5cbi8qKlxuICogQXNzaWducyBwcm9wcyBmcm9tIG9uZSBvYmplY3QgdG8gYW5vdGhlci4gRm9jdXNlZCBvbiBwZXJmb3JtYW5jZSwgb25seSBub3JtYWwgb2JqZWN0cyB3aXRoIG5vXG4gKiBwcm90b3R5cGUgYXJlIHN1cHBvcnRlZC5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZmFzdERlZXBBc3NpZ24odGFyZ2V0LCBzb3VyY2UpIHtcbiAgY29uc3Qgc291cmNlSXNBcnJheSA9IEFycmF5LmlzQXJyYXkoc291cmNlKTtcbiAgY29uc3QgdGFyZ2V0SXNBcnJheSA9IEFycmF5LmlzQXJyYXkodGFyZ2V0KTtcbiAgaWYgKGlzUHJpbWl0aXZlKHNvdXJjZSkpIHtcbiAgICByZXR1cm4gc291cmNlO1xuICB9IGVsc2UgaWYgKGlzUHJpbWl0aXZlT3JCdWlsdEluKHRhcmdldCkpIHtcbiAgICByZXR1cm4gY2xvbmUoc291cmNlKTtcbiAgfSBlbHNlIGlmIChzb3VyY2VJc0FycmF5ICYmIHRhcmdldElzQXJyYXkpIHtcbiAgICByZXR1cm4gbWVyZ2VBcnJheSh0YXJnZXQsIHNvdXJjZSk7XG4gIH0gZWxzZSBpZiAoc291cmNlSXNBcnJheSAhPT0gdGFyZ2V0SXNBcnJheSkge1xuICAgIHJldHVybiBjbG9uZShzb3VyY2UpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBtZXJnZU9iamVjdCh0YXJnZXQsIHNvdXJjZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNsb25lQXJyYXkodmFsdWUpIHtcbiAgbGV0IGkgPSAwO1xuICBjb25zdCBpbCA9IHZhbHVlLmxlbmd0aDtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IEFycmF5KGlsKTtcbiAgZm9yIChpID0gMDsgaSA8IGlsOyBpICs9IDEpIHtcbiAgICByZXN1bHRbaV0gPSBjbG9uZSh2YWx1ZVtpXSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGNsb25lT2JqZWN0KHRhcmdldCkge1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgZm9yIChjb25zdCBrZXkgaW4gdGFyZ2V0KSB7XG4gICAgaWYgKGtleSA9PT0gJ19fcHJvdG9fXycgfHwga2V5ID09PSAnY29uc3RydWN0b3InIHx8IGtleSA9PT0gJ3Byb3RvdHlwZScpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICByZXN1bHRba2V5XSA9IGNsb25lKHRhcmdldFtrZXldKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gbWVyZ2VBcnJheSh0YXJnZXQsIHNvdXJjZSkge1xuICBjb25zdCB0bCA9IHRhcmdldC5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgdGFyZ2V0W3RsICsgaV0gPSBjbG9uZShzb3VyY2VbaV0pO1xuICB9XG4gIHJldHVybiB0YXJnZXQ7XG59XG5mdW5jdGlvbiBpc01lcmdlYWJsZU9iamVjdCh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbCAmJiAhKHZhbHVlIGluc3RhbmNlb2YgUmVnRXhwKSAmJiAhKHZhbHVlIGluc3RhbmNlb2YgRGF0ZSk7XG59XG5mdW5jdGlvbiBpc1ByaW1pdGl2ZSh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JyB8fCB2YWx1ZSA9PT0gbnVsbDtcbn1cbmZ1bmN0aW9uIGlzUHJpbWl0aXZlT3JCdWlsdEluKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnIHx8IHZhbHVlID09PSBudWxsIHx8IHZhbHVlIGluc3RhbmNlb2YgUmVnRXhwIHx8IHZhbHVlIGluc3RhbmNlb2YgRGF0ZTtcbn1cbmZ1bmN0aW9uIGNsb25lKGVudHJ5KSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICByZXR1cm4gaXNNZXJnZWFibGVPYmplY3QoZW50cnkpID8gQXJyYXkuaXNBcnJheShlbnRyeSkgPyBjbG9uZUFycmF5KGVudHJ5KSA6IGNsb25lT2JqZWN0KGVudHJ5KSA6IGVudHJ5O1xufVxuZnVuY3Rpb24gbWVyZ2VPYmplY3QodGFyZ2V0LCBzb3VyY2UpIHtcbiAgZm9yIChjb25zdCBrZXkgaW4gc291cmNlKSB7XG4gICAgaWYgKGtleSA9PT0gJ19fcHJvdG9fXycgfHwga2V5ID09PSAnY29uc3RydWN0b3InIHx8IGtleSA9PT0gJ3Byb3RvdHlwZScpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoa2V5IGluIHRhcmdldCkge1xuICAgICAgdGFyZ2V0W2tleV0gPSBmYXN0RGVlcEFzc2lnbih0YXJnZXRba2V5XSwgc291cmNlW2tleV0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0YXJnZXRba2V5XSA9IGNsb25lKHNvdXJjZVtrZXldKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRhcmdldDtcbn0iLCJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuY29uc3QgcmVzcG9uc2l2ZVByb3BUeXBlID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5udW1iZXIsIFByb3BUeXBlcy5zdHJpbmcsIFByb3BUeXBlcy5vYmplY3QsIFByb3BUeXBlcy5hcnJheV0pIDoge307XG5leHBvcnQgZGVmYXVsdCByZXNwb25zaXZlUHJvcFR5cGU7IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNPYmplY3RFbXB0eShvYmplY3QpIHtcbiAgaWYgKG9iamVjdCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gIGZvciAoY29uc3QgXyBpbiBvYmplY3QpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaXNWYWxpZEVsZW1lbnRUeXBlIH0gZnJvbSAncmVhY3QtaXMnO1xuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vc2luZHJlc29yaHVzL2lzLXBsYWluLW9iai9ibG9iL21haW4vaW5kZXguanNcbmV4cG9ydCBmdW5jdGlvbiBpc1BsYWluT2JqZWN0KGl0ZW0pIHtcbiAgaWYgKHR5cGVvZiBpdGVtICE9PSAnb2JqZWN0JyB8fCBpdGVtID09PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihpdGVtKTtcbiAgcmV0dXJuIChwcm90b3R5cGUgPT09IG51bGwgfHwgcHJvdG90eXBlID09PSBPYmplY3QucHJvdG90eXBlIHx8IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90b3R5cGUpID09PSBudWxsKSAmJiAhKFN5bWJvbC50b1N0cmluZ1RhZyBpbiBpdGVtKSAmJiAhKFN5bWJvbC5pdGVyYXRvciBpbiBpdGVtKTtcbn1cbmZ1bmN0aW9uIGRlZXBDbG9uZShzb3VyY2UpIHtcbiAgaWYgKC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChzb3VyY2UpIHx8IGlzVmFsaWRFbGVtZW50VHlwZShzb3VyY2UpIHx8ICFpc1BsYWluT2JqZWN0KHNvdXJjZSkpIHtcbiAgICByZXR1cm4gc291cmNlO1xuICB9XG4gIGNvbnN0IG91dHB1dCA9IHt9O1xuICBPYmplY3Qua2V5cyhzb3VyY2UpLmZvckVhY2goa2V5ID0+IHtcbiAgICBvdXRwdXRba2V5XSA9IGRlZXBDbG9uZShzb3VyY2Vba2V5XSk7XG4gIH0pO1xuICByZXR1cm4gb3V0cHV0O1xufVxuXG4vKipcbiAqIE1lcmdlIG9iamVjdHMgZGVlcGx5LlxuICogSXQgd2lsbCBzaGFsbG93IGNvcHkgUmVhY3QgZWxlbWVudHMuXG4gKlxuICogSWYgYG9wdGlvbnMuY2xvbmVgIGlzIHNldCB0byBgZmFsc2VgIHRoZSBzb3VyY2Ugb2JqZWN0IHdpbGwgYmUgbWVyZ2VkIGRpcmVjdGx5IGludG8gdGhlIHRhcmdldCBvYmplY3QuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiBkZWVwbWVyZ2UoeyBhOiB7IGI6IDEgfSwgZDogMiB9LCB7IGE6IHsgYzogMiB9LCBkOiA0IH0pO1xuICogLy8gPT4geyBhOiB7IGI6IDEsIGM6IDIgfSwgZDogNCB9XG4gKiBgYGBgXG4gKlxuICogQHBhcmFtIHRhcmdldCBUaGUgdGFyZ2V0IG9iamVjdC5cbiAqIEBwYXJhbSBzb3VyY2UgVGhlIHNvdXJjZSBvYmplY3QuXG4gKiBAcGFyYW0gb3B0aW9ucyBUaGUgbWVyZ2Ugb3B0aW9ucy5cbiAqIEBwYXJhbSBvcHRpb25zLmNsb25lIFNldCB0byBgZmFsc2VgIHRvIG1lcmdlIHRoZSBzb3VyY2Ugb2JqZWN0IGRpcmVjdGx5IGludG8gdGhlIHRhcmdldCBvYmplY3QuXG4gKiBAcmV0dXJucyBUaGUgbWVyZ2VkIG9iamVjdC5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZGVlcG1lcmdlKHRhcmdldCwgc291cmNlLCBvcHRpb25zID0ge1xuICBjbG9uZTogdHJ1ZVxufSkge1xuICBjb25zdCBvdXRwdXQgPSBvcHRpb25zLmNsb25lID8ge1xuICAgIC4uLnRhcmdldFxuICB9IDogdGFyZ2V0O1xuICBpZiAoaXNQbGFpbk9iamVjdCh0YXJnZXQpICYmIGlzUGxhaW5PYmplY3Qoc291cmNlKSkge1xuICAgIE9iamVjdC5rZXlzKHNvdXJjZSkuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgaWYgKC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChzb3VyY2Vba2V5XSkgfHwgaXNWYWxpZEVsZW1lbnRUeXBlKHNvdXJjZVtrZXldKSkge1xuICAgICAgICBvdXRwdXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICAgICAgfSBlbHNlIGlmIChpc1BsYWluT2JqZWN0KHNvdXJjZVtrZXldKSAmJlxuICAgICAgLy8gQXZvaWQgcHJvdG90eXBlIHBvbGx1dGlvblxuICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHRhcmdldCwga2V5KSAmJiBpc1BsYWluT2JqZWN0KHRhcmdldFtrZXldKSkge1xuICAgICAgICAvLyBTaW5jZSBgb3V0cHV0YCBpcyBhIGNsb25lIG9mIGB0YXJnZXRgIGFuZCB3ZSBoYXZlIG5hcnJvd2VkIGB0YXJnZXRgIGluIHRoaXMgYmxvY2sgd2UgY2FuIGNhc3QgdG8gdGhlIHNhbWUgdHlwZS5cbiAgICAgICAgb3V0cHV0W2tleV0gPSBkZWVwbWVyZ2UodGFyZ2V0W2tleV0sIHNvdXJjZVtrZXldLCBvcHRpb25zKTtcbiAgICAgIH0gZWxzZSBpZiAob3B0aW9ucy5jbG9uZSkge1xuICAgICAgICBvdXRwdXRba2V5XSA9IGlzUGxhaW5PYmplY3Qoc291cmNlW2tleV0pID8gZGVlcENsb25lKHNvdXJjZVtrZXldKSA6IHNvdXJjZVtrZXldO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0cHV0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4gb3V0cHV0O1xufSIsImNvbnN0IE1JTl9XSURUSF9QQVRURVJOID0gL21pbi13aWR0aDpcXHMqKFswLTkuXSspLztcblxuLyoqXG4gKiBXQVJOOiBNdXRhYmx5IHVwZGF0ZXMgdGhlIGBjc3NgIG9iamVjdC5cbiAqIEZvciB1c2luZyBpbiBgc3hgIHByb3AgdG8gc29ydCB0aGUgYnJlYWtwb2ludCBmcm9tIGxvdyB0byBoaWdoLlxuICogTm90ZTogdGhpcyBmdW5jdGlvbiBkb2VzIG5vdCB3b3JrIGFuZCB3aWxsIG5vdCBzdXBwb3J0IG11bHRpcGxlIHVuaXRzLlxuICogICAgICAgZS5nLiBpbnB1dDogeyAnQGNvbnRhaW5lciAobWluLXdpZHRoOjMwMHB4KSc6ICcxcmVtJywgJ0Bjb250YWluZXIgKG1pbi13aWR0aDo0MHJlbSknOiAnMnJlbScgfVxuICogICAgICAgICAgICBvdXRwdXQ6IHsgJ0Bjb250YWluZXIgKG1pbi13aWR0aDo0MHJlbSknOiAnMnJlbScsICdAY29udGFpbmVyIChtaW4td2lkdGg6MzAwcHgpJzogJzFyZW0nIH0gLy8gc2luY2UgNDAgPCAzMDAgZXZlbiB0aG91Z2ggNDByZW0gPiAzMDBweFxuICovXG5leHBvcnQgZnVuY3Rpb24gc29ydENvbnRhaW5lclF1ZXJpZXModGhlbWUsIGNzcykge1xuICBpZiAoIXRoZW1lLmNvbnRhaW5lclF1ZXJpZXMgfHwgIWhhc0NvbnRhaW5lclF1ZXJ5KGNzcykpIHtcbiAgICByZXR1cm4gY3NzO1xuICB9XG4gIGNvbnN0IGtleXMgPSBbXTtcbiAgZm9yIChjb25zdCBrZXkgaW4gY3NzKSB7XG4gICAgaWYgKGtleS5zdGFydHNXaXRoKCdAY29udGFpbmVyJykpIHtcbiAgICAgIGtleXMucHVzaChrZXkpO1xuICAgIH1cbiAgfVxuICBrZXlzLnNvcnQoKGEsIGIpID0+IHtcbiAgICByZXR1cm4gKyhhLm1hdGNoKE1JTl9XSURUSF9QQVRURVJOKT8uWzFdIHx8IDApIC0gKyhiLm1hdGNoKE1JTl9XSURUSF9QQVRURVJOKT8uWzFdIHx8IDApO1xuICB9KTtcbiAgY29uc3QgcmVzdWx0ID0gY3NzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICBjb25zdCBrZXkgPSBrZXlzW2ldO1xuICAgIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gICAgZGVsZXRlIHJlc3VsdFtrZXldO1xuICAgIHJlc3VsdFtrZXldID0gdmFsdWU7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGhhc0NvbnRhaW5lclF1ZXJ5KGNzcykge1xuICBmb3IgKGNvbnN0IGtleSBpbiBjc3MpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJ0Bjb250YWluZXInKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0NxU2hvcnRoYW5kKGJyZWFrcG9pbnRLZXlzLCB2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPT09ICdAJyB8fCB2YWx1ZS5zdGFydHNXaXRoKCdAJykgJiYgKGJyZWFrcG9pbnRLZXlzLnNvbWUoa2V5ID0+IHZhbHVlLnN0YXJ0c1dpdGgoYEAke2tleX1gKSkgfHwgISF2YWx1ZS5tYXRjaCgvXkBcXGQvKSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29udGFpbmVyUXVlcnkodGhlbWUsIHNob3J0aGFuZCkge1xuICBjb25zdCBtYXRjaGVzID0gc2hvcnRoYW5kLm1hdGNoKC9eQChbXi9dKyk/XFwvPyguKyk/JC8pO1xuICBpZiAoIW1hdGNoZXMpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgLy8gVE9ETzogYXZvaWQgdGhyb3dpbmcgZHVyaW5nIFJlYWN0IHJlbmRlciBvbmx5IGluIGRldmVsb3BtZW50LlxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG11aS9uby1ndWFyZGVkLXRocm93XG4gICAgICB0aHJvdyAvKiBtaW5pZnktZXJyb3IgKi9uZXcgRXJyb3IoYE1VSTogVGhlIHByb3ZpZGVkIHNob3J0aGFuZCAke2AoJHtzaG9ydGhhbmR9KWB9IGlzIGludmFsaWQuIFRoZSBmb3JtYXQgc2hvdWxkIGJlIFxcYEA8YnJlYWtwb2ludCB8IG51bWJlcj5cXGAgb3IgXFxgQDxicmVha3BvaW50IHwgbnVtYmVyPi88Y29udGFpbmVyPlxcYC5cXG5gICsgJ0ZvciBleGFtcGxlLCBgQHNtYCBvciBgQDYwMGAgb3IgYEA0MHJlbS9zaWRlYmFyYC4nKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgWywgY29udGFpbmVyUXVlcnksIGNvbnRhaW5lck5hbWVdID0gbWF0Y2hlcztcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIuaXNOYU4oK2NvbnRhaW5lclF1ZXJ5KSA/IGNvbnRhaW5lclF1ZXJ5IHx8IDAgOiArY29udGFpbmVyUXVlcnk7XG4gIHJldHVybiB0aGVtZS5jb250YWluZXJRdWVyaWVzKGNvbnRhaW5lck5hbWUpLnVwKHZhbHVlKTtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNzc0NvbnRhaW5lclF1ZXJpZXModGhlbWVJbnB1dCkge1xuICBjb25zdCB0b0NvbnRhaW5lclF1ZXJ5ID0gKG1lZGlhUXVlcnksIG5hbWUpID0+IG1lZGlhUXVlcnkucmVwbGFjZSgnQG1lZGlhJywgbmFtZSA/IGBAY29udGFpbmVyICR7bmFtZX1gIDogJ0Bjb250YWluZXInKTtcbiAgZnVuY3Rpb24gYXR0YWNoQ3Eobm9kZSwgbmFtZSkge1xuICAgIG5vZGUudXAgPSAoLi4uYXJncykgPT4gdG9Db250YWluZXJRdWVyeSh0aGVtZUlucHV0LmJyZWFrcG9pbnRzLnVwKC4uLmFyZ3MpLCBuYW1lKTtcbiAgICBub2RlLmRvd24gPSAoLi4uYXJncykgPT4gdG9Db250YWluZXJRdWVyeSh0aGVtZUlucHV0LmJyZWFrcG9pbnRzLmRvd24oLi4uYXJncyksIG5hbWUpO1xuICAgIG5vZGUuYmV0d2VlbiA9ICguLi5hcmdzKSA9PiB0b0NvbnRhaW5lclF1ZXJ5KHRoZW1lSW5wdXQuYnJlYWtwb2ludHMuYmV0d2VlbiguLi5hcmdzKSwgbmFtZSk7XG4gICAgbm9kZS5vbmx5ID0gKC4uLmFyZ3MpID0+IHRvQ29udGFpbmVyUXVlcnkodGhlbWVJbnB1dC5icmVha3BvaW50cy5vbmx5KC4uLmFyZ3MpLCBuYW1lKTtcbiAgICBub2RlLm5vdCA9ICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSB0b0NvbnRhaW5lclF1ZXJ5KHRoZW1lSW5wdXQuYnJlYWtwb2ludHMubm90KC4uLmFyZ3MpLCBuYW1lKTtcbiAgICAgIGlmIChyZXN1bHQuaW5jbHVkZXMoJ25vdCBhbGwgYW5kJykpIHtcbiAgICAgICAgLy8gYEBjb250YWluZXJgIGRvZXMgbm90IHdvcmsgd2l0aCBgbm90IGFsbCBhbmRgLCBzbyBuZWVkIHRvIGludmVydCB0aGUgbG9naWNcbiAgICAgICAgcmV0dXJuIHJlc3VsdC5yZXBsYWNlKCdub3QgYWxsIGFuZCAnLCAnJykucmVwbGFjZSgnbWluLXdpZHRoOicsICd3aWR0aDwnKS5yZXBsYWNlKCdtYXgtd2lkdGg6JywgJ3dpZHRoPicpLnJlcGxhY2UoJ2FuZCcsICdvcicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuICB9XG4gIGNvbnN0IG5vZGUgPSB7fTtcbiAgY29uc3QgY29udGFpbmVyUXVlcmllcyA9IG5hbWUgPT4ge1xuICAgIGF0dGFjaENxKG5vZGUsIG5hbWUpO1xuICAgIHJldHVybiBub2RlO1xuICB9O1xuICBhdHRhY2hDcShjb250YWluZXJRdWVyaWVzKTtcbiAgcmV0dXJuIHtcbiAgICAuLi50aGVtZUlucHV0LFxuICAgIGNvbnRhaW5lclF1ZXJpZXNcbiAgfTtcbn0iLCIvLyBTb3J0ZWQgQVNDIGJ5IHNpemUuIFRoYXQncyBpbXBvcnRhbnQuXG4vLyBJdCBjYW4ndCBiZSBjb25maWd1cmVkIGFzIGl0J3MgdXNlZCBzdGF0aWNhbGx5IGZvciBwcm9wVHlwZXMuXG5leHBvcnQgY29uc3QgYnJlYWtwb2ludEtleXMgPSBbJ3hzJywgJ3NtJywgJ21kJywgJ2xnJywgJ3hsJ107XG5cbi8vIEtlZXAgaW4gc3luYyB3aXRoIGRvY3Mvc3JjL3BhZ2VzL2N1c3RvbWl6YXRpb24vYnJlYWtwb2ludHMvYnJlYWtwb2ludHMubWRcbi8vICNob3N0LXJlZmVyZW5jZVxuXG5jb25zdCBzb3J0QnJlYWtwb2ludHNWYWx1ZXMgPSB2YWx1ZXMgPT4ge1xuICBjb25zdCBicmVha3BvaW50c0FzQXJyYXkgPSBPYmplY3Qua2V5cyh2YWx1ZXMpLm1hcChrZXkgPT4gKHtcbiAgICBrZXksXG4gICAgdmFsOiB2YWx1ZXNba2V5XVxuICB9KSkgfHwgW107XG4gIC8vIFNvcnQgaW4gYXNjZW5kaW5nIG9yZGVyXG4gIGJyZWFrcG9pbnRzQXNBcnJheS5zb3J0KChicmVha3BvaW50MSwgYnJlYWtwb2ludDIpID0+IGJyZWFrcG9pbnQxLnZhbCAtIGJyZWFrcG9pbnQyLnZhbCk7XG4gIHJldHVybiBicmVha3BvaW50c0FzQXJyYXkucmVkdWNlKChhY2MsIG9iaikgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5hY2MsXG4gICAgICBbb2JqLmtleV06IG9iai52YWxcbiAgICB9O1xuICB9LCB7fSk7XG59O1xuXG4vLyBLZWVwIGluIG1pbmQgdGhhdCBAbWVkaWEgaXMgaW5jbHVzaXZlIGJ5IHRoZSBDU1Mgc3BlY2lmaWNhdGlvbi5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZUJyZWFrcG9pbnRzKGJyZWFrcG9pbnRzKSB7XG4gIGNvbnN0IHtcbiAgICB2YWx1ZXMgPSB7XG4gICAgICB4czogMCxcbiAgICAgIHNtOiA2MDAsXG4gICAgICBtZDogOTAwLFxuICAgICAgbGc6IDEyMDAsXG4gICAgICB4bDogMTUzNlxuICAgIH0sXG4gICAgdW5pdCA9ICdweCcsXG4gICAgc3RlcCA9IDUsXG4gICAgLi4ub3RoZXJcbiAgfSA9IGJyZWFrcG9pbnRzO1xuICBjb25zdCBzb3J0ZWRWYWx1ZXMgPSBzb3J0QnJlYWtwb2ludHNWYWx1ZXModmFsdWVzKTtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHNvcnRlZFZhbHVlcyk7XG4gIGZ1bmN0aW9uIHVwKGtleSkge1xuICAgIGNvbnN0IHZhbHVlID0gdHlwZW9mIHZhbHVlc1trZXldID09PSAnbnVtYmVyJyA/IHZhbHVlc1trZXldIDoga2V5O1xuICAgIHJldHVybiBgQG1lZGlhIChtaW4td2lkdGg6JHt2YWx1ZX0ke3VuaXR9KWA7XG4gIH1cbiAgZnVuY3Rpb24gZG93bihrZXkpIHtcbiAgICBjb25zdCB2YWx1ZSA9IHR5cGVvZiB2YWx1ZXNba2V5XSA9PT0gJ251bWJlcicgPyB2YWx1ZXNba2V5XSA6IGtleTtcbiAgICByZXR1cm4gYEBtZWRpYSAobWF4LXdpZHRoOiR7dmFsdWUgLSBzdGVwIC8gMTAwfSR7dW5pdH0pYDtcbiAgfVxuICBmdW5jdGlvbiBiZXR3ZWVuKHN0YXJ0LCBlbmQpIHtcbiAgICBjb25zdCBlbmRJbmRleCA9IGtleXMuaW5kZXhPZihlbmQpO1xuICAgIHJldHVybiBgQG1lZGlhIChtaW4td2lkdGg6JHt0eXBlb2YgdmFsdWVzW3N0YXJ0XSA9PT0gJ251bWJlcicgPyB2YWx1ZXNbc3RhcnRdIDogc3RhcnR9JHt1bml0fSkgYW5kIGAgKyBgKG1heC13aWR0aDokeyhlbmRJbmRleCAhPT0gLTEgJiYgdHlwZW9mIHZhbHVlc1trZXlzW2VuZEluZGV4XV0gPT09ICdudW1iZXInID8gdmFsdWVzW2tleXNbZW5kSW5kZXhdXSA6IGVuZCkgLSBzdGVwIC8gMTAwfSR7dW5pdH0pYDtcbiAgfVxuICBmdW5jdGlvbiBvbmx5KGtleSkge1xuICAgIGlmIChrZXlzLmluZGV4T2Yoa2V5KSArIDEgPCBrZXlzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGJldHdlZW4oa2V5LCBrZXlzW2tleXMuaW5kZXhPZihrZXkpICsgMV0pO1xuICAgIH1cbiAgICByZXR1cm4gdXAoa2V5KTtcbiAgfVxuICBmdW5jdGlvbiBub3Qoa2V5KSB7XG4gICAgLy8gaGFuZGxlIGZpcnN0IGFuZCBsYXN0IGtleSBzZXBhcmF0ZWx5LCBmb3IgYmV0dGVyIHJlYWRhYmlsaXR5XG4gICAgY29uc3Qga2V5SW5kZXggPSBrZXlzLmluZGV4T2Yoa2V5KTtcbiAgICBpZiAoa2V5SW5kZXggPT09IDApIHtcbiAgICAgIHJldHVybiB1cChrZXlzWzFdKTtcbiAgICB9XG4gICAgaWYgKGtleUluZGV4ID09PSBrZXlzLmxlbmd0aCAtIDEpIHtcbiAgICAgIHJldHVybiBkb3duKGtleXNba2V5SW5kZXhdKTtcbiAgICB9XG4gICAgcmV0dXJuIGJldHdlZW4oa2V5LCBrZXlzW2tleXMuaW5kZXhPZihrZXkpICsgMV0pLnJlcGxhY2UoJ0BtZWRpYScsICdAbWVkaWEgbm90IGFsbCBhbmQnKTtcbiAgfVxuICBjb25zdCBtZWRpYUtleXMgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgbWVkaWFLZXlzLnB1c2godXAoa2V5c1tpXSkpO1xuICB9XG4gIHJldHVybiB7XG4gICAga2V5czoga2V5cyxcbiAgICB2YWx1ZXM6IHNvcnRlZFZhbHVlcyxcbiAgICB1cCxcbiAgICBkb3duLFxuICAgIGJldHdlZW4sXG4gICAgb25seSxcbiAgICBub3QsXG4gICAgdW5pdCxcbiAgICBpbnRlcm5hbF9tZWRpYUtleXM6IG1lZGlhS2V5cyxcbiAgICAuLi5vdGhlclxuICB9O1xufSIsImltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgaXNPYmplY3RFbXB0eSBmcm9tICdAbXVpL3V0aWxzL2lzT2JqZWN0RW1wdHknO1xuaW1wb3J0IGZhc3REZWVwQXNzaWduIGZyb20gJ0BtdWkvdXRpbHMvZmFzdERlZXBBc3NpZ24nO1xuaW1wb3J0IGRlZXBtZXJnZSBmcm9tICdAbXVpL3V0aWxzL2RlZXBtZXJnZSc7XG5pbXBvcnQgbWVyZ2UgZnJvbSBcIi4uL21lcmdlL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgaXNDcVNob3J0aGFuZCwgZ2V0Q29udGFpbmVyUXVlcnkgfSBmcm9tIFwiLi4vY3NzQ29udGFpbmVyUXVlcmllcy9pbmRleC5tanNcIjtcbmltcG9ydCBjcmVhdGVCcmVha3BvaW50cyBmcm9tIFwiLi4vY3JlYXRlQnJlYWtwb2ludHMvY3JlYXRlQnJlYWtwb2ludHMubWpzXCI7XG5jb25zdCBFTVBUWV9USEVNRSA9IHt9O1xuXG4vLyBUaGUgYnJlYWtwb2ludCAqKnN0YXJ0KiogYXQgdGhpcyB2YWx1ZS5cbi8vIEZvciBpbnN0YW5jZSB3aXRoIHRoZSBmaXJzdCBicmVha3BvaW50IHhzOiBbeHMsIHNtWy5cbi8qKiBAaW50ZXJuYWwgKi9cbmV4cG9ydCBjb25zdCB2YWx1ZXMgPSB7XG4gIHhzOiAwLFxuICAvLyBwaG9uZVxuICBzbTogNjAwLFxuICAvLyB0YWJsZXRcbiAgbWQ6IDkwMCxcbiAgLy8gc21hbGwgbGFwdG9wXG4gIGxnOiAxMjAwLFxuICAvLyBkZXNrdG9wXG4gIHhsOiAxNTM2IC8vIGxhcmdlIHNjcmVlblxufTtcbmV4cG9ydCBjb25zdCBERUZBVUxUX0JSRUFLUE9JTlRTID0gY3JlYXRlQnJlYWtwb2ludHMoe1xuICB2YWx1ZXM6IHZhbHVlc1xufSk7XG5jb25zdCBkZWZhdWx0Q29udGFpbmVyUXVlcmllcyA9IHtcbiAgY29udGFpbmVyUXVlcmllczogY29udGFpbmVyTmFtZSA9PiAoe1xuICAgIHVwOiBrZXkgPT4ge1xuICAgICAgbGV0IHJlc3VsdCA9IHR5cGVvZiBrZXkgPT09ICdudW1iZXInID8ga2V5IDogdmFsdWVzW2tleV0gfHwga2V5O1xuICAgICAgaWYgKHR5cGVvZiByZXN1bHQgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHJlc3VsdCA9IGAke3Jlc3VsdH1weGA7XG4gICAgICB9XG4gICAgICByZXR1cm4gY29udGFpbmVyTmFtZSA/IGBAY29udGFpbmVyICR7Y29udGFpbmVyTmFtZX0gKG1pbi13aWR0aDoke3Jlc3VsdH0pYCA6IGBAY29udGFpbmVyIChtaW4td2lkdGg6JHtyZXN1bHR9KWA7XG4gICAgfVxuICB9KVxufTtcbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVCcmVha3BvaW50cyhwcm9wcywgcHJvcFZhbHVlLCBzdHlsZUZyb21Qcm9wVmFsdWUpIHtcbiAgY29uc3QgcmVzdWx0ID0ge307XG4gIHJldHVybiBpdGVyYXRlQnJlYWtwb2ludHMocmVzdWx0LCBwcm9wcy50aGVtZSwgcHJvcFZhbHVlLCAobWVkaWFLZXksIHZhbHVlLCBpbml0aWFsS2V5KSA9PiB7XG4gICAgY29uc3QgZmluYWxWYWx1ZSA9IHN0eWxlRnJvbVByb3BWYWx1ZSh2YWx1ZSwgaW5pdGlhbEtleSk7XG4gICAgaWYgKG1lZGlhS2V5KSB7XG4gICAgICByZXN1bHRbbWVkaWFLZXldID0gZmluYWxWYWx1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgZmFzdERlZXBBc3NpZ24ocmVzdWx0LCBmaW5hbFZhbHVlKTtcbiAgICB9XG4gIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGl0ZXJhdGVCcmVha3BvaW50cyh0YXJnZXQsIHRoZW1lLCBwcm9wVmFsdWUsIGNhbGxiYWNrKSB7XG4gIHRoZW1lID8/PSBFTVBUWV9USEVNRTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocHJvcFZhbHVlKSkge1xuICAgIGNvbnN0IGJyZWFrcG9pbnRzID0gdGhlbWUuYnJlYWtwb2ludHMgPz8gREVGQVVMVF9CUkVBS1BPSU5UUztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByb3BWYWx1ZS5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgYnVpbGRCcmVha3BvaW50KHRhcmdldCwgYnJlYWtwb2ludHMudXAoYnJlYWtwb2ludHMua2V5c1tpXSksIHByb3BWYWx1ZVtpXSwgdW5kZWZpbmVkLCBjYWxsYmFjayk7XG4gICAgfVxuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcm9wVmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgY29uc3QgYnJlYWtwb2ludHMgPSB0aGVtZS5icmVha3BvaW50cyA/PyBERUZBVUxUX0JSRUFLUE9JTlRTO1xuICAgIGNvbnN0IGJyZWFrcG9pbnRWYWx1ZXMgPSBicmVha3BvaW50cy52YWx1ZXMgPz8gdmFsdWVzO1xuICAgIGZvciAoY29uc3Qga2V5IGluIHByb3BWYWx1ZSkge1xuICAgICAgaWYgKGlzQ3FTaG9ydGhhbmQoYnJlYWtwb2ludHMua2V5cywga2V5KSkge1xuICAgICAgICBjb25zdCBjb250YWluZXJLZXkgPSBnZXRDb250YWluZXJRdWVyeSh0aGVtZS5jb250YWluZXJRdWVyaWVzID8gdGhlbWUgOiBkZWZhdWx0Q29udGFpbmVyUXVlcmllcywga2V5KTtcbiAgICAgICAgaWYgKGNvbnRhaW5lcktleSkge1xuICAgICAgICAgIGJ1aWxkQnJlYWtwb2ludCh0YXJnZXQsIGNvbnRhaW5lcktleSwgcHJvcFZhbHVlW2tleV0sIGtleSwgY2FsbGJhY2spO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGtleSBpbiBicmVha3BvaW50VmFsdWVzKSB7XG4gICAgICAgIGNvbnN0IG1lZGlhS2V5ID0gYnJlYWtwb2ludHMudXAoa2V5KTtcbiAgICAgICAgYnVpbGRCcmVha3BvaW50KHRhcmdldCwgbWVkaWFLZXksIHByb3BWYWx1ZVtrZXldLCBrZXksIGNhbGxiYWNrKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGNzc0tleSA9IGtleTtcbiAgICAgICAgdGFyZ2V0W2Nzc0tleV0gPSBwcm9wVmFsdWVbY3NzS2V5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfVxuICBjYWxsYmFjayh1bmRlZmluZWQsIHByb3BWYWx1ZSk7XG4gIHJldHVybiB0YXJnZXQ7XG59XG5mdW5jdGlvbiBidWlsZEJyZWFrcG9pbnQodGFyZ2V0LCBtZWRpYUtleSwgdmFsdWUsIGluaXRpYWxLZXksIGNhbGxiYWNrKSB7XG4gIHRhcmdldFttZWRpYUtleV0gPz89IHt9O1xuICBjYWxsYmFjayhtZWRpYUtleSwgdmFsdWUsIGluaXRpYWxLZXkpO1xufVxuZnVuY3Rpb24gc2V0dXBCcmVha3BvaW50cyhzdHlsZUZ1bmN0aW9uKSB7XG4gIGNvbnN0IG5ld1N0eWxlRnVuY3Rpb24gPSBwcm9wcyA9PiB7XG4gICAgY29uc3QgdGhlbWUgPSBwcm9wcy50aGVtZSB8fCB7fTtcbiAgICBjb25zdCBiYXNlID0gc3R5bGVGdW5jdGlvbihwcm9wcyk7XG4gICAgY29uc3QgdGhlbWVCcmVha3BvaW50cyA9IHRoZW1lLmJyZWFrcG9pbnRzIHx8IERFRkFVTFRfQlJFQUtQT0lOVFM7XG4gICAgY29uc3QgZXh0ZW5kZWQgPSB0aGVtZUJyZWFrcG9pbnRzLmtleXMucmVkdWNlKChhY2MsIGtleSkgPT4ge1xuICAgICAgaWYgKHByb3BzW2tleV0pIHtcbiAgICAgICAgYWNjID0gYWNjIHx8IHt9O1xuICAgICAgICBhY2NbdGhlbWVCcmVha3BvaW50cy51cChrZXkpXSA9IHN0eWxlRnVuY3Rpb24oe1xuICAgICAgICAgIHRoZW1lLFxuICAgICAgICAgIC4uLnByb3BzW2tleV1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYWNjO1xuICAgIH0sIG51bGwpO1xuICAgIHJldHVybiBtZXJnZShiYXNlLCBleHRlbmRlZCk7XG4gIH07XG4gIG5ld1N0eWxlRnVuY3Rpb24ucHJvcFR5cGVzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IHtcbiAgICAuLi5zdHlsZUZ1bmN0aW9uLnByb3BUeXBlcyxcbiAgICB4czogUHJvcFR5cGVzLm9iamVjdCxcbiAgICBzbTogUHJvcFR5cGVzLm9iamVjdCxcbiAgICBtZDogUHJvcFR5cGVzLm9iamVjdCxcbiAgICBsZzogUHJvcFR5cGVzLm9iamVjdCxcbiAgICB4bDogUHJvcFR5cGVzLm9iamVjdFxuICB9IDoge307XG4gIG5ld1N0eWxlRnVuY3Rpb24uZmlsdGVyUHJvcHMgPSBbJ3hzJywgJ3NtJywgJ21kJywgJ2xnJywgJ3hsJywgLi4uc3R5bGVGdW5jdGlvbi5maWx0ZXJQcm9wc107XG4gIHJldHVybiBuZXdTdHlsZUZ1bmN0aW9uO1xufVxuXG4vKiogQGludGVybmFsICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRW1wdHlCcmVha3BvaW50T2JqZWN0KGJyZWFrcG9pbnRzID0gREVGQVVMVF9CUkVBS1BPSU5UUykge1xuICBjb25zdCB7XG4gICAgaW50ZXJuYWxfbWVkaWFLZXlzOiBtZWRpYUtleXNcbiAgfSA9IGJyZWFrcG9pbnRzO1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBtZWRpYUtleXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICByZXN1bHRbbWVkaWFLZXlzW2ldXSA9IHt9O1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKiBAaW50ZXJuYWwgKi9cbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVVbnVzZWRCcmVha3BvaW50cyhicmVha3BvaW50cywgc3R5bGUpIHtcbiAgY29uc3QgYnJlYWtwb2ludEtleXMgPSBicmVha3BvaW50cy5pbnRlcm5hbF9tZWRpYUtleXM7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnJlYWtwb2ludEtleXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICBjb25zdCBrZXkgPSBicmVha3BvaW50S2V5c1tpXTtcbiAgICBpZiAoaXNPYmplY3RFbXB0eShzdHlsZVtrZXldKSkge1xuICAgICAgZGVsZXRlIHN0eWxlW2tleV07XG4gICAgfVxuICB9XG4gIHJldHVybiBzdHlsZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZUJyZWFrcG9pbnRzSW5PcmRlcihicmVha3BvaW50cywgLi4uc3R5bGVzKSB7XG4gIGNvbnN0IGVtcHR5QnJlYWtwb2ludHMgPSBjcmVhdGVFbXB0eUJyZWFrcG9pbnRPYmplY3QoYnJlYWtwb2ludHMpO1xuICBjb25zdCBtZXJnZWRPdXRwdXQgPSBbZW1wdHlCcmVha3BvaW50cywgLi4uc3R5bGVzXS5yZWR1Y2UoKHByZXYsIG5leHQpID0+IGRlZXBtZXJnZShwcmV2LCBuZXh0KSwge30pO1xuICByZXR1cm4gcmVtb3ZlVW51c2VkQnJlYWtwb2ludHMoYnJlYWtwb2ludHMsIG1lcmdlZE91dHB1dCk7XG59XG5cbi8qKiBAaW50ZXJuYWwgKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21wdXRlQnJlYWtwb2ludHNCYXNlKGJyZWFrcG9pbnRWYWx1ZXMsIHRoZW1lQnJlYWtwb2ludHMpIHtcbiAgaWYgKHR5cGVvZiBicmVha3BvaW50VmFsdWVzICE9PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiB7fTtcbiAgfVxuICBjb25zdCBiYXNlID0ge307XG4gIGNvbnN0IGJyZWFrcG9pbnRzS2V5cyA9IE9iamVjdC5rZXlzKHRoZW1lQnJlYWtwb2ludHMpO1xuICBpZiAoQXJyYXkuaXNBcnJheShicmVha3BvaW50VmFsdWVzKSkge1xuICAgIGJyZWFrcG9pbnRzS2V5cy5mb3JFYWNoKChicmVha3BvaW50LCBpKSA9PiB7XG4gICAgICBpZiAoaSA8IGJyZWFrcG9pbnRWYWx1ZXMubGVuZ3RoKSB7XG4gICAgICAgIGJhc2VbYnJlYWtwb2ludF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGJyZWFrcG9pbnRzS2V5cy5mb3JFYWNoKGJyZWFrcG9pbnQgPT4ge1xuICAgICAgaWYgKGJyZWFrcG9pbnRWYWx1ZXNbYnJlYWtwb2ludF0gIT0gbnVsbCkge1xuICAgICAgICBiYXNlW2JyZWFrcG9pbnRdID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4gYmFzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQnJlYWtwb2ludFZhbHVlcyhvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICB2YWx1ZXM6IGJyZWFrcG9pbnRWYWx1ZXMsXG4gICAgYnJlYWtwb2ludHM6IHRoZW1lQnJlYWtwb2ludHMsXG4gICAgYmFzZTogY3VzdG9tQmFzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgYmFzZSA9IGN1c3RvbUJhc2UgfHwgY29tcHV0ZUJyZWFrcG9pbnRzQmFzZShicmVha3BvaW50VmFsdWVzLCB0aGVtZUJyZWFrcG9pbnRzKTtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGJhc2UpO1xuICBpZiAoa2V5cy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gYnJlYWtwb2ludFZhbHVlcztcbiAgfVxuICBsZXQgcHJldmlvdXM7XG4gIHJldHVybiBrZXlzLnJlZHVjZSgoYWNjLCBicmVha3BvaW50LCBpKSA9PiB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYnJlYWtwb2ludFZhbHVlcykpIHtcbiAgICAgIGFjY1ticmVha3BvaW50XSA9IGJyZWFrcG9pbnRWYWx1ZXNbaV0gIT0gbnVsbCA/IGJyZWFrcG9pbnRWYWx1ZXNbaV0gOiBicmVha3BvaW50VmFsdWVzW3ByZXZpb3VzXTtcbiAgICAgIHByZXZpb3VzID0gaTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBicmVha3BvaW50VmFsdWVzID09PSAnb2JqZWN0JyAmJiBicmVha3BvaW50VmFsdWVzKSB7XG4gICAgICBjb25zdCBidiA9IGJyZWFrcG9pbnRWYWx1ZXM7XG4gICAgICBhY2NbYnJlYWtwb2ludF0gPSBidlticmVha3BvaW50XSAhPSBudWxsID8gYnZbYnJlYWtwb2ludF0gOiBidltwcmV2aW91c107XG4gICAgICBwcmV2aW91cyA9IGJyZWFrcG9pbnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFjY1ticmVha3BvaW50XSA9IGJyZWFrcG9pbnRWYWx1ZXM7XG4gICAgfVxuICAgIHJldHVybiBhY2M7XG4gIH0sIHt9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBoYXNCcmVha3BvaW50KGJyZWFrcG9pbnRzLCB2YWx1ZSkge1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYnJlYWtwb2ludHMua2V5cy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgaWYgKGJyZWFrcG9pbnRzLmtleXNbaV0gaW4gdmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlS2V5cyA9IE9iamVjdC5rZXlzKHZhbHVlKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlS2V5cy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgaWYgKGlzQ3FTaG9ydGhhbmQoYnJlYWtwb2ludHMua2V5cywgdmFsdWVLZXlzW2ldKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGRlZmF1bHQgc2V0dXBCcmVha3BvaW50czsiLCJpbXBvcnQgY2FwaXRhbGl6ZSBmcm9tICdAbXVpL3V0aWxzL2NhcGl0YWxpemUnO1xuaW1wb3J0IHJlc3BvbnNpdmVQcm9wVHlwZSBmcm9tIFwiLi4vcmVzcG9uc2l2ZVByb3BUeXBlL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgaGFuZGxlQnJlYWtwb2ludHMgfSBmcm9tIFwiLi4vYnJlYWtwb2ludHMvaW5kZXgubWpzXCI7XG4vKipcbiAqIFRPRE8odjcpOiBLZWVwIGVpdGhlciB0aGlzIG9uZSBvciBgZ2V0U3R5bGVWYWx1ZTJgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdHlsZVZhbHVlKHRoZW1lTWFwcGluZywgdHJhbnNmb3JtLCB2YWx1ZUZpbmFsLCB1c2VyVmFsdWUgPSB2YWx1ZUZpbmFsKSB7XG4gIGxldCB2YWx1ZTtcbiAgaWYgKHR5cGVvZiB0aGVtZU1hcHBpbmcgPT09ICdmdW5jdGlvbicpIHtcbiAgICB2YWx1ZSA9IHRoZW1lTWFwcGluZyh2YWx1ZUZpbmFsKTtcbiAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHRoZW1lTWFwcGluZykpIHtcbiAgICB2YWx1ZSA9IHRoZW1lTWFwcGluZ1t2YWx1ZUZpbmFsXSB8fCB1c2VyVmFsdWU7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlRmluYWwgPT09ICdzdHJpbmcnKSB7XG4gICAgdmFsdWUgPSBnZXRQYXRoKHRoZW1lTWFwcGluZywgdmFsdWVGaW5hbCkgfHwgdXNlclZhbHVlO1xuICB9IGVsc2Uge1xuICAgIHZhbHVlID0gdXNlclZhbHVlO1xuICB9XG4gIGlmICh0cmFuc2Zvcm0pIHtcbiAgICB2YWx1ZSA9IHRyYW5zZm9ybSh2YWx1ZSwgdXNlclZhbHVlLCB0aGVtZU1hcHBpbmcpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuLyoqXG4gKiBIQUNLOiBUaGUgYGFsdGVybmF0ZVByb3BgIGxvZ2ljIGlzIHRoZXJlIGJlY2F1c2Ugb3VyIHRoZW1lIGxvb2tzIGxpa2UgdGhpczpcbiAqIHtcbiAqICAgdHlwb2dyYXBoeToge1xuICogICAgIGZvbnRGYW1pbHk6ICdjb21pYyBzYW5zJyxcbiAqICAgICBmb250RmFtaWx5Q29kZTogJ2NvdXJyaWVyIG5ldycsXG4gKiAgIH1cbiAqIH1cbiAqIEFuZCB3ZSBzdXBwb3J0IHRhcmdldHRpbmc6XG4gKiAtIGB0eXBvZ3JhcGh5LmZvbnRGYW1pbHlgICAgICB3aXRoIGBzeD17eyBmb250RmFtaWx5OiAnZGVmYXVsdCcgfX1gXG4gKiAtIGB0eXBvZ3JhcGh5LmZvbnRGYW1pbHlDb2RlYCB3aXRoIGBzeD17eyBmb250RmFtaWx5OiAnY29kZScgfX1gXG4gKlxuICogVE9ETyh2Nyk6IFJlZmFjdG9yIG91ciB0aGVtZSB0byBsb29rIGxpa2UgdGhpcyBhbmQgcmVtb3ZlIHRoZSBob3JyZW5kb3VzIGxvZ2ljOlxuICoge1xuICogICB0eXBvZ3JhcGh5OiB7XG4gKiAgICAgZm9udEZhbWlseToge1xuICogICAgICAgZGVmYXVsdDogJ2NvbWljIHNhbnMnLFxuICogICAgICAgY29kZTogJ2NvdXJyaWVyIG5ldycsXG4gKiAgICAgfVxuICogICB9XG4gKiB9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdHlsZVZhbHVlMih0aGVtZU1hcHBpbmcsIHRyYW5zZm9ybSwgdXNlclZhbHVlLCBhbHRlcm5hdGVQcm9wKSB7XG4gIGxldCB2YWx1ZTtcbiAgaWYgKHR5cGVvZiB0aGVtZU1hcHBpbmcgPT09ICdmdW5jdGlvbicpIHtcbiAgICB2YWx1ZSA9IHRoZW1lTWFwcGluZyh1c2VyVmFsdWUpO1xuICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodGhlbWVNYXBwaW5nKSkge1xuICAgIHZhbHVlID0gdGhlbWVNYXBwaW5nW3VzZXJWYWx1ZV0gfHwgdXNlclZhbHVlO1xuICB9IGVsc2UgaWYgKHR5cGVvZiB1c2VyVmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgdmFsdWUgPSBnZXRQYXRoKHRoZW1lTWFwcGluZywgdXNlclZhbHVlLCB0cnVlLCBhbHRlcm5hdGVQcm9wKSB8fCB1c2VyVmFsdWU7XG4gIH0gZWxzZSB7XG4gICAgdmFsdWUgPSB1c2VyVmFsdWU7XG4gIH1cbiAgaWYgKHRyYW5zZm9ybSkge1xuICAgIHZhbHVlID0gdHJhbnNmb3JtKHZhbHVlLCB1c2VyVmFsdWUsIHRoZW1lTWFwcGluZyk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFBhdGgob2JqLCBwYXRoSW5wdXQsIGNoZWNrVmFycyA9IHRydWUsIGFsdGVybmF0ZVByb3AgPSB1bmRlZmluZWQpIHtcbiAgaWYgKCFvYmogfHwgIXBhdGhJbnB1dCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHBhdGggPSBwYXRoSW5wdXQuc3BsaXQoJy4nKTtcblxuICAvLyBDaGVjayBpZiBDU1MgdmFyaWFibGVzIGFyZSB1c2VkXG4gIGlmIChvYmoudmFycyAmJiBjaGVja1ZhcnMpIHtcbiAgICBjb25zdCB2YWwgPSBnZXRQYXRoSW1wbChvYmoudmFycywgcGF0aCwgYWx0ZXJuYXRlUHJvcCk7XG4gICAgaWYgKHZhbCAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gdmFsO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZ2V0UGF0aEltcGwob2JqLCBwYXRoLCBhbHRlcm5hdGVQcm9wKTtcbn1cbmZ1bmN0aW9uIGdldFBhdGhJbXBsKG9iamVjdCwgcGF0aCwgYWx0ZXJuYXRlUHJvcCA9IHVuZGVmaW5lZCkge1xuICBsZXQgbGFzdFJlc3VsdCA9IHVuZGVmaW5lZDtcbiAgbGV0IHJlc3VsdCA9IG9iamVjdDtcbiAgbGV0IGluZGV4ID0gMDtcbiAgd2hpbGUgKGluZGV4IDwgcGF0aC5sZW5ndGgpIHtcbiAgICBpZiAocmVzdWx0ID09PSBudWxsIHx8IHJlc3VsdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBsYXN0UmVzdWx0ID0gcmVzdWx0O1xuICAgIHJlc3VsdCA9IHJlc3VsdFtwYXRoW2luZGV4XV07XG4gICAgaW5kZXggKz0gMTtcbiAgfVxuICBpZiAoYWx0ZXJuYXRlUHJvcCAmJiByZXN1bHQgPT09IHVuZGVmaW5lZCkge1xuICAgIGNvbnN0IGxhc3RLZXkgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG4gICAgY29uc3QgYWx0ZXJuYXRlS2V5ID0gYCR7YWx0ZXJuYXRlUHJvcH0ke2xhc3RLZXkgPT09ICdkZWZhdWx0JyA/ICcnIDogY2FwaXRhbGl6ZShsYXN0S2V5KX1gO1xuICAgIHJldHVybiBsYXN0UmVzdWx0Py5bYWx0ZXJuYXRlS2V5XTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc3R5bGUob3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgcHJvcCxcbiAgICBjc3NQcm9wZXJ0eSA9IG9wdGlvbnMucHJvcCxcbiAgICB0aGVtZUtleSxcbiAgICB0cmFuc2Zvcm1cbiAgfSA9IG9wdGlvbnM7XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0L2Z1bmN0aW9uLWNvbXBvbmVudC1kZWZpbml0aW9uXG4gIGNvbnN0IGZuID0gcHJvcHMgPT4ge1xuICAgIGlmIChwcm9wc1twcm9wXSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgcHJvcFZhbHVlID0gcHJvcHNbcHJvcF07XG4gICAgY29uc3QgdGhlbWUgPSBwcm9wcy50aGVtZTtcbiAgICBjb25zdCB0aGVtZU1hcHBpbmcgPSBnZXRQYXRoKHRoZW1lLCB0aGVtZUtleSkgfHwge307XG4gICAgY29uc3Qgc3R5bGVGcm9tUHJvcFZhbHVlID0gdmFsdWVGaW5hbCA9PiB7XG4gICAgICBjb25zdCB2YWx1ZSA9IGdldFN0eWxlVmFsdWUyKHRoZW1lTWFwcGluZywgdHJhbnNmb3JtLCB2YWx1ZUZpbmFsLCBwcm9wKTtcbiAgICAgIHJldHVybiBjc3NQcm9wZXJ0eSA9PT0gZmFsc2UgPyB2YWx1ZSA6IHtcbiAgICAgICAgW2Nzc1Byb3BlcnR5XTogdmFsdWVcbiAgICAgIH07XG4gICAgfTtcbiAgICByZXR1cm4gaGFuZGxlQnJlYWtwb2ludHMocHJvcHMsIHByb3BWYWx1ZSwgc3R5bGVGcm9tUHJvcFZhbHVlKTtcbiAgfTtcbiAgZm4ucHJvcFR5cGVzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IHtcbiAgICBbcHJvcF06IHJlc3BvbnNpdmVQcm9wVHlwZVxuICB9IDoge307XG4gIGZuLmZpbHRlclByb3BzID0gW3Byb3BdO1xuICByZXR1cm4gZm47XG59IiwiaW1wb3J0IHJlc3BvbnNpdmVQcm9wVHlwZSBmcm9tIFwiLi4vcmVzcG9uc2l2ZVByb3BUeXBlL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgaXRlcmF0ZUJyZWFrcG9pbnRzIH0gZnJvbSBcIi4uL2JyZWFrcG9pbnRzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0UGF0aCB9IGZyb20gXCIuLi9zdHlsZS9pbmRleC5tanNcIjtcblxuLyogZXNsaW50LWRpc2FibGUgZ3VhcmQtZm9yLWluICovXG5cbmNvbnN0IEVNUFRZX1RIRU1FID0ge1xuICBpbnRlcm5hbF9jYWNoZToge31cbn07XG5jb25zdCBwcm9wZXJ0aWVzID0ge1xuICBtOiAnbWFyZ2luJyxcbiAgcDogJ3BhZGRpbmcnXG59O1xuY29uc3QgZGlyZWN0aW9ucyA9IHtcbiAgdDogJ1RvcCcsXG4gIHI6ICdSaWdodCcsXG4gIGI6ICdCb3R0b20nLFxuICBsOiAnTGVmdCcsXG4gIHg6IFsnTGVmdCcsICdSaWdodCddLFxuICB5OiBbJ1RvcCcsICdCb3R0b20nXVxufTtcbmNvbnN0IGFsaWFzZXMgPSB7XG4gIG1hcmdpblg6ICdteCcsXG4gIG1hcmdpblk6ICdteScsXG4gIHBhZGRpbmdYOiAncHgnLFxuICBwYWRkaW5nWTogJ3B5J1xufTtcbmNvbnN0IENTU19QUk9QRVJUSUVTID0ge307XG5mb3IgKGNvbnN0IGtleSBpbiBwcm9wZXJ0aWVzKSB7XG4gIENTU19QUk9QRVJUSUVTW2tleV0gPSBbcHJvcGVydGllc1trZXldXTtcbn1cbmZvciAoY29uc3Qga2V5UHJvcGVydHkgaW4gcHJvcGVydGllcykge1xuICBmb3IgKGNvbnN0IGtleURpcmVjdGlvbiBpbiBkaXJlY3Rpb25zKSB7XG4gICAgY29uc3QgcHJvcGVydHkgPSBwcm9wZXJ0aWVzW2tleVByb3BlcnR5XTtcbiAgICBjb25zdCBkaXJlY3Rpb24gPSBkaXJlY3Rpb25zW2tleURpcmVjdGlvbl07XG4gICAgY29uc3QgdmFsdWUgPSBBcnJheS5pc0FycmF5KGRpcmVjdGlvbikgPyBkaXJlY3Rpb24ubWFwKGRpciA9PiBwcm9wZXJ0eSArIGRpcikgOiBbcHJvcGVydHkgKyBkaXJlY3Rpb25dO1xuICAgIENTU19QUk9QRVJUSUVTW2tleVByb3BlcnR5ICsga2V5RGlyZWN0aW9uXSA9IHZhbHVlO1xuICB9XG59XG5mb3IgKGNvbnN0IGtleSBpbiBhbGlhc2VzKSB7XG4gIENTU19QUk9QRVJUSUVTW2tleV0gPSBDU1NfUFJPUEVSVElFU1thbGlhc2VzW2tleV1dO1xufVxuXG4vKiogQGludGVybmFsICovXG5leHBvcnQgY29uc3QgbWFyZ2luS2V5cyA9IG5ldyBTZXQoWydtJywgJ210JywgJ21yJywgJ21iJywgJ21sJywgJ214JywgJ215JywgJ21hcmdpbicsICdtYXJnaW5Ub3AnLCAnbWFyZ2luUmlnaHQnLCAnbWFyZ2luQm90dG9tJywgJ21hcmdpbkxlZnQnLCAnbWFyZ2luWCcsICdtYXJnaW5ZJywgJ21hcmdpbklubGluZScsICdtYXJnaW5JbmxpbmVTdGFydCcsICdtYXJnaW5JbmxpbmVFbmQnLCAnbWFyZ2luQmxvY2snLCAnbWFyZ2luQmxvY2tTdGFydCcsICdtYXJnaW5CbG9ja0VuZCddKTtcblxuLyoqIEBpbnRlcm5hbCAqL1xuZXhwb3J0IGNvbnN0IHBhZGRpbmdLZXlzID0gbmV3IFNldChbJ3AnLCAncHQnLCAncHInLCAncGInLCAncGwnLCAncHgnLCAncHknLCAncGFkZGluZycsICdwYWRkaW5nVG9wJywgJ3BhZGRpbmdSaWdodCcsICdwYWRkaW5nQm90dG9tJywgJ3BhZGRpbmdMZWZ0JywgJ3BhZGRpbmdYJywgJ3BhZGRpbmdZJywgJ3BhZGRpbmdJbmxpbmUnLCAncGFkZGluZ0lubGluZVN0YXJ0JywgJ3BhZGRpbmdJbmxpbmVFbmQnLCAncGFkZGluZ0Jsb2NrJywgJ3BhZGRpbmdCbG9ja1N0YXJ0JywgJ3BhZGRpbmdCbG9ja0VuZCddKTtcbmNvbnN0IHNwYWNpbmdLZXlzID0gbmV3IFNldChbLi4ubWFyZ2luS2V5cywgLi4ucGFkZGluZ0tleXNdKTtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVVbmFyeVVuaXQodGhlbWUsIHRoZW1lS2V5LCBkZWZhdWx0VmFsdWUsIHByb3BOYW1lKSB7XG4gIGNvbnN0IHRoZW1lU3BhY2luZyA9IGdldFBhdGgodGhlbWUsIHRoZW1lS2V5LCB0cnVlKSA/PyBkZWZhdWx0VmFsdWU7XG4gIGlmICh0eXBlb2YgdGhlbWVTcGFjaW5nID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdGhlbWVTcGFjaW5nID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB2YWwgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiB2YWw7XG4gICAgICB9XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBpZiAodHlwZW9mIHZhbCAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBNVUk6IEV4cGVjdGVkICR7cHJvcE5hbWV9IGFyZ3VtZW50IHRvIGJlIGEgbnVtYmVyIG9yIGEgc3RyaW5nLCBnb3QgJHt2YWx9LmApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHRoZW1lU3BhY2luZyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgaWYgKHRoZW1lU3BhY2luZy5zdGFydHNXaXRoKCd2YXIoJykgJiYgdmFsID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoZW1lU3BhY2luZy5zdGFydHNXaXRoKCd2YXIoJykgJiYgdmFsID09PSAxKSB7XG4gICAgICAgICAgcmV0dXJuIHRoZW1lU3BhY2luZztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYGNhbGMoJHt2YWx9ICogJHt0aGVtZVNwYWNpbmd9KWA7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhlbWVTcGFjaW5nICogdmFsO1xuICAgIH07XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodGhlbWVTcGFjaW5nKSkge1xuICAgIHJldHVybiB2YWwgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiB2YWw7XG4gICAgICB9XG4gICAgICBjb25zdCBhYnMgPSBNYXRoLmFicyh2YWwpO1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNJbnRlZ2VyKGFicykpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFtgTVVJOiBUaGUgXFxgdGhlbWUuJHt0aGVtZUtleX1cXGAgYXJyYXkgdHlwZSBjYW5ub3QgYmUgY29tYmluZWQgd2l0aCBub24gaW50ZWdlciB2YWx1ZXMuYCArIGBZb3Ugc2hvdWxkIGVpdGhlciB1c2UgYW4gaW50ZWdlciB2YWx1ZSB0aGF0IGNhbiBiZSB1c2VkIGFzIGluZGV4LCBvciBkZWZpbmUgdGhlIFxcYHRoZW1lLiR7dGhlbWVLZXl9XFxgIGFzIGEgbnVtYmVyLmBdLmpvaW4oJ1xcbicpKTtcbiAgICAgICAgfSBlbHNlIGlmIChhYnMgPiB0aGVtZVNwYWNpbmcubGVuZ3RoIC0gMSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoW2BNVUk6IFRoZSB2YWx1ZSBwcm92aWRlZCAoJHthYnN9KSBvdmVyZmxvd3MuYCwgYFRoZSBzdXBwb3J0ZWQgdmFsdWVzIGFyZTogJHtKU09OLnN0cmluZ2lmeSh0aGVtZVNwYWNpbmcpfS5gLCBgJHthYnN9ID4gJHt0aGVtZVNwYWNpbmcubGVuZ3RoIC0gMX0sIHlvdSBuZWVkIHRvIGFkZCB0aGUgbWlzc2luZyB2YWx1ZXMuYF0uam9pbignXFxuJykpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCB0cmFuc2Zvcm1lZCA9IHRoZW1lU3BhY2luZ1thYnNdO1xuICAgICAgaWYgKHZhbCA+PSAwKSB7XG4gICAgICAgIHJldHVybiB0cmFuc2Zvcm1lZDtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgdHJhbnNmb3JtZWQgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHJldHVybiAtdHJhbnNmb3JtZWQ7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHRyYW5zZm9ybWVkID09PSAnc3RyaW5nJyAmJiB0cmFuc2Zvcm1lZC5zdGFydHNXaXRoKCd2YXIoJykpIHtcbiAgICAgICAgcmV0dXJuIGBjYWxjKC0xICogJHt0cmFuc2Zvcm1lZH0pYDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBgLSR7dHJhbnNmb3JtZWR9YDtcbiAgICB9O1xuICB9XG4gIGlmICh0eXBlb2YgdGhlbWVTcGFjaW5nID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIHRoZW1lU3BhY2luZztcbiAgfVxuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnNvbGUuZXJyb3IoW2BNVUk6IFRoZSBcXGB0aGVtZS4ke3RoZW1lS2V5fVxcYCB2YWx1ZSAoJHt0aGVtZVNwYWNpbmd9KSBpcyBpbnZhbGlkLmAsICdJdCBzaG91bGQgYmUgYSBudW1iZXIsIGFuIGFycmF5IG9yIGEgZnVuY3Rpb24uJ10uam9pbignXFxuJykpO1xuICB9XG4gIHJldHVybiAoKSA9PiB1bmRlZmluZWQ7XG59XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVW5hcnlTcGFjaW5nKHRoZW1lKSB7XG4gIHJldHVybiBjcmVhdGVVbmFyeVVuaXQodGhlbWUsICdzcGFjaW5nJywgOCwgJ3NwYWNpbmcnKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRWYWx1ZSh0cmFuc2Zvcm1lciwgcHJvcFZhbHVlKSB7XG4gIGlmICh0eXBlb2YgcHJvcFZhbHVlID09PSAnc3RyaW5nJyB8fCBwcm9wVmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBwcm9wVmFsdWU7XG4gIH1cbiAgcmV0dXJuIHRyYW5zZm9ybWVyKHByb3BWYWx1ZSk7XG59XG5cbi8vIEF2b2lkIGFsbG9jYXRpb25zXG5jb25zdCBjb250YWluZXIgPSBbJyddO1xuZnVuY3Rpb24gc3R5bGUocHJvcHMsIGtleXMpIHtcbiAgY29uc3QgdGhlbWUgPSBwcm9wcy50aGVtZSA/PyBFTVBUWV9USEVNRTtcbiAgY29uc3QgdHJhbnNmb3JtZXIgPSB0aGVtZT8uaW50ZXJuYWxfY2FjaGU/LnVuYXJ5U3BhY2luZyA/PyBjcmVhdGVVbmFyeVNwYWNpbmcodGhlbWUpO1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgZm9yIChjb25zdCBwcm9wIGluIHByb3BzKSB7XG4gICAgaWYgKCFrZXlzLmhhcyhwcm9wKSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGNzc1Byb3BlcnRpZXMgPSBDU1NfUFJPUEVSVElFU1twcm9wXSA/PyAoY29udGFpbmVyWzBdID0gcHJvcCwgY29udGFpbmVyKTtcbiAgICBjb25zdCBwcm9wVmFsdWUgPSBwcm9wc1twcm9wXTtcbiAgICBpdGVyYXRlQnJlYWtwb2ludHMocmVzdWx0LCBwcm9wcy50aGVtZSwgcHJvcFZhbHVlLCAobWVkaWFLZXksIHZhbHVlKSA9PiB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBtZWRpYUtleSA/IHJlc3VsdFttZWRpYUtleV0gOiByZXN1bHQ7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNzc1Byb3BlcnRpZXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgdGFyZ2V0W2Nzc1Byb3BlcnRpZXNbaV1dID0gZ2V0VmFsdWUodHJhbnNmb3JtZXIsIHZhbHVlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gbWFyZ2luRm4ocHJvcHMpIHtcbiAgcmV0dXJuIHN0eWxlKHByb3BzLCBtYXJnaW5LZXlzKTtcbn1cbm1hcmdpbkZuLnByb3BUeXBlcyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgPyBBcnJheS5mcm9tKG1hcmdpbktleXMpLnJlZHVjZSgob2JqLCBrZXkpID0+IHtcbiAgb2JqW2tleV0gPSByZXNwb25zaXZlUHJvcFR5cGU7XG4gIHJldHVybiBvYmo7XG59LCB7fSkgOiB7fTtcbm1hcmdpbkZuLmZpbHRlclByb3BzID0gbWFyZ2luS2V5cztcbmV4cG9ydCBjb25zdCBtYXJnaW4gPSBtYXJnaW5GbjtcbmZ1bmN0aW9uIHBhZGRpbmdGbihwcm9wcykge1xuICByZXR1cm4gc3R5bGUocHJvcHMsIHBhZGRpbmdLZXlzKTtcbn1cbnBhZGRpbmdGbi5wcm9wVHlwZXMgPSBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nID8gQXJyYXkuZnJvbShwYWRkaW5nS2V5cykucmVkdWNlKChvYmosIGtleSkgPT4ge1xuICBvYmpba2V5XSA9IHJlc3BvbnNpdmVQcm9wVHlwZTtcbiAgcmV0dXJuIG9iajtcbn0sIHt9KSA6IHt9O1xucGFkZGluZ0ZuLmZpbHRlclByb3BzID0gcGFkZGluZ0tleXM7XG5leHBvcnQgY29uc3QgcGFkZGluZyA9IHBhZGRpbmdGbjtcbmZ1bmN0aW9uIHNwYWNpbmdGbihwcm9wcykge1xuICByZXR1cm4gc3R5bGUocHJvcHMsIHNwYWNpbmdLZXlzKTtcbn1cbnNwYWNpbmdGbi5wcm9wVHlwZXMgPSBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nID8gQXJyYXkuZnJvbShzcGFjaW5nS2V5cykucmVkdWNlKChvYmosIGtleSkgPT4ge1xuICBvYmpba2V5XSA9IHJlc3BvbnNpdmVQcm9wVHlwZTtcbiAgcmV0dXJuIG9iajtcbn0sIHt9KSA6IHt9O1xuc3BhY2luZ0ZuLmZpbHRlclByb3BzID0gc3BhY2luZ0tleXM7XG5jb25zdCBzcGFjaW5nID0gc3BhY2luZ0ZuO1xuZXhwb3J0IGRlZmF1bHQgc3BhY2luZzsiLCJpbXBvcnQgZmFzdERlZXBBc3NpZ24gZnJvbSAnQG11aS91dGlscy9mYXN0RGVlcEFzc2lnbic7XG5mdW5jdGlvbiBjb21wb3NlKC4uLnN0eWxlcykge1xuICBjb25zdCBoYW5kbGVycyA9IHN0eWxlcy5yZWR1Y2UoKGFjYywgc3R5bGUpID0+IHtcbiAgICBzdHlsZS5maWx0ZXJQcm9wcy5mb3JFYWNoKHByb3AgPT4ge1xuICAgICAgYWNjW3Byb3BdID0gc3R5bGU7XG4gICAgfSk7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xuICBjb25zdCBmbiA9IHByb3BzID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IHByb3AgaW4gcHJvcHMpIHtcbiAgICAgIGlmIChoYW5kbGVyc1twcm9wXSkge1xuICAgICAgICBmYXN0RGVlcEFzc2lnbihyZXN1bHQsIGhhbmRsZXJzW3Byb3BdKHByb3BzKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG4gIGZuLnByb3BUeXBlcyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgPyBzdHlsZXMucmVkdWNlKChhY2MsIHN0eWxlKSA9PiBPYmplY3QuYXNzaWduKGFjYywgc3R5bGUucHJvcFR5cGVzKSwge30pIDoge307XG4gIGZuLmZpbHRlclByb3BzID0gc3R5bGVzLnJlZHVjZSgoYWNjLCBzdHlsZSkgPT4gYWNjLmNvbmNhdChzdHlsZS5maWx0ZXJQcm9wcyksIFtdKTtcbiAgcmV0dXJuIGZuO1xufVxuZXhwb3J0IGRlZmF1bHQgY29tcG9zZTsiLCJpbXBvcnQgcmVzcG9uc2l2ZVByb3BUeXBlIGZyb20gXCIuLi9yZXNwb25zaXZlUHJvcFR5cGUvaW5kZXgubWpzXCI7XG5pbXBvcnQgc3R5bGUgZnJvbSBcIi4uL3N0eWxlL2luZGV4Lm1qc1wiO1xuaW1wb3J0IGNvbXBvc2UgZnJvbSBcIi4uL2NvbXBvc2UvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVVbmFyeVVuaXQsIGdldFZhbHVlIH0gZnJvbSBcIi4uL3NwYWNpbmcvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBoYW5kbGVCcmVha3BvaW50cyB9IGZyb20gXCIuLi9icmVha3BvaW50cy9pbmRleC5tanNcIjtcblxuLyoqIEBpbnRlcm5hbCAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJvcmRlclRyYW5zZm9ybSh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICByZXR1cm4gYCR7dmFsdWV9cHggc29saWRgO1xufVxuZnVuY3Rpb24gY3JlYXRlQm9yZGVyU3R5bGUocHJvcCwgdHJhbnNmb3JtKSB7XG4gIHJldHVybiBzdHlsZSh7XG4gICAgcHJvcCxcbiAgICB0aGVtZUtleTogJ2JvcmRlcnMnLFxuICAgIHRyYW5zZm9ybTogdHJhbnNmb3JtXG4gIH0pO1xufVxuZXhwb3J0IGNvbnN0IGJvcmRlciA9IGNyZWF0ZUJvcmRlclN0eWxlKCdib3JkZXInLCBib3JkZXJUcmFuc2Zvcm0pO1xuZXhwb3J0IGNvbnN0IGJvcmRlclRvcCA9IGNyZWF0ZUJvcmRlclN0eWxlKCdib3JkZXJUb3AnLCBib3JkZXJUcmFuc2Zvcm0pO1xuZXhwb3J0IGNvbnN0IGJvcmRlclJpZ2h0ID0gY3JlYXRlQm9yZGVyU3R5bGUoJ2JvcmRlclJpZ2h0JywgYm9yZGVyVHJhbnNmb3JtKTtcbmV4cG9ydCBjb25zdCBib3JkZXJCb3R0b20gPSBjcmVhdGVCb3JkZXJTdHlsZSgnYm9yZGVyQm90dG9tJywgYm9yZGVyVHJhbnNmb3JtKTtcbmV4cG9ydCBjb25zdCBib3JkZXJMZWZ0ID0gY3JlYXRlQm9yZGVyU3R5bGUoJ2JvcmRlckxlZnQnLCBib3JkZXJUcmFuc2Zvcm0pO1xuZXhwb3J0IGNvbnN0IGJvcmRlckNvbG9yID0gY3JlYXRlQm9yZGVyU3R5bGUoJ2JvcmRlckNvbG9yJyk7XG5leHBvcnQgY29uc3QgYm9yZGVyVG9wQ29sb3IgPSBjcmVhdGVCb3JkZXJTdHlsZSgnYm9yZGVyVG9wQ29sb3InKTtcbmV4cG9ydCBjb25zdCBib3JkZXJSaWdodENvbG9yID0gY3JlYXRlQm9yZGVyU3R5bGUoJ2JvcmRlclJpZ2h0Q29sb3InKTtcbmV4cG9ydCBjb25zdCBib3JkZXJCb3R0b21Db2xvciA9IGNyZWF0ZUJvcmRlclN0eWxlKCdib3JkZXJCb3R0b21Db2xvcicpO1xuZXhwb3J0IGNvbnN0IGJvcmRlckxlZnRDb2xvciA9IGNyZWF0ZUJvcmRlclN0eWxlKCdib3JkZXJMZWZ0Q29sb3InKTtcbmV4cG9ydCBjb25zdCBvdXRsaW5lID0gY3JlYXRlQm9yZGVyU3R5bGUoJ291dGxpbmUnLCBib3JkZXJUcmFuc2Zvcm0pO1xuZXhwb3J0IGNvbnN0IG91dGxpbmVDb2xvciA9IGNyZWF0ZUJvcmRlclN0eWxlKCdvdXRsaW5lQ29sb3InKTtcbmV4cG9ydCBjb25zdCBib3JkZXJSYWRpdXMgPSBwcm9wcyA9PiB7XG4gIGlmIChwcm9wcy5ib3JkZXJSYWRpdXMgIT09IHVuZGVmaW5lZCAmJiBwcm9wcy5ib3JkZXJSYWRpdXMgIT09IG51bGwpIHtcbiAgICBjb25zdCB0cmFuc2Zvcm1lciA9IGNyZWF0ZVVuYXJ5VW5pdChwcm9wcy50aGVtZSwgJ3NoYXBlLmJvcmRlclJhZGl1cycsIDQsICdib3JkZXJSYWRpdXMnKTtcbiAgICBjb25zdCBzdHlsZUZyb21Qcm9wVmFsdWUgPSBwcm9wVmFsdWUgPT4gKHtcbiAgICAgIGJvcmRlclJhZGl1czogZ2V0VmFsdWUodHJhbnNmb3JtZXIsIHByb3BWYWx1ZSlcbiAgICB9KTtcbiAgICByZXR1cm4gaGFuZGxlQnJlYWtwb2ludHMocHJvcHMsIHByb3BzLmJvcmRlclJhZGl1cywgc3R5bGVGcm9tUHJvcFZhbHVlKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn07XG5ib3JkZXJSYWRpdXMucHJvcFR5cGVzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IHtcbiAgYm9yZGVyUmFkaXVzOiByZXNwb25zaXZlUHJvcFR5cGVcbn0gOiB7fTtcbmJvcmRlclJhZGl1cy5maWx0ZXJQcm9wcyA9IFsnYm9yZGVyUmFkaXVzJ107XG5jb25zdCBib3JkZXJzID0gY29tcG9zZShib3JkZXIsIGJvcmRlclRvcCwgYm9yZGVyUmlnaHQsIGJvcmRlckJvdHRvbSwgYm9yZGVyTGVmdCwgYm9yZGVyQ29sb3IsIGJvcmRlclRvcENvbG9yLCBib3JkZXJSaWdodENvbG9yLCBib3JkZXJCb3R0b21Db2xvciwgYm9yZGVyTGVmdENvbG9yLCBib3JkZXJSYWRpdXMsIG91dGxpbmUsIG91dGxpbmVDb2xvcik7XG5leHBvcnQgZGVmYXVsdCBib3JkZXJzOyIsImltcG9ydCBzdHlsZSBmcm9tIFwiLi4vc3R5bGUvaW5kZXgubWpzXCI7XG5pbXBvcnQgY29tcG9zZSBmcm9tIFwiLi4vY29tcG9zZS9pbmRleC5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZVVuYXJ5VW5pdCwgZ2V0VmFsdWUgfSBmcm9tIFwiLi4vc3BhY2luZy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGhhbmRsZUJyZWFrcG9pbnRzIH0gZnJvbSBcIi4uL2JyZWFrcG9pbnRzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHJlc3BvbnNpdmVQcm9wVHlwZSBmcm9tIFwiLi4vcmVzcG9uc2l2ZVByb3BUeXBlL2luZGV4Lm1qc1wiO1xuZXhwb3J0IGNvbnN0IGdhcCA9IHByb3BzID0+IHtcbiAgaWYgKHByb3BzLmdhcCAhPT0gdW5kZWZpbmVkICYmIHByb3BzLmdhcCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IHRyYW5zZm9ybWVyID0gY3JlYXRlVW5hcnlVbml0KHByb3BzLnRoZW1lLCAnc3BhY2luZycsIDgsICdnYXAnKTtcbiAgICBjb25zdCBzdHlsZUZyb21Qcm9wVmFsdWUgPSBwcm9wVmFsdWUgPT4gKHtcbiAgICAgIGdhcDogZ2V0VmFsdWUodHJhbnNmb3JtZXIsIHByb3BWYWx1ZSlcbiAgICB9KTtcbiAgICByZXR1cm4gaGFuZGxlQnJlYWtwb2ludHMocHJvcHMsIHByb3BzLmdhcCwgc3R5bGVGcm9tUHJvcFZhbHVlKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn07XG5nYXAucHJvcFR5cGVzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyA/IHtcbiAgZ2FwOiByZXNwb25zaXZlUHJvcFR5cGVcbn0gOiB7fTtcbmdhcC5maWx0ZXJQcm9wcyA9IFsnZ2FwJ107XG5leHBvcnQgY29uc3QgY29sdW1uR2FwID0gcHJvcHMgPT4ge1xuICBpZiAocHJvcHMuY29sdW1uR2FwICE9PSB1bmRlZmluZWQgJiYgcHJvcHMuY29sdW1uR2FwICE9PSBudWxsKSB7XG4gICAgY29uc3QgdHJhbnNmb3JtZXIgPSBjcmVhdGVVbmFyeVVuaXQocHJvcHMudGhlbWUsICdzcGFjaW5nJywgOCwgJ2NvbHVtbkdhcCcpO1xuICAgIGNvbnN0IHN0eWxlRnJvbVByb3BWYWx1ZSA9IHByb3BWYWx1ZSA9PiAoe1xuICAgICAgY29sdW1uR2FwOiBnZXRWYWx1ZSh0cmFuc2Zvcm1lciwgcHJvcFZhbHVlKVxuICAgIH0pO1xuICAgIHJldHVybiBoYW5kbGVCcmVha3BvaW50cyhwcm9wcywgcHJvcHMuY29sdW1uR2FwLCBzdHlsZUZyb21Qcm9wVmFsdWUpO1xuICB9XG4gIHJldHVybiBudWxsO1xufTtcbmNvbHVtbkdhcC5wcm9wVHlwZXMgPSBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nID8ge1xuICBjb2x1bW5HYXA6IHJlc3BvbnNpdmVQcm9wVHlwZVxufSA6IHt9O1xuY29sdW1uR2FwLmZpbHRlclByb3BzID0gWydjb2x1bW5HYXAnXTtcbmV4cG9ydCBjb25zdCByb3dHYXAgPSBwcm9wcyA9PiB7XG4gIGlmIChwcm9wcy5yb3dHYXAgIT09IHVuZGVmaW5lZCAmJiBwcm9wcy5yb3dHYXAgIT09IG51bGwpIHtcbiAgICBjb25zdCB0cmFuc2Zvcm1lciA9IGNyZWF0ZVVuYXJ5VW5pdChwcm9wcy50aGVtZSwgJ3NwYWNpbmcnLCA4LCAncm93R2FwJyk7XG4gICAgY29uc3Qgc3R5bGVGcm9tUHJvcFZhbHVlID0gcHJvcFZhbHVlID0+ICh7XG4gICAgICByb3dHYXA6IGdldFZhbHVlKHRyYW5zZm9ybWVyLCBwcm9wVmFsdWUpXG4gICAgfSk7XG4gICAgcmV0dXJuIGhhbmRsZUJyZWFrcG9pbnRzKHByb3BzLCBwcm9wcy5yb3dHYXAsIHN0eWxlRnJvbVByb3BWYWx1ZSk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59O1xucm93R2FwLnByb3BUeXBlcyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgPyB7XG4gIHJvd0dhcDogcmVzcG9uc2l2ZVByb3BUeXBlXG59IDoge307XG5yb3dHYXAuZmlsdGVyUHJvcHMgPSBbJ3Jvd0dhcCddO1xuZXhwb3J0IGNvbnN0IGdyaWRDb2x1bW4gPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkQ29sdW1uJ1xufSk7XG5leHBvcnQgY29uc3QgZ3JpZFJvdyA9IHN0eWxlKHtcbiAgcHJvcDogJ2dyaWRSb3cnXG59KTtcbmV4cG9ydCBjb25zdCBncmlkQXV0b0Zsb3cgPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkQXV0b0Zsb3cnXG59KTtcbmV4cG9ydCBjb25zdCBncmlkQXV0b0NvbHVtbnMgPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkQXV0b0NvbHVtbnMnXG59KTtcbmV4cG9ydCBjb25zdCBncmlkQXV0b1Jvd3MgPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkQXV0b1Jvd3MnXG59KTtcbmV4cG9ydCBjb25zdCBncmlkVGVtcGxhdGVDb2x1bW5zID0gc3R5bGUoe1xuICBwcm9wOiAnZ3JpZFRlbXBsYXRlQ29sdW1ucydcbn0pO1xuZXhwb3J0IGNvbnN0IGdyaWRUZW1wbGF0ZVJvd3MgPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkVGVtcGxhdGVSb3dzJ1xufSk7XG5leHBvcnQgY29uc3QgZ3JpZFRlbXBsYXRlQXJlYXMgPSBzdHlsZSh7XG4gIHByb3A6ICdncmlkVGVtcGxhdGVBcmVhcydcbn0pO1xuZXhwb3J0IGNvbnN0IGdyaWRBcmVhID0gc3R5bGUoe1xuICBwcm9wOiAnZ3JpZEFyZWEnXG59KTtcbmNvbnN0IGdyaWQgPSBjb21wb3NlKGdhcCwgY29sdW1uR2FwLCByb3dHYXAsIGdyaWRDb2x1bW4sIGdyaWRSb3csIGdyaWRBdXRvRmxvdywgZ3JpZEF1dG9Db2x1bW5zLCBncmlkQXV0b1Jvd3MsIGdyaWRUZW1wbGF0ZUNvbHVtbnMsIGdyaWRUZW1wbGF0ZVJvd3MsIGdyaWRUZW1wbGF0ZUFyZWFzLCBncmlkQXJlYSk7XG5leHBvcnQgZGVmYXVsdCBncmlkOyIsImltcG9ydCBzdHlsZSBmcm9tIFwiLi4vc3R5bGUvaW5kZXgubWpzXCI7XG5pbXBvcnQgY29tcG9zZSBmcm9tIFwiLi4vY29tcG9zZS9pbmRleC5tanNcIjtcblxuLyoqIEBpbnRlcm5hbCAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhbGV0dGVUcmFuc2Zvcm0odmFsdWUsIHVzZXJWYWx1ZSkge1xuICBpZiAodXNlclZhbHVlID09PSAnZ3JleScpIHtcbiAgICByZXR1cm4gdXNlclZhbHVlO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cbmV4cG9ydCBjb25zdCBjb2xvciA9IHN0eWxlKHtcbiAgcHJvcDogJ2NvbG9yJyxcbiAgdGhlbWVLZXk6ICdwYWxldHRlJyxcbiAgdHJhbnNmb3JtOiBwYWxldHRlVHJhbnNmb3JtXG59KTtcbmV4cG9ydCBjb25zdCBiZ2NvbG9yID0gc3R5bGUoe1xuICBwcm9wOiAnYmdjb2xvcicsXG4gIGNzc1Byb3BlcnR5OiAnYmFja2dyb3VuZENvbG9yJyxcbiAgdGhlbWVLZXk6ICdwYWxldHRlJyxcbiAgdHJhbnNmb3JtOiBwYWxldHRlVHJhbnNmb3JtXG59KTtcbmV4cG9ydCBjb25zdCBiYWNrZ3JvdW5kQ29sb3IgPSBzdHlsZSh7XG4gIHByb3A6ICdiYWNrZ3JvdW5kQ29sb3InLFxuICB0aGVtZUtleTogJ3BhbGV0dGUnLFxuICB0cmFuc2Zvcm06IHBhbGV0dGVUcmFuc2Zvcm1cbn0pO1xuY29uc3QgcGFsZXR0ZSA9IGNvbXBvc2UoY29sb3IsIGJnY29sb3IsIGJhY2tncm91bmRDb2xvcik7XG5leHBvcnQgZGVmYXVsdCBwYWxldHRlOyIsImltcG9ydCBzdHlsZSBmcm9tIFwiLi4vc3R5bGUvaW5kZXgubWpzXCI7XG5pbXBvcnQgY29tcG9zZSBmcm9tIFwiLi4vY29tcG9zZS9pbmRleC5tanNcIjtcbmltcG9ydCB7IGhhbmRsZUJyZWFrcG9pbnRzIH0gZnJvbSBcIi4uL2JyZWFrcG9pbnRzL2luZGV4Lm1qc1wiO1xuaW1wb3J0ICogYXMgYnJlYWtwb2ludHNNb2R1bGUgZnJvbSBcIi4uL2JyZWFrcG9pbnRzL2luZGV4Lm1qc1wiO1xuY29uc3QgYnJlYWtwb2ludHNWYWx1ZXMgPSBicmVha3BvaW50c01vZHVsZS52YWx1ZXM7XG5cbi8qKiBAaW50ZXJuYWwgKi9cbmV4cG9ydCBmdW5jdGlvbiBzaXppbmdUcmFuc2Zvcm0odmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIDw9IDEgJiYgdmFsdWUgIT09IDAgPyBgJHt2YWx1ZSAqIDEwMH0lYCA6IHZhbHVlO1xufVxuZXhwb3J0IGNvbnN0IHdpZHRoID0gc3R5bGUoe1xuICBwcm9wOiAnd2lkdGgnLFxuICB0cmFuc2Zvcm06IHNpemluZ1RyYW5zZm9ybVxufSk7XG5leHBvcnQgY29uc3QgbWF4V2lkdGggPSBwcm9wcyA9PiB7XG4gIGlmIChwcm9wcy5tYXhXaWR0aCAhPT0gdW5kZWZpbmVkICYmIHByb3BzLm1heFdpZHRoICE9PSBudWxsKSB7XG4gICAgY29uc3Qgc3R5bGVGcm9tUHJvcFZhbHVlID0gcHJvcFZhbHVlID0+IHtcbiAgICAgIGNvbnN0IGJyZWFrcG9pbnQgPSBwcm9wcy50aGVtZT8uYnJlYWtwb2ludHM/LnZhbHVlcz8uW3Byb3BWYWx1ZV0gfHwgYnJlYWtwb2ludHNWYWx1ZXNbcHJvcFZhbHVlXTtcbiAgICAgIGlmICghYnJlYWtwb2ludCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIG1heFdpZHRoOiBzaXppbmdUcmFuc2Zvcm0ocHJvcFZhbHVlKVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKHByb3BzLnRoZW1lPy5icmVha3BvaW50cz8udW5pdCAhPT0gJ3B4Jykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIG1heFdpZHRoOiBgJHticmVha3BvaW50fSR7cHJvcHMudGhlbWUuYnJlYWtwb2ludHMudW5pdH1gXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBtYXhXaWR0aDogYnJlYWtwb2ludFxuICAgICAgfTtcbiAgICB9O1xuICAgIHJldHVybiBoYW5kbGVCcmVha3BvaW50cyhwcm9wcywgcHJvcHMubWF4V2lkdGgsIHN0eWxlRnJvbVByb3BWYWx1ZSk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59O1xubWF4V2lkdGguZmlsdGVyUHJvcHMgPSBbJ21heFdpZHRoJ107XG5leHBvcnQgY29uc3QgbWluV2lkdGggPSBzdHlsZSh7XG4gIHByb3A6ICdtaW5XaWR0aCcsXG4gIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG59KTtcbmV4cG9ydCBjb25zdCBoZWlnaHQgPSBzdHlsZSh7XG4gIHByb3A6ICdoZWlnaHQnLFxuICB0cmFuc2Zvcm06IHNpemluZ1RyYW5zZm9ybVxufSk7XG5leHBvcnQgY29uc3QgbWF4SGVpZ2h0ID0gc3R5bGUoe1xuICBwcm9wOiAnbWF4SGVpZ2h0JyxcbiAgdHJhbnNmb3JtOiBzaXppbmdUcmFuc2Zvcm1cbn0pO1xuZXhwb3J0IGNvbnN0IG1pbkhlaWdodCA9IHN0eWxlKHtcbiAgcHJvcDogJ21pbkhlaWdodCcsXG4gIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG59KTtcbmV4cG9ydCBjb25zdCBzaXplV2lkdGggPSBzdHlsZSh7XG4gIHByb3A6ICdzaXplJyxcbiAgY3NzUHJvcGVydHk6ICd3aWR0aCcsXG4gIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG59KTtcbmV4cG9ydCBjb25zdCBzaXplSGVpZ2h0ID0gc3R5bGUoe1xuICBwcm9wOiAnc2l6ZScsXG4gIGNzc1Byb3BlcnR5OiAnaGVpZ2h0JyxcbiAgdHJhbnNmb3JtOiBzaXppbmdUcmFuc2Zvcm1cbn0pO1xuZXhwb3J0IGNvbnN0IGJveFNpemluZyA9IHN0eWxlKHtcbiAgcHJvcDogJ2JveFNpemluZydcbn0pO1xuY29uc3Qgc2l6aW5nID0gY29tcG9zZSh3aWR0aCwgbWF4V2lkdGgsIG1pbldpZHRoLCBoZWlnaHQsIG1heEhlaWdodCwgbWluSGVpZ2h0LCBib3hTaXppbmcpO1xuZXhwb3J0IGRlZmF1bHQgc2l6aW5nOyIsImltcG9ydCB7IHBhZGRpbmcsIG1hcmdpbiB9IGZyb20gXCIuLi9zcGFjaW5nL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgYm9yZGVyUmFkaXVzLCBib3JkZXJUcmFuc2Zvcm0gfSBmcm9tIFwiLi4vYm9yZGVycy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGdhcCwgcm93R2FwLCBjb2x1bW5HYXAgfSBmcm9tIFwiLi4vY3NzR3JpZC9pbmRleC5tanNcIjtcbmltcG9ydCB7IHBhbGV0dGVUcmFuc2Zvcm0gfSBmcm9tIFwiLi4vcGFsZXR0ZS9pbmRleC5tanNcIjtcbmltcG9ydCB7IG1heFdpZHRoLCBzaXppbmdUcmFuc2Zvcm0gfSBmcm9tIFwiLi4vc2l6aW5nL2luZGV4Lm1qc1wiO1xuY29uc3QgZGVmYXVsdFN4Q29uZmlnID0ge1xuICAvLyBib3JkZXJzXG4gIGJvcmRlcjoge1xuICAgIHRoZW1lS2V5OiAnYm9yZGVycycsXG4gICAgdHJhbnNmb3JtOiBib3JkZXJUcmFuc2Zvcm1cbiAgfSxcbiAgYm9yZGVyVG9wOiB7XG4gICAgdGhlbWVLZXk6ICdib3JkZXJzJyxcbiAgICB0cmFuc2Zvcm06IGJvcmRlclRyYW5zZm9ybVxuICB9LFxuICBib3JkZXJSaWdodDoge1xuICAgIHRoZW1lS2V5OiAnYm9yZGVycycsXG4gICAgdHJhbnNmb3JtOiBib3JkZXJUcmFuc2Zvcm1cbiAgfSxcbiAgYm9yZGVyQm90dG9tOiB7XG4gICAgdGhlbWVLZXk6ICdib3JkZXJzJyxcbiAgICB0cmFuc2Zvcm06IGJvcmRlclRyYW5zZm9ybVxuICB9LFxuICBib3JkZXJMZWZ0OiB7XG4gICAgdGhlbWVLZXk6ICdib3JkZXJzJyxcbiAgICB0cmFuc2Zvcm06IGJvcmRlclRyYW5zZm9ybVxuICB9LFxuICBib3JkZXJDb2xvcjoge1xuICAgIHRoZW1lS2V5OiAncGFsZXR0ZSdcbiAgfSxcbiAgYm9yZGVyVG9wQ29sb3I6IHtcbiAgICB0aGVtZUtleTogJ3BhbGV0dGUnXG4gIH0sXG4gIGJvcmRlclJpZ2h0Q29sb3I6IHtcbiAgICB0aGVtZUtleTogJ3BhbGV0dGUnXG4gIH0sXG4gIGJvcmRlckJvdHRvbUNvbG9yOiB7XG4gICAgdGhlbWVLZXk6ICdwYWxldHRlJ1xuICB9LFxuICBib3JkZXJMZWZ0Q29sb3I6IHtcbiAgICB0aGVtZUtleTogJ3BhbGV0dGUnXG4gIH0sXG4gIG91dGxpbmU6IHtcbiAgICB0aGVtZUtleTogJ2JvcmRlcnMnLFxuICAgIHRyYW5zZm9ybTogYm9yZGVyVHJhbnNmb3JtXG4gIH0sXG4gIG91dGxpbmVDb2xvcjoge1xuICAgIHRoZW1lS2V5OiAncGFsZXR0ZSdcbiAgfSxcbiAgYm9yZGVyUmFkaXVzOiB7XG4gICAgdGhlbWVLZXk6ICdzaGFwZS5ib3JkZXJSYWRpdXMnLFxuICAgIHN0eWxlOiBib3JkZXJSYWRpdXNcbiAgfSxcbiAgLy8gcGFsZXR0ZVxuICBjb2xvcjoge1xuICAgIHRoZW1lS2V5OiAncGFsZXR0ZScsXG4gICAgdHJhbnNmb3JtOiBwYWxldHRlVHJhbnNmb3JtXG4gIH0sXG4gIGJnY29sb3I6IHtcbiAgICB0aGVtZUtleTogJ3BhbGV0dGUnLFxuICAgIGNzc1Byb3BlcnR5OiAnYmFja2dyb3VuZENvbG9yJyxcbiAgICB0cmFuc2Zvcm06IHBhbGV0dGVUcmFuc2Zvcm1cbiAgfSxcbiAgYmFja2dyb3VuZENvbG9yOiB7XG4gICAgdGhlbWVLZXk6ICdwYWxldHRlJyxcbiAgICB0cmFuc2Zvcm06IHBhbGV0dGVUcmFuc2Zvcm1cbiAgfSxcbiAgLy8gc3BhY2luZ1xuICBwOiB7XG4gICAgc3R5bGU6IHBhZGRpbmdcbiAgfSxcbiAgcHQ6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwcjoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBiOiB7XG4gICAgc3R5bGU6IHBhZGRpbmdcbiAgfSxcbiAgcGw6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBweDoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHB5OiB7XG4gICAgc3R5bGU6IHBhZGRpbmdcbiAgfSxcbiAgcGFkZGluZzoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBhZGRpbmdUb3A6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwYWRkaW5nUmlnaHQ6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwYWRkaW5nQm90dG9tOiB7XG4gICAgc3R5bGU6IHBhZGRpbmdcbiAgfSxcbiAgcGFkZGluZ0xlZnQ6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwYWRkaW5nWDoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBhZGRpbmdZOiB7XG4gICAgc3R5bGU6IHBhZGRpbmdcbiAgfSxcbiAgcGFkZGluZ0lubGluZToge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBhZGRpbmdJbmxpbmVTdGFydDoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBhZGRpbmdJbmxpbmVFbmQ6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwYWRkaW5nQmxvY2s6IHtcbiAgICBzdHlsZTogcGFkZGluZ1xuICB9LFxuICBwYWRkaW5nQmxvY2tTdGFydDoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIHBhZGRpbmdCbG9ja0VuZDoge1xuICAgIHN0eWxlOiBwYWRkaW5nXG4gIH0sXG4gIG06IHtcbiAgICBzdHlsZTogbWFyZ2luXG4gIH0sXG4gIG10OiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtcjoge1xuICAgIHN0eWxlOiBtYXJnaW5cbiAgfSxcbiAgbWI6IHtcbiAgICBzdHlsZTogbWFyZ2luXG4gIH0sXG4gIG1sOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBteDoge1xuICAgIHN0eWxlOiBtYXJnaW5cbiAgfSxcbiAgbXk6IHtcbiAgICBzdHlsZTogbWFyZ2luXG4gIH0sXG4gIG1hcmdpbjoge1xuICAgIHN0eWxlOiBtYXJnaW5cbiAgfSxcbiAgbWFyZ2luVG9wOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5SaWdodDoge1xuICAgIHN0eWxlOiBtYXJnaW5cbiAgfSxcbiAgbWFyZ2luQm90dG9tOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5MZWZ0OiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5YOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5ZOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5JbmxpbmU6IHtcbiAgICBzdHlsZTogbWFyZ2luXG4gIH0sXG4gIG1hcmdpbklubGluZVN0YXJ0OiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5JbmxpbmVFbmQ6IHtcbiAgICBzdHlsZTogbWFyZ2luXG4gIH0sXG4gIG1hcmdpbkJsb2NrOiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5CbG9ja1N0YXJ0OiB7XG4gICAgc3R5bGU6IG1hcmdpblxuICB9LFxuICBtYXJnaW5CbG9ja0VuZDoge1xuICAgIHN0eWxlOiBtYXJnaW5cbiAgfSxcbiAgLy8gZGlzcGxheVxuICBkaXNwbGF5UHJpbnQ6IHtcbiAgICBjc3NQcm9wZXJ0eTogZmFsc2UsXG4gICAgdHJhbnNmb3JtOiB2YWx1ZSA9PiAoe1xuICAgICAgJ0BtZWRpYSBwcmludCc6IHtcbiAgICAgICAgZGlzcGxheTogdmFsdWVcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBkaXNwbGF5OiB7fSxcbiAgb3ZlcmZsb3c6IHt9LFxuICB0ZXh0T3ZlcmZsb3c6IHt9LFxuICB2aXNpYmlsaXR5OiB7fSxcbiAgd2hpdGVTcGFjZToge30sXG4gIC8vIGZsZXhib3hcbiAgZmxleEJhc2lzOiB7fSxcbiAgZmxleERpcmVjdGlvbjoge30sXG4gIGZsZXhXcmFwOiB7fSxcbiAganVzdGlmeUNvbnRlbnQ6IHt9LFxuICBhbGlnbkl0ZW1zOiB7fSxcbiAgYWxpZ25Db250ZW50OiB7fSxcbiAgb3JkZXI6IHt9LFxuICBmbGV4OiB7fSxcbiAgZmxleEdyb3c6IHt9LFxuICBmbGV4U2hyaW5rOiB7fSxcbiAgYWxpZ25TZWxmOiB7fSxcbiAganVzdGlmeUl0ZW1zOiB7fSxcbiAganVzdGlmeVNlbGY6IHt9LFxuICAvLyBncmlkXG4gIGdhcDoge1xuICAgIHN0eWxlOiBnYXBcbiAgfSxcbiAgcm93R2FwOiB7XG4gICAgc3R5bGU6IHJvd0dhcFxuICB9LFxuICBjb2x1bW5HYXA6IHtcbiAgICBzdHlsZTogY29sdW1uR2FwXG4gIH0sXG4gIGdyaWRDb2x1bW46IHt9LFxuICBncmlkUm93OiB7fSxcbiAgZ3JpZEF1dG9GbG93OiB7fSxcbiAgZ3JpZEF1dG9Db2x1bW5zOiB7fSxcbiAgZ3JpZEF1dG9Sb3dzOiB7fSxcbiAgZ3JpZFRlbXBsYXRlQ29sdW1uczoge30sXG4gIGdyaWRUZW1wbGF0ZVJvd3M6IHt9LFxuICBncmlkVGVtcGxhdGVBcmVhczoge30sXG4gIGdyaWRBcmVhOiB7fSxcbiAgLy8gcG9zaXRpb25zXG4gIHBvc2l0aW9uOiB7fSxcbiAgekluZGV4OiB7XG4gICAgdGhlbWVLZXk6ICd6SW5kZXgnXG4gIH0sXG4gIHRvcDoge30sXG4gIHJpZ2h0OiB7fSxcbiAgYm90dG9tOiB7fSxcbiAgbGVmdDoge30sXG4gIC8vIHNoYWRvd3NcbiAgYm94U2hhZG93OiB7XG4gICAgdGhlbWVLZXk6ICdzaGFkb3dzJ1xuICB9LFxuICAvLyBzaXppbmdcbiAgd2lkdGg6IHtcbiAgICB0cmFuc2Zvcm06IHNpemluZ1RyYW5zZm9ybVxuICB9LFxuICBtYXhXaWR0aDoge1xuICAgIHN0eWxlOiBtYXhXaWR0aFxuICB9LFxuICBtaW5XaWR0aDoge1xuICAgIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG4gIH0sXG4gIGhlaWdodDoge1xuICAgIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG4gIH0sXG4gIG1heEhlaWdodDoge1xuICAgIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG4gIH0sXG4gIG1pbkhlaWdodDoge1xuICAgIHRyYW5zZm9ybTogc2l6aW5nVHJhbnNmb3JtXG4gIH0sXG4gIGJveFNpemluZzoge30sXG4gIC8vIHR5cG9ncmFwaHlcbiAgZm9udDoge1xuICAgIHRoZW1lS2V5OiAnZm9udCdcbiAgfSxcbiAgZm9udEZhbWlseToge1xuICAgIHRoZW1lS2V5OiAndHlwb2dyYXBoeSdcbiAgfSxcbiAgZm9udFNpemU6IHtcbiAgICB0aGVtZUtleTogJ3R5cG9ncmFwaHknXG4gIH0sXG4gIGZvbnRTdHlsZToge1xuICAgIHRoZW1lS2V5OiAndHlwb2dyYXBoeSdcbiAgfSxcbiAgZm9udFdlaWdodDoge1xuICAgIHRoZW1lS2V5OiAndHlwb2dyYXBoeSdcbiAgfSxcbiAgbGV0dGVyU3BhY2luZzoge30sXG4gIHRleHRUcmFuc2Zvcm06IHt9LFxuICBsaW5lSGVpZ2h0OiB7fSxcbiAgdGV4dEFsaWduOiB7fSxcbiAgdHlwb2dyYXBoeToge1xuICAgIGNzc1Byb3BlcnR5OiBmYWxzZSxcbiAgICB0aGVtZUtleTogJ3R5cG9ncmFwaHknXG4gIH1cbn07XG5leHBvcnQgZGVmYXVsdCBkZWZhdWx0U3hDb25maWc7IiwiaW1wb3J0IG1lcmdlIGZyb20gJ0BtdWkvdXRpbHMvZmFzdERlZXBBc3NpZ24nO1xuaW1wb3J0IHsgZ2V0UGF0aCwgZ2V0U3R5bGVWYWx1ZTIgfSBmcm9tIFwiLi4vc3R5bGUvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBoYXNCcmVha3BvaW50LCBpdGVyYXRlQnJlYWtwb2ludHMsIGNyZWF0ZUVtcHR5QnJlYWtwb2ludE9iamVjdCwgcmVtb3ZlVW51c2VkQnJlYWtwb2ludHMsIERFRkFVTFRfQlJFQUtQT0lOVFMgfSBmcm9tIFwiLi4vYnJlYWtwb2ludHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBzb3J0Q29udGFpbmVyUXVlcmllcyB9IGZyb20gXCIuLi9jc3NDb250YWluZXJRdWVyaWVzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IGRlZmF1bHRTeENvbmZpZyBmcm9tIFwiLi9kZWZhdWx0U3hDb25maWcubWpzXCI7XG5cbi8qIGVzbGludC1kaXNhYmxlIGd1YXJkLWZvci1pbiAqL1xuXG5jb25zdCBFTVBUWV9USEVNRSA9IHt9O1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25hbWluZy1jb252ZW50aW9uXG5leHBvcnQgZnVuY3Rpb24gdW5zdGFibGVfY3JlYXRlU3R5bGVGdW5jdGlvblN4KCkge1xuICBmdW5jdGlvbiBzdHlsZUZ1bmN0aW9uU3gocHJvcHMpIHtcbiAgICBpZiAoIXByb3BzLnN4KSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3Qge1xuICAgICAgc3gsXG4gICAgICB0aGVtZSA9IEVNUFRZX1RIRU1FLFxuICAgICAgbmVzdGVkXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbmZpZyA9IHRoZW1lLnVuc3RhYmxlX3N4Q29uZmlnID8/IGRlZmF1bHRTeENvbmZpZztcblxuICAgIC8vIFBhc3MgYXJndW1lbnQgd2l0aG91dCBsb29wIGFsbG9jYXRpb25zXG4gICAgY29uc3Qgd3JhcHBlciA9IHtcbiAgICAgIHN4OiBudWxsLFxuICAgICAgdGhlbWUsXG4gICAgICBuZXN0ZWQ6IHRydWVcbiAgICB9O1xuICAgIGZ1bmN0aW9uIHByb2Nlc3Moc3hJbnB1dCkge1xuICAgICAgbGV0IHN4T2JqZWN0ID0gc3hJbnB1dDtcbiAgICAgIGlmICh0eXBlb2Ygc3hJbnB1dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBzeE9iamVjdCA9IHN4SW5wdXQodGhlbWUpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygc3hJbnB1dCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgLy8gdmFsdWVcbiAgICAgICAgcmV0dXJuIHN4SW5wdXQ7XG4gICAgICB9XG4gICAgICBpZiAoIXN4T2JqZWN0KSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgYnJlYWtwb2ludHMgPSB0aGVtZS5icmVha3BvaW50cyA/PyBERUZBVUxUX0JSRUFLUE9JTlRTO1xuICAgICAgY29uc3QgY3NzID0gY3JlYXRlRW1wdHlCcmVha3BvaW50T2JqZWN0KGJyZWFrcG9pbnRzKTtcbiAgICAgIGZvciAoY29uc3Qgc3R5bGVLZXkgaW4gc3hPYmplY3QpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBjYWxsSWZGbihzeE9iamVjdFtzdHlsZUtleV0sIHRoZW1lKTtcbiAgICAgICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgIHNldFRoZW1lVmFsdWUoY3NzLCBzdHlsZUtleSwgdmFsdWUsIHRoZW1lLCBjb25maWcpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb25maWdbc3R5bGVLZXldKSB7XG4gICAgICAgICAgc2V0VGhlbWVWYWx1ZShjc3MsIHN0eWxlS2V5LCB2YWx1ZSwgdGhlbWUsIGNvbmZpZyk7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhhc0JyZWFrcG9pbnQoYnJlYWtwb2ludHMsIHZhbHVlKSkge1xuICAgICAgICAgIGl0ZXJhdGVCcmVha3BvaW50cyhjc3MsIHByb3BzLnRoZW1lLCB2YWx1ZSwgKG1lZGlhS2V5LCBmaW5hbFZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjc3NbbWVkaWFLZXldW3N0eWxlS2V5XSA9IGZpbmFsVmFsdWU7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgd3JhcHBlci5zeCA9IHZhbHVlO1xuICAgICAgICAgIGNzc1tzdHlsZUtleV0gPSBzdHlsZUZ1bmN0aW9uU3god3JhcHBlcik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghbmVzdGVkICYmIHRoZW1lLm1vZHVsYXJDc3NMYXllcnMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAnQGxheWVyIHN4Jzogc29ydENvbnRhaW5lclF1ZXJpZXModGhlbWUsIHJlbW92ZVVudXNlZEJyZWFrcG9pbnRzKGJyZWFrcG9pbnRzLCBjc3MpKVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNvcnRDb250YWluZXJRdWVyaWVzKHRoZW1lLCByZW1vdmVVbnVzZWRCcmVha3BvaW50cyhicmVha3BvaW50cywgY3NzKSk7XG4gICAgfVxuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHN4KSA/IHN4Lm1hcChwcm9jZXNzKSA6IHByb2Nlc3Moc3gpO1xuICB9XG4gIHN0eWxlRnVuY3Rpb25TeC5maWx0ZXJQcm9wcyA9IFsnc3gnXTtcbiAgcmV0dXJuIHN0eWxlRnVuY3Rpb25TeDtcbn1cbmV4cG9ydCBkZWZhdWx0IHVuc3RhYmxlX2NyZWF0ZVN0eWxlRnVuY3Rpb25TeCgpO1xuZnVuY3Rpb24gc2V0VGhlbWVWYWx1ZShjc3MsIHByb3AsIHZhbHVlLCB0aGVtZSwgY29uZmlnKSB7XG4gIGNvbnN0IG9wdGlvbnMgPSBjb25maWdbcHJvcF07XG4gIGlmICghb3B0aW9ucykge1xuICAgIGNzc1twcm9wXSA9IHZhbHVlO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB7XG4gICAgdGhlbWVLZXlcbiAgfSA9IG9wdGlvbnM7XG4gIC8vIFRPRE8gdjY6IHJlbW92ZSwgc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvbWF0ZXJpYWwtdWkvcHVsbC8zODEyM1xuICBpZiAodGhlbWVLZXkgPT09ICd0eXBvZ3JhcGh5JyAmJiB2YWx1ZSA9PT0gJ2luaGVyaXQnKSB7XG4gICAgY3NzW3Byb3BdID0gdmFsdWU7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHtcbiAgICBzdHlsZVxuICB9ID0gb3B0aW9ucztcbiAgaWYgKHN0eWxlKSB7XG4gICAgbWVyZ2UoY3NzLCBzdHlsZSh7XG4gICAgICBbcHJvcF06IHZhbHVlLFxuICAgICAgdGhlbWVcbiAgICB9KSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHtcbiAgICBjc3NQcm9wZXJ0eSA9IHByb3AsXG4gICAgdHJhbnNmb3JtXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB0aGVtZU1hcHBpbmcgPSBnZXRQYXRoKHRoZW1lLCB0aGVtZUtleSk7XG4gIGl0ZXJhdGVCcmVha3BvaW50cyhjc3MsIHRoZW1lLCB2YWx1ZSwgKG1lZGlhS2V5LCB2YWx1ZUZpbmFsKSA9PiB7XG4gICAgY29uc3QgZmluYWxWYWx1ZSA9IGdldFN0eWxlVmFsdWUyKHRoZW1lTWFwcGluZywgdHJhbnNmb3JtLCB2YWx1ZUZpbmFsLCBwcm9wKTtcbiAgICBpZiAoY3NzUHJvcGVydHkgPT09IGZhbHNlKSB7XG4gICAgICBpZiAobWVkaWFLZXkpIHtcbiAgICAgICAgbWVyZ2UoY3NzW21lZGlhS2V5XSwgZmluYWxWYWx1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBtZXJnZShjc3MsIGZpbmFsVmFsdWUpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbG9uZWx5LWlmXG4gICAgICBpZiAobWVkaWFLZXkpIHtcbiAgICAgICAgY3NzW21lZGlhS2V5XVtjc3NQcm9wZXJ0eV0gPSBmaW5hbFZhbHVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY3NzW2Nzc1Byb3BlcnR5XSA9IGZpbmFsVmFsdWU7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGNhbGxJZkZuKG1heWJlRm4sIGFyZykge1xuICByZXR1cm4gdHlwZW9mIG1heWJlRm4gPT09ICdmdW5jdGlvbicgPyBtYXliZUZuKGFyZykgOiBtYXliZUZuO1xufSIsInZhciBpc0RldmVsb3BtZW50ID0gdHJ1ZTtcblxuLypcblxuQmFzZWQgb2ZmIGdsYW1vcidzIFN0eWxlU2hlZXQsIHRoYW5rcyBTdW5pbCDinaTvuI9cblxuaGlnaCBwZXJmb3JtYW5jZSBTdHlsZVNoZWV0IGZvciBjc3MtaW4tanMgc3lzdGVtc1xuXG4tIHVzZXMgbXVsdGlwbGUgc3R5bGUgdGFncyBiZWhpbmQgdGhlIHNjZW5lcyBmb3IgbWlsbGlvbnMgb2YgcnVsZXNcbi0gdXNlcyBgaW5zZXJ0UnVsZWAgZm9yIGFwcGVuZGluZyBpbiBwcm9kdWN0aW9uIGZvciAqbXVjaCogZmFzdGVyIHBlcmZvcm1hbmNlXG5cbi8vIHVzYWdlXG5cbmltcG9ydCB7IFN0eWxlU2hlZXQgfSBmcm9tICdAZW1vdGlvbi9zaGVldCdcblxubGV0IHN0eWxlU2hlZXQgPSBuZXcgU3R5bGVTaGVldCh7IGtleTogJycsIGNvbnRhaW5lcjogZG9jdW1lbnQuaGVhZCB9KVxuXG5zdHlsZVNoZWV0Lmluc2VydCgnI2JveCB7IGJvcmRlcjogMXB4IHNvbGlkIHJlZDsgfScpXG4tIGFwcGVuZHMgYSBjc3MgcnVsZSBpbnRvIHRoZSBzdHlsZXNoZWV0XG5cbnN0eWxlU2hlZXQuZmx1c2goKVxuLSBlbXB0aWVzIHRoZSBzdHlsZXNoZWV0IG9mIGFsbCBpdHMgY29udGVudHNcblxuKi9cblxuZnVuY3Rpb24gc2hlZXRGb3JUYWcodGFnKSB7XG4gIGlmICh0YWcuc2hlZXQpIHtcbiAgICByZXR1cm4gdGFnLnNoZWV0O1xuICB9IC8vIHRoaXMgd2VpcmRuZXNzIGJyb3VnaHQgdG8geW91IGJ5IGZpcmVmb3hcblxuICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuXG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBkb2N1bWVudC5zdHlsZVNoZWV0cy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChkb2N1bWVudC5zdHlsZVNoZWV0c1tpXS5vd25lck5vZGUgPT09IHRhZykge1xuICAgICAgcmV0dXJuIGRvY3VtZW50LnN0eWxlU2hlZXRzW2ldO1xuICAgIH1cbiAgfSAvLyB0aGlzIGZ1bmN0aW9uIHNob3VsZCBhbHdheXMgcmV0dXJuIHdpdGggYSB2YWx1ZVxuICAvLyBUUyBjYW4ndCB1bmRlcnN0YW5kIGl0IHRob3VnaCBzbyB3ZSBtYWtlIGl0IHN0b3AgY29tcGxhaW5pbmcgaGVyZVxuXG5cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuZnVuY3Rpb24gY3JlYXRlU3R5bGVFbGVtZW50KG9wdGlvbnMpIHtcbiAgdmFyIHRhZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gIHRhZy5zZXRBdHRyaWJ1dGUoJ2RhdGEtZW1vdGlvbicsIG9wdGlvbnMua2V5KTtcblxuICBpZiAob3B0aW9ucy5ub25jZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgdGFnLnNldEF0dHJpYnV0ZSgnbm9uY2UnLCBvcHRpb25zLm5vbmNlKTtcbiAgfVxuXG4gIHRhZy5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnJykpO1xuICB0YWcuc2V0QXR0cmlidXRlKCdkYXRhLXMnLCAnJyk7XG4gIHJldHVybiB0YWc7XG59XG5cbnZhciBTdHlsZVNoZWV0ID0gLyojX19QVVJFX18qL2Z1bmN0aW9uICgpIHtcbiAgLy8gVXNpbmcgTm9kZSBpbnN0ZWFkIG9mIEhUTUxFbGVtZW50IHNpbmNlIGNvbnRhaW5lciBtYXkgYmUgYSBTaGFkb3dSb290XG4gIGZ1bmN0aW9uIFN0eWxlU2hlZXQob3B0aW9ucykge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICB0aGlzLl9pbnNlcnRUYWcgPSBmdW5jdGlvbiAodGFnKSB7XG4gICAgICB2YXIgYmVmb3JlO1xuXG4gICAgICBpZiAoX3RoaXMudGFncy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgaWYgKF90aGlzLmluc2VydGlvblBvaW50KSB7XG4gICAgICAgICAgYmVmb3JlID0gX3RoaXMuaW5zZXJ0aW9uUG9pbnQubmV4dFNpYmxpbmc7XG4gICAgICAgIH0gZWxzZSBpZiAoX3RoaXMucHJlcGVuZCkge1xuICAgICAgICAgIGJlZm9yZSA9IF90aGlzLmNvbnRhaW5lci5maXJzdENoaWxkO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJlZm9yZSA9IF90aGlzLmJlZm9yZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYmVmb3JlID0gX3RoaXMudGFnc1tfdGhpcy50YWdzLmxlbmd0aCAtIDFdLm5leHRTaWJsaW5nO1xuICAgICAgfVxuXG4gICAgICBfdGhpcy5jb250YWluZXIuaW5zZXJ0QmVmb3JlKHRhZywgYmVmb3JlKTtcblxuICAgICAgX3RoaXMudGFncy5wdXNoKHRhZyk7XG4gICAgfTtcblxuICAgIHRoaXMuaXNTcGVlZHkgPSBvcHRpb25zLnNwZWVkeSA9PT0gdW5kZWZpbmVkID8gIWlzRGV2ZWxvcG1lbnQgOiBvcHRpb25zLnNwZWVkeTtcbiAgICB0aGlzLnRhZ3MgPSBbXTtcbiAgICB0aGlzLmN0ciA9IDA7XG4gICAgdGhpcy5ub25jZSA9IG9wdGlvbnMubm9uY2U7IC8vIGtleSBpcyB0aGUgdmFsdWUgb2YgdGhlIGRhdGEtZW1vdGlvbiBhdHRyaWJ1dGUsIGl0J3MgdXNlZCB0byBpZGVudGlmeSBkaWZmZXJlbnQgc2hlZXRzXG5cbiAgICB0aGlzLmtleSA9IG9wdGlvbnMua2V5O1xuICAgIHRoaXMuY29udGFpbmVyID0gb3B0aW9ucy5jb250YWluZXI7XG4gICAgdGhpcy5wcmVwZW5kID0gb3B0aW9ucy5wcmVwZW5kO1xuICAgIHRoaXMuaW5zZXJ0aW9uUG9pbnQgPSBvcHRpb25zLmluc2VydGlvblBvaW50O1xuICAgIHRoaXMuYmVmb3JlID0gbnVsbDtcbiAgfVxuXG4gIHZhciBfcHJvdG8gPSBTdHlsZVNoZWV0LnByb3RvdHlwZTtcblxuICBfcHJvdG8uaHlkcmF0ZSA9IGZ1bmN0aW9uIGh5ZHJhdGUobm9kZXMpIHtcbiAgICBub2Rlcy5mb3JFYWNoKHRoaXMuX2luc2VydFRhZyk7XG4gIH07XG5cbiAgX3Byb3RvLmluc2VydCA9IGZ1bmN0aW9uIGluc2VydChydWxlKSB7XG4gICAgLy8gdGhlIG1heCBsZW5ndGggaXMgaG93IG1hbnkgcnVsZXMgd2UgaGF2ZSBwZXIgc3R5bGUgdGFnLCBpdCdzIDY1MDAwIGluIHNwZWVkeSBtb2RlXG4gICAgLy8gaXQncyAxIGluIGRldiBiZWNhdXNlIHdlIGluc2VydCBzb3VyY2UgbWFwcyB0aGF0IG1hcCBhIHNpbmdsZSBydWxlIHRvIGEgbG9jYXRpb25cbiAgICAvLyBhbmQgeW91IGNhbiBvbmx5IGhhdmUgb25lIHNvdXJjZSBtYXAgcGVyIHN0eWxlIHRhZ1xuICAgIGlmICh0aGlzLmN0ciAlICh0aGlzLmlzU3BlZWR5ID8gNjUwMDAgOiAxKSA9PT0gMCkge1xuICAgICAgdGhpcy5faW5zZXJ0VGFnKGNyZWF0ZVN0eWxlRWxlbWVudCh0aGlzKSk7XG4gICAgfVxuXG4gICAgdmFyIHRhZyA9IHRoaXMudGFnc1t0aGlzLnRhZ3MubGVuZ3RoIC0gMV07XG5cbiAgICB7XG4gICAgICB2YXIgaXNJbXBvcnRSdWxlID0gcnVsZS5jaGFyQ29kZUF0KDApID09PSA2NCAmJiBydWxlLmNoYXJDb2RlQXQoMSkgPT09IDEwNTtcblxuICAgICAgaWYgKGlzSW1wb3J0UnVsZSAmJiB0aGlzLl9hbHJlYWR5SW5zZXJ0ZWRPcmRlckluc2Vuc2l0aXZlUnVsZSkge1xuICAgICAgICAvLyB0aGlzIHdvdWxkIG9ubHkgY2F1c2UgcHJvYmxlbSBpbiBzcGVlZHkgbW9kZVxuICAgICAgICAvLyBidXQgd2UgZG9uJ3Qgd2FudCBlbmFibGluZyBzcGVlZHkgdG8gYWZmZWN0IHRoZSBvYnNlcnZhYmxlIGJlaGF2aW9yXG4gICAgICAgIC8vIHNvIHdlIHJlcG9ydCB0aGlzIGVycm9yIGF0IGFsbCB0aW1lc1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiWW91J3JlIGF0dGVtcHRpbmcgdG8gaW5zZXJ0IHRoZSBmb2xsb3dpbmcgcnVsZTpcXG5cIiArIHJ1bGUgKyAnXFxuXFxuYEBpbXBvcnRgIHJ1bGVzIG11c3QgYmUgYmVmb3JlIGFsbCBvdGhlciB0eXBlcyBvZiBydWxlcyBpbiBhIHN0eWxlc2hlZXQgYnV0IG90aGVyIHJ1bGVzIGhhdmUgYWxyZWFkeSBiZWVuIGluc2VydGVkLiBQbGVhc2UgZW5zdXJlIHRoYXQgYEBpbXBvcnRgIHJ1bGVzIGFyZSBiZWZvcmUgYWxsIG90aGVyIHJ1bGVzLicpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLl9hbHJlYWR5SW5zZXJ0ZWRPcmRlckluc2Vuc2l0aXZlUnVsZSA9IHRoaXMuX2FscmVhZHlJbnNlcnRlZE9yZGVySW5zZW5zaXRpdmVSdWxlIHx8ICFpc0ltcG9ydFJ1bGU7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaXNTcGVlZHkpIHtcbiAgICAgIHZhciBzaGVldCA9IHNoZWV0Rm9yVGFnKHRhZyk7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIHRoaXMgaXMgdGhlIHVsdHJhZmFzdCB2ZXJzaW9uLCB3b3JrcyBhY3Jvc3MgYnJvd3NlcnNcbiAgICAgICAgLy8gdGhlIGJpZyBkcmF3YmFjayBpcyB0aGF0IHRoZSBjc3Mgd29uJ3QgYmUgZWRpdGFibGUgaW4gZGV2dG9vbHNcbiAgICAgICAgc2hlZXQuaW5zZXJ0UnVsZShydWxlLCBzaGVldC5jc3NSdWxlcy5sZW5ndGgpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAoIS86KC1tb3otcGxhY2Vob2xkZXJ8LW1vei1mb2N1cy1pbm5lcnwtbW96LWZvY3VzcmluZ3wtbXMtaW5wdXQtcGxhY2Vob2xkZXJ8LW1vei1yZWFkLXdyaXRlfC1tb3otcmVhZC1vbmx5fC1tcy1jbGVhcnwtbXMtZXhwYW5kfC1tcy1yZXZlYWwpey8udGVzdChydWxlKSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJUaGVyZSB3YXMgYSBwcm9ibGVtIGluc2VydGluZyB0aGUgZm9sbG93aW5nIHJ1bGU6IFxcXCJcIiArIHJ1bGUgKyBcIlxcXCJcIiwgZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGFnLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKHJ1bGUpKTtcbiAgICB9XG5cbiAgICB0aGlzLmN0cisrO1xuICB9O1xuXG4gIF9wcm90by5mbHVzaCA9IGZ1bmN0aW9uIGZsdXNoKCkge1xuICAgIHRoaXMudGFncy5mb3JFYWNoKGZ1bmN0aW9uICh0YWcpIHtcbiAgICAgIHZhciBfdGFnJHBhcmVudE5vZGU7XG5cbiAgICAgIHJldHVybiAoX3RhZyRwYXJlbnROb2RlID0gdGFnLnBhcmVudE5vZGUpID09IG51bGwgPyB2b2lkIDAgOiBfdGFnJHBhcmVudE5vZGUucmVtb3ZlQ2hpbGQodGFnKTtcbiAgICB9KTtcbiAgICB0aGlzLnRhZ3MgPSBbXTtcbiAgICB0aGlzLmN0ciA9IDA7XG5cbiAgICB7XG4gICAgICB0aGlzLl9hbHJlYWR5SW5zZXJ0ZWRPcmRlckluc2Vuc2l0aXZlUnVsZSA9IGZhbHNlO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gU3R5bGVTaGVldDtcbn0oKTtcblxuZXhwb3J0IHsgU3R5bGVTaGVldCB9O1xuIiwiZXhwb3J0IHZhciBNUyA9ICctbXMtJ1xuZXhwb3J0IHZhciBNT1ogPSAnLW1vei0nXG5leHBvcnQgdmFyIFdFQktJVCA9ICctd2Via2l0LSdcblxuZXhwb3J0IHZhciBDT01NRU5UID0gJ2NvbW0nXG5leHBvcnQgdmFyIFJVTEVTRVQgPSAncnVsZSdcbmV4cG9ydCB2YXIgREVDTEFSQVRJT04gPSAnZGVjbCdcblxuZXhwb3J0IHZhciBQQUdFID0gJ0BwYWdlJ1xuZXhwb3J0IHZhciBNRURJQSA9ICdAbWVkaWEnXG5leHBvcnQgdmFyIElNUE9SVCA9ICdAaW1wb3J0J1xuZXhwb3J0IHZhciBDSEFSU0VUID0gJ0BjaGFyc2V0J1xuZXhwb3J0IHZhciBWSUVXUE9SVCA9ICdAdmlld3BvcnQnXG5leHBvcnQgdmFyIFNVUFBPUlRTID0gJ0BzdXBwb3J0cydcbmV4cG9ydCB2YXIgRE9DVU1FTlQgPSAnQGRvY3VtZW50J1xuZXhwb3J0IHZhciBOQU1FU1BBQ0UgPSAnQG5hbWVzcGFjZSdcbmV4cG9ydCB2YXIgS0VZRlJBTUVTID0gJ0BrZXlmcmFtZXMnXG5leHBvcnQgdmFyIEZPTlRfRkFDRSA9ICdAZm9udC1mYWNlJ1xuZXhwb3J0IHZhciBDT1VOVEVSX1NUWUxFID0gJ0Bjb3VudGVyLXN0eWxlJ1xuZXhwb3J0IHZhciBGT05UX0ZFQVRVUkVfVkFMVUVTID0gJ0Bmb250LWZlYXR1cmUtdmFsdWVzJ1xuZXhwb3J0IHZhciBMQVlFUiA9ICdAbGF5ZXInXG4iLCIvKipcbiAqIEBwYXJhbSB7bnVtYmVyfVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgdmFyIGFicyA9IE1hdGguYWJzXG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9XG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCB2YXIgZnJvbSA9IFN0cmluZy5mcm9tQ2hhckNvZGVcblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdH1cbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IHZhciBhc3NpZ24gPSBPYmplY3QuYXNzaWduXG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge251bWJlcn0gbGVuZ3RoXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoYXNoICh2YWx1ZSwgbGVuZ3RoKSB7XG5cdHJldHVybiBjaGFyYXQodmFsdWUsIDApIF4gNDUgPyAoKCgoKCgobGVuZ3RoIDw8IDIpIF4gY2hhcmF0KHZhbHVlLCAwKSkgPDwgMikgXiBjaGFyYXQodmFsdWUsIDEpKSA8PCAyKSBeIGNoYXJhdCh2YWx1ZSwgMikpIDw8IDIpIF4gY2hhcmF0KHZhbHVlLCAzKSA6IDBcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyaW0gKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZS50cmltKClcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7UmVnRXhwfSBwYXR0ZXJuXG4gKiBAcmV0dXJuIHtzdHJpbmc/fVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0Y2ggKHZhbHVlLCBwYXR0ZXJuKSB7XG5cdHJldHVybiAodmFsdWUgPSBwYXR0ZXJuLmV4ZWModmFsdWUpKSA/IHZhbHVlWzBdIDogdmFsdWVcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7KHN0cmluZ3xSZWdFeHApfSBwYXR0ZXJuXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVwbGFjZW1lbnRcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlcGxhY2UgKHZhbHVlLCBwYXR0ZXJuLCByZXBsYWNlbWVudCkge1xuXHRyZXR1cm4gdmFsdWUucmVwbGFjZShwYXR0ZXJuLCByZXBsYWNlbWVudClcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWFyY2hcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGluZGV4b2YgKHZhbHVlLCBzZWFyY2gpIHtcblx0cmV0dXJuIHZhbHVlLmluZGV4T2Yoc2VhcmNoKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGFyYXQgKHZhbHVlLCBpbmRleCkge1xuXHRyZXR1cm4gdmFsdWUuY2hhckNvZGVBdChpbmRleCkgfCAwXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge251bWJlcn0gYmVnaW5cbiAqIEBwYXJhbSB7bnVtYmVyfSBlbmRcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN1YnN0ciAodmFsdWUsIGJlZ2luLCBlbmQpIHtcblx0cmV0dXJuIHZhbHVlLnNsaWNlKGJlZ2luLCBlbmQpXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdHJsZW4gKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZS5sZW5ndGhcbn1cblxuLyoqXG4gKiBAcGFyYW0ge2FueVtdfSB2YWx1ZVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2l6ZW9mICh2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUubGVuZ3RoXG59XG5cbi8qKlxuICogQHBhcmFtIHthbnl9IHZhbHVlXG4gKiBAcGFyYW0ge2FueVtdfSBhcnJheVxuICogQHJldHVybiB7YW55fVxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kICh2YWx1ZSwgYXJyYXkpIHtcblx0cmV0dXJuIGFycmF5LnB1c2godmFsdWUpLCB2YWx1ZVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nW119IGFycmF5XG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjYWxsYmFja1xuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gY29tYmluZSAoYXJyYXksIGNhbGxiYWNrKSB7XG5cdHJldHVybiBhcnJheS5tYXAoY2FsbGJhY2spLmpvaW4oJycpXG59XG4iLCJpbXBvcnQge2Zyb20sIHRyaW0sIGNoYXJhdCwgc3RybGVuLCBzdWJzdHIsIGFwcGVuZCwgYXNzaWdufSBmcm9tICcuL1V0aWxpdHkuanMnXG5cbmV4cG9ydCB2YXIgbGluZSA9IDFcbmV4cG9ydCB2YXIgY29sdW1uID0gMVxuZXhwb3J0IHZhciBsZW5ndGggPSAwXG5leHBvcnQgdmFyIHBvc2l0aW9uID0gMFxuZXhwb3J0IHZhciBjaGFyYWN0ZXIgPSAwXG5leHBvcnQgdmFyIGNoYXJhY3RlcnMgPSAnJ1xuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtvYmplY3QgfCBudWxsfSByb290XG4gKiBAcGFyYW0ge29iamVjdCB8IG51bGx9IHBhcmVudFxuICogQHBhcmFtIHtzdHJpbmd9IHR5cGVcbiAqIEBwYXJhbSB7c3RyaW5nW10gfCBzdHJpbmd9IHByb3BzXG4gKiBAcGFyYW0ge29iamVjdFtdIHwgc3RyaW5nfSBjaGlsZHJlblxuICogQHBhcmFtIHtudW1iZXJ9IGxlbmd0aFxuICovXG5leHBvcnQgZnVuY3Rpb24gbm9kZSAodmFsdWUsIHJvb3QsIHBhcmVudCwgdHlwZSwgcHJvcHMsIGNoaWxkcmVuLCBsZW5ndGgpIHtcblx0cmV0dXJuIHt2YWx1ZTogdmFsdWUsIHJvb3Q6IHJvb3QsIHBhcmVudDogcGFyZW50LCB0eXBlOiB0eXBlLCBwcm9wczogcHJvcHMsIGNoaWxkcmVuOiBjaGlsZHJlbiwgbGluZTogbGluZSwgY29sdW1uOiBjb2x1bW4sIGxlbmd0aDogbGVuZ3RoLCByZXR1cm46ICcnfVxufVxuXG4vKipcbiAqIEBwYXJhbSB7b2JqZWN0fSByb290XG4gKiBAcGFyYW0ge29iamVjdH0gcHJvcHNcbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvcHkgKHJvb3QsIHByb3BzKSB7XG5cdHJldHVybiBhc3NpZ24obm9kZSgnJywgbnVsbCwgbnVsbCwgJycsIG51bGwsIG51bGwsIDApLCByb290LCB7bGVuZ3RoOiAtcm9vdC5sZW5ndGh9LCBwcm9wcylcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGFyICgpIHtcblx0cmV0dXJuIGNoYXJhY3RlclxufVxuXG4vKipcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByZXYgKCkge1xuXHRjaGFyYWN0ZXIgPSBwb3NpdGlvbiA+IDAgPyBjaGFyYXQoY2hhcmFjdGVycywgLS1wb3NpdGlvbikgOiAwXG5cblx0aWYgKGNvbHVtbi0tLCBjaGFyYWN0ZXIgPT09IDEwKVxuXHRcdGNvbHVtbiA9IDEsIGxpbmUtLVxuXG5cdHJldHVybiBjaGFyYWN0ZXJcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuZXh0ICgpIHtcblx0Y2hhcmFjdGVyID0gcG9zaXRpb24gPCBsZW5ndGggPyBjaGFyYXQoY2hhcmFjdGVycywgcG9zaXRpb24rKykgOiAwXG5cblx0aWYgKGNvbHVtbisrLCBjaGFyYWN0ZXIgPT09IDEwKVxuXHRcdGNvbHVtbiA9IDEsIGxpbmUrK1xuXG5cdHJldHVybiBjaGFyYWN0ZXJcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwZWVrICgpIHtcblx0cmV0dXJuIGNoYXJhdChjaGFyYWN0ZXJzLCBwb3NpdGlvbilcbn1cblxuLyoqXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXJldCAoKSB7XG5cdHJldHVybiBwb3NpdGlvblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBiZWdpblxuICogQHBhcmFtIHtudW1iZXJ9IGVuZFxuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2xpY2UgKGJlZ2luLCBlbmQpIHtcblx0cmV0dXJuIHN1YnN0cihjaGFyYWN0ZXJzLCBiZWdpbiwgZW5kKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcmV0dXJuIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b2tlbiAodHlwZSkge1xuXHRzd2l0Y2ggKHR5cGUpIHtcblx0XHQvLyBcXDAgXFx0IFxcbiBcXHIgXFxzIHdoaXRlc3BhY2UgdG9rZW5cblx0XHRjYXNlIDA6IGNhc2UgOTogY2FzZSAxMDogY2FzZSAxMzogY2FzZSAzMjpcblx0XHRcdHJldHVybiA1XG5cdFx0Ly8gISArICwgLyA+IEAgfiBpc29sYXRlIHRva2VuXG5cdFx0Y2FzZSAzMzogY2FzZSA0MzogY2FzZSA0NDogY2FzZSA0NzogY2FzZSA2MjogY2FzZSA2NDogY2FzZSAxMjY6XG5cdFx0Ly8gOyB7IH0gYnJlYWtwb2ludCB0b2tlblxuXHRcdGNhc2UgNTk6IGNhc2UgMTIzOiBjYXNlIDEyNTpcblx0XHRcdHJldHVybiA0XG5cdFx0Ly8gOiBhY2NvbXBhbmllZCB0b2tlblxuXHRcdGNhc2UgNTg6XG5cdFx0XHRyZXR1cm4gM1xuXHRcdC8vIFwiICcgKCBbIG9wZW5pbmcgZGVsaW1pdCB0b2tlblxuXHRcdGNhc2UgMzQ6IGNhc2UgMzk6IGNhc2UgNDA6IGNhc2UgOTE6XG5cdFx0XHRyZXR1cm4gMlxuXHRcdC8vICkgXSBjbG9zaW5nIGRlbGltaXQgdG9rZW5cblx0XHRjYXNlIDQxOiBjYXNlIDkzOlxuXHRcdFx0cmV0dXJuIDFcblx0fVxuXG5cdHJldHVybiAwXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHthbnlbXX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFsbG9jICh2YWx1ZSkge1xuXHRyZXR1cm4gbGluZSA9IGNvbHVtbiA9IDEsIGxlbmd0aCA9IHN0cmxlbihjaGFyYWN0ZXJzID0gdmFsdWUpLCBwb3NpdGlvbiA9IDAsIFtdXG59XG5cbi8qKlxuICogQHBhcmFtIHthbnl9IHZhbHVlXG4gKiBAcmV0dXJuIHthbnl9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWFsbG9jICh2YWx1ZSkge1xuXHRyZXR1cm4gY2hhcmFjdGVycyA9ICcnLCB2YWx1ZVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWxpbWl0ICh0eXBlKSB7XG5cdHJldHVybiB0cmltKHNsaWNlKHBvc2l0aW9uIC0gMSwgZGVsaW1pdGVyKHR5cGUgPT09IDkxID8gdHlwZSArIDIgOiB0eXBlID09PSA0MCA/IHR5cGUgKyAxIDogdHlwZSkpKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHJldHVybiB7c3RyaW5nW119XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b2tlbml6ZSAodmFsdWUpIHtcblx0cmV0dXJuIGRlYWxsb2ModG9rZW5pemVyKGFsbG9jKHZhbHVlKSkpXG59XG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9IHR5cGVcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdoaXRlc3BhY2UgKHR5cGUpIHtcblx0d2hpbGUgKGNoYXJhY3RlciA9IHBlZWsoKSlcblx0XHRpZiAoY2hhcmFjdGVyIDwgMzMpXG5cdFx0XHRuZXh0KClcblx0XHRlbHNlXG5cdFx0XHRicmVha1xuXG5cdHJldHVybiB0b2tlbih0eXBlKSA+IDIgfHwgdG9rZW4oY2hhcmFjdGVyKSA+IDMgPyAnJyA6ICcgJ1xufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nW119IGNoaWxkcmVuXG4gKiBAcmV0dXJuIHtzdHJpbmdbXX1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRva2VuaXplciAoY2hpbGRyZW4pIHtcblx0d2hpbGUgKG5leHQoKSlcblx0XHRzd2l0Y2ggKHRva2VuKGNoYXJhY3RlcikpIHtcblx0XHRcdGNhc2UgMDogYXBwZW5kKGlkZW50aWZpZXIocG9zaXRpb24gLSAxKSwgY2hpbGRyZW4pXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDI6IGFwcGVuZChkZWxpbWl0KGNoYXJhY3RlciksIGNoaWxkcmVuKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0ZGVmYXVsdDogYXBwZW5kKGZyb20oY2hhcmFjdGVyKSwgY2hpbGRyZW4pXG5cdFx0fVxuXG5cdHJldHVybiBjaGlsZHJlblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtudW1iZXJ9IGNvdW50XG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlc2NhcGluZyAoaW5kZXgsIGNvdW50KSB7XG5cdHdoaWxlICgtLWNvdW50ICYmIG5leHQoKSlcblx0XHQvLyBub3QgMC05IEEtRiBhLWZcblx0XHRpZiAoY2hhcmFjdGVyIDwgNDggfHwgY2hhcmFjdGVyID4gMTAyIHx8IChjaGFyYWN0ZXIgPiA1NyAmJiBjaGFyYWN0ZXIgPCA2NSkgfHwgKGNoYXJhY3RlciA+IDcwICYmIGNoYXJhY3RlciA8IDk3KSlcblx0XHRcdGJyZWFrXG5cblx0cmV0dXJuIHNsaWNlKGluZGV4LCBjYXJldCgpICsgKGNvdW50IDwgNiAmJiBwZWVrKCkgPT0gMzIgJiYgbmV4dCgpID09IDMyKSlcbn1cblxuLyoqXG4gKiBAcGFyYW0ge251bWJlcn0gdHlwZVxuICogQHJldHVybiB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVsaW1pdGVyICh0eXBlKSB7XG5cdHdoaWxlIChuZXh0KCkpXG5cdFx0c3dpdGNoIChjaGFyYWN0ZXIpIHtcblx0XHRcdC8vIF0gKSBcIiAnXG5cdFx0XHRjYXNlIHR5cGU6XG5cdFx0XHRcdHJldHVybiBwb3NpdGlvblxuXHRcdFx0Ly8gXCIgJ1xuXHRcdFx0Y2FzZSAzNDogY2FzZSAzOTpcblx0XHRcdFx0aWYgKHR5cGUgIT09IDM0ICYmIHR5cGUgIT09IDM5KVxuXHRcdFx0XHRcdGRlbGltaXRlcihjaGFyYWN0ZXIpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyAoXG5cdFx0XHRjYXNlIDQwOlxuXHRcdFx0XHRpZiAodHlwZSA9PT0gNDEpXG5cdFx0XHRcdFx0ZGVsaW1pdGVyKHR5cGUpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyBcXFxuXHRcdFx0Y2FzZSA5Mjpcblx0XHRcdFx0bmV4dCgpXG5cdFx0XHRcdGJyZWFrXG5cdFx0fVxuXG5cdHJldHVybiBwb3NpdGlvblxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB0eXBlXG4gKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcbiAqIEByZXR1cm4ge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbW1lbnRlciAodHlwZSwgaW5kZXgpIHtcblx0d2hpbGUgKG5leHQoKSlcblx0XHQvLyAvL1xuXHRcdGlmICh0eXBlICsgY2hhcmFjdGVyID09PSA0NyArIDEwKVxuXHRcdFx0YnJlYWtcblx0XHQvLyAvKlxuXHRcdGVsc2UgaWYgKHR5cGUgKyBjaGFyYWN0ZXIgPT09IDQyICsgNDIgJiYgcGVlaygpID09PSA0Nylcblx0XHRcdGJyZWFrXG5cblx0cmV0dXJuICcvKicgKyBzbGljZShpbmRleCwgcG9zaXRpb24gLSAxKSArICcqJyArIGZyb20odHlwZSA9PT0gNDcgPyB0eXBlIDogbmV4dCgpKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gaWRlbnRpZmllciAoaW5kZXgpIHtcblx0d2hpbGUgKCF0b2tlbihwZWVrKCkpKVxuXHRcdG5leHQoKVxuXG5cdHJldHVybiBzbGljZShpbmRleCwgcG9zaXRpb24pXG59XG4iLCJpbXBvcnQge0NPTU1FTlQsIFJVTEVTRVQsIERFQ0xBUkFUSU9OfSBmcm9tICcuL0VudW0uanMnXG5pbXBvcnQge2FicywgY2hhcmF0LCB0cmltLCBmcm9tLCBzaXplb2YsIHN0cmxlbiwgc3Vic3RyLCBhcHBlbmQsIHJlcGxhY2UsIGluZGV4b2Z9IGZyb20gJy4vVXRpbGl0eS5qcydcbmltcG9ydCB7bm9kZSwgY2hhciwgcHJldiwgbmV4dCwgcGVlaywgY2FyZXQsIGFsbG9jLCBkZWFsbG9jLCBkZWxpbWl0LCB3aGl0ZXNwYWNlLCBlc2NhcGluZywgaWRlbnRpZmllciwgY29tbWVudGVyfSBmcm9tICcuL1Rva2VuaXplci5qcydcblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEByZXR1cm4ge29iamVjdFtdfVxuICovXG5leHBvcnQgZnVuY3Rpb24gY29tcGlsZSAodmFsdWUpIHtcblx0cmV0dXJuIGRlYWxsb2MocGFyc2UoJycsIG51bGwsIG51bGwsIG51bGwsIFsnJ10sIHZhbHVlID0gYWxsb2ModmFsdWUpLCAwLCBbMF0sIHZhbHVlKSlcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7b2JqZWN0fSByb290XG4gKiBAcGFyYW0ge29iamVjdD99IHBhcmVudFxuICogQHBhcmFtIHtzdHJpbmdbXX0gcnVsZVxuICogQHBhcmFtIHtzdHJpbmdbXX0gcnVsZXNcbiAqIEBwYXJhbSB7c3RyaW5nW119IHJ1bGVzZXRzXG4gKiBAcGFyYW0ge251bWJlcltdfSBwc2V1ZG9cbiAqIEBwYXJhbSB7bnVtYmVyW119IHBvaW50c1xuICogQHBhcmFtIHtzdHJpbmdbXX0gZGVjbGFyYXRpb25zXG4gKiBAcmV0dXJuIHtvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZSAodmFsdWUsIHJvb3QsIHBhcmVudCwgcnVsZSwgcnVsZXMsIHJ1bGVzZXRzLCBwc2V1ZG8sIHBvaW50cywgZGVjbGFyYXRpb25zKSB7XG5cdHZhciBpbmRleCA9IDBcblx0dmFyIG9mZnNldCA9IDBcblx0dmFyIGxlbmd0aCA9IHBzZXVkb1xuXHR2YXIgYXRydWxlID0gMFxuXHR2YXIgcHJvcGVydHkgPSAwXG5cdHZhciBwcmV2aW91cyA9IDBcblx0dmFyIHZhcmlhYmxlID0gMVxuXHR2YXIgc2Nhbm5pbmcgPSAxXG5cdHZhciBhbXBlcnNhbmQgPSAxXG5cdHZhciBjaGFyYWN0ZXIgPSAwXG5cdHZhciB0eXBlID0gJydcblx0dmFyIHByb3BzID0gcnVsZXNcblx0dmFyIGNoaWxkcmVuID0gcnVsZXNldHNcblx0dmFyIHJlZmVyZW5jZSA9IHJ1bGVcblx0dmFyIGNoYXJhY3RlcnMgPSB0eXBlXG5cblx0d2hpbGUgKHNjYW5uaW5nKVxuXHRcdHN3aXRjaCAocHJldmlvdXMgPSBjaGFyYWN0ZXIsIGNoYXJhY3RlciA9IG5leHQoKSkge1xuXHRcdFx0Ly8gKFxuXHRcdFx0Y2FzZSA0MDpcblx0XHRcdFx0aWYgKHByZXZpb3VzICE9IDEwOCAmJiBjaGFyYXQoY2hhcmFjdGVycywgbGVuZ3RoIC0gMSkgPT0gNTgpIHtcblx0XHRcdFx0XHRpZiAoaW5kZXhvZihjaGFyYWN0ZXJzICs9IHJlcGxhY2UoZGVsaW1pdChjaGFyYWN0ZXIpLCAnJicsICcmXFxmJyksICcmXFxmJykgIT0gLTEpXG5cdFx0XHRcdFx0XHRhbXBlcnNhbmQgPSAtMVxuXHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdH1cblx0XHRcdC8vIFwiICcgW1xuXHRcdFx0Y2FzZSAzNDogY2FzZSAzOTogY2FzZSA5MTpcblx0XHRcdFx0Y2hhcmFjdGVycyArPSBkZWxpbWl0KGNoYXJhY3Rlcilcblx0XHRcdFx0YnJlYWtcblx0XHRcdC8vIFxcdCBcXG4gXFxyIFxcc1xuXHRcdFx0Y2FzZSA5OiBjYXNlIDEwOiBjYXNlIDEzOiBjYXNlIDMyOlxuXHRcdFx0XHRjaGFyYWN0ZXJzICs9IHdoaXRlc3BhY2UocHJldmlvdXMpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyBcXFxuXHRcdFx0Y2FzZSA5Mjpcblx0XHRcdFx0Y2hhcmFjdGVycyArPSBlc2NhcGluZyhjYXJldCgpIC0gMSwgNylcblx0XHRcdFx0Y29udGludWVcblx0XHRcdC8vIC9cblx0XHRcdGNhc2UgNDc6XG5cdFx0XHRcdHN3aXRjaCAocGVlaygpKSB7XG5cdFx0XHRcdFx0Y2FzZSA0MjogY2FzZSA0Nzpcblx0XHRcdFx0XHRcdGFwcGVuZChjb21tZW50KGNvbW1lbnRlcihuZXh0KCksIGNhcmV0KCkpLCByb290LCBwYXJlbnQpLCBkZWNsYXJhdGlvbnMpXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdFx0XHRjaGFyYWN0ZXJzICs9ICcvJ1xuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrXG5cdFx0XHQvLyB7XG5cdFx0XHRjYXNlIDEyMyAqIHZhcmlhYmxlOlxuXHRcdFx0XHRwb2ludHNbaW5kZXgrK10gPSBzdHJsZW4oY2hhcmFjdGVycykgKiBhbXBlcnNhbmRcblx0XHRcdC8vIH0gOyBcXDBcblx0XHRcdGNhc2UgMTI1ICogdmFyaWFibGU6IGNhc2UgNTk6IGNhc2UgMDpcblx0XHRcdFx0c3dpdGNoIChjaGFyYWN0ZXIpIHtcblx0XHRcdFx0XHQvLyBcXDAgfVxuXHRcdFx0XHRcdGNhc2UgMDogY2FzZSAxMjU6IHNjYW5uaW5nID0gMFxuXHRcdFx0XHRcdC8vIDtcblx0XHRcdFx0XHRjYXNlIDU5ICsgb2Zmc2V0OiBpZiAoYW1wZXJzYW5kID09IC0xKSBjaGFyYWN0ZXJzID0gcmVwbGFjZShjaGFyYWN0ZXJzLCAvXFxmL2csICcnKVxuXHRcdFx0XHRcdFx0aWYgKHByb3BlcnR5ID4gMCAmJiAoc3RybGVuKGNoYXJhY3RlcnMpIC0gbGVuZ3RoKSlcblx0XHRcdFx0XHRcdFx0YXBwZW5kKHByb3BlcnR5ID4gMzIgPyBkZWNsYXJhdGlvbihjaGFyYWN0ZXJzICsgJzsnLCBydWxlLCBwYXJlbnQsIGxlbmd0aCAtIDEpIDogZGVjbGFyYXRpb24ocmVwbGFjZShjaGFyYWN0ZXJzLCAnICcsICcnKSArICc7JywgcnVsZSwgcGFyZW50LCBsZW5ndGggLSAyKSwgZGVjbGFyYXRpb25zKVxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHQvLyBAIDtcblx0XHRcdFx0XHRjYXNlIDU5OiBjaGFyYWN0ZXJzICs9ICc7J1xuXHRcdFx0XHRcdC8vIHsgcnVsZS9hdC1ydWxlXG5cdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdGFwcGVuZChyZWZlcmVuY2UgPSBydWxlc2V0KGNoYXJhY3RlcnMsIHJvb3QsIHBhcmVudCwgaW5kZXgsIG9mZnNldCwgcnVsZXMsIHBvaW50cywgdHlwZSwgcHJvcHMgPSBbXSwgY2hpbGRyZW4gPSBbXSwgbGVuZ3RoKSwgcnVsZXNldHMpXG5cblx0XHRcdFx0XHRcdGlmIChjaGFyYWN0ZXIgPT09IDEyMylcblx0XHRcdFx0XHRcdFx0aWYgKG9mZnNldCA9PT0gMClcblx0XHRcdFx0XHRcdFx0XHRwYXJzZShjaGFyYWN0ZXJzLCByb290LCByZWZlcmVuY2UsIHJlZmVyZW5jZSwgcHJvcHMsIHJ1bGVzZXRzLCBsZW5ndGgsIHBvaW50cywgY2hpbGRyZW4pXG5cdFx0XHRcdFx0XHRcdGVsc2Vcblx0XHRcdFx0XHRcdFx0XHRzd2l0Y2ggKGF0cnVsZSA9PT0gOTkgJiYgY2hhcmF0KGNoYXJhY3RlcnMsIDMpID09PSAxMTAgPyAxMDAgOiBhdHJ1bGUpIHtcblx0XHRcdFx0XHRcdFx0XHRcdC8vIGQgbCBtIHNcblx0XHRcdFx0XHRcdFx0XHRcdGNhc2UgMTAwOiBjYXNlIDEwODogY2FzZSAxMDk6IGNhc2UgMTE1OlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRwYXJzZSh2YWx1ZSwgcmVmZXJlbmNlLCByZWZlcmVuY2UsIHJ1bGUgJiYgYXBwZW5kKHJ1bGVzZXQodmFsdWUsIHJlZmVyZW5jZSwgcmVmZXJlbmNlLCAwLCAwLCBydWxlcywgcG9pbnRzLCB0eXBlLCBydWxlcywgcHJvcHMgPSBbXSwgbGVuZ3RoKSwgY2hpbGRyZW4pLCBydWxlcywgY2hpbGRyZW4sIGxlbmd0aCwgcG9pbnRzLCBydWxlID8gcHJvcHMgOiBjaGlsZHJlbilcblx0XHRcdFx0XHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHRcdFx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHBhcnNlKGNoYXJhY3RlcnMsIHJlZmVyZW5jZSwgcmVmZXJlbmNlLCByZWZlcmVuY2UsIFsnJ10sIGNoaWxkcmVuLCAwLCBwb2ludHMsIGNoaWxkcmVuKVxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGluZGV4ID0gb2Zmc2V0ID0gcHJvcGVydHkgPSAwLCB2YXJpYWJsZSA9IGFtcGVyc2FuZCA9IDEsIHR5cGUgPSBjaGFyYWN0ZXJzID0gJycsIGxlbmd0aCA9IHBzZXVkb1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Ly8gOlxuXHRcdFx0Y2FzZSA1ODpcblx0XHRcdFx0bGVuZ3RoID0gMSArIHN0cmxlbihjaGFyYWN0ZXJzKSwgcHJvcGVydHkgPSBwcmV2aW91c1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0aWYgKHZhcmlhYmxlIDwgMSlcblx0XHRcdFx0XHRpZiAoY2hhcmFjdGVyID09IDEyMylcblx0XHRcdFx0XHRcdC0tdmFyaWFibGVcblx0XHRcdFx0XHRlbHNlIGlmIChjaGFyYWN0ZXIgPT0gMTI1ICYmIHZhcmlhYmxlKysgPT0gMCAmJiBwcmV2KCkgPT0gMTI1KVxuXHRcdFx0XHRcdFx0Y29udGludWVcblxuXHRcdFx0XHRzd2l0Y2ggKGNoYXJhY3RlcnMgKz0gZnJvbShjaGFyYWN0ZXIpLCBjaGFyYWN0ZXIgKiB2YXJpYWJsZSkge1xuXHRcdFx0XHRcdC8vICZcblx0XHRcdFx0XHRjYXNlIDM4OlxuXHRcdFx0XHRcdFx0YW1wZXJzYW5kID0gb2Zmc2V0ID4gMCA/IDEgOiAoY2hhcmFjdGVycyArPSAnXFxmJywgLTEpXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdC8vICxcblx0XHRcdFx0XHRjYXNlIDQ0OlxuXHRcdFx0XHRcdFx0cG9pbnRzW2luZGV4KytdID0gKHN0cmxlbihjaGFyYWN0ZXJzKSAtIDEpICogYW1wZXJzYW5kLCBhbXBlcnNhbmQgPSAxXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdC8vIEBcblx0XHRcdFx0XHRjYXNlIDY0OlxuXHRcdFx0XHRcdFx0Ly8gLVxuXHRcdFx0XHRcdFx0aWYgKHBlZWsoKSA9PT0gNDUpXG5cdFx0XHRcdFx0XHRcdGNoYXJhY3RlcnMgKz0gZGVsaW1pdChuZXh0KCkpXG5cblx0XHRcdFx0XHRcdGF0cnVsZSA9IHBlZWsoKSwgb2Zmc2V0ID0gbGVuZ3RoID0gc3RybGVuKHR5cGUgPSBjaGFyYWN0ZXJzICs9IGlkZW50aWZpZXIoY2FyZXQoKSkpLCBjaGFyYWN0ZXIrK1xuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHQvLyAtXG5cdFx0XHRcdFx0Y2FzZSA0NTpcblx0XHRcdFx0XHRcdGlmIChwcmV2aW91cyA9PT0gNDUgJiYgc3RybGVuKGNoYXJhY3RlcnMpID09IDIpXG5cdFx0XHRcdFx0XHRcdHZhcmlhYmxlID0gMFxuXHRcdFx0XHR9XG5cdFx0fVxuXG5cdHJldHVybiBydWxlc2V0c1xufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtvYmplY3R9IHJvb3RcbiAqIEBwYXJhbSB7b2JqZWN0P30gcGFyZW50XG4gKiBAcGFyYW0ge251bWJlcn0gaW5kZXhcbiAqIEBwYXJhbSB7bnVtYmVyfSBvZmZzZXRcbiAqIEBwYXJhbSB7c3RyaW5nW119IHJ1bGVzXG4gKiBAcGFyYW0ge251bWJlcltdfSBwb2ludHNcbiAqIEBwYXJhbSB7c3RyaW5nfSB0eXBlXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBwcm9wc1xuICogQHBhcmFtIHtzdHJpbmdbXX0gY2hpbGRyZW5cbiAqIEBwYXJhbSB7bnVtYmVyfSBsZW5ndGhcbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bGVzZXQgKHZhbHVlLCByb290LCBwYXJlbnQsIGluZGV4LCBvZmZzZXQsIHJ1bGVzLCBwb2ludHMsIHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgbGVuZ3RoKSB7XG5cdHZhciBwb3N0ID0gb2Zmc2V0IC0gMVxuXHR2YXIgcnVsZSA9IG9mZnNldCA9PT0gMCA/IHJ1bGVzIDogWycnXVxuXHR2YXIgc2l6ZSA9IHNpemVvZihydWxlKVxuXG5cdGZvciAodmFyIGkgPSAwLCBqID0gMCwgayA9IDA7IGkgPCBpbmRleDsgKytpKVxuXHRcdGZvciAodmFyIHggPSAwLCB5ID0gc3Vic3RyKHZhbHVlLCBwb3N0ICsgMSwgcG9zdCA9IGFicyhqID0gcG9pbnRzW2ldKSksIHogPSB2YWx1ZTsgeCA8IHNpemU7ICsreClcblx0XHRcdGlmICh6ID0gdHJpbShqID4gMCA/IHJ1bGVbeF0gKyAnICcgKyB5IDogcmVwbGFjZSh5LCAvJlxcZi9nLCBydWxlW3hdKSkpXG5cdFx0XHRcdHByb3BzW2srK10gPSB6XG5cblx0cmV0dXJuIG5vZGUodmFsdWUsIHJvb3QsIHBhcmVudCwgb2Zmc2V0ID09PSAwID8gUlVMRVNFVCA6IHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgbGVuZ3RoKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSB2YWx1ZVxuICogQHBhcmFtIHtvYmplY3R9IHJvb3RcbiAqIEBwYXJhbSB7b2JqZWN0P30gcGFyZW50XG4gKiBAcmV0dXJuIHtvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21tZW50ICh2YWx1ZSwgcm9vdCwgcGFyZW50KSB7XG5cdHJldHVybiBub2RlKHZhbHVlLCByb290LCBwYXJlbnQsIENPTU1FTlQsIGZyb20oY2hhcigpKSwgc3Vic3RyKHZhbHVlLCAyLCAtMiksIDApXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiBAcGFyYW0ge29iamVjdH0gcm9vdFxuICogQHBhcmFtIHtvYmplY3Q/fSBwYXJlbnRcbiAqIEBwYXJhbSB7bnVtYmVyfSBsZW5ndGhcbiAqIEByZXR1cm4ge29iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY2xhcmF0aW9uICh2YWx1ZSwgcm9vdCwgcGFyZW50LCBsZW5ndGgpIHtcblx0cmV0dXJuIG5vZGUodmFsdWUsIHJvb3QsIHBhcmVudCwgREVDTEFSQVRJT04sIHN1YnN0cih2YWx1ZSwgMCwgbGVuZ3RoKSwgc3Vic3RyKHZhbHVlLCBsZW5ndGggKyAxLCAtMSksIGxlbmd0aClcbn1cbiIsImltcG9ydCB7SU1QT1JULCBMQVlFUiwgQ09NTUVOVCwgUlVMRVNFVCwgREVDTEFSQVRJT04sIEtFWUZSQU1FU30gZnJvbSAnLi9FbnVtLmpzJ1xuaW1wb3J0IHtzdHJsZW4sIHNpemVvZn0gZnJvbSAnLi9VdGlsaXR5LmpzJ1xuXG4vKipcbiAqIEBwYXJhbSB7b2JqZWN0W119IGNoaWxkcmVuXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjYWxsYmFja1xuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplIChjaGlsZHJlbiwgY2FsbGJhY2spIHtcblx0dmFyIG91dHB1dCA9ICcnXG5cdHZhciBsZW5ndGggPSBzaXplb2YoY2hpbGRyZW4pXG5cblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKylcblx0XHRvdXRwdXQgKz0gY2FsbGJhY2soY2hpbGRyZW5baV0sIGksIGNoaWxkcmVuLCBjYWxsYmFjaykgfHwgJydcblxuXHRyZXR1cm4gb3V0cHV0XG59XG5cbi8qKlxuICogQHBhcmFtIHtvYmplY3R9IGVsZW1lbnRcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtvYmplY3RbXX0gY2hpbGRyZW5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdHJpbmdpZnkgKGVsZW1lbnQsIGluZGV4LCBjaGlsZHJlbiwgY2FsbGJhY2spIHtcblx0c3dpdGNoIChlbGVtZW50LnR5cGUpIHtcblx0XHRjYXNlIExBWUVSOiBpZiAoZWxlbWVudC5jaGlsZHJlbi5sZW5ndGgpIGJyZWFrXG5cdFx0Y2FzZSBJTVBPUlQ6IGNhc2UgREVDTEFSQVRJT046IHJldHVybiBlbGVtZW50LnJldHVybiA9IGVsZW1lbnQucmV0dXJuIHx8IGVsZW1lbnQudmFsdWVcblx0XHRjYXNlIENPTU1FTlQ6IHJldHVybiAnJ1xuXHRcdGNhc2UgS0VZRlJBTUVTOiByZXR1cm4gZWxlbWVudC5yZXR1cm4gPSBlbGVtZW50LnZhbHVlICsgJ3snICsgc2VyaWFsaXplKGVsZW1lbnQuY2hpbGRyZW4sIGNhbGxiYWNrKSArICd9J1xuXHRcdGNhc2UgUlVMRVNFVDogZWxlbWVudC52YWx1ZSA9IGVsZW1lbnQucHJvcHMuam9pbignLCcpXG5cdH1cblxuXHRyZXR1cm4gc3RybGVuKGNoaWxkcmVuID0gc2VyaWFsaXplKGVsZW1lbnQuY2hpbGRyZW4sIGNhbGxiYWNrKSkgPyBlbGVtZW50LnJldHVybiA9IGVsZW1lbnQudmFsdWUgKyAneycgKyBjaGlsZHJlbiArICd9JyA6ICcnXG59XG4iLCJpbXBvcnQge01TLCBNT1osIFdFQktJVCwgUlVMRVNFVCwgS0VZRlJBTUVTLCBERUNMQVJBVElPTn0gZnJvbSAnLi9FbnVtLmpzJ1xuaW1wb3J0IHttYXRjaCwgY2hhcmF0LCBzdWJzdHIsIHN0cmxlbiwgc2l6ZW9mLCByZXBsYWNlLCBjb21iaW5lfSBmcm9tICcuL1V0aWxpdHkuanMnXG5pbXBvcnQge2NvcHksIHRva2VuaXplfSBmcm9tICcuL1Rva2VuaXplci5qcydcbmltcG9ydCB7c2VyaWFsaXplfSBmcm9tICcuL1NlcmlhbGl6ZXIuanMnXG5pbXBvcnQge3ByZWZpeH0gZnJvbSAnLi9QcmVmaXhlci5qcydcblxuLyoqXG4gKiBAcGFyYW0ge2Z1bmN0aW9uW119IGNvbGxlY3Rpb25cbiAqIEByZXR1cm4ge2Z1bmN0aW9ufVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWlkZGxld2FyZSAoY29sbGVjdGlvbikge1xuXHR2YXIgbGVuZ3RoID0gc2l6ZW9mKGNvbGxlY3Rpb24pXG5cblx0cmV0dXJuIGZ1bmN0aW9uIChlbGVtZW50LCBpbmRleCwgY2hpbGRyZW4sIGNhbGxiYWNrKSB7XG5cdFx0dmFyIG91dHB1dCA9ICcnXG5cblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKVxuXHRcdFx0b3V0cHV0ICs9IGNvbGxlY3Rpb25baV0oZWxlbWVudCwgaW5kZXgsIGNoaWxkcmVuLCBjYWxsYmFjaykgfHwgJydcblxuXHRcdHJldHVybiBvdXRwdXRcblx0fVxufVxuXG4vKipcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKiBAcmV0dXJuIHtmdW5jdGlvbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bGVzaGVldCAoY2FsbGJhY2spIHtcblx0cmV0dXJuIGZ1bmN0aW9uIChlbGVtZW50KSB7XG5cdFx0aWYgKCFlbGVtZW50LnJvb3QpXG5cdFx0XHRpZiAoZWxlbWVudCA9IGVsZW1lbnQucmV0dXJuKVxuXHRcdFx0XHRjYWxsYmFjayhlbGVtZW50KVxuXHR9XG59XG5cbi8qKlxuICogQHBhcmFtIHtvYmplY3R9IGVsZW1lbnRcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtvYmplY3RbXX0gY2hpbGRyZW5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmVmaXhlciAoZWxlbWVudCwgaW5kZXgsIGNoaWxkcmVuLCBjYWxsYmFjaykge1xuXHRpZiAoZWxlbWVudC5sZW5ndGggPiAtMSlcblx0XHRpZiAoIWVsZW1lbnQucmV0dXJuKVxuXHRcdFx0c3dpdGNoIChlbGVtZW50LnR5cGUpIHtcblx0XHRcdFx0Y2FzZSBERUNMQVJBVElPTjogZWxlbWVudC5yZXR1cm4gPSBwcmVmaXgoZWxlbWVudC52YWx1ZSwgZWxlbWVudC5sZW5ndGgsIGNoaWxkcmVuKVxuXHRcdFx0XHRcdHJldHVyblxuXHRcdFx0XHRjYXNlIEtFWUZSQU1FUzpcblx0XHRcdFx0XHRyZXR1cm4gc2VyaWFsaXplKFtjb3B5KGVsZW1lbnQsIHt2YWx1ZTogcmVwbGFjZShlbGVtZW50LnZhbHVlLCAnQCcsICdAJyArIFdFQktJVCl9KV0sIGNhbGxiYWNrKVxuXHRcdFx0XHRjYXNlIFJVTEVTRVQ6XG5cdFx0XHRcdFx0aWYgKGVsZW1lbnQubGVuZ3RoKVxuXHRcdFx0XHRcdFx0cmV0dXJuIGNvbWJpbmUoZWxlbWVudC5wcm9wcywgZnVuY3Rpb24gKHZhbHVlKSB7XG5cdFx0XHRcdFx0XHRcdHN3aXRjaCAobWF0Y2godmFsdWUsIC8oOjpwbGFjXFx3K3w6cmVhZC1cXHcrKS8pKSB7XG5cdFx0XHRcdFx0XHRcdFx0Ly8gOnJlYWQtKG9ubHl8d3JpdGUpXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSAnOnJlYWQtb25seSc6IGNhc2UgJzpyZWFkLXdyaXRlJzpcblx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiBzZXJpYWxpemUoW2NvcHkoZWxlbWVudCwge3Byb3BzOiBbcmVwbGFjZSh2YWx1ZSwgLzoocmVhZC1cXHcrKS8sICc6JyArIE1PWiArICckMScpXX0pXSwgY2FsbGJhY2spXG5cdFx0XHRcdFx0XHRcdFx0Ly8gOnBsYWNlaG9sZGVyXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSAnOjpwbGFjZWhvbGRlcic6XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gc2VyaWFsaXplKFtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBXRUJLSVQgKyAnaW5wdXQtJDEnKV19KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBNT1ogKyAnJDEnKV19KSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29weShlbGVtZW50LCB7cHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCBNUyArICdpbnB1dC0kMScpXX0pXG5cdFx0XHRcdFx0XHRcdFx0XHRdLCBjYWxsYmFjaylcblx0XHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRcdHJldHVybiAnJ1xuXHRcdFx0XHRcdFx0fSlcblx0XHRcdH1cbn1cblxuLyoqXG4gKiBAcGFyYW0ge29iamVjdH0gZWxlbWVudFxuICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gKiBAcGFyYW0ge29iamVjdFtdfSBjaGlsZHJlblxuICovXG5leHBvcnQgZnVuY3Rpb24gbmFtZXNwYWNlIChlbGVtZW50KSB7XG5cdHN3aXRjaCAoZWxlbWVudC50eXBlKSB7XG5cdFx0Y2FzZSBSVUxFU0VUOlxuXHRcdFx0ZWxlbWVudC5wcm9wcyA9IGVsZW1lbnQucHJvcHMubWFwKGZ1bmN0aW9uICh2YWx1ZSkge1xuXHRcdFx0XHRyZXR1cm4gY29tYmluZSh0b2tlbml6ZSh2YWx1ZSksIGZ1bmN0aW9uICh2YWx1ZSwgaW5kZXgsIGNoaWxkcmVuKSB7XG5cdFx0XHRcdFx0c3dpdGNoIChjaGFyYXQodmFsdWUsIDApKSB7XG5cdFx0XHRcdFx0XHQvLyBcXGZcblx0XHRcdFx0XHRcdGNhc2UgMTI6XG5cdFx0XHRcdFx0XHRcdHJldHVybiBzdWJzdHIodmFsdWUsIDEsIHN0cmxlbih2YWx1ZSkpXG5cdFx0XHRcdFx0XHQvLyBcXDAgKCArID4gflxuXHRcdFx0XHRcdFx0Y2FzZSAwOiBjYXNlIDQwOiBjYXNlIDQzOiBjYXNlIDYyOiBjYXNlIDEyNjpcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHZhbHVlXG5cdFx0XHRcdFx0XHQvLyA6XG5cdFx0XHRcdFx0XHRjYXNlIDU4OlxuXHRcdFx0XHRcdFx0XHRpZiAoY2hpbGRyZW5bKytpbmRleF0gPT09ICdnbG9iYWwnKVxuXHRcdFx0XHRcdFx0XHRcdGNoaWxkcmVuW2luZGV4XSA9ICcnLCBjaGlsZHJlblsrK2luZGV4XSA9ICdcXGYnICsgc3Vic3RyKGNoaWxkcmVuW2luZGV4XSwgaW5kZXggPSAxLCAtMSlcblx0XHRcdFx0XHRcdC8vIFxcc1xuXHRcdFx0XHRcdFx0Y2FzZSAzMjpcblx0XHRcdFx0XHRcdFx0cmV0dXJuIGluZGV4ID09PSAxID8gJycgOiB2YWx1ZVxuXHRcdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdFx0c3dpdGNoIChpbmRleCkge1xuXHRcdFx0XHRcdFx0XHRcdGNhc2UgMDogZWxlbWVudCA9IHZhbHVlXG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gc2l6ZW9mKGNoaWxkcmVuKSA+IDEgPyAnJyA6IHZhbHVlXG5cdFx0XHRcdFx0XHRcdFx0Y2FzZSBpbmRleCA9IHNpemVvZihjaGlsZHJlbikgLSAxOiBjYXNlIDI6XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gaW5kZXggPT09IDIgPyB2YWx1ZSArIGVsZW1lbnQgKyBlbGVtZW50IDogdmFsdWUgKyBlbGVtZW50XG5cdFx0XHRcdFx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiB2YWx1ZVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fSlcblx0fVxufVxuIiwiZnVuY3Rpb24gbWVtb2l6ZShmbikge1xuICB2YXIgY2FjaGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4gZnVuY3Rpb24gKGFyZykge1xuICAgIGlmIChjYWNoZVthcmddID09PSB1bmRlZmluZWQpIGNhY2hlW2FyZ10gPSBmbihhcmcpO1xuICAgIHJldHVybiBjYWNoZVthcmddO1xuICB9O1xufVxuXG5leHBvcnQgeyBtZW1vaXplIGFzIGRlZmF1bHQgfTtcbiIsImltcG9ydCB7IFN0eWxlU2hlZXQgfSBmcm9tICdAZW1vdGlvbi9zaGVldCc7XG5pbXBvcnQgeyBkZWFsbG9jLCBhbGxvYywgbmV4dCwgdG9rZW4sIGZyb20sIHBlZWssIGRlbGltaXQsIHNsaWNlLCBwb3NpdGlvbiwgUlVMRVNFVCwgY29tYmluZSwgbWF0Y2gsIHNlcmlhbGl6ZSwgY29weSwgcmVwbGFjZSwgV0VCS0lULCBNT1osIE1TLCBLRVlGUkFNRVMsIERFQ0xBUkFUSU9OLCBoYXNoLCBjaGFyYXQsIHN0cmxlbiwgaW5kZXhvZiwgbWlkZGxld2FyZSwgc3RyaW5naWZ5LCBDT01NRU5ULCBjb21waWxlIH0gZnJvbSAnc3R5bGlzJztcbmltcG9ydCAnQGVtb3Rpb24vd2Vhay1tZW1vaXplJztcbmltcG9ydCAnQGVtb3Rpb24vbWVtb2l6ZSc7XG5cbnZhciBpZGVudGlmaWVyV2l0aFBvaW50VHJhY2tpbmcgPSBmdW5jdGlvbiBpZGVudGlmaWVyV2l0aFBvaW50VHJhY2tpbmcoYmVnaW4sIHBvaW50cywgaW5kZXgpIHtcbiAgdmFyIHByZXZpb3VzID0gMDtcbiAgdmFyIGNoYXJhY3RlciA9IDA7XG5cbiAgd2hpbGUgKHRydWUpIHtcbiAgICBwcmV2aW91cyA9IGNoYXJhY3RlcjtcbiAgICBjaGFyYWN0ZXIgPSBwZWVrKCk7IC8vICZcXGZcblxuICAgIGlmIChwcmV2aW91cyA9PT0gMzggJiYgY2hhcmFjdGVyID09PSAxMikge1xuICAgICAgcG9pbnRzW2luZGV4XSA9IDE7XG4gICAgfVxuXG4gICAgaWYgKHRva2VuKGNoYXJhY3RlcikpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIG5leHQoKTtcbiAgfVxuXG4gIHJldHVybiBzbGljZShiZWdpbiwgcG9zaXRpb24pO1xufTtcblxudmFyIHRvUnVsZXMgPSBmdW5jdGlvbiB0b1J1bGVzKHBhcnNlZCwgcG9pbnRzKSB7XG4gIC8vIHByZXRlbmQgd2UndmUgc3RhcnRlZCB3aXRoIGEgY29tbWFcbiAgdmFyIGluZGV4ID0gLTE7XG4gIHZhciBjaGFyYWN0ZXIgPSA0NDtcblxuICBkbyB7XG4gICAgc3dpdGNoICh0b2tlbihjaGFyYWN0ZXIpKSB7XG4gICAgICBjYXNlIDA6XG4gICAgICAgIC8vICZcXGZcbiAgICAgICAgaWYgKGNoYXJhY3RlciA9PT0gMzggJiYgcGVlaygpID09PSAxMikge1xuICAgICAgICAgIC8vIHRoaXMgaXMgbm90IDEwMCUgY29ycmVjdCwgd2UgZG9uJ3QgYWNjb3VudCBmb3IgbGl0ZXJhbCBzZXF1ZW5jZXMgaGVyZSAtIGxpa2UgZm9yIGV4YW1wbGUgcXVvdGVkIHN0cmluZ3NcbiAgICAgICAgICAvLyBzdHlsaXMgaW5zZXJ0cyBcXGYgYWZ0ZXIgJiB0byBrbm93IHdoZW4gJiB3aGVyZSBpdCBzaG91bGQgcmVwbGFjZSB0aGlzIHNlcXVlbmNlIHdpdGggdGhlIGNvbnRleHQgc2VsZWN0b3JcbiAgICAgICAgICAvLyBhbmQgd2hlbiBpdCBzaG91bGQganVzdCBjb25jYXRlbmF0ZSB0aGUgb3V0ZXIgYW5kIGlubmVyIHNlbGVjdG9yc1xuICAgICAgICAgIC8vIGl0J3MgdmVyeSB1bmxpa2VseSBmb3IgdGhpcyBzZXF1ZW5jZSB0byBhY3R1YWxseSBhcHBlYXIgaW4gYSBkaWZmZXJlbnQgY29udGV4dCwgc28gd2UganVzdCBsZXZlcmFnZSB0aGlzIGZhY3QgaGVyZVxuICAgICAgICAgIHBvaW50c1tpbmRleF0gPSAxO1xuICAgICAgICB9XG5cbiAgICAgICAgcGFyc2VkW2luZGV4XSArPSBpZGVudGlmaWVyV2l0aFBvaW50VHJhY2tpbmcocG9zaXRpb24gLSAxLCBwb2ludHMsIGluZGV4KTtcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgMjpcbiAgICAgICAgcGFyc2VkW2luZGV4XSArPSBkZWxpbWl0KGNoYXJhY3Rlcik7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlIDQ6XG4gICAgICAgIC8vIGNvbW1hXG4gICAgICAgIGlmIChjaGFyYWN0ZXIgPT09IDQ0KSB7XG4gICAgICAgICAgLy8gY29sb25cbiAgICAgICAgICBwYXJzZWRbKytpbmRleF0gPSBwZWVrKCkgPT09IDU4ID8gJyZcXGYnIDogJyc7XG4gICAgICAgICAgcG9pbnRzW2luZGV4XSA9IHBhcnNlZFtpbmRleF0ubGVuZ3RoO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgIC8vIGZhbGx0aHJvdWdoXG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHBhcnNlZFtpbmRleF0gKz0gZnJvbShjaGFyYWN0ZXIpO1xuICAgIH1cbiAgfSB3aGlsZSAoY2hhcmFjdGVyID0gbmV4dCgpKTtcblxuICByZXR1cm4gcGFyc2VkO1xufTtcblxudmFyIGdldFJ1bGVzID0gZnVuY3Rpb24gZ2V0UnVsZXModmFsdWUsIHBvaW50cykge1xuICByZXR1cm4gZGVhbGxvYyh0b1J1bGVzKGFsbG9jKHZhbHVlKSwgcG9pbnRzKSk7XG59OyAvLyBXZWFrU2V0IHdvdWxkIGJlIG1vcmUgYXBwcm9wcmlhdGUsIGJ1dCBvbmx5IFdlYWtNYXAgaXMgc3VwcG9ydGVkIGluIElFMTFcblxuXG52YXIgZml4ZWRFbGVtZW50cyA9IC8qICNfX1BVUkVfXyAqL25ldyBXZWFrTWFwKCk7XG52YXIgY29tcGF0ID0gZnVuY3Rpb24gY29tcGF0KGVsZW1lbnQpIHtcbiAgaWYgKGVsZW1lbnQudHlwZSAhPT0gJ3J1bGUnIHx8ICFlbGVtZW50LnBhcmVudCB8fCAvLyBwb3NpdGl2ZSAubGVuZ3RoIGluZGljYXRlcyB0aGF0IHRoaXMgcnVsZSBjb250YWlucyBwc2V1ZG9cbiAgLy8gbmVnYXRpdmUgLmxlbmd0aCBpbmRpY2F0ZXMgdGhhdCB0aGlzIHJ1bGUgaGFzIGJlZW4gYWxyZWFkeSBwcmVmaXhlZFxuICBlbGVtZW50Lmxlbmd0aCA8IDEpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICB2YXIgdmFsdWUgPSBlbGVtZW50LnZhbHVlO1xuICB2YXIgcGFyZW50ID0gZWxlbWVudC5wYXJlbnQ7XG4gIHZhciBpc0ltcGxpY2l0UnVsZSA9IGVsZW1lbnQuY29sdW1uID09PSBwYXJlbnQuY29sdW1uICYmIGVsZW1lbnQubGluZSA9PT0gcGFyZW50LmxpbmU7XG5cbiAgd2hpbGUgKHBhcmVudC50eXBlICE9PSAncnVsZScpIHtcbiAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50O1xuICAgIGlmICghcGFyZW50KSByZXR1cm47XG4gIH0gLy8gc2hvcnQtY2lyY3VpdCBmb3IgdGhlIHNpbXBsZXN0IGNhc2VcblxuXG4gIGlmIChlbGVtZW50LnByb3BzLmxlbmd0aCA9PT0gMSAmJiB2YWx1ZS5jaGFyQ29kZUF0KDApICE9PSA1OFxuICAvKiBjb2xvbiAqL1xuICAmJiAhZml4ZWRFbGVtZW50cy5nZXQocGFyZW50KSkge1xuICAgIHJldHVybjtcbiAgfSAvLyBpZiB0aGlzIGlzIGFuIGltcGxpY2l0bHkgaW5zZXJ0ZWQgcnVsZSAodGhlIG9uZSBlYWdlcmx5IGluc2VydGVkIGF0IHRoZSBlYWNoIG5ldyBuZXN0ZWQgbGV2ZWwpXG4gIC8vIHRoZW4gdGhlIHByb3BzIGhhcyBhbHJlYWR5IGJlZW4gbWFuaXB1bGF0ZWQgYmVmb3JlaGFuZCBhcyB0aGV5IHRoYXQgYXJyYXkgaXMgc2hhcmVkIGJldHdlZW4gaXQgYW5kIGl0cyBcInJ1bGUgcGFyZW50XCJcblxuXG4gIGlmIChpc0ltcGxpY2l0UnVsZSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGZpeGVkRWxlbWVudHMuc2V0KGVsZW1lbnQsIHRydWUpO1xuICB2YXIgcG9pbnRzID0gW107XG4gIHZhciBydWxlcyA9IGdldFJ1bGVzKHZhbHVlLCBwb2ludHMpO1xuICB2YXIgcGFyZW50UnVsZXMgPSBwYXJlbnQucHJvcHM7XG5cbiAgZm9yICh2YXIgaSA9IDAsIGsgPSAwOyBpIDwgcnVsZXMubGVuZ3RoOyBpKyspIHtcbiAgICBmb3IgKHZhciBqID0gMDsgaiA8IHBhcmVudFJ1bGVzLmxlbmd0aDsgaisrLCBrKyspIHtcbiAgICAgIGVsZW1lbnQucHJvcHNba10gPSBwb2ludHNbaV0gPyBydWxlc1tpXS5yZXBsYWNlKC8mXFxmL2csIHBhcmVudFJ1bGVzW2pdKSA6IHBhcmVudFJ1bGVzW2pdICsgXCIgXCIgKyBydWxlc1tpXTtcbiAgICB9XG4gIH1cbn07XG52YXIgcmVtb3ZlTGFiZWwgPSBmdW5jdGlvbiByZW1vdmVMYWJlbChlbGVtZW50KSB7XG4gIGlmIChlbGVtZW50LnR5cGUgPT09ICdkZWNsJykge1xuICAgIHZhciB2YWx1ZSA9IGVsZW1lbnQudmFsdWU7XG5cbiAgICBpZiAoIC8vIGNoYXJjb2RlIGZvciBsXG4gICAgdmFsdWUuY2hhckNvZGVBdCgwKSA9PT0gMTA4ICYmIC8vIGNoYXJjb2RlIGZvciBiXG4gICAgdmFsdWUuY2hhckNvZGVBdCgyKSA9PT0gOTgpIHtcbiAgICAgIC8vIHRoaXMgaWdub3JlcyBsYWJlbFxuICAgICAgZWxlbWVudFtcInJldHVyblwiXSA9ICcnO1xuICAgICAgZWxlbWVudC52YWx1ZSA9ICcnO1xuICAgIH1cbiAgfVxufTtcbnZhciBpZ25vcmVGbGFnID0gJ2Vtb3Rpb24tZGlzYWJsZS1zZXJ2ZXItcmVuZGVyaW5nLXVuc2FmZS1zZWxlY3Rvci13YXJuaW5nLXBsZWFzZS1kby1ub3QtdXNlLXRoaXMtdGhlLXdhcm5pbmctZXhpc3RzLWZvci1hLXJlYXNvbic7XG5cbnZhciBpc0lnbm9yaW5nQ29tbWVudCA9IGZ1bmN0aW9uIGlzSWdub3JpbmdDb21tZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQudHlwZSA9PT0gJ2NvbW0nICYmIGVsZW1lbnQuY2hpbGRyZW4uaW5kZXhPZihpZ25vcmVGbGFnKSA+IC0xO1xufTtcblxudmFyIGNyZWF0ZVVuc2FmZVNlbGVjdG9yc0FsYXJtID0gZnVuY3Rpb24gY3JlYXRlVW5zYWZlU2VsZWN0b3JzQWxhcm0oY2FjaGUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChlbGVtZW50LCBpbmRleCwgY2hpbGRyZW4pIHtcbiAgICBpZiAoZWxlbWVudC50eXBlICE9PSAncnVsZScgfHwgY2FjaGUuY29tcGF0KSByZXR1cm47XG4gICAgdmFyIHVuc2FmZVBzZXVkb0NsYXNzZXMgPSBlbGVtZW50LnZhbHVlLm1hdGNoKC8oOmZpcnN0fDpudGh8Om50aC1sYXN0KS1jaGlsZC9nKTtcblxuICAgIGlmICh1bnNhZmVQc2V1ZG9DbGFzc2VzKSB7XG4gICAgICB2YXIgaXNOZXN0ZWQgPSAhIWVsZW1lbnQucGFyZW50OyAvLyBpbiBuZXN0ZWQgcnVsZXMgY29tbWVudHMgYmVjb21lIGNoaWxkcmVuIG9mIHRoZSBcImF1dG8taW5zZXJ0ZWRcIiBydWxlIGFuZCB0aGF0J3MgYWx3YXlzIHRoZSBgZWxlbWVudC5wYXJlbnRgXG4gICAgICAvL1xuICAgICAgLy8gY29uc2lkZXJpbmcgdGhpcyBpbnB1dDpcbiAgICAgIC8vIC5hIHtcbiAgICAgIC8vICAgLmIgLyogY29tbSAqLyB7fVxuICAgICAgLy8gICBjb2xvcjogaG90cGluaztcbiAgICAgIC8vIH1cbiAgICAgIC8vIHdlIGdldCBvdXRwdXQgY29ycmVzcG9uZGluZyB0byB0aGlzOlxuICAgICAgLy8gLmEge1xuICAgICAgLy8gICAmIHtcbiAgICAgIC8vICAgICAvKiBjb21tICovXG4gICAgICAvLyAgICAgY29sb3I6IGhvdHBpbms7XG4gICAgICAvLyAgIH1cbiAgICAgIC8vICAgLmIge31cbiAgICAgIC8vIH1cblxuICAgICAgdmFyIGNvbW1lbnRDb250YWluZXIgPSBpc05lc3RlZCA/IGVsZW1lbnQucGFyZW50LmNoaWxkcmVuIDogLy8gZ2xvYmFsIHJ1bGUgYXQgdGhlIHJvb3QgbGV2ZWxcbiAgICAgIGNoaWxkcmVuO1xuXG4gICAgICBmb3IgKHZhciBpID0gY29tbWVudENvbnRhaW5lci5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICB2YXIgbm9kZSA9IGNvbW1lbnRDb250YWluZXJbaV07XG5cbiAgICAgICAgaWYgKG5vZGUubGluZSA8IGVsZW1lbnQubGluZSkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9IC8vIGl0IGlzIHF1aXRlIHdlaXJkIGJ1dCBjb21tZW50cyBhcmUgKnVzdWFsbHkqIHB1dCBhdCBgY29sdW1uOiBlbGVtZW50LmNvbHVtbiAtIDFgXG4gICAgICAgIC8vIHNvIHdlIHNlZWsgKmZyb20gdGhlIGVuZCogZm9yIHRoZSBub2RlIHRoYXQgaXMgZWFybGllciB0aGFuIHRoZSBydWxlJ3MgYGVsZW1lbnRgIGFuZCBjaGVjayB0aGF0XG4gICAgICAgIC8vIHRoaXMgd2lsbCBhbHNvIG1hdGNoIGlucHV0cyBsaWtlIHRoaXM6XG4gICAgICAgIC8vIC5hIHtcbiAgICAgICAgLy8gICAvKiBjb21tICovXG4gICAgICAgIC8vICAgLmIge31cbiAgICAgICAgLy8gfVxuICAgICAgICAvL1xuICAgICAgICAvLyBidXQgdGhhdCBpcyBmaW5lXG4gICAgICAgIC8vXG4gICAgICAgIC8vIGl0IHdvdWxkIGJlIHRoZSBlYXNpZXN0IHRvIGNoYW5nZSB0aGUgcGxhY2VtZW50IG9mIHRoZSBjb21tZW50IHRvIGJlIHRoZSBmaXJzdCBjaGlsZCBvZiB0aGUgcnVsZTpcbiAgICAgICAgLy8gLmEge1xuICAgICAgICAvLyAgIC5iIHsgLyogY29tbSAqLyB9XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gd2l0aCBzdWNoIGlucHV0cyB3ZSB3b3VsZG4ndCBoYXZlIHRvIHNlYXJjaCBmb3IgdGhlIGNvbW1lbnQgYXQgYWxsXG4gICAgICAgIC8vIFRPRE86IGNvbnNpZGVyIGNoYW5naW5nIHRoaXMgY29tbWVudCBwbGFjZW1lbnQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvblxuXG5cbiAgICAgICAgaWYgKG5vZGUuY29sdW1uIDwgZWxlbWVudC5jb2x1bW4pIHtcbiAgICAgICAgICBpZiAoaXNJZ25vcmluZ0NvbW1lbnQobm9kZSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB1bnNhZmVQc2V1ZG9DbGFzc2VzLmZvckVhY2goZnVuY3Rpb24gKHVuc2FmZVBzZXVkb0NsYXNzKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJUaGUgcHNldWRvIGNsYXNzIFxcXCJcIiArIHVuc2FmZVBzZXVkb0NsYXNzICsgXCJcXFwiIGlzIHBvdGVudGlhbGx5IHVuc2FmZSB3aGVuIGRvaW5nIHNlcnZlci1zaWRlIHJlbmRlcmluZy4gVHJ5IGNoYW5naW5nIGl0IHRvIFxcXCJcIiArIHVuc2FmZVBzZXVkb0NsYXNzLnNwbGl0KCctY2hpbGQnKVswXSArIFwiLW9mLXR5cGVcXFwiLlwiKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn07XG5cbnZhciBpc0ltcG9ydFJ1bGUgPSBmdW5jdGlvbiBpc0ltcG9ydFJ1bGUoZWxlbWVudCkge1xuICByZXR1cm4gZWxlbWVudC50eXBlLmNoYXJDb2RlQXQoMSkgPT09IDEwNSAmJiBlbGVtZW50LnR5cGUuY2hhckNvZGVBdCgwKSA9PT0gNjQ7XG59O1xuXG52YXIgaXNQcmVwZW5kZWRXaXRoUmVndWxhclJ1bGVzID0gZnVuY3Rpb24gaXNQcmVwZW5kZWRXaXRoUmVndWxhclJ1bGVzKGluZGV4LCBjaGlsZHJlbikge1xuICBmb3IgKHZhciBpID0gaW5kZXggLSAxOyBpID49IDA7IGktLSkge1xuICAgIGlmICghaXNJbXBvcnRSdWxlKGNoaWxkcmVuW2ldKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufTsgLy8gdXNlIHRoaXMgdG8gcmVtb3ZlIGluY29ycmVjdCBlbGVtZW50cyBmcm9tIGZ1cnRoZXIgcHJvY2Vzc2luZ1xuLy8gc28gdGhleSBkb24ndCBnZXQgaGFuZGVkIHRvIHRoZSBgc2hlZXRgIChvciBhbnl0aGluZyBlbHNlKVxuLy8gYXMgdGhhdCBjb3VsZCBwb3RlbnRpYWxseSBsZWFkIHRvIGFkZGl0aW9uYWwgbG9ncyB3aGljaCBpbiB0dXJuIGNvdWxkIGJlIG92ZXJoZWxtaW5nIHRvIHRoZSB1c2VyXG5cblxudmFyIG51bGxpZnlFbGVtZW50ID0gZnVuY3Rpb24gbnVsbGlmeUVsZW1lbnQoZWxlbWVudCkge1xuICBlbGVtZW50LnR5cGUgPSAnJztcbiAgZWxlbWVudC52YWx1ZSA9ICcnO1xuICBlbGVtZW50W1wicmV0dXJuXCJdID0gJyc7XG4gIGVsZW1lbnQuY2hpbGRyZW4gPSAnJztcbiAgZWxlbWVudC5wcm9wcyA9ICcnO1xufTtcblxudmFyIGluY29ycmVjdEltcG9ydEFsYXJtID0gZnVuY3Rpb24gaW5jb3JyZWN0SW1wb3J0QWxhcm0oZWxlbWVudCwgaW5kZXgsIGNoaWxkcmVuKSB7XG4gIGlmICghaXNJbXBvcnRSdWxlKGVsZW1lbnQpKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGVsZW1lbnQucGFyZW50KSB7XG4gICAgY29uc29sZS5lcnJvcihcImBAaW1wb3J0YCBydWxlcyBjYW4ndCBiZSBuZXN0ZWQgaW5zaWRlIG90aGVyIHJ1bGVzLiBQbGVhc2UgbW92ZSBpdCB0byB0aGUgdG9wIGxldmVsIGFuZCBwdXQgaXQgYmVmb3JlIHJlZ3VsYXIgcnVsZXMuIEtlZXAgaW4gbWluZCB0aGF0IHRoZXkgY2FuIG9ubHkgYmUgdXNlZCB3aXRoaW4gZ2xvYmFsIHN0eWxlcy5cIik7XG4gICAgbnVsbGlmeUVsZW1lbnQoZWxlbWVudCk7XG4gIH0gZWxzZSBpZiAoaXNQcmVwZW5kZWRXaXRoUmVndWxhclJ1bGVzKGluZGV4LCBjaGlsZHJlbikpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiYEBpbXBvcnRgIHJ1bGVzIGNhbid0IGJlIGFmdGVyIG90aGVyIHJ1bGVzLiBQbGVhc2UgcHV0IHlvdXIgYEBpbXBvcnRgIHJ1bGVzIGJlZm9yZSB5b3VyIG90aGVyIHJ1bGVzLlwiKTtcbiAgICBudWxsaWZ5RWxlbWVudChlbGVtZW50KTtcbiAgfVxufTtcblxuLyogZXNsaW50LWRpc2FibGUgbm8tZmFsbHRocm91Z2ggKi9cblxuZnVuY3Rpb24gcHJlZml4KHZhbHVlLCBsZW5ndGgpIHtcbiAgc3dpdGNoIChoYXNoKHZhbHVlLCBsZW5ndGgpKSB7XG4gICAgLy8gY29sb3ItYWRqdXN0XG4gICAgY2FzZSA1MTAzOlxuICAgICAgcmV0dXJuIFdFQktJVCArICdwcmludC0nICsgdmFsdWUgKyB2YWx1ZTtcbiAgICAvLyBhbmltYXRpb24sIGFuaW1hdGlvbi0oZGVsYXl8ZGlyZWN0aW9ufGR1cmF0aW9ufGZpbGwtbW9kZXxpdGVyYXRpb24tY291bnR8bmFtZXxwbGF5LXN0YXRlfHRpbWluZy1mdW5jdGlvbilcblxuICAgIGNhc2UgNTczNzpcbiAgICBjYXNlIDQyMDE6XG4gICAgY2FzZSAzMTc3OlxuICAgIGNhc2UgMzQzMzpcbiAgICBjYXNlIDE2NDE6XG4gICAgY2FzZSA0NDU3OlxuICAgIGNhc2UgMjkyMTogLy8gdGV4dC1kZWNvcmF0aW9uLCBmaWx0ZXIsIGNsaXAtcGF0aCwgYmFja2ZhY2UtdmlzaWJpbGl0eSwgY29sdW1uLCBib3gtZGVjb3JhdGlvbi1icmVha1xuXG4gICAgY2FzZSA1NTcyOlxuICAgIGNhc2UgNjM1NjpcbiAgICBjYXNlIDU4NDQ6XG4gICAgY2FzZSAzMTkxOlxuICAgIGNhc2UgNjY0NTpcbiAgICBjYXNlIDMwMDU6IC8vIG1hc2ssIG1hc2staW1hZ2UsIG1hc2stKG1vZGV8Y2xpcHxzaXplKSwgbWFzay0ocmVwZWF0fG9yaWdpbiksIG1hc2stcG9zaXRpb24sIG1hc2stY29tcG9zaXRlLFxuXG4gICAgY2FzZSA2MzkxOlxuICAgIGNhc2UgNTg3OTpcbiAgICBjYXNlIDU2MjM6XG4gICAgY2FzZSA2MTM1OlxuICAgIGNhc2UgNDU5OTpcbiAgICBjYXNlIDQ4NTU6IC8vIGJhY2tncm91bmQtY2xpcCwgY29sdW1ucywgY29sdW1uLShjb3VudHxmaWxsfGdhcHxydWxlfHJ1bGUtY29sb3J8cnVsZS1zdHlsZXxydWxlLXdpZHRofHNwYW58d2lkdGgpXG5cbiAgICBjYXNlIDQyMTU6XG4gICAgY2FzZSA2Mzg5OlxuICAgIGNhc2UgNTEwOTpcbiAgICBjYXNlIDUzNjU6XG4gICAgY2FzZSA1NjIxOlxuICAgIGNhc2UgMzgyOTpcbiAgICAgIHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIHZhbHVlO1xuICAgIC8vIGFwcGVhcmFuY2UsIHVzZXItc2VsZWN0LCB0cmFuc2Zvcm0sIGh5cGhlbnMsIHRleHQtc2l6ZS1hZGp1c3RcblxuICAgIGNhc2UgNTM0OTpcbiAgICBjYXNlIDQyNDY6XG4gICAgY2FzZSA0ODEwOlxuICAgIGNhc2UgNjk2ODpcbiAgICBjYXNlIDI3NTY6XG4gICAgICByZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNT1ogKyB2YWx1ZSArIE1TICsgdmFsdWUgKyB2YWx1ZTtcbiAgICAvLyBmbGV4LCBmbGV4LWRpcmVjdGlvblxuXG4gICAgY2FzZSA2ODI4OlxuICAgIGNhc2UgNDI2ODpcbiAgICAgIHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgdmFsdWUgKyB2YWx1ZTtcbiAgICAvLyBvcmRlclxuXG4gICAgY2FzZSA2MTY1OlxuICAgICAgcmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyAnZmxleC0nICsgdmFsdWUgKyB2YWx1ZTtcbiAgICAvLyBhbGlnbi1pdGVtc1xuXG4gICAgY2FzZSA1MTg3OlxuICAgICAgcmV0dXJuIFdFQktJVCArIHZhbHVlICsgcmVwbGFjZSh2YWx1ZSwgLyhcXHcrKS4rKDpbXl0rKS8sIFdFQktJVCArICdib3gtJDEkMicgKyBNUyArICdmbGV4LSQxJDInKSArIHZhbHVlO1xuICAgIC8vIGFsaWduLXNlbGZcblxuICAgIGNhc2UgNTQ0MzpcbiAgICAgIHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgJ2ZsZXgtaXRlbS0nICsgcmVwbGFjZSh2YWx1ZSwgL2ZsZXgtfC1zZWxmLywgJycpICsgdmFsdWU7XG4gICAgLy8gYWxpZ24tY29udGVudFxuXG4gICAgY2FzZSA0Njc1OlxuICAgICAgcmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyAnZmxleC1saW5lLXBhY2snICsgcmVwbGFjZSh2YWx1ZSwgL2FsaWduLWNvbnRlbnR8ZmxleC18LXNlbGYvLCAnJykgKyB2YWx1ZTtcbiAgICAvLyBmbGV4LXNocmlua1xuXG4gICAgY2FzZSA1NTQ4OlxuICAgICAgcmV0dXJuIFdFQktJVCArIHZhbHVlICsgTVMgKyByZXBsYWNlKHZhbHVlLCAnc2hyaW5rJywgJ25lZ2F0aXZlJykgKyB2YWx1ZTtcbiAgICAvLyBmbGV4LWJhc2lzXG5cbiAgICBjYXNlIDUyOTI6XG4gICAgICByZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNUyArIHJlcGxhY2UodmFsdWUsICdiYXNpcycsICdwcmVmZXJyZWQtc2l6ZScpICsgdmFsdWU7XG4gICAgLy8gZmxleC1ncm93XG5cbiAgICBjYXNlIDYwNjA6XG4gICAgICByZXR1cm4gV0VCS0lUICsgJ2JveC0nICsgcmVwbGFjZSh2YWx1ZSwgJy1ncm93JywgJycpICsgV0VCS0lUICsgdmFsdWUgKyBNUyArIHJlcGxhY2UodmFsdWUsICdncm93JywgJ3Bvc2l0aXZlJykgKyB2YWx1ZTtcbiAgICAvLyB0cmFuc2l0aW9uXG5cbiAgICBjYXNlIDQ1NTQ6XG4gICAgICByZXR1cm4gV0VCS0lUICsgcmVwbGFjZSh2YWx1ZSwgLyhbXi1dKSh0cmFuc2Zvcm0pL2csICckMScgKyBXRUJLSVQgKyAnJDInKSArIHZhbHVlO1xuICAgIC8vIGN1cnNvclxuXG4gICAgY2FzZSA2MTg3OlxuICAgICAgcmV0dXJuIHJlcGxhY2UocmVwbGFjZShyZXBsYWNlKHZhbHVlLCAvKHpvb20tfGdyYWIpLywgV0VCS0lUICsgJyQxJyksIC8oaW1hZ2Utc2V0KS8sIFdFQktJVCArICckMScpLCB2YWx1ZSwgJycpICsgdmFsdWU7XG4gICAgLy8gYmFja2dyb3VuZCwgYmFja2dyb3VuZC1pbWFnZVxuXG4gICAgY2FzZSA1NDk1OlxuICAgIGNhc2UgMzk1OTpcbiAgICAgIHJldHVybiByZXBsYWNlKHZhbHVlLCAvKGltYWdlLXNldFxcKFteXSopLywgV0VCS0lUICsgJyQxJyArICckYCQxJyk7XG4gICAgLy8ganVzdGlmeS1jb250ZW50XG5cbiAgICBjYXNlIDQ5Njg6XG4gICAgICByZXR1cm4gcmVwbGFjZShyZXBsYWNlKHZhbHVlLCAvKC4rOikoZmxleC0pPyguKikvLCBXRUJLSVQgKyAnYm94LXBhY2s6JDMnICsgTVMgKyAnZmxleC1wYWNrOiQzJyksIC9zListYlteO10rLywgJ2p1c3RpZnknKSArIFdFQktJVCArIHZhbHVlICsgdmFsdWU7XG4gICAgLy8gKG1hcmdpbnxwYWRkaW5nKS1pbmxpbmUtKHN0YXJ0fGVuZClcblxuICAgIGNhc2UgNDA5NTpcbiAgICBjYXNlIDM1ODM6XG4gICAgY2FzZSA0MDY4OlxuICAgIGNhc2UgMjUzMjpcbiAgICAgIHJldHVybiByZXBsYWNlKHZhbHVlLCAvKC4rKS1pbmxpbmUoLispLywgV0VCS0lUICsgJyQxJDInKSArIHZhbHVlO1xuICAgIC8vIChtaW58bWF4KT8od2lkdGh8aGVpZ2h0fGlubGluZS1zaXplfGJsb2NrLXNpemUpXG5cbiAgICBjYXNlIDgxMTY6XG4gICAgY2FzZSA3MDU5OlxuICAgIGNhc2UgNTc1MzpcbiAgICBjYXNlIDU1MzU6XG4gICAgY2FzZSA1NDQ1OlxuICAgIGNhc2UgNTcwMTpcbiAgICBjYXNlIDQ5MzM6XG4gICAgY2FzZSA0Njc3OlxuICAgIGNhc2UgNTUzMzpcbiAgICBjYXNlIDU3ODk6XG4gICAgY2FzZSA1MDIxOlxuICAgIGNhc2UgNDc2NTpcbiAgICAgIC8vIHN0cmV0Y2gsIG1heC1jb250ZW50LCBtaW4tY29udGVudCwgZmlsbC1hdmFpbGFibGVcbiAgICAgIGlmIChzdHJsZW4odmFsdWUpIC0gMSAtIGxlbmd0aCA+IDYpIHN3aXRjaCAoY2hhcmF0KHZhbHVlLCBsZW5ndGggKyAxKSkge1xuICAgICAgICAvLyAobSlheC1jb250ZW50LCAobSlpbi1jb250ZW50XG4gICAgICAgIGNhc2UgMTA5OlxuICAgICAgICAgIC8vIC1cbiAgICAgICAgICBpZiAoY2hhcmF0KHZhbHVlLCBsZW5ndGggKyA0KSAhPT0gNDUpIGJyZWFrO1xuICAgICAgICAvLyAoZilpbGwtYXZhaWxhYmxlLCAoZilpdC1jb250ZW50XG5cbiAgICAgICAgY2FzZSAxMDI6XG4gICAgICAgICAgcmV0dXJuIHJlcGxhY2UodmFsdWUsIC8oLis6KSguKyktKFteXSspLywgJyQxJyArIFdFQktJVCArICckMi0kMycgKyAnJDEnICsgTU9aICsgKGNoYXJhdCh2YWx1ZSwgbGVuZ3RoICsgMykgPT0gMTA4ID8gJyQzJyA6ICckMi0kMycpKSArIHZhbHVlO1xuICAgICAgICAvLyAocyl0cmV0Y2hcblxuICAgICAgICBjYXNlIDExNTpcbiAgICAgICAgICByZXR1cm4gfmluZGV4b2YodmFsdWUsICdzdHJldGNoJykgPyBwcmVmaXgocmVwbGFjZSh2YWx1ZSwgJ3N0cmV0Y2gnLCAnZmlsbC1hdmFpbGFibGUnKSwgbGVuZ3RoKSArIHZhbHVlIDogdmFsdWU7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICAvLyBwb3NpdGlvbjogc3RpY2t5XG5cbiAgICBjYXNlIDQ5NDk6XG4gICAgICAvLyAocyl0aWNreT9cbiAgICAgIGlmIChjaGFyYXQodmFsdWUsIGxlbmd0aCArIDEpICE9PSAxMTUpIGJyZWFrO1xuICAgIC8vIGRpc3BsYXk6IChmbGV4fGlubGluZS1mbGV4KVxuXG4gICAgY2FzZSA2NDQ0OlxuICAgICAgc3dpdGNoIChjaGFyYXQodmFsdWUsIHN0cmxlbih2YWx1ZSkgLSAzIC0gKH5pbmRleG9mKHZhbHVlLCAnIWltcG9ydGFudCcpICYmIDEwKSkpIHtcbiAgICAgICAgLy8gc3RpYyhrKXlcbiAgICAgICAgY2FzZSAxMDc6XG4gICAgICAgICAgcmV0dXJuIHJlcGxhY2UodmFsdWUsICc6JywgJzonICsgV0VCS0lUKSArIHZhbHVlO1xuICAgICAgICAvLyAoaW5saW5lLSk/ZmwoZSl4XG5cbiAgICAgICAgY2FzZSAxMDE6XG4gICAgICAgICAgcmV0dXJuIHJlcGxhY2UodmFsdWUsIC8oLis6KShbXjshXSspKDt8IS4rKT8vLCAnJDEnICsgV0VCS0lUICsgKGNoYXJhdCh2YWx1ZSwgMTQpID09PSA0NSA/ICdpbmxpbmUtJyA6ICcnKSArICdib3gkMycgKyAnJDEnICsgV0VCS0lUICsgJyQyJDMnICsgJyQxJyArIE1TICsgJyQyYm94JDMnKSArIHZhbHVlO1xuICAgICAgfVxuXG4gICAgICBicmVhaztcbiAgICAvLyB3cml0aW5nLW1vZGVcblxuICAgIGNhc2UgNTkzNjpcbiAgICAgIHN3aXRjaCAoY2hhcmF0KHZhbHVlLCBsZW5ndGggKyAxMSkpIHtcbiAgICAgICAgLy8gdmVydGljYWwtbChyKVxuICAgICAgICBjYXNlIDExNDpcbiAgICAgICAgICByZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNUyArIHJlcGxhY2UodmFsdWUsIC9bc3ZoXVxcdystW3RibHJdezJ9LywgJ3RiJykgKyB2YWx1ZTtcbiAgICAgICAgLy8gdmVydGljYWwtcihsKVxuXG4gICAgICAgIGNhc2UgMTA4OlxuICAgICAgICAgIHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgcmVwbGFjZSh2YWx1ZSwgL1tzdmhdXFx3Ky1bdGJscl17Mn0vLCAndGItcmwnKSArIHZhbHVlO1xuICAgICAgICAvLyBob3Jpem9udGFsKC0pdGJcblxuICAgICAgICBjYXNlIDQ1OlxuICAgICAgICAgIHJldHVybiBXRUJLSVQgKyB2YWx1ZSArIE1TICsgcmVwbGFjZSh2YWx1ZSwgL1tzdmhdXFx3Ky1bdGJscl17Mn0vLCAnbHInKSArIHZhbHVlO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gV0VCS0lUICsgdmFsdWUgKyBNUyArIHZhbHVlICsgdmFsdWU7XG4gIH1cblxuICByZXR1cm4gdmFsdWU7XG59XG5cbnZhciBwcmVmaXhlciA9IGZ1bmN0aW9uIHByZWZpeGVyKGVsZW1lbnQsIGluZGV4LCBjaGlsZHJlbiwgY2FsbGJhY2spIHtcbiAgaWYgKGVsZW1lbnQubGVuZ3RoID4gLTEpIGlmICghZWxlbWVudFtcInJldHVyblwiXSkgc3dpdGNoIChlbGVtZW50LnR5cGUpIHtcbiAgICBjYXNlIERFQ0xBUkFUSU9OOlxuICAgICAgZWxlbWVudFtcInJldHVyblwiXSA9IHByZWZpeChlbGVtZW50LnZhbHVlLCBlbGVtZW50Lmxlbmd0aCk7XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgS0VZRlJBTUVTOlxuICAgICAgcmV0dXJuIHNlcmlhbGl6ZShbY29weShlbGVtZW50LCB7XG4gICAgICAgIHZhbHVlOiByZXBsYWNlKGVsZW1lbnQudmFsdWUsICdAJywgJ0AnICsgV0VCS0lUKVxuICAgICAgfSldLCBjYWxsYmFjayk7XG5cbiAgICBjYXNlIFJVTEVTRVQ6XG4gICAgICBpZiAoZWxlbWVudC5sZW5ndGgpIHJldHVybiBjb21iaW5lKGVsZW1lbnQucHJvcHMsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICBzd2l0Y2ggKG1hdGNoKHZhbHVlLCAvKDo6cGxhY1xcdyt8OnJlYWQtXFx3KykvKSkge1xuICAgICAgICAgIC8vIDpyZWFkLShvbmx5fHdyaXRlKVxuICAgICAgICAgIGNhc2UgJzpyZWFkLW9ubHknOlxuICAgICAgICAgIGNhc2UgJzpyZWFkLXdyaXRlJzpcbiAgICAgICAgICAgIHJldHVybiBzZXJpYWxpemUoW2NvcHkoZWxlbWVudCwge1xuICAgICAgICAgICAgICBwcm9wczogW3JlcGxhY2UodmFsdWUsIC86KHJlYWQtXFx3KykvLCAnOicgKyBNT1ogKyAnJDEnKV1cbiAgICAgICAgICAgIH0pXSwgY2FsbGJhY2spO1xuICAgICAgICAgIC8vIDpwbGFjZWhvbGRlclxuXG4gICAgICAgICAgY2FzZSAnOjpwbGFjZWhvbGRlcic6XG4gICAgICAgICAgICByZXR1cm4gc2VyaWFsaXplKFtjb3B5KGVsZW1lbnQsIHtcbiAgICAgICAgICAgICAgcHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBXRUJLSVQgKyAnaW5wdXQtJDEnKV1cbiAgICAgICAgICAgIH0pLCBjb3B5KGVsZW1lbnQsIHtcbiAgICAgICAgICAgICAgcHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCAnOicgKyBNT1ogKyAnJDEnKV1cbiAgICAgICAgICAgIH0pLCBjb3B5KGVsZW1lbnQsIHtcbiAgICAgICAgICAgICAgcHJvcHM6IFtyZXBsYWNlKHZhbHVlLCAvOihwbGFjXFx3KykvLCBNUyArICdpbnB1dC0kMScpXVxuICAgICAgICAgICAgfSldLCBjYWxsYmFjayk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gJyc7XG4gICAgICB9KTtcbiAgfVxufTtcblxudmFyIGRlZmF1bHRTdHlsaXNQbHVnaW5zID0gW3ByZWZpeGVyXTtcbnZhciBnZXRTb3VyY2VNYXA7XG5cbntcbiAgdmFyIHNvdXJjZU1hcFBhdHRlcm4gPSAvXFwvXFwqI1xcc3NvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvblxcL2pzb247XFxTK1xccytcXCpcXC8vZztcblxuICBnZXRTb3VyY2VNYXAgPSBmdW5jdGlvbiBnZXRTb3VyY2VNYXAoc3R5bGVzKSB7XG4gICAgdmFyIG1hdGNoZXMgPSBzdHlsZXMubWF0Y2goc291cmNlTWFwUGF0dGVybik7XG4gICAgaWYgKCFtYXRjaGVzKSByZXR1cm47XG4gICAgcmV0dXJuIG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXTtcbiAgfTtcbn1cblxudmFyIGNyZWF0ZUNhY2hlID0gZnVuY3Rpb24gY3JlYXRlQ2FjaGUob3B0aW9ucykge1xuICB2YXIga2V5ID0gb3B0aW9ucy5rZXk7XG5cbiAgaWYgKCFrZXkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJZb3UgaGF2ZSB0byBjb25maWd1cmUgYGtleWAgZm9yIHlvdXIgY2FjaGUuIFBsZWFzZSBtYWtlIHN1cmUgaXQncyB1bmlxdWUgKGFuZCBub3QgZXF1YWwgdG8gJ2NzcycpIGFzIGl0J3MgdXNlZCBmb3IgbGlua2luZyBzdHlsZXMgdG8geW91ciBjYWNoZS5cXG5cIiArIFwiSWYgbXVsdGlwbGUgY2FjaGVzIHNoYXJlIHRoZSBzYW1lIGtleSB0aGV5IG1pZ2h0IFxcXCJmaWdodFxcXCIgZm9yIGVhY2ggb3RoZXIncyBzdHlsZSBlbGVtZW50cy5cIik7XG4gIH1cblxuICBpZiAoa2V5ID09PSAnY3NzJykge1xuICAgIHZhciBzc3JTdHlsZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwic3R5bGVbZGF0YS1lbW90aW9uXTpub3QoW2RhdGEtc10pXCIpOyAvLyBnZXQgU1NSZWQgc3R5bGVzIG91dCBvZiB0aGUgd2F5IG9mIFJlYWN0J3MgaHlkcmF0aW9uXG4gICAgLy8gZG9jdW1lbnQuaGVhZCBpcyBhIHNhZmUgcGxhY2UgdG8gbW92ZSB0aGVtIHRvKHRob3VnaCBub3RlIGRvY3VtZW50LmhlYWQgaXMgbm90IG5lY2Vzc2FyaWx5IHRoZSBsYXN0IHBsYWNlIHRoZXkgd2lsbCBiZSlcbiAgICAvLyBub3RlIHRoaXMgdmVyeSB2ZXJ5IGludGVudGlvbmFsbHkgdGFyZ2V0cyBhbGwgc3R5bGUgZWxlbWVudHMgcmVnYXJkbGVzcyBvZiB0aGUga2V5IHRvIGVuc3VyZVxuICAgIC8vIHRoYXQgY3JlYXRpbmcgYSBjYWNoZSB3b3JrcyBpbnNpZGUgb2YgcmVuZGVyIG9mIGEgUmVhY3QgY29tcG9uZW50XG5cbiAgICBBcnJheS5wcm90b3R5cGUuZm9yRWFjaC5jYWxsKHNzclN0eWxlcywgZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAgIC8vIHdlIHdhbnQgdG8gb25seSBtb3ZlIGVsZW1lbnRzIHdoaWNoIGhhdmUgYSBzcGFjZSBpbiB0aGUgZGF0YS1lbW90aW9uIGF0dHJpYnV0ZSB2YWx1ZVxuICAgICAgLy8gYmVjYXVzZSB0aGF0IGluZGljYXRlcyB0aGF0IGl0IGlzIGFuIEVtb3Rpb24gMTEgc2VydmVyLXNpZGUgcmVuZGVyZWQgc3R5bGUgZWxlbWVudHNcbiAgICAgIC8vIHdoaWxlIHdlIHdpbGwgYWxyZWFkeSBpZ25vcmUgRW1vdGlvbiAxMSBjbGllbnQtc2lkZSBpbnNlcnRlZCBzdHlsZXMgYmVjYXVzZSBvZiB0aGUgOm5vdChbZGF0YS1zXSkgcGFydCBpbiB0aGUgc2VsZWN0b3JcbiAgICAgIC8vIEVtb3Rpb24gMTAgY2xpZW50LXNpZGUgaW5zZXJ0ZWQgc3R5bGVzIGRpZCBub3QgaGF2ZSBkYXRhLXMgKGJ1dCBpbXBvcnRhbnRseSBkaWQgbm90IGhhdmUgYSBzcGFjZSBpbiB0aGVpciBkYXRhLWVtb3Rpb24gYXR0cmlidXRlcylcbiAgICAgIC8vIHNvIGNoZWNraW5nIGZvciB0aGUgc3BhY2UgZW5zdXJlcyB0aGF0IGxvYWRpbmcgRW1vdGlvbiAxMSBhZnRlciBFbW90aW9uIDEwIGhhcyBpbnNlcnRlZCBzb21lIHN0eWxlc1xuICAgICAgLy8gd2lsbCBub3QgcmVzdWx0IGluIHRoZSBFbW90aW9uIDEwIHN0eWxlcyBiZWluZyBkZXN0cm95ZWRcbiAgICAgIHZhciBkYXRhRW1vdGlvbkF0dHJpYnV0ZSA9IG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWVtb3Rpb24nKTtcblxuICAgICAgaWYgKGRhdGFFbW90aW9uQXR0cmlidXRlLmluZGV4T2YoJyAnKSA9PT0gLTEpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKG5vZGUpO1xuICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2RhdGEtcycsICcnKTtcbiAgICB9KTtcbiAgfVxuXG4gIHZhciBzdHlsaXNQbHVnaW5zID0gb3B0aW9ucy5zdHlsaXNQbHVnaW5zIHx8IGRlZmF1bHRTdHlsaXNQbHVnaW5zO1xuXG4gIHtcbiAgICBpZiAoL1teYS16LV0vLnRlc3Qoa2V5KSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRW1vdGlvbiBrZXkgbXVzdCBvbmx5IGNvbnRhaW4gbG93ZXIgY2FzZSBhbHBoYWJldGljYWwgY2hhcmFjdGVycyBhbmQgLSBidXQgXFxcIlwiICsga2V5ICsgXCJcXFwiIHdhcyBwYXNzZWRcIik7XG4gICAgfVxuICB9XG5cbiAgdmFyIGluc2VydGVkID0ge307XG4gIHZhciBjb250YWluZXI7XG4gIHZhciBub2Rlc1RvSHlkcmF0ZSA9IFtdO1xuXG4gIHtcbiAgICBjb250YWluZXIgPSBvcHRpb25zLmNvbnRhaW5lciB8fCBkb2N1bWVudC5oZWFkO1xuICAgIEFycmF5LnByb3RvdHlwZS5mb3JFYWNoLmNhbGwoIC8vIHRoaXMgbWVhbnMgd2Ugd2lsbCBpZ25vcmUgZWxlbWVudHMgd2hpY2ggZG9uJ3QgaGF2ZSBhIHNwYWNlIGluIHRoZW0gd2hpY2hcbiAgICAvLyBtZWFucyB0aGF0IHRoZSBzdHlsZSBlbGVtZW50cyB3ZSdyZSBsb29raW5nIGF0IGFyZSBvbmx5IEVtb3Rpb24gMTEgc2VydmVyLXJlbmRlcmVkIHN0eWxlIGVsZW1lbnRzXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcInN0eWxlW2RhdGEtZW1vdGlvbl49XFxcIlwiICsga2V5ICsgXCIgXFxcIl1cIiksIGZ1bmN0aW9uIChub2RlKSB7XG4gICAgICB2YXIgYXR0cmliID0gbm9kZS5nZXRBdHRyaWJ1dGUoXCJkYXRhLWVtb3Rpb25cIikuc3BsaXQoJyAnKTtcblxuICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhdHRyaWIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaW5zZXJ0ZWRbYXR0cmliW2ldXSA9IHRydWU7XG4gICAgICB9XG5cbiAgICAgIG5vZGVzVG9IeWRyYXRlLnB1c2gobm9kZSk7XG4gICAgfSk7XG4gIH1cblxuICB2YXIgX2luc2VydDtcblxuICB2YXIgb21uaXByZXNlbnRQbHVnaW5zID0gW2NvbXBhdCwgcmVtb3ZlTGFiZWxdO1xuXG4gIHtcbiAgICBvbW5pcHJlc2VudFBsdWdpbnMucHVzaChjcmVhdGVVbnNhZmVTZWxlY3RvcnNBbGFybSh7XG4gICAgICBnZXQgY29tcGF0KCkge1xuICAgICAgICByZXR1cm4gY2FjaGUuY29tcGF0O1xuICAgICAgfVxuXG4gICAgfSksIGluY29ycmVjdEltcG9ydEFsYXJtKTtcbiAgfVxuXG4gIHtcbiAgICB2YXIgY3VycmVudFNoZWV0O1xuICAgIHZhciBmaW5hbGl6aW5nUGx1Z2lucyA9IFtzdHJpbmdpZnksIGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gICAgICBpZiAoIWVsZW1lbnQucm9vdCkge1xuICAgICAgICBpZiAoZWxlbWVudFtcInJldHVyblwiXSkge1xuICAgICAgICAgIGN1cnJlbnRTaGVldC5pbnNlcnQoZWxlbWVudFtcInJldHVyblwiXSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZWxlbWVudC52YWx1ZSAmJiBlbGVtZW50LnR5cGUgIT09IENPTU1FTlQpIHtcbiAgICAgICAgICAvLyBpbnNlcnQgZW1wdHkgcnVsZSBpbiBub24tcHJvZHVjdGlvbiBlbnZpcm9ubWVudHNcbiAgICAgICAgICAvLyBzbyBAZW1vdGlvbi9qZXN0IGNhbiBncmFiIGBrZXlgIGZyb20gdGhlIChKUylET00gZm9yIGNhY2hlcyB3aXRob3V0IGFueSBydWxlcyBpbnNlcnRlZCB5ZXRcbiAgICAgICAgICBjdXJyZW50U2hlZXQuaW5zZXJ0KGVsZW1lbnQudmFsdWUgKyBcInt9XCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBdO1xuICAgIHZhciBzZXJpYWxpemVyID0gbWlkZGxld2FyZShvbW5pcHJlc2VudFBsdWdpbnMuY29uY2F0KHN0eWxpc1BsdWdpbnMsIGZpbmFsaXppbmdQbHVnaW5zKSk7XG5cbiAgICB2YXIgc3R5bGlzID0gZnVuY3Rpb24gc3R5bGlzKHN0eWxlcykge1xuICAgICAgcmV0dXJuIHNlcmlhbGl6ZShjb21waWxlKHN0eWxlcyksIHNlcmlhbGl6ZXIpO1xuICAgIH07XG5cbiAgICBfaW5zZXJ0ID0gZnVuY3Rpb24gaW5zZXJ0KHNlbGVjdG9yLCBzZXJpYWxpemVkLCBzaGVldCwgc2hvdWxkQ2FjaGUpIHtcbiAgICAgIGN1cnJlbnRTaGVldCA9IHNoZWV0O1xuXG4gICAgICBpZiAoZ2V0U291cmNlTWFwKSB7XG4gICAgICAgIHZhciBzb3VyY2VNYXAgPSBnZXRTb3VyY2VNYXAoc2VyaWFsaXplZC5zdHlsZXMpO1xuXG4gICAgICAgIGlmIChzb3VyY2VNYXApIHtcbiAgICAgICAgICBjdXJyZW50U2hlZXQgPSB7XG4gICAgICAgICAgICBpbnNlcnQ6IGZ1bmN0aW9uIGluc2VydChydWxlKSB7XG4gICAgICAgICAgICAgIHNoZWV0Lmluc2VydChydWxlICsgc291cmNlTWFwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHN0eWxpcyhzZWxlY3RvciA/IHNlbGVjdG9yICsgXCJ7XCIgKyBzZXJpYWxpemVkLnN0eWxlcyArIFwifVwiIDogc2VyaWFsaXplZC5zdHlsZXMpO1xuXG4gICAgICBpZiAoc2hvdWxkQ2FjaGUpIHtcbiAgICAgICAgY2FjaGUuaW5zZXJ0ZWRbc2VyaWFsaXplZC5uYW1lXSA9IHRydWU7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIHZhciBjYWNoZSA9IHtcbiAgICBrZXk6IGtleSxcbiAgICBzaGVldDogbmV3IFN0eWxlU2hlZXQoe1xuICAgICAga2V5OiBrZXksXG4gICAgICBjb250YWluZXI6IGNvbnRhaW5lcixcbiAgICAgIG5vbmNlOiBvcHRpb25zLm5vbmNlLFxuICAgICAgc3BlZWR5OiBvcHRpb25zLnNwZWVkeSxcbiAgICAgIHByZXBlbmQ6IG9wdGlvbnMucHJlcGVuZCxcbiAgICAgIGluc2VydGlvblBvaW50OiBvcHRpb25zLmluc2VydGlvblBvaW50XG4gICAgfSksXG4gICAgbm9uY2U6IG9wdGlvbnMubm9uY2UsXG4gICAgaW5zZXJ0ZWQ6IGluc2VydGVkLFxuICAgIHJlZ2lzdGVyZWQ6IHt9LFxuICAgIGluc2VydDogX2luc2VydFxuICB9O1xuICBjYWNoZS5zaGVldC5oeWRyYXRlKG5vZGVzVG9IeWRyYXRlKTtcbiAgcmV0dXJuIGNhY2hlO1xufTtcblxuZXhwb3J0IHsgY3JlYXRlQ2FjaGUgYXMgZGVmYXVsdCB9O1xuIiwiLyoqIEBsaWNlbnNlIFJlYWN0IHYxNi4xMy4xXG4gKiByZWFjdC1pcy5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgRmFjZWJvb2ssIEluYy4gYW5kIGl0cyBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbid1c2Ugc3RyaWN0JztcblxuXG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgKGZ1bmN0aW9uKCkge1xuJ3VzZSBzdHJpY3QnO1xuXG4vLyBUaGUgU3ltYm9sIHVzZWQgdG8gdGFnIHRoZSBSZWFjdEVsZW1lbnQtbGlrZSB0eXBlcy4gSWYgdGhlcmUgaXMgbm8gbmF0aXZlIFN5bWJvbFxuLy8gbm9yIHBvbHlmaWxsLCB0aGVuIGEgcGxhaW4gbnVtYmVyIGlzIHVzZWQgZm9yIHBlcmZvcm1hbmNlLlxudmFyIGhhc1N5bWJvbCA9IHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgU3ltYm9sLmZvcjtcbnZhciBSRUFDVF9FTEVNRU5UX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5lbGVtZW50JykgOiAweGVhYzc7XG52YXIgUkVBQ1RfUE9SVEFMX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5wb3J0YWwnKSA6IDB4ZWFjYTtcbnZhciBSRUFDVF9GUkFHTUVOVF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuZnJhZ21lbnQnKSA6IDB4ZWFjYjtcbnZhciBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3Quc3RyaWN0X21vZGUnKSA6IDB4ZWFjYztcbnZhciBSRUFDVF9QUk9GSUxFUl9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QucHJvZmlsZXInKSA6IDB4ZWFkMjtcbnZhciBSRUFDVF9QUk9WSURFUl9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QucHJvdmlkZXInKSA6IDB4ZWFjZDtcbnZhciBSRUFDVF9DT05URVhUX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5jb250ZXh0JykgOiAweGVhY2U7IC8vIFRPRE86IFdlIGRvbid0IHVzZSBBc3luY01vZGUgb3IgQ29uY3VycmVudE1vZGUgYW55bW9yZS4gVGhleSB3ZXJlIHRlbXBvcmFyeVxuLy8gKHVuc3RhYmxlKSBBUElzIHRoYXQgaGF2ZSBiZWVuIHJlbW92ZWQuIENhbiB3ZSByZW1vdmUgdGhlIHN5bWJvbHM/XG5cbnZhciBSRUFDVF9BU1lOQ19NT0RFX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5hc3luY19tb2RlJykgOiAweGVhY2Y7XG52YXIgUkVBQ1RfQ09OQ1VSUkVOVF9NT0RFX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5jb25jdXJyZW50X21vZGUnKSA6IDB4ZWFjZjtcbnZhciBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuZm9yd2FyZF9yZWYnKSA6IDB4ZWFkMDtcbnZhciBSRUFDVF9TVVNQRU5TRV9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3Quc3VzcGVuc2UnKSA6IDB4ZWFkMTtcbnZhciBSRUFDVF9TVVNQRU5TRV9MSVNUX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5zdXNwZW5zZV9saXN0JykgOiAweGVhZDg7XG52YXIgUkVBQ1RfTUVNT19UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QubWVtbycpIDogMHhlYWQzO1xudmFyIFJFQUNUX0xBWllfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LmxhenknKSA6IDB4ZWFkNDtcbnZhciBSRUFDVF9CTE9DS19UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuYmxvY2snKSA6IDB4ZWFkOTtcbnZhciBSRUFDVF9GVU5EQU1FTlRBTF9UWVBFID0gaGFzU3ltYm9sID8gU3ltYm9sLmZvcigncmVhY3QuZnVuZGFtZW50YWwnKSA6IDB4ZWFkNTtcbnZhciBSRUFDVF9SRVNQT05ERVJfVFlQRSA9IGhhc1N5bWJvbCA/IFN5bWJvbC5mb3IoJ3JlYWN0LnJlc3BvbmRlcicpIDogMHhlYWQ2O1xudmFyIFJFQUNUX1NDT1BFX1RZUEUgPSBoYXNTeW1ib2wgPyBTeW1ib2wuZm9yKCdyZWFjdC5zY29wZScpIDogMHhlYWQ3O1xuXG5mdW5jdGlvbiBpc1ZhbGlkRWxlbWVudFR5cGUodHlwZSkge1xuICByZXR1cm4gdHlwZW9mIHR5cGUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB0eXBlID09PSAnZnVuY3Rpb24nIHx8IC8vIE5vdGU6IGl0cyB0eXBlb2YgbWlnaHQgYmUgb3RoZXIgdGhhbiAnc3ltYm9sJyBvciAnbnVtYmVyJyBpZiBpdCdzIGEgcG9seWZpbGwuXG4gIHR5cGUgPT09IFJFQUNUX0ZSQUdNRU5UX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfQ09OQ1VSUkVOVF9NT0RFX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfUFJPRklMRVJfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX1NVU1BFTlNFX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfU1VTUEVOU0VfTElTVF9UWVBFIHx8IHR5cGVvZiB0eXBlID09PSAnb2JqZWN0JyAmJiB0eXBlICE9PSBudWxsICYmICh0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9MQVpZX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfTUVNT19UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX1BST1ZJREVSX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfQ09OVEVYVF9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0ZPUldBUkRfUkVGX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfRlVOREFNRU5UQUxfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9SRVNQT05ERVJfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9TQ09QRV9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0JMT0NLX1RZUEUpO1xufVxuXG5mdW5jdGlvbiB0eXBlT2Yob2JqZWN0KSB7XG4gIGlmICh0eXBlb2Ygb2JqZWN0ID09PSAnb2JqZWN0JyAmJiBvYmplY3QgIT09IG51bGwpIHtcbiAgICB2YXIgJCR0eXBlb2YgPSBvYmplY3QuJCR0eXBlb2Y7XG5cbiAgICBzd2l0Y2ggKCQkdHlwZW9mKSB7XG4gICAgICBjYXNlIFJFQUNUX0VMRU1FTlRfVFlQRTpcbiAgICAgICAgdmFyIHR5cGUgPSBvYmplY3QudHlwZTtcblxuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICBjYXNlIFJFQUNUX0FTWU5DX01PREVfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX0NPTkNVUlJFTlRfTU9ERV9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfRlJBR01FTlRfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX1BST0ZJTEVSX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfU1VTUEVOU0VfVFlQRTpcbiAgICAgICAgICAgIHJldHVybiB0eXBlO1xuXG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHZhciAkJHR5cGVvZlR5cGUgPSB0eXBlICYmIHR5cGUuJCR0eXBlb2Y7XG5cbiAgICAgICAgICAgIHN3aXRjaCAoJCR0eXBlb2ZUeXBlKSB7XG4gICAgICAgICAgICAgIGNhc2UgUkVBQ1RfQ09OVEVYVF9UWVBFOlxuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0ZPUldBUkRfUkVGX1RZUEU6XG4gICAgICAgICAgICAgIGNhc2UgUkVBQ1RfTEFaWV9UWVBFOlxuICAgICAgICAgICAgICBjYXNlIFJFQUNUX01FTU9fVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9QUk9WSURFUl9UWVBFOlxuICAgICAgICAgICAgICAgIHJldHVybiAkJHR5cGVvZlR5cGU7XG5cbiAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICByZXR1cm4gJCR0eXBlb2Y7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuXG4gICAgICBjYXNlIFJFQUNUX1BPUlRBTF9UWVBFOlxuICAgICAgICByZXR1cm4gJCR0eXBlb2Y7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn0gLy8gQXN5bmNNb2RlIGlzIGRlcHJlY2F0ZWQgYWxvbmcgd2l0aCBpc0FzeW5jTW9kZVxuXG52YXIgQXN5bmNNb2RlID0gUkVBQ1RfQVNZTkNfTU9ERV9UWVBFO1xudmFyIENvbmN1cnJlbnRNb2RlID0gUkVBQ1RfQ09OQ1VSUkVOVF9NT0RFX1RZUEU7XG52YXIgQ29udGV4dENvbnN1bWVyID0gUkVBQ1RfQ09OVEVYVF9UWVBFO1xudmFyIENvbnRleHRQcm92aWRlciA9IFJFQUNUX1BST1ZJREVSX1RZUEU7XG52YXIgRWxlbWVudCA9IFJFQUNUX0VMRU1FTlRfVFlQRTtcbnZhciBGb3J3YXJkUmVmID0gUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRTtcbnZhciBGcmFnbWVudCA9IFJFQUNUX0ZSQUdNRU5UX1RZUEU7XG52YXIgTGF6eSA9IFJFQUNUX0xBWllfVFlQRTtcbnZhciBNZW1vID0gUkVBQ1RfTUVNT19UWVBFO1xudmFyIFBvcnRhbCA9IFJFQUNUX1BPUlRBTF9UWVBFO1xudmFyIFByb2ZpbGVyID0gUkVBQ1RfUFJPRklMRVJfVFlQRTtcbnZhciBTdHJpY3RNb2RlID0gUkVBQ1RfU1RSSUNUX01PREVfVFlQRTtcbnZhciBTdXNwZW5zZSA9IFJFQUNUX1NVU1BFTlNFX1RZUEU7XG52YXIgaGFzV2FybmVkQWJvdXREZXByZWNhdGVkSXNBc3luY01vZGUgPSBmYWxzZTsgLy8gQXN5bmNNb2RlIHNob3VsZCBiZSBkZXByZWNhdGVkXG5cbmZ1bmN0aW9uIGlzQXN5bmNNb2RlKG9iamVjdCkge1xuICB7XG4gICAgaWYgKCFoYXNXYXJuZWRBYm91dERlcHJlY2F0ZWRJc0FzeW5jTW9kZSkge1xuICAgICAgaGFzV2FybmVkQWJvdXREZXByZWNhdGVkSXNBc3luY01vZGUgPSB0cnVlOyAvLyBVc2luZyBjb25zb2xlWyd3YXJuJ10gdG8gZXZhZGUgQmFiZWwgYW5kIEVTTGludFxuXG4gICAgICBjb25zb2xlWyd3YXJuJ10oJ1RoZSBSZWFjdElzLmlzQXN5bmNNb2RlKCkgYWxpYXMgaGFzIGJlZW4gZGVwcmVjYXRlZCwgJyArICdhbmQgd2lsbCBiZSByZW1vdmVkIGluIFJlYWN0IDE3Ky4gVXBkYXRlIHlvdXIgY29kZSB0byB1c2UgJyArICdSZWFjdElzLmlzQ29uY3VycmVudE1vZGUoKSBpbnN0ZWFkLiBJdCBoYXMgdGhlIGV4YWN0IHNhbWUgQVBJLicpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBpc0NvbmN1cnJlbnRNb2RlKG9iamVjdCkgfHwgdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0FTWU5DX01PREVfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzQ29uY3VycmVudE1vZGUob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfQ09OQ1VSUkVOVF9NT0RFX1RZUEU7XG59XG5mdW5jdGlvbiBpc0NvbnRleHRDb25zdW1lcihvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9DT05URVhUX1RZUEU7XG59XG5mdW5jdGlvbiBpc0NvbnRleHRQcm92aWRlcihvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9QUk9WSURFUl9UWVBFO1xufVxuZnVuY3Rpb24gaXNFbGVtZW50KG9iamVjdCkge1xuICByZXR1cm4gdHlwZW9mIG9iamVjdCA9PT0gJ29iamVjdCcgJiYgb2JqZWN0ICE9PSBudWxsICYmIG9iamVjdC4kJHR5cGVvZiA9PT0gUkVBQ1RfRUxFTUVOVF9UWVBFO1xufVxuZnVuY3Rpb24gaXNGb3J3YXJkUmVmKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0ZPUldBUkRfUkVGX1RZUEU7XG59XG5mdW5jdGlvbiBpc0ZyYWdtZW50KG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0ZSQUdNRU5UX1RZUEU7XG59XG5mdW5jdGlvbiBpc0xhenkob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfTEFaWV9UWVBFO1xufVxuZnVuY3Rpb24gaXNNZW1vKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX01FTU9fVFlQRTtcbn1cbmZ1bmN0aW9uIGlzUG9ydGFsKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX1BPUlRBTF9UWVBFO1xufVxuZnVuY3Rpb24gaXNQcm9maWxlcihvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9QUk9GSUxFUl9UWVBFO1xufVxuZnVuY3Rpb24gaXNTdHJpY3RNb2RlKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX1NUUklDVF9NT0RFX1RZUEU7XG59XG5mdW5jdGlvbiBpc1N1c3BlbnNlKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX1NVU1BFTlNFX1RZUEU7XG59XG5cbmV4cG9ydHMuQXN5bmNNb2RlID0gQXN5bmNNb2RlO1xuZXhwb3J0cy5Db25jdXJyZW50TW9kZSA9IENvbmN1cnJlbnRNb2RlO1xuZXhwb3J0cy5Db250ZXh0Q29uc3VtZXIgPSBDb250ZXh0Q29uc3VtZXI7XG5leHBvcnRzLkNvbnRleHRQcm92aWRlciA9IENvbnRleHRQcm92aWRlcjtcbmV4cG9ydHMuRWxlbWVudCA9IEVsZW1lbnQ7XG5leHBvcnRzLkZvcndhcmRSZWYgPSBGb3J3YXJkUmVmO1xuZXhwb3J0cy5GcmFnbWVudCA9IEZyYWdtZW50O1xuZXhwb3J0cy5MYXp5ID0gTGF6eTtcbmV4cG9ydHMuTWVtbyA9IE1lbW87XG5leHBvcnRzLlBvcnRhbCA9IFBvcnRhbDtcbmV4cG9ydHMuUHJvZmlsZXIgPSBQcm9maWxlcjtcbmV4cG9ydHMuU3RyaWN0TW9kZSA9IFN0cmljdE1vZGU7XG5leHBvcnRzLlN1c3BlbnNlID0gU3VzcGVuc2U7XG5leHBvcnRzLmlzQXN5bmNNb2RlID0gaXNBc3luY01vZGU7XG5leHBvcnRzLmlzQ29uY3VycmVudE1vZGUgPSBpc0NvbmN1cnJlbnRNb2RlO1xuZXhwb3J0cy5pc0NvbnRleHRDb25zdW1lciA9IGlzQ29udGV4dENvbnN1bWVyO1xuZXhwb3J0cy5pc0NvbnRleHRQcm92aWRlciA9IGlzQ29udGV4dFByb3ZpZGVyO1xuZXhwb3J0cy5pc0VsZW1lbnQgPSBpc0VsZW1lbnQ7XG5leHBvcnRzLmlzRm9yd2FyZFJlZiA9IGlzRm9yd2FyZFJlZjtcbmV4cG9ydHMuaXNGcmFnbWVudCA9IGlzRnJhZ21lbnQ7XG5leHBvcnRzLmlzTGF6eSA9IGlzTGF6eTtcbmV4cG9ydHMuaXNNZW1vID0gaXNNZW1vO1xuZXhwb3J0cy5pc1BvcnRhbCA9IGlzUG9ydGFsO1xuZXhwb3J0cy5pc1Byb2ZpbGVyID0gaXNQcm9maWxlcjtcbmV4cG9ydHMuaXNTdHJpY3RNb2RlID0gaXNTdHJpY3RNb2RlO1xuZXhwb3J0cy5pc1N1c3BlbnNlID0gaXNTdXNwZW5zZTtcbmV4cG9ydHMuaXNWYWxpZEVsZW1lbnRUeXBlID0gaXNWYWxpZEVsZW1lbnRUeXBlO1xuZXhwb3J0cy50eXBlT2YgPSB0eXBlT2Y7XG4gIH0pKCk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvcmVhY3QtaXMucHJvZHVjdGlvbi5taW4uanMnKTtcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvcmVhY3QtaXMuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHJlYWN0SXMgPSByZXF1aXJlKCdyZWFjdC1pcycpO1xuXG4vKipcbiAqIENvcHlyaWdodCAyMDE1LCBZYWhvbyEgSW5jLlxuICogQ29weXJpZ2h0cyBsaWNlbnNlZCB1bmRlciB0aGUgTmV3IEJTRCBMaWNlbnNlLiBTZWUgdGhlIGFjY29tcGFueWluZyBMSUNFTlNFIGZpbGUgZm9yIHRlcm1zLlxuICovXG52YXIgUkVBQ1RfU1RBVElDUyA9IHtcbiAgY2hpbGRDb250ZXh0VHlwZXM6IHRydWUsXG4gIGNvbnRleHRUeXBlOiB0cnVlLFxuICBjb250ZXh0VHlwZXM6IHRydWUsXG4gIGRlZmF1bHRQcm9wczogdHJ1ZSxcbiAgZGlzcGxheU5hbWU6IHRydWUsXG4gIGdldERlZmF1bHRQcm9wczogdHJ1ZSxcbiAgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yOiB0cnVlLFxuICBnZXREZXJpdmVkU3RhdGVGcm9tUHJvcHM6IHRydWUsXG4gIG1peGluczogdHJ1ZSxcbiAgcHJvcFR5cGVzOiB0cnVlLFxuICB0eXBlOiB0cnVlXG59O1xudmFyIEtOT1dOX1NUQVRJQ1MgPSB7XG4gIG5hbWU6IHRydWUsXG4gIGxlbmd0aDogdHJ1ZSxcbiAgcHJvdG90eXBlOiB0cnVlLFxuICBjYWxsZXI6IHRydWUsXG4gIGNhbGxlZTogdHJ1ZSxcbiAgYXJndW1lbnRzOiB0cnVlLFxuICBhcml0eTogdHJ1ZVxufTtcbnZhciBGT1JXQVJEX1JFRl9TVEFUSUNTID0ge1xuICAnJCR0eXBlb2YnOiB0cnVlLFxuICByZW5kZXI6IHRydWUsXG4gIGRlZmF1bHRQcm9wczogdHJ1ZSxcbiAgZGlzcGxheU5hbWU6IHRydWUsXG4gIHByb3BUeXBlczogdHJ1ZVxufTtcbnZhciBNRU1PX1NUQVRJQ1MgPSB7XG4gICckJHR5cGVvZic6IHRydWUsXG4gIGNvbXBhcmU6IHRydWUsXG4gIGRlZmF1bHRQcm9wczogdHJ1ZSxcbiAgZGlzcGxheU5hbWU6IHRydWUsXG4gIHByb3BUeXBlczogdHJ1ZSxcbiAgdHlwZTogdHJ1ZVxufTtcbnZhciBUWVBFX1NUQVRJQ1MgPSB7fTtcblRZUEVfU1RBVElDU1tyZWFjdElzLkZvcndhcmRSZWZdID0gRk9SV0FSRF9SRUZfU1RBVElDUztcblRZUEVfU1RBVElDU1tyZWFjdElzLk1lbW9dID0gTUVNT19TVEFUSUNTO1xuXG5mdW5jdGlvbiBnZXRTdGF0aWNzKGNvbXBvbmVudCkge1xuICAvLyBSZWFjdCB2MTYuMTEgYW5kIGJlbG93XG4gIGlmIChyZWFjdElzLmlzTWVtbyhjb21wb25lbnQpKSB7XG4gICAgcmV0dXJuIE1FTU9fU1RBVElDUztcbiAgfSAvLyBSZWFjdCB2MTYuMTIgYW5kIGFib3ZlXG5cblxuICByZXR1cm4gVFlQRV9TVEFUSUNTW2NvbXBvbmVudFsnJCR0eXBlb2YnXV0gfHwgUkVBQ1RfU1RBVElDUztcbn1cblxudmFyIGRlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIGdldE93blByb3BlcnR5TmFtZXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBnZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xudmFyIGdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgZ2V0UHJvdG90eXBlT2YgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgb2JqZWN0UHJvdG90eXBlID0gT2JqZWN0LnByb3RvdHlwZTtcbmZ1bmN0aW9uIGhvaXN0Tm9uUmVhY3RTdGF0aWNzKHRhcmdldENvbXBvbmVudCwgc291cmNlQ29tcG9uZW50LCBibGFja2xpc3QpIHtcbiAgaWYgKHR5cGVvZiBzb3VyY2VDb21wb25lbnQgIT09ICdzdHJpbmcnKSB7XG4gICAgLy8gZG9uJ3QgaG9pc3Qgb3ZlciBzdHJpbmcgKGh0bWwpIGNvbXBvbmVudHNcbiAgICBpZiAob2JqZWN0UHJvdG90eXBlKSB7XG4gICAgICB2YXIgaW5oZXJpdGVkQ29tcG9uZW50ID0gZ2V0UHJvdG90eXBlT2Yoc291cmNlQ29tcG9uZW50KTtcblxuICAgICAgaWYgKGluaGVyaXRlZENvbXBvbmVudCAmJiBpbmhlcml0ZWRDb21wb25lbnQgIT09IG9iamVjdFByb3RvdHlwZSkge1xuICAgICAgICBob2lzdE5vblJlYWN0U3RhdGljcyh0YXJnZXRDb21wb25lbnQsIGluaGVyaXRlZENvbXBvbmVudCwgYmxhY2tsaXN0KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB2YXIga2V5cyA9IGdldE93blByb3BlcnR5TmFtZXMoc291cmNlQ29tcG9uZW50KTtcblxuICAgIGlmIChnZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICAgIGtleXMgPSBrZXlzLmNvbmNhdChnZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlQ29tcG9uZW50KSk7XG4gICAgfVxuXG4gICAgdmFyIHRhcmdldFN0YXRpY3MgPSBnZXRTdGF0aWNzKHRhcmdldENvbXBvbmVudCk7XG4gICAgdmFyIHNvdXJjZVN0YXRpY3MgPSBnZXRTdGF0aWNzKHNvdXJjZUNvbXBvbmVudCk7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpIHtcbiAgICAgIHZhciBrZXkgPSBrZXlzW2ldO1xuXG4gICAgICBpZiAoIUtOT1dOX1NUQVRJQ1Nba2V5XSAmJiAhKGJsYWNrbGlzdCAmJiBibGFja2xpc3Rba2V5XSkgJiYgIShzb3VyY2VTdGF0aWNzICYmIHNvdXJjZVN0YXRpY3Nba2V5XSkgJiYgISh0YXJnZXRTdGF0aWNzICYmIHRhcmdldFN0YXRpY3Nba2V5XSkpIHtcbiAgICAgICAgdmFyIGRlc2NyaXB0b3IgPSBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc291cmNlQ29tcG9uZW50LCBrZXkpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gQXZvaWQgZmFpbHVyZXMgZnJvbSByZWFkLW9ubHkgcHJvcGVydGllc1xuICAgICAgICAgIGRlZmluZVByb3BlcnR5KHRhcmdldENvbXBvbmVudCwga2V5LCBkZXNjcmlwdG9yKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge31cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gdGFyZ2V0Q29tcG9uZW50O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGhvaXN0Tm9uUmVhY3RTdGF0aWNzO1xuIiwidmFyIGlzQnJvd3NlciA9IHRydWU7XG5cbmZ1bmN0aW9uIGdldFJlZ2lzdGVyZWRTdHlsZXMocmVnaXN0ZXJlZCwgcmVnaXN0ZXJlZFN0eWxlcywgY2xhc3NOYW1lcykge1xuICB2YXIgcmF3Q2xhc3NOYW1lID0gJyc7XG4gIGNsYXNzTmFtZXMuc3BsaXQoJyAnKS5mb3JFYWNoKGZ1bmN0aW9uIChjbGFzc05hbWUpIHtcbiAgICBpZiAocmVnaXN0ZXJlZFtjbGFzc05hbWVdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJlZ2lzdGVyZWRTdHlsZXMucHVzaChyZWdpc3RlcmVkW2NsYXNzTmFtZV0gKyBcIjtcIik7XG4gICAgfSBlbHNlIGlmIChjbGFzc05hbWUpIHtcbiAgICAgIHJhd0NsYXNzTmFtZSArPSBjbGFzc05hbWUgKyBcIiBcIjtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gcmF3Q2xhc3NOYW1lO1xufVxudmFyIHJlZ2lzdGVyU3R5bGVzID0gZnVuY3Rpb24gcmVnaXN0ZXJTdHlsZXMoY2FjaGUsIHNlcmlhbGl6ZWQsIGlzU3RyaW5nVGFnKSB7XG4gIHZhciBjbGFzc05hbWUgPSBjYWNoZS5rZXkgKyBcIi1cIiArIHNlcmlhbGl6ZWQubmFtZTtcblxuICBpZiAoIC8vIHdlIG9ubHkgbmVlZCB0byBhZGQgdGhlIHN0eWxlcyB0byB0aGUgcmVnaXN0ZXJlZCBjYWNoZSBpZiB0aGVcbiAgLy8gY2xhc3MgbmFtZSBjb3VsZCBiZSB1c2VkIGZ1cnRoZXIgZG93blxuICAvLyB0aGUgdHJlZSBidXQgaWYgaXQncyBhIHN0cmluZyB0YWcsIHdlIGtub3cgaXQgd29uJ3RcbiAgLy8gc28gd2UgZG9uJ3QgaGF2ZSB0byBhZGQgaXQgdG8gcmVnaXN0ZXJlZCBjYWNoZS5cbiAgLy8gdGhpcyBpbXByb3ZlcyBtZW1vcnkgdXNhZ2Ugc2luY2Ugd2UgY2FuIGF2b2lkIHN0b3JpbmcgdGhlIHdob2xlIHN0eWxlIHN0cmluZ1xuICAoaXNTdHJpbmdUYWcgPT09IGZhbHNlIHx8IC8vIHdlIG5lZWQgdG8gYWx3YXlzIHN0b3JlIGl0IGlmIHdlJ3JlIGluIGNvbXBhdCBtb2RlIGFuZFxuICAvLyBpbiBub2RlIHNpbmNlIGVtb3Rpb24tc2VydmVyIHJlbGllcyBvbiB3aGV0aGVyIGEgc3R5bGUgaXMgaW5cbiAgLy8gdGhlIHJlZ2lzdGVyZWQgY2FjaGUgdG8ga25vdyB3aGV0aGVyIGEgc3R5bGUgaXMgZ2xvYmFsIG9yIG5vdFxuICAvLyBhbHNvLCBub3RlIHRoYXQgdGhpcyBjaGVjayB3aWxsIGJlIGRlYWQgY29kZSBlbGltaW5hdGVkIGluIHRoZSBicm93c2VyXG4gIGlzQnJvd3NlciA9PT0gZmFsc2UgKSAmJiBjYWNoZS5yZWdpc3RlcmVkW2NsYXNzTmFtZV0gPT09IHVuZGVmaW5lZCkge1xuICAgIGNhY2hlLnJlZ2lzdGVyZWRbY2xhc3NOYW1lXSA9IHNlcmlhbGl6ZWQuc3R5bGVzO1xuICB9XG59O1xudmFyIGluc2VydFN0eWxlcyA9IGZ1bmN0aW9uIGluc2VydFN0eWxlcyhjYWNoZSwgc2VyaWFsaXplZCwgaXNTdHJpbmdUYWcpIHtcbiAgcmVnaXN0ZXJTdHlsZXMoY2FjaGUsIHNlcmlhbGl6ZWQsIGlzU3RyaW5nVGFnKTtcbiAgdmFyIGNsYXNzTmFtZSA9IGNhY2hlLmtleSArIFwiLVwiICsgc2VyaWFsaXplZC5uYW1lO1xuXG4gIGlmIChjYWNoZS5pbnNlcnRlZFtzZXJpYWxpemVkLm5hbWVdID09PSB1bmRlZmluZWQpIHtcbiAgICB2YXIgY3VycmVudCA9IHNlcmlhbGl6ZWQ7XG5cbiAgICBkbyB7XG4gICAgICBjYWNoZS5pbnNlcnQoc2VyaWFsaXplZCA9PT0gY3VycmVudCA/IFwiLlwiICsgY2xhc3NOYW1lIDogJycsIGN1cnJlbnQsIGNhY2hlLnNoZWV0LCB0cnVlKTtcblxuICAgICAgY3VycmVudCA9IGN1cnJlbnQubmV4dDtcbiAgICB9IHdoaWxlIChjdXJyZW50ICE9PSB1bmRlZmluZWQpO1xuICB9XG59O1xuXG5leHBvcnQgeyBnZXRSZWdpc3RlcmVkU3R5bGVzLCBpbnNlcnRTdHlsZXMsIHJlZ2lzdGVyU3R5bGVzIH07XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSAqL1xuLy8gSW5zcGlyZWQgYnkgaHR0cHM6Ly9naXRodWIuY29tL2dhcnljb3VydC9tdXJtdXJoYXNoLWpzXG4vLyBQb3J0ZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vYWFwcGxlYnkvc21oYXNoZXIvYmxvYi82MWEwNTMwZjI4Mjc3ZjJlODUwYmZjMzk2MDBjZTYxZDAyYjUxOGRlL3NyYy9NdXJtdXJIYXNoMi5jcHAjTDM3LUw4NlxuZnVuY3Rpb24gbXVybXVyMihzdHIpIHtcbiAgLy8gJ20nIGFuZCAncicgYXJlIG1peGluZyBjb25zdGFudHMgZ2VuZXJhdGVkIG9mZmxpbmUuXG4gIC8vIFRoZXkncmUgbm90IHJlYWxseSAnbWFnaWMnLCB0aGV5IGp1c3QgaGFwcGVuIHRvIHdvcmsgd2VsbC5cbiAgLy8gY29uc3QgbSA9IDB4NWJkMWU5OTU7XG4gIC8vIGNvbnN0IHIgPSAyNDtcbiAgLy8gSW5pdGlhbGl6ZSB0aGUgaGFzaFxuICB2YXIgaCA9IDA7IC8vIE1peCA0IGJ5dGVzIGF0IGEgdGltZSBpbnRvIHRoZSBoYXNoXG5cbiAgdmFyIGssXG4gICAgICBpID0gMCxcbiAgICAgIGxlbiA9IHN0ci5sZW5ndGg7XG5cbiAgZm9yICg7IGxlbiA+PSA0OyArK2ksIGxlbiAtPSA0KSB7XG4gICAgayA9IHN0ci5jaGFyQ29kZUF0KGkpICYgMHhmZiB8IChzdHIuY2hhckNvZGVBdCgrK2kpICYgMHhmZikgPDwgOCB8IChzdHIuY2hhckNvZGVBdCgrK2kpICYgMHhmZikgPDwgMTYgfCAoc3RyLmNoYXJDb2RlQXQoKytpKSAmIDB4ZmYpIDw8IDI0O1xuICAgIGsgPVxuICAgIC8qIE1hdGguaW11bChrLCBtKTogKi9cbiAgICAoayAmIDB4ZmZmZikgKiAweDViZDFlOTk1ICsgKChrID4+PiAxNikgKiAweGU5OTUgPDwgMTYpO1xuICAgIGsgXj1cbiAgICAvKiBrID4+PiByOiAqL1xuICAgIGsgPj4+IDI0O1xuICAgIGggPVxuICAgIC8qIE1hdGguaW11bChrLCBtKTogKi9cbiAgICAoayAmIDB4ZmZmZikgKiAweDViZDFlOTk1ICsgKChrID4+PiAxNikgKiAweGU5OTUgPDwgMTYpIF5cbiAgICAvKiBNYXRoLmltdWwoaCwgbSk6ICovXG4gICAgKGggJiAweGZmZmYpICogMHg1YmQxZTk5NSArICgoaCA+Pj4gMTYpICogMHhlOTk1IDw8IDE2KTtcbiAgfSAvLyBIYW5kbGUgdGhlIGxhc3QgZmV3IGJ5dGVzIG9mIHRoZSBpbnB1dCBhcnJheVxuXG5cbiAgc3dpdGNoIChsZW4pIHtcbiAgICBjYXNlIDM6XG4gICAgICBoIF49IChzdHIuY2hhckNvZGVBdChpICsgMikgJiAweGZmKSA8PCAxNjtcblxuICAgIGNhc2UgMjpcbiAgICAgIGggXj0gKHN0ci5jaGFyQ29kZUF0KGkgKyAxKSAmIDB4ZmYpIDw8IDg7XG5cbiAgICBjYXNlIDE6XG4gICAgICBoIF49IHN0ci5jaGFyQ29kZUF0KGkpICYgMHhmZjtcbiAgICAgIGggPVxuICAgICAgLyogTWF0aC5pbXVsKGgsIG0pOiAqL1xuICAgICAgKGggJiAweGZmZmYpICogMHg1YmQxZTk5NSArICgoaCA+Pj4gMTYpICogMHhlOTk1IDw8IDE2KTtcbiAgfSAvLyBEbyBhIGZldyBmaW5hbCBtaXhlcyBvZiB0aGUgaGFzaCB0byBlbnN1cmUgdGhlIGxhc3QgZmV3XG4gIC8vIGJ5dGVzIGFyZSB3ZWxsLWluY29ycG9yYXRlZC5cblxuXG4gIGggXj0gaCA+Pj4gMTM7XG4gIGggPVxuICAvKiBNYXRoLmltdWwoaCwgbSk6ICovXG4gIChoICYgMHhmZmZmKSAqIDB4NWJkMWU5OTUgKyAoKGggPj4+IDE2KSAqIDB4ZTk5NSA8PCAxNik7XG4gIHJldHVybiAoKGggXiBoID4+PiAxNSkgPj4+IDApLnRvU3RyaW5nKDM2KTtcbn1cblxuZXhwb3J0IHsgbXVybXVyMiBhcyBkZWZhdWx0IH07XG4iLCJ2YXIgdW5pdGxlc3NLZXlzID0ge1xuICBhbmltYXRpb25JdGVyYXRpb25Db3VudDogMSxcbiAgYXNwZWN0UmF0aW86IDEsXG4gIGJvcmRlckltYWdlT3V0c2V0OiAxLFxuICBib3JkZXJJbWFnZVNsaWNlOiAxLFxuICBib3JkZXJJbWFnZVdpZHRoOiAxLFxuICBib3hGbGV4OiAxLFxuICBib3hGbGV4R3JvdXA6IDEsXG4gIGJveE9yZGluYWxHcm91cDogMSxcbiAgY29sdW1uQ291bnQ6IDEsXG4gIGNvbHVtbnM6IDEsXG4gIGZsZXg6IDEsXG4gIGZsZXhHcm93OiAxLFxuICBmbGV4UG9zaXRpdmU6IDEsXG4gIGZsZXhTaHJpbms6IDEsXG4gIGZsZXhOZWdhdGl2ZTogMSxcbiAgZmxleE9yZGVyOiAxLFxuICBncmlkUm93OiAxLFxuICBncmlkUm93RW5kOiAxLFxuICBncmlkUm93U3BhbjogMSxcbiAgZ3JpZFJvd1N0YXJ0OiAxLFxuICBncmlkQ29sdW1uOiAxLFxuICBncmlkQ29sdW1uRW5kOiAxLFxuICBncmlkQ29sdW1uU3BhbjogMSxcbiAgZ3JpZENvbHVtblN0YXJ0OiAxLFxuICBtc0dyaWRSb3c6IDEsXG4gIG1zR3JpZFJvd1NwYW46IDEsXG4gIG1zR3JpZENvbHVtbjogMSxcbiAgbXNHcmlkQ29sdW1uU3BhbjogMSxcbiAgZm9udFdlaWdodDogMSxcbiAgbGluZUhlaWdodDogMSxcbiAgb3BhY2l0eTogMSxcbiAgb3JkZXI6IDEsXG4gIG9ycGhhbnM6IDEsXG4gIHNjYWxlOiAxLFxuICB0YWJTaXplOiAxLFxuICB3aWRvd3M6IDEsXG4gIHpJbmRleDogMSxcbiAgem9vbTogMSxcbiAgV2Via2l0TGluZUNsYW1wOiAxLFxuICAvLyBTVkctcmVsYXRlZCBwcm9wZXJ0aWVzXG4gIGZpbGxPcGFjaXR5OiAxLFxuICBmbG9vZE9wYWNpdHk6IDEsXG4gIHN0b3BPcGFjaXR5OiAxLFxuICBzdHJva2VEYXNoYXJyYXk6IDEsXG4gIHN0cm9rZURhc2hvZmZzZXQ6IDEsXG4gIHN0cm9rZU1pdGVybGltaXQ6IDEsXG4gIHN0cm9rZU9wYWNpdHk6IDEsXG4gIHN0cm9rZVdpZHRoOiAxXG59O1xuXG5leHBvcnQgeyB1bml0bGVzc0tleXMgYXMgZGVmYXVsdCB9O1xuIiwiaW1wb3J0IGhhc2hTdHJpbmcgZnJvbSAnQGVtb3Rpb24vaGFzaCc7XG5pbXBvcnQgdW5pdGxlc3MgZnJvbSAnQGVtb3Rpb24vdW5pdGxlc3MnO1xuaW1wb3J0IG1lbW9pemUgZnJvbSAnQGVtb3Rpb24vbWVtb2l6ZSc7XG5cbnZhciBpc0RldmVsb3BtZW50ID0gdHJ1ZTtcblxudmFyIElMTEVHQUxfRVNDQVBFX1NFUVVFTkNFX0VSUk9SID0gXCJZb3UgaGF2ZSBpbGxlZ2FsIGVzY2FwZSBzZXF1ZW5jZSBpbiB5b3VyIHRlbXBsYXRlIGxpdGVyYWwsIG1vc3QgbGlrZWx5IGluc2lkZSBjb250ZW50J3MgcHJvcGVydHkgdmFsdWUuXFxuQmVjYXVzZSB5b3Ugd3JpdGUgeW91ciBDU1MgaW5zaWRlIGEgSmF2YVNjcmlwdCBzdHJpbmcgeW91IGFjdHVhbGx5IGhhdmUgdG8gZG8gZG91YmxlIGVzY2FwaW5nLCBzbyBmb3IgZXhhbXBsZSBcXFwiY29udGVudDogJ1xcXFwwMGQ3JztcXFwiIHNob3VsZCBiZWNvbWUgXFxcImNvbnRlbnQ6ICdcXFxcXFxcXDAwZDcnO1xcXCIuXFxuWW91IGNhbiByZWFkIG1vcmUgYWJvdXQgdGhpcyBoZXJlOlxcbmh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL1RlbXBsYXRlX2xpdGVyYWxzI0VTMjAxOF9yZXZpc2lvbl9vZl9pbGxlZ2FsX2VzY2FwZV9zZXF1ZW5jZXNcIjtcbnZhciBVTkRFRklORURfQVNfT0JKRUNUX0tFWV9FUlJPUiA9IFwiWW91IGhhdmUgcGFzc2VkIGluIGZhbHN5IHZhbHVlIGFzIHN0eWxlIG9iamVjdCdzIGtleSAoY2FuIGhhcHBlbiB3aGVuIGluIGV4YW1wbGUgeW91IHBhc3MgdW5leHBvcnRlZCBjb21wb25lbnQgYXMgY29tcHV0ZWQga2V5KS5cIjtcbnZhciBoeXBoZW5hdGVSZWdleCA9IC9bQS1aXXxebXMvZztcbnZhciBhbmltYXRpb25SZWdleCA9IC9fRU1PXyhbXl9dKz8pXyhbXl0qPylfRU1PXy9nO1xuXG52YXIgaXNDdXN0b21Qcm9wZXJ0eSA9IGZ1bmN0aW9uIGlzQ3VzdG9tUHJvcGVydHkocHJvcGVydHkpIHtcbiAgcmV0dXJuIHByb3BlcnR5LmNoYXJDb2RlQXQoMSkgPT09IDQ1O1xufTtcblxudmFyIGlzUHJvY2Vzc2FibGVWYWx1ZSA9IGZ1bmN0aW9uIGlzUHJvY2Vzc2FibGVWYWx1ZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgIT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgIT09ICdib29sZWFuJztcbn07XG5cbnZhciBwcm9jZXNzU3R5bGVOYW1lID0gLyogI19fUFVSRV9fICovbWVtb2l6ZShmdW5jdGlvbiAoc3R5bGVOYW1lKSB7XG4gIHJldHVybiBpc0N1c3RvbVByb3BlcnR5KHN0eWxlTmFtZSkgPyBzdHlsZU5hbWUgOiBzdHlsZU5hbWUucmVwbGFjZShoeXBoZW5hdGVSZWdleCwgJy0kJicpLnRvTG93ZXJDYXNlKCk7XG59KTtcblxudmFyIHByb2Nlc3NTdHlsZVZhbHVlID0gZnVuY3Rpb24gcHJvY2Vzc1N0eWxlVmFsdWUoa2V5LCB2YWx1ZSkge1xuICBzd2l0Y2ggKGtleSkge1xuICAgIGNhc2UgJ2FuaW1hdGlvbic6XG4gICAgY2FzZSAnYW5pbWF0aW9uTmFtZSc6XG4gICAgICB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoYW5pbWF0aW9uUmVnZXgsIGZ1bmN0aW9uIChtYXRjaCwgcDEsIHAyKSB7XG4gICAgICAgICAgICBjdXJzb3IgPSB7XG4gICAgICAgICAgICAgIG5hbWU6IHAxLFxuICAgICAgICAgICAgICBzdHlsZXM6IHAyLFxuICAgICAgICAgICAgICBuZXh0OiBjdXJzb3JcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICByZXR1cm4gcDE7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgfVxuXG4gIGlmICh1bml0bGVzc1trZXldICE9PSAxICYmICFpc0N1c3RvbVByb3BlcnR5KGtleSkgJiYgdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyAmJiB2YWx1ZSAhPT0gMCkge1xuICAgIHJldHVybiB2YWx1ZSArICdweCc7XG4gIH1cblxuICByZXR1cm4gdmFsdWU7XG59O1xuXG57XG4gIHZhciBjb250ZW50VmFsdWVQYXR0ZXJuID0gLyh2YXJ8YXR0cnxjb3VudGVycz98dXJsfGVsZW1lbnR8KCgocmVwZWF0aW5nLSk/KGxpbmVhcnxyYWRpYWwpKXxjb25pYyktZ3JhZGllbnQpXFwofChuby0pPyhvcGVufGNsb3NlKS1xdW90ZS87XG4gIHZhciBjb250ZW50VmFsdWVzID0gWydub3JtYWwnLCAnbm9uZScsICdpbml0aWFsJywgJ2luaGVyaXQnLCAndW5zZXQnXTtcbiAgdmFyIG9sZFByb2Nlc3NTdHlsZVZhbHVlID0gcHJvY2Vzc1N0eWxlVmFsdWU7XG4gIHZhciBtc1BhdHRlcm4gPSAvXi1tcy0vO1xuICB2YXIgaHlwaGVuUGF0dGVybiA9IC8tKC4pL2c7XG4gIHZhciBoeXBoZW5hdGVkQ2FjaGUgPSB7fTtcblxuICBwcm9jZXNzU3R5bGVWYWx1ZSA9IGZ1bmN0aW9uIHByb2Nlc3NTdHlsZVZhbHVlKGtleSwgdmFsdWUpIHtcbiAgICBpZiAoa2V5ID09PSAnY29udGVudCcpIHtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnIHx8IGNvbnRlbnRWYWx1ZXMuaW5kZXhPZih2YWx1ZSkgPT09IC0xICYmICFjb250ZW50VmFsdWVQYXR0ZXJuLnRlc3QodmFsdWUpICYmICh2YWx1ZS5jaGFyQXQoMCkgIT09IHZhbHVlLmNoYXJBdCh2YWx1ZS5sZW5ndGggLSAxKSB8fCB2YWx1ZS5jaGFyQXQoMCkgIT09ICdcIicgJiYgdmFsdWUuY2hhckF0KDApICE9PSBcIidcIikpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiWW91IHNlZW0gdG8gYmUgdXNpbmcgYSB2YWx1ZSBmb3IgJ2NvbnRlbnQnIHdpdGhvdXQgcXVvdGVzLCB0cnkgcmVwbGFjaW5nIGl0IHdpdGggYGNvbnRlbnQ6ICdcXFwiXCIgKyB2YWx1ZSArIFwiXFxcIidgXCIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZhciBwcm9jZXNzZWQgPSBvbGRQcm9jZXNzU3R5bGVWYWx1ZShrZXksIHZhbHVlKTtcblxuICAgIGlmIChwcm9jZXNzZWQgIT09ICcnICYmICFpc0N1c3RvbVByb3BlcnR5KGtleSkgJiYga2V5LmluZGV4T2YoJy0nKSAhPT0gLTEgJiYgaHlwaGVuYXRlZENhY2hlW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgaHlwaGVuYXRlZENhY2hlW2tleV0gPSB0cnVlO1xuICAgICAgY29uc29sZS5lcnJvcihcIlVzaW5nIGtlYmFiLWNhc2UgZm9yIGNzcyBwcm9wZXJ0aWVzIGluIG9iamVjdHMgaXMgbm90IHN1cHBvcnRlZC4gRGlkIHlvdSBtZWFuIFwiICsga2V5LnJlcGxhY2UobXNQYXR0ZXJuLCAnbXMtJykucmVwbGFjZShoeXBoZW5QYXR0ZXJuLCBmdW5jdGlvbiAoc3RyLCBfY2hhcikge1xuICAgICAgICByZXR1cm4gX2NoYXIudG9VcHBlckNhc2UoKTtcbiAgICAgIH0pICsgXCI/XCIpO1xuICAgIH1cblxuICAgIHJldHVybiBwcm9jZXNzZWQ7XG4gIH07XG59XG5cbnZhciBub0NvbXBvbmVudFNlbGVjdG9yTWVzc2FnZSA9ICdDb21wb25lbnQgc2VsZWN0b3JzIGNhbiBvbmx5IGJlIHVzZWQgaW4gY29uanVuY3Rpb24gd2l0aCAnICsgJ0BlbW90aW9uL2JhYmVsLXBsdWdpbiwgdGhlIHN3YyBFbW90aW9uIHBsdWdpbiwgb3IgYW5vdGhlciBFbW90aW9uLWF3YXJlICcgKyAnY29tcGlsZXIgdHJhbnNmb3JtLic7XG5cbmZ1bmN0aW9uIGhhbmRsZUludGVycG9sYXRpb24obWVyZ2VkUHJvcHMsIHJlZ2lzdGVyZWQsIGludGVycG9sYXRpb24pIHtcbiAgaWYgKGludGVycG9sYXRpb24gPT0gbnVsbCkge1xuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIHZhciBjb21wb25lbnRTZWxlY3RvciA9IGludGVycG9sYXRpb247XG5cbiAgaWYgKGNvbXBvbmVudFNlbGVjdG9yLl9fZW1vdGlvbl9zdHlsZXMgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmIChTdHJpbmcoY29tcG9uZW50U2VsZWN0b3IpID09PSAnTk9fQ09NUE9ORU5UX1NFTEVDVE9SJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKG5vQ29tcG9uZW50U2VsZWN0b3JNZXNzYWdlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gY29tcG9uZW50U2VsZWN0b3I7XG4gIH1cblxuICBzd2l0Y2ggKHR5cGVvZiBpbnRlcnBvbGF0aW9uKSB7XG4gICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICAgIH1cblxuICAgIGNhc2UgJ29iamVjdCc6XG4gICAgICB7XG4gICAgICAgIHZhciBrZXlmcmFtZXMgPSBpbnRlcnBvbGF0aW9uO1xuXG4gICAgICAgIGlmIChrZXlmcmFtZXMuYW5pbSA9PT0gMSkge1xuICAgICAgICAgIGN1cnNvciA9IHtcbiAgICAgICAgICAgIG5hbWU6IGtleWZyYW1lcy5uYW1lLFxuICAgICAgICAgICAgc3R5bGVzOiBrZXlmcmFtZXMuc3R5bGVzLFxuICAgICAgICAgICAgbmV4dDogY3Vyc29yXG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4ga2V5ZnJhbWVzLm5hbWU7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgc2VyaWFsaXplZFN0eWxlcyA9IGludGVycG9sYXRpb247XG5cbiAgICAgICAgaWYgKHNlcmlhbGl6ZWRTdHlsZXMuc3R5bGVzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB2YXIgbmV4dCA9IHNlcmlhbGl6ZWRTdHlsZXMubmV4dDtcblxuICAgICAgICAgIGlmIChuZXh0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIC8vIG5vdCB0aGUgbW9zdCBlZmZpY2llbnQgdGhpbmcgZXZlciBidXQgdGhpcyBpcyBhIHByZXR0eSByYXJlIGNhc2VcbiAgICAgICAgICAgIC8vIGFuZCB0aGVyZSB3aWxsIGJlIHZlcnkgZmV3IGl0ZXJhdGlvbnMgb2YgdGhpcyBnZW5lcmFsbHlcbiAgICAgICAgICAgIHdoaWxlIChuZXh0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgY3Vyc29yID0ge1xuICAgICAgICAgICAgICAgIG5hbWU6IG5leHQubmFtZSxcbiAgICAgICAgICAgICAgICBzdHlsZXM6IG5leHQuc3R5bGVzLFxuICAgICAgICAgICAgICAgIG5leHQ6IGN1cnNvclxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBuZXh0ID0gbmV4dC5uZXh0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHZhciBzdHlsZXMgPSBzZXJpYWxpemVkU3R5bGVzLnN0eWxlcyArIFwiO1wiO1xuICAgICAgICAgIHJldHVybiBzdHlsZXM7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gY3JlYXRlU3RyaW5nRnJvbU9iamVjdChtZXJnZWRQcm9wcywgcmVnaXN0ZXJlZCwgaW50ZXJwb2xhdGlvbik7XG4gICAgICB9XG5cbiAgICBjYXNlICdmdW5jdGlvbic6XG4gICAgICB7XG4gICAgICAgIGlmIChtZXJnZWRQcm9wcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgdmFyIHByZXZpb3VzQ3Vyc29yID0gY3Vyc29yO1xuICAgICAgICAgIHZhciByZXN1bHQgPSBpbnRlcnBvbGF0aW9uKG1lcmdlZFByb3BzKTtcbiAgICAgICAgICBjdXJzb3IgPSBwcmV2aW91c0N1cnNvcjtcbiAgICAgICAgICByZXR1cm4gaGFuZGxlSW50ZXJwb2xhdGlvbihtZXJnZWRQcm9wcywgcmVnaXN0ZXJlZCwgcmVzdWx0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdGdW5jdGlvbnMgdGhhdCBhcmUgaW50ZXJwb2xhdGVkIGluIGNzcyBjYWxscyB3aWxsIGJlIHN0cmluZ2lmaWVkLlxcbicgKyAnSWYgeW91IHdhbnQgdG8gaGF2ZSBhIGNzcyBjYWxsIGJhc2VkIG9uIHByb3BzLCBjcmVhdGUgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBjc3MgY2FsbCBsaWtlIHRoaXNcXG4nICsgJ2xldCBkeW5hbWljU3R5bGUgPSAocHJvcHMpID0+IGNzc2Bjb2xvcjogJHtwcm9wcy5jb2xvcn1gXFxuJyArICdJdCBjYW4gYmUgY2FsbGVkIGRpcmVjdGx5IHdpdGggcHJvcHMgb3IgaW50ZXJwb2xhdGVkIGluIGEgc3R5bGVkIGNhbGwgbGlrZSB0aGlzXFxuJyArIFwibGV0IFNvbWVDb21wb25lbnQgPSBzdHlsZWQoJ2RpdicpYCR7ZHluYW1pY1N0eWxlfWBcIik7XG4gICAgICAgIH1cblxuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICB7XG4gICAgICAgIHZhciBtYXRjaGVkID0gW107XG4gICAgICAgIHZhciByZXBsYWNlZCA9IGludGVycG9sYXRpb24ucmVwbGFjZShhbmltYXRpb25SZWdleCwgZnVuY3Rpb24gKF9tYXRjaCwgX3AxLCBwMikge1xuICAgICAgICAgIHZhciBmYWtlVmFyTmFtZSA9IFwiYW5pbWF0aW9uXCIgKyBtYXRjaGVkLmxlbmd0aDtcbiAgICAgICAgICBtYXRjaGVkLnB1c2goXCJjb25zdCBcIiArIGZha2VWYXJOYW1lICsgXCIgPSBrZXlmcmFtZXNgXCIgKyBwMi5yZXBsYWNlKC9eQGtleWZyYW1lcyBhbmltYXRpb24tXFx3Ky8sICcnKSArIFwiYFwiKTtcbiAgICAgICAgICByZXR1cm4gXCIke1wiICsgZmFrZVZhck5hbWUgKyBcIn1cIjtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKG1hdGNoZWQubGVuZ3RoKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcImBrZXlmcmFtZXNgIG91dHB1dCBnb3QgaW50ZXJwb2xhdGVkIGludG8gcGxhaW4gc3RyaW5nLCBwbGVhc2Ugd3JhcCBpdCB3aXRoIGBjc3NgLlxcblxcbkluc3RlYWQgb2YgZG9pbmcgdGhpczpcXG5cXG5cIiArIFtdLmNvbmNhdChtYXRjaGVkLCBbXCJgXCIgKyByZXBsYWNlZCArIFwiYFwiXSkuam9pbignXFxuJykgKyBcIlxcblxcbllvdSBzaG91bGQgd3JhcCBpdCB3aXRoIGBjc3NgIGxpa2UgdGhpczpcXG5cXG5jc3NgXCIgKyByZXBsYWNlZCArIFwiYFwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBicmVhaztcbiAgfSAvLyBmaW5hbGl6ZSBzdHJpbmcgdmFsdWVzIChyZWd1bGFyIHN0cmluZ3MgYW5kIGZ1bmN0aW9ucyBpbnRlcnBvbGF0ZWQgaW50byBjc3MgY2FsbHMpXG5cblxuICB2YXIgYXNTdHJpbmcgPSBpbnRlcnBvbGF0aW9uO1xuXG4gIGlmIChyZWdpc3RlcmVkID09IG51bGwpIHtcbiAgICByZXR1cm4gYXNTdHJpbmc7XG4gIH1cblxuICB2YXIgY2FjaGVkID0gcmVnaXN0ZXJlZFthc1N0cmluZ107XG4gIHJldHVybiBjYWNoZWQgIT09IHVuZGVmaW5lZCA/IGNhY2hlZCA6IGFzU3RyaW5nO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVTdHJpbmdGcm9tT2JqZWN0KG1lcmdlZFByb3BzLCByZWdpc3RlcmVkLCBvYmopIHtcbiAgdmFyIHN0cmluZyA9ICcnO1xuXG4gIGlmIChBcnJheS5pc0FycmF5KG9iaikpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9iai5sZW5ndGg7IGkrKykge1xuICAgICAgc3RyaW5nICs9IGhhbmRsZUludGVycG9sYXRpb24obWVyZ2VkUHJvcHMsIHJlZ2lzdGVyZWQsIG9ialtpXSkgKyBcIjtcIjtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZm9yICh2YXIga2V5IGluIG9iaikge1xuICAgICAgdmFyIHZhbHVlID0gb2JqW2tleV07XG5cbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnKSB7XG4gICAgICAgIHZhciBhc1N0cmluZyA9IHZhbHVlO1xuXG4gICAgICAgIGlmIChyZWdpc3RlcmVkICE9IG51bGwgJiYgcmVnaXN0ZXJlZFthc1N0cmluZ10gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHN0cmluZyArPSBrZXkgKyBcIntcIiArIHJlZ2lzdGVyZWRbYXNTdHJpbmddICsgXCJ9XCI7XG4gICAgICAgIH0gZWxzZSBpZiAoaXNQcm9jZXNzYWJsZVZhbHVlKGFzU3RyaW5nKSkge1xuICAgICAgICAgIHN0cmluZyArPSBwcm9jZXNzU3R5bGVOYW1lKGtleSkgKyBcIjpcIiArIHByb2Nlc3NTdHlsZVZhbHVlKGtleSwgYXNTdHJpbmcpICsgXCI7XCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChrZXkgPT09ICdOT19DT01QT05FTlRfU0VMRUNUT1InICYmIGlzRGV2ZWxvcG1lbnQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3Iobm9Db21wb25lbnRTZWxlY3Rvck1lc3NhZ2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHR5cGVvZiB2YWx1ZVswXSA9PT0gJ3N0cmluZycgJiYgKHJlZ2lzdGVyZWQgPT0gbnVsbCB8fCByZWdpc3RlcmVkW3ZhbHVlWzBdXSA9PT0gdW5kZWZpbmVkKSkge1xuICAgICAgICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCB2YWx1ZS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIGlmIChpc1Byb2Nlc3NhYmxlVmFsdWUodmFsdWVbX2ldKSkge1xuICAgICAgICAgICAgICBzdHJpbmcgKz0gcHJvY2Vzc1N0eWxlTmFtZShrZXkpICsgXCI6XCIgKyBwcm9jZXNzU3R5bGVWYWx1ZShrZXksIHZhbHVlW19pXSkgKyBcIjtcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdmFyIGludGVycG9sYXRlZCA9IGhhbmRsZUludGVycG9sYXRpb24obWVyZ2VkUHJvcHMsIHJlZ2lzdGVyZWQsIHZhbHVlKTtcblxuICAgICAgICAgIHN3aXRjaCAoa2V5KSB7XG4gICAgICAgICAgICBjYXNlICdhbmltYXRpb24nOlxuICAgICAgICAgICAgY2FzZSAnYW5pbWF0aW9uTmFtZSc6XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBzdHJpbmcgKz0gcHJvY2Vzc1N0eWxlTmFtZShrZXkpICsgXCI6XCIgKyBpbnRlcnBvbGF0ZWQgKyBcIjtcIjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaWYgKGtleSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoVU5ERUZJTkVEX0FTX09CSkVDVF9LRVlfRVJST1IpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHN0cmluZyArPSBrZXkgKyBcIntcIiArIGludGVycG9sYXRlZCArIFwifVwiO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHN0cmluZztcbn1cblxudmFyIGxhYmVsUGF0dGVybiA9IC9sYWJlbDpcXHMqKFteXFxzO3tdKylcXHMqKDt8JCkvZzsgLy8gdGhpcyBpcyB0aGUgY3Vyc29yIGZvciBrZXlmcmFtZXNcbi8vIGtleWZyYW1lcyBhcmUgc3RvcmVkIG9uIHRoZSBTZXJpYWxpemVkU3R5bGVzIG9iamVjdCBhcyBhIGxpbmtlZCBsaXN0XG5cbnZhciBjdXJzb3I7XG5mdW5jdGlvbiBzZXJpYWxpemVTdHlsZXMoYXJncywgcmVnaXN0ZXJlZCwgbWVyZ2VkUHJvcHMpIHtcbiAgaWYgKGFyZ3MubGVuZ3RoID09PSAxICYmIHR5cGVvZiBhcmdzWzBdID09PSAnb2JqZWN0JyAmJiBhcmdzWzBdICE9PSBudWxsICYmIGFyZ3NbMF0uc3R5bGVzICE9PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gYXJnc1swXTtcbiAgfVxuXG4gIHZhciBzdHJpbmdNb2RlID0gdHJ1ZTtcbiAgdmFyIHN0eWxlcyA9ICcnO1xuICBjdXJzb3IgPSB1bmRlZmluZWQ7XG4gIHZhciBzdHJpbmdzID0gYXJnc1swXTtcblxuICBpZiAoc3RyaW5ncyA9PSBudWxsIHx8IHN0cmluZ3MucmF3ID09PSB1bmRlZmluZWQpIHtcbiAgICBzdHJpbmdNb2RlID0gZmFsc2U7XG4gICAgc3R5bGVzICs9IGhhbmRsZUludGVycG9sYXRpb24obWVyZ2VkUHJvcHMsIHJlZ2lzdGVyZWQsIHN0cmluZ3MpO1xuICB9IGVsc2Uge1xuICAgIHZhciBhc1RlbXBsYXRlU3RyaW5nc0FyciA9IHN0cmluZ3M7XG5cbiAgICBpZiAoYXNUZW1wbGF0ZVN0cmluZ3NBcnJbMF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgY29uc29sZS5lcnJvcihJTExFR0FMX0VTQ0FQRV9TRVFVRU5DRV9FUlJPUik7XG4gICAgfVxuXG4gICAgc3R5bGVzICs9IGFzVGVtcGxhdGVTdHJpbmdzQXJyWzBdO1xuICB9IC8vIHdlIHN0YXJ0IGF0IDEgc2luY2Ugd2UndmUgYWxyZWFkeSBoYW5kbGVkIHRoZSBmaXJzdCBhcmdcblxuXG4gIGZvciAodmFyIGkgPSAxOyBpIDwgYXJncy5sZW5ndGg7IGkrKykge1xuICAgIHN0eWxlcyArPSBoYW5kbGVJbnRlcnBvbGF0aW9uKG1lcmdlZFByb3BzLCByZWdpc3RlcmVkLCBhcmdzW2ldKTtcblxuICAgIGlmIChzdHJpbmdNb2RlKSB7XG4gICAgICB2YXIgdGVtcGxhdGVTdHJpbmdzQXJyID0gc3RyaW5ncztcblxuICAgICAgaWYgKHRlbXBsYXRlU3RyaW5nc0FycltpXSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoSUxMRUdBTF9FU0NBUEVfU0VRVUVOQ0VfRVJST1IpO1xuICAgICAgfVxuXG4gICAgICBzdHlsZXMgKz0gdGVtcGxhdGVTdHJpbmdzQXJyW2ldO1xuICAgIH1cbiAgfSAvLyB1c2luZyBhIGdsb2JhbCByZWdleCB3aXRoIC5leGVjIGlzIHN0YXRlZnVsIHNvIGxhc3RJbmRleCBoYXMgdG8gYmUgcmVzZXQgZWFjaCB0aW1lXG5cblxuICBsYWJlbFBhdHRlcm4ubGFzdEluZGV4ID0gMDtcbiAgdmFyIGlkZW50aWZpZXJOYW1lID0gJyc7XG4gIHZhciBtYXRjaDsgLy8gaHR0cHM6Ly9lc2JlbmNoLmNvbS9iZW5jaC81YjgwOWMyY2YyOTQ5ODAwYTBmNjFmYjVcblxuICB3aGlsZSAoKG1hdGNoID0gbGFiZWxQYXR0ZXJuLmV4ZWMoc3R5bGVzKSkgIT09IG51bGwpIHtcbiAgICBpZGVudGlmaWVyTmFtZSArPSAnLScgKyBtYXRjaFsxXTtcbiAgfVxuXG4gIHZhciBuYW1lID0gaGFzaFN0cmluZyhzdHlsZXMpICsgaWRlbnRpZmllck5hbWU7XG5cbiAge1xuICAgIHZhciBkZXZTdHlsZXMgPSB7XG4gICAgICBuYW1lOiBuYW1lLFxuICAgICAgc3R5bGVzOiBzdHlsZXMsXG4gICAgICBuZXh0OiBjdXJzb3IsXG4gICAgICB0b1N0cmluZzogZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgICAgIHJldHVybiBcIllvdSBoYXZlIHRyaWVkIHRvIHN0cmluZ2lmeSBvYmplY3QgcmV0dXJuZWQgZnJvbSBgY3NzYCBmdW5jdGlvbi4gSXQgaXNuJ3Qgc3VwcG9zZWQgdG8gYmUgdXNlZCBkaXJlY3RseSAoZS5nLiBhcyB2YWx1ZSBvZiB0aGUgYGNsYXNzTmFtZWAgcHJvcCksIGJ1dCByYXRoZXIgaGFuZGVkIHRvIGVtb3Rpb24gc28gaXQgY2FuIGhhbmRsZSBpdCAoZS5nLiBhcyB2YWx1ZSBvZiBgY3NzYCBwcm9wKS5cIjtcbiAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBkZXZTdHlsZXM7XG4gIH1cbn1cblxuZXhwb3J0IHsgc2VyaWFsaXplU3R5bGVzIH07XG4iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbnZhciBzeW5jRmFsbGJhY2sgPSBmdW5jdGlvbiBzeW5jRmFsbGJhY2soY3JlYXRlKSB7XG4gIHJldHVybiBjcmVhdGUoKTtcbn07XG5cbnZhciB1c2VJbnNlcnRpb25FZmZlY3QgPSBSZWFjdFsndXNlSW5zZXJ0aW9uJyArICdFZmZlY3QnXSA/IFJlYWN0Wyd1c2VJbnNlcnRpb24nICsgJ0VmZmVjdCddIDogZmFsc2U7XG52YXIgdXNlSW5zZXJ0aW9uRWZmZWN0QWx3YXlzV2l0aFN5bmNGYWxsYmFjayA9IHVzZUluc2VydGlvbkVmZmVjdCB8fCBzeW5jRmFsbGJhY2s7XG52YXIgdXNlSW5zZXJ0aW9uRWZmZWN0V2l0aExheW91dEZhbGxiYWNrID0gdXNlSW5zZXJ0aW9uRWZmZWN0IHx8IFJlYWN0LnVzZUxheW91dEVmZmVjdDtcblxuZXhwb3J0IHsgdXNlSW5zZXJ0aW9uRWZmZWN0QWx3YXlzV2l0aFN5bmNGYWxsYmFjaywgdXNlSW5zZXJ0aW9uRWZmZWN0V2l0aExheW91dEZhbGxiYWNrIH07XG4iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDb250ZXh0LCBmb3J3YXJkUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNyZWF0ZUNhY2hlIGZyb20gJ0BlbW90aW9uL2NhY2hlJztcbmltcG9ydCBfZXh0ZW5kcyBmcm9tICdAYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS9leHRlbmRzJztcbmltcG9ydCB3ZWFrTWVtb2l6ZSBmcm9tICdAZW1vdGlvbi93ZWFrLW1lbW9pemUnO1xuaW1wb3J0IGhvaXN0Tm9uUmVhY3RTdGF0aWNzIGZyb20gJy4uL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qcyc7XG5pbXBvcnQgeyBnZXRSZWdpc3RlcmVkU3R5bGVzLCByZWdpc3RlclN0eWxlcywgaW5zZXJ0U3R5bGVzIH0gZnJvbSAnQGVtb3Rpb24vdXRpbHMnO1xuaW1wb3J0IHsgc2VyaWFsaXplU3R5bGVzIH0gZnJvbSAnQGVtb3Rpb24vc2VyaWFsaXplJztcbmltcG9ydCB7IHVzZUluc2VydGlvbkVmZmVjdEFsd2F5c1dpdGhTeW5jRmFsbGJhY2sgfSBmcm9tICdAZW1vdGlvbi91c2UtaW5zZXJ0aW9uLWVmZmVjdC13aXRoLWZhbGxiYWNrcyc7XG5cbnZhciBFbW90aW9uQ2FjaGVDb250ZXh0ID0gLyogI19fUFVSRV9fICovUmVhY3QuY3JlYXRlQ29udGV4dCggLy8gd2UncmUgZG9pbmcgdGhpcyB0byBhdm9pZCBwcmVjb25zdHJ1Y3QncyBkZWFkIGNvZGUgZWxpbWluYXRpb24gaW4gdGhpcyBvbmUgY2FzZVxuLy8gYmVjYXVzZSB0aGlzIG1vZHVsZSBpcyBwcmltYXJpbHkgaW50ZW5kZWQgZm9yIHRoZSBicm93c2VyIGFuZCBub2RlXG4vLyBidXQgaXQncyBhbHNvIHJlcXVpcmVkIGluIHJlYWN0IG5hdGl2ZSBhbmQgc2ltaWxhciBlbnZpcm9ubWVudHMgc29tZXRpbWVzXG4vLyBhbmQgd2UgY291bGQgaGF2ZSBhIHNwZWNpYWwgYnVpbGQganVzdCBmb3IgdGhhdFxuLy8gYnV0IHRoaXMgaXMgbXVjaCBlYXNpZXIgYW5kIHRoZSBuYXRpdmUgcGFja2FnZXNcbi8vIG1pZ2h0IHVzZSBhIGRpZmZlcmVudCB0aGVtZSBjb250ZXh0IGluIHRoZSBmdXR1cmUgYW55d2F5XG50eXBlb2YgSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnID8gLyogI19fUFVSRV9fICovY3JlYXRlQ2FjaGUoe1xuICBrZXk6ICdjc3MnXG59KSA6IG51bGwpO1xuXG57XG4gIEVtb3Rpb25DYWNoZUNvbnRleHQuZGlzcGxheU5hbWUgPSAnRW1vdGlvbkNhY2hlQ29udGV4dCc7XG59XG5cbnZhciBDYWNoZVByb3ZpZGVyID0gRW1vdGlvbkNhY2hlQ29udGV4dC5Qcm92aWRlcjtcbnZhciBfX3Vuc2FmZV91c2VFbW90aW9uQ2FjaGUgPSBmdW5jdGlvbiB1c2VFbW90aW9uQ2FjaGUoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0KEVtb3Rpb25DYWNoZUNvbnRleHQpO1xufTtcblxudmFyIHdpdGhFbW90aW9uQ2FjaGUgPSBmdW5jdGlvbiB3aXRoRW1vdGlvbkNhY2hlKGZ1bmMpIHtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9mb3J3YXJkUmVmKGZ1bmN0aW9uIChwcm9wcywgcmVmKSB7XG4gICAgLy8gdGhlIGNhY2hlIHdpbGwgbmV2ZXIgYmUgbnVsbCBpbiB0aGUgYnJvd3NlclxuICAgIHZhciBjYWNoZSA9IHVzZUNvbnRleHQoRW1vdGlvbkNhY2hlQ29udGV4dCk7XG4gICAgcmV0dXJuIGZ1bmMocHJvcHMsIGNhY2hlLCByZWYpO1xuICB9KTtcbn07XG5cbnZhciBUaGVtZUNvbnRleHQgPSAvKiAjX19QVVJFX18gKi9SZWFjdC5jcmVhdGVDb250ZXh0KHt9KTtcblxue1xuICBUaGVtZUNvbnRleHQuZGlzcGxheU5hbWUgPSAnRW1vdGlvblRoZW1lQ29udGV4dCc7XG59XG5cbnZhciB1c2VUaGVtZSA9IGZ1bmN0aW9uIHVzZVRoZW1lKCkge1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChUaGVtZUNvbnRleHQpO1xufTtcblxudmFyIGdldFRoZW1lID0gZnVuY3Rpb24gZ2V0VGhlbWUob3V0ZXJUaGVtZSwgdGhlbWUpIHtcbiAgaWYgKHR5cGVvZiB0aGVtZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHZhciBtZXJnZWRUaGVtZSA9IHRoZW1lKG91dGVyVGhlbWUpO1xuXG4gICAgaWYgKChtZXJnZWRUaGVtZSA9PSBudWxsIHx8IHR5cGVvZiBtZXJnZWRUaGVtZSAhPT0gJ29iamVjdCcgfHwgQXJyYXkuaXNBcnJheShtZXJnZWRUaGVtZSkpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1tUaGVtZVByb3ZpZGVyXSBQbGVhc2UgcmV0dXJuIGFuIG9iamVjdCBmcm9tIHlvdXIgdGhlbWUgZnVuY3Rpb24sIGkuZS4gdGhlbWU9eygpID0+ICh7fSl9IScpO1xuICAgIH1cblxuICAgIHJldHVybiBtZXJnZWRUaGVtZTtcbiAgfVxuXG4gIGlmICgodGhlbWUgPT0gbnVsbCB8fCB0eXBlb2YgdGhlbWUgIT09ICdvYmplY3QnIHx8IEFycmF5LmlzQXJyYXkodGhlbWUpKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignW1RoZW1lUHJvdmlkZXJdIFBsZWFzZSBtYWtlIHlvdXIgdGhlbWUgcHJvcCBhIHBsYWluIG9iamVjdCcpO1xuICB9XG5cbiAgcmV0dXJuIF9leHRlbmRzKHt9LCBvdXRlclRoZW1lLCB0aGVtZSk7XG59O1xuXG52YXIgY3JlYXRlQ2FjaGVXaXRoVGhlbWUgPSAvKiAjX19QVVJFX18gKi93ZWFrTWVtb2l6ZShmdW5jdGlvbiAob3V0ZXJUaGVtZSkge1xuICByZXR1cm4gd2Vha01lbW9pemUoZnVuY3Rpb24gKHRoZW1lKSB7XG4gICAgcmV0dXJuIGdldFRoZW1lKG91dGVyVGhlbWUsIHRoZW1lKTtcbiAgfSk7XG59KTtcbnZhciBUaGVtZVByb3ZpZGVyID0gZnVuY3Rpb24gVGhlbWVQcm92aWRlcihwcm9wcykge1xuICB2YXIgdGhlbWUgPSBSZWFjdC51c2VDb250ZXh0KFRoZW1lQ29udGV4dCk7XG5cbiAgaWYgKHByb3BzLnRoZW1lICE9PSB0aGVtZSkge1xuICAgIHRoZW1lID0gY3JlYXRlQ2FjaGVXaXRoVGhlbWUodGhlbWUpKHByb3BzLnRoZW1lKTtcbiAgfVxuXG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChUaGVtZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdGhlbWVcbiAgfSwgcHJvcHMuY2hpbGRyZW4pO1xufTtcbmZ1bmN0aW9uIHdpdGhUaGVtZShDb21wb25lbnQpIHtcbiAgdmFyIGNvbXBvbmVudE5hbWUgPSBDb21wb25lbnQuZGlzcGxheU5hbWUgfHwgQ29tcG9uZW50Lm5hbWUgfHwgJ0NvbXBvbmVudCc7XG4gIHZhciBXaXRoVGhlbWUgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiByZW5kZXIocHJvcHMsIHJlZikge1xuICAgIHZhciB0aGVtZSA9IFJlYWN0LnVzZUNvbnRleHQoVGhlbWVDb250ZXh0KTtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoQ29tcG9uZW50LCBfZXh0ZW5kcyh7XG4gICAgICB0aGVtZTogdGhlbWUsXG4gICAgICByZWY6IHJlZlxuICAgIH0sIHByb3BzKSk7XG4gIH0pO1xuICBXaXRoVGhlbWUuZGlzcGxheU5hbWUgPSBcIldpdGhUaGVtZShcIiArIGNvbXBvbmVudE5hbWUgKyBcIilcIjtcbiAgcmV0dXJuIGhvaXN0Tm9uUmVhY3RTdGF0aWNzKFdpdGhUaGVtZSwgQ29tcG9uZW50KTtcbn1cblxudmFyIGhhc093biA9IHt9Lmhhc093blByb3BlcnR5O1xuXG52YXIgZ2V0TGFzdFBhcnQgPSBmdW5jdGlvbiBnZXRMYXN0UGFydChmdW5jdGlvbk5hbWUpIHtcbiAgLy8gVGhlIG1hdGNoIG1heSBiZSBzb21ldGhpbmcgbGlrZSAnT2JqZWN0LmNyZWF0ZUVtb3Rpb25Qcm9wcycgb3JcbiAgLy8gJ0xvYWRlci5wcm90b3R5cGUucmVuZGVyJ1xuICB2YXIgcGFydHMgPSBmdW5jdGlvbk5hbWUuc3BsaXQoJy4nKTtcbiAgcmV0dXJuIHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdO1xufTtcblxudmFyIGdldEZ1bmN0aW9uTmFtZUZyb21TdGFja1RyYWNlTGluZSA9IGZ1bmN0aW9uIGdldEZ1bmN0aW9uTmFtZUZyb21TdGFja1RyYWNlTGluZShsaW5lKSB7XG4gIC8vIFY4XG4gIHZhciBtYXRjaCA9IC9eXFxzK2F0XFxzKyhbQS1aYS16MC05JC5dKylcXHMvLmV4ZWMobGluZSk7XG4gIGlmIChtYXRjaCkgcmV0dXJuIGdldExhc3RQYXJ0KG1hdGNoWzFdKTsgLy8gU2FmYXJpIC8gRmlyZWZveFxuXG4gIG1hdGNoID0gL14oW0EtWmEtejAtOSQuXSspQC8uZXhlYyhsaW5lKTtcbiAgaWYgKG1hdGNoKSByZXR1cm4gZ2V0TGFzdFBhcnQobWF0Y2hbMV0pO1xuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcblxudmFyIGludGVybmFsUmVhY3RGdW5jdGlvbk5hbWVzID0gLyogI19fUFVSRV9fICovbmV3IFNldChbJ3JlbmRlcldpdGhIb29rcycsICdwcm9jZXNzQ2hpbGQnLCAnZmluaXNoQ2xhc3NDb21wb25lbnQnLCAncmVuZGVyVG9TdHJpbmcnXSk7IC8vIFRoZXNlIGlkZW50aWZpZXJzIGNvbWUgZnJvbSBlcnJvciBzdGFja3MsIHNvIHRoZXkgaGF2ZSB0byBiZSB2YWxpZCBKU1xuLy8gaWRlbnRpZmllcnMsIHRodXMgd2Ugb25seSBuZWVkIHRvIHJlcGxhY2Ugd2hhdCBpcyBhIHZhbGlkIGNoYXJhY3RlciBmb3IgSlMsXG4vLyBidXQgbm90IGZvciBDU1MuXG5cbnZhciBzYW5pdGl6ZUlkZW50aWZpZXIgPSBmdW5jdGlvbiBzYW5pdGl6ZUlkZW50aWZpZXIoaWRlbnRpZmllcikge1xuICByZXR1cm4gaWRlbnRpZmllci5yZXBsYWNlKC9cXCQvZywgJy0nKTtcbn07XG5cbnZhciBnZXRMYWJlbEZyb21TdGFja1RyYWNlID0gZnVuY3Rpb24gZ2V0TGFiZWxGcm9tU3RhY2tUcmFjZShzdGFja1RyYWNlKSB7XG4gIGlmICghc3RhY2tUcmFjZSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgdmFyIGxpbmVzID0gc3RhY2tUcmFjZS5zcGxpdCgnXFxuJyk7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgIHZhciBmdW5jdGlvbk5hbWUgPSBnZXRGdW5jdGlvbk5hbWVGcm9tU3RhY2tUcmFjZUxpbmUobGluZXNbaV0pOyAvLyBUaGUgZmlyc3QgbGluZSBvZiBWOCBzdGFjayB0cmFjZXMgaXMganVzdCBcIkVycm9yXCJcblxuICAgIGlmICghZnVuY3Rpb25OYW1lKSBjb250aW51ZTsgLy8gSWYgd2UgcmVhY2ggb25lIG9mIHRoZXNlLCB3ZSBoYXZlIGdvbmUgdG9vIGZhciBhbmQgc2hvdWxkIHF1aXRcblxuICAgIGlmIChpbnRlcm5hbFJlYWN0RnVuY3Rpb25OYW1lcy5oYXMoZnVuY3Rpb25OYW1lKSkgYnJlYWs7IC8vIFRoZSBjb21wb25lbnQgbmFtZSBpcyB0aGUgZmlyc3QgZnVuY3Rpb24gaW4gdGhlIHN0YWNrIHRoYXQgc3RhcnRzIHdpdGggYW5cbiAgICAvLyB1cHBlcmNhc2UgbGV0dGVyXG5cbiAgICBpZiAoL15bQS1aXS8udGVzdChmdW5jdGlvbk5hbWUpKSByZXR1cm4gc2FuaXRpemVJZGVudGlmaWVyKGZ1bmN0aW9uTmFtZSk7XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcblxudmFyIHR5cGVQcm9wTmFtZSA9ICdfX0VNT1RJT05fVFlQRV9QTEVBU0VfRE9fTk9UX1VTRV9fJztcbnZhciBsYWJlbFByb3BOYW1lID0gJ19fRU1PVElPTl9MQUJFTF9QTEVBU0VfRE9fTk9UX1VTRV9fJztcbnZhciBjcmVhdGVFbW90aW9uUHJvcHMgPSBmdW5jdGlvbiBjcmVhdGVFbW90aW9uUHJvcHModHlwZSwgcHJvcHMpIHtcbiAgaWYgKHR5cGVvZiBwcm9wcy5jc3MgPT09ICdzdHJpbmcnICYmIC8vIGNoZWNrIGlmIHRoZXJlIGlzIGEgY3NzIGRlY2xhcmF0aW9uXG4gIHByb3BzLmNzcy5pbmRleE9mKCc6JykgIT09IC0xKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiU3RyaW5ncyBhcmUgbm90IGFsbG93ZWQgYXMgY3NzIHByb3AgdmFsdWVzLCBwbGVhc2Ugd3JhcCBpdCBpbiBhIGNzcyB0ZW1wbGF0ZSBsaXRlcmFsIGZyb20gJ0BlbW90aW9uL3JlYWN0JyBsaWtlIHRoaXM6IGNzc2BcIiArIHByb3BzLmNzcyArIFwiYFwiKTtcbiAgfVxuXG4gIHZhciBuZXdQcm9wcyA9IHt9O1xuXG4gIGZvciAodmFyIF9rZXkgaW4gcHJvcHMpIHtcbiAgICBpZiAoaGFzT3duLmNhbGwocHJvcHMsIF9rZXkpKSB7XG4gICAgICBuZXdQcm9wc1tfa2V5XSA9IHByb3BzW19rZXldO1xuICAgIH1cbiAgfVxuXG4gIG5ld1Byb3BzW3R5cGVQcm9wTmFtZV0gPSB0eXBlOyAvLyBSdW50aW1lIGxhYmVsaW5nIGlzIGFuIG9wdC1pbiBmZWF0dXJlIGJlY2F1c2U6XG4gIC8vIC0gSXQgY2F1c2VzIGh5ZHJhdGlvbiB3YXJuaW5ncyB3aGVuIHVzaW5nIFNhZmFyaSBhbmQgU1NSXG4gIC8vIC0gSXQgY2FuIGRlZ3JhZGUgcGVyZm9ybWFuY2UgaWYgdGhlcmUgYXJlIGEgaHVnZSBudW1iZXIgb2YgZWxlbWVudHNcbiAgLy9cbiAgLy8gRXZlbiBpZiB0aGUgZmxhZyBpcyBzZXQsIHdlIHN0aWxsIGRvbid0IGNvbXB1dGUgdGhlIGxhYmVsIGlmIGl0IGhhcyBhbHJlYWR5XG4gIC8vIGJlZW4gZGV0ZXJtaW5lZCBieSB0aGUgQmFiZWwgcGx1Z2luLlxuXG4gIGlmICh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCcgJiYgISFnbG9iYWxUaGlzLkVNT1RJT05fUlVOVElNRV9BVVRPX0xBQkVMICYmICEhcHJvcHMuY3NzICYmICh0eXBlb2YgcHJvcHMuY3NzICE9PSAnb2JqZWN0JyB8fCAhKCduYW1lJyBpbiBwcm9wcy5jc3MpIHx8IHR5cGVvZiBwcm9wcy5jc3MubmFtZSAhPT0gJ3N0cmluZycgfHwgcHJvcHMuY3NzLm5hbWUuaW5kZXhPZignLScpID09PSAtMSkpIHtcbiAgICB2YXIgbGFiZWwgPSBnZXRMYWJlbEZyb21TdGFja1RyYWNlKG5ldyBFcnJvcigpLnN0YWNrKTtcbiAgICBpZiAobGFiZWwpIG5ld1Byb3BzW2xhYmVsUHJvcE5hbWVdID0gbGFiZWw7XG4gIH1cblxuICByZXR1cm4gbmV3UHJvcHM7XG59O1xuXG52YXIgSW5zZXJ0aW9uID0gZnVuY3Rpb24gSW5zZXJ0aW9uKF9yZWYpIHtcbiAgdmFyIGNhY2hlID0gX3JlZi5jYWNoZSxcbiAgICAgIHNlcmlhbGl6ZWQgPSBfcmVmLnNlcmlhbGl6ZWQsXG4gICAgICBpc1N0cmluZ1RhZyA9IF9yZWYuaXNTdHJpbmdUYWc7XG4gIHJlZ2lzdGVyU3R5bGVzKGNhY2hlLCBzZXJpYWxpemVkLCBpc1N0cmluZ1RhZyk7XG4gIHVzZUluc2VydGlvbkVmZmVjdEFsd2F5c1dpdGhTeW5jRmFsbGJhY2soZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBpbnNlcnRTdHlsZXMoY2FjaGUsIHNlcmlhbGl6ZWQsIGlzU3RyaW5nVGFnKTtcbiAgfSk7XG5cbiAgcmV0dXJuIG51bGw7XG59O1xuXG52YXIgRW1vdGlvbiA9IC8qICNfX1BVUkVfXyAqL3dpdGhFbW90aW9uQ2FjaGUoZnVuY3Rpb24gKHByb3BzLCBjYWNoZSwgcmVmKSB7XG4gIHZhciBjc3NQcm9wID0gcHJvcHMuY3NzOyAvLyBzbyB0aGF0IHVzaW5nIGBjc3NgIGZyb20gYGVtb3Rpb25gIGFuZCBwYXNzaW5nIHRoZSByZXN1bHQgdG8gdGhlIGNzcyBwcm9wIHdvcmtzXG4gIC8vIG5vdCBwYXNzaW5nIHRoZSByZWdpc3RlcmVkIGNhY2hlIHRvIHNlcmlhbGl6ZVN0eWxlcyBiZWNhdXNlIGl0IHdvdWxkXG4gIC8vIG1ha2UgY2VydGFpbiBiYWJlbCBvcHRpbWlzYXRpb25zIG5vdCBwb3NzaWJsZVxuXG4gIGlmICh0eXBlb2YgY3NzUHJvcCA9PT0gJ3N0cmluZycgJiYgY2FjaGUucmVnaXN0ZXJlZFtjc3NQcm9wXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY3NzUHJvcCA9IGNhY2hlLnJlZ2lzdGVyZWRbY3NzUHJvcF07XG4gIH1cblxuICB2YXIgV3JhcHBlZENvbXBvbmVudCA9IHByb3BzW3R5cGVQcm9wTmFtZV07XG4gIHZhciByZWdpc3RlcmVkU3R5bGVzID0gW2Nzc1Byb3BdO1xuICB2YXIgY2xhc3NOYW1lID0gJyc7XG5cbiAgaWYgKHR5cGVvZiBwcm9wcy5jbGFzc05hbWUgPT09ICdzdHJpbmcnKSB7XG4gICAgY2xhc3NOYW1lID0gZ2V0UmVnaXN0ZXJlZFN0eWxlcyhjYWNoZS5yZWdpc3RlcmVkLCByZWdpc3RlcmVkU3R5bGVzLCBwcm9wcy5jbGFzc05hbWUpO1xuICB9IGVsc2UgaWYgKHByb3BzLmNsYXNzTmFtZSAhPSBudWxsKSB7XG4gICAgY2xhc3NOYW1lID0gcHJvcHMuY2xhc3NOYW1lICsgXCIgXCI7XG4gIH1cblxuICB2YXIgc2VyaWFsaXplZCA9IHNlcmlhbGl6ZVN0eWxlcyhyZWdpc3RlcmVkU3R5bGVzLCB1bmRlZmluZWQsIFJlYWN0LnVzZUNvbnRleHQoVGhlbWVDb250ZXh0KSk7XG5cbiAgaWYgKHNlcmlhbGl6ZWQubmFtZS5pbmRleE9mKCctJykgPT09IC0xKSB7XG4gICAgdmFyIGxhYmVsRnJvbVN0YWNrID0gcHJvcHNbbGFiZWxQcm9wTmFtZV07XG5cbiAgICBpZiAobGFiZWxGcm9tU3RhY2spIHtcbiAgICAgIHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVTdHlsZXMoW3NlcmlhbGl6ZWQsICdsYWJlbDonICsgbGFiZWxGcm9tU3RhY2sgKyAnOyddKTtcbiAgICB9XG4gIH1cblxuICBjbGFzc05hbWUgKz0gY2FjaGUua2V5ICsgXCItXCIgKyBzZXJpYWxpemVkLm5hbWU7XG4gIHZhciBuZXdQcm9wcyA9IHt9O1xuXG4gIGZvciAodmFyIF9rZXkyIGluIHByb3BzKSB7XG4gICAgaWYgKGhhc093bi5jYWxsKHByb3BzLCBfa2V5MikgJiYgX2tleTIgIT09ICdjc3MnICYmIF9rZXkyICE9PSB0eXBlUHJvcE5hbWUgJiYgKF9rZXkyICE9PSBsYWJlbFByb3BOYW1lKSkge1xuICAgICAgbmV3UHJvcHNbX2tleTJdID0gcHJvcHNbX2tleTJdO1xuICAgIH1cbiAgfVxuXG4gIG5ld1Byb3BzLmNsYXNzTmFtZSA9IGNsYXNzTmFtZTtcblxuICBpZiAocmVmKSB7XG4gICAgbmV3UHJvcHMucmVmID0gcmVmO1xuICB9XG5cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChJbnNlcnRpb24sIHtcbiAgICBjYWNoZTogY2FjaGUsXG4gICAgc2VyaWFsaXplZDogc2VyaWFsaXplZCxcbiAgICBpc1N0cmluZ1RhZzogdHlwZW9mIFdyYXBwZWRDb21wb25lbnQgPT09ICdzdHJpbmcnXG4gIH0pLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChXcmFwcGVkQ29tcG9uZW50LCBuZXdQcm9wcykpO1xufSk7XG5cbntcbiAgRW1vdGlvbi5kaXNwbGF5TmFtZSA9ICdFbW90aW9uQ3NzUHJvcEludGVybmFsJztcbn1cblxudmFyIEVtb3Rpb24kMSA9IEVtb3Rpb247XG5cbmV4cG9ydCB7IENhY2hlUHJvdmlkZXIgYXMgQywgRW1vdGlvbiQxIGFzIEUsIFRoZW1lQ29udGV4dCBhcyBULCBfX3Vuc2FmZV91c2VFbW90aW9uQ2FjaGUgYXMgXywgVGhlbWVQcm92aWRlciBhcyBhLCB3aXRoVGhlbWUgYXMgYiwgY3JlYXRlRW1vdGlvblByb3BzIGFzIGMsIGhhc093biBhcyBoLCB1c2VUaGVtZSBhcyB1LCB3aXRoRW1vdGlvbkNhY2hlIGFzIHcgfTtcbiIsImltcG9ydCB7IGggYXMgaGFzT3duLCBFIGFzIEVtb3Rpb24sIGMgYXMgY3JlYXRlRW1vdGlvblByb3BzLCB3IGFzIHdpdGhFbW90aW9uQ2FjaGUsIFQgYXMgVGhlbWVDb250ZXh0IH0gZnJvbSAnLi9lbW90aW9uLWVsZW1lbnQtNDg5NDU5ZjIuYnJvd3Nlci5kZXZlbG9wbWVudC5lc20uanMnO1xuZXhwb3J0IHsgQyBhcyBDYWNoZVByb3ZpZGVyLCBUIGFzIFRoZW1lQ29udGV4dCwgYSBhcyBUaGVtZVByb3ZpZGVyLCBfIGFzIF9fdW5zYWZlX3VzZUVtb3Rpb25DYWNoZSwgdSBhcyB1c2VUaGVtZSwgdyBhcyB3aXRoRW1vdGlvbkNhY2hlLCBiIGFzIHdpdGhUaGVtZSB9IGZyb20gJy4vZW1vdGlvbi1lbGVtZW50LTQ4OTQ1OWYyLmJyb3dzZXIuZGV2ZWxvcG1lbnQuZXNtLmpzJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGluc2VydFN0eWxlcywgcmVnaXN0ZXJTdHlsZXMsIGdldFJlZ2lzdGVyZWRTdHlsZXMgfSBmcm9tICdAZW1vdGlvbi91dGlscyc7XG5pbXBvcnQgeyB1c2VJbnNlcnRpb25FZmZlY3RXaXRoTGF5b3V0RmFsbGJhY2ssIHVzZUluc2VydGlvbkVmZmVjdEFsd2F5c1dpdGhTeW5jRmFsbGJhY2sgfSBmcm9tICdAZW1vdGlvbi91c2UtaW5zZXJ0aW9uLWVmZmVjdC13aXRoLWZhbGxiYWNrcyc7XG5pbXBvcnQgeyBzZXJpYWxpemVTdHlsZXMgfSBmcm9tICdAZW1vdGlvbi9zZXJpYWxpemUnO1xuaW1wb3J0ICdAZW1vdGlvbi9jYWNoZSc7XG5pbXBvcnQgJ0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgJ0BlbW90aW9uL3dlYWstbWVtb2l6ZSc7XG5pbXBvcnQgJy4uL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qcyc7XG5pbXBvcnQgJ2hvaXN0LW5vbi1yZWFjdC1zdGF0aWNzJztcblxudmFyIGlzRGV2ZWxvcG1lbnQgPSB0cnVlO1xuXG52YXIgcGtnID0ge1xuXHRuYW1lOiBcIkBlbW90aW9uL3JlYWN0XCIsXG5cdHZlcnNpb246IFwiMTEuMTQuMFwiLFxuXHRtYWluOiBcImRpc3QvZW1vdGlvbi1yZWFjdC5janMuanNcIixcblx0bW9kdWxlOiBcImRpc3QvZW1vdGlvbi1yZWFjdC5lc20uanNcIixcblx0dHlwZXM6IFwiZGlzdC9lbW90aW9uLXJlYWN0LmNqcy5kLnRzXCIsXG5cdGV4cG9ydHM6IHtcblx0XHRcIi5cIjoge1xuXHRcdFx0dHlwZXM6IHtcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0ZGV2ZWxvcG1lbnQ6IHtcblx0XHRcdFx0XCJlZGdlLWxpZ2h0XCI6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdFx0bW9kdWxlOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHdvcmtlcmQ6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0YnJvd3Nlcjoge1xuXHRcdFx0XHRcdG1vZHVsZTogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qc1wiLFxuXHRcdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuYnJvd3Nlci5kZXZlbG9wbWVudC5janMubWpzXCIsXG5cdFx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuYnJvd3Nlci5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRtb2R1bGU6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZGV2ZWxvcG1lbnQuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZGV2ZWxvcG1lbnQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdFwiZWRnZS1saWdodFwiOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyZDoge1xuXHRcdFx0XHRtb2R1bGU6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2Rpc3QvZW1vdGlvbi1yZWFjdC5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZWRnZS1saWdodC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdGJyb3dzZXI6IHtcblx0XHRcdFx0bW9kdWxlOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmJyb3dzZXIuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuYnJvd3Nlci5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmJyb3dzZXIuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHRtb2R1bGU6IFwiLi9kaXN0L2Vtb3Rpb24tcmVhY3QuZXNtLmpzXCIsXG5cdFx0XHRcImltcG9ydFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmNqcy5tanNcIixcblx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vZGlzdC9lbW90aW9uLXJlYWN0LmNqcy5qc1wiXG5cdFx0fSxcblx0XHRcIi4vanN4LXJ1bnRpbWVcIjoge1xuXHRcdFx0dHlwZXM6IHtcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0ZGV2ZWxvcG1lbnQ6IHtcblx0XHRcdFx0XCJlZGdlLWxpZ2h0XCI6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdFx0bW9kdWxlOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHdvcmtlcmQ6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0YnJvd3Nlcjoge1xuXHRcdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qc1wiLFxuXHRcdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuYnJvd3Nlci5kZXZlbG9wbWVudC5janMubWpzXCIsXG5cdFx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuYnJvd3Nlci5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdFwiZWRnZS1saWdodFwiOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyZDoge1xuXHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtcnVudGltZS5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZWRnZS1saWdodC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdGJyb3dzZXI6IHtcblx0XHRcdFx0bW9kdWxlOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmJyb3dzZXIuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuYnJvd3Nlci5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmJyb3dzZXIuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHRtb2R1bGU6IFwiLi9qc3gtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LXJ1bnRpbWUuZXNtLmpzXCIsXG5cdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmNqcy5tanNcIixcblx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1ydW50aW1lLmNqcy5qc1wiXG5cdFx0fSxcblx0XHRcIi4vX2lzb2xhdGVkLWhucnNcIjoge1xuXHRcdFx0dHlwZXM6IHtcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0ZGV2ZWxvcG1lbnQ6IHtcblx0XHRcdFx0XCJlZGdlLWxpZ2h0XCI6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdFx0bW9kdWxlOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHdvcmtlcmQ6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0YnJvd3Nlcjoge1xuXHRcdFx0XHRcdG1vZHVsZTogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5icm93c2VyLmRldmVsb3BtZW50LmVzbS5qc1wiLFxuXHRcdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuYnJvd3Nlci5kZXZlbG9wbWVudC5janMubWpzXCIsXG5cdFx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuYnJvd3Nlci5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRtb2R1bGU6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZGV2ZWxvcG1lbnQuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZGV2ZWxvcG1lbnQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5kZXZlbG9wbWVudC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdFwiZWRnZS1saWdodFwiOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0d29ya2VyZDoge1xuXHRcdFx0XHRtb2R1bGU6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL19pc29sYXRlZC1obnJzL2Rpc3QvZW1vdGlvbi1yZWFjdC1faXNvbGF0ZWQtaG5ycy5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZWRnZS1saWdodC5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdGJyb3dzZXI6IHtcblx0XHRcdFx0bW9kdWxlOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmJyb3dzZXIuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuYnJvd3Nlci5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmJyb3dzZXIuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHRtb2R1bGU6IFwiLi9faXNvbGF0ZWQtaG5ycy9kaXN0L2Vtb3Rpb24tcmVhY3QtX2lzb2xhdGVkLWhucnMuZXNtLmpzXCIsXG5cdFx0XHRcImltcG9ydFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmNqcy5tanNcIixcblx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vX2lzb2xhdGVkLWhucnMvZGlzdC9lbW90aW9uLXJlYWN0LV9pc29sYXRlZC1obnJzLmNqcy5qc1wiXG5cdFx0fSxcblx0XHRcIi4vanN4LWRldi1ydW50aW1lXCI6IHtcblx0XHRcdHR5cGVzOiB7XG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHRkZXZlbG9wbWVudDoge1xuXHRcdFx0XHRcImVkZ2UtbGlnaHRcIjoge1xuXHRcdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5janMuanNcIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHR3b3JrZXI6IHtcblx0XHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmVzbS5qc1wiLFxuXHRcdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5kZXZlbG9wbWVudC5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0d29ya2VyZDoge1xuXHRcdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuZWRnZS1saWdodC5janMuanNcIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRicm93c2VyOiB7XG5cdFx0XHRcdFx0bW9kdWxlOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuYnJvd3Nlci5kZXZlbG9wbWVudC5lc20uanNcIixcblx0XHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuYnJvd3Nlci5kZXZlbG9wbWVudC5janMubWpzXCIsXG5cdFx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5icm93c2VyLmRldmVsb3BtZW50LmNqcy5qc1wiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuZGV2ZWxvcG1lbnQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmRldmVsb3BtZW50LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0XCJlZGdlLWxpZ2h0XCI6IHtcblx0XHRcdFx0bW9kdWxlOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHR3b3JrZXI6IHtcblx0XHRcdFx0bW9kdWxlOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuZWRnZS1saWdodC5lc20uanNcIixcblx0XHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLm1qc1wiLFxuXHRcdFx0XHRcImRlZmF1bHRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVkZ2UtbGlnaHQuY2pzLmpzXCJcblx0XHRcdH0sXG5cdFx0XHR3b3JrZXJkOiB7XG5cdFx0XHRcdG1vZHVsZTogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVkZ2UtbGlnaHQuZXNtLmpzXCIsXG5cdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5lZGdlLWxpZ2h0LmNqcy5tanNcIixcblx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5lZGdlLWxpZ2h0LmNqcy5qc1wiXG5cdFx0XHR9LFxuXHRcdFx0YnJvd3Nlcjoge1xuXHRcdFx0XHRtb2R1bGU6IFwiLi9qc3gtZGV2LXJ1bnRpbWUvZGlzdC9lbW90aW9uLXJlYWN0LWpzeC1kZXYtcnVudGltZS5icm93c2VyLmVzbS5qc1wiLFxuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuYnJvd3Nlci5janMubWpzXCIsXG5cdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuYnJvd3Nlci5janMuanNcIlxuXHRcdFx0fSxcblx0XHRcdG1vZHVsZTogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmVzbS5qc1wiLFxuXHRcdFx0XCJpbXBvcnRcIjogXCIuL2pzeC1kZXYtcnVudGltZS9kaXN0L2Vtb3Rpb24tcmVhY3QtanN4LWRldi1ydW50aW1lLmNqcy5tanNcIixcblx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vanN4LWRldi1ydW50aW1lL2Rpc3QvZW1vdGlvbi1yZWFjdC1qc3gtZGV2LXJ1bnRpbWUuY2pzLmpzXCJcblx0XHR9LFxuXHRcdFwiLi9wYWNrYWdlLmpzb25cIjogXCIuL3BhY2thZ2UuanNvblwiLFxuXHRcdFwiLi90eXBlcy9jc3MtcHJvcFwiOiBcIi4vdHlwZXMvY3NzLXByb3AuZC50c1wiLFxuXHRcdFwiLi9tYWNyb1wiOiB7XG5cdFx0XHR0eXBlczoge1xuXHRcdFx0XHRcImltcG9ydFwiOiBcIi4vbWFjcm8uZC5tdHNcIixcblx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9tYWNyby5kLnRzXCJcblx0XHRcdH0sXG5cdFx0XHRcImRlZmF1bHRcIjogXCIuL21hY3JvLmpzXCJcblx0XHR9XG5cdH0sXG5cdGltcG9ydHM6IHtcblx0XHRcIiNpcy1kZXZlbG9wbWVudFwiOiB7XG5cdFx0XHRkZXZlbG9wbWVudDogXCIuL3NyYy9jb25kaXRpb25zL3RydWUudHNcIixcblx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vc3JjL2NvbmRpdGlvbnMvZmFsc2UudHNcIlxuXHRcdH0sXG5cdFx0XCIjaXMtYnJvd3NlclwiOiB7XG5cdFx0XHRcImVkZ2UtbGlnaHRcIjogXCIuL3NyYy9jb25kaXRpb25zL2ZhbHNlLnRzXCIsXG5cdFx0XHR3b3JrZXJkOiBcIi4vc3JjL2NvbmRpdGlvbnMvZmFsc2UudHNcIixcblx0XHRcdHdvcmtlcjogXCIuL3NyYy9jb25kaXRpb25zL2ZhbHNlLnRzXCIsXG5cdFx0XHRicm93c2VyOiBcIi4vc3JjL2NvbmRpdGlvbnMvdHJ1ZS50c1wiLFxuXHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9zcmMvY29uZGl0aW9ucy9pcy1icm93c2VyLnRzXCJcblx0XHR9XG5cdH0sXG5cdGZpbGVzOiBbXG5cdFx0XCJzcmNcIixcblx0XHRcImRpc3RcIixcblx0XHRcImpzeC1ydW50aW1lXCIsXG5cdFx0XCJqc3gtZGV2LXJ1bnRpbWVcIixcblx0XHRcIl9pc29sYXRlZC1obnJzXCIsXG5cdFx0XCJ0eXBlcy9jc3MtcHJvcC5kLnRzXCIsXG5cdFx0XCJtYWNyby4qXCJcblx0XSxcblx0c2lkZUVmZmVjdHM6IGZhbHNlLFxuXHRhdXRob3I6IFwiRW1vdGlvbiBDb250cmlidXRvcnNcIixcblx0bGljZW5zZTogXCJNSVRcIixcblx0c2NyaXB0czoge1xuXHRcdFwidGVzdDp0eXBlc2NyaXB0XCI6IFwiZHRzbGludCB0eXBlc1wiXG5cdH0sXG5cdGRlcGVuZGVuY2llczoge1xuXHRcdFwiQGJhYmVsL3J1bnRpbWVcIjogXCJeNy4xOC4zXCIsXG5cdFx0XCJAZW1vdGlvbi9iYWJlbC1wbHVnaW5cIjogXCJeMTEuMTMuNVwiLFxuXHRcdFwiQGVtb3Rpb24vY2FjaGVcIjogXCJeMTEuMTQuMFwiLFxuXHRcdFwiQGVtb3Rpb24vc2VyaWFsaXplXCI6IFwiXjEuMy4zXCIsXG5cdFx0XCJAZW1vdGlvbi91c2UtaW5zZXJ0aW9uLWVmZmVjdC13aXRoLWZhbGxiYWNrc1wiOiBcIl4xLjIuMFwiLFxuXHRcdFwiQGVtb3Rpb24vdXRpbHNcIjogXCJeMS40LjJcIixcblx0XHRcIkBlbW90aW9uL3dlYWstbWVtb2l6ZVwiOiBcIl4wLjQuMFwiLFxuXHRcdFwiaG9pc3Qtbm9uLXJlYWN0LXN0YXRpY3NcIjogXCJeMy4zLjFcIlxuXHR9LFxuXHRwZWVyRGVwZW5kZW5jaWVzOiB7XG5cdFx0cmVhY3Q6IFwiPj0xNi44LjBcIlxuXHR9LFxuXHRwZWVyRGVwZW5kZW5jaWVzTWV0YToge1xuXHRcdFwiQHR5cGVzL3JlYWN0XCI6IHtcblx0XHRcdG9wdGlvbmFsOiB0cnVlXG5cdFx0fVxuXHR9LFxuXHRkZXZEZXBlbmRlbmNpZXM6IHtcblx0XHRcIkBkZWZpbml0ZWx5dHlwZWQvZHRzbGludFwiOiBcIjAuMC4xMTJcIixcblx0XHRcIkBlbW90aW9uL2Nzc1wiOiBcIjExLjEzLjVcIixcblx0XHRcIkBlbW90aW9uL2Nzcy1wcmV0dGlmaWVyXCI6IFwiMS4yLjBcIixcblx0XHRcIkBlbW90aW9uL3NlcnZlclwiOiBcIjExLjExLjBcIixcblx0XHRcIkBlbW90aW9uL3N0eWxlZFwiOiBcIjExLjE0LjBcIixcblx0XHRcIkB0eXBlcy9ob2lzdC1ub24tcmVhY3Qtc3RhdGljc1wiOiBcIl4zLjMuNVwiLFxuXHRcdFwiaHRtbC10YWctbmFtZXNcIjogXCJeMS4xLjJcIixcblx0XHRyZWFjdDogXCIxNi4xNC4wXCIsXG5cdFx0XCJzdmctdGFnLW5hbWVzXCI6IFwiXjEuMS4xXCIsXG5cdFx0dHlwZXNjcmlwdDogXCJeNS40LjVcIlxuXHR9LFxuXHRyZXBvc2l0b3J5OiBcImh0dHBzOi8vZ2l0aHViLmNvbS9lbW90aW9uLWpzL2Vtb3Rpb24vdHJlZS9tYWluL3BhY2thZ2VzL3JlYWN0XCIsXG5cdHB1Ymxpc2hDb25maWc6IHtcblx0XHRhY2Nlc3M6IFwicHVibGljXCJcblx0fSxcblx0XCJ1bWQ6bWFpblwiOiBcImRpc3QvZW1vdGlvbi1yZWFjdC51bWQubWluLmpzXCIsXG5cdHByZWNvbnN0cnVjdDoge1xuXHRcdGVudHJ5cG9pbnRzOiBbXG5cdFx0XHRcIi4vaW5kZXgudHNcIixcblx0XHRcdFwiLi9qc3gtcnVudGltZS50c1wiLFxuXHRcdFx0XCIuL2pzeC1kZXYtcnVudGltZS50c1wiLFxuXHRcdFx0XCIuL19pc29sYXRlZC1obnJzLnRzXCJcblx0XHRdLFxuXHRcdHVtZE5hbWU6IFwiZW1vdGlvblJlYWN0XCIsXG5cdFx0ZXhwb3J0czoge1xuXHRcdFx0ZXh0cmE6IHtcblx0XHRcdFx0XCIuL3R5cGVzL2Nzcy1wcm9wXCI6IFwiLi90eXBlcy9jc3MtcHJvcC5kLnRzXCIsXG5cdFx0XHRcdFwiLi9tYWNyb1wiOiB7XG5cdFx0XHRcdFx0dHlwZXM6IHtcblx0XHRcdFx0XHRcdFwiaW1wb3J0XCI6IFwiLi9tYWNyby5kLm10c1wiLFxuXHRcdFx0XHRcdFx0XCJkZWZhdWx0XCI6IFwiLi9tYWNyby5kLnRzXCJcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFwiZGVmYXVsdFwiOiBcIi4vbWFjcm8uanNcIlxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59O1xuXG52YXIganN4ID0gZnVuY3Rpb24ganN4KHR5cGUsIHByb3BzKSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmVmZXItcmVzdC1wYXJhbXNcbiAgdmFyIGFyZ3MgPSBhcmd1bWVudHM7XG5cbiAgaWYgKHByb3BzID09IG51bGwgfHwgIWhhc093bi5jYWxsKHByb3BzLCAnY3NzJykpIHtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudC5hcHBseSh1bmRlZmluZWQsIGFyZ3MpO1xuICB9XG5cbiAgdmFyIGFyZ3NMZW5ndGggPSBhcmdzLmxlbmd0aDtcbiAgdmFyIGNyZWF0ZUVsZW1lbnRBcmdBcnJheSA9IG5ldyBBcnJheShhcmdzTGVuZ3RoKTtcbiAgY3JlYXRlRWxlbWVudEFyZ0FycmF5WzBdID0gRW1vdGlvbjtcbiAgY3JlYXRlRWxlbWVudEFyZ0FycmF5WzFdID0gY3JlYXRlRW1vdGlvblByb3BzKHR5cGUsIHByb3BzKTtcblxuICBmb3IgKHZhciBpID0gMjsgaSA8IGFyZ3NMZW5ndGg7IGkrKykge1xuICAgIGNyZWF0ZUVsZW1lbnRBcmdBcnJheVtpXSA9IGFyZ3NbaV07XG4gIH1cblxuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudC5hcHBseShudWxsLCBjcmVhdGVFbGVtZW50QXJnQXJyYXkpO1xufTtcblxuKGZ1bmN0aW9uIChfanN4KSB7XG4gIHZhciBKU1g7XG5cbiAgKGZ1bmN0aW9uIChfSlNYKSB7fSkoSlNYIHx8IChKU1ggPSBfanN4LkpTWCB8fCAoX2pzeC5KU1ggPSB7fSkpKTtcbn0pKGpzeCB8fCAoanN4ID0ge30pKTtcblxudmFyIHdhcm5lZEFib3V0Q3NzUHJvcEZvckdsb2JhbCA9IGZhbHNlOyAvLyBtYWludGFpbiBwbGFjZSBvdmVyIHJlcmVuZGVycy5cbi8vIGluaXRpYWwgcmVuZGVyIGZyb20gYnJvd3NlciwgaW5zZXJ0QmVmb3JlIGNvbnRleHQuc2hlZXQudGFnc1swXSBvciBpZiBhIHN0eWxlIGhhc24ndCBiZWVuIGluc2VydGVkIHRoZXJlIHlldCwgYXBwZW5kQ2hpbGRcbi8vIGluaXRpYWwgY2xpZW50LXNpZGUgcmVuZGVyIGZyb20gU1NSLCB1c2UgcGxhY2Ugb2YgaHlkcmF0aW5nIHRhZ1xuXG52YXIgR2xvYmFsID0gLyogI19fUFVSRV9fICovd2l0aEVtb3Rpb25DYWNoZShmdW5jdGlvbiAocHJvcHMsIGNhY2hlKSB7XG4gIGlmICghd2FybmVkQWJvdXRDc3NQcm9wRm9yR2xvYmFsICYmICggLy8gY2hlY2sgZm9yIGNsYXNzTmFtZSBhcyB3ZWxsIHNpbmNlIHRoZSB1c2VyIGlzXG4gIC8vIHByb2JhYmx5IHVzaW5nIHRoZSBjdXN0b20gY3JlYXRlRWxlbWVudCB3aGljaFxuICAvLyBtZWFucyBpdCB3aWxsIGJlIHR1cm5lZCBpbnRvIGEgY2xhc3NOYW1lIHByb3BcbiAgLy8gSSBkb24ndCByZWFsbHkgd2FudCB0byBhZGQgaXQgdG8gdGhlIHR5cGUgc2luY2UgaXQgc2hvdWxkbid0IGJlIHVzZWRcbiAgJ2NsYXNzTmFtZScgaW4gcHJvcHMgJiYgcHJvcHMuY2xhc3NOYW1lIHx8ICdjc3MnIGluIHByb3BzICYmIHByb3BzLmNzcykpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiSXQgbG9va3MgbGlrZSB5b3UncmUgdXNpbmcgdGhlIGNzcyBwcm9wIG9uIEdsb2JhbCwgZGlkIHlvdSBtZWFuIHRvIHVzZSB0aGUgc3R5bGVzIHByb3AgaW5zdGVhZD9cIik7XG4gICAgd2FybmVkQWJvdXRDc3NQcm9wRm9yR2xvYmFsID0gdHJ1ZTtcbiAgfVxuXG4gIHZhciBzdHlsZXMgPSBwcm9wcy5zdHlsZXM7XG4gIHZhciBzZXJpYWxpemVkID0gc2VyaWFsaXplU3R5bGVzKFtzdHlsZXNdLCB1bmRlZmluZWQsIFJlYWN0LnVzZUNvbnRleHQoVGhlbWVDb250ZXh0KSk7XG4gIC8vIGJ1dCBpdCBpcyBiYXNlZCBvbiBhIGNvbnN0YW50IHRoYXQgd2lsbCBuZXZlciBjaGFuZ2UgYXQgcnVudGltZVxuICAvLyBpdCdzIGVmZmVjdGl2ZWx5IGxpa2UgaGF2aW5nIHR3byBpbXBsZW1lbnRhdGlvbnMgYW5kIHN3aXRjaGluZyB0aGVtIG91dFxuICAvLyBzbyBpdCdzIG5vdCBhY3R1YWxseSBicmVha2luZyBhbnl0aGluZ1xuXG5cbiAgdmFyIHNoZWV0UmVmID0gUmVhY3QudXNlUmVmKCk7XG4gIHVzZUluc2VydGlvbkVmZmVjdFdpdGhMYXlvdXRGYWxsYmFjayhmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGtleSA9IGNhY2hlLmtleSArIFwiLWdsb2JhbFwiOyAvLyB1c2UgY2FzZSBvZiBodHRwczovL2dpdGh1Yi5jb20vZW1vdGlvbi1qcy9lbW90aW9uL2lzc3Vlcy8yNjc1XG5cbiAgICB2YXIgc2hlZXQgPSBuZXcgY2FjaGUuc2hlZXQuY29uc3RydWN0b3Ioe1xuICAgICAga2V5OiBrZXksXG4gICAgICBub25jZTogY2FjaGUuc2hlZXQubm9uY2UsXG4gICAgICBjb250YWluZXI6IGNhY2hlLnNoZWV0LmNvbnRhaW5lcixcbiAgICAgIHNwZWVkeTogY2FjaGUuc2hlZXQuaXNTcGVlZHlcbiAgICB9KTtcbiAgICB2YXIgcmVoeWRyYXRpbmcgPSBmYWxzZTtcbiAgICB2YXIgbm9kZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJzdHlsZVtkYXRhLWVtb3Rpb249XFxcIlwiICsga2V5ICsgXCIgXCIgKyBzZXJpYWxpemVkLm5hbWUgKyBcIlxcXCJdXCIpO1xuXG4gICAgaWYgKGNhY2hlLnNoZWV0LnRhZ3MubGVuZ3RoKSB7XG4gICAgICBzaGVldC5iZWZvcmUgPSBjYWNoZS5zaGVldC50YWdzWzBdO1xuICAgIH1cblxuICAgIGlmIChub2RlICE9PSBudWxsKSB7XG4gICAgICByZWh5ZHJhdGluZyA9IHRydWU7IC8vIGNsZWFyIHRoZSBoYXNoIHNvIHRoaXMgbm9kZSB3b24ndCBiZSByZWNvZ25pemFibGUgYXMgcmVoeWRyYXRhYmxlIGJ5IG90aGVyIDxHbG9iYWwvPnNcblxuICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2RhdGEtZW1vdGlvbicsIGtleSk7XG4gICAgICBzaGVldC5oeWRyYXRlKFtub2RlXSk7XG4gICAgfVxuXG4gICAgc2hlZXRSZWYuY3VycmVudCA9IFtzaGVldCwgcmVoeWRyYXRpbmddO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICBzaGVldC5mbHVzaCgpO1xuICAgIH07XG4gIH0sIFtjYWNoZV0pO1xuICB1c2VJbnNlcnRpb25FZmZlY3RXaXRoTGF5b3V0RmFsbGJhY2soZnVuY3Rpb24gKCkge1xuICAgIHZhciBzaGVldFJlZkN1cnJlbnQgPSBzaGVldFJlZi5jdXJyZW50O1xuICAgIHZhciBzaGVldCA9IHNoZWV0UmVmQ3VycmVudFswXSxcbiAgICAgICAgcmVoeWRyYXRpbmcgPSBzaGVldFJlZkN1cnJlbnRbMV07XG5cbiAgICBpZiAocmVoeWRyYXRpbmcpIHtcbiAgICAgIHNoZWV0UmVmQ3VycmVudFsxXSA9IGZhbHNlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChzZXJpYWxpemVkLm5leHQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgLy8gaW5zZXJ0IGtleWZyYW1lc1xuICAgICAgaW5zZXJ0U3R5bGVzKGNhY2hlLCBzZXJpYWxpemVkLm5leHQsIHRydWUpO1xuICAgIH1cblxuICAgIGlmIChzaGVldC50YWdzLmxlbmd0aCkge1xuICAgICAgLy8gaWYgdGhpcyBkb2Vzbid0IGV4aXN0IHRoZW4gaXQgd2lsbCBiZSBudWxsIHNvIHRoZSBzdHlsZSBlbGVtZW50IHdpbGwgYmUgYXBwZW5kZWRcbiAgICAgIHZhciBlbGVtZW50ID0gc2hlZXQudGFnc1tzaGVldC50YWdzLmxlbmd0aCAtIDFdLm5leHRFbGVtZW50U2libGluZztcbiAgICAgIHNoZWV0LmJlZm9yZSA9IGVsZW1lbnQ7XG4gICAgICBzaGVldC5mbHVzaCgpO1xuICAgIH1cblxuICAgIGNhY2hlLmluc2VydChcIlwiLCBzZXJpYWxpemVkLCBzaGVldCwgZmFsc2UpO1xuICB9LCBbY2FjaGUsIHNlcmlhbGl6ZWQubmFtZV0pO1xuICByZXR1cm4gbnVsbDtcbn0pO1xuXG57XG4gIEdsb2JhbC5kaXNwbGF5TmFtZSA9ICdFbW90aW9uR2xvYmFsJztcbn1cblxuZnVuY3Rpb24gY3NzKCkge1xuICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICB9XG5cbiAgcmV0dXJuIHNlcmlhbGl6ZVN0eWxlcyhhcmdzKTtcbn1cblxuZnVuY3Rpb24ga2V5ZnJhbWVzKCkge1xuICB2YXIgaW5zZXJ0YWJsZSA9IGNzcy5hcHBseSh2b2lkIDAsIGFyZ3VtZW50cyk7XG4gIHZhciBuYW1lID0gXCJhbmltYXRpb24tXCIgKyBpbnNlcnRhYmxlLm5hbWU7XG4gIHJldHVybiB7XG4gICAgbmFtZTogbmFtZSxcbiAgICBzdHlsZXM6IFwiQGtleWZyYW1lcyBcIiArIG5hbWUgKyBcIntcIiArIGluc2VydGFibGUuc3R5bGVzICsgXCJ9XCIsXG4gICAgYW5pbTogMSxcbiAgICB0b1N0cmluZzogZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgICByZXR1cm4gXCJfRU1PX1wiICsgdGhpcy5uYW1lICsgXCJfXCIgKyB0aGlzLnN0eWxlcyArIFwiX0VNT19cIjtcbiAgICB9XG4gIH07XG59XG5cbnZhciBjbGFzc25hbWVzID0gZnVuY3Rpb24gY2xhc3NuYW1lcyhhcmdzKSB7XG4gIHZhciBsZW4gPSBhcmdzLmxlbmd0aDtcbiAgdmFyIGkgPSAwO1xuICB2YXIgY2xzID0gJyc7XG5cbiAgZm9yICg7IGkgPCBsZW47IGkrKykge1xuICAgIHZhciBhcmcgPSBhcmdzW2ldO1xuICAgIGlmIChhcmcgPT0gbnVsbCkgY29udGludWU7XG4gICAgdmFyIHRvQWRkID0gdm9pZCAwO1xuXG4gICAgc3dpdGNoICh0eXBlb2YgYXJnKSB7XG4gICAgICBjYXNlICdib29sZWFuJzpcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGNhc2UgJ29iamVjdCc6XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShhcmcpKSB7XG4gICAgICAgICAgICB0b0FkZCA9IGNsYXNzbmFtZXMoYXJnKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGFyZy5zdHlsZXMgIT09IHVuZGVmaW5lZCAmJiBhcmcubmFtZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1lvdSBoYXZlIHBhc3NlZCBzdHlsZXMgY3JlYXRlZCB3aXRoIGBjc3NgIGZyb20gYEBlbW90aW9uL3JlYWN0YCBwYWNrYWdlIHRvIHRoZSBgY3hgLlxcbicgKyAnYGN4YCBpcyBtZWFudCB0byBjb21wb3NlIGNsYXNzIG5hbWVzIChzdHJpbmdzKSBzbyB5b3Ugc2hvdWxkIGNvbnZlcnQgdGhvc2Ugc3R5bGVzIHRvIGEgY2xhc3MgbmFtZSBieSBwYXNzaW5nIHRoZW0gdG8gdGhlIGBjc3NgIHJlY2VpdmVkIGZyb20gPENsYXNzTmFtZXMvPiBjb21wb25lbnQuJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRvQWRkID0gJyc7XG5cbiAgICAgICAgICAgIGZvciAodmFyIGsgaW4gYXJnKSB7XG4gICAgICAgICAgICAgIGlmIChhcmdba10gJiYgaykge1xuICAgICAgICAgICAgICAgIHRvQWRkICYmICh0b0FkZCArPSAnICcpO1xuICAgICAgICAgICAgICAgIHRvQWRkICs9IGs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICB7XG4gICAgICAgICAgdG9BZGQgPSBhcmc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodG9BZGQpIHtcbiAgICAgIGNscyAmJiAoY2xzICs9ICcgJyk7XG4gICAgICBjbHMgKz0gdG9BZGQ7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNscztcbn07XG5cbmZ1bmN0aW9uIG1lcmdlKHJlZ2lzdGVyZWQsIGNzcywgY2xhc3NOYW1lKSB7XG4gIHZhciByZWdpc3RlcmVkU3R5bGVzID0gW107XG4gIHZhciByYXdDbGFzc05hbWUgPSBnZXRSZWdpc3RlcmVkU3R5bGVzKHJlZ2lzdGVyZWQsIHJlZ2lzdGVyZWRTdHlsZXMsIGNsYXNzTmFtZSk7XG5cbiAgaWYgKHJlZ2lzdGVyZWRTdHlsZXMubGVuZ3RoIDwgMikge1xuICAgIHJldHVybiBjbGFzc05hbWU7XG4gIH1cblxuICByZXR1cm4gcmF3Q2xhc3NOYW1lICsgY3NzKHJlZ2lzdGVyZWRTdHlsZXMpO1xufVxuXG52YXIgSW5zZXJ0aW9uID0gZnVuY3Rpb24gSW5zZXJ0aW9uKF9yZWYpIHtcbiAgdmFyIGNhY2hlID0gX3JlZi5jYWNoZSxcbiAgICAgIHNlcmlhbGl6ZWRBcnIgPSBfcmVmLnNlcmlhbGl6ZWRBcnI7XG4gIHVzZUluc2VydGlvbkVmZmVjdEFsd2F5c1dpdGhTeW5jRmFsbGJhY2soZnVuY3Rpb24gKCkge1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZXJpYWxpemVkQXJyLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpbnNlcnRTdHlsZXMoY2FjaGUsIHNlcmlhbGl6ZWRBcnJbaV0sIGZhbHNlKTtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBudWxsO1xufTtcblxudmFyIENsYXNzTmFtZXMgPSAvKiAjX19QVVJFX18gKi93aXRoRW1vdGlvbkNhY2hlKGZ1bmN0aW9uIChwcm9wcywgY2FjaGUpIHtcbiAgdmFyIGhhc1JlbmRlcmVkID0gZmFsc2U7XG4gIHZhciBzZXJpYWxpemVkQXJyID0gW107XG5cbiAgdmFyIGNzcyA9IGZ1bmN0aW9uIGNzcygpIHtcbiAgICBpZiAoaGFzUmVuZGVyZWQgJiYgaXNEZXZlbG9wbWVudCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjc3MgY2FuIG9ubHkgYmUgdXNlZCBkdXJpbmcgcmVuZGVyJyk7XG4gICAgfVxuXG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIHZhciBzZXJpYWxpemVkID0gc2VyaWFsaXplU3R5bGVzKGFyZ3MsIGNhY2hlLnJlZ2lzdGVyZWQpO1xuICAgIHNlcmlhbGl6ZWRBcnIucHVzaChzZXJpYWxpemVkKTsgLy8gcmVnaXN0cmF0aW9uIGhhcyB0byBoYXBwZW4gaGVyZSBhcyB0aGUgcmVzdWx0IG9mIHRoaXMgbWlnaHQgZ2V0IGNvbnN1bWVkIGJ5IGBjeGBcblxuICAgIHJlZ2lzdGVyU3R5bGVzKGNhY2hlLCBzZXJpYWxpemVkLCBmYWxzZSk7XG4gICAgcmV0dXJuIGNhY2hlLmtleSArIFwiLVwiICsgc2VyaWFsaXplZC5uYW1lO1xuICB9O1xuXG4gIHZhciBjeCA9IGZ1bmN0aW9uIGN4KCkge1xuICAgIGlmIChoYXNSZW5kZXJlZCAmJiBpc0RldmVsb3BtZW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2N4IGNhbiBvbmx5IGJlIHVzZWQgZHVyaW5nIHJlbmRlcicpO1xuICAgIH1cblxuICAgIGZvciAodmFyIF9sZW4yID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuMiksIF9rZXkyID0gMDsgX2tleTIgPCBfbGVuMjsgX2tleTIrKykge1xuICAgICAgYXJnc1tfa2V5Ml0gPSBhcmd1bWVudHNbX2tleTJdO1xuICAgIH1cblxuICAgIHJldHVybiBtZXJnZShjYWNoZS5yZWdpc3RlcmVkLCBjc3MsIGNsYXNzbmFtZXMoYXJncykpO1xuICB9O1xuXG4gIHZhciBjb250ZW50ID0ge1xuICAgIGNzczogY3NzLFxuICAgIGN4OiBjeCxcbiAgICB0aGVtZTogUmVhY3QudXNlQ29udGV4dChUaGVtZUNvbnRleHQpXG4gIH07XG4gIHZhciBlbGUgPSBwcm9wcy5jaGlsZHJlbihjb250ZW50KTtcbiAgaGFzUmVuZGVyZWQgPSB0cnVlO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEluc2VydGlvbiwge1xuICAgIGNhY2hlOiBjYWNoZSxcbiAgICBzZXJpYWxpemVkQXJyOiBzZXJpYWxpemVkQXJyXG4gIH0pLCBlbGUpO1xufSk7XG5cbntcbiAgQ2xhc3NOYW1lcy5kaXNwbGF5TmFtZSA9ICdFbW90aW9uQ2xhc3NOYW1lcyc7XG59XG5cbntcbiAgdmFyIGlzQnJvd3NlciA9IHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCc7IC8vICMxNzI3LCAjMjkwNSBmb3Igc29tZSByZWFzb24gSmVzdCBhbmQgVml0ZXN0IGV2YWx1YXRlIG1vZHVsZXMgdHdpY2UgaWYgc29tZSBjb25zdW1pbmcgbW9kdWxlIGdldHMgbW9ja2VkXG5cbiAgdmFyIGlzVGVzdEVudiA9IHR5cGVvZiBqZXN0ICE9PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgdmkgIT09ICd1bmRlZmluZWQnO1xuXG4gIGlmIChpc0Jyb3dzZXIgJiYgIWlzVGVzdEVudikge1xuICAgIC8vIGdsb2JhbFRoaXMgaGFzIHdpZGUgYnJvd3NlciBzdXBwb3J0IC0gaHR0cHM6Ly9jYW5pdXNlLmNvbS8/c2VhcmNoPWdsb2JhbFRoaXMsIE5vZGUuanMgMTIgYW5kIGxhdGVyXG4gICAgdmFyIGdsb2JhbENvbnRleHQgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCcgPyBnbG9iYWxUaGlzIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW5kZWZcbiAgICA6IGlzQnJvd3NlciA/IHdpbmRvdyA6IGdsb2JhbDtcbiAgICB2YXIgZ2xvYmFsS2V5ID0gXCJfX0VNT1RJT05fUkVBQ1RfXCIgKyBwa2cudmVyc2lvbi5zcGxpdCgnLicpWzBdICsgXCJfX1wiO1xuXG4gICAgaWYgKGdsb2JhbENvbnRleHRbZ2xvYmFsS2V5XSkge1xuICAgICAgY29uc29sZS53YXJuKCdZb3UgYXJlIGxvYWRpbmcgQGVtb3Rpb24vcmVhY3Qgd2hlbiBpdCBpcyBhbHJlYWR5IGxvYWRlZC4gUnVubmluZyAnICsgJ211bHRpcGxlIGluc3RhbmNlcyBtYXkgY2F1c2UgcHJvYmxlbXMuIFRoaXMgY2FuIGhhcHBlbiBpZiBtdWx0aXBsZSAnICsgJ3ZlcnNpb25zIGFyZSB1c2VkLCBvciBpZiBtdWx0aXBsZSBidWlsZHMgb2YgdGhlIHNhbWUgdmVyc2lvbiBhcmUgJyArICd1c2VkLicpO1xuICAgIH1cblxuICAgIGdsb2JhbENvbnRleHRbZ2xvYmFsS2V5XSA9IHRydWU7XG4gIH1cbn1cblxuZXhwb3J0IHsgQ2xhc3NOYW1lcywgR2xvYmFsLCBqc3ggYXMgY3JlYXRlRWxlbWVudCwgY3NzLCBqc3gsIGtleWZyYW1lcyB9O1xuIiwiaW1wb3J0IG1lbW9pemUgZnJvbSAnQGVtb3Rpb24vbWVtb2l6ZSc7XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxudmFyIHJlYWN0UHJvcHNSZWdleCA9IC9eKChjaGlsZHJlbnxkYW5nZXJvdXNseVNldElubmVySFRNTHxrZXl8cmVmfGF1dG9Gb2N1c3xkZWZhdWx0VmFsdWV8ZGVmYXVsdENoZWNrZWR8aW5uZXJIVE1MfHN1cHByZXNzQ29udGVudEVkaXRhYmxlV2FybmluZ3xzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmd8dmFsdWVMaW5rfGFiYnJ8YWNjZXB0fGFjY2VwdENoYXJzZXR8YWNjZXNzS2V5fGFjdGlvbnxhbGxvd3xhbGxvd1VzZXJNZWRpYXxhbGxvd1BheW1lbnRSZXF1ZXN0fGFsbG93RnVsbFNjcmVlbnxhbGxvd1RyYW5zcGFyZW5jeXxhbHR8YXN5bmN8YXV0b0NvbXBsZXRlfGF1dG9QbGF5fGNhcHR1cmV8Y2VsbFBhZGRpbmd8Y2VsbFNwYWNpbmd8Y2hhbGxlbmdlfGNoYXJTZXR8Y2hlY2tlZHxjaXRlfGNsYXNzSUR8Y2xhc3NOYW1lfGNvbHN8Y29sU3Bhbnxjb250ZW50fGNvbnRlbnRFZGl0YWJsZXxjb250ZXh0TWVudXxjb250cm9sc3xjb250cm9sc0xpc3R8Y29vcmRzfGNyb3NzT3JpZ2lufGRhdGF8ZGF0ZVRpbWV8ZGVjb2Rpbmd8ZGVmYXVsdHxkZWZlcnxkaXJ8ZGlzYWJsZWR8ZGlzYWJsZVBpY3R1cmVJblBpY3R1cmV8ZGlzYWJsZVJlbW90ZVBsYXliYWNrfGRvd25sb2FkfGRyYWdnYWJsZXxlbmNUeXBlfGVudGVyS2V5SGludHxmZXRjaHByaW9yaXR5fGZldGNoUHJpb3JpdHl8Zm9ybXxmb3JtQWN0aW9ufGZvcm1FbmNUeXBlfGZvcm1NZXRob2R8Zm9ybU5vVmFsaWRhdGV8Zm9ybVRhcmdldHxmcmFtZUJvcmRlcnxoZWFkZXJzfGhlaWdodHxoaWRkZW58aGlnaHxocmVmfGhyZWZMYW5nfGh0bWxGb3J8aHR0cEVxdWl2fGlkfGlucHV0TW9kZXxpbnRlZ3JpdHl8aXN8a2V5UGFyYW1zfGtleVR5cGV8a2luZHxsYWJlbHxsYW5nfGxpc3R8bG9hZGluZ3xsb29wfGxvd3xtYXJnaW5IZWlnaHR8bWFyZ2luV2lkdGh8bWF4fG1heExlbmd0aHxtZWRpYXxtZWRpYUdyb3VwfG1ldGhvZHxtaW58bWluTGVuZ3RofG11bHRpcGxlfG11dGVkfG5hbWV8bm9uY2V8bm9WYWxpZGF0ZXxvcGVufG9wdGltdW18cGF0dGVybnxwbGFjZWhvbGRlcnxwbGF5c0lubGluZXxwb3BvdmVyfHBvcG92ZXJUYXJnZXR8cG9wb3ZlclRhcmdldEFjdGlvbnxwb3N0ZXJ8cHJlbG9hZHxwcm9maWxlfHJhZGlvR3JvdXB8cmVhZE9ubHl8cmVmZXJyZXJQb2xpY3l8cmVsfHJlcXVpcmVkfHJldmVyc2VkfHJvbGV8cm93c3xyb3dTcGFufHNhbmRib3h8c2NvcGV8c2NvcGVkfHNjcm9sbGluZ3xzZWFtbGVzc3xzZWxlY3RlZHxzaGFwZXxzaXplfHNpemVzfHNsb3R8c3BhbnxzcGVsbENoZWNrfHNyY3xzcmNEb2N8c3JjTGFuZ3xzcmNTZXR8c3RhcnR8c3RlcHxzdHlsZXxzdW1tYXJ5fHRhYkluZGV4fHRhcmdldHx0aXRsZXx0cmFuc2xhdGV8dHlwZXx1c2VNYXB8dmFsdWV8d2lkdGh8d21vZGV8d3JhcHxhYm91dHxkYXRhdHlwZXxpbmxpc3R8cHJlZml4fHByb3BlcnR5fHJlc291cmNlfHR5cGVvZnx2b2NhYnxhdXRvQ2FwaXRhbGl6ZXxhdXRvQ29ycmVjdHxhdXRvU2F2ZXxjb2xvcnxpbmNyZW1lbnRhbHxmYWxsYmFja3xpbmVydHxpdGVtUHJvcHxpdGVtU2NvcGV8aXRlbVR5cGV8aXRlbUlEfGl0ZW1SZWZ8b258b3B0aW9ufHJlc3VsdHN8c2VjdXJpdHl8dW5zZWxlY3RhYmxlfGFjY2VudEhlaWdodHxhY2N1bXVsYXRlfGFkZGl0aXZlfGFsaWdubWVudEJhc2VsaW5lfGFsbG93UmVvcmRlcnxhbHBoYWJldGljfGFtcGxpdHVkZXxhcmFiaWNGb3JtfGFzY2VudHxhdHRyaWJ1dGVOYW1lfGF0dHJpYnV0ZVR5cGV8YXV0b1JldmVyc2V8YXppbXV0aHxiYXNlRnJlcXVlbmN5fGJhc2VsaW5lU2hpZnR8YmFzZVByb2ZpbGV8YmJveHxiZWdpbnxiaWFzfGJ5fGNhbGNNb2RlfGNhcEhlaWdodHxjbGlwfGNsaXBQYXRoVW5pdHN8Y2xpcFBhdGh8Y2xpcFJ1bGV8Y29sb3JJbnRlcnBvbGF0aW9ufGNvbG9ySW50ZXJwb2xhdGlvbkZpbHRlcnN8Y29sb3JQcm9maWxlfGNvbG9yUmVuZGVyaW5nfGNvbnRlbnRTY3JpcHRUeXBlfGNvbnRlbnRTdHlsZVR5cGV8Y3Vyc29yfGN4fGN5fGR8ZGVjZWxlcmF0ZXxkZXNjZW50fGRpZmZ1c2VDb25zdGFudHxkaXJlY3Rpb258ZGlzcGxheXxkaXZpc29yfGRvbWluYW50QmFzZWxpbmV8ZHVyfGR4fGR5fGVkZ2VNb2RlfGVsZXZhdGlvbnxlbmFibGVCYWNrZ3JvdW5kfGVuZHxleHBvbmVudHxleHRlcm5hbFJlc291cmNlc1JlcXVpcmVkfGZpbGx8ZmlsbE9wYWNpdHl8ZmlsbFJ1bGV8ZmlsdGVyfGZpbHRlclJlc3xmaWx0ZXJVbml0c3xmbG9vZENvbG9yfGZsb29kT3BhY2l0eXxmb2N1c2FibGV8Zm9udEZhbWlseXxmb250U2l6ZXxmb250U2l6ZUFkanVzdHxmb250U3RyZXRjaHxmb250U3R5bGV8Zm9udFZhcmlhbnR8Zm9udFdlaWdodHxmb3JtYXR8ZnJvbXxmcnxmeHxmeXxnMXxnMnxnbHlwaE5hbWV8Z2x5cGhPcmllbnRhdGlvbkhvcml6b250YWx8Z2x5cGhPcmllbnRhdGlvblZlcnRpY2FsfGdseXBoUmVmfGdyYWRpZW50VHJhbnNmb3JtfGdyYWRpZW50VW5pdHN8aGFuZ2luZ3xob3JpekFkdlh8aG9yaXpPcmlnaW5YfGlkZW9ncmFwaGljfGltYWdlUmVuZGVyaW5nfGlufGluMnxpbnRlcmNlcHR8a3xrMXxrMnxrM3xrNHxrZXJuZWxNYXRyaXh8a2VybmVsVW5pdExlbmd0aHxrZXJuaW5nfGtleVBvaW50c3xrZXlTcGxpbmVzfGtleVRpbWVzfGxlbmd0aEFkanVzdHxsZXR0ZXJTcGFjaW5nfGxpZ2h0aW5nQ29sb3J8bGltaXRpbmdDb25lQW5nbGV8bG9jYWx8bWFya2VyRW5kfG1hcmtlck1pZHxtYXJrZXJTdGFydHxtYXJrZXJIZWlnaHR8bWFya2VyVW5pdHN8bWFya2VyV2lkdGh8bWFza3xtYXNrQ29udGVudFVuaXRzfG1hc2tVbml0c3xtYXRoZW1hdGljYWx8bW9kZXxudW1PY3RhdmVzfG9mZnNldHxvcGFjaXR5fG9wZXJhdG9yfG9yZGVyfG9yaWVudHxvcmllbnRhdGlvbnxvcmlnaW58b3ZlcmZsb3d8b3ZlcmxpbmVQb3NpdGlvbnxvdmVybGluZVRoaWNrbmVzc3xwYW5vc2UxfHBhaW50T3JkZXJ8cGF0aExlbmd0aHxwYXR0ZXJuQ29udGVudFVuaXRzfHBhdHRlcm5UcmFuc2Zvcm18cGF0dGVyblVuaXRzfHBvaW50ZXJFdmVudHN8cG9pbnRzfHBvaW50c0F0WHxwb2ludHNBdFl8cG9pbnRzQXRafHByZXNlcnZlQWxwaGF8cHJlc2VydmVBc3BlY3RSYXRpb3xwcmltaXRpdmVVbml0c3xyfHJhZGl1c3xyZWZYfHJlZll8cmVuZGVyaW5nSW50ZW50fHJlcGVhdENvdW50fHJlcGVhdER1cnxyZXF1aXJlZEV4dGVuc2lvbnN8cmVxdWlyZWRGZWF0dXJlc3xyZXN0YXJ0fHJlc3VsdHxyb3RhdGV8cnh8cnl8c2NhbGV8c2VlZHxzaGFwZVJlbmRlcmluZ3xzbG9wZXxzcGFjaW5nfHNwZWN1bGFyQ29uc3RhbnR8c3BlY3VsYXJFeHBvbmVudHxzcGVlZHxzcHJlYWRNZXRob2R8c3RhcnRPZmZzZXR8c3RkRGV2aWF0aW9ufHN0ZW1ofHN0ZW12fHN0aXRjaFRpbGVzfHN0b3BDb2xvcnxzdG9wT3BhY2l0eXxzdHJpa2V0aHJvdWdoUG9zaXRpb258c3RyaWtldGhyb3VnaFRoaWNrbmVzc3xzdHJpbmd8c3Ryb2tlfHN0cm9rZURhc2hhcnJheXxzdHJva2VEYXNob2Zmc2V0fHN0cm9rZUxpbmVjYXB8c3Ryb2tlTGluZWpvaW58c3Ryb2tlTWl0ZXJsaW1pdHxzdHJva2VPcGFjaXR5fHN0cm9rZVdpZHRofHN1cmZhY2VTY2FsZXxzeXN0ZW1MYW5ndWFnZXx0YWJsZVZhbHVlc3x0YXJnZXRYfHRhcmdldFl8dGV4dEFuY2hvcnx0ZXh0RGVjb3JhdGlvbnx0ZXh0UmVuZGVyaW5nfHRleHRMZW5ndGh8dG98dHJhbnNmb3JtfHUxfHUyfHVuZGVybGluZVBvc2l0aW9ufHVuZGVybGluZVRoaWNrbmVzc3x1bmljb2RlfHVuaWNvZGVCaWRpfHVuaWNvZGVSYW5nZXx1bml0c1BlckVtfHZBbHBoYWJldGljfHZIYW5naW5nfHZJZGVvZ3JhcGhpY3x2TWF0aGVtYXRpY2FsfHZhbHVlc3x2ZWN0b3JFZmZlY3R8dmVyc2lvbnx2ZXJ0QWR2WXx2ZXJ0T3JpZ2luWHx2ZXJ0T3JpZ2luWXx2aWV3Qm94fHZpZXdUYXJnZXR8dmlzaWJpbGl0eXx3aWR0aHN8d29yZFNwYWNpbmd8d3JpdGluZ01vZGV8eHx4SGVpZ2h0fHgxfHgyfHhDaGFubmVsU2VsZWN0b3J8eGxpbmtBY3R1YXRlfHhsaW5rQXJjcm9sZXx4bGlua0hyZWZ8eGxpbmtSb2xlfHhsaW5rU2hvd3x4bGlua1RpdGxlfHhsaW5rVHlwZXx4bWxCYXNlfHhtbG5zfHhtbG5zWGxpbmt8eG1sTGFuZ3x4bWxTcGFjZXx5fHkxfHkyfHlDaGFubmVsU2VsZWN0b3J8enx6b29tQW5kUGFufGZvcnxjbGFzc3xhdXRvZm9jdXMpfCgoW0RkXVtBYV1bVHRdW0FhXXxbQWFdW1JyXVtJaV1bQWFdfHgpLS4qKSkkLzsgLy8gaHR0cHM6Ly9lc2JlbmNoLmNvbS9iZW5jaC81YmZlZTY4YTRjZDdlNjAwOWVmNjFkMjNcblxudmFyIGlzUHJvcFZhbGlkID0gLyogI19fUFVSRV9fICovbWVtb2l6ZShmdW5jdGlvbiAocHJvcCkge1xuICByZXR1cm4gcmVhY3RQcm9wc1JlZ2V4LnRlc3QocHJvcCkgfHwgcHJvcC5jaGFyQ29kZUF0KDApID09PSAxMTFcbiAgLyogbyAqL1xuICAmJiBwcm9wLmNoYXJDb2RlQXQoMSkgPT09IDExMFxuICAvKiBuICovXG4gICYmIHByb3AuY2hhckNvZGVBdCgyKSA8IDkxO1xufVxuLyogWisxICovXG4pO1xuXG5leHBvcnQgeyBpc1Byb3BWYWxpZCBhcyBkZWZhdWx0IH07XG4iLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZXh0ZW5kcyc7XG5pbXBvcnQgeyB3aXRoRW1vdGlvbkNhY2hlLCBUaGVtZUNvbnRleHQgfSBmcm9tICdAZW1vdGlvbi9yZWFjdCc7XG5pbXBvcnQgeyBzZXJpYWxpemVTdHlsZXMgfSBmcm9tICdAZW1vdGlvbi9zZXJpYWxpemUnO1xuaW1wb3J0IHsgdXNlSW5zZXJ0aW9uRWZmZWN0QWx3YXlzV2l0aFN5bmNGYWxsYmFjayB9IGZyb20gJ0BlbW90aW9uL3VzZS1pbnNlcnRpb24tZWZmZWN0LXdpdGgtZmFsbGJhY2tzJztcbmltcG9ydCB7IGdldFJlZ2lzdGVyZWRTdHlsZXMsIHJlZ2lzdGVyU3R5bGVzLCBpbnNlcnRTdHlsZXMgfSBmcm9tICdAZW1vdGlvbi91dGlscyc7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgaXNQcm9wVmFsaWQgZnJvbSAnQGVtb3Rpb24vaXMtcHJvcC12YWxpZCc7XG5cbnZhciBpc0RldmVsb3BtZW50ID0gdHJ1ZTtcblxudmFyIHRlc3RPbWl0UHJvcHNPblN0cmluZ1RhZyA9IGlzUHJvcFZhbGlkO1xuXG52YXIgdGVzdE9taXRQcm9wc09uQ29tcG9uZW50ID0gZnVuY3Rpb24gdGVzdE9taXRQcm9wc09uQ29tcG9uZW50KGtleSkge1xuICByZXR1cm4ga2V5ICE9PSAndGhlbWUnO1xufTtcblxudmFyIGdldERlZmF1bHRTaG91bGRGb3J3YXJkUHJvcCA9IGZ1bmN0aW9uIGdldERlZmF1bHRTaG91bGRGb3J3YXJkUHJvcCh0YWcpIHtcbiAgcmV0dXJuIHR5cGVvZiB0YWcgPT09ICdzdHJpbmcnICYmIC8vIDk2IGlzIG9uZSBsZXNzIHRoYW4gdGhlIGNoYXIgY29kZVxuICAvLyBmb3IgXCJhXCIgc28gdGhpcyBpcyBjaGVja2luZyB0aGF0XG4gIC8vIGl0J3MgYSBsb3dlcmNhc2UgY2hhcmFjdGVyXG4gIHRhZy5jaGFyQ29kZUF0KDApID4gOTYgPyB0ZXN0T21pdFByb3BzT25TdHJpbmdUYWcgOiB0ZXN0T21pdFByb3BzT25Db21wb25lbnQ7XG59O1xudmFyIGNvbXBvc2VTaG91bGRGb3J3YXJkUHJvcHMgPSBmdW5jdGlvbiBjb21wb3NlU2hvdWxkRm9yd2FyZFByb3BzKHRhZywgb3B0aW9ucywgaXNSZWFsKSB7XG4gIHZhciBzaG91bGRGb3J3YXJkUHJvcDtcblxuICBpZiAob3B0aW9ucykge1xuICAgIHZhciBvcHRpb25zU2hvdWxkRm9yd2FyZFByb3AgPSBvcHRpb25zLnNob3VsZEZvcndhcmRQcm9wO1xuICAgIHNob3VsZEZvcndhcmRQcm9wID0gdGFnLl9fZW1vdGlvbl9mb3J3YXJkUHJvcCAmJiBvcHRpb25zU2hvdWxkRm9yd2FyZFByb3AgPyBmdW5jdGlvbiAocHJvcE5hbWUpIHtcbiAgICAgIHJldHVybiB0YWcuX19lbW90aW9uX2ZvcndhcmRQcm9wKHByb3BOYW1lKSAmJiBvcHRpb25zU2hvdWxkRm9yd2FyZFByb3AocHJvcE5hbWUpO1xuICAgIH0gOiBvcHRpb25zU2hvdWxkRm9yd2FyZFByb3A7XG4gIH1cblxuICBpZiAodHlwZW9mIHNob3VsZEZvcndhcmRQcm9wICE9PSAnZnVuY3Rpb24nICYmIGlzUmVhbCkge1xuICAgIHNob3VsZEZvcndhcmRQcm9wID0gdGFnLl9fZW1vdGlvbl9mb3J3YXJkUHJvcDtcbiAgfVxuXG4gIHJldHVybiBzaG91bGRGb3J3YXJkUHJvcDtcbn07XG5cbnZhciBJTExFR0FMX0VTQ0FQRV9TRVFVRU5DRV9FUlJPUiA9IFwiWW91IGhhdmUgaWxsZWdhbCBlc2NhcGUgc2VxdWVuY2UgaW4geW91ciB0ZW1wbGF0ZSBsaXRlcmFsLCBtb3N0IGxpa2VseSBpbnNpZGUgY29udGVudCdzIHByb3BlcnR5IHZhbHVlLlxcbkJlY2F1c2UgeW91IHdyaXRlIHlvdXIgQ1NTIGluc2lkZSBhIEphdmFTY3JpcHQgc3RyaW5nIHlvdSBhY3R1YWxseSBoYXZlIHRvIGRvIGRvdWJsZSBlc2NhcGluZywgc28gZm9yIGV4YW1wbGUgXFxcImNvbnRlbnQ6ICdcXFxcMDBkNyc7XFxcIiBzaG91bGQgYmVjb21lIFxcXCJjb250ZW50OiAnXFxcXFxcXFwwMGQ3JztcXFwiLlxcbllvdSBjYW4gcmVhZCBtb3JlIGFib3V0IHRoaXMgaGVyZTpcXG5odHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9UZW1wbGF0ZV9saXRlcmFscyNFUzIwMThfcmV2aXNpb25fb2ZfaWxsZWdhbF9lc2NhcGVfc2VxdWVuY2VzXCI7XG5cbnZhciBJbnNlcnRpb24gPSBmdW5jdGlvbiBJbnNlcnRpb24oX3JlZikge1xuICB2YXIgY2FjaGUgPSBfcmVmLmNhY2hlLFxuICAgICAgc2VyaWFsaXplZCA9IF9yZWYuc2VyaWFsaXplZCxcbiAgICAgIGlzU3RyaW5nVGFnID0gX3JlZi5pc1N0cmluZ1RhZztcbiAgcmVnaXN0ZXJTdHlsZXMoY2FjaGUsIHNlcmlhbGl6ZWQsIGlzU3RyaW5nVGFnKTtcbiAgdXNlSW5zZXJ0aW9uRWZmZWN0QWx3YXlzV2l0aFN5bmNGYWxsYmFjayhmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIGluc2VydFN0eWxlcyhjYWNoZSwgc2VyaWFsaXplZCwgaXNTdHJpbmdUYWcpO1xuICB9KTtcblxuICByZXR1cm4gbnVsbDtcbn07XG5cbnZhciBjcmVhdGVTdHlsZWQgPSBmdW5jdGlvbiBjcmVhdGVTdHlsZWQodGFnLCBvcHRpb25zKSB7XG4gIHtcbiAgICBpZiAodGFnID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignWW91IGFyZSB0cnlpbmcgdG8gY3JlYXRlIGEgc3R5bGVkIGVsZW1lbnQgd2l0aCBhbiB1bmRlZmluZWQgY29tcG9uZW50LlxcbllvdSBtYXkgaGF2ZSBmb3Jnb3R0ZW4gdG8gaW1wb3J0IGl0LicpO1xuICAgIH1cbiAgfVxuXG4gIHZhciBpc1JlYWwgPSB0YWcuX19lbW90aW9uX3JlYWwgPT09IHRhZztcbiAgdmFyIGJhc2VUYWcgPSBpc1JlYWwgJiYgdGFnLl9fZW1vdGlvbl9iYXNlIHx8IHRhZztcbiAgdmFyIGlkZW50aWZpZXJOYW1lO1xuICB2YXIgdGFyZ2V0Q2xhc3NOYW1lO1xuXG4gIGlmIChvcHRpb25zICE9PSB1bmRlZmluZWQpIHtcbiAgICBpZGVudGlmaWVyTmFtZSA9IG9wdGlvbnMubGFiZWw7XG4gICAgdGFyZ2V0Q2xhc3NOYW1lID0gb3B0aW9ucy50YXJnZXQ7XG4gIH1cblxuICB2YXIgc2hvdWxkRm9yd2FyZFByb3AgPSBjb21wb3NlU2hvdWxkRm9yd2FyZFByb3BzKHRhZywgb3B0aW9ucywgaXNSZWFsKTtcbiAgdmFyIGRlZmF1bHRTaG91bGRGb3J3YXJkUHJvcCA9IHNob3VsZEZvcndhcmRQcm9wIHx8IGdldERlZmF1bHRTaG91bGRGb3J3YXJkUHJvcChiYXNlVGFnKTtcbiAgdmFyIHNob3VsZFVzZUFzID0gIWRlZmF1bHRTaG91bGRGb3J3YXJkUHJvcCgnYXMnKTtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcHJlZmVyLXJlc3QtcGFyYW1zXG4gICAgdmFyIGFyZ3MgPSBhcmd1bWVudHM7XG4gICAgdmFyIHN0eWxlcyA9IGlzUmVhbCAmJiB0YWcuX19lbW90aW9uX3N0eWxlcyAhPT0gdW5kZWZpbmVkID8gdGFnLl9fZW1vdGlvbl9zdHlsZXMuc2xpY2UoMCkgOiBbXTtcblxuICAgIGlmIChpZGVudGlmaWVyTmFtZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBzdHlsZXMucHVzaChcImxhYmVsOlwiICsgaWRlbnRpZmllck5hbWUgKyBcIjtcIik7XG4gICAgfVxuXG4gICAgaWYgKGFyZ3NbMF0gPT0gbnVsbCB8fCBhcmdzWzBdLnJhdyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcHJlZmVyLXNwcmVhZFxuICAgICAgc3R5bGVzLnB1c2guYXBwbHkoc3R5bGVzLCBhcmdzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHRlbXBsYXRlU3RyaW5nc0FyciA9IGFyZ3NbMF07XG5cbiAgICAgIGlmICh0ZW1wbGF0ZVN0cmluZ3NBcnJbMF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKElMTEVHQUxfRVNDQVBFX1NFUVVFTkNFX0VSUk9SKTtcbiAgICAgIH1cblxuICAgICAgc3R5bGVzLnB1c2godGVtcGxhdGVTdHJpbmdzQXJyWzBdKTtcbiAgICAgIHZhciBsZW4gPSBhcmdzLmxlbmd0aDtcbiAgICAgIHZhciBpID0gMTtcblxuICAgICAgZm9yICg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBpZiAodGVtcGxhdGVTdHJpbmdzQXJyW2ldID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKElMTEVHQUxfRVNDQVBFX1NFUVVFTkNFX0VSUk9SKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHN0eWxlcy5wdXNoKGFyZ3NbaV0sIHRlbXBsYXRlU3RyaW5nc0FycltpXSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdmFyIFN0eWxlZCA9IHdpdGhFbW90aW9uQ2FjaGUoZnVuY3Rpb24gKHByb3BzLCBjYWNoZSwgcmVmKSB7XG4gICAgICB2YXIgRmluYWxUYWcgPSBzaG91bGRVc2VBcyAmJiBwcm9wcy5hcyB8fCBiYXNlVGFnO1xuICAgICAgdmFyIGNsYXNzTmFtZSA9ICcnO1xuICAgICAgdmFyIGNsYXNzSW50ZXJwb2xhdGlvbnMgPSBbXTtcbiAgICAgIHZhciBtZXJnZWRQcm9wcyA9IHByb3BzO1xuXG4gICAgICBpZiAocHJvcHMudGhlbWUgPT0gbnVsbCkge1xuICAgICAgICBtZXJnZWRQcm9wcyA9IHt9O1xuXG4gICAgICAgIGZvciAodmFyIGtleSBpbiBwcm9wcykge1xuICAgICAgICAgIG1lcmdlZFByb3BzW2tleV0gPSBwcm9wc1trZXldO1xuICAgICAgICB9XG5cbiAgICAgICAgbWVyZ2VkUHJvcHMudGhlbWUgPSBSZWFjdC51c2VDb250ZXh0KFRoZW1lQ29udGV4dCk7XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2YgcHJvcHMuY2xhc3NOYW1lID09PSAnc3RyaW5nJykge1xuICAgICAgICBjbGFzc05hbWUgPSBnZXRSZWdpc3RlcmVkU3R5bGVzKGNhY2hlLnJlZ2lzdGVyZWQsIGNsYXNzSW50ZXJwb2xhdGlvbnMsIHByb3BzLmNsYXNzTmFtZSk7XG4gICAgICB9IGVsc2UgaWYgKHByb3BzLmNsYXNzTmFtZSAhPSBudWxsKSB7XG4gICAgICAgIGNsYXNzTmFtZSA9IHByb3BzLmNsYXNzTmFtZSArIFwiIFwiO1xuICAgICAgfVxuXG4gICAgICB2YXIgc2VyaWFsaXplZCA9IHNlcmlhbGl6ZVN0eWxlcyhzdHlsZXMuY29uY2F0KGNsYXNzSW50ZXJwb2xhdGlvbnMpLCBjYWNoZS5yZWdpc3RlcmVkLCBtZXJnZWRQcm9wcyk7XG4gICAgICBjbGFzc05hbWUgKz0gY2FjaGUua2V5ICsgXCItXCIgKyBzZXJpYWxpemVkLm5hbWU7XG5cbiAgICAgIGlmICh0YXJnZXRDbGFzc05hbWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjbGFzc05hbWUgKz0gXCIgXCIgKyB0YXJnZXRDbGFzc05hbWU7XG4gICAgICB9XG5cbiAgICAgIHZhciBmaW5hbFNob3VsZEZvcndhcmRQcm9wID0gc2hvdWxkVXNlQXMgJiYgc2hvdWxkRm9yd2FyZFByb3AgPT09IHVuZGVmaW5lZCA/IGdldERlZmF1bHRTaG91bGRGb3J3YXJkUHJvcChGaW5hbFRhZykgOiBkZWZhdWx0U2hvdWxkRm9yd2FyZFByb3A7XG4gICAgICB2YXIgbmV3UHJvcHMgPSB7fTtcblxuICAgICAgZm9yICh2YXIgX2tleSBpbiBwcm9wcykge1xuICAgICAgICBpZiAoc2hvdWxkVXNlQXMgJiYgX2tleSA9PT0gJ2FzJykgY29udGludWU7XG5cbiAgICAgICAgaWYgKGZpbmFsU2hvdWxkRm9yd2FyZFByb3AoX2tleSkpIHtcbiAgICAgICAgICBuZXdQcm9wc1tfa2V5XSA9IHByb3BzW19rZXldO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIG5ld1Byb3BzLmNsYXNzTmFtZSA9IGNsYXNzTmFtZTtcblxuICAgICAgaWYgKHJlZikge1xuICAgICAgICBuZXdQcm9wcy5yZWYgPSByZWY7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoSW5zZXJ0aW9uLCB7XG4gICAgICAgIGNhY2hlOiBjYWNoZSxcbiAgICAgICAgc2VyaWFsaXplZDogc2VyaWFsaXplZCxcbiAgICAgICAgaXNTdHJpbmdUYWc6IHR5cGVvZiBGaW5hbFRhZyA9PT0gJ3N0cmluZydcbiAgICAgIH0pLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGaW5hbFRhZywgbmV3UHJvcHMpKTtcbiAgICB9KTtcbiAgICBTdHlsZWQuZGlzcGxheU5hbWUgPSBpZGVudGlmaWVyTmFtZSAhPT0gdW5kZWZpbmVkID8gaWRlbnRpZmllck5hbWUgOiBcIlN0eWxlZChcIiArICh0eXBlb2YgYmFzZVRhZyA9PT0gJ3N0cmluZycgPyBiYXNlVGFnIDogYmFzZVRhZy5kaXNwbGF5TmFtZSB8fCBiYXNlVGFnLm5hbWUgfHwgJ0NvbXBvbmVudCcpICsgXCIpXCI7XG4gICAgU3R5bGVkLmRlZmF1bHRQcm9wcyA9IHRhZy5kZWZhdWx0UHJvcHM7XG4gICAgU3R5bGVkLl9fZW1vdGlvbl9yZWFsID0gU3R5bGVkO1xuICAgIFN0eWxlZC5fX2Vtb3Rpb25fYmFzZSA9IGJhc2VUYWc7XG4gICAgU3R5bGVkLl9fZW1vdGlvbl9zdHlsZXMgPSBzdHlsZXM7XG4gICAgU3R5bGVkLl9fZW1vdGlvbl9mb3J3YXJkUHJvcCA9IHNob3VsZEZvcndhcmRQcm9wO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTdHlsZWQsICd0b1N0cmluZycsIHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbiB2YWx1ZSgpIHtcbiAgICAgICAgaWYgKHRhcmdldENsYXNzTmFtZSA9PT0gdW5kZWZpbmVkICYmIGlzRGV2ZWxvcG1lbnQpIHtcbiAgICAgICAgICByZXR1cm4gJ05PX0NPTVBPTkVOVF9TRUxFQ1RPUic7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gXCIuXCIgKyB0YXJnZXRDbGFzc05hbWU7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBTdHlsZWQud2l0aENvbXBvbmVudCA9IGZ1bmN0aW9uIChuZXh0VGFnLCBuZXh0T3B0aW9ucykge1xuICAgICAgdmFyIG5ld1N0eWxlZCA9IGNyZWF0ZVN0eWxlZChuZXh0VGFnLCBfZXh0ZW5kcyh7fSwgb3B0aW9ucywgbmV4dE9wdGlvbnMsIHtcbiAgICAgICAgc2hvdWxkRm9yd2FyZFByb3A6IGNvbXBvc2VTaG91bGRGb3J3YXJkUHJvcHMoU3R5bGVkLCBuZXh0T3B0aW9ucywgdHJ1ZSlcbiAgICAgIH0pKTtcbiAgICAgIHJldHVybiBuZXdTdHlsZWQuYXBwbHkodm9pZCAwLCBzdHlsZXMpO1xuICAgIH07XG5cbiAgICByZXR1cm4gU3R5bGVkO1xuICB9O1xufTtcblxuZXhwb3J0IHsgY3JlYXRlU3R5bGVkIGFzIGRlZmF1bHQgfTtcbiIsImltcG9ydCBjcmVhdGVTdHlsZWQgZnJvbSAnLi4vYmFzZS9kaXN0L2Vtb3Rpb24tc3R5bGVkLWJhc2UuYnJvd3Nlci5kZXZlbG9wbWVudC5lc20uanMnO1xuaW1wb3J0ICdAYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0ICdAZW1vdGlvbi9yZWFjdCc7XG5pbXBvcnQgJ0BlbW90aW9uL3NlcmlhbGl6ZSc7XG5pbXBvcnQgJ0BlbW90aW9uL3VzZS1pbnNlcnRpb24tZWZmZWN0LXdpdGgtZmFsbGJhY2tzJztcbmltcG9ydCAnQGVtb3Rpb24vdXRpbHMnO1xuaW1wb3J0ICdyZWFjdCc7XG5pbXBvcnQgJ0BlbW90aW9uL2lzLXByb3AtdmFsaWQnO1xuXG52YXIgdGFncyA9IFsnYScsICdhYmJyJywgJ2FkZHJlc3MnLCAnYXJlYScsICdhcnRpY2xlJywgJ2FzaWRlJywgJ2F1ZGlvJywgJ2InLCAnYmFzZScsICdiZGknLCAnYmRvJywgJ2JpZycsICdibG9ja3F1b3RlJywgJ2JvZHknLCAnYnInLCAnYnV0dG9uJywgJ2NhbnZhcycsICdjYXB0aW9uJywgJ2NpdGUnLCAnY29kZScsICdjb2wnLCAnY29sZ3JvdXAnLCAnZGF0YScsICdkYXRhbGlzdCcsICdkZCcsICdkZWwnLCAnZGV0YWlscycsICdkZm4nLCAnZGlhbG9nJywgJ2RpdicsICdkbCcsICdkdCcsICdlbScsICdlbWJlZCcsICdmaWVsZHNldCcsICdmaWdjYXB0aW9uJywgJ2ZpZ3VyZScsICdmb290ZXInLCAnZm9ybScsICdoMScsICdoMicsICdoMycsICdoNCcsICdoNScsICdoNicsICdoZWFkJywgJ2hlYWRlcicsICdoZ3JvdXAnLCAnaHInLCAnaHRtbCcsICdpJywgJ2lmcmFtZScsICdpbWcnLCAnaW5wdXQnLCAnaW5zJywgJ2tiZCcsICdrZXlnZW4nLCAnbGFiZWwnLCAnbGVnZW5kJywgJ2xpJywgJ2xpbmsnLCAnbWFpbicsICdtYXAnLCAnbWFyaycsICdtYXJxdWVlJywgJ21lbnUnLCAnbWVudWl0ZW0nLCAnbWV0YScsICdtZXRlcicsICduYXYnLCAnbm9zY3JpcHQnLCAnb2JqZWN0JywgJ29sJywgJ29wdGdyb3VwJywgJ29wdGlvbicsICdvdXRwdXQnLCAncCcsICdwYXJhbScsICdwaWN0dXJlJywgJ3ByZScsICdwcm9ncmVzcycsICdxJywgJ3JwJywgJ3J0JywgJ3J1YnknLCAncycsICdzYW1wJywgJ3NjcmlwdCcsICdzZWN0aW9uJywgJ3NlbGVjdCcsICdzbWFsbCcsICdzb3VyY2UnLCAnc3BhbicsICdzdHJvbmcnLCAnc3R5bGUnLCAnc3ViJywgJ3N1bW1hcnknLCAnc3VwJywgJ3RhYmxlJywgJ3Rib2R5JywgJ3RkJywgJ3RleHRhcmVhJywgJ3Rmb290JywgJ3RoJywgJ3RoZWFkJywgJ3RpbWUnLCAndGl0bGUnLCAndHInLCAndHJhY2snLCAndScsICd1bCcsICd2YXInLCAndmlkZW8nLCAnd2JyJywgLy8gU1ZHXG4nY2lyY2xlJywgJ2NsaXBQYXRoJywgJ2RlZnMnLCAnZWxsaXBzZScsICdmb3JlaWduT2JqZWN0JywgJ2cnLCAnaW1hZ2UnLCAnbGluZScsICdsaW5lYXJHcmFkaWVudCcsICdtYXNrJywgJ3BhdGgnLCAncGF0dGVybicsICdwb2x5Z29uJywgJ3BvbHlsaW5lJywgJ3JhZGlhbEdyYWRpZW50JywgJ3JlY3QnLCAnc3RvcCcsICdzdmcnLCAndGV4dCcsICd0c3BhbiddO1xuXG4vLyBiaW5kIGl0IHRvIGF2b2lkIG11dGF0aW5nIHRoZSBvcmlnaW5hbCBmdW5jdGlvblxudmFyIHN0eWxlZCA9IGNyZWF0ZVN0eWxlZC5iaW5kKG51bGwpO1xudGFncy5mb3JFYWNoKGZ1bmN0aW9uICh0YWdOYW1lKSB7XG4gIHN0eWxlZFt0YWdOYW1lXSA9IHN0eWxlZCh0YWdOYW1lKTtcbn0pO1xuXG5leHBvcnQgeyBzdHlsZWQgYXMgZGVmYXVsdCB9O1xuIiwiLyoqXG4gKiBAbXVpL3N0eWxlZC1lbmdpbmUgdjkuMy4wXG4gKlxuICogQGxpY2Vuc2UgTUlUXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuJ3VzZSBjbGllbnQnO1xuXG4vKiBlc2xpbnQtZGlzYWJsZSBuby11bmRlcnNjb3JlLWRhbmdsZSAqL1xuaW1wb3J0IGVtU3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCc7XG5pbXBvcnQgeyBzZXJpYWxpemVTdHlsZXMgYXMgZW1TZXJpYWxpemVTdHlsZXMgfSBmcm9tICdAZW1vdGlvbi9zZXJpYWxpemUnO1xuXG4vLyBSZS1leHBvcnQgdGhlIHB1YmxpYyB0eXBlIHN1cmZhY2Ugb2YgYEBlbW90aW9uL3N0eWxlZGAuIEV4cGxpY2l0IG5hbWVzIHJhdGhlclxuLy8gdGhhbiBgZXhwb3J0IHR5cGUgKmA6IGFuIGBleHBvcnQgKmAgKGV2ZW4gdHlwZS1vbmx5KSBpcyBkaXNhbGxvd2VkIGJ5IHRoZVxuLy8gYCd1c2UgY2xpZW50J2AgTmV4dC5qcyBsaW50IHJ1bGUuIE5hbWVzIGxvY2FsbHkgcmVkZWNsYXJlZCBiZWxvdyBpbnRlbnRpb25hbGx5XG4vLyBzaGFkb3cgRW1vdGlvbidzIGFuZCBhcmUgbm90IHJlLWV4cG9ydGVkIGhlcmUuXG5cbmZ1bmN0aW9uIHN0eWxlZCh0YWcsIG9wdGlvbnMpIHtcbiAgLy8gRW1vdGlvbidzIGBzdHlsZWRgIG92ZXJsb2FkcyBlYWNoIGV4cGVjdCBhIHNwZWNpZmljIHRhZy9jb21wb25lbnQgc2hhcGU7XG4gIC8vIG5vbmUgYWNjZXB0IHRoZSBicm9hZGVuZWQgYFJlYWN0LkVsZW1lbnRUeXBlYCB1bmlvbiwgc28gY2FzdCB0aGUgcGFzc3Rocm91Z2guXG4gIGNvbnN0IHN0eWxlc0ZhY3RvcnkgPSBlbVN0eWxlZCh0YWcsIG9wdGlvbnMpO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIHJldHVybiAoLi4uc3R5bGVzKSA9PiB7XG4gICAgICBjb25zdCBjb21wb25lbnQgPSB0eXBlb2YgdGFnID09PSAnc3RyaW5nJyA/IGBcIiR7dGFnfVwiYCA6ICdjb21wb25lbnQnO1xuICAgICAgaWYgKHN0eWxlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihbYE1VSTogU2VlbXMgbGlrZSB5b3UgY2FsbGVkIFxcYHN0eWxlZCgke2NvbXBvbmVudH0pKClcXGAgd2l0aG91dCBhIFxcYHN0eWxlXFxgIGFyZ3VtZW50LmAsICdZb3UgbXVzdCBwcm92aWRlIGEgYHN0eWxlc2AgYXJndW1lbnQ6IGBzdHlsZWQoXCJkaXZcIikoc3R5bGVZb3VGb3Jnb3RUb1Bhc3MpYC4nXS5qb2luKCdcXG4nKSk7XG4gICAgICB9IGVsc2UgaWYgKHN0eWxlcy5zb21lKHN0eWxlID0+IHN0eWxlID09PSB1bmRlZmluZWQpKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYE1VSTogdGhlIHN0eWxlZCgke2NvbXBvbmVudH0pKC4uLmFyZ3MpIEFQSSByZXF1aXJlcyBhbGwgaXRzIGFyZ3MgdG8gYmUgZGVmaW5lZC5gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHlsZXNGYWN0b3J5KC4uLnN0eWxlcyk7XG4gICAgfTtcbiAgfVxuICByZXR1cm4gc3R5bGVzRmFjdG9yeTtcbn1cbmV4cG9ydCBkZWZhdWx0IHN0eWxlZDtcblxuLyoqXG4gKiBGb3IgaW50ZXJuYWwgdXNhZ2UgaW4gYEBtdWkvc3lzdGVtYCBwYWNrYWdlXG4gKi9cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbmFtaW5nLWNvbnZlbnRpb25cbmV4cG9ydCBmdW5jdGlvbiBpbnRlcm5hbF9tdXRhdGVTdHlsZXModGFnLCBwcm9jZXNzb3IpIHtcbiAgLy8gRW1vdGlvbiBhdHRhY2hlcyBhbGwgdGhlIHN0eWxlcyBhcyBgX19lbW90aW9uX3N0eWxlc2AuXG4gIC8vIFJlZjogaHR0cHM6Ly9naXRodWIuY29tL2Vtb3Rpb24tanMvZW1vdGlvbi9ibG9iLzE2ZDk3MWQwZGEyMjk1OTZkNmJjYzM5ZDI4MmJhOTc1M2M5ZWU3Y2YvcGFja2FnZXMvc3R5bGVkL3NyYy9iYXNlLmpzI0wxODZcbiAgaWYgKEFycmF5LmlzQXJyYXkodGFnLl9fZW1vdGlvbl9zdHlsZXMpKSB7XG4gICAgdGFnLl9fZW1vdGlvbl9zdHlsZXMgPSBwcm9jZXNzb3IodGFnLl9fZW1vdGlvbl9zdHlsZXMpO1xuICB9XG59XG5cbi8vIEVtb3Rpb24gb25seSBhY2NlcHRzIGFuIGFycmF5LCBidXQgd2Ugd2FudCB0byBhdm9pZCBhbGxvY2F0aW9uc1xuY29uc3Qgd3JhcHBlciA9IFtdO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uYW1pbmctY29udmVudGlvblxuZXhwb3J0IGZ1bmN0aW9uIGludGVybmFsX3NlcmlhbGl6ZVN0eWxlcyhzdHlsZXMpIHtcbiAgd3JhcHBlclswXSA9IHN0eWxlcztcbiAgcmV0dXJuIGVtU2VyaWFsaXplU3R5bGVzKHdyYXBwZXIpO1xufVxuZXhwb3J0IHsgVGhlbWVDb250ZXh0LCBrZXlmcmFtZXMsIGNzcyB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcbmV4cG9ydCB7IGRlZmF1bHQgYXMgU3R5bGVkRW5naW5lUHJvdmlkZXIgfSBmcm9tIFwiLi9TdHlsZWRFbmdpbmVQcm92aWRlci9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgR2xvYmFsU3R5bGVzIH0gZnJvbSBcIi4vR2xvYmFsU3R5bGVzL2luZGV4Lm1qc1wiO1xuXG4vLyBUT0RPIHY2IC0gY2hlY2sgaWYgd2UgY2FuIGRyb3AgdGhlIHVua25vd24sIGFzIGl0IGJyZWFrcyB0aGUgYXV0b2NvbXBsZXRlXG4vLyBGb3IgbW9yZSBpbmZvIG9uIHdoeSBpdCB3YXMgYWRkZWQsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXVpL21hdGVyaWFsLXVpL3B1bGwvMjYyMjhcblxuLy8gVE9ETyB2NiAtIGNoZWNrIGlmIHdlIGNhbiBkcm9wIHRoZSB1bmtub3duLCBhcyBpdCBicmVha3MgdGhlIGF1dG9jb21wbGV0ZVxuLy8gRm9yIG1vcmUgaW5mbyBvbiB3aHkgaXQgd2FzIGFkZGVkLCBzZWUgaHR0cHM6Ly9naXRodWIuY29tL211aS9tYXRlcmlhbC11aS9wdWxsLzI2MjI4XG5cbi8vIE9taXQgdmFyaWFudHMgYXMgYSBrZXksIGJlY2F1c2Ugd2UgaGF2ZSBhIHNwZWNpYWwgaGFuZGxpbmcgZm9yIGl0XG5cbi8qKiBTYW1lIGFzIFN0eWxlZE9wdGlvbnMgYnV0IHNob3VsZEZvcndhcmRQcm9wIG11c3QgYmUgYSB0eXBlIGd1YXJkICovXG5cbi8qKlxuICogQHR5cGVwYXJhbSBDb21wb25lbnRQcm9wcyAgUHJvcHMgd2hpY2ggd2lsbCBiZSBpbmNsdWRlZCB3aGVuIHdpdGhDb21wb25lbnQgaXMgY2FsbGVkXG4gKiBAdHlwZXBhcmFtIFNwZWNpZmljQ29tcG9uZW50UHJvcHMgIFByb3BzIHdoaWNoIHdpbGwgKm5vdCogYmUgaW5jbHVkZWQgd2hlbiB3aXRoQ29tcG9uZW50IGlzIGNhbGxlZFxuICovIiwiY29uc3Qgc2hhcGUgPSB7XG4gIGJvcmRlclJhZGl1czogNFxufTtcbmV4cG9ydCBkZWZhdWx0IHNoYXBlOyIsImltcG9ydCB7IGNyZWF0ZVVuYXJ5U3BhY2luZyB9IGZyb20gXCIuLi9zcGFjaW5nL2luZGV4Lm1qc1wiO1xuXG4vLyBUaGUgZGlmZmVyZW50IHNpZ25hdHVyZXMgaW1wbHkgZGlmZmVyZW50IG1lYW5pbmcgZm9yIHRoZWlyIGFyZ3VtZW50cyB0aGF0IGNhbid0IGJlIGV4cHJlc3NlZCBzdHJ1Y3R1cmFsbHkuXG4vLyBXZSBleHByZXNzIHRoZSBkaWZmZXJlbmNlIHdpdGggdmFyaWFibGUgbmFtZXMuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZVNwYWNpbmcoc3BhY2luZ0lucHV0ID0gOCxcbi8vIE1hdGVyaWFsIERlc2lnbiBsYXlvdXRzIGFyZSB2aXN1YWxseSBiYWxhbmNlZC4gTW9zdCBtZWFzdXJlbWVudHMgYWxpZ24gdG8gYW4gOGRwIGdyaWQsIHdoaWNoIGFsaWducyBib3RoIHNwYWNpbmcgYW5kIHRoZSBvdmVyYWxsIGxheW91dC5cbi8vIFNtYWxsZXIgY29tcG9uZW50cywgc3VjaCBhcyBpY29ucywgY2FuIGFsaWduIHRvIGEgNGRwIGdyaWQuXG4vLyBodHRwczovL20yLm1hdGVyaWFsLmlvL2Rlc2lnbi9sYXlvdXQvdW5kZXJzdGFuZGluZy1sYXlvdXQuaHRtbFxudHJhbnNmb3JtID0gY3JlYXRlVW5hcnlTcGFjaW5nKHtcbiAgc3BhY2luZzogc3BhY2luZ0lucHV0XG59KSkge1xuICAvLyBBbHJlYWR5IHRyYW5zZm9ybWVkLlxuICBpZiAoc3BhY2luZ0lucHV0Lm11aSkge1xuICAgIHJldHVybiBzcGFjaW5nSW5wdXQ7XG4gIH1cbiAgY29uc3Qgc3BhY2luZyA9ICguLi5hcmdzSW5wdXQpID0+IHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgaWYgKCEoYXJnc0lucHV0Lmxlbmd0aCA8PSA0KSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBNVUk6IFRvbyBtYW55IGFyZ3VtZW50cyBwcm92aWRlZCwgZXhwZWN0ZWQgYmV0d2VlbiAwIGFuZCA0LCBnb3QgJHthcmdzSW5wdXQubGVuZ3RofWApO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBhcmdzID0gYXJnc0lucHV0Lmxlbmd0aCA9PT0gMCA/IFsxXSA6IGFyZ3NJbnB1dDtcbiAgICByZXR1cm4gYXJncy5tYXAoYXJndW1lbnQgPT4ge1xuICAgICAgY29uc3Qgb3V0cHV0ID0gdHJhbnNmb3JtKGFyZ3VtZW50KTtcbiAgICAgIHJldHVybiB0eXBlb2Ygb3V0cHV0ID09PSAnbnVtYmVyJyA/IGAke291dHB1dH1weGAgOiBvdXRwdXQ7XG4gICAgfSkuam9pbignICcpO1xuICB9O1xuICBzcGFjaW5nLm11aSA9IHRydWU7XG4gIHJldHVybiBzcGFjaW5nO1xufSIsIi8qKlxuICogQSB1bml2ZXJzYWwgdXRpbGl0eSB0byBzdHlsZSBjb21wb25lbnRzIHdpdGggbXVsdGlwbGUgY29sb3IgbW9kZXMuIEFsd2F5cyB1c2UgaXQgZnJvbSB0aGUgdGhlbWUgb2JqZWN0LlxuICogSXQgd29ya3Mgd2l0aDpcbiAqICAtIFtCYXNpYyB0aGVtZV0oaHR0cHM6Ly9tdWkuY29tL21hdGVyaWFsLXVpL2N1c3RvbWl6YXRpb24vZGFyay1tb2RlLylcbiAqICAtIFtDU1MgdGhlbWUgdmFyaWFibGVzXShodHRwczovL211aS5jb20vbWF0ZXJpYWwtdWkvY3VzdG9taXphdGlvbi9jc3MtdGhlbWUtdmFyaWFibGVzL292ZXJ2aWV3LylcbiAqICAtIFplcm8tcnVudGltZSBlbmdpbmVcbiAqXG4gKiBUaXBzOiBVc2UgYW4gYXJyYXkgb3ZlciBvYmplY3Qgc3ByZWFkIGFuZCBwbGFjZSBgdGhlbWUuYXBwbHlTdHlsZXMoKWAgbGFzdC5cbiAqXG4gKiBXaXRoIHRoZSBzdHlsZWQgZnVuY3Rpb246XG4gKiDinIUgW3sgYmFja2dyb3VuZDogJyNlNWU1ZTUnIH0sIHRoZW1lLmFwcGx5U3R5bGVzKCdkYXJrJywgeyBiYWNrZ3JvdW5kOiAnIzFjMWMxYycgfSldXG4gKiDwn5qrIHsgYmFja2dyb3VuZDogJyNlNWU1ZTUnLCAuLi50aGVtZS5hcHBseVN0eWxlcygnZGFyaycsIHsgYmFja2dyb3VuZDogJyMxYzFjMWMnIH0pfVxuICpcbiAqIFdpdGggdGhlIHN4IHByb3A6XG4gKiDinIUgW3sgYmFja2dyb3VuZDogJyNlNWU1ZTUnIH0sIHRoZW1lID0+IHRoZW1lLmFwcGx5U3R5bGVzKCdkYXJrJywgeyBiYWNrZ3JvdW5kOiAnIzFjMWMxYycgfSldXG4gKiDwn5qrIHsgYmFja2dyb3VuZDogJyNlNWU1ZTUnLCAuLi50aGVtZSA9PiB0aGVtZS5hcHBseVN0eWxlcygnZGFyaycsIHsgYmFja2dyb3VuZDogJyMxYzFjMWMnIH0pfVxuICpcbiAqIEBleGFtcGxlXG4gKiAxLiB1c2luZyB3aXRoIGBzdHlsZWRgOlxuICogYGBganN4XG4gKiAgIGNvbnN0IENvbXBvbmVudCA9IHN0eWxlZCgnZGl2JykoKHsgdGhlbWUgfSkgPT4gW1xuICogICAgIHsgYmFja2dyb3VuZDogJyNlNWU1ZTUnIH0sXG4gKiAgICAgdGhlbWUuYXBwbHlTdHlsZXMoJ2RhcmsnLCB7XG4gKiAgICAgICBiYWNrZ3JvdW5kOiAnIzFjMWMxYycsXG4gKiAgICAgICBjb2xvcjogJyNmZmYnLFxuICogICAgIH0pLFxuICogICBdKTtcbiAqIGBgYFxuICpcbiAqIEBleGFtcGxlXG4gKiAyLiB1c2luZyB3aXRoIGBzeGAgcHJvcDpcbiAqIGBgYGpzeFxuICogICA8Qm94IHN4PXtbXG4gKiAgICAgeyBiYWNrZ3JvdW5kOiAnI2U1ZTVlNScgfSxcbiAqICAgICB0aGVtZSA9PiB0aGVtZS5hcHBseVN0eWxlcygnZGFyaycsIHtcbiAqICAgICAgICBiYWNrZ3JvdW5kOiAnIzFjMWMxYycsXG4gKiAgICAgICAgY29sb3I6ICcjZmZmJyxcbiAqICAgICAgfSksXG4gKiAgICAgXX1cbiAqICAgLz5cbiAqIGBgYFxuICpcbiAqIEBleGFtcGxlXG4gKiAzLiB0aGVtaW5nIGEgY29tcG9uZW50OlxuICogYGBganN4XG4gKiAgIGV4dGVuZFRoZW1lKHtcbiAqICAgICBjb21wb25lbnRzOiB7XG4gKiAgICAgICBNdWlCdXR0b246IHtcbiAqICAgICAgICAgc3R5bGVPdmVycmlkZXM6IHtcbiAqICAgICAgICAgICByb290OiAoeyB0aGVtZSB9KSA9PiBbXG4gKiAgICAgICAgICAgICB7IGJhY2tncm91bmQ6ICcjZTVlNWU1JyB9LFxuICogICAgICAgICAgICAgdGhlbWUuYXBwbHlTdHlsZXMoJ2RhcmsnLCB7XG4gKiAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICcjMWMxYzFjJyxcbiAqICAgICAgICAgICAgICAgY29sb3I6ICcjZmZmJyxcbiAqICAgICAgICAgICAgIH0pLFxuICogICAgICAgICAgIF0sXG4gKiAgICAgICAgIH0sXG4gKiAgICAgICB9XG4gKiAgICAgfVxuICogICB9KVxuICpgYGBcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYXBwbHlTdHlsZXMoa2V5LCBzdHlsZXMpIHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB0aGlzIGlzICdhbnknIHR5cGVcbiAgY29uc3QgdGhlbWUgPSB0aGlzO1xuICBpZiAodGhlbWUudmFycykge1xuICAgIGlmICghdGhlbWUuY29sb3JTY2hlbWVzPy5ba2V5XSB8fCB0eXBlb2YgdGhlbWUuZ2V0Q29sb3JTY2hlbWVTZWxlY3RvciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICAvLyBJZiBDc3NWYXJzUHJvdmlkZXIgaXMgdXNlZCBhcyBhIHByb3ZpZGVyLCByZXR1cm5zICcqOndoZXJlKHtzZWxlY3Rvcn0pICYnXG4gICAgbGV0IHNlbGVjdG9yID0gdGhlbWUuZ2V0Q29sb3JTY2hlbWVTZWxlY3RvcihrZXkpO1xuICAgIGlmIChzZWxlY3RvciA9PT0gJyYnKSB7XG4gICAgICByZXR1cm4gc3R5bGVzO1xuICAgIH1cbiAgICBpZiAoc2VsZWN0b3IuaW5jbHVkZXMoJ2RhdGEtJykgfHwgc2VsZWN0b3IuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgLy8gJyonIGlzIHJlcXVpcmVkIGFzIGEgd29ya2Fyb3VuZCBmb3IgRW1vdGlvbiBpc3N1ZSAoaHR0cHM6Ly9naXRodWIuY29tL2Vtb3Rpb24tanMvZW1vdGlvbi9pc3N1ZXMvMjgzNilcbiAgICAgIHNlbGVjdG9yID0gYCo6d2hlcmUoJHtzZWxlY3Rvci5yZXBsYWNlKC9cXHMqJiQvLCAnJyl9KSAmYDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIFtzZWxlY3Rvcl06IHN0eWxlc1xuICAgIH07XG4gIH1cbiAgaWYgKHRoZW1lLnBhbGV0dGUubW9kZSA9PT0ga2V5KSB7XG4gICAgcmV0dXJuIHN0eWxlcztcbiAgfVxuICByZXR1cm4ge307XG59IiwiaW1wb3J0IGRlZXBtZXJnZSBmcm9tICdAbXVpL3V0aWxzL2RlZXBtZXJnZSc7XG5pbXBvcnQgY3JlYXRlQnJlYWtwb2ludHMgZnJvbSBcIi4uL2NyZWF0ZUJyZWFrcG9pbnRzL2NyZWF0ZUJyZWFrcG9pbnRzLm1qc1wiO1xuaW1wb3J0IGNzc0NvbnRhaW5lclF1ZXJpZXMgZnJvbSBcIi4uL2Nzc0NvbnRhaW5lclF1ZXJpZXMvaW5kZXgubWpzXCI7XG5pbXBvcnQgc2hhcGUgZnJvbSBcIi4vc2hhcGUubWpzXCI7XG5pbXBvcnQgY3JlYXRlU3BhY2luZyBmcm9tIFwiLi9jcmVhdGVTcGFjaW5nLm1qc1wiO1xuaW1wb3J0IHN0eWxlRnVuY3Rpb25TeCBmcm9tIFwiLi4vc3R5bGVGdW5jdGlvblN4L3N0eWxlRnVuY3Rpb25TeC5tanNcIjtcbmltcG9ydCBkZWZhdWx0U3hDb25maWcgZnJvbSBcIi4uL3N0eWxlRnVuY3Rpb25TeC9kZWZhdWx0U3hDb25maWcubWpzXCI7XG5pbXBvcnQgYXBwbHlTdHlsZXMgZnJvbSBcIi4vYXBwbHlTdHlsZXMubWpzXCI7XG5mdW5jdGlvbiBjcmVhdGVUaGVtZShvcHRpb25zID0ge30sIC4uLmFyZ3MpIHtcbiAgY29uc3Qge1xuICAgIGJyZWFrcG9pbnRzOiBicmVha3BvaW50c0lucHV0ID0ge30sXG4gICAgcGFsZXR0ZTogcGFsZXR0ZUlucHV0ID0ge30sXG4gICAgc3BhY2luZzogc3BhY2luZ0lucHV0LFxuICAgIHNoYXBlOiBzaGFwZUlucHV0ID0ge30sXG4gICAgLi4ub3RoZXJcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGJyZWFrcG9pbnRzID0gY3JlYXRlQnJlYWtwb2ludHMoYnJlYWtwb2ludHNJbnB1dCk7XG4gIGNvbnN0IHNwYWNpbmcgPSBjcmVhdGVTcGFjaW5nKHNwYWNpbmdJbnB1dCk7XG4gIGxldCBtdWlUaGVtZSA9IGRlZXBtZXJnZSh7XG4gICAgYnJlYWtwb2ludHMsXG4gICAgZGlyZWN0aW9uOiAnbHRyJyxcbiAgICBjb21wb25lbnRzOiB7fSxcbiAgICAvLyBJbmplY3QgY29tcG9uZW50IGRlZmluaXRpb25zLlxuICAgIHBhbGV0dGU6IHtcbiAgICAgIG1vZGU6ICdsaWdodCcsXG4gICAgICAuLi5wYWxldHRlSW5wdXRcbiAgICB9LFxuICAgIHNwYWNpbmcsXG4gICAgc2hhcGU6IHtcbiAgICAgIC4uLnNoYXBlLFxuICAgICAgLi4uc2hhcGVJbnB1dFxuICAgIH1cbiAgfSwgb3RoZXIpO1xuICBtdWlUaGVtZSA9IGNzc0NvbnRhaW5lclF1ZXJpZXMobXVpVGhlbWUpO1xuICBtdWlUaGVtZS5hcHBseVN0eWxlcyA9IGFwcGx5U3R5bGVzO1xuICBtdWlUaGVtZSA9IGFyZ3MucmVkdWNlKChhY2MsIGFyZ3VtZW50KSA9PiBkZWVwbWVyZ2UoYWNjLCBhcmd1bWVudCksIG11aVRoZW1lKTtcbiAgbXVpVGhlbWUudW5zdGFibGVfc3hDb25maWcgPSB7XG4gICAgLi4uZGVmYXVsdFN4Q29uZmlnLFxuICAgIC4uLm90aGVyPy51bnN0YWJsZV9zeENvbmZpZ1xuICB9O1xuICBtdWlUaGVtZS51bnN0YWJsZV9zeCA9IGZ1bmN0aW9uIHN4KHByb3BzKSB7XG4gICAgcmV0dXJuIHN0eWxlRnVuY3Rpb25TeCh7XG4gICAgICBzeDogcHJvcHMsXG4gICAgICB0aGVtZTogdGhpc1xuICAgIH0pO1xuICB9O1xuICBtdWlUaGVtZS5pbnRlcm5hbF9jYWNoZSA9IHt9O1xuICByZXR1cm4gbXVpVGhlbWU7XG59XG5leHBvcnQgZGVmYXVsdCBjcmVhdGVUaGVtZTsiLCJjb25zdCBkZWZhdWx0R2VuZXJhdG9yID0gY29tcG9uZW50TmFtZSA9PiBjb21wb25lbnROYW1lO1xuY29uc3QgY3JlYXRlQ2xhc3NOYW1lR2VuZXJhdG9yID0gKCkgPT4ge1xuICBsZXQgZ2VuZXJhdGUgPSBkZWZhdWx0R2VuZXJhdG9yO1xuICByZXR1cm4ge1xuICAgIGNvbmZpZ3VyZShnZW5lcmF0b3IpIHtcbiAgICAgIGdlbmVyYXRlID0gZ2VuZXJhdG9yO1xuICAgIH0sXG4gICAgZ2VuZXJhdGUoY29tcG9uZW50TmFtZSkge1xuICAgICAgcmV0dXJuIGdlbmVyYXRlKGNvbXBvbmVudE5hbWUpO1xuICAgIH0sXG4gICAgcmVzZXQoKSB7XG4gICAgICBnZW5lcmF0ZSA9IGRlZmF1bHRHZW5lcmF0b3I7XG4gICAgfVxuICB9O1xufTtcbmNvbnN0IENsYXNzTmFtZUdlbmVyYXRvciA9IGNyZWF0ZUNsYXNzTmFtZUdlbmVyYXRvcigpO1xuZXhwb3J0IGRlZmF1bHQgQ2xhc3NOYW1lR2VuZXJhdG9yOyIsImltcG9ydCBDbGFzc05hbWVHZW5lcmF0b3IgZnJvbSBcIi4uL0NsYXNzTmFtZUdlbmVyYXRvci9pbmRleC5tanNcIjtcbmV4cG9ydCBjb25zdCBnbG9iYWxTdGF0ZUNsYXNzZXMgPSB7XG4gIGFjdGl2ZTogJ2FjdGl2ZScsXG4gIGNoZWNrZWQ6ICdjaGVja2VkJyxcbiAgY29tcGxldGVkOiAnY29tcGxldGVkJyxcbiAgZGlzYWJsZWQ6ICdkaXNhYmxlZCcsXG4gIGVycm9yOiAnZXJyb3InLFxuICBleHBhbmRlZDogJ2V4cGFuZGVkJyxcbiAgZm9jdXNlZDogJ2ZvY3VzZWQnLFxuICBmb2N1c1Zpc2libGU6ICdmb2N1c1Zpc2libGUnLFxuICBvcGVuOiAnb3BlbicsXG4gIHJlYWRPbmx5OiAncmVhZE9ubHknLFxuICByZXF1aXJlZDogJ3JlcXVpcmVkJyxcbiAgc2VsZWN0ZWQ6ICdzZWxlY3RlZCdcbn07XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZW5lcmF0ZVV0aWxpdHlDbGFzcyhjb21wb25lbnROYW1lLCBzbG90LCBnbG9iYWxTdGF0ZVByZWZpeCA9ICdNdWknKSB7XG4gIGNvbnN0IGdsb2JhbFN0YXRlQ2xhc3MgPSBnbG9iYWxTdGF0ZUNsYXNzZXNbc2xvdF07XG4gIHJldHVybiBnbG9iYWxTdGF0ZUNsYXNzID8gYCR7Z2xvYmFsU3RhdGVQcmVmaXh9LSR7Z2xvYmFsU3RhdGVDbGFzc31gIDogYCR7Q2xhc3NOYW1lR2VuZXJhdG9yLmdlbmVyYXRlKGNvbXBvbmVudE5hbWUpfS0ke3Nsb3R9YDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0dsb2JhbFN0YXRlKHNsb3QpIHtcbiAgcmV0dXJuIGdsb2JhbFN0YXRlQ2xhc3Nlc1tzbG90XSAhPT0gdW5kZWZpbmVkO1xufSIsImltcG9ydCBnZW5lcmF0ZVV0aWxpdHlDbGFzcyBmcm9tIFwiLi4vZ2VuZXJhdGVVdGlsaXR5Q2xhc3MvaW5kZXgubWpzXCI7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZW5lcmF0ZVV0aWxpdHlDbGFzc2VzKGNvbXBvbmVudE5hbWUsIHNsb3RzLCBnbG9iYWxTdGF0ZVByZWZpeCA9ICdNdWknKSB7XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBzbG90cy5mb3JFYWNoKHNsb3QgPT4ge1xuICAgIHJlc3VsdFtzbG90XSA9IGdlbmVyYXRlVXRpbGl0eUNsYXNzKGNvbXBvbmVudE5hbWUsIHNsb3QsIGdsb2JhbFN0YXRlUHJlZml4KTtcbiAgfSk7XG4gIHJldHVybiByZXN1bHQ7XG59IiwiaW1wb3J0IHsgRm9yd2FyZFJlZiwgTWVtbyB9IGZyb20gJ3JlYWN0LWlzJztcbmZ1bmN0aW9uIGdldEZ1bmN0aW9uQ29tcG9uZW50TmFtZShDb21wb25lbnQsIGZhbGxiYWNrID0gJycpIHtcbiAgcmV0dXJuIENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb25lbnQubmFtZSB8fCBmYWxsYmFjaztcbn1cbmZ1bmN0aW9uIGdldFdyYXBwZWROYW1lKG91dGVyVHlwZSwgaW5uZXJUeXBlLCB3cmFwcGVyTmFtZSkge1xuICBjb25zdCBmdW5jdGlvbk5hbWUgPSBnZXRGdW5jdGlvbkNvbXBvbmVudE5hbWUoaW5uZXJUeXBlKTtcbiAgcmV0dXJuIG91dGVyVHlwZS5kaXNwbGF5TmFtZSB8fCAoZnVuY3Rpb25OYW1lICE9PSAnJyA/IGAke3dyYXBwZXJOYW1lfSgke2Z1bmN0aW9uTmFtZX0pYCA6IHdyYXBwZXJOYW1lKTtcbn1cblxuLyoqXG4gKiBjaGVycnktcGljayBmcm9tXG4gKiBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvYmxvYi83NjliMWYyNzBlMTI1MWQ5ZGJkY2UwZmNiZDllOTJlNTAyZDA1OWI4L3BhY2thZ2VzL3NoYXJlZC9nZXRDb21wb25lbnROYW1lLmpzXG4gKiBvcmlnaW5hbGx5IGZvcmtlZCBmcm9tIHJlY29tcG9zZS9nZXREaXNwbGF5TmFtZVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZXREaXNwbGF5TmFtZShDb21wb25lbnQpIHtcbiAgaWYgKENvbXBvbmVudCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBpZiAodHlwZW9mIENvbXBvbmVudCA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gQ29tcG9uZW50O1xuICB9XG4gIGlmICh0eXBlb2YgQ29tcG9uZW50ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIGdldEZ1bmN0aW9uQ29tcG9uZW50TmFtZShDb21wb25lbnQsICdDb21wb25lbnQnKTtcbiAgfVxuXG4gIC8vIFR5cGVTY3JpcHQgY2FuJ3QgaGF2ZSBjb21wb25lbnRzIGFzIG9iamVjdHMgYnV0IHRoZXkgZXhpc3QgaW4gdGhlIGZvcm0gb2YgYG1lbW9gIG9yIGBTdXNwZW5zZWBcbiAgaWYgKHR5cGVvZiBDb21wb25lbnQgPT09ICdvYmplY3QnKSB7XG4gICAgc3dpdGNoIChDb21wb25lbnQuJCR0eXBlb2YpIHtcbiAgICAgIGNhc2UgRm9yd2FyZFJlZjpcbiAgICAgICAgcmV0dXJuIGdldFdyYXBwZWROYW1lKENvbXBvbmVudCwgQ29tcG9uZW50LnJlbmRlciwgJ0ZvcndhcmRSZWYnKTtcbiAgICAgIGNhc2UgTWVtbzpcbiAgICAgICAgcmV0dXJuIGdldFdyYXBwZWROYW1lKENvbXBvbmVudCwgQ29tcG9uZW50LnR5cGUsICdtZW1vJyk7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufSIsImltcG9ydCB7IGludGVybmFsX3NlcmlhbGl6ZVN0eWxlcyB9IGZyb20gJ0BtdWkvc3R5bGVkLWVuZ2luZSc7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBwcmVwcm9jZXNzU3R5bGVzKGlucHV0KSB7XG4gIGNvbnN0IHtcbiAgICB2YXJpYW50cyxcbiAgICAuLi5zdHlsZVxuICB9ID0gaW5wdXQ7XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICB2YXJpYW50cyxcbiAgICBzdHlsZTogaW50ZXJuYWxfc2VyaWFsaXplU3R5bGVzKHN0eWxlKSxcbiAgICBpc1Byb2Nlc3NlZDogdHJ1ZVxuICB9O1xuXG4gIC8vIE5vdCBzdXBwb3J0ZWQgb24gc3R5bGVkLWNvbXBvbmVudHNcbiAgaWYgKHJlc3VsdC5zdHlsZSA9PT0gc3R5bGUpIHtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGlmICh2YXJpYW50cykge1xuICAgIHZhcmlhbnRzLmZvckVhY2godmFyaWFudCA9PiB7XG4gICAgICBpZiAodHlwZW9mIHZhcmlhbnQuc3R5bGUgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgdmFyaWFudC5zdHlsZSA9IGludGVybmFsX3NlcmlhbGl6ZVN0eWxlcyh2YXJpYW50LnN0eWxlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufSIsImltcG9ydCBzdHlsZWRFbmdpbmVTdHlsZWQsIHsgaW50ZXJuYWxfbXV0YXRlU3R5bGVzIGFzIG11dGF0ZVN0eWxlcywgaW50ZXJuYWxfc2VyaWFsaXplU3R5bGVzIGFzIHNlcmlhbGl6ZVN0eWxlcyB9IGZyb20gJ0BtdWkvc3R5bGVkLWVuZ2luZSc7XG5pbXBvcnQgaXNPYmplY3RFbXB0eSBmcm9tICdAbXVpL3V0aWxzL2lzT2JqZWN0RW1wdHknO1xuaW1wb3J0IHsgaXNQbGFpbk9iamVjdCB9IGZyb20gJ0BtdWkvdXRpbHMvZGVlcG1lcmdlJztcbmltcG9ydCBjYXBpdGFsaXplIGZyb20gJ0BtdWkvdXRpbHMvY2FwaXRhbGl6ZSc7XG5pbXBvcnQgZ2V0RGlzcGxheU5hbWUgZnJvbSAnQG11aS91dGlscy9nZXREaXNwbGF5TmFtZSc7XG5pbXBvcnQgY3JlYXRlVGhlbWUgZnJvbSBcIi4uL2NyZWF0ZVRoZW1lL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHN0eWxlRnVuY3Rpb25TeCBmcm9tIFwiLi4vc3R5bGVGdW5jdGlvblN4L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHByZXByb2Nlc3NTdHlsZXMgZnJvbSBcIi4uL3ByZXByb2Nlc3NTdHlsZXMubWpzXCI7XG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLXVuZGVyc2NvcmUtZGFuZ2xlICovXG4vKiBlc2xpbnQtZGlzYWJsZSBuby1sYWJlbHMgKi9cbi8qIGVzbGludC1kaXNhYmxlIG5vLWxvbmUtYmxvY2tzICovXG5cbmV4cG9ydCBjb25zdCBzeXN0ZW1EZWZhdWx0VGhlbWUgPSBjcmVhdGVUaGVtZSgpO1xuXG4vLyBVcGRhdGUgL3N5c3RlbS9zdHlsZWQvI2FwaSBpbiBjYXNlIGlmIHRoaXMgY2hhbmdlc1xuZXhwb3J0IGZ1bmN0aW9uIHNob3VsZEZvcndhcmRQcm9wKHByb3ApIHtcbiAgcmV0dXJuIHByb3AgIT09ICdvd25lclN0YXRlJyAmJiBwcm9wICE9PSAndGhlbWUnICYmIHByb3AgIT09ICdzeCcgJiYgcHJvcCAhPT0gJ2FzJztcbn1cbmZ1bmN0aW9uIHNoYWxsb3dMYXllcihzZXJpYWxpemVkLCBsYXllck5hbWUpIHtcbiAgaWYgKGxheWVyTmFtZSAmJiBzZXJpYWxpemVkICYmIHR5cGVvZiBzZXJpYWxpemVkID09PSAnb2JqZWN0JyAmJiBzZXJpYWxpemVkLnN0eWxlcyAmJiAhc2VyaWFsaXplZC5zdHlsZXMuc3RhcnRzV2l0aCgnQGxheWVyJykgLy8gb25seSBhZGQgdGhlIGxheWVyIGlmIGl0IGlzIG5vdCBhbHJlYWR5IHRoZXJlLlxuICApIHtcbiAgICBzZXJpYWxpemVkLnN0eWxlcyA9IGBAbGF5ZXIgJHtsYXllck5hbWV9eyR7U3RyaW5nKHNlcmlhbGl6ZWQuc3R5bGVzKX19YDtcbiAgfVxuICByZXR1cm4gc2VyaWFsaXplZDtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRPdmVycmlkZXNSZXNvbHZlcihzbG90KSB7XG4gIGlmICghc2xvdCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAoX3Byb3BzLCBzdHlsZXMpID0+IHN0eWxlc1tzbG90XTtcbn1cbmZ1bmN0aW9uIGF0dGFjaFRoZW1lKHByb3BzLCB0aGVtZUlkLCBkZWZhdWx0VGhlbWUpIHtcbiAgcHJvcHMudGhlbWUgPSBpc09iamVjdEVtcHR5KHByb3BzLnRoZW1lKSA/IGRlZmF1bHRUaGVtZSA6IHByb3BzLnRoZW1lW3RoZW1lSWRdIHx8IHByb3BzLnRoZW1lO1xufVxuZnVuY3Rpb24gcHJvY2Vzc1N0eWxlKHByb3BzLCBzdHlsZSwgbGF5ZXJOYW1lKSB7XG4gIC8qXG4gICAqIFN0eWxlIHR5cGVzOlxuICAgKiAgLSBudWxsL3VuZGVmaW5lZFxuICAgKiAgLSBzdHJpbmdcbiAgICogIC0gQ1NTIHN0eWxlIG9iamVjdDogeyBbY3NzS2V5XTogW2Nzc1ZhbHVlXSwgdmFyaWFudHMgfVxuICAgKiAgLSBQcm9jZXNzZWQgc3R5bGUgb2JqZWN0OiB7IHN0eWxlLCB2YXJpYW50cywgaXNQcm9jZXNzZWQ6IHRydWUgfVxuICAgKiAgLSBBcnJheSBvZiBhbnkgb2YgdGhlIGFib3ZlXG4gICAqL1xuXG4gIGNvbnN0IHJlc29sdmVkU3R5bGUgPSB0eXBlb2Ygc3R5bGUgPT09ICdmdW5jdGlvbicgPyBzdHlsZShwcm9wcykgOiBzdHlsZTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocmVzb2x2ZWRTdHlsZSkpIHtcbiAgICByZXR1cm4gcmVzb2x2ZWRTdHlsZS5mbGF0TWFwKHN1YlN0eWxlID0+IHByb2Nlc3NTdHlsZShwcm9wcywgc3ViU3R5bGUsIGxheWVyTmFtZSkpO1xuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHJlc29sdmVkU3R5bGU/LnZhcmlhbnRzKSkge1xuICAgIGxldCByb290U3R5bGU7XG4gICAgaWYgKHJlc29sdmVkU3R5bGUuaXNQcm9jZXNzZWQpIHtcbiAgICAgIHJvb3RTdHlsZSA9IGxheWVyTmFtZSA/IHNoYWxsb3dMYXllcihyZXNvbHZlZFN0eWxlLnN0eWxlLCBsYXllck5hbWUpIDogcmVzb2x2ZWRTdHlsZS5zdHlsZTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qge1xuICAgICAgICB2YXJpYW50cyxcbiAgICAgICAgLi4ub3RoZXJTdHlsZXNcbiAgICAgIH0gPSByZXNvbHZlZFN0eWxlO1xuICAgICAgcm9vdFN0eWxlID0gbGF5ZXJOYW1lID8gc2hhbGxvd0xheWVyKHNlcmlhbGl6ZVN0eWxlcyhvdGhlclN0eWxlcyksIGxheWVyTmFtZSkgOiBvdGhlclN0eWxlcztcbiAgICB9XG4gICAgcmV0dXJuIHByb2Nlc3NTdHlsZVZhcmlhbnRzKHByb3BzLCByZXNvbHZlZFN0eWxlLnZhcmlhbnRzLCBbcm9vdFN0eWxlXSwgbGF5ZXJOYW1lKTtcbiAgfVxuICBpZiAocmVzb2x2ZWRTdHlsZT8uaXNQcm9jZXNzZWQpIHtcbiAgICByZXR1cm4gbGF5ZXJOYW1lID8gc2hhbGxvd0xheWVyKHNlcmlhbGl6ZVN0eWxlcyhyZXNvbHZlZFN0eWxlLnN0eWxlKSwgbGF5ZXJOYW1lKSA6IHJlc29sdmVkU3R5bGUuc3R5bGU7XG4gIH1cbiAgcmV0dXJuIGxheWVyTmFtZSA/IHNoYWxsb3dMYXllcihzZXJpYWxpemVTdHlsZXMocmVzb2x2ZWRTdHlsZSksIGxheWVyTmFtZSkgOiByZXNvbHZlZFN0eWxlO1xufVxuZnVuY3Rpb24gcHJvY2Vzc1N0eWxlVmFyaWFudHMocHJvcHMsIHZhcmlhbnRzLCByZXN1bHRzID0gW10sIGxheWVyTmFtZSA9IHVuZGVmaW5lZCkge1xuICBsZXQgbWVyZ2VkU3RhdGU7IC8vIFdlIG1pZ2h0IG5vdCBuZWVkIGl0LCBpbml0aWFsaXplZCBsYXppbHlcblxuICB2YXJpYW50TG9vcDogZm9yIChsZXQgaSA9IDA7IGkgPCB2YXJpYW50cy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIGNvbnN0IHZhcmlhbnQgPSB2YXJpYW50c1tpXTtcbiAgICBpZiAodHlwZW9mIHZhcmlhbnQucHJvcHMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIG1lcmdlZFN0YXRlID8/PSB7XG4gICAgICAgIC4uLnByb3BzLFxuICAgICAgICAuLi5wcm9wcy5vd25lclN0YXRlLFxuICAgICAgICBvd25lclN0YXRlOiBwcm9wcy5vd25lclN0YXRlXG4gICAgICB9O1xuICAgICAgaWYgKCF2YXJpYW50LnByb3BzKG1lcmdlZFN0YXRlKSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCBrZXkgaW4gdmFyaWFudC5wcm9wcykge1xuICAgICAgICBpZiAocHJvcHNba2V5XSAhPT0gdmFyaWFudC5wcm9wc1trZXldICYmIHByb3BzLm93bmVyU3RhdGU/LltrZXldICE9PSB2YXJpYW50LnByb3BzW2tleV0pIHtcbiAgICAgICAgICBjb250aW51ZSB2YXJpYW50TG9vcDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhcmlhbnQuc3R5bGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIG1lcmdlZFN0YXRlID8/PSB7XG4gICAgICAgIC4uLnByb3BzLFxuICAgICAgICAuLi5wcm9wcy5vd25lclN0YXRlLFxuICAgICAgICBvd25lclN0YXRlOiBwcm9wcy5vd25lclN0YXRlXG4gICAgICB9O1xuICAgICAgcmVzdWx0cy5wdXNoKGxheWVyTmFtZSA/IHNoYWxsb3dMYXllcihzZXJpYWxpemVTdHlsZXModmFyaWFudC5zdHlsZShtZXJnZWRTdGF0ZSkpLCBsYXllck5hbWUpIDogdmFyaWFudC5zdHlsZShtZXJnZWRTdGF0ZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHRzLnB1c2gobGF5ZXJOYW1lID8gc2hhbGxvd0xheWVyKHNlcmlhbGl6ZVN0eWxlcyh2YXJpYW50LnN0eWxlKSwgbGF5ZXJOYW1lKSA6IHZhcmlhbnQuc3R5bGUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzdWx0cztcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZVN0eWxlZChpbnB1dCA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICB0aGVtZUlkLFxuICAgIGRlZmF1bHRUaGVtZSA9IHN5c3RlbURlZmF1bHRUaGVtZSxcbiAgICByb290U2hvdWxkRm9yd2FyZFByb3AgPSBzaG91bGRGb3J3YXJkUHJvcCxcbiAgICBzbG90U2hvdWxkRm9yd2FyZFByb3AgPSBzaG91bGRGb3J3YXJkUHJvcFxuICB9ID0gaW5wdXQ7XG4gIGZ1bmN0aW9uIHN0eWxlQXR0YWNoVGhlbWUocHJvcHMpIHtcbiAgICBhdHRhY2hUaGVtZShwcm9wcywgdGhlbWVJZCwgZGVmYXVsdFRoZW1lKTtcbiAgfVxuICBjb25zdCBzdHlsZWQgPSAodGFnLCBpbnB1dE9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIC8vIElmIGB0YWdgIGlzIGFscmVhZHkgYSBzdHlsZWQgY29tcG9uZW50LCBmaWx0ZXIgb3V0IHRoZSBgc3hgIHN0eWxlIGZ1bmN0aW9uXG4gICAgLy8gdG8gcHJldmVudCB1bm5lY2Vzc2FyeSBzdHlsZXMgZ2VuZXJhdGVkIGJ5IHRoZSBjb21wb3NpdGUgY29tcG9uZW50cy5cbiAgICBtdXRhdGVTdHlsZXModGFnLCBzdHlsZXMgPT4gc3R5bGVzLmZpbHRlcihzdHlsZSA9PiBzdHlsZSAhPT0gc3R5bGVGdW5jdGlvblN4KSk7XG4gICAgY29uc3Qge1xuICAgICAgbmFtZTogY29tcG9uZW50TmFtZSxcbiAgICAgIHNsb3Q6IGNvbXBvbmVudFNsb3QsXG4gICAgICBza2lwVmFyaWFudHNSZXNvbHZlcjogaW5wdXRTa2lwVmFyaWFudHNSZXNvbHZlcixcbiAgICAgIHNraXBTeDogaW5wdXRTa2lwU3gsXG4gICAgICAvLyBUT0RPIHY2OiByZW1vdmUgYGxvd2VyY2FzZUZpcnN0TGV0dGVyKClgIGluIHRoZSBuZXh0IG1ham9yIHJlbGVhc2VcbiAgICAgIC8vIEZvciBtb3JlIGRldGFpbHM6IGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvbWF0ZXJpYWwtdWkvcHVsbC8zNzkwOFxuICAgICAgb3ZlcnJpZGVzUmVzb2x2ZXIgPSBkZWZhdWx0T3ZlcnJpZGVzUmVzb2x2ZXIobG93ZXJjYXNlRmlyc3RMZXR0ZXIoY29tcG9uZW50U2xvdCkpLFxuICAgICAgLi4ub3B0aW9uc1xuICAgIH0gPSBpbnB1dE9wdGlvbnM7XG4gICAgY29uc3QgbGF5ZXJOYW1lID0gY29tcG9uZW50TmFtZSAmJiBjb21wb25lbnROYW1lLnN0YXJ0c1dpdGgoJ011aScpIHx8ICEhY29tcG9uZW50U2xvdCA/ICdjb21wb25lbnRzJyA6ICdjdXN0b20nO1xuXG4gICAgLy8gaWYgc2tpcFZhcmlhbnRzUmVzb2x2ZXIgb3B0aW9uIGlzIGRlZmluZWQsIHRha2UgdGhlIHZhbHVlLCBvdGhlcndpc2UsIHRydWUgZm9yIHJvb3QgYW5kIGZhbHNlIGZvciBvdGhlciBzbG90cy5cbiAgICBjb25zdCBza2lwVmFyaWFudHNSZXNvbHZlciA9IGlucHV0U2tpcFZhcmlhbnRzUmVzb2x2ZXIgIT09IHVuZGVmaW5lZCA/IGlucHV0U2tpcFZhcmlhbnRzUmVzb2x2ZXIgOlxuICAgIC8vIFRPRE8gdjY6IHJlbW92ZSBgUm9vdGAgaW4gdGhlIG5leHQgbWFqb3IgcmVsZWFzZVxuICAgIC8vIEZvciBtb3JlIGRldGFpbHM6IGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvbWF0ZXJpYWwtdWkvcHVsbC8zNzkwOFxuICAgIGNvbXBvbmVudFNsb3QgJiYgY29tcG9uZW50U2xvdCAhPT0gJ1Jvb3QnICYmIGNvbXBvbmVudFNsb3QgIT09ICdyb290JyB8fCBmYWxzZTtcbiAgICBjb25zdCBza2lwU3ggPSBpbnB1dFNraXBTeCB8fCBmYWxzZTtcbiAgICBsZXQgc2hvdWxkRm9yd2FyZFByb3BPcHRpb24gPSBzaG91bGRGb3J3YXJkUHJvcDtcblxuICAgIC8vIFRPRE8gdjY6IHJlbW92ZSBgUm9vdGAgaW4gdGhlIG5leHQgbWFqb3IgcmVsZWFzZVxuICAgIC8vIEZvciBtb3JlIGRldGFpbHM6IGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvbWF0ZXJpYWwtdWkvcHVsbC8zNzkwOFxuICAgIGlmIChjb21wb25lbnRTbG90ID09PSAnUm9vdCcgfHwgY29tcG9uZW50U2xvdCA9PT0gJ3Jvb3QnKSB7XG4gICAgICBzaG91bGRGb3J3YXJkUHJvcE9wdGlvbiA9IHJvb3RTaG91bGRGb3J3YXJkUHJvcDtcbiAgICB9IGVsc2UgaWYgKGNvbXBvbmVudFNsb3QpIHtcbiAgICAgIC8vIGFueSBvdGhlciBzbG90IHNwZWNpZmllZFxuICAgICAgc2hvdWxkRm9yd2FyZFByb3BPcHRpb24gPSBzbG90U2hvdWxkRm9yd2FyZFByb3A7XG4gICAgfSBlbHNlIGlmIChpc1N0cmluZ1RhZyh0YWcpKSB7XG4gICAgICAvLyBmb3Igc3RyaW5nIChodG1sKSB0YWcsIHByZXNlcnZlIHRoZSBiZWhhdmlvciBpbiBlbW90aW9uICYgc3R5bGVkLWNvbXBvbmVudHMuXG4gICAgICBzaG91bGRGb3J3YXJkUHJvcE9wdGlvbiA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgZGVmYXVsdFN0eWxlZFJlc29sdmVyID0gc3R5bGVkRW5naW5lU3R5bGVkKHRhZywge1xuICAgICAgc2hvdWxkRm9yd2FyZFByb3A6IHNob3VsZEZvcndhcmRQcm9wT3B0aW9uLFxuICAgICAgbGFiZWw6IGdlbmVyYXRlU3R5bGVkTGFiZWwoY29tcG9uZW50TmFtZSwgY29tcG9uZW50U2xvdCksXG4gICAgICAuLi5vcHRpb25zXG4gICAgfSk7XG4gICAgY29uc3QgdHJhbnNmb3JtU3R5bGUgPSBzdHlsZSA9PiB7XG4gICAgICAvLyAtIE9uIHRoZSBzZXJ2ZXIgRW1vdGlvbiBkb2Vzbid0IHVzZSBSZWFjdC5mb3J3YXJkUmVmIGZvciBjcmVhdGluZyBjb21wb25lbnRzLCBzbyB0aGUgY3JlYXRlZFxuICAgICAgLy8gICBjb21wb25lbnQgc3RheXMgYXMgYSBmdW5jdGlvbi4gVGhpcyBjb25kaXRpb24gbWFrZXMgc3VyZSB0aGF0IHdlIGRvIG5vdCBpbnRlcnBvbGF0ZSBmdW5jdGlvbnNcbiAgICAgIC8vICAgd2hpY2ggYXJlIGJhc2ljYWxseSBjb21wb25lbnRzIHVzZWQgYXMgYSBzZWxlY3RvcnMuXG4gICAgICAvLyAtIGBzdHlsZWAgY291bGQgYmUgYSBzdHlsZWQgY29tcG9uZW50IGZyb20gYSBiYWJlbCBwbHVnaW4gZm9yIGNvbXBvbmVudCBzZWxlY3RvcnMsIFRoaXMgY29uZGl0aW9uXG4gICAgICAvLyAgIG1ha2VzIHN1cmUgdGhhdCB3ZSBkbyBub3QgaW50ZXJwb2xhdGUgdGhlbS5cbiAgICAgIGlmIChzdHlsZS5fX2Vtb3Rpb25fcmVhbCA9PT0gc3R5bGUpIHtcbiAgICAgICAgcmV0dXJuIHN0eWxlO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBzdHlsZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gc3R5bGVGdW5jdGlvblByb2Nlc3Nvcihwcm9wcykge1xuICAgICAgICAgIHJldHVybiBwcm9jZXNzU3R5bGUocHJvcHMsIHN0eWxlLCBwcm9wcy50aGVtZS5tb2R1bGFyQ3NzTGF5ZXJzID8gbGF5ZXJOYW1lIDogdW5kZWZpbmVkKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmIChpc1BsYWluT2JqZWN0KHN0eWxlKSkge1xuICAgICAgICBjb25zdCBzZXJpYWxpemVkID0gcHJlcHJvY2Vzc1N0eWxlcyhzdHlsZSk7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBzdHlsZU9iamVjdFByb2Nlc3Nvcihwcm9wcykge1xuICAgICAgICAgIGlmICghc2VyaWFsaXplZC52YXJpYW50cykge1xuICAgICAgICAgICAgcmV0dXJuIHByb3BzLnRoZW1lLm1vZHVsYXJDc3NMYXllcnMgPyBzaGFsbG93TGF5ZXIoc2VyaWFsaXplZC5zdHlsZSwgbGF5ZXJOYW1lKSA6IHNlcmlhbGl6ZWQuc3R5bGU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBwcm9jZXNzU3R5bGUocHJvcHMsIHNlcmlhbGl6ZWQsIHByb3BzLnRoZW1lLm1vZHVsYXJDc3NMYXllcnMgPyBsYXllck5hbWUgOiB1bmRlZmluZWQpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0eWxlO1xuICAgIH07XG4gICAgY29uc3QgbXVpU3R5bGVkUmVzb2x2ZXIgPSAoLi4uZXhwcmVzc2lvbnNJbnB1dCkgPT4ge1xuICAgICAgY29uc3QgZXhwcmVzc2lvbnNIZWFkID0gW107XG4gICAgICBjb25zdCBleHByZXNzaW9uc0JvZHkgPSBleHByZXNzaW9uc0lucHV0Lm1hcCh0cmFuc2Zvcm1TdHlsZSk7XG4gICAgICBjb25zdCBleHByZXNzaW9uc1RhaWwgPSBbXTtcblxuICAgICAgLy8gUHJlcHJvY2VzcyBgcHJvcHNgIHRvIHNldCB0aGUgc2NvcGVkIHRoZW1lIHZhbHVlLlxuICAgICAgLy8gVGhpcyBtdXN0IHJ1biBiZWZvcmUgYW55IG90aGVyIGV4cHJlc3Npb24uXG4gICAgICBleHByZXNzaW9uc0hlYWQucHVzaChzdHlsZUF0dGFjaFRoZW1lKTtcbiAgICAgIGlmIChjb21wb25lbnROYW1lICYmIG92ZXJyaWRlc1Jlc29sdmVyKSB7XG4gICAgICAgIGV4cHJlc3Npb25zVGFpbC5wdXNoKGZ1bmN0aW9uIHN0eWxlVGhlbWVPdmVycmlkZXMocHJvcHMpIHtcbiAgICAgICAgICBjb25zdCB0aGVtZSA9IHByb3BzLnRoZW1lO1xuICAgICAgICAgIGNvbnN0IHN0eWxlT3ZlcnJpZGVzID0gdGhlbWUuY29tcG9uZW50cz8uW2NvbXBvbmVudE5hbWVdPy5zdHlsZU92ZXJyaWRlcztcbiAgICAgICAgICBpZiAoIXN0eWxlT3ZlcnJpZGVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgcmVzb2x2ZWRTdHlsZU92ZXJyaWRlcyA9IHt9O1xuXG4gICAgICAgICAgLy8gVE9ETzogdjcgcmVtb3ZlIGl0ZXJhdGlvbiBhbmQgdXNlIGByZXNvbHZlU3R5bGVBcmcoc3R5bGVPdmVycmlkZXNbc2xvdF0pYCBkaXJlY3RseVxuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBndWFyZC1mb3ItaW5cbiAgICAgICAgICBmb3IgKGNvbnN0IHNsb3RLZXkgaW4gc3R5bGVPdmVycmlkZXMpIHtcbiAgICAgICAgICAgIHJlc29sdmVkU3R5bGVPdmVycmlkZXNbc2xvdEtleV0gPSBwcm9jZXNzU3R5bGUocHJvcHMsIHN0eWxlT3ZlcnJpZGVzW3Nsb3RLZXldLCBwcm9wcy50aGVtZS5tb2R1bGFyQ3NzTGF5ZXJzID8gJ3RoZW1lJyA6IHVuZGVmaW5lZCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBvdmVycmlkZXNSZXNvbHZlcihwcm9wcywgcmVzb2x2ZWRTdHlsZU92ZXJyaWRlcyk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKGNvbXBvbmVudE5hbWUgJiYgIXNraXBWYXJpYW50c1Jlc29sdmVyKSB7XG4gICAgICAgIGV4cHJlc3Npb25zVGFpbC5wdXNoKGZ1bmN0aW9uIHN0eWxlVGhlbWVWYXJpYW50cyhwcm9wcykge1xuICAgICAgICAgIGNvbnN0IHRoZW1lID0gcHJvcHMudGhlbWU7XG4gICAgICAgICAgY29uc3QgdGhlbWVWYXJpYW50cyA9IHRoZW1lPy5jb21wb25lbnRzPy5bY29tcG9uZW50TmFtZV0/LnZhcmlhbnRzO1xuICAgICAgICAgIGlmICghdGhlbWVWYXJpYW50cykge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBwcm9jZXNzU3R5bGVWYXJpYW50cyhwcm9wcywgdGhlbWVWYXJpYW50cywgW10sIHByb3BzLnRoZW1lLm1vZHVsYXJDc3NMYXllcnMgPyAndGhlbWUnIDogdW5kZWZpbmVkKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAoIXNraXBTeCkge1xuICAgICAgICBleHByZXNzaW9uc1RhaWwucHVzaChzdHlsZUZ1bmN0aW9uU3gpO1xuICAgICAgfVxuXG4gICAgICAvLyBUaGlzIGZ1bmN0aW9uIGNhbiBiZSBjYWxsZWQgYXMgYSB0YWdnZWQgdGVtcGxhdGUsIHNvIHRoZSBmaXJzdCBhcmd1bWVudCB3b3VsZCBjb250YWluXG4gICAgICAvLyBDU1MgYHN0cmluZ1tdYCB2YWx1ZXMuXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShleHByZXNzaW9uc0JvZHlbMF0pKSB7XG4gICAgICAgIGNvbnN0IGlucHV0U3RyaW5ncyA9IGV4cHJlc3Npb25zQm9keS5zaGlmdCgpO1xuXG4gICAgICAgIC8vIFdlIG5lZWQgdG8gYWRkIHBsYWNlaG9sZGVycyBpbiB0aGUgdGFnZ2VkIHRlbXBsYXRlIGZvciB0aGUgY3VzdG9tIGZ1bmN0aW9ucyB3ZSBoYXZlXG4gICAgICAgIC8vIHBvc3NpYmx5IGFkZGVkIChhdHRhY2hUaGVtZSwgb3ZlcnJpZGVzLCB2YXJpYW50cywgYW5kIHN4KS5cbiAgICAgICAgY29uc3QgcGxhY2Vob2xkZXJzSGVhZCA9IG5ldyBBcnJheShleHByZXNzaW9uc0hlYWQubGVuZ3RoKS5maWxsKCcnKTtcbiAgICAgICAgY29uc3QgcGxhY2Vob2xkZXJzVGFpbCA9IG5ldyBBcnJheShleHByZXNzaW9uc1RhaWwubGVuZ3RoKS5maWxsKCcnKTtcbiAgICAgICAgbGV0IG91dHB1dFN0cmluZ3M7XG4gICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICB7XG4gICAgICAgICAgb3V0cHV0U3RyaW5ncyA9IFsuLi5wbGFjZWhvbGRlcnNIZWFkLCAuLi5pbnB1dFN0cmluZ3MsIC4uLnBsYWNlaG9sZGVyc1RhaWxdO1xuICAgICAgICAgIG91dHB1dFN0cmluZ3MucmF3ID0gWy4uLnBsYWNlaG9sZGVyc0hlYWQsIC4uLmlucHV0U3RyaW5ncy5yYXcsIC4uLnBsYWNlaG9sZGVyc1RhaWxdO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGhlIG9ubHkgY2FzZSB3aGVyZSB3ZSBwdXQgc29tZXRoaW5nIGJlZm9yZSBgYXR0YWNoVGhlbWVgXG4gICAgICAgIGV4cHJlc3Npb25zSGVhZC51bnNoaWZ0KG91dHB1dFN0cmluZ3MpO1xuICAgICAgfVxuICAgICAgY29uc3QgZXhwcmVzc2lvbnMgPSBbLi4uZXhwcmVzc2lvbnNIZWFkLCAuLi5leHByZXNzaW9uc0JvZHksIC4uLmV4cHJlc3Npb25zVGFpbF07XG4gICAgICBjb25zdCBDb21wb25lbnQgPSBkZWZhdWx0U3R5bGVkUmVzb2x2ZXIoLi4uZXhwcmVzc2lvbnMpO1xuICAgICAgaWYgKHRhZy5tdWlOYW1lKSB7XG4gICAgICAgIENvbXBvbmVudC5tdWlOYW1lID0gdGFnLm11aU5hbWU7XG4gICAgICB9XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBDb21wb25lbnQuZGlzcGxheU5hbWUgPSBnZW5lcmF0ZURpc3BsYXlOYW1lKGNvbXBvbmVudE5hbWUsIGNvbXBvbmVudFNsb3QsIHRhZyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gQ29tcG9uZW50O1xuICAgIH07XG4gICAgaWYgKGRlZmF1bHRTdHlsZWRSZXNvbHZlci53aXRoQ29uZmlnKSB7XG4gICAgICBtdWlTdHlsZWRSZXNvbHZlci53aXRoQ29uZmlnID0gZGVmYXVsdFN0eWxlZFJlc29sdmVyLndpdGhDb25maWc7XG4gICAgfVxuICAgIHJldHVybiBtdWlTdHlsZWRSZXNvbHZlcjtcbiAgfTtcbiAgcmV0dXJuIHN0eWxlZDtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlRGlzcGxheU5hbWUoY29tcG9uZW50TmFtZSwgY29tcG9uZW50U2xvdCwgdGFnKSB7XG4gIGlmIChjb21wb25lbnROYW1lKSB7XG4gICAgcmV0dXJuIGAke2NvbXBvbmVudE5hbWV9JHtjYXBpdGFsaXplKGNvbXBvbmVudFNsb3QgfHwgJycpfWA7XG4gIH1cbiAgcmV0dXJuIGBTdHlsZWQoJHtnZXREaXNwbGF5TmFtZSh0YWcpfSlgO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVTdHlsZWRMYWJlbChjb21wb25lbnROYW1lLCBjb21wb25lbnRTbG90KSB7XG4gIGxldCBsYWJlbDtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoY29tcG9uZW50TmFtZSkge1xuICAgICAgLy8gVE9ETyB2NjogcmVtb3ZlIGBsb3dlcmNhc2VGaXJzdExldHRlcigpYCBpbiB0aGUgbmV4dCBtYWpvciByZWxlYXNlXG4gICAgICAvLyBGb3IgbW9yZSBkZXRhaWxzOiBodHRwczovL2dpdGh1Yi5jb20vbXVpL21hdGVyaWFsLXVpL3B1bGwvMzc5MDhcbiAgICAgIGxhYmVsID0gYCR7Y29tcG9uZW50TmFtZX0tJHtsb3dlcmNhc2VGaXJzdExldHRlcihjb21wb25lbnRTbG90IHx8ICdSb290Jyl9YDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGxhYmVsO1xufVxuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vZW1vdGlvbi1qcy9lbW90aW9uL2Jsb2IvMjZkZWQ2MTA5ZmNkOGNhOTg3NWNjMmNlNDU2NGZlZTY3OGEzZjNjNS9wYWNrYWdlcy9zdHlsZWQvc3JjL3V0aWxzLmpzI0w0MFxuZnVuY3Rpb24gaXNTdHJpbmdUYWcodGFnKSB7XG4gIHJldHVybiB0eXBlb2YgdGFnID09PSAnc3RyaW5nJyAmJlxuICAvLyA5NiBpcyBvbmUgbGVzcyB0aGFuIHRoZSBjaGFyIGNvZGVcbiAgLy8gZm9yIFwiYVwiIHNvIHRoaXMgaXMgY2hlY2tpbmcgdGhhdFxuICAvLyBpdCdzIGEgbG93ZXJjYXNlIGNoYXJhY3RlclxuICB0YWcuY2hhckNvZGVBdCgwKSA+IDk2O1xufVxuZnVuY3Rpb24gbG93ZXJjYXNlRmlyc3RMZXR0ZXIoc3RyaW5nKSB7XG4gIGlmICghc3RyaW5nKSB7XG4gICAgcmV0dXJuIHN0cmluZztcbiAgfVxuICByZXR1cm4gc3RyaW5nLmNoYXJBdCgwKS50b0xvd2VyQ2FzZSgpICsgc3RyaW5nLnNsaWNlKDEpO1xufSIsImltcG9ydCBjbHN4IGZyb20gJ2Nsc3gnO1xuXG4vKipcbiAqIEFkZCBrZXlzLCB2YWx1ZXMgb2YgYGRlZmF1bHRQcm9wc2AgdGhhdCBkb2VzIG5vdCBleGlzdCBpbiBgcHJvcHNgXG4gKiBAcGFyYW0gZGVmYXVsdFByb3BzXG4gKiBAcGFyYW0gcHJvcHNcbiAqIEBwYXJhbSBtZXJnZUNsYXNzTmFtZUFuZFN0eWxlIElmIGB0cnVlYCwgbWVyZ2VzIGBjbGFzc05hbWVgIGFuZCBgc3R5bGVgIHByb3BzIGluc3RlYWQgb2Ygb3ZlcnJpZGluZyB0aGVtLlxuICogICBXaGVuIGBmYWxzZWAgKGRlZmF1bHQpLCBwcm9wcyBvdmVycmlkZSBkZWZhdWx0UHJvcHMuIFdoZW4gYHRydWVgLCBgY2xhc3NOYW1lYCB2YWx1ZXMgYXJlIGNvbmNhdGVuYXRlZFxuICogICBhbmQgYHN0eWxlYCBvYmplY3RzIGFyZSBtZXJnZWQgd2l0aCBwcm9wcyB0YWtpbmcgcHJlY2VkZW5jZS5cbiAqIEByZXR1cm5zIHJlc29sdmVkIHByb3BzXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlc29sdmVQcm9wcyhkZWZhdWx0UHJvcHMsIHByb3BzLCBtZXJnZUNsYXNzTmFtZUFuZFN0eWxlID0gZmFsc2UpIHtcbiAgY29uc3Qgb3V0cHV0ID0ge1xuICAgIC4uLnByb3BzXG4gIH07XG4gIGZvciAoY29uc3Qga2V5IGluIGRlZmF1bHRQcm9wcykge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZGVmYXVsdFByb3BzLCBrZXkpKSB7XG4gICAgICBjb25zdCBwcm9wTmFtZSA9IGtleTtcbiAgICAgIGlmIChwcm9wTmFtZSA9PT0gJ2NvbXBvbmVudHMnIHx8IHByb3BOYW1lID09PSAnc2xvdHMnKSB7XG4gICAgICAgIG91dHB1dFtwcm9wTmFtZV0gPSB7XG4gICAgICAgICAgLi4uZGVmYXVsdFByb3BzW3Byb3BOYW1lXSxcbiAgICAgICAgICAuLi5vdXRwdXRbcHJvcE5hbWVdXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKHByb3BOYW1lID09PSAnY29tcG9uZW50c1Byb3BzJyB8fCBwcm9wTmFtZSA9PT0gJ3Nsb3RQcm9wcycpIHtcbiAgICAgICAgY29uc3QgZGVmYXVsdFNsb3RQcm9wcyA9IGRlZmF1bHRQcm9wc1twcm9wTmFtZV07XG4gICAgICAgIGNvbnN0IHNsb3RQcm9wcyA9IHByb3BzW3Byb3BOYW1lXTtcbiAgICAgICAgaWYgKCFzbG90UHJvcHMpIHtcbiAgICAgICAgICBvdXRwdXRbcHJvcE5hbWVdID0gZGVmYXVsdFNsb3RQcm9wcyB8fCB7fTtcbiAgICAgICAgfSBlbHNlIGlmICghZGVmYXVsdFNsb3RQcm9wcykge1xuICAgICAgICAgIG91dHB1dFtwcm9wTmFtZV0gPSBzbG90UHJvcHM7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3V0cHV0W3Byb3BOYW1lXSA9IHtcbiAgICAgICAgICAgIC4uLnNsb3RQcm9wc1xuICAgICAgICAgIH07XG4gICAgICAgICAgZm9yIChjb25zdCBzbG90S2V5IGluIGRlZmF1bHRTbG90UHJvcHMpIHtcbiAgICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZGVmYXVsdFNsb3RQcm9wcywgc2xvdEtleSkpIHtcbiAgICAgICAgICAgICAgY29uc3Qgc2xvdFByb3BOYW1lID0gc2xvdEtleTtcbiAgICAgICAgICAgICAgb3V0cHV0W3Byb3BOYW1lXVtzbG90UHJvcE5hbWVdID0gcmVzb2x2ZVByb3BzKGRlZmF1bHRTbG90UHJvcHNbc2xvdFByb3BOYW1lXSwgc2xvdFByb3BzW3Nsb3RQcm9wTmFtZV0sIG1lcmdlQ2xhc3NOYW1lQW5kU3R5bGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChwcm9wTmFtZSA9PT0gJ2NsYXNzTmFtZScgJiYgbWVyZ2VDbGFzc05hbWVBbmRTdHlsZSAmJiBwcm9wcy5jbGFzc05hbWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBvdXRwdXQuY2xhc3NOYW1lID0gY2xzeChkZWZhdWx0UHJvcHM/LmNsYXNzTmFtZSwgcHJvcHM/LmNsYXNzTmFtZSk7XG4gICAgICB9IGVsc2UgaWYgKHByb3BOYW1lID09PSAnc3R5bGUnICYmIG1lcmdlQ2xhc3NOYW1lQW5kU3R5bGUgJiYgcHJvcHMuc3R5bGUpIHtcbiAgICAgICAgb3V0cHV0LnN0eWxlID0ge1xuICAgICAgICAgIC4uLmRlZmF1bHRQcm9wcz8uc3R5bGUsXG4gICAgICAgICAgLi4ucHJvcHM/LnN0eWxlXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKG91dHB1dFtwcm9wTmFtZV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBvdXRwdXRbcHJvcE5hbWVdID0gZGVmYXVsdFByb3BzW3Byb3BOYW1lXTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dHB1dDtcbn0iLCJmdW5jdGlvbiBjbGFtcCh2YWwsIG1pbiA9IE51bWJlci5NSU5fU0FGRV9JTlRFR0VSLCBtYXggPSBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUikge1xuICByZXR1cm4gTWF0aC5tYXgobWluLCBNYXRoLm1pbih2YWwsIG1heCkpO1xufVxuZXhwb3J0IGRlZmF1bHQgY2xhbXA7IiwiaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBtdWkvdXRpbHMvZm9ybWF0TXVpRXJyb3JNZXNzYWdlXCI7XG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbmFtaW5nLWNvbnZlbnRpb24gKi9cbmltcG9ydCBjbGFtcCBmcm9tICdAbXVpL3V0aWxzL2NsYW1wJztcblxuLyoqXG4gKiBSZXR1cm5zIGEgbnVtYmVyIHdob3NlIHZhbHVlIGlzIGxpbWl0ZWQgdG8gdGhlIGdpdmVuIHJhbmdlLlxuICogQHBhcmFtIHtudW1iZXJ9IHZhbHVlIFRoZSB2YWx1ZSB0byBiZSBjbGFtcGVkXG4gKiBAcGFyYW0ge251bWJlcn0gbWluIFRoZSBsb3dlciBib3VuZGFyeSBvZiB0aGUgb3V0cHV0IHJhbmdlXG4gKiBAcGFyYW0ge251bWJlcn0gbWF4IFRoZSB1cHBlciBib3VuZGFyeSBvZiB0aGUgb3V0cHV0IHJhbmdlXG4gKiBAcmV0dXJucyB7bnVtYmVyfSBBIG51bWJlciBpbiB0aGUgcmFuZ2UgW21pbiwgbWF4XVxuICovXG5mdW5jdGlvbiBjbGFtcFdyYXBwZXIodmFsdWUsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAodmFsdWUgPCBtaW4gfHwgdmFsdWUgPiBtYXgpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYE1VSTogVGhlIHZhbHVlIHByb3ZpZGVkICR7dmFsdWV9IGlzIG91dCBvZiByYW5nZSBbJHttaW59LCAke21heH1dLmApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gY2xhbXAodmFsdWUsIG1pbiwgbWF4KTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhIGNvbG9yIGZyb20gQ1NTIGhleCBmb3JtYXQgdG8gQ1NTIHJnYiBmb3JtYXQuXG4gKiBAcGFyYW0ge3N0cmluZ30gY29sb3IgLSBIZXggY29sb3IsIGkuZS4gI25ubiBvciAjbm5ubm5uXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIENTUyByZ2IgY29sb3Igc3RyaW5nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoZXhUb1JnYihjb2xvcikge1xuICBjb2xvciA9IGNvbG9yLnNsaWNlKDEpO1xuICBjb25zdCByZSA9IG5ldyBSZWdFeHAoYC57MSwke2NvbG9yLmxlbmd0aCA+PSA2ID8gMiA6IDF9fWAsICdnJyk7XG4gIGxldCBjb2xvcnMgPSBjb2xvci5tYXRjaChyZSk7XG4gIGlmIChjb2xvcnMgJiYgY29sb3JzWzBdLmxlbmd0aCA9PT0gMSkge1xuICAgIGNvbG9ycyA9IGNvbG9ycy5tYXAobiA9PiBuICsgbik7XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoY29sb3IubGVuZ3RoICE9PSBjb2xvci50cmltKCkubGVuZ3RoKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBNVUk6IFRoZSBjb2xvcjogXCIke2NvbG9yfVwiIGlzIGludmFsaWQuIE1ha2Ugc3VyZSB0aGUgY29sb3IgaW5wdXQgZG9lc24ndCBjb250YWluIGxlYWRpbmcvdHJhaWxpbmcgc3BhY2UuYCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBjb2xvcnMgPyBgcmdiJHtjb2xvcnMubGVuZ3RoID09PSA0ID8gJ2EnIDogJyd9KCR7Y29sb3JzLm1hcCgobiwgaW5kZXgpID0+IHtcbiAgICByZXR1cm4gaW5kZXggPCAzID8gcGFyc2VJbnQobiwgMTYpIDogTWF0aC5yb3VuZChwYXJzZUludChuLCAxNikgLyAyNTUgKiAxMDAwKSAvIDEwMDA7XG4gIH0pLmpvaW4oJywgJyl9KWAgOiAnJztcbn1cbmZ1bmN0aW9uIGludFRvSGV4KGludCkge1xuICBjb25zdCBoZXggPSBpbnQudG9TdHJpbmcoMTYpO1xuICByZXR1cm4gaGV4Lmxlbmd0aCA9PT0gMSA/IGAwJHtoZXh9YCA6IGhleDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIG9iamVjdCB3aXRoIHRoZSB0eXBlIGFuZCB2YWx1ZXMgb2YgYSBjb2xvci5cbiAqXG4gKiBOb3RlOiBEb2VzIG5vdCBzdXBwb3J0IHJnYiAlIHZhbHVlcy5cbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKCksIGNvbG9yKClcbiAqIEByZXR1cm5zIHtvYmplY3R9IC0gQSBNVUkgY29sb3Igb2JqZWN0OiB7dHlwZTogc3RyaW5nLCB2YWx1ZXM6IG51bWJlcltdfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb21wb3NlQ29sb3IoY29sb3IpIHtcbiAgLy8gSWRlbXBvdGVudFxuICBpZiAoY29sb3IudHlwZSkge1xuICAgIHJldHVybiBjb2xvcjtcbiAgfVxuICBpZiAoY29sb3IuY2hhckF0KDApID09PSAnIycpIHtcbiAgICByZXR1cm4gZGVjb21wb3NlQ29sb3IoaGV4VG9SZ2IoY29sb3IpKTtcbiAgfVxuICBjb25zdCBtYXJrZXIgPSBjb2xvci5pbmRleE9mKCcoJyk7XG4gIGNvbnN0IHR5cGUgPSBjb2xvci5zdWJzdHJpbmcoMCwgbWFya2VyKTtcbiAgaWYgKCFbJ3JnYicsICdyZ2JhJywgJ2hzbCcsICdoc2xhJywgJ2NvbG9yJ10uaW5jbHVkZXModHlwZSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYE1VSTogVW5zdXBwb3J0ZWQgXFxgJHtjb2xvcn1cXGAgY29sb3IuXFxuYCArICdUaGUgZm9sbG93aW5nIGZvcm1hdHMgYXJlIHN1cHBvcnRlZDogI25ubiwgI25ubm5ubiwgcmdiKCksIHJnYmEoKSwgaHNsKCksIGhzbGEoKSwgY29sb3IoKS4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg5LCBjb2xvcikpO1xuICB9XG4gIGxldCB2YWx1ZXMgPSBjb2xvci5zdWJzdHJpbmcobWFya2VyICsgMSwgY29sb3IubGVuZ3RoIC0gMSk7XG4gIGxldCBjb2xvclNwYWNlO1xuICBpZiAodHlwZSA9PT0gJ2NvbG9yJykge1xuICAgIHZhbHVlcyA9IHZhbHVlcy5zcGxpdCgnICcpO1xuICAgIGNvbG9yU3BhY2UgPSB2YWx1ZXMuc2hpZnQoKTtcbiAgICBpZiAodmFsdWVzLmxlbmd0aCA9PT0gNCAmJiB2YWx1ZXNbM10uY2hhckF0KDApID09PSAnLycpIHtcbiAgICAgIHZhbHVlc1szXSA9IHZhbHVlc1szXS5zbGljZSgxKTtcbiAgICB9XG4gICAgaWYgKCFbJ3NyZ2InLCAnZGlzcGxheS1wMycsICdhOTgtcmdiJywgJ3Byb3Bob3RvLXJnYicsICdyZWMtMjAyMCddLmluY2x1ZGVzKGNvbG9yU3BhY2UpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYE1VSTogdW5zdXBwb3J0ZWQgXFxgJHtjb2xvclNwYWNlfVxcYCBjb2xvciBzcGFjZS5cXG5gICsgJ1RoZSBmb2xsb3dpbmcgY29sb3Igc3BhY2VzIGFyZSBzdXBwb3J0ZWQ6IHNyZ2IsIGRpc3BsYXktcDMsIGE5OC1yZ2IsIHByb3Bob3RvLXJnYiwgcmVjLTIwMjAuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTAsIGNvbG9yU3BhY2UpKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdmFsdWVzID0gdmFsdWVzLnNwbGl0KCcsJyk7XG4gIH1cbiAgdmFsdWVzID0gdmFsdWVzLm1hcCh2YWx1ZSA9PiBwYXJzZUZsb2F0KHZhbHVlKSk7XG4gIHJldHVybiB7XG4gICAgdHlwZSxcbiAgICB2YWx1ZXMsXG4gICAgY29sb3JTcGFjZVxuICB9O1xufVxuXG4vKipcbiAqIFJldHVybnMgYSBjaGFubmVsIGNyZWF0ZWQgZnJvbSB0aGUgaW5wdXQgY29sb3IuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGNvbG9yIC0gQ1NTIGNvbG9yLCBpLmUuIG9uZSBvZjogI25ubiwgI25ubm5ubiwgcmdiKCksIHJnYmEoKSwgaHNsKCksIGhzbGEoKSwgY29sb3IoKVxuICogQHJldHVybnMge3N0cmluZ30gLSBUaGUgY2hhbm5lbCBmb3IgdGhlIGNvbG9yLCB0aGF0IGNhbiBiZSB1c2VkIGluIHJnYmEgb3IgaHNsYSBjb2xvcnNcbiAqL1xuZXhwb3J0IGNvbnN0IGNvbG9yQ2hhbm5lbCA9IGNvbG9yID0+IHtcbiAgY29uc3QgZGVjb21wb3NlZENvbG9yID0gZGVjb21wb3NlQ29sb3IoY29sb3IpO1xuICByZXR1cm4gZGVjb21wb3NlZENvbG9yLnZhbHVlcy5zbGljZSgwLCAzKS5tYXAoKHZhbCwgaWR4KSA9PiBkZWNvbXBvc2VkQ29sb3IudHlwZS5pbmNsdWRlcygnaHNsJykgJiYgaWR4ICE9PSAwID8gYCR7dmFsfSVgIDogdmFsKS5qb2luKCcgJyk7XG59O1xuZXhwb3J0IGNvbnN0IHByaXZhdGVfc2FmZUNvbG9yQ2hhbm5lbCA9IChjb2xvciwgd2FybmluZykgPT4ge1xuICB0cnkge1xuICAgIHJldHVybiBjb2xvckNoYW5uZWwoY29sb3IpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmICh3YXJuaW5nICYmIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIGNvbnNvbGUud2Fybih3YXJuaW5nKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbG9yO1xuICB9XG59O1xuXG4vKipcbiAqIENvbnZlcnRzIGEgY29sb3Igb2JqZWN0IHdpdGggdHlwZSBhbmQgdmFsdWVzIHRvIGEgc3RyaW5nLlxuICogQHBhcmFtIHtvYmplY3R9IGNvbG9yIC0gRGVjb21wb3NlZCBjb2xvclxuICogQHBhcmFtIHtzdHJpbmd9IGNvbG9yLnR5cGUgLSBPbmUgb2Y6ICdyZ2InLCAncmdiYScsICdoc2wnLCAnaHNsYScsICdjb2xvcidcbiAqIEBwYXJhbSB7YXJyYXl9IGNvbG9yLnZhbHVlcyAtIFtuLG4sbl0gb3IgW24sbixuLG5dXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIENTUyBjb2xvciBzdHJpbmdcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlY29tcG9zZUNvbG9yKGNvbG9yKSB7XG4gIGNvbnN0IHtcbiAgICB0eXBlLFxuICAgIGNvbG9yU3BhY2VcbiAgfSA9IGNvbG9yO1xuICBsZXQge1xuICAgIHZhbHVlc1xuICB9ID0gY29sb3I7XG4gIGlmICh0eXBlLmluY2x1ZGVzKCdyZ2InKSkge1xuICAgIC8vIE9ubHkgY29udmVydCB0aGUgZmlyc3QgMyB2YWx1ZXMgdG8gaW50IChpLmUuIG5vdCBhbHBoYSlcbiAgICB2YWx1ZXMgPSB2YWx1ZXMubWFwKChuLCBpKSA9PiBpIDwgMyA/IHBhcnNlSW50KG4sIDEwKSA6IG4pO1xuICB9IGVsc2UgaWYgKHR5cGUuaW5jbHVkZXMoJ2hzbCcpKSB7XG4gICAgdmFsdWVzWzFdID0gYCR7dmFsdWVzWzFdfSVgO1xuICAgIHZhbHVlc1syXSA9IGAke3ZhbHVlc1syXX0lYDtcbiAgfVxuICBpZiAodHlwZS5pbmNsdWRlcygnY29sb3InKSkge1xuICAgIHZhbHVlcyA9IGAke2NvbG9yU3BhY2V9ICR7dmFsdWVzLmpvaW4oJyAnKX1gO1xuICB9IGVsc2Uge1xuICAgIHZhbHVlcyA9IGAke3ZhbHVlcy5qb2luKCcsICcpfWA7XG4gIH1cbiAgcmV0dXJuIGAke3R5cGV9KCR7dmFsdWVzfSlgO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGEgY29sb3IgZnJvbSBDU1MgcmdiIGZvcm1hdCB0byBDU1MgaGV4IGZvcm1hdC5cbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIFJHQiBjb2xvciwgaS5lLiByZ2IobiwgbiwgbilcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEEgQ1NTIHJnYiBjb2xvciBzdHJpbmcsIGkuZS4gI25ubm5ublxuICovXG5leHBvcnQgZnVuY3Rpb24gcmdiVG9IZXgoY29sb3IpIHtcbiAgLy8gSWRlbXBvdGVudFxuICBpZiAoY29sb3Iuc3RhcnRzV2l0aCgnIycpKSB7XG4gICAgcmV0dXJuIGNvbG9yO1xuICB9XG4gIGNvbnN0IHtcbiAgICB2YWx1ZXNcbiAgfSA9IGRlY29tcG9zZUNvbG9yKGNvbG9yKTtcbiAgcmV0dXJuIGAjJHt2YWx1ZXMubWFwKChuLCBpKSA9PiBpbnRUb0hleChpID09PSAzID8gTWF0aC5yb3VuZCgyNTUgKiBuKSA6IG4pKS5qb2luKCcnKX1gO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGEgY29sb3IgZnJvbSBoc2wgZm9ybWF0IHRvIHJnYiBmb3JtYXQuXG4gKiBAcGFyYW0ge3N0cmluZ30gY29sb3IgLSBIU0wgY29sb3IgdmFsdWVzXG4gKiBAcmV0dXJucyB7c3RyaW5nfSByZ2IgY29sb3IgdmFsdWVzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoc2xUb1JnYihjb2xvcikge1xuICBjb2xvciA9IGRlY29tcG9zZUNvbG9yKGNvbG9yKTtcbiAgY29uc3Qge1xuICAgIHZhbHVlc1xuICB9ID0gY29sb3I7XG4gIGNvbnN0IGggPSB2YWx1ZXNbMF07XG4gIGNvbnN0IHMgPSB2YWx1ZXNbMV0gLyAxMDA7XG4gIGNvbnN0IGwgPSB2YWx1ZXNbMl0gLyAxMDA7XG4gIGNvbnN0IGEgPSBzICogTWF0aC5taW4obCwgMSAtIGwpO1xuICBjb25zdCBmID0gKG4sIGsgPSAobiArIGggLyAzMCkgJSAxMikgPT4gbCAtIGEgKiBNYXRoLm1heChNYXRoLm1pbihrIC0gMywgOSAtIGssIDEpLCAtMSk7XG4gIGxldCB0eXBlID0gJ3JnYic7XG4gIGNvbnN0IHJnYiA9IFtNYXRoLnJvdW5kKGYoMCkgKiAyNTUpLCBNYXRoLnJvdW5kKGYoOCkgKiAyNTUpLCBNYXRoLnJvdW5kKGYoNCkgKiAyNTUpXTtcbiAgaWYgKGNvbG9yLnR5cGUgPT09ICdoc2xhJykge1xuICAgIHR5cGUgKz0gJ2EnO1xuICAgIHJnYi5wdXNoKHZhbHVlc1szXSk7XG4gIH1cbiAgcmV0dXJuIHJlY29tcG9zZUNvbG9yKHtcbiAgICB0eXBlLFxuICAgIHZhbHVlczogcmdiXG4gIH0pO1xufVxuLyoqXG4gKiBUaGUgcmVsYXRpdmUgYnJpZ2h0bmVzcyBvZiBhbnkgcG9pbnQgaW4gYSBjb2xvciBzcGFjZSxcbiAqIG5vcm1hbGl6ZWQgdG8gMCBmb3IgZGFya2VzdCBibGFjayBhbmQgMSBmb3IgbGlnaHRlc3Qgd2hpdGUuXG4gKlxuICogRm9ybXVsYTogaHR0cHM6Ly93d3cudzMub3JnL1RSL1dDQUcyMC1URUNIUy9HMTcuaHRtbCNHMTctdGVzdHNcbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKCksIGNvbG9yKClcbiAqIEByZXR1cm5zIHtudW1iZXJ9IFRoZSByZWxhdGl2ZSBicmlnaHRuZXNzIG9mIHRoZSBjb2xvciBpbiB0aGUgcmFuZ2UgMCAtIDFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEx1bWluYW5jZShjb2xvcikge1xuICBjb2xvciA9IGRlY29tcG9zZUNvbG9yKGNvbG9yKTtcbiAgbGV0IHJnYiA9IGNvbG9yLnR5cGUgPT09ICdoc2wnIHx8IGNvbG9yLnR5cGUgPT09ICdoc2xhJyA/IGRlY29tcG9zZUNvbG9yKGhzbFRvUmdiKGNvbG9yKSkudmFsdWVzIDogY29sb3IudmFsdWVzO1xuICByZ2IgPSByZ2IubWFwKHZhbCA9PiB7XG4gICAgaWYgKGNvbG9yLnR5cGUgIT09ICdjb2xvcicpIHtcbiAgICAgIHZhbCAvPSAyNTU7IC8vIG5vcm1hbGl6ZWRcbiAgICB9XG4gICAgcmV0dXJuIHZhbCA8PSAwLjAzOTI4ID8gdmFsIC8gMTIuOTIgOiAoKHZhbCArIDAuMDU1KSAvIDEuMDU1KSAqKiAyLjQ7XG4gIH0pO1xuXG4gIC8vIFRydW5jYXRlIGF0IDMgZGlnaXRzXG4gIHJldHVybiBOdW1iZXIoKDAuMjEyNiAqIHJnYlswXSArIDAuNzE1MiAqIHJnYlsxXSArIDAuMDcyMiAqIHJnYlsyXSkudG9GaXhlZCgzKSk7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgY29udHJhc3QgcmF0aW8gYmV0d2VlbiB0d28gY29sb3JzLlxuICpcbiAqIEZvcm11bGE6IGh0dHBzOi8vd3d3LnczLm9yZy9UUi9XQ0FHMjAtVEVDSFMvRzE3Lmh0bWwjRzE3LXRlc3RzXG4gKiBAcGFyYW0ge3N0cmluZ30gZm9yZWdyb3VuZCAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKClcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYWNrZ3JvdW5kIC0gQ1NTIGNvbG9yLCBpLmUuIG9uZSBvZjogI25ubiwgI25ubm5ubiwgcmdiKCksIHJnYmEoKSwgaHNsKCksIGhzbGEoKVxuICogQHJldHVybnMge251bWJlcn0gQSBjb250cmFzdCByYXRpbyB2YWx1ZSBpbiB0aGUgcmFuZ2UgMCAtIDIxLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29udHJhc3RSYXRpbyhmb3JlZ3JvdW5kLCBiYWNrZ3JvdW5kKSB7XG4gIGNvbnN0IGx1bUEgPSBnZXRMdW1pbmFuY2UoZm9yZWdyb3VuZCk7XG4gIGNvbnN0IGx1bUIgPSBnZXRMdW1pbmFuY2UoYmFja2dyb3VuZCk7XG4gIHJldHVybiAoTWF0aC5tYXgobHVtQSwgbHVtQikgKyAwLjA1KSAvIChNYXRoLm1pbihsdW1BLCBsdW1CKSArIDAuMDUpO1xufVxuXG4vKipcbiAqIFNldHMgdGhlIGFic29sdXRlIHRyYW5zcGFyZW5jeSBvZiBhIGNvbG9yLlxuICogQW55IGV4aXN0aW5nIGFscGhhIHZhbHVlcyBhcmUgb3ZlcndyaXR0ZW4uXG4gKiBAcGFyYW0ge3N0cmluZ30gY29sb3IgLSBDU1MgY29sb3IsIGkuZS4gb25lIG9mOiAjbm5uLCAjbm5ubm5uLCByZ2IoKSwgcmdiYSgpLCBoc2woKSwgaHNsYSgpLCBjb2xvcigpXG4gKiBAcGFyYW0ge251bWJlcn0gdmFsdWUgLSB2YWx1ZSB0byBzZXQgdGhlIGFscGhhIGNoYW5uZWwgdG8gaW4gdGhlIHJhbmdlIDAgLSAxXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIENTUyBjb2xvciBzdHJpbmcuIEhleCBpbnB1dCB2YWx1ZXMgYXJlIHJldHVybmVkIGFzIHJnYlxuICovXG5leHBvcnQgZnVuY3Rpb24gYWxwaGEoY29sb3IsIHZhbHVlKSB7XG4gIGNvbG9yID0gZGVjb21wb3NlQ29sb3IoY29sb3IpO1xuICB2YWx1ZSA9IGNsYW1wV3JhcHBlcih2YWx1ZSk7XG4gIGlmIChjb2xvci50eXBlID09PSAncmdiJyB8fCBjb2xvci50eXBlID09PSAnaHNsJykge1xuICAgIGNvbG9yLnR5cGUgKz0gJ2EnO1xuICB9XG4gIGlmIChjb2xvci50eXBlID09PSAnY29sb3InKSB7XG4gICAgY29sb3IudmFsdWVzWzNdID0gYC8ke3ZhbHVlfWA7XG4gIH0gZWxzZSB7XG4gICAgY29sb3IudmFsdWVzWzNdID0gdmFsdWU7XG4gIH1cbiAgcmV0dXJuIHJlY29tcG9zZUNvbG9yKGNvbG9yKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwcml2YXRlX3NhZmVBbHBoYShjb2xvciwgdmFsdWUsIHdhcm5pbmcpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gYWxwaGEoY29sb3IsIHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAod2FybmluZyAmJiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBjb25zb2xlLndhcm4od2FybmluZyk7XG4gICAgfVxuICAgIHJldHVybiBjb2xvcjtcbiAgfVxufVxuXG4vKipcbiAqIERhcmtlbnMgYSBjb2xvci5cbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKCksIGNvbG9yKClcbiAqIEBwYXJhbSB7bnVtYmVyfSBjb2VmZmljaWVudCAtIG11bHRpcGxpZXIgaW4gdGhlIHJhbmdlIDAgLSAxXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIENTUyBjb2xvciBzdHJpbmcuIEhleCBpbnB1dCB2YWx1ZXMgYXJlIHJldHVybmVkIGFzIHJnYlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGFya2VuKGNvbG9yLCBjb2VmZmljaWVudCkge1xuICBjb2xvciA9IGRlY29tcG9zZUNvbG9yKGNvbG9yKTtcbiAgY29lZmZpY2llbnQgPSBjbGFtcFdyYXBwZXIoY29lZmZpY2llbnQpO1xuICBpZiAoY29sb3IudHlwZS5pbmNsdWRlcygnaHNsJykpIHtcbiAgICBjb2xvci52YWx1ZXNbMl0gKj0gMSAtIGNvZWZmaWNpZW50O1xuICB9IGVsc2UgaWYgKGNvbG9yLnR5cGUuaW5jbHVkZXMoJ3JnYicpIHx8IGNvbG9yLnR5cGUuaW5jbHVkZXMoJ2NvbG9yJykpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDM7IGkgKz0gMSkge1xuICAgICAgY29sb3IudmFsdWVzW2ldICo9IDEgLSBjb2VmZmljaWVudDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlY29tcG9zZUNvbG9yKGNvbG9yKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwcml2YXRlX3NhZmVEYXJrZW4oY29sb3IsIGNvZWZmaWNpZW50LCB3YXJuaW5nKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGRhcmtlbihjb2xvciwgY29lZmZpY2llbnQpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmICh3YXJuaW5nICYmIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIGNvbnNvbGUud2Fybih3YXJuaW5nKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbG9yO1xuICB9XG59XG5cbi8qKlxuICogTGlnaHRlbnMgYSBjb2xvci5cbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKCksIGNvbG9yKClcbiAqIEBwYXJhbSB7bnVtYmVyfSBjb2VmZmljaWVudCAtIG11bHRpcGxpZXIgaW4gdGhlIHJhbmdlIDAgLSAxXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIENTUyBjb2xvciBzdHJpbmcuIEhleCBpbnB1dCB2YWx1ZXMgYXJlIHJldHVybmVkIGFzIHJnYlxuICovXG5leHBvcnQgZnVuY3Rpb24gbGlnaHRlbihjb2xvciwgY29lZmZpY2llbnQpIHtcbiAgY29sb3IgPSBkZWNvbXBvc2VDb2xvcihjb2xvcik7XG4gIGNvZWZmaWNpZW50ID0gY2xhbXBXcmFwcGVyKGNvZWZmaWNpZW50KTtcbiAgaWYgKGNvbG9yLnR5cGUuaW5jbHVkZXMoJ2hzbCcpKSB7XG4gICAgY29sb3IudmFsdWVzWzJdICs9ICgxMDAgLSBjb2xvci52YWx1ZXNbMl0pICogY29lZmZpY2llbnQ7XG4gIH0gZWxzZSBpZiAoY29sb3IudHlwZS5pbmNsdWRlcygncmdiJykpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDM7IGkgKz0gMSkge1xuICAgICAgY29sb3IudmFsdWVzW2ldICs9ICgyNTUgLSBjb2xvci52YWx1ZXNbaV0pICogY29lZmZpY2llbnQ7XG4gICAgfVxuICB9IGVsc2UgaWYgKGNvbG9yLnR5cGUuaW5jbHVkZXMoJ2NvbG9yJykpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDM7IGkgKz0gMSkge1xuICAgICAgY29sb3IudmFsdWVzW2ldICs9ICgxIC0gY29sb3IudmFsdWVzW2ldKSAqIGNvZWZmaWNpZW50O1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVjb21wb3NlQ29sb3IoY29sb3IpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHByaXZhdGVfc2FmZUxpZ2h0ZW4oY29sb3IsIGNvZWZmaWNpZW50LCB3YXJuaW5nKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGxpZ2h0ZW4oY29sb3IsIGNvZWZmaWNpZW50KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAod2FybmluZyAmJiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBjb25zb2xlLndhcm4od2FybmluZyk7XG4gICAgfVxuICAgIHJldHVybiBjb2xvcjtcbiAgfVxufVxuXG4vKipcbiAqIERhcmtlbiBvciBsaWdodGVuIGEgY29sb3IsIGRlcGVuZGluZyBvbiBpdHMgbHVtaW5hbmNlLlxuICogTGlnaHQgY29sb3JzIGFyZSBkYXJrZW5lZCwgZGFyayBjb2xvcnMgYXJlIGxpZ2h0ZW5lZC5cbiAqIEBwYXJhbSB7c3RyaW5nfSBjb2xvciAtIENTUyBjb2xvciwgaS5lLiBvbmUgb2Y6ICNubm4sICNubm5ubm4sIHJnYigpLCByZ2JhKCksIGhzbCgpLCBoc2xhKCksIGNvbG9yKClcbiAqIEBwYXJhbSB7bnVtYmVyfSBjb2VmZmljaWVudD0wLjE1IC0gbXVsdGlwbGllciBpbiB0aGUgcmFuZ2UgMCAtIDFcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEEgQ1NTIGNvbG9yIHN0cmluZy4gSGV4IGlucHV0IHZhbHVlcyBhcmUgcmV0dXJuZWQgYXMgcmdiXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbXBoYXNpemUoY29sb3IsIGNvZWZmaWNpZW50ID0gMC4xNSkge1xuICByZXR1cm4gZ2V0THVtaW5hbmNlKGNvbG9yKSA+IDAuNSA/IGRhcmtlbihjb2xvciwgY29lZmZpY2llbnQpIDogbGlnaHRlbihjb2xvciwgY29lZmZpY2llbnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHByaXZhdGVfc2FmZUVtcGhhc2l6ZShjb2xvciwgY29lZmZpY2llbnQsIHdhcm5pbmcpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gZW1waGFzaXplKGNvbG9yLCBjb2VmZmljaWVudCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgaWYgKHdhcm5pbmcgJiYgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc29sZS53YXJuKHdhcm5pbmcpO1xuICAgIH1cbiAgICByZXR1cm4gY29sb3I7XG4gIH1cbn1cblxuLyoqXG4gKiBCbGVuZCBhIHRyYW5zcGFyZW50IG92ZXJsYXkgY29sb3Igd2l0aCBhIGJhY2tncm91bmQgY29sb3IsIHJlc3VsdGluZyBpbiBhIHNpbmdsZVxuICogUkdCIGNvbG9yLlxuICogQHBhcmFtIHtzdHJpbmd9IGJhY2tncm91bmQgLSBDU1MgY29sb3JcbiAqIEBwYXJhbSB7c3RyaW5nfSBvdmVybGF5IC0gQ1NTIGNvbG9yXG4gKiBAcGFyYW0ge251bWJlcn0gb3BhY2l0eSAtIE9wYWNpdHkgbXVsdGlwbGllciBpbiB0aGUgcmFuZ2UgMCAtIDFcbiAqIEBwYXJhbSB7bnVtYmVyfSBbZ2FtbWE9MS4wXSAtIEdhbW1hIGNvcnJlY3Rpb24gZmFjdG9yLiBGb3IgZ2FtbWEtY29ycmVjdCBibGVuZGluZywgMi4yIGlzIHVzdWFsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYmxlbmQoYmFja2dyb3VuZCwgb3ZlcmxheSwgb3BhY2l0eSwgZ2FtbWEgPSAxLjApIHtcbiAgY29uc3QgYmxlbmRDaGFubmVsID0gKGIsIG8pID0+IE1hdGgucm91bmQoKGIgKiogKDEgLyBnYW1tYSkgKiAoMSAtIG9wYWNpdHkpICsgbyAqKiAoMSAvIGdhbW1hKSAqIG9wYWNpdHkpICoqIGdhbW1hKTtcbiAgY29uc3QgYmFja2dyb3VuZENvbG9yID0gZGVjb21wb3NlQ29sb3IoYmFja2dyb3VuZCk7XG4gIGNvbnN0IG92ZXJsYXlDb2xvciA9IGRlY29tcG9zZUNvbG9yKG92ZXJsYXkpO1xuICBjb25zdCByZ2IgPSBbYmxlbmRDaGFubmVsKGJhY2tncm91bmRDb2xvci52YWx1ZXNbMF0sIG92ZXJsYXlDb2xvci52YWx1ZXNbMF0pLCBibGVuZENoYW5uZWwoYmFja2dyb3VuZENvbG9yLnZhbHVlc1sxXSwgb3ZlcmxheUNvbG9yLnZhbHVlc1sxXSksIGJsZW5kQ2hhbm5lbChiYWNrZ3JvdW5kQ29sb3IudmFsdWVzWzJdLCBvdmVybGF5Q29sb3IudmFsdWVzWzJdKV07XG4gIHJldHVybiByZWNvbXBvc2VDb2xvcih7XG4gICAgdHlwZTogJ3JnYicsXG4gICAgdmFsdWVzOiByZ2JcbiAgfSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmNvbnN0IFJ0bENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCgpO1xuZnVuY3Rpb24gUnRsUHJvdmlkZXIoe1xuICB2YWx1ZSxcbiAgLi4ucHJvcHNcbn0pIHtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFJ0bENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdmFsdWUgPz8gdHJ1ZSxcbiAgICAuLi5wcm9wc1xuICB9KTtcbn1cbnByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFJ0bFByb3ZpZGVyLnByb3BUeXBlcyA9IHtcbiAgY2hpbGRyZW46IFByb3BUeXBlcy5ub2RlLFxuICB2YWx1ZTogUHJvcFR5cGVzLmJvb2xcbn0gOiB2b2lkIDA7XG5leHBvcnQgY29uc3QgdXNlUnRsID0gKCkgPT4ge1xuICBjb25zdCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoUnRsQ29udGV4dCk7XG4gIHJldHVybiB2YWx1ZSA/PyBmYWxzZTtcbn07XG5leHBvcnQgZGVmYXVsdCBSdGxQcm92aWRlcjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgcmVzb2x2ZVByb3BzIGZyb20gJ0BtdWkvdXRpbHMvcmVzb2x2ZVByb3BzJztcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBQcm9wc0NvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuZnVuY3Rpb24gRGVmYXVsdFByb3BzUHJvdmlkZXIoe1xuICB2YWx1ZSxcbiAgY2hpbGRyZW5cbn0pIHtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFByb3BzQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiB2YWx1ZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgfSk7XG59XG5wcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBEZWZhdWx0UHJvcHNQcm92aWRlci5wcm9wVHlwZXMgLyogcmVtb3ZlLXByb3B0eXBlcyAqLyA9IHtcbiAgLy8g4pSM4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIFdhcm5pbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSQXG4gIC8vIOKUgiBUaGVzZSBQcm9wVHlwZXMgYXJlIGdlbmVyYXRlZCBmcm9tIHRoZSBUeXBlU2NyaXB0IHR5cGUgZGVmaW5pdGlvbnMuIOKUglxuICAvLyDilIIgVG8gdXBkYXRlIHRoZW0sIGVkaXQgdGhlIFR5cGVTY3JpcHQgdHlwZXMgYW5kIHJ1biBgcG5wbSBwcm9wdHlwZXNgLiDilIJcbiAgLy8g4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYXG4gIC8qKlxuICAgKiBAaWdub3JlXG4gICAqL1xuICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGUsXG4gIC8qKlxuICAgKiBAaWdub3JlXG4gICAqL1xuICB2YWx1ZTogUHJvcFR5cGVzLm9iamVjdFxufSA6IHZvaWQgMDtcbmZ1bmN0aW9uIGdldFRoZW1lUHJvcHMocGFyYW1zKSB7XG4gIGNvbnN0IHtcbiAgICB0aGVtZSxcbiAgICBuYW1lLFxuICAgIHByb3BzXG4gIH0gPSBwYXJhbXM7XG4gIGlmICghdGhlbWUgfHwgIXRoZW1lLmNvbXBvbmVudHMgfHwgIXRoZW1lLmNvbXBvbmVudHNbbmFtZV0pIHtcbiAgICByZXR1cm4gcHJvcHM7XG4gIH1cbiAgY29uc3QgY29uZmlnID0gdGhlbWUuY29tcG9uZW50c1tuYW1lXTtcbiAgaWYgKGNvbmZpZy5kZWZhdWx0UHJvcHMpIHtcbiAgICAvLyBjb21wYXRpYmxlIHdpdGggdjUgc2lnbmF0dXJlXG4gICAgcmV0dXJuIHJlc29sdmVQcm9wcyhjb25maWcuZGVmYXVsdFByb3BzLCBwcm9wcywgdGhlbWUuY29tcG9uZW50cy5tZXJnZUNsYXNzTmFtZUFuZFN0eWxlKTtcbiAgfVxuICBpZiAoIWNvbmZpZy5zdHlsZU92ZXJyaWRlcyAmJiAhY29uZmlnLnZhcmlhbnRzKSB7XG4gICAgLy8gdjYgc2lnbmF0dXJlLCBubyBwcm9wZXJ0eSAnZGVmYXVsdFByb3BzJ1xuICAgIHJldHVybiByZXNvbHZlUHJvcHMoY29uZmlnLCBwcm9wcywgdGhlbWUuY29tcG9uZW50cy5tZXJnZUNsYXNzTmFtZUFuZFN0eWxlKTtcbiAgfVxuICByZXR1cm4gcHJvcHM7XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlRGVmYXVsdFByb3BzKHtcbiAgcHJvcHMsXG4gIG5hbWVcbn0pIHtcbiAgY29uc3QgY3R4ID0gUmVhY3QudXNlQ29udGV4dChQcm9wc0NvbnRleHQpO1xuICByZXR1cm4gZ2V0VGhlbWVQcm9wcyh7XG4gICAgcHJvcHMsXG4gICAgbmFtZSxcbiAgICB0aGVtZToge1xuICAgICAgY29tcG9uZW50czogY3R4XG4gICAgfVxuICB9KTtcbn1cbmV4cG9ydCBkZWZhdWx0IERlZmF1bHRQcm9wc1Byb3ZpZGVyOyIsImltcG9ydCBwcmVwcm9jZXNzU3R5bGVzIGZyb20gXCIuL3ByZXByb2Nlc3NTdHlsZXMubWpzXCI7XG5cbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uYW1pbmctY29udmVudGlvbiAqL1xuXG4vLyBXZSBuZWVkIHRvIHBhc3MgYW4gYXJndW1lbnQgYXMgYHsgdGhlbWUgfWAgZm9yIFBpZ21lbnRDU1MsIGJ1dCB3ZSBkb24ndCB3YW50IHRvXG4vLyBhbGxvY2F0ZSBtb3JlIG9iamVjdHMuXG5jb25zdCBhcmcgPSB7XG4gIHRoZW1lOiB1bmRlZmluZWRcbn07XG5cbi8qKlxuICogTWVtb2l6ZSBzdHlsZSBmdW5jdGlvbiBvbiB0aGVtZS5cbiAqIEludGVuZGVkIHRvIGJlIHVzZWQgaW4gc3R5bGVkKCkgY2FsbHMgdGhhdCBvbmx5IG5lZWQgYWNjZXNzIHRvIHRoZSB0aGVtZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdW5zdGFibGVfbWVtb1RoZW1lKHN0eWxlRm4pIHtcbiAgbGV0IGxhc3RWYWx1ZTtcbiAgbGV0IGxhc3RUaGVtZTtcbiAgcmV0dXJuIGZ1bmN0aW9uIHN0eWxlTWVtb2l6ZWQocHJvcHMpIHtcbiAgICBsZXQgdmFsdWUgPSBsYXN0VmFsdWU7XG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgcHJvcHMudGhlbWUgIT09IGxhc3RUaGVtZSkge1xuICAgICAgYXJnLnRoZW1lID0gcHJvcHMudGhlbWU7XG4gICAgICB2YWx1ZSA9IHByZXByb2Nlc3NTdHlsZXMoc3R5bGVGbihhcmcpKTtcbiAgICAgIGxhc3RWYWx1ZSA9IHZhbHVlO1xuICAgICAgbGFzdFRoZW1lID0gcHJvcHMudGhlbWU7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcbn0iLCIvKipcbiAqIFRoZSBiZW5lZml0IG9mIHRoaXMgZnVuY3Rpb24gaXMgdG8gaGVscCBkZXZlbG9wZXJzIGdldCBDU1MgdmFyIGZyb20gdGhlbWUgd2l0aG91dCBzcGVjaWZ5aW5nIHRoZSB3aG9sZSB2YXJpYWJsZVxuICogYW5kIHRoZXkgZG9lcyBub3QgbmVlZCB0byByZW1lbWJlciB0aGUgcHJlZml4IChkZWZpbmVkIG9uY2UpLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjcmVhdGVHZXRDc3NWYXIocHJlZml4ID0gJycpIHtcbiAgZnVuY3Rpb24gYXBwZW5kVmFyKC4uLnZhcnMpIHtcbiAgICBpZiAoIXZhcnMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlID0gdmFyc1swXTtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiAhdmFsdWUubWF0Y2goLygjfFxcKHxcXCl8KC0/KFxcZCpcXC4pP1xcZCspKHB4fGVtfCV8ZXh8Y2h8cmVtfHZ3fHZofHZtaW58dm1heHxjbXxtbXxpbnxwdHxwYykpfF4oLT8oXFxkKlxcLik/XFxkKykkfChcXGQrIFxcZCsgXFxkKykvKSkge1xuICAgICAgcmV0dXJuIGAsIHZhcigtLSR7cHJlZml4ID8gYCR7cHJlZml4fS1gIDogJyd9JHt2YWx1ZX0ke2FwcGVuZFZhciguLi52YXJzLnNsaWNlKDEpKX0pYDtcbiAgICB9XG4gICAgcmV0dXJuIGAsICR7dmFsdWV9YDtcbiAgfVxuXG4gIC8vIEFkZGl0aW9uYWxWYXJzIG1ha2VzIGBnZXRDc3NWYXJgIGxlc3Mgc3RyaWN0LCBzbyBpdCBjYW4gYmUgdXNlIGxpa2UgdGhpcyBgZ2V0Q3NzVmFyKCdub24tbXVpLXZhcmlhYmxlJylgIHdpdGhvdXQgdHlwZSBlcnJvci5cbiAgY29uc3QgZ2V0Q3NzVmFyID0gKGZpZWxkLCAuLi5mYWxsYmFja3MpID0+IHtcbiAgICByZXR1cm4gYHZhcigtLSR7cHJlZml4ID8gYCR7cHJlZml4fS1gIDogJyd9JHtmaWVsZH0ke2FwcGVuZFZhciguLi5mYWxsYmFja3MpfSlgO1xuICB9O1xuICByZXR1cm4gZ2V0Q3NzVmFyO1xufSIsImNvbnN0IHByb3RvdHlwZVBvbGx1dGluZ0tleXMgPSBuZXcgU2V0KFsnX19wcm90b19fJywgJ2NvbnN0cnVjdG9yJywgJ3Byb3RvdHlwZSddKTtcblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGNyZWF0ZSBhbiBvYmplY3QgZnJvbSBrZXlzLCB2YWx1ZSBhbmQgdGhlbiBhc3NpZ24gdG8gdGFyZ2V0XG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iaiA6IHRoZSB0YXJnZXQgb2JqZWN0IHRvIGJlIGFzc2lnbmVkXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBrZXlzXG4gKiBAcGFyYW0ge3N0cmluZyB8IG51bWJlcn0gdmFsdWVcbiAqXG4gKiBAZXhhbXBsZVxuICogY29uc3Qgc291cmNlID0ge31cbiAqIGFzc2lnbk5lc3RlZEtleXMoc291cmNlLCBbJ3BhbGV0dGUnLCAncHJpbWFyeSddLCAndmFyKC0tcGFsZXR0ZS1wcmltYXJ5KScpXG4gKiBjb25zb2xlLmxvZyhzb3VyY2UpIC8vIHsgcGFsZXR0ZTogeyBwcmltYXJ5OiAndmFyKC0tcGFsZXR0ZS1wcmltYXJ5KScgfSB9XG4gKlxuICogQGV4YW1wbGVcbiAqIGNvbnN0IHNvdXJjZSA9IHsgcGFsZXR0ZTogeyBwcmltYXJ5OiAndmFyKC0tcGFsZXR0ZS1wcmltYXJ5KScgfSB9XG4gKiBhc3NpZ25OZXN0ZWRLZXlzKHNvdXJjZSwgWydwYWxldHRlJywgJ3NlY29uZGFyeSddLCAndmFyKC0tcGFsZXR0ZS1zZWNvbmRhcnkpJylcbiAqIGNvbnNvbGUubG9nKHNvdXJjZSkgLy8geyBwYWxldHRlOiB7IHByaW1hcnk6ICd2YXIoLS1wYWxldHRlLXByaW1hcnkpJywgc2Vjb25kYXJ5OiAndmFyKC0tcGFsZXR0ZS1zZWNvbmRhcnkpJyB9IH1cbiAqL1xuZXhwb3J0IGNvbnN0IGFzc2lnbk5lc3RlZEtleXMgPSAob2JqLCBrZXlzLCB2YWx1ZSwgYXJyYXlLZXlzID0gW10pID0+IHtcbiAgbGV0IHRlbXAgPSBvYmo7XG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBrZXlzLmxlbmd0aDsgaW5kZXggKz0gMSkge1xuICAgIGNvbnN0IGsgPSBrZXlzW2luZGV4XTtcbiAgICAvLyBQcmV2ZW50IHByb3RvdHlwZSBwb2xsdXRpb246IG5ldmVyIHRyYXZlcnNlIG9yIHdyaXRlIHRocm91Z2hcbiAgICAvLyBgX19wcm90b19fYCAvIGBjb25zdHJ1Y3RvcmAgLyBgcHJvdG90eXBlYCAoZS5nLiBhIHRoZW1lIHBhcnNlZCBmcm9tIHVudHJ1c3RlZCBKU09OKS5cbiAgICBpZiAocHJvdG90eXBlUG9sbHV0aW5nS2V5cy5oYXMoaykpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBpZiAoaW5kZXggPT09IGtleXMubGVuZ3RoIC0gMSkge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkodGVtcCkpIHtcbiAgICAgICAgdGVtcFtOdW1iZXIoayldID0gdmFsdWU7XG4gICAgICB9IGVsc2UgaWYgKHRlbXAgJiYgdHlwZW9mIHRlbXAgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIHRlbXBba10gPSB2YWx1ZTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHRlbXAgJiYgdHlwZW9mIHRlbXAgPT09ICdvYmplY3QnKSB7XG4gICAgICBpZiAoIXRlbXBba10pIHtcbiAgICAgICAgdGVtcFtrXSA9IGFycmF5S2V5cy5pbmNsdWRlcyhrKSA/IFtdIDoge307XG4gICAgICB9XG4gICAgICB0ZW1wID0gdGVtcFtrXTtcbiAgICB9XG4gIH1cbn07XG5cbi8qKlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogOiBzb3VyY2Ugb2JqZWN0XG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayA6IGEgZnVuY3Rpb24gdGhhdCB3aWxsIGJlIGNhbGxlZCB3aGVuXG4gKiAgICAgICAgICAgICAgICAgICAtIHRoZSBkZWVwZXN0IGtleSBpbiBzb3VyY2Ugb2JqZWN0IGlzIHJlYWNoZWRcbiAqICAgICAgICAgICAgICAgICAgIC0gdGhlIHZhbHVlIG9mIHRoZSBkZWVwZXN0IGtleSBpcyBOT1QgYHVuZGVmaW5lZGAgfCBgbnVsbGBcbiAqXG4gKiBAZXhhbXBsZVxuICogd2Fsa09iamVjdERlZXAoeyBwYWxldHRlOiB7IHByaW1hcnk6IHsgbWFpbjogJyMwMDAwMDAnIH0gfSB9LCBjb25zb2xlLmxvZylcbiAqIC8vIFsncGFsZXR0ZScsICdwcmltYXJ5JywgJ21haW4nXSAnIzAwMDAwMCdcbiAqL1xuZXhwb3J0IGNvbnN0IHdhbGtPYmplY3REZWVwID0gKG9iaiwgY2FsbGJhY2ssIHNob3VsZFNraXBQYXRocykgPT4ge1xuICBmdW5jdGlvbiByZWN1cnNlKG9iamVjdCwgcGFyZW50S2V5cyA9IFtdLCBhcnJheUtleXMgPSBbXSkge1xuICAgIE9iamVjdC5lbnRyaWVzKG9iamVjdCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICBpZiAoIXNob3VsZFNraXBQYXRocyB8fCBzaG91bGRTa2lwUGF0aHMgJiYgIXNob3VsZFNraXBQYXRocyhbLi4ucGFyZW50S2V5cywga2V5XSkpIHtcbiAgICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IG51bGwpIHtcbiAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiBPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgcmVjdXJzZSh2YWx1ZSwgWy4uLnBhcmVudEtleXMsIGtleV0sIEFycmF5LmlzQXJyYXkodmFsdWUpID8gWy4uLmFycmF5S2V5cywga2V5XSA6IGFycmF5S2V5cyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKFsuLi5wYXJlbnRLZXlzLCBrZXldLCB2YWx1ZSwgYXJyYXlLZXlzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZWN1cnNlKG9iaik7XG59O1xuY29uc3QgZ2V0Q3NzVmFsdWUgPSAoa2V5cywgdmFsdWUpID0+IHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcbiAgICBpZiAoWydsaW5lSGVpZ2h0JywgJ2ZvbnRXZWlnaHQnLCAnb3BhY2l0eScsICd6SW5kZXgnXS5zb21lKHByb3AgPT4ga2V5cy5pbmNsdWRlcyhwcm9wKSkpIHtcbiAgICAgIC8vIENTUyBwcm9wZXJ0eSB0aGF0IGFyZSB1bml0bGVzc1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBjb25zdCBsYXN0S2V5ID0ga2V5c1trZXlzLmxlbmd0aCAtIDFdO1xuICAgIGlmIChsYXN0S2V5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ29wYWNpdHknKSkge1xuICAgICAgLy8gb3BhY2l0eSB2YWx1ZXMgYXJlIHVuaXRsZXNzXG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBgJHt2YWx1ZX1weGA7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufTtcblxuLyoqXG4gKiBhIGZ1bmN0aW9uIHRoYXQgcGFyc2UgdGhlbWUgYW5kIHJldHVybiB7IGNzcywgdmFycyB9XG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHRoZW1lXG4gKiBAcGFyYW0ge3tcbiAqICBwcmVmaXg/OiBzdHJpbmcsXG4gKiAgc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXI/OiAob2JqZWN0UGF0aEtleXM6IEFycmF5PHN0cmluZz4sIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IGJvb2xlYW5cbiAqIH19IG9wdGlvbnMuXG4gKiAgYHByZWZpeGA6IFRoZSBwcmVmaXggb2YgdGhlIGdlbmVyYXRlZCBDU1MgdmFyaWFibGVzLiBUaGlzIGZ1bmN0aW9uIGRvZXMgbm90IGNoYW5nZSB0aGUgdmFsdWUuXG4gKlxuICogQHJldHVybnMge3sgY3NzOiBPYmplY3QsIHZhcnM6IE9iamVjdCB9fSBgY3NzYCBpcyB0aGUgc3R5bGVzaGVldCwgYHZhcnNgIGlzIGFuIG9iamVjdCB0byBnZXQgY3NzIHZhcmlhYmxlIChzYW1lIHN0cnVjdHVyZSBhcyB0aGVtZSkuXG4gKlxuICogQGV4YW1wbGVcbiAqIGNvbnN0IHsgY3NzLCB2YXJzIH0gPSBwYXJzZXIoe1xuICogICBmb250U2l6ZTogMTIsXG4gKiAgIGxpbmVIZWlnaHQ6IDEuMixcbiAqICAgcGFsZXR0ZTogeyBwcmltYXJ5OiB7IDUwMDogJ3ZhcigtLWNvbG9yKScgfSB9XG4gKiB9LCB7IHByZWZpeDogJ2ZvbycgfSlcbiAqXG4gKiBjb25zb2xlLmxvZyhjc3MpIC8vIHsgJy0tZm9vLWZvbnRTaXplJzogJzEycHgnLCAnLS1mb28tbGluZUhlaWdodCc6IDEuMiwgJy0tZm9vLXBhbGV0dGUtcHJpbWFyeS01MDAnOiAndmFyKC0tY29sb3IpJyB9XG4gKiBjb25zb2xlLmxvZyh2YXJzKSAvLyB7IGZvbnRTaXplOiAndmFyKC0tZm9vLWZvbnRTaXplKScsIGxpbmVIZWlnaHQ6ICd2YXIoLS1mb28tbGluZUhlaWdodCknLCBwYWxldHRlOiB7IHByaW1hcnk6IHsgNTAwOiAndmFyKC0tZm9vLXBhbGV0dGUtcHJpbWFyeS01MDApJyB9IH0gfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjc3NWYXJzUGFyc2VyKHRoZW1lLCBvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBwcmVmaXgsXG4gICAgc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXJcbiAgfSA9IG9wdGlvbnMgfHwge307XG4gIGNvbnN0IGNzcyA9IHt9O1xuICBjb25zdCB2YXJzID0ge307XG4gIGNvbnN0IHZhcnNXaXRoRGVmYXVsdHMgPSB7fTtcbiAgd2Fsa09iamVjdERlZXAodGhlbWUsIChrZXlzLCB2YWx1ZSwgYXJyYXlLZXlzKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgICAgaWYgKCFzaG91bGRTa2lwR2VuZXJhdGluZ1ZhciB8fCAhc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXIoa2V5cywgdmFsdWUpKSB7XG4gICAgICAgIC8vIG9ubHkgY3JlYXRlIGNzcyAmIHZhciBpZiBgc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXJgIHJldHVybiBmYWxzZVxuICAgICAgICBjb25zdCBjc3NWYXIgPSBgLS0ke3ByZWZpeCA/IGAke3ByZWZpeH0tYCA6ICcnfSR7a2V5cy5qb2luKCctJyl9YDtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWRWYWx1ZSA9IGdldENzc1ZhbHVlKGtleXMsIHZhbHVlKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihjc3MsIHtcbiAgICAgICAgICBbY3NzVmFyXTogcmVzb2x2ZWRWYWx1ZVxuICAgICAgICB9KTtcbiAgICAgICAgYXNzaWduTmVzdGVkS2V5cyh2YXJzLCBrZXlzLCBgdmFyKCR7Y3NzVmFyfSlgLCBhcnJheUtleXMpO1xuICAgICAgICBhc3NpZ25OZXN0ZWRLZXlzKHZhcnNXaXRoRGVmYXVsdHMsIGtleXMsIGB2YXIoJHtjc3NWYXJ9LCAke3Jlc29sdmVkVmFsdWV9KWAsIGFycmF5S2V5cyk7XG4gICAgICB9XG4gICAgfVxuICB9LCBrZXlzID0+IGtleXNbMF0gPT09ICd2YXJzJyAvLyBza2lwICd2YXJzLyonIHBhdGhzXG4gICk7XG4gIHJldHVybiB7XG4gICAgY3NzLFxuICAgIHZhcnMsXG4gICAgdmFyc1dpdGhEZWZhdWx0c1xuICB9O1xufSIsImltcG9ydCBkZWVwbWVyZ2UgZnJvbSAnQG11aS91dGlscy9kZWVwbWVyZ2UnO1xuaW1wb3J0IGNzc1ZhcnNQYXJzZXIgZnJvbSBcIi4vY3NzVmFyc1BhcnNlci5tanNcIjtcbmZ1bmN0aW9uIHByZXBhcmVDc3NWYXJzKHRoZW1lLCBwYXJzZXJDb25maWcgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZ2V0U2VsZWN0b3IgPSBkZWZhdWx0R2V0U2VsZWN0b3IsXG4gICAgZGlzYWJsZUNzc0NvbG9yU2NoZW1lLFxuICAgIGNvbG9yU2NoZW1lU2VsZWN0b3I6IHNlbGVjdG9yLFxuICAgIGVuYWJsZUNvbnRyYXN0VmFyc1xuICB9ID0gcGFyc2VyQ29uZmlnO1xuICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gaWdub3JlIGNvbXBvbmVudHMgZG8gbm90IGV4aXN0XG4gIGNvbnN0IHtcbiAgICBjb2xvclNjaGVtZXMgPSB7fSxcbiAgICBjb21wb25lbnRzLFxuICAgIGRlZmF1bHRDb2xvclNjaGVtZSA9ICdsaWdodCcsXG4gICAgLi4ub3RoZXJUaGVtZVxuICB9ID0gdGhlbWU7XG4gIGNvbnN0IHtcbiAgICB2YXJzOiByb290VmFycyxcbiAgICBjc3M6IHJvb3RDc3MsXG4gICAgdmFyc1dpdGhEZWZhdWx0czogcm9vdFZhcnNXaXRoRGVmYXVsdHNcbiAgfSA9IGNzc1ZhcnNQYXJzZXIob3RoZXJUaGVtZSwgcGFyc2VyQ29uZmlnKTtcbiAgbGV0IHRoZW1lVmFycyA9IHJvb3RWYXJzV2l0aERlZmF1bHRzO1xuICBjb25zdCBjb2xvclNjaGVtZXNNYXAgPSB7fTtcbiAgY29uc3Qge1xuICAgIFtkZWZhdWx0Q29sb3JTY2hlbWVdOiBkZWZhdWx0U2NoZW1lLFxuICAgIC4uLm90aGVyQ29sb3JTY2hlbWVzXG4gIH0gPSBjb2xvclNjaGVtZXM7XG4gIE9iamVjdC5lbnRyaWVzKG90aGVyQ29sb3JTY2hlbWVzIHx8IHt9KS5mb3JFYWNoKChba2V5LCBzY2hlbWVdKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgdmFycyxcbiAgICAgIGNzcyxcbiAgICAgIHZhcnNXaXRoRGVmYXVsdHNcbiAgICB9ID0gY3NzVmFyc1BhcnNlcihzY2hlbWUsIHBhcnNlckNvbmZpZyk7XG4gICAgdGhlbWVWYXJzID0gZGVlcG1lcmdlKHRoZW1lVmFycywgdmFyc1dpdGhEZWZhdWx0cyk7XG4gICAgY29sb3JTY2hlbWVzTWFwW2tleV0gPSB7XG4gICAgICBjc3MsXG4gICAgICB2YXJzXG4gICAgfTtcbiAgfSk7XG4gIGlmIChkZWZhdWx0U2NoZW1lKSB7XG4gICAgLy8gZGVmYXVsdCBjb2xvciBzY2hlbWUgdmFycyBzaG91bGQgYmUgbWVyZ2VkIGxhc3QgdG8gc2V0IGFzIGRlZmF1bHRcbiAgICBjb25zdCB7XG4gICAgICBjc3MsXG4gICAgICB2YXJzLFxuICAgICAgdmFyc1dpdGhEZWZhdWx0c1xuICAgIH0gPSBjc3NWYXJzUGFyc2VyKGRlZmF1bHRTY2hlbWUsIHBhcnNlckNvbmZpZyk7XG4gICAgdGhlbWVWYXJzID0gZGVlcG1lcmdlKHRoZW1lVmFycywgdmFyc1dpdGhEZWZhdWx0cyk7XG4gICAgY29sb3JTY2hlbWVzTWFwW2RlZmF1bHRDb2xvclNjaGVtZV0gPSB7XG4gICAgICBjc3MsXG4gICAgICB2YXJzXG4gICAgfTtcbiAgfVxuICBmdW5jdGlvbiBkZWZhdWx0R2V0U2VsZWN0b3IoY29sb3JTY2hlbWUsIGNzc09iamVjdCkge1xuICAgIGxldCBydWxlID0gc2VsZWN0b3I7XG4gICAgaWYgKHNlbGVjdG9yID09PSAnY2xhc3MnKSB7XG4gICAgICBydWxlID0gJy4lcyc7XG4gICAgfVxuICAgIGlmIChzZWxlY3RvciA9PT0gJ2RhdGEnKSB7XG4gICAgICBydWxlID0gJ1tkYXRhLSVzXSc7XG4gICAgfVxuICAgIGlmIChzZWxlY3Rvcj8uc3RhcnRzV2l0aCgnZGF0YS0nKSAmJiAhc2VsZWN0b3IuaW5jbHVkZXMoJyVzJykpIHtcbiAgICAgIC8vICdkYXRhLWpveS1jb2xvci1zY2hlbWUnIC0+ICdbZGF0YS1qb3ktY29sb3Itc2NoZW1lPVwiJXNcIl0nXG4gICAgICBydWxlID0gYFske3NlbGVjdG9yfT1cIiVzXCJdYDtcbiAgICB9XG4gICAgaWYgKGNvbG9yU2NoZW1lKSB7XG4gICAgICBpZiAocnVsZSA9PT0gJ21lZGlhJykge1xuICAgICAgICBpZiAodGhlbWUuZGVmYXVsdENvbG9yU2NoZW1lID09PSBjb2xvclNjaGVtZSkge1xuICAgICAgICAgIHJldHVybiAnOnJvb3QnO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1vZGUgPSBjb2xvclNjaGVtZXNbY29sb3JTY2hlbWVdPy5wYWxldHRlPy5tb2RlIHx8IGNvbG9yU2NoZW1lO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIFtgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogJHttb2RlfSlgXToge1xuICAgICAgICAgICAgJzpyb290JzogY3NzT2JqZWN0XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKHJ1bGUpIHtcbiAgICAgICAgaWYgKHRoZW1lLmRlZmF1bHRDb2xvclNjaGVtZSA9PT0gY29sb3JTY2hlbWUpIHtcbiAgICAgICAgICByZXR1cm4gYDpyb290LCAke3J1bGUucmVwbGFjZSgnJXMnLCBTdHJpbmcoY29sb3JTY2hlbWUpKX1gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBydWxlLnJlcGxhY2UoJyVzJywgU3RyaW5nKGNvbG9yU2NoZW1lKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAnOnJvb3QnO1xuICB9XG4gIGNvbnN0IGdlbmVyYXRlVGhlbWVWYXJzID0gKCkgPT4ge1xuICAgIGxldCB2YXJzID0ge1xuICAgICAgLi4ucm9vdFZhcnNcbiAgICB9O1xuICAgIE9iamVjdC5lbnRyaWVzKGNvbG9yU2NoZW1lc01hcCkuZm9yRWFjaCgoWywge1xuICAgICAgdmFyczogc2NoZW1lVmFyc1xuICAgIH1dKSA9PiB7XG4gICAgICB2YXJzID0gZGVlcG1lcmdlKHZhcnMsIHNjaGVtZVZhcnMpO1xuICAgIH0pO1xuICAgIHJldHVybiB2YXJzO1xuICB9O1xuICBjb25zdCBnZW5lcmF0ZVN0eWxlU2hlZXRzID0gKCkgPT4ge1xuICAgIGNvbnN0IHN0eWxlc2hlZXRzID0gW107XG4gICAgY29uc3QgY29sb3JTY2hlbWUgPSB0aGVtZS5kZWZhdWx0Q29sb3JTY2hlbWUgfHwgJ2xpZ2h0JztcbiAgICBmdW5jdGlvbiBpbnNlcnRTdHlsZVNoZWV0KGtleSwgY3NzKSB7XG4gICAgICBpZiAoT2JqZWN0LmtleXMoY3NzKS5sZW5ndGgpIHtcbiAgICAgICAgc3R5bGVzaGVldHMucHVzaCh0eXBlb2Yga2V5ID09PSAnc3RyaW5nJyA/IHtcbiAgICAgICAgICBba2V5XToge1xuICAgICAgICAgICAgLi4uY3NzXG4gICAgICAgICAgfVxuICAgICAgICB9IDoga2V5KTtcbiAgICAgIH1cbiAgICB9XG4gICAgaW5zZXJ0U3R5bGVTaGVldChnZXRTZWxlY3Rvcih1bmRlZmluZWQsIHtcbiAgICAgIC4uLnJvb3RDc3NcbiAgICB9KSwgcm9vdENzcyk7XG4gICAgY29uc3Qge1xuICAgICAgW2NvbG9yU2NoZW1lXTogZGVmYXVsdFNjaGVtZVZhbCxcbiAgICAgIC4uLm90aGVyXG4gICAgfSA9IGNvbG9yU2NoZW1lc01hcDtcbiAgICBpZiAoZGVmYXVsdFNjaGVtZVZhbCkge1xuICAgICAgLy8gZGVmYXVsdCBjb2xvciBzY2hlbWUgaGFzIHRvIGNvbWUgYmVmb3JlIG90aGVyIGNvbG9yIHNjaGVtZXNcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgY3NzXG4gICAgICB9ID0gZGVmYXVsdFNjaGVtZVZhbDtcbiAgICAgIGNvbnN0IGNzc0NvbG9yU2hlbWUgPSBjb2xvclNjaGVtZXNbY29sb3JTY2hlbWVdPy5wYWxldHRlPy5tb2RlO1xuICAgICAgY29uc3QgZmluYWxDc3MgPSAhZGlzYWJsZUNzc0NvbG9yU2NoZW1lICYmIGNzc0NvbG9yU2hlbWUgPyB7XG4gICAgICAgIGNvbG9yU2NoZW1lOiBjc3NDb2xvclNoZW1lLFxuICAgICAgICAuLi5jc3NcbiAgICAgIH0gOiB7XG4gICAgICAgIC4uLmNzc1xuICAgICAgfTtcbiAgICAgIGluc2VydFN0eWxlU2hlZXQoZ2V0U2VsZWN0b3IoY29sb3JTY2hlbWUsIHtcbiAgICAgICAgLi4uZmluYWxDc3NcbiAgICAgIH0pLCBmaW5hbENzcyk7XG4gICAgfVxuICAgIE9iamVjdC5lbnRyaWVzKG90aGVyKS5mb3JFYWNoKChba2V5LCB7XG4gICAgICBjc3NcbiAgICB9XSkgPT4ge1xuICAgICAgY29uc3QgY3NzQ29sb3JTaGVtZSA9IGNvbG9yU2NoZW1lc1trZXldPy5wYWxldHRlPy5tb2RlO1xuICAgICAgY29uc3QgZmluYWxDc3MgPSAhZGlzYWJsZUNzc0NvbG9yU2NoZW1lICYmIGNzc0NvbG9yU2hlbWUgPyB7XG4gICAgICAgIGNvbG9yU2NoZW1lOiBjc3NDb2xvclNoZW1lLFxuICAgICAgICAuLi5jc3NcbiAgICAgIH0gOiB7XG4gICAgICAgIC4uLmNzc1xuICAgICAgfTtcbiAgICAgIGluc2VydFN0eWxlU2hlZXQoZ2V0U2VsZWN0b3Ioa2V5LCB7XG4gICAgICAgIC4uLmZpbmFsQ3NzXG4gICAgICB9KSwgZmluYWxDc3MpO1xuICAgIH0pO1xuICAgIGlmIChlbmFibGVDb250cmFzdFZhcnMpIHtcbiAgICAgIHN0eWxlc2hlZXRzLnB1c2goe1xuICAgICAgICAnOnJvb3QnOiB7XG4gICAgICAgICAgLy8gdXNlIGRvdWJsZSB1bmRlcnNjb3JlIHRvIGluZGljYXRlIHRoYXQgdGhlc2UgYXJlIHByaXZhdGUgdmFyaWFibGVzXG4gICAgICAgICAgJy0tX19sLXRocmVzaG9sZCc6ICcwLjcnLFxuICAgICAgICAgICctLV9fbCc6ICdjbGFtcCgwLCAobCAvIHZhcigtLV9fbC10aHJlc2hvbGQpIC0gMSkgKiAtaW5maW5pdHksIDEpJyxcbiAgICAgICAgICAnLS1fX2EnOiAnY2xhbXAoMC44NywgKGwgLyB2YXIoLS1fX2wtdGhyZXNob2xkKSAtIDEpICogLWluZmluaXR5LCAxKScgLy8gMC44NyBpcyB0aGUgZGVmYXVsdCBhbHBoYSB2YWx1ZSBmb3IgYmxhY2sgdGV4dC5cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBzdHlsZXNoZWV0cztcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICB2YXJzOiB0aGVtZVZhcnMsXG4gICAgZ2VuZXJhdGVUaGVtZVZhcnMsXG4gICAgZ2VuZXJhdGVTdHlsZVNoZWV0c1xuICB9O1xufVxuZXhwb3J0IGRlZmF1bHQgcHJlcGFyZUNzc1ZhcnM7IiwiLyogZXNsaW50LWRpc2FibGUgaW1wb3J0L3ByZWZlci1kZWZhdWx0LWV4cG9ydCAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUdldENvbG9yU2NoZW1lU2VsZWN0b3Ioc2VsZWN0b3IpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGdldENvbG9yU2NoZW1lU2VsZWN0b3IoY29sb3JTY2hlbWUpIHtcbiAgICBpZiAoc2VsZWN0b3IgPT09ICdtZWRpYScpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGlmIChjb2xvclNjaGVtZSAhPT0gJ2xpZ2h0JyAmJiBjb2xvclNjaGVtZSAhPT0gJ2RhcmsnKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgTVVJOiBAbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lKSBzdXBwb3J0cyBvbmx5ICdsaWdodCcgb3IgJ2RhcmsnLCBidXQgcmVjZWl2ZSAnJHtjb2xvclNjaGVtZX0nLmApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gYEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6ICR7Y29sb3JTY2hlbWV9KWA7XG4gICAgfVxuICAgIGlmIChzZWxlY3Rvcikge1xuICAgICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoJ2RhdGEtJykgJiYgIXNlbGVjdG9yLmluY2x1ZGVzKCclcycpKSB7XG4gICAgICAgIHJldHVybiBgWyR7c2VsZWN0b3J9PVwiJHtjb2xvclNjaGVtZX1cIl0gJmA7XG4gICAgICB9XG4gICAgICBpZiAoc2VsZWN0b3IgPT09ICdjbGFzcycpIHtcbiAgICAgICAgcmV0dXJuIGAuJHtjb2xvclNjaGVtZX0gJmA7XG4gICAgICB9XG4gICAgICBpZiAoc2VsZWN0b3IgPT09ICdkYXRhJykge1xuICAgICAgICByZXR1cm4gYFtkYXRhLSR7Y29sb3JTY2hlbWV9XSAmYDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBgJHtzZWxlY3Rvci5yZXBsYWNlKCclcycsIGNvbG9yU2NoZW1lKX0gJmA7XG4gICAgfVxuICAgIHJldHVybiAnJic7XG4gIH07XG59IiwiLyoqXG4gKiBAbXVpL3N5c3RlbSB2OS4zLjBcbiAqXG4gKiBAbGljZW5zZSBNSVRcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQG11aS91dGlscy9mb3JtYXRNdWlFcnJvck1lc3NhZ2VcIjtcbmV4cG9ydCB7IGNzcywga2V5ZnJhbWVzLCBTdHlsZWRFbmdpbmVQcm92aWRlciB9IGZyb20gJ0BtdWkvc3R5bGVkLWVuZ2luZSc7XG5leHBvcnQgeyBkZWZhdWx0IGFzIEdsb2JhbFN0eWxlcyB9IGZyb20gXCIuL0dsb2JhbFN0eWxlcy9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgYm9yZGVycyB9IGZyb20gXCIuL2JvcmRlcnMvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9ib3JkZXJzL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBicmVha3BvaW50cyB9IGZyb20gXCIuL2JyZWFrcG9pbnRzL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBjc3NDb250YWluZXJRdWVyaWVzIH0gZnJvbSBcIi4vY3NzQ29udGFpbmVyUXVlcmllcy9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGhhbmRsZUJyZWFrcG9pbnRzLCBtZXJnZUJyZWFrcG9pbnRzSW5PcmRlciwgcmVzb2x2ZUJyZWFrcG9pbnRWYWx1ZXMgYXMgdW5zdGFibGVfcmVzb2x2ZUJyZWFrcG9pbnRWYWx1ZXMgfSBmcm9tIFwiLi9icmVha3BvaW50cy9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgY29tcG9zZSB9IGZyb20gXCIuL2NvbXBvc2UvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIGRpc3BsYXkgfSBmcm9tIFwiLi9kaXNwbGF5L2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBmbGV4Ym94IH0gZnJvbSBcIi4vZmxleGJveC9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2ZsZXhib3gvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIGdyaWQgfSBmcm9tIFwiLi9jc3NHcmlkL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vY3NzR3JpZC9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgcGFsZXR0ZSB9IGZyb20gXCIuL3BhbGV0dGUvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9wYWxldHRlL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBwb3NpdGlvbnMgfSBmcm9tIFwiLi9wb3NpdGlvbnMvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9wb3NpdGlvbnMvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHNoYWRvd3MgfSBmcm9tIFwiLi9zaGFkb3dzL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBzaXppbmcgfSBmcm9tIFwiLi9zaXppbmcvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9zaXppbmcvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHNwYWNpbmcgfSBmcm9tIFwiLi9zcGFjaW5nL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vc3BhY2luZy9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgc3R5bGUsIGdldFBhdGgsIGdldFN0eWxlVmFsdWUgfSBmcm9tIFwiLi9zdHlsZS9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdHlwb2dyYXBoeSB9IGZyb20gXCIuL3R5cG9ncmFwaHkvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi90eXBvZ3JhcGh5L2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyB1bnN0YWJsZV9zdHlsZUZ1bmN0aW9uU3gsIHVuc3RhYmxlX2NyZWF0ZVN0eWxlRnVuY3Rpb25TeCwgZXh0ZW5kU3hQcm9wIGFzIHVuc3RhYmxlX2V4dGVuZFN4UHJvcCwgdW5zdGFibGVfZGVmYXVsdFN4Q29uZmlnIH0gZnJvbSBcIi4vc3R5bGVGdW5jdGlvblN4L2luZGV4Lm1qc1wiO1xuLy8gVE9ETzogUmVtb3ZlIHRoaXMgZnVuY3Rpb24gaW4gdjZcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbmFtaW5nLWNvbnZlbnRpb25cbmV4cG9ydCBmdW5jdGlvbiBleHBlcmltZW50YWxfc3goKSB7XG4gIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnTVVJOiBUaGUgYGV4cGVyaW1lbnRhbF9zeGAgaGFzIGJlZW4gbW92ZWQgdG8gYHRoZW1lLnVuc3RhYmxlX3N4YC4nICsgJ0ZvciBtb3JlIGRldGFpbHMsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXVpL21hdGVyaWFsLXVpL3B1bGwvMzUxNTAuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTkpKTtcbn1cbmV4cG9ydCB7IGRlZmF1bHQgYXMgdW5zdGFibGVfZ2V0VGhlbWVWYWx1ZSB9IGZyb20gXCIuL2dldFRoZW1lVmFsdWUvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIEJveCB9IGZyb20gXCIuL0JveC9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL0JveC9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgY3JlYXRlQm94IH0gZnJvbSBcIi4vY3JlYXRlQm94L2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBjcmVhdGVTdHlsZWQgfSBmcm9tIFwiLi9jcmVhdGVTdHlsZWQvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9jcmVhdGVTdHlsZWQvaW5kZXgubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHN0eWxlZCB9IGZyb20gXCIuL3N0eWxlZC9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgY3JlYXRlVGhlbWUgfSBmcm9tIFwiLi9jcmVhdGVUaGVtZS9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgY3JlYXRlQnJlYWtwb2ludHMgfSBmcm9tIFwiLi9jcmVhdGVCcmVha3BvaW50cy9jcmVhdGVCcmVha3BvaW50cy5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgY3JlYXRlU3BhY2luZyB9IGZyb20gXCIuL2NyZWF0ZVRoZW1lL2NyZWF0ZVNwYWNpbmcubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHNoYXBlIH0gZnJvbSBcIi4vY3JlYXRlVGhlbWUvc2hhcGUubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHVzZVRoZW1lUHJvcHMsIGdldFRoZW1lUHJvcHMgfSBmcm9tIFwiLi91c2VUaGVtZVByb3BzL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyB1c2VUaGVtZSB9IGZyb20gXCIuL3VzZVRoZW1lL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyB1c2VUaGVtZVdpdGhvdXREZWZhdWx0IH0gZnJvbSBcIi4vdXNlVGhlbWVXaXRob3V0RGVmYXVsdC9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdXNlTWVkaWFRdWVyeSB9IGZyb20gXCIuL3VzZU1lZGlhUXVlcnkvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9jb2xvck1hbmlwdWxhdG9yL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBUaGVtZVByb3ZpZGVyIH0gZnJvbSBcIi4vVGhlbWVQcm92aWRlci9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdW5zdGFibGVfbWVtb1RoZW1lIH0gZnJvbSBcIi4vbWVtb1RoZW1lLm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyB1bnN0YWJsZV9jcmVhdGVDc3NWYXJzUHJvdmlkZXIgfSBmcm9tIFwiLi9jc3NWYXJzL2NyZWF0ZUNzc1ZhcnNQcm92aWRlci5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdW5zdGFibGVfY3JlYXRlR2V0Q3NzVmFyIH0gZnJvbSBcIi4vY3NzVmFycy9jcmVhdGVHZXRDc3NWYXIubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHVuc3RhYmxlX2Nzc1ZhcnNQYXJzZXIgfSBmcm9tIFwiLi9jc3NWYXJzL2Nzc1ZhcnNQYXJzZXIubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHVuc3RhYmxlX3ByZXBhcmVDc3NWYXJzIH0gZnJvbSBcIi4vY3NzVmFycy9wcmVwYXJlQ3NzVmFycy5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdW5zdGFibGVfY3JlYXRlQ3NzVmFyc1RoZW1lIH0gZnJvbSBcIi4vY3NzVmFycy9jcmVhdGVDc3NWYXJzVGhlbWUubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHJlc3BvbnNpdmVQcm9wVHlwZSB9IGZyb20gXCIuL3Jlc3BvbnNpdmVQcm9wVHlwZS9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgUnRsUHJvdmlkZXIgfSBmcm9tIFwiLi9SdGxQcm92aWRlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL1J0bFByb3ZpZGVyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vdmVyc2lvbi9pbmRleC5tanNcIjtcblxuLyoqIC0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiogTGF5b3V0IGNvbXBvbmVudHMgKi9cbmV4cG9ydCB7IGRlZmF1bHQgYXMgY3JlYXRlQ29udGFpbmVyIH0gZnJvbSBcIi4vQ29udGFpbmVyL2NyZWF0ZUNvbnRhaW5lci5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ29udGFpbmVyIH0gZnJvbSBcIi4vQ29udGFpbmVyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vQ29udGFpbmVyL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBHcmlkIH0gZnJvbSBcIi4vR3JpZC9HcmlkLm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vR3JpZC9pbmRleC5tanNcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgU3RhY2sgfSBmcm9tIFwiLi9TdGFjay9TdGFjay5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL1N0YWNrL2luZGV4Lm1qc1wiOyIsImNvbnN0IGNvbW1vbiA9IHtcbiAgYmxhY2s6ICcjMDAwJyxcbiAgd2hpdGU6ICcjZmZmJ1xufTtcbmV4cG9ydCBkZWZhdWx0IGNvbW1vbjsiLCJjb25zdCBncmV5ID0ge1xuICA1MDogJyNmYWZhZmEnLFxuICAxMDA6ICcjZjVmNWY1JyxcbiAgMjAwOiAnI2VlZWVlZScsXG4gIDMwMDogJyNlMGUwZTAnLFxuICA0MDA6ICcjYmRiZGJkJyxcbiAgNTAwOiAnIzllOWU5ZScsXG4gIDYwMDogJyM3NTc1NzUnLFxuICA3MDA6ICcjNjE2MTYxJyxcbiAgODAwOiAnIzQyNDI0MicsXG4gIDkwMDogJyMyMTIxMjEnLFxuICBBMTAwOiAnI2Y1ZjVmNScsXG4gIEEyMDA6ICcjZWVlZWVlJyxcbiAgQTQwMDogJyNiZGJkYmQnLFxuICBBNzAwOiAnIzYxNjE2MSdcbn07XG5leHBvcnQgZGVmYXVsdCBncmV5OyIsImNvbnN0IHB1cnBsZSA9IHtcbiAgNTA6ICcjZjNlNWY1JyxcbiAgMTAwOiAnI2UxYmVlNycsXG4gIDIwMDogJyNjZTkzZDgnLFxuICAzMDA6ICcjYmE2OGM4JyxcbiAgNDAwOiAnI2FiNDdiYycsXG4gIDUwMDogJyM5YzI3YjAnLFxuICA2MDA6ICcjOGUyNGFhJyxcbiAgNzAwOiAnIzdiMWZhMicsXG4gIDgwMDogJyM2YTFiOWEnLFxuICA5MDA6ICcjNGExNDhjJyxcbiAgQTEwMDogJyNlYTgwZmMnLFxuICBBMjAwOiAnI2UwNDBmYicsXG4gIEE0MDA6ICcjZDUwMGY5JyxcbiAgQTcwMDogJyNhYTAwZmYnXG59O1xuZXhwb3J0IGRlZmF1bHQgcHVycGxlOyIsImNvbnN0IHJlZCA9IHtcbiAgNTA6ICcjZmZlYmVlJyxcbiAgMTAwOiAnI2ZmY2RkMicsXG4gIDIwMDogJyNlZjlhOWEnLFxuICAzMDA6ICcjZTU3MzczJyxcbiAgNDAwOiAnI2VmNTM1MCcsXG4gIDUwMDogJyNmNDQzMzYnLFxuICA2MDA6ICcjZTUzOTM1JyxcbiAgNzAwOiAnI2QzMmYyZicsXG4gIDgwMDogJyNjNjI4MjgnLFxuICA5MDA6ICcjYjcxYzFjJyxcbiAgQTEwMDogJyNmZjhhODAnLFxuICBBMjAwOiAnI2ZmNTI1MicsXG4gIEE0MDA6ICcjZmYxNzQ0JyxcbiAgQTcwMDogJyNkNTAwMDAnXG59O1xuZXhwb3J0IGRlZmF1bHQgcmVkOyIsImNvbnN0IG9yYW5nZSA9IHtcbiAgNTA6ICcjZmZmM2UwJyxcbiAgMTAwOiAnI2ZmZTBiMicsXG4gIDIwMDogJyNmZmNjODAnLFxuICAzMDA6ICcjZmZiNzRkJyxcbiAgNDAwOiAnI2ZmYTcyNicsXG4gIDUwMDogJyNmZjk4MDAnLFxuICA2MDA6ICcjZmI4YzAwJyxcbiAgNzAwOiAnI2Y1N2MwMCcsXG4gIDgwMDogJyNlZjZjMDAnLFxuICA5MDA6ICcjZTY1MTAwJyxcbiAgQTEwMDogJyNmZmQxODAnLFxuICBBMjAwOiAnI2ZmYWI0MCcsXG4gIEE0MDA6ICcjZmY5MTAwJyxcbiAgQTcwMDogJyNmZjZkMDAnXG59O1xuZXhwb3J0IGRlZmF1bHQgb3JhbmdlOyIsImNvbnN0IGJsdWUgPSB7XG4gIDUwOiAnI2UzZjJmZCcsXG4gIDEwMDogJyNiYmRlZmInLFxuICAyMDA6ICcjOTBjYWY5JyxcbiAgMzAwOiAnIzY0YjVmNicsXG4gIDQwMDogJyM0MmE1ZjUnLFxuICA1MDA6ICcjMjE5NmYzJyxcbiAgNjAwOiAnIzFlODhlNScsXG4gIDcwMDogJyMxOTc2ZDInLFxuICA4MDA6ICcjMTU2NWMwJyxcbiAgOTAwOiAnIzBkNDdhMScsXG4gIEExMDA6ICcjODJiMWZmJyxcbiAgQTIwMDogJyM0NDhhZmYnLFxuICBBNDAwOiAnIzI5NzlmZicsXG4gIEE3MDA6ICcjMjk2MmZmJ1xufTtcbmV4cG9ydCBkZWZhdWx0IGJsdWU7IiwiY29uc3QgbGlnaHRCbHVlID0ge1xuICA1MDogJyNlMWY1ZmUnLFxuICAxMDA6ICcjYjNlNWZjJyxcbiAgMjAwOiAnIzgxZDRmYScsXG4gIDMwMDogJyM0ZmMzZjcnLFxuICA0MDA6ICcjMjliNmY2JyxcbiAgNTAwOiAnIzAzYTlmNCcsXG4gIDYwMDogJyMwMzliZTUnLFxuICA3MDA6ICcjMDI4OGQxJyxcbiAgODAwOiAnIzAyNzdiZCcsXG4gIDkwMDogJyMwMTU3OWInLFxuICBBMTAwOiAnIzgwZDhmZicsXG4gIEEyMDA6ICcjNDBjNGZmJyxcbiAgQTQwMDogJyMwMGIwZmYnLFxuICBBNzAwOiAnIzAwOTFlYSdcbn07XG5leHBvcnQgZGVmYXVsdCBsaWdodEJsdWU7IiwiY29uc3QgZ3JlZW4gPSB7XG4gIDUwOiAnI2U4ZjVlOScsXG4gIDEwMDogJyNjOGU2YzknLFxuICAyMDA6ICcjYTVkNmE3JyxcbiAgMzAwOiAnIzgxYzc4NCcsXG4gIDQwMDogJyM2NmJiNmEnLFxuICA1MDA6ICcjNGNhZjUwJyxcbiAgNjAwOiAnIzQzYTA0NycsXG4gIDcwMDogJyMzODhlM2MnLFxuICA4MDA6ICcjMmU3ZDMyJyxcbiAgOTAwOiAnIzFiNWUyMCcsXG4gIEExMDA6ICcjYjlmNmNhJyxcbiAgQTIwMDogJyM2OWYwYWUnLFxuICBBNDAwOiAnIzAwZTY3NicsXG4gIEE3MDA6ICcjMDBjODUzJ1xufTtcbmV4cG9ydCBkZWZhdWx0IGdyZWVuOyIsImltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAbXVpL3V0aWxzL2Zvcm1hdE11aUVycm9yTWVzc2FnZVwiO1xuaW1wb3J0IGRlZXBtZXJnZSBmcm9tICdAbXVpL3V0aWxzL2RlZXBtZXJnZSc7XG5pbXBvcnQgeyBkYXJrZW4sIGdldENvbnRyYXN0UmF0aW8sIGxpZ2h0ZW4gfSBmcm9tICdAbXVpL3N5c3RlbS9jb2xvck1hbmlwdWxhdG9yJztcbmltcG9ydCBjb21tb24gZnJvbSBcIi4uL2NvbG9ycy9jb21tb24ubWpzXCI7XG5pbXBvcnQgZ3JleSBmcm9tIFwiLi4vY29sb3JzL2dyZXkubWpzXCI7XG5pbXBvcnQgcHVycGxlIGZyb20gXCIuLi9jb2xvcnMvcHVycGxlLm1qc1wiO1xuaW1wb3J0IHJlZCBmcm9tIFwiLi4vY29sb3JzL3JlZC5tanNcIjtcbmltcG9ydCBvcmFuZ2UgZnJvbSBcIi4uL2NvbG9ycy9vcmFuZ2UubWpzXCI7XG5pbXBvcnQgYmx1ZSBmcm9tIFwiLi4vY29sb3JzL2JsdWUubWpzXCI7XG5pbXBvcnQgbGlnaHRCbHVlIGZyb20gXCIuLi9jb2xvcnMvbGlnaHRCbHVlLm1qc1wiO1xuaW1wb3J0IGdyZWVuIGZyb20gXCIuLi9jb2xvcnMvZ3JlZW4ubWpzXCI7XG5mdW5jdGlvbiBnZXRMaWdodCgpIHtcbiAgcmV0dXJuIHtcbiAgICAvLyBUaGUgY29sb3JzIHVzZWQgdG8gc3R5bGUgdGhlIHRleHQuXG4gICAgdGV4dDoge1xuICAgICAgLy8gVGhlIG1vc3QgaW1wb3J0YW50IHRleHQuXG4gICAgICBwcmltYXJ5OiAncmdiYSgwLCAwLCAwLCAwLjg3KScsXG4gICAgICAvLyBTZWNvbmRhcnkgdGV4dC5cbiAgICAgIHNlY29uZGFyeTogJ3JnYmEoMCwgMCwgMCwgMC42KScsXG4gICAgICAvLyBEaXNhYmxlZCB0ZXh0IGhhdmUgZXZlbiBsb3dlciB2aXN1YWwgcHJvbWluZW5jZS5cbiAgICAgIGRpc2FibGVkOiAncmdiYSgwLCAwLCAwLCAwLjM4KSdcbiAgICB9LFxuICAgIC8vIFRoZSBjb2xvciB1c2VkIHRvIGRpdmlkZSBkaWZmZXJlbnQgZWxlbWVudHMuXG4gICAgZGl2aWRlcjogJ3JnYmEoMCwgMCwgMCwgMC4xMiknLFxuICAgIC8vIFRoZSBiYWNrZ3JvdW5kIGNvbG9ycyB1c2VkIHRvIHN0eWxlIHRoZSBzdXJmYWNlcy5cbiAgICAvLyBDb25zaXN0ZW5jeSBiZXR3ZWVuIHRoZXNlIHZhbHVlcyBpcyBpbXBvcnRhbnQuXG4gICAgYmFja2dyb3VuZDoge1xuICAgICAgcGFwZXI6IGNvbW1vbi53aGl0ZSxcbiAgICAgIGRlZmF1bHQ6IGNvbW1vbi53aGl0ZVxuICAgIH0sXG4gICAgLy8gVGhlIGNvbG9ycyB1c2VkIHRvIHN0eWxlIHRoZSBhY3Rpb24gZWxlbWVudHMuXG4gICAgYWN0aW9uOiB7XG4gICAgICAvLyBUaGUgY29sb3Igb2YgYW4gYWN0aXZlIGFjdGlvbiBsaWtlIGFuIGljb24gYnV0dG9uLlxuICAgICAgYWN0aXZlOiAncmdiYSgwLCAwLCAwLCAwLjU0KScsXG4gICAgICAvLyBUaGUgY29sb3Igb2YgYW4gaG92ZXJlZCBhY3Rpb24uXG4gICAgICBob3ZlcjogJ3JnYmEoMCwgMCwgMCwgMC4wNCknLFxuICAgICAgaG92ZXJPcGFjaXR5OiAwLjA0LFxuICAgICAgLy8gVGhlIGNvbG9yIG9mIGEgc2VsZWN0ZWQgYWN0aW9uLlxuICAgICAgc2VsZWN0ZWQ6ICdyZ2JhKDAsIDAsIDAsIDAuMDgpJyxcbiAgICAgIHNlbGVjdGVkT3BhY2l0eTogMC4wOCxcbiAgICAgIC8vIFRoZSBjb2xvciBvZiBhIGRpc2FibGVkIGFjdGlvbi5cbiAgICAgIGRpc2FibGVkOiAncmdiYSgwLCAwLCAwLCAwLjI2KScsXG4gICAgICAvLyBUaGUgYmFja2dyb3VuZCBjb2xvciBvZiBhIGRpc2FibGVkIGFjdGlvbi5cbiAgICAgIGRpc2FibGVkQmFja2dyb3VuZDogJ3JnYmEoMCwgMCwgMCwgMC4xMiknLFxuICAgICAgZGlzYWJsZWRPcGFjaXR5OiAwLjM4LFxuICAgICAgZm9jdXM6ICdyZ2JhKDAsIDAsIDAsIDAuMTIpJyxcbiAgICAgIGZvY3VzT3BhY2l0eTogMC4xMixcbiAgICAgIGFjdGl2YXRlZE9wYWNpdHk6IDAuMTJcbiAgICB9XG4gIH07XG59XG5leHBvcnQgY29uc3QgbGlnaHQgPSBnZXRMaWdodCgpO1xuZnVuY3Rpb24gZ2V0RGFyaygpIHtcbiAgcmV0dXJuIHtcbiAgICB0ZXh0OiB7XG4gICAgICBwcmltYXJ5OiBjb21tb24ud2hpdGUsXG4gICAgICBzZWNvbmRhcnk6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNyknLFxuICAgICAgZGlzYWJsZWQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSknLFxuICAgICAgaWNvbjogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC41KSdcbiAgICB9LFxuICAgIGRpdmlkZXI6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTIpJyxcbiAgICBiYWNrZ3JvdW5kOiB7XG4gICAgICBwYXBlcjogJyMxMjEyMTInLFxuICAgICAgZGVmYXVsdDogJyMxMjEyMTInXG4gICAgfSxcbiAgICBhY3Rpb246IHtcbiAgICAgIGFjdGl2ZTogY29tbW9uLndoaXRlLFxuICAgICAgaG92ZXI6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDgpJyxcbiAgICAgIGhvdmVyT3BhY2l0eTogMC4wOCxcbiAgICAgIHNlbGVjdGVkOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE2KScsXG4gICAgICBzZWxlY3RlZE9wYWNpdHk6IDAuMTYsXG4gICAgICBkaXNhYmxlZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4zKScsXG4gICAgICBkaXNhYmxlZEJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTIpJyxcbiAgICAgIGRpc2FibGVkT3BhY2l0eTogMC4zOCxcbiAgICAgIGZvY3VzOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEyKScsXG4gICAgICBmb2N1c09wYWNpdHk6IDAuMTIsXG4gICAgICBhY3RpdmF0ZWRPcGFjaXR5OiAwLjI0XG4gICAgfVxuICB9O1xufVxuZXhwb3J0IGNvbnN0IGRhcmsgPSBnZXREYXJrKCk7XG5mdW5jdGlvbiBhZGRMaWdodE9yRGFyayhpbnRlbnQsIGRpcmVjdGlvbiwgc2hhZGUsIHRvbmFsT2Zmc2V0KSB7XG4gIGNvbnN0IHRvbmFsT2Zmc2V0TGlnaHQgPSB0b25hbE9mZnNldC5saWdodCB8fCB0b25hbE9mZnNldDtcbiAgY29uc3QgdG9uYWxPZmZzZXREYXJrID0gdG9uYWxPZmZzZXQuZGFyayB8fCB0b25hbE9mZnNldCAqIDEuNTtcbiAgaWYgKCFpbnRlbnRbZGlyZWN0aW9uXSkge1xuICAgIGlmIChpbnRlbnQuaGFzT3duUHJvcGVydHkoc2hhZGUpKSB7XG4gICAgICBpbnRlbnRbZGlyZWN0aW9uXSA9IGludGVudFtzaGFkZV07XG4gICAgfSBlbHNlIGlmIChkaXJlY3Rpb24gPT09ICdsaWdodCcpIHtcbiAgICAgIGludGVudC5saWdodCA9IGxpZ2h0ZW4oaW50ZW50Lm1haW4sIHRvbmFsT2Zmc2V0TGlnaHQpO1xuICAgIH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAnZGFyaycpIHtcbiAgICAgIGludGVudC5kYXJrID0gZGFya2VuKGludGVudC5tYWluLCB0b25hbE9mZnNldERhcmspO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gbWl4TGlnaHRPckRhcmsoY29sb3JTcGFjZSwgaW50ZW50LCBkaXJlY3Rpb24sIHNoYWRlLCB0b25hbE9mZnNldCkge1xuICBjb25zdCB0b25hbE9mZnNldExpZ2h0ID0gdG9uYWxPZmZzZXQubGlnaHQgfHwgdG9uYWxPZmZzZXQ7XG4gIGNvbnN0IHRvbmFsT2Zmc2V0RGFyayA9IHRvbmFsT2Zmc2V0LmRhcmsgfHwgdG9uYWxPZmZzZXQgKiAxLjU7XG4gIGlmICghaW50ZW50W2RpcmVjdGlvbl0pIHtcbiAgICBpZiAoaW50ZW50Lmhhc093blByb3BlcnR5KHNoYWRlKSkge1xuICAgICAgaW50ZW50W2RpcmVjdGlvbl0gPSBpbnRlbnRbc2hhZGVdO1xuICAgIH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAnbGlnaHQnKSB7XG4gICAgICBpbnRlbnQubGlnaHQgPSBgY29sb3ItbWl4KGluICR7Y29sb3JTcGFjZX0sICR7aW50ZW50Lm1haW59LCAjZmZmICR7KHRvbmFsT2Zmc2V0TGlnaHQgKiAxMDApLnRvRml4ZWQoMCl9JSlgO1xuICAgIH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAnZGFyaycpIHtcbiAgICAgIGludGVudC5kYXJrID0gYGNvbG9yLW1peChpbiAke2NvbG9yU3BhY2V9LCAke2ludGVudC5tYWlufSwgIzAwMCAkeyh0b25hbE9mZnNldERhcmsgKiAxMDApLnRvRml4ZWQoMCl9JSlgO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gZ2V0RGVmYXVsdFByaW1hcnkobW9kZSA9ICdsaWdodCcpIHtcbiAgaWYgKG1vZGUgPT09ICdkYXJrJykge1xuICAgIHJldHVybiB7XG4gICAgICBtYWluOiBibHVlWzIwMF0sXG4gICAgICBsaWdodDogYmx1ZVs1MF0sXG4gICAgICBkYXJrOiBibHVlWzQwMF1cbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgbWFpbjogYmx1ZVs3MDBdLFxuICAgIGxpZ2h0OiBibHVlWzQwMF0sXG4gICAgZGFyazogYmx1ZVs4MDBdXG4gIH07XG59XG5mdW5jdGlvbiBnZXREZWZhdWx0U2Vjb25kYXJ5KG1vZGUgPSAnbGlnaHQnKSB7XG4gIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbjogcHVycGxlWzIwMF0sXG4gICAgICBsaWdodDogcHVycGxlWzUwXSxcbiAgICAgIGRhcms6IHB1cnBsZVs0MDBdXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG1haW46IHB1cnBsZVs1MDBdLFxuICAgIGxpZ2h0OiBwdXJwbGVbMzAwXSxcbiAgICBkYXJrOiBwdXJwbGVbNzAwXVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0RGVmYXVsdEVycm9yKG1vZGUgPSAnbGlnaHQnKSB7XG4gIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbjogcmVkWzUwMF0sXG4gICAgICBsaWdodDogcmVkWzMwMF0sXG4gICAgICBkYXJrOiByZWRbNzAwXVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYWluOiByZWRbNzAwXSxcbiAgICBsaWdodDogcmVkWzQwMF0sXG4gICAgZGFyazogcmVkWzgwMF1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldERlZmF1bHRJbmZvKG1vZGUgPSAnbGlnaHQnKSB7XG4gIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbjogbGlnaHRCbHVlWzQwMF0sXG4gICAgICBsaWdodDogbGlnaHRCbHVlWzMwMF0sXG4gICAgICBkYXJrOiBsaWdodEJsdWVbNzAwXVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYWluOiBsaWdodEJsdWVbNzAwXSxcbiAgICBsaWdodDogbGlnaHRCbHVlWzUwMF0sXG4gICAgZGFyazogbGlnaHRCbHVlWzkwMF1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldERlZmF1bHRTdWNjZXNzKG1vZGUgPSAnbGlnaHQnKSB7XG4gIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbjogZ3JlZW5bNDAwXSxcbiAgICAgIGxpZ2h0OiBncmVlblszMDBdLFxuICAgICAgZGFyazogZ3JlZW5bNzAwXVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYWluOiBncmVlbls4MDBdLFxuICAgIGxpZ2h0OiBncmVlbls1MDBdLFxuICAgIGRhcms6IGdyZWVuWzkwMF1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldERlZmF1bHRXYXJuaW5nKG1vZGUgPSAnbGlnaHQnKSB7XG4gIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbjogb3JhbmdlWzQwMF0sXG4gICAgICBsaWdodDogb3JhbmdlWzMwMF0sXG4gICAgICBkYXJrOiBvcmFuZ2VbNzAwXVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYWluOiAnI2VkNmMwMicsXG4gICAgLy8gY2xvc2VzdCB0byBvcmFuZ2VbODAwXSB0aGF0IHBhc3MgMzoxLlxuICAgIGxpZ2h0OiBvcmFuZ2VbNTAwXSxcbiAgICBkYXJrOiBvcmFuZ2VbOTAwXVxuICB9O1xufVxuXG4vLyBVc2UgdGhlIHNhbWUgbmFtZSBhcyB0aGUgZXhwZXJpbWVudGFsIENTUyBgY29udHJhc3QtY29sb3JgIGZ1bmN0aW9uLlxuZXhwb3J0IGZ1bmN0aW9uIGNvbnRyYXN0Q29sb3IoYmFja2dyb3VuZCkge1xuICByZXR1cm4gYG9rbGNoKGZyb20gJHtiYWNrZ3JvdW5kfSB2YXIoLS1fX2wpIDAgaCAvIHZhcigtLV9fYSkpYDtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZVBhbGV0dGUocGFsZXR0ZSkge1xuICBjb25zdCB7XG4gICAgbW9kZSA9ICdsaWdodCcsXG4gICAgY29udHJhc3RUaHJlc2hvbGQgPSAzLFxuICAgIHRvbmFsT2Zmc2V0ID0gMC4yLFxuICAgIGNvbG9yU3BhY2UsXG4gICAgLi4ub3RoZXJcbiAgfSA9IHBhbGV0dGU7XG4gIGNvbnN0IHByaW1hcnkgPSBwYWxldHRlLnByaW1hcnkgfHwgZ2V0RGVmYXVsdFByaW1hcnkobW9kZSk7XG4gIGNvbnN0IHNlY29uZGFyeSA9IHBhbGV0dGUuc2Vjb25kYXJ5IHx8IGdldERlZmF1bHRTZWNvbmRhcnkobW9kZSk7XG4gIGNvbnN0IGVycm9yID0gcGFsZXR0ZS5lcnJvciB8fCBnZXREZWZhdWx0RXJyb3IobW9kZSk7XG4gIGNvbnN0IGluZm8gPSBwYWxldHRlLmluZm8gfHwgZ2V0RGVmYXVsdEluZm8obW9kZSk7XG4gIGNvbnN0IHN1Y2Nlc3MgPSBwYWxldHRlLnN1Y2Nlc3MgfHwgZ2V0RGVmYXVsdFN1Y2Nlc3MobW9kZSk7XG4gIGNvbnN0IHdhcm5pbmcgPSBwYWxldHRlLndhcm5pbmcgfHwgZ2V0RGVmYXVsdFdhcm5pbmcobW9kZSk7XG5cbiAgLy8gVXNlIHRoZSBzYW1lIGxvZ2ljIGFzXG4gIC8vIEJvb3RzdHJhcDogaHR0cHM6Ly9naXRodWIuY29tL3R3YnMvYm9vdHN0cmFwL2Jsb2IvMWQ2ZTM3MTBkZDQ0N2RlMWEyMDBmMjllOGZhNTIxZjhhMDkwOGY3MC9zY3NzL19mdW5jdGlvbnMuc2NzcyNMNTlcbiAgLy8gYW5kIG1hdGVyaWFsLWNvbXBvbmVudHMtd2ViIGh0dHBzOi8vZ2l0aHViLmNvbS9tYXRlcmlhbC1jb21wb25lbnRzL21hdGVyaWFsLWNvbXBvbmVudHMtd2ViL2Jsb2IvYWM0NmI4ODYzYzRkYWI5ZmMyMmM0YzY2MmRjNmJkMWI2NWRkNjUyZi9wYWNrYWdlcy9tZGMtdGhlbWUvX2Z1bmN0aW9ucy5zY3NzI0w1NFxuICBmdW5jdGlvbiBnZXRDb250cmFzdFRleHQoYmFja2dyb3VuZCkge1xuICAgIGlmIChjb2xvclNwYWNlKSB7XG4gICAgICByZXR1cm4gY29udHJhc3RDb2xvcihiYWNrZ3JvdW5kKTtcbiAgICB9XG4gICAgY29uc3QgY29udHJhc3RUZXh0ID0gZ2V0Q29udHJhc3RSYXRpbyhiYWNrZ3JvdW5kLCBkYXJrLnRleHQucHJpbWFyeSkgPj0gY29udHJhc3RUaHJlc2hvbGQgPyBkYXJrLnRleHQucHJpbWFyeSA6IGxpZ2h0LnRleHQucHJpbWFyeTtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgY29udHJhc3QgPSBnZXRDb250cmFzdFJhdGlvKGJhY2tncm91bmQsIGNvbnRyYXN0VGV4dCk7XG4gICAgICBpZiAoY29udHJhc3QgPCAzKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoW2BNVUk6IFRoZSBjb250cmFzdCByYXRpbyBvZiAke2NvbnRyYXN0fToxIGZvciAke2NvbnRyYXN0VGV4dH0gb24gJHtiYWNrZ3JvdW5kfWAsICdmYWxscyBiZWxvdyB0aGUgV0NBRyByZWNvbW1lbmRlZCBhYnNvbHV0ZSBtaW5pbXVtIGNvbnRyYXN0IHJhdGlvIG9mIDM6MS4nLCAnaHR0cHM6Ly93d3cudzMub3JnL1RSLzIwMDgvUkVDLVdDQUcyMC0yMDA4MTIxMS8jdmlzdWFsLWF1ZGlvLWNvbnRyYXN0LWNvbnRyYXN0J10uam9pbignXFxuJykpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY29udHJhc3RUZXh0O1xuICB9XG4gIGNvbnN0IGF1Z21lbnRDb2xvciA9ICh7XG4gICAgY29sb3IsXG4gICAgbmFtZSxcbiAgICBtYWluU2hhZGUgPSA1MDAsXG4gICAgbGlnaHRTaGFkZSA9IDMwMCxcbiAgICBkYXJrU2hhZGUgPSA3MDBcbiAgfSkgPT4ge1xuICAgIGNvbG9yID0ge1xuICAgICAgLi4uY29sb3JcbiAgICB9O1xuICAgIGlmICghY29sb3IubWFpbiAmJiBjb2xvclttYWluU2hhZGVdKSB7XG4gICAgICBjb2xvci5tYWluID0gY29sb3JbbWFpblNoYWRlXTtcbiAgICB9XG4gICAgaWYgKCFjb2xvci5oYXNPd25Qcm9wZXJ0eSgnbWFpbicpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYE1VSTogVGhlIGNvbG9yJHtuYW1lID8gYCAoJHtuYW1lfSlgIDogJyd9IHByb3ZpZGVkIHRvIGF1Z21lbnRDb2xvcihjb2xvcikgaXMgaW52YWxpZC5cXG5gICsgYFRoZSBjb2xvciBvYmplY3QgbmVlZHMgdG8gaGF2ZSBhIFxcYG1haW5cXGAgcHJvcGVydHkgb3IgYSBcXGAke21haW5TaGFkZX1cXGAgcHJvcGVydHkuYCA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTEsIG5hbWUgPyBgICgke25hbWV9KWAgOiAnJywgbWFpblNoYWRlKSk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29sb3IubWFpbiAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBgTVVJOiBUaGUgY29sb3Ike25hbWUgPyBgICgke25hbWV9KWAgOiAnJ30gcHJvdmlkZWQgdG8gYXVnbWVudENvbG9yKGNvbG9yKSBpcyBpbnZhbGlkLlxcbmAgKyBgXFxgY29sb3IubWFpblxcYCBzaG91bGQgYmUgYSBzdHJpbmcsIGJ1dCBcXGAke0pTT04uc3RyaW5naWZ5KGNvbG9yLm1haW4pfVxcYCB3YXMgcHJvdmlkZWQgaW5zdGVhZC5cXG5gICsgJ1xcbicgKyAnRGlkIHlvdSBpbnRlbmQgdG8gdXNlIG9uZSBvZiB0aGUgZm9sbG93aW5nIGFwcHJvYWNoZXM/XFxuJyArICdcXG4nICsgJ2ltcG9ydCB7IGdyZWVuIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvY29sb3JzXCI7XFxuJyArICdcXG4nICsgJ2NvbnN0IHRoZW1lMSA9IGNyZWF0ZVRoZW1lKHsgcGFsZXR0ZToge1xcbicgKyAnICBwcmltYXJ5OiBncmVlbixcXG4nICsgJ30gfSk7XFxuJyArICdcXG4nICsgJ2NvbnN0IHRoZW1lMiA9IGNyZWF0ZVRoZW1lKHsgcGFsZXR0ZToge1xcbicgKyAnICBwcmltYXJ5OiB7IG1haW46IGdyZWVuWzUwMF0gfSxcXG4nICsgJ30gfSk7JyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTIsIG5hbWUgPyBgICgke25hbWV9KWAgOiAnJywgSlNPTi5zdHJpbmdpZnkoY29sb3IubWFpbikpKTtcbiAgICB9XG4gICAgaWYgKGNvbG9yU3BhY2UpIHtcbiAgICAgIG1peExpZ2h0T3JEYXJrKGNvbG9yU3BhY2UsIGNvbG9yLCAnbGlnaHQnLCBsaWdodFNoYWRlLCB0b25hbE9mZnNldCk7XG4gICAgICBtaXhMaWdodE9yRGFyayhjb2xvclNwYWNlLCBjb2xvciwgJ2RhcmsnLCBkYXJrU2hhZGUsIHRvbmFsT2Zmc2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYWRkTGlnaHRPckRhcmsoY29sb3IsICdsaWdodCcsIGxpZ2h0U2hhZGUsIHRvbmFsT2Zmc2V0KTtcbiAgICAgIGFkZExpZ2h0T3JEYXJrKGNvbG9yLCAnZGFyaycsIGRhcmtTaGFkZSwgdG9uYWxPZmZzZXQpO1xuICAgIH1cbiAgICBpZiAoIWNvbG9yLmNvbnRyYXN0VGV4dCkge1xuICAgICAgY29sb3IuY29udHJhc3RUZXh0ID0gZ2V0Q29udHJhc3RUZXh0KGNvbG9yLm1haW4pO1xuICAgIH1cbiAgICByZXR1cm4gY29sb3I7XG4gIH07XG4gIGxldCBtb2RlSHlkcmF0ZWQ7XG4gIGlmIChtb2RlID09PSAnbGlnaHQnKSB7XG4gICAgbW9kZUh5ZHJhdGVkID0gZ2V0TGlnaHQoKTtcbiAgfSBlbHNlIGlmIChtb2RlID09PSAnZGFyaycpIHtcbiAgICBtb2RlSHlkcmF0ZWQgPSBnZXREYXJrKCk7XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoIW1vZGVIeWRyYXRlZCkge1xuICAgICAgY29uc29sZS5lcnJvcihgTVVJOiBUaGUgcGFsZXR0ZSBtb2RlIFxcYCR7bW9kZX1cXGAgaXMgbm90IHN1cHBvcnRlZC5gKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgcGFsZXR0ZU91dHB1dCA9IGRlZXBtZXJnZSh7XG4gICAgLy8gQSBjb2xsZWN0aW9uIG9mIGNvbW1vbiBjb2xvcnMuXG4gICAgY29tbW9uOiB7XG4gICAgICAuLi5jb21tb25cbiAgICB9LFxuICAgIC8vIHByZXZlbnQgbXV0YWJsZSBvYmplY3QuXG4gICAgLy8gVGhlIHBhbGV0dGUgbW9kZSwgY2FuIGJlIGxpZ2h0IG9yIGRhcmsuXG4gICAgbW9kZSxcbiAgICAvLyBUaGUgY29sb3JzIHVzZWQgdG8gcmVwcmVzZW50IHByaW1hcnkgaW50ZXJmYWNlIGVsZW1lbnRzIGZvciBhIHVzZXIuXG4gICAgcHJpbWFyeTogYXVnbWVudENvbG9yKHtcbiAgICAgIGNvbG9yOiBwcmltYXJ5LFxuICAgICAgbmFtZTogJ3ByaW1hcnknXG4gICAgfSksXG4gICAgLy8gVGhlIGNvbG9ycyB1c2VkIHRvIHJlcHJlc2VudCBzZWNvbmRhcnkgaW50ZXJmYWNlIGVsZW1lbnRzIGZvciBhIHVzZXIuXG4gICAgc2Vjb25kYXJ5OiBhdWdtZW50Q29sb3Ioe1xuICAgICAgY29sb3I6IHNlY29uZGFyeSxcbiAgICAgIG5hbWU6ICdzZWNvbmRhcnknLFxuICAgICAgbWFpblNoYWRlOiAnQTQwMCcsXG4gICAgICBsaWdodFNoYWRlOiAnQTIwMCcsXG4gICAgICBkYXJrU2hhZGU6ICdBNzAwJ1xuICAgIH0pLFxuICAgIC8vIFRoZSBjb2xvcnMgdXNlZCB0byByZXByZXNlbnQgaW50ZXJmYWNlIGVsZW1lbnRzIHRoYXQgdGhlIHVzZXIgc2hvdWxkIGJlIG1hZGUgYXdhcmUgb2YuXG4gICAgZXJyb3I6IGF1Z21lbnRDb2xvcih7XG4gICAgICBjb2xvcjogZXJyb3IsXG4gICAgICBuYW1lOiAnZXJyb3InXG4gICAgfSksXG4gICAgLy8gVGhlIGNvbG9ycyB1c2VkIHRvIHJlcHJlc2VudCBwb3RlbnRpYWxseSBkYW5nZXJvdXMgYWN0aW9ucyBvciBpbXBvcnRhbnQgbWVzc2FnZXMuXG4gICAgd2FybmluZzogYXVnbWVudENvbG9yKHtcbiAgICAgIGNvbG9yOiB3YXJuaW5nLFxuICAgICAgbmFtZTogJ3dhcm5pbmcnXG4gICAgfSksXG4gICAgLy8gVGhlIGNvbG9ycyB1c2VkIHRvIHByZXNlbnQgaW5mb3JtYXRpb24gdG8gdGhlIHVzZXIgdGhhdCBpcyBuZXV0cmFsIGFuZCBub3QgbmVjZXNzYXJpbHkgaW1wb3J0YW50LlxuICAgIGluZm86IGF1Z21lbnRDb2xvcih7XG4gICAgICBjb2xvcjogaW5mbyxcbiAgICAgIG5hbWU6ICdpbmZvJ1xuICAgIH0pLFxuICAgIC8vIFRoZSBjb2xvcnMgdXNlZCB0byBpbmRpY2F0ZSB0aGUgc3VjY2Vzc2Z1bCBjb21wbGV0aW9uIG9mIGFuIGFjdGlvbiB0aGF0IHVzZXIgdHJpZ2dlcmVkLlxuICAgIHN1Y2Nlc3M6IGF1Z21lbnRDb2xvcih7XG4gICAgICBjb2xvcjogc3VjY2VzcyxcbiAgICAgIG5hbWU6ICdzdWNjZXNzJ1xuICAgIH0pLFxuICAgIC8vIFRoZSBncmV5IGNvbG9ycy5cbiAgICBncmV5LFxuICAgIC8vIFVzZWQgYnkgYGdldENvbnRyYXN0VGV4dCgpYCB0byBtYXhpbWl6ZSB0aGUgY29udHJhc3QgYmV0d2VlblxuICAgIC8vIHRoZSBiYWNrZ3JvdW5kIGFuZCB0aGUgdGV4dC5cbiAgICBjb250cmFzdFRocmVzaG9sZCxcbiAgICAvLyBUYWtlcyBhIGJhY2tncm91bmQgY29sb3IgYW5kIHJldHVybnMgdGhlIHRleHQgY29sb3IgdGhhdCBtYXhpbWl6ZXMgdGhlIGNvbnRyYXN0LlxuICAgIGdldENvbnRyYXN0VGV4dCxcbiAgICAvLyBHZW5lcmF0ZSBhIHJpY2ggY29sb3Igb2JqZWN0LlxuICAgIGF1Z21lbnRDb2xvcixcbiAgICAvLyBVc2VkIGJ5IHRoZSBmdW5jdGlvbnMgYmVsb3cgdG8gc2hpZnQgYSBjb2xvcidzIGx1bWluYW5jZSBieSBhcHByb3hpbWF0ZWx5XG4gICAgLy8gdHdvIGluZGV4ZXMgd2l0aGluIGl0cyB0b25hbCBwYWxldHRlLlxuICAgIC8vIEUuZy4sIHNoaWZ0IGZyb20gUmVkIDUwMCB0byBSZWQgMzAwIG9yIFJlZCA3MDAuXG4gICAgdG9uYWxPZmZzZXQsXG4gICAgLy8gVGhlIGxpZ2h0IGFuZCBkYXJrIG1vZGUgb2JqZWN0LlxuICAgIC4uLm1vZGVIeWRyYXRlZFxuICB9LCBvdGhlcik7XG4gIHJldHVybiBwYWxldHRlT3V0cHV0O1xufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHByZXBhcmVUeXBvZ3JhcGh5VmFycyh0eXBvZ3JhcGh5KSB7XG4gIGNvbnN0IHZhcnMgPSB7fTtcbiAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHR5cG9ncmFwaHkpO1xuICBlbnRyaWVzLmZvckVhY2goZW50cnkgPT4ge1xuICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IGVudHJ5O1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICB2YXJzW2tleV0gPSBgJHt2YWx1ZS5mb250U3R5bGUgPyBgJHt2YWx1ZS5mb250U3R5bGV9IGAgOiAnJ30ke3ZhbHVlLmZvbnRWYXJpYW50ID8gYCR7dmFsdWUuZm9udFZhcmlhbnR9IGAgOiAnJ30ke3ZhbHVlLmZvbnRXZWlnaHQgPyBgJHt2YWx1ZS5mb250V2VpZ2h0fSBgIDogJyd9JHt2YWx1ZS5mb250U3RyZXRjaCA/IGAke3ZhbHVlLmZvbnRTdHJldGNofSBgIDogJyd9JHt2YWx1ZS5mb250U2l6ZSB8fCAnJ30ke3ZhbHVlLmxpbmVIZWlnaHQgPyBgLyR7dmFsdWUubGluZUhlaWdodH0gYCA6ICcnfSR7dmFsdWUuZm9udEZhbWlseSB8fCAnJ31gO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiB2YXJzO1xufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZU1peGlucyhicmVha3BvaW50cywgbWl4aW5zKSB7XG4gIHJldHVybiB7XG4gICAgdG9vbGJhcjoge1xuICAgICAgbWluSGVpZ2h0OiA1NixcbiAgICAgIFticmVha3BvaW50cy51cCgneHMnKV06IHtcbiAgICAgICAgJ0BtZWRpYSAob3JpZW50YXRpb246IGxhbmRzY2FwZSknOiB7XG4gICAgICAgICAgbWluSGVpZ2h0OiA0OFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgW2JyZWFrcG9pbnRzLnVwKCdzbScpXToge1xuICAgICAgICBtaW5IZWlnaHQ6IDY0XG4gICAgICB9XG4gICAgfSxcbiAgICAuLi5taXhpbnNcbiAgfTtcbn0iLCJpbXBvcnQgZGVlcG1lcmdlIGZyb20gJ0BtdWkvdXRpbHMvZGVlcG1lcmdlJztcbmZ1bmN0aW9uIHJvdW5kKHZhbHVlKSB7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogMWU1KSAvIDFlNTtcbn1cbmNvbnN0IGNhc2VBbGxDYXBzID0ge1xuICB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJ1xufTtcbmNvbnN0IGRlZmF1bHRGb250RmFtaWx5ID0gJ1wiUm9ib3RvXCIsIFwiSGVsdmV0aWNhXCIsIFwiQXJpYWxcIiwgc2Fucy1zZXJpZic7XG5cbi8qKlxuICogQHNlZSBAbGlua3todHRwczovL20yLm1hdGVyaWFsLmlvL2Rlc2lnbi90eXBvZ3JhcGh5L3RoZS10eXBlLXN5c3RlbS5odG1sfVxuICogQHNlZSBAbGlua3todHRwczovL20yLm1hdGVyaWFsLmlvL2Rlc2lnbi90eXBvZ3JhcGh5L3VuZGVyc3RhbmRpbmctdHlwb2dyYXBoeS5odG1sfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjcmVhdGVUeXBvZ3JhcGh5KHBhbGV0dGUsIHR5cG9ncmFwaHkpIHtcbiAgY29uc3Qge1xuICAgIGZvbnRGYW1pbHkgPSBkZWZhdWx0Rm9udEZhbWlseSxcbiAgICAvLyBUaGUgZGVmYXVsdCBmb250IHNpemUgb2YgdGhlIE1hdGVyaWFsIFNwZWNpZmljYXRpb24uXG4gICAgZm9udFNpemUgPSAxNCxcbiAgICAvLyBweFxuICAgIGZvbnRXZWlnaHRMaWdodCA9IDMwMCxcbiAgICBmb250V2VpZ2h0UmVndWxhciA9IDQwMCxcbiAgICBmb250V2VpZ2h0TWVkaXVtID0gNTAwLFxuICAgIGZvbnRXZWlnaHRCb2xkID0gNzAwLFxuICAgIC8vIFRlbGwgTVVJIHdoYXQncyB0aGUgZm9udC1zaXplIG9uIHRoZSBodG1sIGVsZW1lbnQuXG4gICAgLy8gMTZweCBpcyB0aGUgZGVmYXVsdCBmb250LXNpemUgdXNlZCBieSBicm93c2Vycy5cbiAgICBodG1sRm9udFNpemUgPSAxNixcbiAgICAvLyBBcHBseSB0aGUgQ1NTIHByb3BlcnRpZXMgdG8gYWxsIHRoZSB2YXJpYW50cy5cbiAgICBhbGxWYXJpYW50cyxcbiAgICBweFRvUmVtOiBweFRvUmVtMixcbiAgICAuLi5vdGhlclxuICB9ID0gdHlwZW9mIHR5cG9ncmFwaHkgPT09ICdmdW5jdGlvbicgPyB0eXBvZ3JhcGh5KHBhbGV0dGUpIDogdHlwb2dyYXBoeTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAodHlwZW9mIGZvbnRTaXplICE9PSAnbnVtYmVyJykge1xuICAgICAgY29uc29sZS5lcnJvcignTVVJOiBgZm9udFNpemVgIGlzIHJlcXVpcmVkIHRvIGJlIGEgbnVtYmVyLicpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGh0bWxGb250U2l6ZSAhPT0gJ251bWJlcicpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ01VSTogYGh0bWxGb250U2l6ZWAgaXMgcmVxdWlyZWQgdG8gYmUgYSBudW1iZXIuJyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGNvZWYgPSBmb250U2l6ZSAvIDE0O1xuICBjb25zdCBweFRvUmVtID0gcHhUb1JlbTIgfHwgKHNpemUgPT4gYCR7c2l6ZSAvIGh0bWxGb250U2l6ZSAqIGNvZWZ9cmVtYCk7XG4gIGNvbnN0IGJ1aWxkVmFyaWFudCA9IChmb250V2VpZ2h0LCBzaXplLCBsaW5lSGVpZ2h0LCBsZXR0ZXJTcGFjaW5nLCBjYXNpbmcpID0+ICh7XG4gICAgZm9udEZhbWlseSxcbiAgICBmb250V2VpZ2h0LFxuICAgIGZvbnRTaXplOiBweFRvUmVtKHNpemUpLFxuICAgIC8vIFVuaXRsZXNzIGZvbGxvd2luZyBodHRwczovL21leWVyd2ViLmNvbS9lcmljL3Rob3VnaHRzLzIwMDYvMDIvMDgvdW5pdGxlc3MtbGluZS1oZWlnaHRzL1xuICAgIGxpbmVIZWlnaHQsXG4gICAgLy8gVGhlIGxldHRlciBzcGFjaW5nIHdhcyBkZXNpZ25lZCBmb3IgdGhlIFJvYm90byBmb250LWZhbWlseS4gVXNpbmcgdGhlIHNhbWUgbGV0dGVyLXNwYWNpbmdcbiAgICAvLyBhY3Jvc3MgZm9udC1mYW1pbGllcyBjYW4gY2F1c2UgaXNzdWVzIHdpdGggdGhlIGtlcm5pbmcuXG4gICAgLi4uKGZvbnRGYW1pbHkgPT09IGRlZmF1bHRGb250RmFtaWx5ID8ge1xuICAgICAgbGV0dGVyU3BhY2luZzogYCR7cm91bmQobGV0dGVyU3BhY2luZyAvIHNpemUpfWVtYFxuICAgIH0gOiB7fSksXG4gICAgLi4uY2FzaW5nLFxuICAgIC4uLmFsbFZhcmlhbnRzXG4gIH0pO1xuICBjb25zdCB2YXJpYW50cyA9IHtcbiAgICBoMTogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRMaWdodCwgOTYsIDEuMTY3LCAtMS41KSxcbiAgICBoMjogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRMaWdodCwgNjAsIDEuMiwgLTAuNSksXG4gICAgaDM6IGJ1aWxkVmFyaWFudChmb250V2VpZ2h0UmVndWxhciwgNDgsIDEuMTY3LCAwKSxcbiAgICBoNDogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRSZWd1bGFyLCAzNCwgMS4yMzUsIDAuMjUpLFxuICAgIGg1OiBidWlsZFZhcmlhbnQoZm9udFdlaWdodFJlZ3VsYXIsIDI0LCAxLjMzNCwgMCksXG4gICAgaDY6IGJ1aWxkVmFyaWFudChmb250V2VpZ2h0TWVkaXVtLCAyMCwgMS42LCAwLjE1KSxcbiAgICBzdWJ0aXRsZTE6IGJ1aWxkVmFyaWFudChmb250V2VpZ2h0UmVndWxhciwgMTYsIDEuNzUsIDAuMTUpLFxuICAgIHN1YnRpdGxlMjogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRNZWRpdW0sIDE0LCAxLjU3LCAwLjEpLFxuICAgIGJvZHkxOiBidWlsZFZhcmlhbnQoZm9udFdlaWdodFJlZ3VsYXIsIDE2LCAxLjUsIDAuMTUpLFxuICAgIGJvZHkyOiBidWlsZFZhcmlhbnQoZm9udFdlaWdodFJlZ3VsYXIsIDE0LCAxLjQzLCAwLjE1KSxcbiAgICBidXR0b246IGJ1aWxkVmFyaWFudChmb250V2VpZ2h0TWVkaXVtLCAxNCwgMS43NSwgMC40LCBjYXNlQWxsQ2FwcyksXG4gICAgY2FwdGlvbjogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRSZWd1bGFyLCAxMiwgMS42NiwgMC40KSxcbiAgICBvdmVybGluZTogYnVpbGRWYXJpYW50KGZvbnRXZWlnaHRSZWd1bGFyLCAxMiwgMi42NiwgMSwgY2FzZUFsbENhcHMpLFxuICAgIC8vIFRPRE8gdjY6IFJlbW92ZSBoYW5kbGluZyBvZiAnaW5oZXJpdCcgdmFyaWFudCBmcm9tIHRoZSB0aGVtZSBhcyBpdCBpcyBhbHJlYWR5IGhhbmRsZWQgaW4gTWF0ZXJpYWwgVUkncyBUeXBvZ3JhcGh5IGNvbXBvbmVudC4gQWxzbywgcmVtZW1iZXIgdG8gcmVtb3ZlIHRoZSBhc3NvY2lhdGVkIHR5cGVzLlxuICAgIGluaGVyaXQ6IHtcbiAgICAgIGZvbnRGYW1pbHk6ICdpbmhlcml0JyxcbiAgICAgIGZvbnRXZWlnaHQ6ICdpbmhlcml0JyxcbiAgICAgIGZvbnRTaXplOiAnaW5oZXJpdCcsXG4gICAgICBsaW5lSGVpZ2h0OiAnaW5oZXJpdCcsXG4gICAgICBsZXR0ZXJTcGFjaW5nOiAnaW5oZXJpdCdcbiAgICB9XG4gIH07XG4gIHJldHVybiBkZWVwbWVyZ2Uoe1xuICAgIGh0bWxGb250U2l6ZSxcbiAgICBweFRvUmVtLFxuICAgIGZvbnRGYW1pbHksXG4gICAgZm9udFNpemUsXG4gICAgZm9udFdlaWdodExpZ2h0LFxuICAgIGZvbnRXZWlnaHRSZWd1bGFyLFxuICAgIGZvbnRXZWlnaHRNZWRpdW0sXG4gICAgZm9udFdlaWdodEJvbGQsXG4gICAgLi4udmFyaWFudHNcbiAgfSwgb3RoZXIsIHtcbiAgICBjbG9uZTogZmFsc2UgLy8gTm8gbmVlZCB0byBjbG9uZSBkZWVwXG4gIH0pO1xufSIsImNvbnN0IHNoYWRvd0tleVVtYnJhT3BhY2l0eSA9IDAuMjtcbmNvbnN0IHNoYWRvd0tleVBlbnVtYnJhT3BhY2l0eSA9IDAuMTQ7XG5jb25zdCBzaGFkb3dBbWJpZW50U2hhZG93T3BhY2l0eSA9IDAuMTI7XG5mdW5jdGlvbiBjcmVhdGVTaGFkb3coLi4ucHgpIHtcbiAgcmV0dXJuIFtgJHtweFswXX1weCAke3B4WzFdfXB4ICR7cHhbMl19cHggJHtweFszXX1weCByZ2JhKDAsMCwwLCR7c2hhZG93S2V5VW1icmFPcGFjaXR5fSlgLCBgJHtweFs0XX1weCAke3B4WzVdfXB4ICR7cHhbNl19cHggJHtweFs3XX1weCByZ2JhKDAsMCwwLCR7c2hhZG93S2V5UGVudW1icmFPcGFjaXR5fSlgLCBgJHtweFs4XX1weCAke3B4WzldfXB4ICR7cHhbMTBdfXB4ICR7cHhbMTFdfXB4IHJnYmEoMCwwLDAsJHtzaGFkb3dBbWJpZW50U2hhZG93T3BhY2l0eX0pYF0uam9pbignLCcpO1xufVxuXG4vLyBWYWx1ZXMgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vbWF0ZXJpYWwtY29tcG9uZW50cy9tYXRlcmlhbC1jb21wb25lbnRzLXdlYi9ibG9iL2JlODc0N2Y5NDU3NDY2OWNiNWU3YWRkMWE3YzU0ZmE0MWE4OWNlYzcvcGFja2FnZXMvbWRjLWVsZXZhdGlvbi9fdmFyaWFibGVzLnNjc3NcbmNvbnN0IHNoYWRvd3MgPSBbJ25vbmUnLCBjcmVhdGVTaGFkb3coMCwgMiwgMSwgLTEsIDAsIDEsIDEsIDAsIDAsIDEsIDMsIDApLCBjcmVhdGVTaGFkb3coMCwgMywgMSwgLTIsIDAsIDIsIDIsIDAsIDAsIDEsIDUsIDApLCBjcmVhdGVTaGFkb3coMCwgMywgMywgLTIsIDAsIDMsIDQsIDAsIDAsIDEsIDgsIDApLCBjcmVhdGVTaGFkb3coMCwgMiwgNCwgLTEsIDAsIDQsIDUsIDAsIDAsIDEsIDEwLCAwKSwgY3JlYXRlU2hhZG93KDAsIDMsIDUsIC0xLCAwLCA1LCA4LCAwLCAwLCAxLCAxNCwgMCksIGNyZWF0ZVNoYWRvdygwLCAzLCA1LCAtMSwgMCwgNiwgMTAsIDAsIDAsIDEsIDE4LCAwKSwgY3JlYXRlU2hhZG93KDAsIDQsIDUsIC0yLCAwLCA3LCAxMCwgMSwgMCwgMiwgMTYsIDEpLCBjcmVhdGVTaGFkb3coMCwgNSwgNSwgLTMsIDAsIDgsIDEwLCAxLCAwLCAzLCAxNCwgMiksIGNyZWF0ZVNoYWRvdygwLCA1LCA2LCAtMywgMCwgOSwgMTIsIDEsIDAsIDMsIDE2LCAyKSwgY3JlYXRlU2hhZG93KDAsIDYsIDYsIC0zLCAwLCAxMCwgMTQsIDEsIDAsIDQsIDE4LCAzKSwgY3JlYXRlU2hhZG93KDAsIDYsIDcsIC00LCAwLCAxMSwgMTUsIDEsIDAsIDQsIDIwLCAzKSwgY3JlYXRlU2hhZG93KDAsIDcsIDgsIC00LCAwLCAxMiwgMTcsIDIsIDAsIDUsIDIyLCA0KSwgY3JlYXRlU2hhZG93KDAsIDcsIDgsIC00LCAwLCAxMywgMTksIDIsIDAsIDUsIDI0LCA0KSwgY3JlYXRlU2hhZG93KDAsIDcsIDksIC00LCAwLCAxNCwgMjEsIDIsIDAsIDUsIDI2LCA0KSwgY3JlYXRlU2hhZG93KDAsIDgsIDksIC01LCAwLCAxNSwgMjIsIDIsIDAsIDYsIDI4LCA1KSwgY3JlYXRlU2hhZG93KDAsIDgsIDEwLCAtNSwgMCwgMTYsIDI0LCAyLCAwLCA2LCAzMCwgNSksIGNyZWF0ZVNoYWRvdygwLCA4LCAxMSwgLTUsIDAsIDE3LCAyNiwgMiwgMCwgNiwgMzIsIDUpLCBjcmVhdGVTaGFkb3coMCwgOSwgMTEsIC01LCAwLCAxOCwgMjgsIDIsIDAsIDcsIDM0LCA2KSwgY3JlYXRlU2hhZG93KDAsIDksIDEyLCAtNiwgMCwgMTksIDI5LCAyLCAwLCA3LCAzNiwgNiksIGNyZWF0ZVNoYWRvdygwLCAxMCwgMTMsIC02LCAwLCAyMCwgMzEsIDMsIDAsIDgsIDM4LCA3KSwgY3JlYXRlU2hhZG93KDAsIDEwLCAxMywgLTYsIDAsIDIxLCAzMywgMywgMCwgOCwgNDAsIDcpLCBjcmVhdGVTaGFkb3coMCwgMTAsIDE0LCAtNiwgMCwgMjIsIDM1LCAzLCAwLCA4LCA0MiwgNyksIGNyZWF0ZVNoYWRvdygwLCAxMSwgMTQsIC03LCAwLCAyMywgMzYsIDMsIDAsIDksIDQ0LCA4KSwgY3JlYXRlU2hhZG93KDAsIDExLCAxNSwgLTcsIDAsIDI0LCAzOCwgMywgMCwgOSwgNDYsIDgpXTtcbmV4cG9ydCBkZWZhdWx0IHNoYWRvd3M7IiwiY29uc3QgREVGQVVMVF9UUkFOU0lUSU9OX1BST1BTID0gWydhbGwnXTtcbmNvbnN0IEVNUFRZX09QVElPTlMgPSB7fTtcblxuLy8gRm9sbG93IGh0dHBzOi8vbWF0ZXJpYWwuZ29vZ2xlLmNvbS9tb3Rpb24vZHVyYXRpb24tZWFzaW5nLmh0bWwjZHVyYXRpb24tZWFzaW5nLW5hdHVyYWwtZWFzaW5nLWN1cnZlc1xuLy8gdG8gbGVhcm4gdGhlIGNvbnRleHQgaW4gd2hpY2ggZWFjaCBlYXNpbmcgc2hvdWxkIGJlIHVzZWQuXG5leHBvcnQgY29uc3QgZWFzaW5nID0ge1xuICAvLyBUaGlzIGlzIHRoZSBtb3N0IGNvbW1vbiBlYXNpbmcgY3VydmUuXG4gIGVhc2VJbk91dDogJ2N1YmljLWJlemllcigwLjQsIDAsIDAuMiwgMSknLFxuICAvLyBPYmplY3RzIGVudGVyIHRoZSBzY3JlZW4gYXQgZnVsbCB2ZWxvY2l0eSBmcm9tIG9mZi1zY3JlZW4gYW5kXG4gIC8vIHNsb3dseSBkZWNlbGVyYXRlIHRvIGEgcmVzdGluZyBwb2ludC5cbiAgZWFzZU91dDogJ2N1YmljLWJlemllcigwLjAsIDAsIDAuMiwgMSknLFxuICAvLyBPYmplY3RzIGxlYXZlIHRoZSBzY3JlZW4gYXQgZnVsbCB2ZWxvY2l0eS4gVGhleSBkbyBub3QgZGVjZWxlcmF0ZSB3aGVuIG9mZi1zY3JlZW4uXG4gIGVhc2VJbjogJ2N1YmljLWJlemllcigwLjQsIDAsIDEsIDEpJyxcbiAgLy8gVGhlIHNoYXJwIGN1cnZlIGlzIHVzZWQgYnkgb2JqZWN0cyB0aGF0IG1heSByZXR1cm4gdG8gdGhlIHNjcmVlbiBhdCBhbnkgdGltZS5cbiAgc2hhcnA6ICdjdWJpYy1iZXppZXIoMC40LCAwLCAwLjYsIDEpJ1xufTtcblxuLy8gRm9sbG93IGh0dHBzOi8vbTIubWF0ZXJpYWwuaW8vZ3VpZGVsaW5lcy9tb3Rpb24vZHVyYXRpb24tZWFzaW5nLmh0bWwjZHVyYXRpb24tZWFzaW5nLWNvbW1vbi1kdXJhdGlvbnNcbi8vIHRvIGxlYXJuIHdoZW4gdXNlIHdoYXQgdGltaW5nXG5leHBvcnQgY29uc3QgZHVyYXRpb24gPSB7XG4gIHNob3J0ZXN0OiAxNTAsXG4gIHNob3J0ZXI6IDIwMCxcbiAgc2hvcnQ6IDI1MCxcbiAgLy8gbW9zdCBiYXNpYyByZWNvbW1lbmRlZCB0aW1pbmdcbiAgc3RhbmRhcmQ6IDMwMCxcbiAgLy8gdGhpcyBpcyB0byBiZSB1c2VkIGluIGNvbXBsZXggYW5pbWF0aW9uc1xuICBjb21wbGV4OiAzNzUsXG4gIC8vIHJlY29tbWVuZGVkIHdoZW4gc29tZXRoaW5nIGlzIGVudGVyaW5nIHNjcmVlblxuICBlbnRlcmluZ1NjcmVlbjogMjI1LFxuICAvLyByZWNvbW1lbmRlZCB3aGVuIHNvbWV0aGluZyBpcyBsZWF2aW5nIHNjcmVlblxuICBsZWF2aW5nU2NyZWVuOiAxOTVcbn07XG5mdW5jdGlvbiBmb3JtYXRNcyhtaWxsaXNlY29uZHMpIHtcbiAgcmV0dXJuIGAke01hdGgucm91bmQobWlsbGlzZWNvbmRzKX1tc2A7XG59XG5mdW5jdGlvbiBnZXRBdXRvSGVpZ2h0RHVyYXRpb24oaGVpZ2h0KSB7XG4gIGlmICghaGVpZ2h0KSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cbiAgY29uc3QgY29uc3RhbnQgPSBoZWlnaHQgLyAzNjtcblxuICAvLyBodHRwczovL3d3dy5kZXNtb3MuY29tL2NhbGN1bGF0b3IvdmJycDNnZ3FldFxuICByZXR1cm4gTWF0aC5taW4oTWF0aC5yb3VuZCgoNCArIDE1ICogY29uc3RhbnQgKiogMC4yNSArIGNvbnN0YW50IC8gNSkgKiAxMCksIDMwMDApO1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY3JlYXRlVHJhbnNpdGlvbnMoaW5wdXRUcmFuc2l0aW9ucykge1xuICBjb25zdCB0cmFuc2l0aW9ucyA9IHtcbiAgICAuLi5pbnB1dFRyYW5zaXRpb25zXG4gIH07XG4gIGRlbGV0ZSB0cmFuc2l0aW9ucy5yZWR1Y2VkTW90aW9uO1xuICBjb25zdCBtZXJnZWRFYXNpbmcgPSB7XG4gICAgLi4uZWFzaW5nLFxuICAgIC4uLnRyYW5zaXRpb25zLmVhc2luZ1xuICB9O1xuICBjb25zdCBtZXJnZWREdXJhdGlvbiA9IHtcbiAgICAuLi5kdXJhdGlvbixcbiAgICAuLi50cmFuc2l0aW9ucy5kdXJhdGlvblxuICB9O1xuICBjb25zdCBjcmVhdGVUcmFuc2l0aW9uVmFsdWUgPSAocHJvcHMgPSBERUZBVUxUX1RSQU5TSVRJT05fUFJPUFMsIG9wdGlvbnMgPSBFTVBUWV9PUFRJT05TKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgZHVyYXRpb246IGR1cmF0aW9uT3B0aW9uID0gbWVyZ2VkRHVyYXRpb24uc3RhbmRhcmQsXG4gICAgICBlYXNpbmc6IGVhc2luZ09wdGlvbiA9IG1lcmdlZEVhc2luZy5lYXNlSW5PdXQsXG4gICAgICBkZWxheSA9IDAsXG4gICAgICAuLi5vdGhlclxuICAgIH0gPSBvcHRpb25zO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBjb25zdCBpc1N0cmluZyA9IHZhbHVlID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZyc7XG4gICAgICBjb25zdCBpc051bWJlciA9IHZhbHVlID0+ICFOdW1iZXIuaXNOYU4ocGFyc2VGbG9hdCh2YWx1ZSkpO1xuICAgICAgaWYgKCFpc1N0cmluZyhwcm9wcykgJiYgIUFycmF5LmlzQXJyYXkocHJvcHMpKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ01VSTogQXJndW1lbnQgXCJwcm9wc1wiIG11c3QgYmUgYSBzdHJpbmcgb3IgQXJyYXkuJyk7XG4gICAgICB9XG4gICAgICBpZiAoIWlzTnVtYmVyKGR1cmF0aW9uT3B0aW9uKSAmJiAhaXNTdHJpbmcoZHVyYXRpb25PcHRpb24pKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYE1VSTogQXJndW1lbnQgXCJkdXJhdGlvblwiIG11c3QgYmUgYSBudW1iZXIgb3IgYSBzdHJpbmcgYnV0IGZvdW5kICR7ZHVyYXRpb25PcHRpb259LmApO1xuICAgICAgfVxuICAgICAgaWYgKCFpc1N0cmluZyhlYXNpbmdPcHRpb24pKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ01VSTogQXJndW1lbnQgXCJlYXNpbmdcIiBtdXN0IGJlIGEgc3RyaW5nLicpO1xuICAgICAgfVxuICAgICAgaWYgKCFpc051bWJlcihkZWxheSkgJiYgIWlzU3RyaW5nKGRlbGF5KSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdNVUk6IEFyZ3VtZW50IFwiZGVsYXlcIiBtdXN0IGJlIGEgbnVtYmVyIG9yIGEgc3RyaW5nLicpO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zICE9PSAnb2JqZWN0Jykge1xuICAgICAgICBjb25zb2xlLmVycm9yKFsnTVVJOiBTZWNvbmcgYXJndW1lbnQgb2YgdHJhbnNpdGlvbi5jcmVhdGUgbXVzdCBiZSBhbiBvYmplY3QuJywgXCJBcmd1bWVudHMgc2hvdWxkIGJlIGVpdGhlciBgY3JlYXRlKCdwcm9wMScsIG9wdGlvbnMpYCBvciBgY3JlYXRlKFsncHJvcDEnLCAncHJvcDInXSwgb3B0aW9ucylgXCJdLmpvaW4oJ1xcbicpKTtcbiAgICAgIH1cbiAgICAgIGlmIChPYmplY3Qua2V5cyhvdGhlcikubGVuZ3RoICE9PSAwKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYE1VSTogVW5yZWNvZ25pemVkIGFyZ3VtZW50KHMpIFske09iamVjdC5rZXlzKG90aGVyKS5qb2luKCcsJyl9XS5gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIChBcnJheS5pc0FycmF5KHByb3BzKSA/IHByb3BzIDogW3Byb3BzXSkubWFwKGFuaW1hdGVkUHJvcCA9PiBgJHthbmltYXRlZFByb3B9ICR7dHlwZW9mIGR1cmF0aW9uT3B0aW9uID09PSAnc3RyaW5nJyA/IGR1cmF0aW9uT3B0aW9uIDogZm9ybWF0TXMoZHVyYXRpb25PcHRpb24pfSAke2Vhc2luZ09wdGlvbn0gJHt0eXBlb2YgZGVsYXkgPT09ICdzdHJpbmcnID8gZGVsYXkgOiBmb3JtYXRNcyhkZWxheSl9YCkuam9pbignLCcpO1xuICB9O1xuICBjb25zdCBjcmVhdGUgPSB0cmFuc2l0aW9ucy5jcmVhdGUgPz8gY3JlYXRlVHJhbnNpdGlvblZhbHVlO1xuICByZXR1cm4ge1xuICAgIGdldEF1dG9IZWlnaHREdXJhdGlvbixcbiAgICBjcmVhdGUsXG4gICAgLi4udHJhbnNpdGlvbnMsXG4gICAgZWFzaW5nOiBtZXJnZWRFYXNpbmcsXG4gICAgZHVyYXRpb246IG1lcmdlZER1cmF0aW9uXG4gIH07XG59IiwiY29uc3QgRU1QVFlfTU9USU9OID0ge307XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjcmVhdGVNb3Rpb24oaW5wdXRNb3Rpb24gPSBFTVBUWV9NT1RJT04pIHtcbiAgcmV0dXJuIHtcbiAgICByZWR1Y2VkTW90aW9uOiAnbmV2ZXInLFxuICAgIC4uLmlucHV0TW90aW9uXG4gIH07XG59IiwiLy8gV2UgbmVlZCB0byBjZW50cmFsaXplIHRoZSB6SW5kZXggZGVmaW5pdGlvbnMgYXMgdGhleSB3b3JrXG4vLyBsaWtlIGdsb2JhbCB2YWx1ZXMgaW4gdGhlIGJyb3dzZXIuXG5jb25zdCB6SW5kZXggPSB7XG4gIG1vYmlsZVN0ZXBwZXI6IDEwMDAsXG4gIGZhYjogMTA1MCxcbiAgc3BlZWREaWFsOiAxMDUwLFxuICBhcHBCYXI6IDExMDAsXG4gIGRyYXdlcjogMTIwMCxcbiAgbW9kYWw6IDEzMDAsXG4gIHNuYWNrYmFyOiAxNDAwLFxuICB0b29sdGlwOiAxNTAwXG59O1xuZXhwb3J0IGRlZmF1bHQgekluZGV4OyIsIi8qIGVzbGludC1kaXNhYmxlIGltcG9ydC9wcmVmZXItZGVmYXVsdC1leHBvcnQgKi9cbmltcG9ydCB7IGlzUGxhaW5PYmplY3QgfSBmcm9tICdAbXVpL3V0aWxzL2RlZXBtZXJnZSc7XG5mdW5jdGlvbiBpc1NlcmlhbGl6YWJsZSh2YWwpIHtcbiAgcmV0dXJuIGlzUGxhaW5PYmplY3QodmFsKSB8fCB0eXBlb2YgdmFsID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgdmFsID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsID09PSAnYm9vbGVhbicgfHwgdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgfHwgQXJyYXkuaXNBcnJheSh2YWwpO1xufVxuXG4vKipcbiAqIGBiYXNlVGhlbWVgIHVzdWFsbHkgY29tZXMgZnJvbSBgY3JlYXRlVGhlbWUoKWAgb3IgYGV4dGVuZFRoZW1lKClgLlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gaXMgaW50ZW5kZWQgdG8gYmUgdXNlZCB3aXRoIHplcm8tcnVudGltZSBDU1MtaW4tSlMgbGlrZSBQaWdtZW50IENTU1xuICogRm9yIGV4YW1wbGUsIGluIGEgTmV4dC5qcyBwcm9qZWN0OlxuICpcbiAqIGBgYGpzXG4gKiAvLyBuZXh0LmNvbmZpZy5qc1xuICogY29uc3QgeyBleHRlbmRUaGVtZSB9ID0gcmVxdWlyZSgnQG11aS9tYXRlcmlhbC9zdHlsZXMnKTtcbiAqXG4gKiBjb25zdCB0aGVtZSA9IGV4dGVuZFRoZW1lKCk7XG4gKiAvLyBgLnRvUnVudGltZVNvdXJjZWAgaXMgUGlnbWVudCBDU1Mgc3BlY2lmaWMgdG8gY3JlYXRlIGEgdGhlbWUgdGhhdCBpcyBhdmFpbGFibGUgYXQgcnVudGltZS5cbiAqIHRoZW1lLnRvUnVudGltZVNvdXJjZSA9IHN0cmluZ2lmeVRoZW1lO1xuICpcbiAqIG1vZHVsZS5leHBvcnRzID0gd2l0aFBpZ21lbnQoe1xuICogIHRoZW1lLFxuICogfSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN0cmluZ2lmeVRoZW1lKGJhc2VUaGVtZSA9IHt9KSB7XG4gIGNvbnN0IHNlcmlhbGl6YWJsZVRoZW1lID0ge1xuICAgIC4uLmJhc2VUaGVtZVxuICB9O1xuICBmdW5jdGlvbiBzZXJpYWxpemVUaGVtZShvYmplY3QpIHtcbiAgICBjb25zdCBhcnJheSA9IE9iamVjdC5lbnRyaWVzKG9iamVjdCk7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBsdXNwbHVzXG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGFycmF5Lmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgY29uc3QgW2tleSwgdmFsdWVdID0gYXJyYXlbaW5kZXhdO1xuICAgICAgaWYgKCFpc1NlcmlhbGl6YWJsZSh2YWx1ZSkgfHwga2V5LnN0YXJ0c1dpdGgoJ3Vuc3RhYmxlXycpIHx8IGtleS5zdGFydHNXaXRoKCdpbnRlcm5hbF8nKSkge1xuICAgICAgICBkZWxldGUgb2JqZWN0W2tleV07XG4gICAgICB9IGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsdWUpKSB7XG4gICAgICAgIG9iamVjdFtrZXldID0ge1xuICAgICAgICAgIC4uLnZhbHVlXG4gICAgICAgIH07XG4gICAgICAgIHNlcmlhbGl6ZVRoZW1lKG9iamVjdFtrZXldKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc2VyaWFsaXplVGhlbWUoc2VyaWFsaXphYmxlVGhlbWUpO1xuICByZXR1cm4gYGltcG9ydCB7IHVuc3RhYmxlX2NyZWF0ZUJyZWFrcG9pbnRzIGFzIGNyZWF0ZUJyZWFrcG9pbnRzLCBjcmVhdGVUcmFuc2l0aW9ucyB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvc3R5bGVzJztcblxuY29uc3QgdGhlbWUgPSAke0pTT04uc3RyaW5naWZ5KHNlcmlhbGl6YWJsZVRoZW1lLCBudWxsLCAyKX07XG5cbnRoZW1lLmJyZWFrcG9pbnRzID0gY3JlYXRlQnJlYWtwb2ludHModGhlbWUuYnJlYWtwb2ludHMgfHwge30pO1xudGhlbWUubW90aW9uID0geyByZWR1Y2VkTW90aW9uOiAnbmV2ZXInLCAuLi50aGVtZS5tb3Rpb24gfTtcbnRoZW1lLnRyYW5zaXRpb25zID0gY3JlYXRlVHJhbnNpdGlvbnModGhlbWUudHJhbnNpdGlvbnMgfHwge30pO1xuXG5leHBvcnQgZGVmYXVsdCB0aGVtZTtgO1xufSIsImltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAbXVpL3V0aWxzL2Zvcm1hdE11aUVycm9yTWVzc2FnZVwiO1xuaW1wb3J0IGRlZXBtZXJnZSBmcm9tICdAbXVpL3V0aWxzL2RlZXBtZXJnZSc7XG5pbXBvcnQgc3R5bGVGdW5jdGlvblN4LCB7IHVuc3RhYmxlX2RlZmF1bHRTeENvbmZpZyBhcyBkZWZhdWx0U3hDb25maWcgfSBmcm9tICdAbXVpL3N5c3RlbS9zdHlsZUZ1bmN0aW9uU3gnO1xuaW1wb3J0IHN5c3RlbUNyZWF0ZVRoZW1lIGZyb20gJ0BtdWkvc3lzdGVtL2NyZWF0ZVRoZW1lJztcbmltcG9ydCB7IGFscGhhIGFzIHN5c3RlbUFscGhhLCBsaWdodGVuIGFzIHN5c3RlbUxpZ2h0ZW4sIGRhcmtlbiBhcyBzeXN0ZW1EYXJrZW4gfSBmcm9tICdAbXVpL3N5c3RlbS9jb2xvck1hbmlwdWxhdG9yJztcbmltcG9ydCBnZW5lcmF0ZVV0aWxpdHlDbGFzcyBmcm9tICdAbXVpL3V0aWxzL2dlbmVyYXRlVXRpbGl0eUNsYXNzJztcbmltcG9ydCBjcmVhdGVNaXhpbnMgZnJvbSBcIi4vY3JlYXRlTWl4aW5zLm1qc1wiO1xuaW1wb3J0IGNyZWF0ZVBhbGV0dGUgZnJvbSBcIi4vY3JlYXRlUGFsZXR0ZS5tanNcIjtcbmltcG9ydCBjcmVhdGVUeXBvZ3JhcGh5IGZyb20gXCIuL2NyZWF0ZVR5cG9ncmFwaHkubWpzXCI7XG5pbXBvcnQgc2hhZG93cyBmcm9tIFwiLi9zaGFkb3dzLm1qc1wiO1xuaW1wb3J0IGNyZWF0ZVRyYW5zaXRpb25zIGZyb20gXCIuL2NyZWF0ZVRyYW5zaXRpb25zLm1qc1wiO1xuaW1wb3J0IGNyZWF0ZU1vdGlvbiBmcm9tIFwiLi9jcmVhdGVNb3Rpb24ubWpzXCI7XG5pbXBvcnQgekluZGV4IGZyb20gXCIuL3pJbmRleC5tanNcIjtcbmltcG9ydCB7IHN0cmluZ2lmeVRoZW1lIH0gZnJvbSBcIi4vc3RyaW5naWZ5VGhlbWUubWpzXCI7XG5mdW5jdGlvbiBjb2VmZmljaWVudFRvUGVyY2VudGFnZShjb2VmZmljaWVudCkge1xuICBpZiAodHlwZW9mIGNvZWZmaWNpZW50ID09PSAnbnVtYmVyJykge1xuICAgIHJldHVybiBgJHsoY29lZmZpY2llbnQgKiAxMDApLnRvRml4ZWQoMCl9JWA7XG4gIH1cbiAgcmV0dXJuIGBjYWxjKCgke2NvZWZmaWNpZW50fSkgKiAxMDAlKWA7XG59XG5cbi8vIFRoaXMgY2FuIGJlIHJlbW92ZWQgd2hlbiBtb3ZlZCB0byBgY29sb3ItbWl4KClgIGVudGlyZWx5LlxuY29uc3QgcGFyc2VBZGRpdGlvbiA9IHN0ciA9PiB7XG4gIGlmICghTnVtYmVyLmlzTmFOKCtzdHIpKSB7XG4gICAgcmV0dXJuICtzdHI7XG4gIH1cbiAgY29uc3QgbnVtYmVycyA9IHN0ci5tYXRjaCgvXFxkKlxcLj9cXGQrL2cpO1xuICBpZiAoIW51bWJlcnMpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICBsZXQgc3VtID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1iZXJzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgc3VtICs9ICtudW1iZXJzW2ldO1xuICB9XG4gIHJldHVybiBzdW07XG59O1xuZnVuY3Rpb24gYXR0YWNoQ29sb3JNYW5pcHVsYXRvcnModGhlbWUpIHtcbiAgT2JqZWN0LmFzc2lnbih0aGVtZSwge1xuICAgIGFscGhhKGNvbG9yLCBjb2VmZmljaWVudCkge1xuICAgICAgY29uc3Qgb2JqID0gdGhpcyB8fCB0aGVtZTtcbiAgICAgIGlmIChvYmouY29sb3JTcGFjZSkge1xuICAgICAgICByZXR1cm4gYG9rbGNoKGZyb20gJHtjb2xvcn0gbCBjIGggLyAke3R5cGVvZiBjb2VmZmljaWVudCA9PT0gJ3N0cmluZycgPyBgY2FsYygke2NvZWZmaWNpZW50fSlgIDogY29lZmZpY2llbnR9KWA7XG4gICAgICB9XG4gICAgICBpZiAob2JqLnZhcnMpIHtcbiAgICAgICAgLy8gVG8gcHJlc2VydmUgdGhlIGJlaGF2aW9yIG9mIHRoZSBDU1MgdGhlbWUgdmFyaWFibGVzXG4gICAgICAgIC8vIEluIHRoZSBmdXR1cmUsIHRoaXMgY291bGQgYmUgcmVwbGFjZWQgYnkgYGNvbG9yLW1peGAgKHdoZW4gaHR0cHM6Ly9jYW5pdXNlLmNvbS8/c2VhcmNoPWNvbG9yLW1peCByZWFjaGVzIDk1JSkuXG4gICAgICAgIHJldHVybiBgcmdiYSgke2NvbG9yLnJlcGxhY2UoL3ZhclxcKC0tKFteLFxccyldKykoPzosW14pXSspP1xcKSsvZywgJ3ZhcigtLSQxQ2hhbm5lbCknKX0gLyAke3R5cGVvZiBjb2VmZmljaWVudCA9PT0gJ3N0cmluZycgPyBgY2FsYygke2NvZWZmaWNpZW50fSlgIDogY29lZmZpY2llbnR9KWA7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3lzdGVtQWxwaGEoY29sb3IsIHBhcnNlQWRkaXRpb24oY29lZmZpY2llbnQpKTtcbiAgICB9LFxuICAgIGxpZ2h0ZW4oY29sb3IsIGNvZWZmaWNpZW50KSB7XG4gICAgICBjb25zdCBvYmogPSB0aGlzIHx8IHRoZW1lO1xuICAgICAgaWYgKG9iai5jb2xvclNwYWNlKSB7XG4gICAgICAgIHJldHVybiBgY29sb3ItbWl4KGluICR7b2JqLmNvbG9yU3BhY2V9LCAke2NvbG9yfSwgI2ZmZiAke2NvZWZmaWNpZW50VG9QZXJjZW50YWdlKGNvZWZmaWNpZW50KX0pYDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzeXN0ZW1MaWdodGVuKGNvbG9yLCBjb2VmZmljaWVudCk7XG4gICAgfSxcbiAgICBkYXJrZW4oY29sb3IsIGNvZWZmaWNpZW50KSB7XG4gICAgICBjb25zdCBvYmogPSB0aGlzIHx8IHRoZW1lO1xuICAgICAgaWYgKG9iai5jb2xvclNwYWNlKSB7XG4gICAgICAgIHJldHVybiBgY29sb3ItbWl4KGluICR7b2JqLmNvbG9yU3BhY2V9LCAke2NvbG9yfSwgIzAwMCAke2NvZWZmaWNpZW50VG9QZXJjZW50YWdlKGNvZWZmaWNpZW50KX0pYDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzeXN0ZW1EYXJrZW4oY29sb3IsIGNvZWZmaWNpZW50KTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlVGhlbWVOb1ZhcnMob3B0aW9ucyA9IHt9LCAuLi5hcmdzKSB7XG4gIGNvbnN0IHtcbiAgICBicmVha3BvaW50czogYnJlYWtwb2ludHNJbnB1dCxcbiAgICBtaXhpbnM6IG1peGluc0lucHV0ID0ge30sXG4gICAgc3BhY2luZzogc3BhY2luZ0lucHV0LFxuICAgIHBhbGV0dGU6IHBhbGV0dGVJbnB1dCA9IHt9LFxuICAgIG1vdGlvbjogbW90aW9uSW5wdXQgPSB7fSxcbiAgICB0cmFuc2l0aW9uczogdHJhbnNpdGlvbnNJbnB1dCA9IHt9LFxuICAgIHR5cG9ncmFwaHk6IHR5cG9ncmFwaHlJbnB1dCA9IHt9LFxuICAgIHNoYXBlOiBzaGFwZUlucHV0LFxuICAgIGNvbG9yU3BhY2UsXG4gICAgLi4ub3RoZXJcbiAgfSA9IG9wdGlvbnM7XG4gIGlmIChvcHRpb25zLnZhcnMgJiZcbiAgLy8gVGhlIGVycm9yIHNob3VsZCB0aHJvdyBvbmx5IGZvciB0aGUgcm9vdCB0aGVtZSBjcmVhdGlvbiBiZWNhdXNlIHVzZXIgaXMgbm90IGFsbG93ZWQgdG8gdXNlIGEgY3VzdG9tIG5vZGUgYHZhcnNgLlxuICAvLyBgZ2VuZXJhdGVUaGVtZVZhcnNgIGlzIHRoZSBjbG9zZXN0IGlkZW50aWZpZXIgZm9yIGNoZWNraW5nIHRoYXQgdGhlIGBvcHRpb25zYCBpcyBhIHJlc3VsdCBvZiBgY3JlYXRlVGhlbWVgIHdpdGggQ1NTIHZhcmlhYmxlcyBzbyB0aGF0IHVzZXIgY2FuIGNyZWF0ZSBuZXcgdGhlbWUgZm9yIG5lc3RlZCBUaGVtZVByb3ZpZGVyLlxuICBvcHRpb25zLmdlbmVyYXRlVGhlbWVWYXJzID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ01VSTogYHZhcnNgIGlzIGEgcHJpdmF0ZSBmaWVsZCB1c2VkIGZvciBDU1MgdmFyaWFibGVzIHN1cHBvcnQuXFxuJyArXG4gICAgLy8gI2hvc3QtcmVmZXJlbmNlXG4gICAgJ1BsZWFzZSB1c2UgYW5vdGhlciBuYW1lIG9yIGZvbGxvdyB0aGUgW2RvY3NdKGh0dHBzOi8vbXVpLmNvbS9tYXRlcmlhbC11aS9jdXN0b21pemF0aW9uL2Nzcy10aGVtZS12YXJpYWJsZXMvdXNhZ2UvKSB0byBlbmFibGUgdGhlIGZlYXR1cmUuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMjIpKTtcbiAgfVxuICBjb25zdCBwYWxldHRlID0gY3JlYXRlUGFsZXR0ZSh7XG4gICAgLi4ucGFsZXR0ZUlucHV0LFxuICAgIGNvbG9yU3BhY2VcbiAgfSk7XG4gIGNvbnN0IHN5c3RlbVRoZW1lID0gc3lzdGVtQ3JlYXRlVGhlbWUob3B0aW9ucyk7XG4gIGxldCBtdWlUaGVtZSA9IGRlZXBtZXJnZShzeXN0ZW1UaGVtZSwge1xuICAgIG1peGluczogY3JlYXRlTWl4aW5zKHN5c3RlbVRoZW1lLmJyZWFrcG9pbnRzLCBtaXhpbnNJbnB1dCksXG4gICAgcGFsZXR0ZSxcbiAgICAvLyBEb24ndCB1c2UgWy4uLnNoYWRvd3NdIHVudGlsIHlvdSd2ZSB2ZXJpZmllZCBpdHMgdHJhbnNwaWxlZCBjb2RlIGlzIG5vdCBpbnZva2luZyB0aGUgaXRlcmF0b3IgcHJvdG9jb2wuXG4gICAgc2hhZG93czogc2hhZG93cy5zbGljZSgpLFxuICAgIHR5cG9ncmFwaHk6IGNyZWF0ZVR5cG9ncmFwaHkocGFsZXR0ZSwgdHlwb2dyYXBoeUlucHV0KSxcbiAgICBtb3Rpb246IGNyZWF0ZU1vdGlvbihtb3Rpb25JbnB1dCksXG4gICAgdHJhbnNpdGlvbnM6IGNyZWF0ZVRyYW5zaXRpb25zKHRyYW5zaXRpb25zSW5wdXQpLFxuICAgIHpJbmRleDoge1xuICAgICAgLi4uekluZGV4XG4gICAgfVxuICB9KTtcbiAgbXVpVGhlbWUgPSBkZWVwbWVyZ2UobXVpVGhlbWUsIG90aGVyKTtcbiAgbXVpVGhlbWUgPSBhcmdzLnJlZHVjZSgoYWNjLCBhcmd1bWVudCkgPT4gZGVlcG1lcmdlKGFjYywgYXJndW1lbnQpLCBtdWlUaGVtZSk7XG4gIC8vIGByZWR1Y2VkTW90aW9uYCBpcyBvd25lZCBieSBgdGhlbWUubW90aW9uYDsgcmVtb3ZlIHN0YWxlIHZhbHVlcyBwcmVzZXJ2ZWQgYnkgc3lzdGVtQ3JlYXRlVGhlbWUuXG4gIGRlbGV0ZSBtdWlUaGVtZS50cmFuc2l0aW9ucy5yZWR1Y2VkTW90aW9uO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIC8vIFRPRE8gdjY6IFJlZmFjdG9yIHRvIHVzZSBnbG9iYWxTdGF0ZUNsYXNzZXNNYXBwaW5nIGZyb20gQG11aS91dGlscyBvbmNlIGByZWFkT25seWAgc3RhdGUgY2xhc3MgaXMgdXNlZCBpbiBSYXRpbmcgY29tcG9uZW50LlxuICAgIGNvbnN0IHN0YXRlQ2xhc3NlcyA9IFsnYWN0aXZlJywgJ2NoZWNrZWQnLCAnY29tcGxldGVkJywgJ2Rpc2FibGVkJywgJ2Vycm9yJywgJ2V4cGFuZGVkJywgJ2ZvY3VzZWQnLCAnZm9jdXNWaXNpYmxlJywgJ3JlcXVpcmVkJywgJ3NlbGVjdGVkJ107XG4gICAgY29uc3QgdHJhdmVyc2UgPSAobm9kZSwgY29tcG9uZW50KSA9PiB7XG4gICAgICBsZXQga2V5O1xuXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZ3VhcmQtZm9yLWluXG4gICAgICBmb3IgKGtleSBpbiBub2RlKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gbm9kZVtrZXldO1xuICAgICAgICBpZiAoc3RhdGVDbGFzc2VzLmluY2x1ZGVzKGtleSkgJiYgT2JqZWN0LmtleXMoY2hpbGQpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgY29uc3Qgc3RhdGVDbGFzcyA9IGdlbmVyYXRlVXRpbGl0eUNsYXNzKCcnLCBrZXkpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihbYE1VSTogVGhlIFxcYCR7Y29tcG9uZW50fVxcYCBjb21wb25lbnQgaW5jcmVhc2VzIGAgKyBgdGhlIENTUyBzcGVjaWZpY2l0eSBvZiB0aGUgXFxgJHtrZXl9XFxgIGludGVybmFsIHN0YXRlLmAsICdZb3UgY2FuIG5vdCBvdmVycmlkZSBpdCBsaWtlIHRoaXM6ICcsIEpTT04uc3RyaW5naWZ5KG5vZGUsIG51bGwsIDIpLCAnJywgYEluc3RlYWQsIHlvdSBuZWVkIHRvIHVzZSB0aGUgJyYuJHtzdGF0ZUNsYXNzfScgc3ludGF4OmAsIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgcm9vdDoge1xuICAgICAgICAgICAgICAgIFtgJi4ke3N0YXRlQ2xhc3N9YF06IGNoaWxkXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIG51bGwsIDIpLCAnJywgJ2h0dHBzOi8vbXVpLmNvbS9yL3N0YXRlLWNsYXNzZXMtZ3VpZGUnXS5qb2luKCdcXG4nKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIFJlbW92ZSB0aGUgc3R5bGUgdG8gcHJldmVudCBnbG9iYWwgY29uZmxpY3RzLlxuICAgICAgICAgIG5vZGVba2V5XSA9IHt9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBPYmplY3Qua2V5cyhtdWlUaGVtZS5jb21wb25lbnRzKS5mb3JFYWNoKGNvbXBvbmVudCA9PiB7XG4gICAgICBjb25zdCBzdHlsZU92ZXJyaWRlcyA9IG11aVRoZW1lLmNvbXBvbmVudHNbY29tcG9uZW50XS5zdHlsZU92ZXJyaWRlcztcbiAgICAgIGlmIChzdHlsZU92ZXJyaWRlcyAmJiBjb21wb25lbnQuc3RhcnRzV2l0aCgnTXVpJykpIHtcbiAgICAgICAgdHJhdmVyc2Uoc3R5bGVPdmVycmlkZXMsIGNvbXBvbmVudCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbXVpVGhlbWUudW5zdGFibGVfc3hDb25maWcgPSB7XG4gICAgLi4uZGVmYXVsdFN4Q29uZmlnLFxuICAgIC4uLm90aGVyPy51bnN0YWJsZV9zeENvbmZpZ1xuICB9O1xuICBtdWlUaGVtZS51bnN0YWJsZV9zeCA9IGZ1bmN0aW9uIHN4KHByb3BzKSB7XG4gICAgcmV0dXJuIHN0eWxlRnVuY3Rpb25TeCh7XG4gICAgICBzeDogcHJvcHMsXG4gICAgICB0aGVtZTogdGhpc1xuICAgIH0pO1xuICB9O1xuICBtdWlUaGVtZS50b1J1bnRpbWVTb3VyY2UgPSBzdHJpbmdpZnlUaGVtZTsgLy8gZm9yIFBpZ21lbnQgQ1NTIGludGVncmF0aW9uXG5cbiAgYXR0YWNoQ29sb3JNYW5pcHVsYXRvcnMobXVpVGhlbWUpO1xuICByZXR1cm4gbXVpVGhlbWU7XG59XG5leHBvcnQgZGVmYXVsdCBjcmVhdGVUaGVtZU5vVmFyczsiLCIvLyBJbnNwaXJlZCBieSBodHRwczovL2dpdGh1Yi5jb20vbWF0ZXJpYWwtY29tcG9uZW50cy9tYXRlcmlhbC1jb21wb25lbnRzLWlvcy9ibG9iL2JjYTM2MTA3NDA1NTk0ZDViN2IxNjI2NWE1YjBlZDY5OGY4NWE1ZWUvY29tcG9uZW50cy9FbGV2YXRpb24vc3JjL1VJQ29sb3IlMkJNYXRlcmlhbEVsZXZhdGlvbi5tI0w2MVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0T3ZlcmxheUFscGhhKGVsZXZhdGlvbikge1xuICBsZXQgYWxwaGFWYWx1ZTtcbiAgaWYgKGVsZXZhdGlvbiA8IDEpIHtcbiAgICBhbHBoYVZhbHVlID0gNS4xMTkxNiAqIGVsZXZhdGlvbiAqKiAyO1xuICB9IGVsc2Uge1xuICAgIGFscGhhVmFsdWUgPSA0LjUgKiBNYXRoLmxvZyhlbGV2YXRpb24gKyAxKSArIDI7XG4gIH1cbiAgcmV0dXJuIE1hdGgucm91bmQoYWxwaGFWYWx1ZSAqIDEwKSAvIDEwMDA7XG59IiwiaW1wb3J0IGNyZWF0ZVBhbGV0dGUgZnJvbSBcIi4vY3JlYXRlUGFsZXR0ZS5tanNcIjtcbmltcG9ydCBnZXRPdmVybGF5QWxwaGEgZnJvbSBcIi4vZ2V0T3ZlcmxheUFscGhhLm1qc1wiO1xuY29uc3QgZGVmYXVsdERhcmtPdmVybGF5cyA9IFsuLi5BcnJheSgyNSldLm1hcCgoXywgaW5kZXgpID0+IHtcbiAgaWYgKGluZGV4ID09PSAwKSB7XG4gICAgcmV0dXJuICdub25lJztcbiAgfVxuICBjb25zdCBvdmVybGF5ID0gZ2V0T3ZlcmxheUFscGhhKGluZGV4KTtcbiAgcmV0dXJuIGBsaW5lYXItZ3JhZGllbnQocmdiYSgyNTUgMjU1IDI1NSAvICR7b3ZlcmxheX0pLCByZ2JhKDI1NSAyNTUgMjU1IC8gJHtvdmVybGF5fSkpYDtcbn0pO1xuZXhwb3J0IGZ1bmN0aW9uIGdldE9wYWNpdHkobW9kZSkge1xuICByZXR1cm4ge1xuICAgIGlucHV0UGxhY2Vob2xkZXI6IG1vZGUgPT09ICdkYXJrJyA/IDAuNSA6IDAuNDIsXG4gICAgaW5wdXRVbmRlcmxpbmU6IG1vZGUgPT09ICdkYXJrJyA/IDAuNyA6IDAuNDIsXG4gICAgc3dpdGNoVHJhY2tEaXNhYmxlZDogbW9kZSA9PT0gJ2RhcmsnID8gMC4yIDogMC4xMixcbiAgICBzd2l0Y2hUcmFjazogbW9kZSA9PT0gJ2RhcmsnID8gMC4zIDogMC4zOFxuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldE92ZXJsYXlzKG1vZGUpIHtcbiAgcmV0dXJuIG1vZGUgPT09ICdkYXJrJyA/IGRlZmF1bHREYXJrT3ZlcmxheXMgOiBbXTtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZUNvbG9yU2NoZW1lKG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHBhbGV0dGU6IHBhbGV0dGVJbnB1dCA9IHtcbiAgICAgIG1vZGU6ICdsaWdodCdcbiAgICB9LFxuICAgIC8vIG5lZWQgdG8gY2FzdCB0byBhdm9pZCBtb2R1bGUgYXVnbWVudGF0aW9uIHRlc3RcbiAgICBvcGFjaXR5LFxuICAgIG92ZXJsYXlzLFxuICAgIGNvbG9yU3BhY2UsXG4gICAgLi4ub3RoZXJcbiAgfSA9IG9wdGlvbnM7XG4gIC8vIG5lZWQgdG8gY2FzdCBiZWNhdXNlIGBjb2xvclNwYWNlYCBpcyBjb25zaWRlcmVkIGludGVybmFsIGF0IHRoZSBtb21lbnQuXG4gIGNvbnN0IHBhbGV0dGUgPSBjcmVhdGVQYWxldHRlKHtcbiAgICAuLi5wYWxldHRlSW5wdXQsXG4gICAgY29sb3JTcGFjZVxuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBwYWxldHRlLFxuICAgIG9wYWNpdHk6IHtcbiAgICAgIC4uLmdldE9wYWNpdHkocGFsZXR0ZS5tb2RlKSxcbiAgICAgIC4uLm9wYWNpdHlcbiAgICB9LFxuICAgIG92ZXJsYXlzOiBvdmVybGF5cyB8fCBnZXRPdmVybGF5cyhwYWxldHRlLm1vZGUpLFxuICAgIC4uLm90aGVyXG4gIH07XG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXIoa2V5cykge1xuICByZXR1cm4ga2V5c1swXSA9PT0gJ21vdGlvbicgfHwgISFrZXlzWzBdLm1hdGNoKC8oY3NzVmFyUHJlZml4fGNvbG9yU2NoZW1lU2VsZWN0b3J8bW9kdWxhckNzc0xheWVyc3xyb290U2VsZWN0b3J8dHlwb2dyYXBoeXxtaXhpbnN8YnJlYWtwb2ludHN8ZGlyZWN0aW9ufHRyYW5zaXRpb25zKS8pIHx8ICEha2V5c1swXS5tYXRjaCgvc3hDb25maWckLykgfHxcbiAgLy8gZW5kcyB3aXRoIHN4Q29uZmlnXG4gIGtleXNbMF0gPT09ICdwYWxldHRlJyAmJiAhIWtleXNbMV0/Lm1hdGNoKC8obW9kZXxjb250cmFzdFRocmVzaG9sZHx0b25hbE9mZnNldCkvKTtcbn0iLCIvKipcbiAqIEBpbnRlcm5hbCBUaGVzZSB2YXJpYWJsZXMgc2hvdWxkIG5vdCBhcHBlYXIgaW4gdGhlIDpyb290IHN0eWxlc2hlZXQgd2hlbiB0aGUgYGRlZmF1bHRDb2xvclNjaGVtZT1cImRhcmtcImBcbiAqL1xuY29uc3QgZXhjbHVkZVZhcmlhYmxlc0Zyb21Sb290ID0gY3NzVmFyUHJlZml4ID0+IFsuLi5bLi4uQXJyYXkoMjUpXS5tYXAoKF8sIGluZGV4KSA9PiBgLS0ke2Nzc1ZhclByZWZpeCA/IGAke2Nzc1ZhclByZWZpeH0tYCA6ICcnfW92ZXJsYXlzLSR7aW5kZXh9YCksIGAtLSR7Y3NzVmFyUHJlZml4ID8gYCR7Y3NzVmFyUHJlZml4fS1gIDogJyd9cGFsZXR0ZS1BcHBCYXItZGFya0JnYCwgYC0tJHtjc3NWYXJQcmVmaXggPyBgJHtjc3NWYXJQcmVmaXh9LWAgOiAnJ31wYWxldHRlLUFwcEJhci1kYXJrQ29sb3JgXTtcbmV4cG9ydCBkZWZhdWx0IGV4Y2x1ZGVWYXJpYWJsZXNGcm9tUm9vdDsiLCJpbXBvcnQgZXhjbHVkZVZhcmlhYmxlc0Zyb21Sb290IGZyb20gXCIuL2V4Y2x1ZGVWYXJpYWJsZXNGcm9tUm9vdC5tanNcIjtcbmV4cG9ydCBkZWZhdWx0IHRoZW1lID0+IChjb2xvclNjaGVtZSwgY3NzKSA9PiB7XG4gIGNvbnN0IHJvb3QgPSB0aGVtZS5yb290U2VsZWN0b3IgfHwgJzpyb290JztcbiAgY29uc3Qgc2VsZWN0b3IgPSB0aGVtZS5jb2xvclNjaGVtZVNlbGVjdG9yO1xuICBsZXQgcnVsZSA9IHNlbGVjdG9yO1xuICBpZiAoc2VsZWN0b3IgPT09ICdjbGFzcycpIHtcbiAgICBydWxlID0gJy4lcyc7XG4gIH1cbiAgaWYgKHNlbGVjdG9yID09PSAnZGF0YScpIHtcbiAgICBydWxlID0gJ1tkYXRhLSVzXSc7XG4gIH1cbiAgaWYgKHNlbGVjdG9yPy5zdGFydHNXaXRoKCdkYXRhLScpICYmICFzZWxlY3Rvci5pbmNsdWRlcygnJXMnKSkge1xuICAgIC8vICdkYXRhLW11aS1jb2xvci1zY2hlbWUnIC0+ICdbZGF0YS1tdWktY29sb3Itc2NoZW1lPVwiJXNcIl0nXG4gICAgcnVsZSA9IGBbJHtzZWxlY3Rvcn09XCIlc1wiXWA7XG4gIH1cbiAgaWYgKHRoZW1lLmRlZmF1bHRDb2xvclNjaGVtZSA9PT0gY29sb3JTY2hlbWUpIHtcbiAgICBpZiAoY29sb3JTY2hlbWUgPT09ICdkYXJrJykge1xuICAgICAgY29uc3QgZXhjbHVkZWRWYXJpYWJsZXMgPSB7fTtcbiAgICAgIGV4Y2x1ZGVWYXJpYWJsZXNGcm9tUm9vdCh0aGVtZS5jc3NWYXJQcmVmaXgpLmZvckVhY2goY3NzVmFyID0+IHtcbiAgICAgICAgZXhjbHVkZWRWYXJpYWJsZXNbY3NzVmFyXSA9IGNzc1tjc3NWYXJdO1xuICAgICAgICBkZWxldGUgY3NzW2Nzc1Zhcl07XG4gICAgICB9KTtcbiAgICAgIGlmIChydWxlID09PSAnbWVkaWEnKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgW3Jvb3RdOiBjc3MsXG4gICAgICAgICAgW2BAbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKWBdOiB7XG4gICAgICAgICAgICBbcm9vdF06IGV4Y2x1ZGVkVmFyaWFibGVzXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKHJ1bGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBbcnVsZS5yZXBsYWNlKCclcycsIGNvbG9yU2NoZW1lKV06IGV4Y2x1ZGVkVmFyaWFibGVzLFxuICAgICAgICAgIFtgJHtyb290fSwgJHtydWxlLnJlcGxhY2UoJyVzJywgY29sb3JTY2hlbWUpfWBdOiBjc3NcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIFtyb290XToge1xuICAgICAgICAgIC4uLmNzcyxcbiAgICAgICAgICAuLi5leGNsdWRlZFZhcmlhYmxlc1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAocnVsZSAmJiBydWxlICE9PSAnbWVkaWEnKSB7XG4gICAgICByZXR1cm4gYCR7cm9vdH0sICR7cnVsZS5yZXBsYWNlKCclcycsIFN0cmluZyhjb2xvclNjaGVtZSkpfWA7XG4gICAgfVxuICB9IGVsc2UgaWYgKGNvbG9yU2NoZW1lKSB7XG4gICAgaWYgKHJ1bGUgPT09ICdtZWRpYScpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIFtgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogJHtTdHJpbmcoY29sb3JTY2hlbWUpfSlgXToge1xuICAgICAgICAgIFtyb290XTogY3NzXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChydWxlKSB7XG4gICAgICByZXR1cm4gcnVsZS5yZXBsYWNlKCclcycsIFN0cmluZyhjb2xvclNjaGVtZSkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcm9vdDtcbn07IiwiaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBtdWkvdXRpbHMvZm9ybWF0TXVpRXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgZGVlcG1lcmdlIGZyb20gJ0BtdWkvdXRpbHMvZGVlcG1lcmdlJztcbmltcG9ydCB7IHVuc3RhYmxlX2NyZWF0ZUdldENzc1ZhciBhcyBzeXN0ZW1DcmVhdGVHZXRDc3NWYXIsIGNyZWF0ZVNwYWNpbmcgfSBmcm9tICdAbXVpL3N5c3RlbSc7XG5pbXBvcnQgeyBjcmVhdGVVbmFyeVNwYWNpbmcgfSBmcm9tICdAbXVpL3N5c3RlbS9zcGFjaW5nJztcbmltcG9ydCB7IHByZXBhcmVDc3NWYXJzLCBwcmVwYXJlVHlwb2dyYXBoeVZhcnMsIGNyZWF0ZUdldENvbG9yU2NoZW1lU2VsZWN0b3IgfSBmcm9tICdAbXVpL3N5c3RlbS9jc3NWYXJzJztcbmltcG9ydCBzdHlsZUZ1bmN0aW9uU3gsIHsgdW5zdGFibGVfZGVmYXVsdFN4Q29uZmlnIGFzIGRlZmF1bHRTeENvbmZpZyB9IGZyb20gJ0BtdWkvc3lzdGVtL3N0eWxlRnVuY3Rpb25TeCc7XG5pbXBvcnQgeyBwcml2YXRlX3NhZmVDb2xvckNoYW5uZWwgYXMgc2FmZUNvbG9yQ2hhbm5lbCwgcHJpdmF0ZV9zYWZlQWxwaGEgYXMgc2FmZUFscGhhLCBwcml2YXRlX3NhZmVEYXJrZW4gYXMgc2FmZURhcmtlbiwgcHJpdmF0ZV9zYWZlTGlnaHRlbiBhcyBzYWZlTGlnaHRlbiwgcHJpdmF0ZV9zYWZlRW1waGFzaXplIGFzIHNhZmVFbXBoYXNpemUsIGhzbFRvUmdiIH0gZnJvbSAnQG11aS9zeXN0ZW0vY29sb3JNYW5pcHVsYXRvcic7XG5pbXBvcnQgY3JlYXRlVGhlbWVOb1ZhcnMgZnJvbSBcIi4vY3JlYXRlVGhlbWVOb1ZhcnMubWpzXCI7XG5pbXBvcnQgY3JlYXRlQ29sb3JTY2hlbWUsIHsgZ2V0T3BhY2l0eSwgZ2V0T3ZlcmxheXMgfSBmcm9tIFwiLi9jcmVhdGVDb2xvclNjaGVtZS5tanNcIjtcbmltcG9ydCBkZWZhdWx0U2hvdWxkU2tpcEdlbmVyYXRpbmdWYXIgZnJvbSBcIi4vc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXIubWpzXCI7XG5pbXBvcnQgZGVmYXVsdEdldFNlbGVjdG9yIGZyb20gXCIuL2NyZWF0ZUdldFNlbGVjdG9yLm1qc1wiO1xuaW1wb3J0IHsgc3RyaW5naWZ5VGhlbWUgfSBmcm9tIFwiLi9zdHJpbmdpZnlUaGVtZS5tanNcIjtcbmltcG9ydCB7IGxpZ2h0LCBkYXJrIH0gZnJvbSBcIi4vY3JlYXRlUGFsZXR0ZS5tanNcIjtcbmZ1bmN0aW9uIGFzc2lnbk5vZGUob2JqLCBrZXlzKSB7XG4gIGtleXMuZm9yRWFjaChrID0+IHtcbiAgICBpZiAoIW9ialtrXSkge1xuICAgICAgb2JqW2tdID0ge307XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIHNldENvbG9yKG9iaiwga2V5LCBkZWZhdWx0VmFsdWUpIHtcbiAgaWYgKCFvYmpba2V5XSAmJiBkZWZhdWx0VmFsdWUpIHtcbiAgICBvYmpba2V5XSA9IGRlZmF1bHRWYWx1ZTtcbiAgfVxufVxuZnVuY3Rpb24gdG9SZ2IoY29sb3IpIHtcbiAgaWYgKHR5cGVvZiBjb2xvciAhPT0gJ3N0cmluZycgfHwgIWNvbG9yLnN0YXJ0c1dpdGgoJ2hzbCcpKSB7XG4gICAgcmV0dXJuIGNvbG9yO1xuICB9XG4gIHJldHVybiBoc2xUb1JnYihjb2xvcik7XG59XG5mdW5jdGlvbiBzZXRDb2xvckNoYW5uZWwob2JqLCBrZXkpIHtcbiAgaWYgKCEoYCR7a2V5fUNoYW5uZWxgIGluIG9iaikpIHtcbiAgICAvLyBjdXN0b20gY2hhbm5lbCB0b2tlbiBpcyBub3QgcHJvdmlkZWQsIGdlbmVyYXRlIG9uZS5cbiAgICAvLyBpZiBjaGFubmVsIHRva2VuIGNhbid0IGJlIGdlbmVyYXRlZCwgc2hvdyBhIHdhcm5pbmcuXG4gICAgb2JqW2Ake2tleX1DaGFubmVsYF0gPSBzYWZlQ29sb3JDaGFubmVsKHRvUmdiKG9ialtrZXldKSwgYE1VSTogQ2FuJ3QgY3JlYXRlIFxcYHBhbGV0dGUuJHtrZXl9Q2hhbm5lbFxcYCBiZWNhdXNlIFxcYHBhbGV0dGUuJHtrZXl9XFxgIGlzIG5vdCBvbmUgb2YgdGhlc2UgZm9ybWF0czogI25ubiwgI25ubm5ubiwgcmdiKCksIHJnYmEoKSwgaHNsKCksIGhzbGEoKSwgY29sb3IoKS5gICsgJ1xcbicgKyBgVG8gc3VwcHJlc3MgdGhpcyB3YXJuaW5nLCB5b3UgbmVlZCB0byBleHBsaWNpdGx5IHByb3ZpZGUgdGhlIFxcYHBhbGV0dGUuJHtrZXl9Q2hhbm5lbFxcYCBhcyBhIHN0cmluZyAoaW4gcmdiIGZvcm1hdCwgZm9yIGV4YW1wbGUgXCIxMiAxMiAxMlwiKSBvciB1bmRlZmluZWQgaWYgeW91IHdhbnQgdG8gcmVtb3ZlIHRoZSBjaGFubmVsIHRva2VuLmApO1xuICB9XG59XG5mdW5jdGlvbiBnZXRTcGFjaW5nVmFsKHNwYWNpbmdJbnB1dCkge1xuICBpZiAodHlwZW9mIHNwYWNpbmdJbnB1dCA9PT0gJ251bWJlcicpIHtcbiAgICByZXR1cm4gYCR7c3BhY2luZ0lucHV0fXB4YDtcbiAgfVxuICBpZiAodHlwZW9mIHNwYWNpbmdJbnB1dCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHNwYWNpbmdJbnB1dCA9PT0gJ2Z1bmN0aW9uJyB8fCBBcnJheS5pc0FycmF5KHNwYWNpbmdJbnB1dCkpIHtcbiAgICByZXR1cm4gc3BhY2luZ0lucHV0O1xuICB9XG4gIHJldHVybiAnOHB4Jztcbn1cbmNvbnN0IHNpbGVudCA9IGZuID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gZm4oKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAvLyBpZ25vcmUgZXJyb3JcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbmV4cG9ydCBjb25zdCBjcmVhdGVHZXRDc3NWYXIgPSAoY3NzVmFyUHJlZml4ID0gJ211aScpID0+IHN5c3RlbUNyZWF0ZUdldENzc1Zhcihjc3NWYXJQcmVmaXgpO1xuZnVuY3Rpb24gYXR0YWNoQ29sb3JTY2hlbWUoY29sb3JTcGFjZSwgY29sb3JTY2hlbWVzLCBzY2hlbWUsIHJlc3RUaGVtZSwgY29sb3JTY2hlbWUpIHtcbiAgaWYgKCFzY2hlbWUpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHNjaGVtZSA9IHNjaGVtZSA9PT0gdHJ1ZSA/IHt9IDogc2NoZW1lO1xuICBjb25zdCBtb2RlID0gY29sb3JTY2hlbWUgPT09ICdkYXJrJyA/ICdkYXJrJyA6ICdsaWdodCc7XG4gIGlmICghcmVzdFRoZW1lKSB7XG4gICAgY29sb3JTY2hlbWVzW2NvbG9yU2NoZW1lXSA9IGNyZWF0ZUNvbG9yU2NoZW1lKHtcbiAgICAgIC4uLnNjaGVtZSxcbiAgICAgIHBhbGV0dGU6IHtcbiAgICAgICAgbW9kZSxcbiAgICAgICAgLi4uc2NoZW1lPy5wYWxldHRlXG4gICAgICB9LFxuICAgICAgY29sb3JTcGFjZVxuICAgIH0pO1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgY29uc3Qge1xuICAgIHBhbGV0dGUsXG4gICAgLi4ubXVpVGhlbWVcbiAgfSA9IGNyZWF0ZVRoZW1lTm9WYXJzKHtcbiAgICAuLi5yZXN0VGhlbWUsXG4gICAgcGFsZXR0ZToge1xuICAgICAgbW9kZSxcbiAgICAgIC4uLnNjaGVtZT8ucGFsZXR0ZVxuICAgIH0sXG4gICAgY29sb3JTcGFjZVxuICB9KTtcbiAgY29sb3JTY2hlbWVzW2NvbG9yU2NoZW1lXSA9IHtcbiAgICAuLi5zY2hlbWUsXG4gICAgcGFsZXR0ZSxcbiAgICBvcGFjaXR5OiB7XG4gICAgICAuLi5nZXRPcGFjaXR5KG1vZGUpLFxuICAgICAgLi4uc2NoZW1lPy5vcGFjaXR5XG4gICAgfSxcbiAgICBvdmVybGF5czogc2NoZW1lPy5vdmVybGF5cyB8fCBnZXRPdmVybGF5cyhtb2RlKVxuICB9O1xuICByZXR1cm4gbXVpVGhlbWU7XG59XG5cbi8qKlxuICogQSBkZWZhdWx0IGBjcmVhdGVUaGVtZVdpdGhWYXJzYCBjb21lcyB3aXRoIGEgc2luZ2xlIGNvbG9yIHNjaGVtZSwgZWl0aGVyIGBsaWdodGAgb3IgYGRhcmtgIGJhc2VkIG9uIHRoZSBgZGVmYXVsdENvbG9yU2NoZW1lYC5cbiAqIFRoaXMgaXMgYmV0dGVyIHN1aXRlZCBmb3IgYXBwcyB0aGF0IG9ubHkgbmVlZCBhIHNpbmdsZSBjb2xvciBzY2hlbWUuXG4gKlxuICogVG8gZW5hYmxlIGJ1aWx0LWluIGBsaWdodGAgYW5kIGBkYXJrYCBjb2xvciBzY2hlbWVzLCBlaXRoZXI6XG4gKiAxLiBwcm92aWRlIGEgYGNvbG9yU2NoZW1lU2VsZWN0b3JgIHRvIGRlZmluZSBob3cgdGhlIGNvbG9yIHNjaGVtZXMgd2lsbCBjaGFuZ2UuXG4gKiAyLiBwcm92aWRlIGBjb2xvclNjaGVtZXMuZGFya2Agd2lsbCBzZXQgYGNvbG9yU2NoZW1lU2VsZWN0b3I6ICdtZWRpYSdgIGJ5IGRlZmF1bHQuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZVRoZW1lV2l0aFZhcnMob3B0aW9ucyA9IHt9LCAuLi5hcmdzKSB7XG4gIGNvbnN0IHtcbiAgICBjb2xvclNjaGVtZXM6IGNvbG9yU2NoZW1lc0lucHV0ID0ge1xuICAgICAgbGlnaHQ6IHRydWVcbiAgICB9LFxuICAgIGRlZmF1bHRDb2xvclNjaGVtZTogZGVmYXVsdENvbG9yU2NoZW1lSW5wdXQsXG4gICAgZGlzYWJsZUNzc0NvbG9yU2NoZW1lID0gZmFsc2UsXG4gICAgY3NzVmFyUHJlZml4ID0gJ211aScsXG4gICAgbmF0aXZlQ29sb3IgPSBmYWxzZSxcbiAgICBzaG91bGRTa2lwR2VuZXJhdGluZ1ZhciA9IGRlZmF1bHRTaG91bGRTa2lwR2VuZXJhdGluZ1ZhcixcbiAgICBjb2xvclNjaGVtZVNlbGVjdG9yOiBzZWxlY3RvciA9IGNvbG9yU2NoZW1lc0lucHV0LmxpZ2h0ICYmIGNvbG9yU2NoZW1lc0lucHV0LmRhcmsgPyAnbWVkaWEnIDogdW5kZWZpbmVkLFxuICAgIHJvb3RTZWxlY3RvciA9ICc6cm9vdCcsXG4gICAgLi4uaW5wdXRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZpcnN0Q29sb3JTY2hlbWUgPSBPYmplY3Qua2V5cyhjb2xvclNjaGVtZXNJbnB1dClbMF07XG4gIGNvbnN0IGRlZmF1bHRDb2xvclNjaGVtZSA9IGRlZmF1bHRDb2xvclNjaGVtZUlucHV0IHx8IChjb2xvclNjaGVtZXNJbnB1dC5saWdodCAmJiBmaXJzdENvbG9yU2NoZW1lICE9PSAnbGlnaHQnID8gJ2xpZ2h0JyA6IGZpcnN0Q29sb3JTY2hlbWUpO1xuICBjb25zdCBnZXRDc3NWYXIgPSBjcmVhdGVHZXRDc3NWYXIoY3NzVmFyUHJlZml4KTtcbiAgY29uc3Qge1xuICAgIFtkZWZhdWx0Q29sb3JTY2hlbWVdOiBkZWZhdWx0U2NoZW1lSW5wdXQsXG4gICAgbGlnaHQ6IGJ1aWx0SW5MaWdodCxcbiAgICBkYXJrOiBidWlsdEluRGFyayxcbiAgICAuLi5jdXN0b21Db2xvclNjaGVtZXNcbiAgfSA9IGNvbG9yU2NoZW1lc0lucHV0O1xuICBjb25zdCBjb2xvclNjaGVtZXMgPSB7XG4gICAgLi4uY3VzdG9tQ29sb3JTY2hlbWVzXG4gIH07XG4gIGxldCBkZWZhdWx0U2NoZW1lID0gZGVmYXVsdFNjaGVtZUlucHV0O1xuXG4gIC8vIEZvciBidWlsdC1pbiBsaWdodCBhbmQgZGFyayBjb2xvciBzY2hlbWVzLCBlbnN1cmUgdGhhdCB0aGUgdmFsdWUgaXMgdmFsaWQgaWYgdGhleSBhcmUgdGhlIGRlZmF1bHQgY29sb3Igc2NoZW1lLlxuICBpZiAoZGVmYXVsdENvbG9yU2NoZW1lID09PSAnZGFyaycgJiYgISgnZGFyaycgaW4gY29sb3JTY2hlbWVzSW5wdXQpIHx8IGRlZmF1bHRDb2xvclNjaGVtZSA9PT0gJ2xpZ2h0JyAmJiAhKCdsaWdodCcgaW4gY29sb3JTY2hlbWVzSW5wdXQpKSB7XG4gICAgZGVmYXVsdFNjaGVtZSA9IHRydWU7XG4gIH1cbiAgaWYgKCFkZWZhdWx0U2NoZW1lKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBNVUk6IFRoZSBcXGBjb2xvclNjaGVtZXMuJHtkZWZhdWx0Q29sb3JTY2hlbWV9XFxgIG9wdGlvbiBpcyBlaXRoZXIgbWlzc2luZyBvciBpbnZhbGlkLmAgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDIxLCBkZWZhdWx0Q29sb3JTY2hlbWUpKTtcbiAgfVxuXG4gIC8vIFRoZSByZWFzb24gdG8gdXNlIGBva2xjaGAgaXMgdGhhdCBpdCBpcyB0aGUgbW9zdCBwZXJjZXB0dWFsbHkgdW5pZm9ybSBjb2xvciBzcGFjZSBhbmQgd2lkZWx5IHN1cHBvcnRlZC5cbiAgbGV0IGNvbG9yU3BhY2U7XG4gIGlmIChuYXRpdmVDb2xvcikge1xuICAgIGNvbG9yU3BhY2UgPSAnb2tsY2gnO1xuICB9XG5cbiAgLy8gQ3JlYXRlIHRoZSBwYWxldHRlIGZvciB0aGUgZGVmYXVsdCBjb2xvciBzY2hlbWUsIGVpdGhlciBgbGlnaHRgLCBgZGFya2AsIG9yIGN1c3RvbSBjb2xvciBzY2hlbWUuXG4gIGNvbnN0IG11aVRoZW1lID0gYXR0YWNoQ29sb3JTY2hlbWUoY29sb3JTcGFjZSwgY29sb3JTY2hlbWVzLCBkZWZhdWx0U2NoZW1lLCBpbnB1dCwgZGVmYXVsdENvbG9yU2NoZW1lKTtcbiAgaWYgKGJ1aWx0SW5MaWdodCAmJiAhY29sb3JTY2hlbWVzLmxpZ2h0KSB7XG4gICAgYXR0YWNoQ29sb3JTY2hlbWUoY29sb3JTcGFjZSwgY29sb3JTY2hlbWVzLCBidWlsdEluTGlnaHQsIHVuZGVmaW5lZCwgJ2xpZ2h0Jyk7XG4gIH1cbiAgaWYgKGJ1aWx0SW5EYXJrICYmICFjb2xvclNjaGVtZXMuZGFyaykge1xuICAgIGF0dGFjaENvbG9yU2NoZW1lKGNvbG9yU3BhY2UsIGNvbG9yU2NoZW1lcywgYnVpbHRJbkRhcmssIHVuZGVmaW5lZCwgJ2RhcmsnKTtcbiAgfVxuICBsZXQgdGhlbWUgPSB7XG4gICAgZGVmYXVsdENvbG9yU2NoZW1lLFxuICAgIC4uLm11aVRoZW1lLFxuICAgIGNzc1ZhclByZWZpeCxcbiAgICBjb2xvclNjaGVtZVNlbGVjdG9yOiBzZWxlY3RvcixcbiAgICByb290U2VsZWN0b3IsXG4gICAgZ2V0Q3NzVmFyLFxuICAgIGNvbG9yU2NoZW1lcyxcbiAgICBmb250OiB7XG4gICAgICAuLi5wcmVwYXJlVHlwb2dyYXBoeVZhcnMobXVpVGhlbWUudHlwb2dyYXBoeSksXG4gICAgICAuLi5tdWlUaGVtZS5mb250XG4gICAgfSxcbiAgICBzcGFjaW5nOiBnZXRTcGFjaW5nVmFsKGlucHV0LnNwYWNpbmcpXG4gIH07XG4gIE9iamVjdC5rZXlzKHRoZW1lLmNvbG9yU2NoZW1lcykuZm9yRWFjaChrZXkgPT4ge1xuICAgIGNvbnN0IHBhbGV0dGUgPSB0aGVtZS5jb2xvclNjaGVtZXNba2V5XS5wYWxldHRlO1xuICAgIGNvbnN0IHNldENzc1ZhckNvbG9yID0gY3NzVmFyID0+IHtcbiAgICAgIGNvbnN0IHRva2VucyA9IGNzc1Zhci5zcGxpdCgnLScpO1xuICAgICAgY29uc3QgY29sb3IgPSB0b2tlbnNbMV07XG4gICAgICBjb25zdCBjb2xvclRva2VuID0gdG9rZW5zWzJdO1xuICAgICAgcmV0dXJuIGdldENzc1Zhcihjc3NWYXIsIHBhbGV0dGVbY29sb3JdW2NvbG9yVG9rZW5dKTtcbiAgICB9O1xuXG4gICAgLy8gYXR0YWNoIGJsYWNrICYgd2hpdGUgY2hhbm5lbHMgdG8gY29tbW9uIG5vZGVcbiAgICBpZiAocGFsZXR0ZS5tb2RlID09PSAnbGlnaHQnKSB7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLmNvbW1vbiwgJ2JhY2tncm91bmQnLCAnI2ZmZicpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5jb21tb24sICdvbkJhY2tncm91bmQnLCAnIzAwMCcpO1xuICAgIH1cbiAgICBpZiAocGFsZXR0ZS5tb2RlID09PSAnZGFyaycpIHtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuY29tbW9uLCAnYmFja2dyb3VuZCcsICcjMDAwJyk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLmNvbW1vbiwgJ29uQmFja2dyb3VuZCcsICcjZmZmJyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNvbG9yTWl4KG1ldGhvZCwgY29sb3IsIGNvZWZmaWNpZW50KSB7XG4gICAgICBpZiAoY29sb3JTcGFjZSkge1xuICAgICAgICBsZXQgbWl4ZXI7XG4gICAgICAgIGlmIChtZXRob2QgPT09IHNhZmVBbHBoYSkge1xuICAgICAgICAgIG1peGVyID0gYHRyYW5zcGFyZW50ICR7KCgxIC0gY29lZmZpY2llbnQpICogMTAwKS50b0ZpeGVkKDApfSVgO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09IHNhZmVEYXJrZW4pIHtcbiAgICAgICAgICBtaXhlciA9IGAjMDAwICR7KGNvZWZmaWNpZW50ICogMTAwKS50b0ZpeGVkKDApfSVgO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09IHNhZmVMaWdodGVuKSB7XG4gICAgICAgICAgbWl4ZXIgPSBgI2ZmZiAkeyhjb2VmZmljaWVudCAqIDEwMCkudG9GaXhlZCgwKX0lYDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYGNvbG9yLW1peChpbiAke2NvbG9yU3BhY2V9LCAke2NvbG9yfSwgJHttaXhlcn0pYDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtZXRob2QoY29sb3IsIGNvZWZmaWNpZW50KTtcbiAgICB9XG5cbiAgICAvLyBhc3NpZ24gY29tcG9uZW50IHZhcmlhYmxlc1xuICAgIGFzc2lnbk5vZGUocGFsZXR0ZSwgWydBbGVydCcsICdBcHBCYXInLCAnQXZhdGFyJywgJ0J1dHRvbicsICdDaGlwJywgJ0ZpbGxlZElucHV0JywgJ0xpbmVhclByb2dyZXNzJywgJ1NrZWxldG9uJywgJ1NsaWRlcicsICdTbmFja2JhckNvbnRlbnQnLCAnU3BlZWREaWFsQWN0aW9uJywgJ1N0ZXBDb25uZWN0b3InLCAnU3RlcENvbnRlbnQnLCAnU3dpdGNoJywgJ1RhYmxlQ2VsbCcsICdUb29sdGlwJ10pO1xuICAgIGlmIChwYWxldHRlLm1vZGUgPT09ICdsaWdodCcpIHtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdlcnJvckNvbG9yJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtZXJyb3ItbGlnaHQnKSA6IHBhbGV0dGUuZXJyb3IubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9Db2xvcicsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWluZm8tbGlnaHQnKSA6IHBhbGV0dGUuaW5mby5saWdodCwgMC42KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnc3VjY2Vzc0NvbG9yJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtc3VjY2Vzcy1saWdodCcpIDogcGFsZXR0ZS5zdWNjZXNzLmxpZ2h0LCAwLjYpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICd3YXJuaW5nQ29sb3InLCBjb2xvck1peChzYWZlRGFya2VuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS13YXJuaW5nLWxpZ2h0JykgOiBwYWxldHRlLndhcm5pbmcubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yRmlsbGVkQmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1lcnJvci1tYWluJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9GaWxsZWRCZycsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWluZm8tbWFpbicpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzRmlsbGVkQmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnd2FybmluZ0ZpbGxlZEJnJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtd2FybmluZy1tYWluJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yRmlsbGVkQ29sb3InLCBzaWxlbnQoKCkgPT4gcGFsZXR0ZS5nZXRDb250cmFzdFRleHQocGFsZXR0ZS5lcnJvci5tYWluKSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9GaWxsZWRDb2xvcicsIHNpbGVudCgoKSA9PiBwYWxldHRlLmdldENvbnRyYXN0VGV4dChwYWxldHRlLmluZm8ubWFpbikpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzRmlsbGVkQ29sb3InLCBzaWxlbnQoKCkgPT4gcGFsZXR0ZS5nZXRDb250cmFzdFRleHQocGFsZXR0ZS5zdWNjZXNzLm1haW4pKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnd2FybmluZ0ZpbGxlZENvbG9yJywgc2lsZW50KCgpID0+IHBhbGV0dGUuZ2V0Q29udHJhc3RUZXh0KHBhbGV0dGUud2FybmluZy5tYWluKSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yU3RhbmRhcmRCZycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1lcnJvci1saWdodCcpIDogcGFsZXR0ZS5lcnJvci5saWdodCwgMC45KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnaW5mb1N0YW5kYXJkQmcnLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtaW5mby1saWdodCcpIDogcGFsZXR0ZS5pbmZvLmxpZ2h0LCAwLjkpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzU3RhbmRhcmRCZycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLWxpZ2h0JykgOiBwYWxldHRlLnN1Y2Nlc3MubGlnaHQsIDAuOSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ3dhcm5pbmdTdGFuZGFyZEJnJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXdhcm5pbmctbGlnaHQnKSA6IHBhbGV0dGUud2FybmluZy5saWdodCwgMC45KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnZXJyb3JJY29uQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1lcnJvci1tYWluJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9JY29uQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1pbmZvLW1haW4nKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnc3VjY2Vzc0ljb25Db2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLXN1Y2Nlc3MtbWFpbicpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICd3YXJuaW5nSWNvbkNvbG9yJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtd2FybmluZy1tYWluJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BcHBCYXIsICdkZWZhdWx0QmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTEwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQXZhdGFyLCAnZGVmYXVsdEJnJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS00MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkJ1dHRvbiwgJ2luaGVyaXRDb250YWluZWRCZycsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktMzAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5CdXR0b24sICdpbmhlcml0Q29udGFpbmVkSG92ZXJCZycsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktQTEwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQ2hpcCwgJ2RlZmF1bHRCb3JkZXInLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTQwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQ2hpcCwgJ2RlZmF1bHRBdmF0YXJDb2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktNzAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5DaGlwLCAnZGVmYXVsdEljb25Db2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktNzAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5GaWxsZWRJbnB1dCwgJ2JnJywgJ3JnYmEoMCwgMCwgMCwgMC4wNiknKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuRmlsbGVkSW5wdXQsICdob3ZlckJnJywgJ3JnYmEoMCwgMCwgMCwgMC4wOSknKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuRmlsbGVkSW5wdXQsICdkaXNhYmxlZEJnJywgJ3JnYmEoMCwgMCwgMCwgMC4xMiknKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuTGluZWFyUHJvZ3Jlc3MsICdwcmltYXJ5QmcnLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtcHJpbWFyeS1tYWluJykgOiBwYWxldHRlLnByaW1hcnkubWFpbiwgMC42MikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5MaW5lYXJQcm9ncmVzcywgJ3NlY29uZGFyeUJnJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXNlY29uZGFyeS1tYWluJykgOiBwYWxldHRlLnNlY29uZGFyeS5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnZXJyb3JCZycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1lcnJvci1tYWluJykgOiBwYWxldHRlLmVycm9yLm1haW4sIDAuNjIpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuTGluZWFyUHJvZ3Jlc3MsICdpbmZvQmcnLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtaW5mby1tYWluJykgOiBwYWxldHRlLmluZm8ubWFpbiwgMC42MikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5MaW5lYXJQcm9ncmVzcywgJ3N1Y2Nlc3NCZycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSA6IHBhbGV0dGUuc3VjY2Vzcy5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnd2FybmluZ0JnJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXdhcm5pbmctbGlnaHQnKSA6IHBhbGV0dGUud2FybmluZy5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNrZWxldG9uLCAnYmcnLCBjb2xvclNwYWNlID8gY29sb3JNaXgoc2FmZUFscGhhLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS10ZXh0LXByaW1hcnknKSA6IHBhbGV0dGUudGV4dC5wcmltYXJ5LCAwLjExKSA6IGByZ2JhKCR7c2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtdGV4dC1wcmltYXJ5Q2hhbm5lbCcpfSAvIDAuMTEpYCk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ3ByaW1hcnlUcmFjaycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1wcmltYXJ5LW1haW4nKSA6IHBhbGV0dGUucHJpbWFyeS5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ3NlY29uZGFyeVRyYWNrJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXNlY29uZGFyeS1tYWluJykgOiBwYWxldHRlLnNlY29uZGFyeS5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ2Vycm9yVHJhY2snLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtZXJyb3ItbWFpbicpIDogcGFsZXR0ZS5lcnJvci5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ2luZm9UcmFjaycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1pbmZvLW1haW4nKSA6IHBhbGV0dGUuaW5mby5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ3N1Y2Nlc3NUcmFjaycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSA6IHBhbGV0dGUuc3VjY2Vzcy5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ3dhcm5pbmdUcmFjaycsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS13YXJuaW5nLW1haW4nKSA6IHBhbGV0dGUud2FybmluZy5tYWluLCAwLjYyKSk7XG4gICAgICBjb25zdCBzbmFja2JhckNvbnRlbnRCYWNrZ3JvdW5kID0gY29sb3JTcGFjZSA/IGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWJhY2tncm91bmQtZGVmYXVsdCcpIDogcGFsZXR0ZS5iYWNrZ3JvdW5kLmRlZmF1bHQsIDAuNjgyNSkgLy8gdXNlIGAwLjY4MjVgIGluc3RlYWQgb2YgYDAuOGAgdG8gbWF0Y2ggdGhlIGNvbnRyYXN0IHJhdGlvIG9mIEpTIGltcGxlbWVudGF0aW9uXG4gICAgICA6IHNhZmVFbXBoYXNpemUocGFsZXR0ZS5iYWNrZ3JvdW5kLmRlZmF1bHQsIDAuOCk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNuYWNrYmFyQ29udGVudCwgJ2JnJywgc25hY2tiYXJDb250ZW50QmFja2dyb3VuZCk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNuYWNrYmFyQ29udGVudCwgJ2NvbG9yJywgc2lsZW50KCgpID0+IGNvbG9yU3BhY2UgPyBkYXJrLnRleHQucHJpbWFyeSA6IHBhbGV0dGUuZ2V0Q29udHJhc3RUZXh0KHNuYWNrYmFyQ29udGVudEJhY2tncm91bmQpKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNwZWVkRGlhbEFjdGlvbiwgJ2ZhYkhvdmVyQmcnLCBzYWZlRW1waGFzaXplKHBhbGV0dGUuYmFja2dyb3VuZC5wYXBlciwgMC4xNSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5TdGVwQ29ubmVjdG9yLCAnYm9yZGVyJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS00MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN0ZXBDb250ZW50LCAnYm9yZGVyJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS00MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ2RlZmF1bHRDb2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWNvbW1vbi13aGl0ZScpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU3dpdGNoLCAnZGVmYXVsdERpc2FibGVkQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTEwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU3dpdGNoLCAncHJpbWFyeURpc2FibGVkQ29sb3InLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtcHJpbWFyeS1tYWluJykgOiBwYWxldHRlLnByaW1hcnkubWFpbiwgMC42MikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5Td2l0Y2gsICdzZWNvbmRhcnlEaXNhYmxlZENvbG9yJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXNlY29uZGFyeS1tYWluJykgOiBwYWxldHRlLnNlY29uZGFyeS5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ2Vycm9yRGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1lcnJvci1tYWluJykgOiBwYWxldHRlLmVycm9yLm1haW4sIDAuNjIpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU3dpdGNoLCAnaW5mb0Rpc2FibGVkQ29sb3InLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtaW5mby1tYWluJykgOiBwYWxldHRlLmluZm8ubWFpbiwgMC42MikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5Td2l0Y2gsICdzdWNjZXNzRGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSA6IHBhbGV0dGUuc3VjY2Vzcy5tYWluLCAwLjYyKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ3dhcm5pbmdEaXNhYmxlZENvbG9yJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXdhcm5pbmctbWFpbicpIDogcGFsZXR0ZS53YXJuaW5nLm1haW4sIDAuNjIpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuVGFibGVDZWxsLCAnYm9yZGVyJywgY29sb3JNaXgoc2FmZUxpZ2h0ZW4sIHNhZmVBbHBoYShuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1kaXZpZGVyJykgOiBwYWxldHRlLmRpdmlkZXIsIDEpLCAwLjg4KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlRvb2x0aXAsICdiZycsIGNvbG9yTWl4KHNhZmVBbHBoYSwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtZ3JleS03MDAnKSA6IHBhbGV0dGUuZ3JleVs3MDBdLCAwLjkyKSk7XG4gICAgfVxuICAgIGlmIChwYWxldHRlLm1vZGUgPT09ICdkYXJrJykge1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yQ29sb3InLCBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtZXJyb3ItbGlnaHQnKSA6IHBhbGV0dGUuZXJyb3IubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9Db2xvcicsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1pbmZvLWxpZ2h0JykgOiBwYWxldHRlLmluZm8ubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ3N1Y2Nlc3NDb2xvcicsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLWxpZ2h0JykgOiBwYWxldHRlLnN1Y2Nlc3MubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ3dhcm5pbmdDb2xvcicsIGNvbG9yTWl4KHNhZmVMaWdodGVuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS13YXJuaW5nLWxpZ2h0JykgOiBwYWxldHRlLndhcm5pbmcubGlnaHQsIDAuNikpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yRmlsbGVkQmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1lcnJvci1kYXJrJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9GaWxsZWRCZycsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWluZm8tZGFyaycpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzRmlsbGVkQmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1zdWNjZXNzLWRhcmsnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnd2FybmluZ0ZpbGxlZEJnJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtd2FybmluZy1kYXJrJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yRmlsbGVkQ29sb3InLCBzaWxlbnQoKCkgPT4gcGFsZXR0ZS5nZXRDb250cmFzdFRleHQocGFsZXR0ZS5lcnJvci5kYXJrKSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2luZm9GaWxsZWRDb2xvcicsIHNpbGVudCgoKSA9PiBwYWxldHRlLmdldENvbnRyYXN0VGV4dChwYWxldHRlLmluZm8uZGFyaykpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzRmlsbGVkQ29sb3InLCBzaWxlbnQoKCkgPT4gcGFsZXR0ZS5nZXRDb250cmFzdFRleHQocGFsZXR0ZS5zdWNjZXNzLmRhcmspKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnd2FybmluZ0ZpbGxlZENvbG9yJywgc2lsZW50KCgpID0+IHBhbGV0dGUuZ2V0Q29udHJhc3RUZXh0KHBhbGV0dGUud2FybmluZy5kYXJrKSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ2Vycm9yU3RhbmRhcmRCZycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWVycm9yLWxpZ2h0JykgOiBwYWxldHRlLmVycm9yLmxpZ2h0LCAwLjkpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdpbmZvU3RhbmRhcmRCZycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWluZm8tbGlnaHQnKSA6IHBhbGV0dGUuaW5mby5saWdodCwgMC45KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnc3VjY2Vzc1N0YW5kYXJkQmcnLCBjb2xvck1peChzYWZlRGFya2VuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLWxpZ2h0JykgOiBwYWxldHRlLnN1Y2Nlc3MubGlnaHQsIDAuOSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ3dhcm5pbmdTdGFuZGFyZEJnJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtd2FybmluZy1saWdodCcpIDogcGFsZXR0ZS53YXJuaW5nLmxpZ2h0LCAwLjkpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdlcnJvckljb25Db2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWVycm9yLW1haW4nKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFsZXJ0LCAnaW5mb0ljb25Db2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWluZm8tbWFpbicpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQWxlcnQsICdzdWNjZXNzSWNvbkNvbG9yJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtc3VjY2Vzcy1tYWluJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BbGVydCwgJ3dhcm5pbmdJY29uQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS13YXJuaW5nLW1haW4nKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFwcEJhciwgJ2RlZmF1bHRCZycsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktOTAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BcHBCYXIsICdkYXJrQmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1iYWNrZ3JvdW5kLXBhcGVyJykpOyAvLyBzcGVjaWZpYyBmb3IgZGFyayBtb2RlXG4gICAgICBzZXRDb2xvcihwYWxldHRlLkFwcEJhciwgJ2RhcmtDb2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLXRleHQtcHJpbWFyeScpKTsgLy8gc3BlY2lmaWMgZm9yIGRhcmsgbW9kZVxuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5BdmF0YXIsICdkZWZhdWx0QmcnLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTYwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQnV0dG9uLCAnaW5oZXJpdENvbnRhaW5lZEJnJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS04MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkJ1dHRvbiwgJ2luaGVyaXRDb250YWluZWRIb3ZlckJnJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS03MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkNoaXAsICdkZWZhdWx0Qm9yZGVyJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS03MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkNoaXAsICdkZWZhdWx0QXZhdGFyQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTMwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuQ2hpcCwgJ2RlZmF1bHRJY29uQ29sb3InLCBzZXRDc3NWYXJDb2xvcigncGFsZXR0ZS1ncmV5LTMwMCcpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuRmlsbGVkSW5wdXQsICdiZycsICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDkpJyk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkZpbGxlZElucHV0LCAnaG92ZXJCZycsICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTMpJyk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkZpbGxlZElucHV0LCAnZGlzYWJsZWRCZycsICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTIpJyk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAncHJpbWFyeUJnJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtcHJpbWFyeS1tYWluJykgOiBwYWxldHRlLnByaW1hcnkubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnc2Vjb25kYXJ5QmcnLCBjb2xvck1peChzYWZlRGFya2VuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zZWNvbmRhcnktbWFpbicpIDogcGFsZXR0ZS5zZWNvbmRhcnkubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnZXJyb3JCZycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWVycm9yLW1haW4nKSA6IHBhbGV0dGUuZXJyb3IubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnaW5mb0JnJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtaW5mby1tYWluJykgOiBwYWxldHRlLmluZm8ubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnc3VjY2Vzc0JnJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtc3VjY2Vzcy1tYWluJykgOiBwYWxldHRlLnN1Y2Nlc3MubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLkxpbmVhclByb2dyZXNzLCAnd2FybmluZ0JnJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtd2FybmluZy1tYWluJykgOiBwYWxldHRlLndhcm5pbmcubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNrZWxldG9uLCAnYmcnLCBjb2xvclNwYWNlID8gY29sb3JNaXgoc2FmZUFscGhhLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS10ZXh0LXByaW1hcnknKSA6IHBhbGV0dGUudGV4dC5wcmltYXJ5LCAwLjEzKSA6IGByZ2JhKCR7c2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtdGV4dC1wcmltYXJ5Q2hhbm5lbCcpfSAvIDAuMTMpYCk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ3ByaW1hcnlUcmFjaycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXByaW1hcnktbWFpbicpIDogcGFsZXR0ZS5wcmltYXJ5Lm1haW4sIDAuNSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5TbGlkZXIsICdzZWNvbmRhcnlUcmFjaycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXNlY29uZGFyeS1tYWluJykgOiBwYWxldHRlLnNlY29uZGFyeS5tYWluLCAwLjUpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU2xpZGVyLCAnZXJyb3JUcmFjaycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWVycm9yLW1haW4nKSA6IHBhbGV0dGUuZXJyb3IubWFpbiwgMC41KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNsaWRlciwgJ2luZm9UcmFjaycsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWluZm8tbWFpbicpIDogcGFsZXR0ZS5pbmZvLm1haW4sIDAuNSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5TbGlkZXIsICdzdWNjZXNzVHJhY2snLCBjb2xvck1peChzYWZlRGFya2VuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSA6IHBhbGV0dGUuc3VjY2Vzcy5tYWluLCAwLjUpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU2xpZGVyLCAnd2FybmluZ1RyYWNrJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtd2FybmluZy1saWdodCcpIDogcGFsZXR0ZS53YXJuaW5nLm1haW4sIDAuNSkpO1xuICAgICAgY29uc3Qgc25hY2tiYXJDb250ZW50QmFja2dyb3VuZCA9IGNvbG9yU3BhY2UgPyBjb2xvck1peChzYWZlTGlnaHRlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtYmFja2dyb3VuZC1kZWZhdWx0JykgOiBwYWxldHRlLmJhY2tncm91bmQuZGVmYXVsdCwgMC45ODUpIC8vIHVzZSBgMC45ODVgIGluc3RlYWQgb2YgYDAuOThgIHRvIG1hdGNoIHRoZSBjb250cmFzdCByYXRpbyBvZiBKUyBpbXBsZW1lbnRhdGlvblxuICAgICAgOiBzYWZlRW1waGFzaXplKHBhbGV0dGUuYmFja2dyb3VuZC5kZWZhdWx0LCAwLjk4KTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU25hY2tiYXJDb250ZW50LCAnYmcnLCBzbmFja2JhckNvbnRlbnRCYWNrZ3JvdW5kKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU25hY2tiYXJDb250ZW50LCAnY29sb3InLCBzaWxlbnQoKCkgPT4gY29sb3JTcGFjZSA/IGxpZ2h0LnRleHQucHJpbWFyeSA6IHBhbGV0dGUuZ2V0Q29udHJhc3RUZXh0KHNuYWNrYmFyQ29udGVudEJhY2tncm91bmQpKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlNwZWVkRGlhbEFjdGlvbiwgJ2ZhYkhvdmVyQmcnLCBzYWZlRW1waGFzaXplKHBhbGV0dGUuYmFja2dyb3VuZC5wYXBlciwgMC4xNSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5TdGVwQ29ubmVjdG9yLCAnYm9yZGVyJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS02MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN0ZXBDb250ZW50LCAnYm9yZGVyJywgc2V0Q3NzVmFyQ29sb3IoJ3BhbGV0dGUtZ3JleS02MDAnKSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ2RlZmF1bHRDb2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktMzAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5Td2l0Y2gsICdkZWZhdWx0RGlzYWJsZWRDb2xvcicsIHNldENzc1ZhckNvbG9yKCdwYWxldHRlLWdyZXktNjAwJykpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5Td2l0Y2gsICdwcmltYXJ5RGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXByaW1hcnktbWFpbicpIDogcGFsZXR0ZS5wcmltYXJ5Lm1haW4sIDAuNTUpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU3dpdGNoLCAnc2Vjb25kYXJ5RGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLXNlY29uZGFyeS1tYWluJykgOiBwYWxldHRlLnNlY29uZGFyeS5tYWluLCAwLjU1KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ2Vycm9yRGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWVycm9yLW1haW4nKSA6IHBhbGV0dGUuZXJyb3IubWFpbiwgMC41NSkpO1xuICAgICAgc2V0Q29sb3IocGFsZXR0ZS5Td2l0Y2gsICdpbmZvRGlzYWJsZWRDb2xvcicsIGNvbG9yTWl4KHNhZmVEYXJrZW4sIG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWluZm8tbWFpbicpIDogcGFsZXR0ZS5pbmZvLm1haW4sIDAuNTUpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuU3dpdGNoLCAnc3VjY2Vzc0Rpc2FibGVkQ29sb3InLCBjb2xvck1peChzYWZlRGFya2VuLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1zdWNjZXNzLW1haW4nKSA6IHBhbGV0dGUuc3VjY2Vzcy5tYWluLCAwLjU1KSk7XG4gICAgICBzZXRDb2xvcihwYWxldHRlLlN3aXRjaCwgJ3dhcm5pbmdEaXNhYmxlZENvbG9yJywgY29sb3JNaXgoc2FmZURhcmtlbiwgbmF0aXZlQ29sb3IgPyBnZXRDc3NWYXIoJ3BhbGV0dGUtd2FybmluZy1saWdodCcpIDogcGFsZXR0ZS53YXJuaW5nLm1haW4sIDAuNTUpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuVGFibGVDZWxsLCAnYm9yZGVyJywgY29sb3JNaXgoc2FmZURhcmtlbiwgc2FmZUFscGhhKG5hdGl2ZUNvbG9yID8gZ2V0Q3NzVmFyKCdwYWxldHRlLWRpdmlkZXInKSA6IHBhbGV0dGUuZGl2aWRlciwgMSksIDAuNjgpKTtcbiAgICAgIHNldENvbG9yKHBhbGV0dGUuVG9vbHRpcCwgJ2JnJywgY29sb3JNaXgoc2FmZUFscGhhLCBuYXRpdmVDb2xvciA/IGdldENzc1ZhcigncGFsZXR0ZS1ncmV5LTcwMCcpIDogcGFsZXR0ZS5ncmV5WzcwMF0sIDAuOTIpKTtcbiAgICB9XG4gICAgaWYgKCFuYXRpdmVDb2xvcikge1xuICAgICAgc2V0Q29sb3JDaGFubmVsKHBhbGV0dGUuYmFja2dyb3VuZCwgJ2RlZmF1bHQnKTtcblxuICAgICAgLy8gYWRkZWQgZm9yIGNvbnNpc3RlbmN5IHdpdGggdGhlIGBiYWNrZ3JvdW5kLmRlZmF1bHRgIHRva2VuXG4gICAgICBzZXRDb2xvckNoYW5uZWwocGFsZXR0ZS5iYWNrZ3JvdW5kLCAncGFwZXInKTtcbiAgICAgIHNldENvbG9yQ2hhbm5lbChwYWxldHRlLmNvbW1vbiwgJ2JhY2tncm91bmQnKTtcbiAgICAgIHNldENvbG9yQ2hhbm5lbChwYWxldHRlLmNvbW1vbiwgJ29uQmFja2dyb3VuZCcpO1xuICAgICAgc2V0Q29sb3JDaGFubmVsKHBhbGV0dGUsICdkaXZpZGVyJyk7XG4gICAgfVxuICAgIE9iamVjdC5rZXlzKHBhbGV0dGUpLmZvckVhY2goY29sb3IgPT4ge1xuICAgICAgY29uc3QgY29sb3JzID0gcGFsZXR0ZVtjb2xvcl07XG5cbiAgICAgIC8vIFRoZSBkZWZhdWx0IHBhbGV0dGVzIChwcmltYXJ5LCBzZWNvbmRhcnksIGVycm9yLCBpbmZvLCBzdWNjZXNzLCBhbmQgd2FybmluZykgZXJyb3JzIGFyZSBoYW5kbGVkIGJ5IHRoZSBhYm92ZSBgY3JlYXRlVGhlbWUoLi4uKWAuXG5cbiAgICAgIGlmIChjb2xvciAhPT0gJ3RvbmFsT2Zmc2V0JyAmJiAhbmF0aXZlQ29sb3IgJiYgY29sb3JzICYmIHR5cGVvZiBjb2xvcnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIC8vIFNpbGVudCB0aGUgZXJyb3IgZm9yIGN1c3RvbSBwYWxldHRlcy5cbiAgICAgICAgaWYgKGNvbG9ycy5tYWluKSB7XG4gICAgICAgICAgc2V0Q29sb3IocGFsZXR0ZVtjb2xvcl0sICdtYWluQ2hhbm5lbCcsIHNhZmVDb2xvckNoYW5uZWwodG9SZ2IoY29sb3JzLm1haW4pKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbG9ycy5saWdodCkge1xuICAgICAgICAgIHNldENvbG9yKHBhbGV0dGVbY29sb3JdLCAnbGlnaHRDaGFubmVsJywgc2FmZUNvbG9yQ2hhbm5lbCh0b1JnYihjb2xvcnMubGlnaHQpKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbG9ycy5kYXJrKSB7XG4gICAgICAgICAgc2V0Q29sb3IocGFsZXR0ZVtjb2xvcl0sICdkYXJrQ2hhbm5lbCcsIHNhZmVDb2xvckNoYW5uZWwodG9SZ2IoY29sb3JzLmRhcmspKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbG9ycy5jb250cmFzdFRleHQpIHtcbiAgICAgICAgICBzZXRDb2xvcihwYWxldHRlW2NvbG9yXSwgJ2NvbnRyYXN0VGV4dENoYW5uZWwnLCBzYWZlQ29sb3JDaGFubmVsKHRvUmdiKGNvbG9ycy5jb250cmFzdFRleHQpKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbG9yID09PSAndGV4dCcpIHtcbiAgICAgICAgICAvLyBUZXh0IGNvbG9yczogdGV4dC5wcmltYXJ5LCB0ZXh0LnNlY29uZGFyeVxuICAgICAgICAgIHNldENvbG9yQ2hhbm5lbChwYWxldHRlW2NvbG9yXSwgJ3ByaW1hcnknKTtcbiAgICAgICAgICBzZXRDb2xvckNoYW5uZWwocGFsZXR0ZVtjb2xvcl0sICdzZWNvbmRhcnknKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29sb3IgPT09ICdhY3Rpb24nKSB7XG4gICAgICAgICAgLy8gQWN0aW9uIGNvbG9yczogYWN0aW9uLmFjdGl2ZSwgYWN0aW9uLnNlbGVjdGVkXG4gICAgICAgICAgaWYgKGNvbG9ycy5hY3RpdmUpIHtcbiAgICAgICAgICAgIHNldENvbG9yQ2hhbm5lbChwYWxldHRlW2NvbG9yXSwgJ2FjdGl2ZScpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY29sb3JzLnNlbGVjdGVkKSB7XG4gICAgICAgICAgICBzZXRDb2xvckNoYW5uZWwocGFsZXR0ZVtjb2xvcl0sICdzZWxlY3RlZCcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbiAgdGhlbWUgPSBhcmdzLnJlZHVjZSgoYWNjLCBhcmd1bWVudCkgPT4gZGVlcG1lcmdlKGFjYywgYXJndW1lbnQpLCB0aGVtZSk7XG4gIGNvbnN0IHBhcnNlckNvbmZpZyA9IHtcbiAgICBwcmVmaXg6IGNzc1ZhclByZWZpeCxcbiAgICBkaXNhYmxlQ3NzQ29sb3JTY2hlbWUsXG4gICAgc2hvdWxkU2tpcEdlbmVyYXRpbmdWYXIsXG4gICAgZ2V0U2VsZWN0b3I6IGRlZmF1bHRHZXRTZWxlY3Rvcih0aGVtZSksXG4gICAgZW5hYmxlQ29udHJhc3RWYXJzOiBuYXRpdmVDb2xvclxuICB9O1xuICBjb25zdCB7XG4gICAgdmFycyxcbiAgICBnZW5lcmF0ZVRoZW1lVmFycyxcbiAgICBnZW5lcmF0ZVN0eWxlU2hlZXRzXG4gIH0gPSBwcmVwYXJlQ3NzVmFycyh0aGVtZSwgcGFyc2VyQ29uZmlnKTtcbiAgdGhlbWUudmFycyA9IHZhcnM7XG4gIE9iamVjdC5lbnRyaWVzKHRoZW1lLmNvbG9yU2NoZW1lc1t0aGVtZS5kZWZhdWx0Q29sb3JTY2hlbWVdKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICB0aGVtZVtrZXldID0gdmFsdWU7XG4gIH0pO1xuICB0aGVtZS5nZW5lcmF0ZVRoZW1lVmFycyA9IGdlbmVyYXRlVGhlbWVWYXJzO1xuICB0aGVtZS5nZW5lcmF0ZVN0eWxlU2hlZXRzID0gZ2VuZXJhdGVTdHlsZVNoZWV0cztcbiAgdGhlbWUuZ2VuZXJhdGVTcGFjaW5nID0gZnVuY3Rpb24gZ2VuZXJhdGVTcGFjaW5nKCkge1xuICAgIHJldHVybiBjcmVhdGVTcGFjaW5nKGlucHV0LnNwYWNpbmcsIGNyZWF0ZVVuYXJ5U3BhY2luZyh0aGlzKSk7XG4gIH07XG4gIHRoZW1lLmdldENvbG9yU2NoZW1lU2VsZWN0b3IgPSBjcmVhdGVHZXRDb2xvclNjaGVtZVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgdGhlbWUuc3BhY2luZyA9IHRoZW1lLmdlbmVyYXRlU3BhY2luZygpO1xuICB0aGVtZS5zaG91bGRTa2lwR2VuZXJhdGluZ1ZhciA9IHNob3VsZFNraXBHZW5lcmF0aW5nVmFyO1xuICB0aGVtZS51bnN0YWJsZV9zeENvbmZpZyA9IHtcbiAgICAuLi5kZWZhdWx0U3hDb25maWcsXG4gICAgLi4uaW5wdXQ/LnVuc3RhYmxlX3N4Q29uZmlnXG4gIH07XG4gIHRoZW1lLnVuc3RhYmxlX3N4ID0gZnVuY3Rpb24gc3gocHJvcHMpIHtcbiAgICByZXR1cm4gc3R5bGVGdW5jdGlvblN4KHtcbiAgICAgIHN4OiBwcm9wcyxcbiAgICAgIHRoZW1lOiB0aGlzXG4gICAgfSk7XG4gIH07XG4gIHRoZW1lLmludGVybmFsX2NhY2hlID0ge307XG4gIHRoZW1lLnRvUnVudGltZVNvdXJjZSA9IHN0cmluZ2lmeVRoZW1lOyAvLyBmb3IgUGlnbWVudCBDU1MgaW50ZWdyYXRpb25cblxuICByZXR1cm4gdGhlbWU7XG59IiwiaW1wb3J0IGNyZWF0ZVBhbGV0dGUgZnJvbSBcIi4vY3JlYXRlUGFsZXR0ZS5tanNcIjtcbmltcG9ydCBjcmVhdGVUaGVtZVdpdGhWYXJzIGZyb20gXCIuL2NyZWF0ZVRoZW1lV2l0aFZhcnMubWpzXCI7XG5pbXBvcnQgY3JlYXRlVGhlbWVOb1ZhcnMgZnJvbSBcIi4vY3JlYXRlVGhlbWVOb1ZhcnMubWpzXCI7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbmZ1bmN0aW9uIGF0dGFjaENvbG9yU2NoZW1lKHRoZW1lLCBzY2hlbWUsIGNvbG9yU2NoZW1lKSB7XG4gIGlmICghdGhlbWUuY29sb3JTY2hlbWVzKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBpZiAoY29sb3JTY2hlbWUpIHtcbiAgICB0aGVtZS5jb2xvclNjaGVtZXNbc2NoZW1lXSA9IHtcbiAgICAgIC4uLihjb2xvclNjaGVtZSAhPT0gdHJ1ZSAmJiBjb2xvclNjaGVtZSksXG4gICAgICBwYWxldHRlOiBjcmVhdGVQYWxldHRlKHtcbiAgICAgICAgLi4uKGNvbG9yU2NoZW1lID09PSB0cnVlID8ge30gOiBjb2xvclNjaGVtZS5wYWxldHRlKSxcbiAgICAgICAgbW9kZTogc2NoZW1lXG4gICAgICB9KSAvLyBjYXN0IHR5cGUgdG8gc2tpcCBtb2R1bGUgYXVnbWVudGF0aW9uIHRlc3RcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogR2VuZXJhdGUgYSB0aGVtZSBiYXNlIG9uIHRoZSBvcHRpb25zIHJlY2VpdmVkLlxuICogQHBhcmFtIG9wdGlvbnMgVGFrZXMgYW4gaW5jb21wbGV0ZSB0aGVtZSBvYmplY3QgYW5kIGFkZHMgdGhlIG1pc3NpbmcgcGFydHMuXG4gKiBAcGFyYW0gYXJncyBEZWVwIG1lcmdlIHRoZSBhcmd1bWVudHMgd2l0aCB0aGUgYWJvdXQgdG8gYmUgcmV0dXJuZWQgdGhlbWUuXG4gKiBAcmV0dXJucyBBIGNvbXBsZXRlLCByZWFkeS10by11c2UgdGhlbWUgb2JqZWN0LlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjcmVhdGVUaGVtZShvcHRpb25zID0ge30sXG4vLyBjYXN0IHR5cGUgdG8gc2tpcCBtb2R1bGUgYXVnbWVudGF0aW9uIHRlc3Rcbi4uLmFyZ3MpIHtcbiAgY29uc3Qge1xuICAgIHBhbGV0dGUsXG4gICAgY3NzVmFyaWFibGVzID0gZmFsc2UsXG4gICAgY29sb3JTY2hlbWVzOiBpbml0aWFsQ29sb3JTY2hlbWVzID0gIXBhbGV0dGUgPyB7XG4gICAgICBsaWdodDogdHJ1ZVxuICAgIH0gOiB1bmRlZmluZWQsXG4gICAgZGVmYXVsdENvbG9yU2NoZW1lOiBpbml0aWFsRGVmYXVsdENvbG9yU2NoZW1lID0gcGFsZXR0ZT8ubW9kZSxcbiAgICAuLi5vdGhlclxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgZGVmYXVsdENvbG9yU2NoZW1lSW5wdXQgPSBpbml0aWFsRGVmYXVsdENvbG9yU2NoZW1lIHx8ICdsaWdodCc7XG4gIGNvbnN0IGRlZmF1bHRTY2hlbWUgPSBpbml0aWFsQ29sb3JTY2hlbWVzPy5bZGVmYXVsdENvbG9yU2NoZW1lSW5wdXRdO1xuICBjb25zdCBjb2xvclNjaGVtZXNJbnB1dCA9IHtcbiAgICAuLi5pbml0aWFsQ29sb3JTY2hlbWVzLFxuICAgIC4uLihwYWxldHRlID8ge1xuICAgICAgW2RlZmF1bHRDb2xvclNjaGVtZUlucHV0XToge1xuICAgICAgICAuLi4odHlwZW9mIGRlZmF1bHRTY2hlbWUgIT09ICdib29sZWFuJyAmJiBkZWZhdWx0U2NoZW1lKSxcbiAgICAgICAgcGFsZXR0ZVxuICAgICAgfVxuICAgIH0gOiB1bmRlZmluZWQpXG4gIH07XG4gIGlmIChjc3NWYXJpYWJsZXMgPT09IGZhbHNlKSB7XG4gICAgaWYgKCEoJ2NvbG9yU2NoZW1lcycgaW4gb3B0aW9ucykpIHtcbiAgICAgIC8vIEJlaGF2ZXMgZXhhY3RseSBhcyB2NVxuICAgICAgcmV0dXJuIGNyZWF0ZVRoZW1lTm9WYXJzKG9wdGlvbnMsIC4uLmFyZ3MpO1xuICAgIH1cbiAgICBsZXQgcGFsZXR0ZU9wdGlvbnMgPSBwYWxldHRlO1xuICAgIGlmICghKCdwYWxldHRlJyBpbiBvcHRpb25zKSkge1xuICAgICAgaWYgKGNvbG9yU2NoZW1lc0lucHV0W2RlZmF1bHRDb2xvclNjaGVtZUlucHV0XSkge1xuICAgICAgICBpZiAoY29sb3JTY2hlbWVzSW5wdXRbZGVmYXVsdENvbG9yU2NoZW1lSW5wdXRdICE9PSB0cnVlKSB7XG4gICAgICAgICAgcGFsZXR0ZU9wdGlvbnMgPSBjb2xvclNjaGVtZXNJbnB1dFtkZWZhdWx0Q29sb3JTY2hlbWVJbnB1dF0ucGFsZXR0ZTtcbiAgICAgICAgfSBlbHNlIGlmIChkZWZhdWx0Q29sb3JTY2hlbWVJbnB1dCA9PT0gJ2RhcmsnKSB7XG4gICAgICAgICAgLy8gQHRzLWlnbm9yZSB0byBwcmV2ZW50IHRoZSBtb2R1bGUgYXVnbWVudGF0aW9uIHRlc3QgZnJvbSBmYWlsaW5nXG4gICAgICAgICAgcGFsZXR0ZU9wdGlvbnMgPSB7XG4gICAgICAgICAgICBtb2RlOiAnZGFyaydcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHRoZW1lID0gY3JlYXRlVGhlbWVOb1ZhcnMoe1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHBhbGV0dGU6IHBhbGV0dGVPcHRpb25zXG4gICAgfSwgLi4uYXJncyk7XG4gICAgdGhlbWUuZGVmYXVsdENvbG9yU2NoZW1lID0gZGVmYXVsdENvbG9yU2NoZW1lSW5wdXQ7XG4gICAgdGhlbWUuY29sb3JTY2hlbWVzID0gY29sb3JTY2hlbWVzSW5wdXQ7XG4gICAgaWYgKHRoZW1lLnBhbGV0dGUubW9kZSA9PT0gJ2xpZ2h0Jykge1xuICAgICAgdGhlbWUuY29sb3JTY2hlbWVzLmxpZ2h0ID0ge1xuICAgICAgICAuLi4oY29sb3JTY2hlbWVzSW5wdXQubGlnaHQgIT09IHRydWUgJiYgY29sb3JTY2hlbWVzSW5wdXQubGlnaHQpLFxuICAgICAgICBwYWxldHRlOiB0aGVtZS5wYWxldHRlXG4gICAgICB9O1xuICAgICAgYXR0YWNoQ29sb3JTY2hlbWUodGhlbWUsICdkYXJrJywgY29sb3JTY2hlbWVzSW5wdXQuZGFyayk7XG4gICAgfVxuICAgIGlmICh0aGVtZS5wYWxldHRlLm1vZGUgPT09ICdkYXJrJykge1xuICAgICAgdGhlbWUuY29sb3JTY2hlbWVzLmRhcmsgPSB7XG4gICAgICAgIC4uLihjb2xvclNjaGVtZXNJbnB1dC5kYXJrICE9PSB0cnVlICYmIGNvbG9yU2NoZW1lc0lucHV0LmRhcmspLFxuICAgICAgICBwYWxldHRlOiB0aGVtZS5wYWxldHRlXG4gICAgICB9O1xuICAgICAgYXR0YWNoQ29sb3JTY2hlbWUodGhlbWUsICdsaWdodCcsIGNvbG9yU2NoZW1lc0lucHV0LmxpZ2h0KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoZW1lO1xuICB9XG4gIGlmICghcGFsZXR0ZSAmJiAhKCdsaWdodCcgaW4gY29sb3JTY2hlbWVzSW5wdXQpICYmIGRlZmF1bHRDb2xvclNjaGVtZUlucHV0ID09PSAnbGlnaHQnKSB7XG4gICAgY29sb3JTY2hlbWVzSW5wdXQubGlnaHQgPSB0cnVlO1xuICB9XG4gIHJldHVybiBjcmVhdGVUaGVtZVdpdGhWYXJzKHtcbiAgICAuLi5vdGhlcixcbiAgICBjb2xvclNjaGVtZXM6IGNvbG9yU2NoZW1lc0lucHV0LFxuICAgIGRlZmF1bHRDb2xvclNjaGVtZTogZGVmYXVsdENvbG9yU2NoZW1lSW5wdXQsXG4gICAgLi4uKHR5cGVvZiBjc3NWYXJpYWJsZXMgIT09ICdib29sZWFuJyAmJiBjc3NWYXJpYWJsZXMpXG4gIH0sIC4uLmFyZ3MpO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IGNyZWF0ZVRoZW1lIGZyb20gXCIuL2NyZWF0ZVRoZW1lLm1qc1wiO1xuY29uc3QgZGVmYXVsdFRoZW1lID0gY3JlYXRlVGhlbWUoKTtcbmV4cG9ydCBkZWZhdWx0IGRlZmF1bHRUaGVtZTsiLCJleHBvcnQgZGVmYXVsdCAnJCRtYXRlcmlhbCc7IiwiLy8gY29waWVkIGZyb20gQG11aS9zeXN0ZW0vY3JlYXRlU3R5bGVkXG5mdW5jdGlvbiBzbG90U2hvdWxkRm9yd2FyZFByb3AocHJvcCkge1xuICByZXR1cm4gcHJvcCAhPT0gJ293bmVyU3RhdGUnICYmIHByb3AgIT09ICd0aGVtZScgJiYgcHJvcCAhPT0gJ3N4JyAmJiBwcm9wICE9PSAnYXMnO1xufVxuZXhwb3J0IGRlZmF1bHQgc2xvdFNob3VsZEZvcndhcmRQcm9wOyIsImltcG9ydCBzbG90U2hvdWxkRm9yd2FyZFByb3AgZnJvbSBcIi4vc2xvdFNob3VsZEZvcndhcmRQcm9wLm1qc1wiO1xuY29uc3Qgcm9vdFNob3VsZEZvcndhcmRQcm9wID0gcHJvcCA9PiBzbG90U2hvdWxkRm9yd2FyZFByb3AocHJvcCkgJiYgcHJvcCAhPT0gJ2NsYXNzZXMnO1xuZXhwb3J0IGRlZmF1bHQgcm9vdFNob3VsZEZvcndhcmRQcm9wOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IGNyZWF0ZVN0eWxlZCBmcm9tICdAbXVpL3N5c3RlbS9jcmVhdGVTdHlsZWQnO1xuaW1wb3J0IGRlZmF1bHRUaGVtZSBmcm9tIFwiLi9kZWZhdWx0VGhlbWUubWpzXCI7XG5pbXBvcnQgVEhFTUVfSUQgZnJvbSBcIi4vaWRlbnRpZmllci5tanNcIjtcbmltcG9ydCByb290U2hvdWxkRm9yd2FyZFByb3AgZnJvbSBcIi4vcm9vdFNob3VsZEZvcndhcmRQcm9wLm1qc1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBzbG90U2hvdWxkRm9yd2FyZFByb3AgfSBmcm9tIFwiLi9zbG90U2hvdWxkRm9yd2FyZFByb3AubWpzXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHJvb3RTaG91bGRGb3J3YXJkUHJvcCB9IGZyb20gXCIuL3Jvb3RTaG91bGRGb3J3YXJkUHJvcC5tanNcIjtcbmNvbnN0IHN0eWxlZCA9IGNyZWF0ZVN0eWxlZCh7XG4gIHRoZW1lSWQ6IFRIRU1FX0lELFxuICBkZWZhdWx0VGhlbWUsXG4gIHJvb3RTaG91bGRGb3J3YXJkUHJvcFxufSk7XG5leHBvcnQgZGVmYXVsdCBzdHlsZWQ7IiwiaW1wb3J0IHsgdW5zdGFibGVfbWVtb1RoZW1lIH0gZnJvbSAnQG11aS9zeXN0ZW0nO1xuY29uc3QgbWVtb1RoZW1lID0gdW5zdGFibGVfbWVtb1RoZW1lO1xuZXhwb3J0IGRlZmF1bHQgbWVtb1RoZW1lOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBTeXN0ZW1EZWZhdWx0UHJvcHNQcm92aWRlciwgeyB1c2VEZWZhdWx0UHJvcHMgYXMgdXNlU3lzdGVtRGVmYXVsdFByb3BzIH0gZnJvbSAnQG11aS9zeXN0ZW0vRGVmYXVsdFByb3BzUHJvdmlkZXInO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmZ1bmN0aW9uIERlZmF1bHRQcm9wc1Byb3ZpZGVyKHByb3BzKSB7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChTeXN0ZW1EZWZhdWx0UHJvcHNQcm92aWRlciwge1xuICAgIC4uLnByb3BzXG4gIH0pO1xufVxucHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gRGVmYXVsdFByb3BzUHJvdmlkZXIucHJvcFR5cGVzIC8qIHJlbW92ZS1wcm9wdHlwZXMgKi8gPSB7XG4gIC8vIOKUjOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBXYXJuaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUkFxuICAvLyDilIIgVGhlc2UgUHJvcFR5cGVzIGFyZSBnZW5lcmF0ZWQgZnJvbSB0aGUgVHlwZVNjcmlwdCB0eXBlIGRlZmluaXRpb25zLiDilIJcbiAgLy8g4pSCIFRvIHVwZGF0ZSB0aGVtLCBlZGl0IHRoZSBUeXBlU2NyaXB0IHR5cGVzIGFuZCBydW4gYHBucG0gcHJvcHR5cGVzYC4g4pSCXG4gIC8vIOKUlOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUmFxuICAvKipcbiAgICogQGlnbm9yZVxuICAgKi9cbiAgY2hpbGRyZW46IFByb3BUeXBlcy5ub2RlLFxuICAvKipcbiAgICogQGlnbm9yZVxuICAgKi9cbiAgdmFsdWU6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZFxufSA6IHZvaWQgMDtcbmV4cG9ydCBkZWZhdWx0IERlZmF1bHRQcm9wc1Byb3ZpZGVyO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZURlZmF1bHRQcm9wcyhwYXJhbXMpIHtcbiAgcmV0dXJuIHVzZVN5c3RlbURlZmF1bHRQcm9wcyhwYXJhbXMpO1xufSIsImltcG9ydCBnZW5lcmF0ZVV0aWxpdHlDbGFzc2VzIGZyb20gJ0BtdWkvdXRpbHMvZ2VuZXJhdGVVdGlsaXR5Q2xhc3Nlcyc7XG5pbXBvcnQgZ2VuZXJhdGVVdGlsaXR5Q2xhc3MgZnJvbSAnQG11aS91dGlscy9nZW5lcmF0ZVV0aWxpdHlDbGFzcyc7XG5leHBvcnQgZnVuY3Rpb24gZ2V0U3ZnSWNvblV0aWxpdHlDbGFzcyhzbG90KSB7XG4gIHJldHVybiBnZW5lcmF0ZVV0aWxpdHlDbGFzcygnTXVpU3ZnSWNvbicsIHNsb3QpO1xufVxuY29uc3Qgc3ZnSWNvbkNsYXNzZXMgPSBnZW5lcmF0ZVV0aWxpdHlDbGFzc2VzKCdNdWlTdmdJY29uJywgWydyb290JywgJ2NvbG9yUHJpbWFyeScsICdjb2xvclNlY29uZGFyeScsICdjb2xvckFjdGlvbicsICdjb2xvckVycm9yJywgJ2NvbG9yRGlzYWJsZWQnLCAnZm9udFNpemVJbmhlcml0JywgJ2ZvbnRTaXplU21hbGwnLCAnZm9udFNpemVNZWRpdW0nLCAnZm9udFNpemVMYXJnZSddKTtcbmV4cG9ydCBkZWZhdWx0IHN2Z0ljb25DbGFzc2VzOyIsImV4cG9ydCBjb25zdCBkZWZhdWx0U3R5bGVzID0ge1xuICB0cmFuc2l0aW9uOiAnbm9uZSdcbn07XG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVJlZHVjZWRNb3Rpb25TdHlsZXMocmVkdWNlZE1vdGlvbiwgc3R5bGVzKSB7XG4gIGlmIChyZWR1Y2VkTW90aW9uID09PSAnYWx3YXlzJykge1xuICAgIHJldHVybiBzdHlsZXM7XG4gIH1cbiAgaWYgKHJlZHVjZWRNb3Rpb24gPT09ICdzeXN0ZW0nKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICdAbWVkaWEgKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknOiBzdHlsZXNcbiAgICB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufSIsImltcG9ydCB7IGRlZmF1bHRTdHlsZXMsIHJlc29sdmVSZWR1Y2VkTW90aW9uU3R5bGVzIH0gZnJvbSBcIi4uL3N0eWxlcy9yZWR1Y2VkTW90aW9uLm1qc1wiO1xuZXhwb3J0IGNvbnN0IHJlZmxvdyA9IG5vZGUgPT4gbm9kZS5zY3JvbGxUb3A7XG5jb25zdCBERUZBVUxUX1RSQU5TTEFURV9PRkZTRVQgPSB7XG4gIG9mZnNldFg6IDAsXG4gIG9mZnNldFk6IDBcbn07XG5jb25zdCBFTVBUWV9TVFlMRSA9IHt9O1xuY29uc3QgREVGQVVMVF9UUkFOU0lUSU9OX1BST1BTID0gWydhbGwnXTtcbmNvbnN0IEVNUFRZX09QVElPTlMgPSB7fTtcbmNvbnN0IHRyYW5zZm9ybU9mZnNldEluZGV4ZXMgPSB7XG4gIG1hdHJpeDogWzQsIDVdLFxuICBtYXRyaXgzZDogWzEyLCAxM10sXG4gIHRyYW5zbGF0ZTogWzAsIDFdLFxuICB0cmFuc2xhdGUzZDogWzAsIDFdLFxuICB0cmFuc2xhdGVYOiBbMCwgbnVsbF0sXG4gIHRyYW5zbGF0ZVk6IFtudWxsLCAwXVxufTtcbmZ1bmN0aW9uIHBhcnNlVHJhbnNsYXRlVmFsdWUodmFsdWUpIHtcbiAgY29uc3QgcGFyc2VkVmFsdWUgPSBwYXJzZUZsb2F0KHZhbHVlID8/ICcnKTtcbiAgcmV0dXJuIE51bWJlci5pc05hTihwYXJzZWRWYWx1ZSkgPyAwIDogcGFyc2VkVmFsdWU7XG59XG5mdW5jdGlvbiBwYXJzZVRyYW5zZm9ybSh0cmFuc2Zvcm0pIHtcbiAgY29uc3QgbWF0Y2ggPSB0cmFuc2Zvcm0ubWF0Y2goL14obWF0cml4fG1hdHJpeDNkfHRyYW5zbGF0ZXx0cmFuc2xhdGUzZHx0cmFuc2xhdGVYfHRyYW5zbGF0ZVkpXFwoKC4rKVxcKSQvKTtcbiAgaWYgKCFtYXRjaCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiB7XG4gICAgdHlwZTogbWF0Y2hbMV0sXG4gICAgdmFsdWVzOiBtYXRjaFsyXS5zcGxpdCgnLCcpLm1hcChwYXJzZVRyYW5zbGF0ZVZhbHVlKVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0VHJhbnNsYXRlT2Zmc2V0VmFsdWUodmFsdWVzLCBpbmRleCkge1xuICByZXR1cm4gaW5kZXggPT09IG51bGwgPyAwIDogdmFsdWVzW2luZGV4XSB8fCAwO1xufVxuXG4vKipcbiAqIEV4dHJhY3RzIHRoZSB4L3kgdHJhbnNsYXRpb24gZnJvbSBhIENTUyB0cmFuc2Zvcm0gc3RyaW5nLlxuICpcbiAqIFRyYW5zaXRpb24gY29tcG9uZW50cyB1c2UgdGhlc2Ugb2Zmc2V0cyB3aGVuIGNhbGN1bGF0aW5nIG9mZi1zY3JlZW4gcG9zaXRpb25zOlxuICogaWYgYW4gZWxlbWVudCBpcyBhbHJlYWR5IHRyYW5zbGF0ZWQsIHRoZSBkaXN0YW5jZSBuZWVkZWQgdG8gaGlkZSBpdCBtdXN0IHN0YXJ0XG4gKiBmcm9tIHRoYXQgdmlzdWFsIHBvc2l0aW9uIGluc3RlYWQgb2YgaXRzIHVudHJhbnNmb3JtZWQgbGF5b3V0IHBvc2l0aW9uLlxuICpcbiAqIENTU09NIGNvbW1vbmx5IHNlcmlhbGl6ZXMgdHJhbnNsYXRpb25zIGFzIG1hdHJpeCgpIG9yIG1hdHJpeDNkKCksIHdoaWxlIGlubGluZVxuICogZ2VzdHVyZSBzdHlsZXMgbWF5IHVzZSB0cmFuc2xhdGUoKSwgdHJhbnNsYXRlM2QoKSwgdHJhbnNsYXRlWCgpLCBvclxuICogdHJhbnNsYXRlWSgpLiBUaGlzIGhlbHBlciBub3JtYWxpemVzIHRob3NlIHN1cHBvcnRlZCBmb3JtcyBpbnRvIG51bWVyaWMgcGl4ZWxcbiAqIG9mZnNldHMgYW5kIHJldHVybnMgemVybyBvZmZzZXRzIGZvciBlbXB0eSwgbm9uZSwgb3IgdW5zdXBwb3J0ZWQgdHJhbnNmb3Jtcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFRyYW5zbGF0ZU9mZnNldHModHJhbnNmb3JtKSB7XG4gIGlmICghdHJhbnNmb3JtIHx8IHRyYW5zZm9ybSA9PT0gJ25vbmUnKSB7XG4gICAgcmV0dXJuIERFRkFVTFRfVFJBTlNMQVRFX09GRlNFVDtcbiAgfVxuICBjb25zdCBwYXJzZWRUcmFuc2Zvcm0gPSBwYXJzZVRyYW5zZm9ybSh0cmFuc2Zvcm0pO1xuICBpZiAoIXBhcnNlZFRyYW5zZm9ybSkge1xuICAgIHJldHVybiBERUZBVUxUX1RSQU5TTEFURV9PRkZTRVQ7XG4gIH1cbiAgY29uc3Qge1xuICAgIHR5cGUsXG4gICAgdmFsdWVzXG4gIH0gPSBwYXJzZWRUcmFuc2Zvcm07XG4gIGNvbnN0IG9mZnNldEluZGV4ZXMgPSB0cmFuc2Zvcm1PZmZzZXRJbmRleGVzW3R5cGVdO1xuICBpZiAoIW9mZnNldEluZGV4ZXMpIHtcbiAgICByZXR1cm4gREVGQVVMVF9UUkFOU0xBVEVfT0ZGU0VUO1xuICB9XG4gIHJldHVybiB7XG4gICAgb2Zmc2V0WDogZ2V0VHJhbnNsYXRlT2Zmc2V0VmFsdWUodmFsdWVzLCBvZmZzZXRJbmRleGVzWzBdKSxcbiAgICBvZmZzZXRZOiBnZXRUcmFuc2xhdGVPZmZzZXRWYWx1ZSh2YWx1ZXMsIG9mZnNldEluZGV4ZXNbMV0pXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplZFRyYW5zaXRpb25DYWxsYmFjayhub2RlUmVmLCBjYWxsYmFjaykge1xuICByZXR1cm4gbWF5YmVJc0FwcGVhcmluZyA9PiB7XG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICBjb25zdCBub2RlID0gbm9kZVJlZi5jdXJyZW50O1xuICAgICAgLy8gRW50ZXIgY2FsbGJhY2tzIHJlY2VpdmUgaXNBcHBlYXJpbmc7IGV4aXQgY2FsbGJhY2tzIGRvIG5vdC5cbiAgICAgIGlmIChtYXliZUlzQXBwZWFyaW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY2FsbGJhY2sobm9kZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYWxsYmFjayhub2RlLCBtYXliZUlzQXBwZWFyaW5nKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG4vKipcbiAqIFJldHVybiB0aGUgY2hpbGQgc3R5bGUgZm9yIGEgdHJhbnNpdGlvbi4gUmV1c2UgcHJlZGVmaW5lZCBzdHlsZSBvYmplY3RzIHdoZW5cbiAqIG5vIGN1c3RvbSBzdHlsZXMgYXJlIHByZXNlbnQgc28gbWVtb2l6ZWQgY2hpbGRyZW4gc2VlIHRoZSBzYW1lIG9iamVjdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFRyYW5zaXRpb25DaGlsZFN0eWxlKHN0YXRlLCBpblByb3AsIGJhc2VTdHlsZXMsIGhpZGRlblN0eWxlcywgc3R5bGVQcm9wLCBjaGlsZFN0eWxlKSB7XG4gIGNvbnN0IGJhc2UgPSBzdGF0ZSA9PT0gJ2V4aXRlZCcgJiYgIWluUHJvcCA/IGhpZGRlblN0eWxlcyA6IGJhc2VTdHlsZXNbc3RhdGVdIHx8IGJhc2VTdHlsZXMuZXhpdGVkO1xuICByZXR1cm4gc3R5bGVQcm9wIHx8IGNoaWxkU3R5bGUgPyB7XG4gICAgLi4uYmFzZSxcbiAgICAuLi5zdHlsZVByb3AsXG4gICAgLi4uY2hpbGRTdHlsZVxuICB9IDogYmFzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUcmFuc2l0aW9uUHJvcHMocHJvcHMsIG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHRpbWVvdXQsXG4gICAgZWFzaW5nLFxuICAgIHN0eWxlID0gRU1QVFlfU1RZTEVcbiAgfSA9IHByb3BzO1xuICByZXR1cm4ge1xuICAgIGR1cmF0aW9uOiBzdHlsZS50cmFuc2l0aW9uRHVyYXRpb24gPz8gKHR5cGVvZiB0aW1lb3V0ID09PSAnbnVtYmVyJyA/IHRpbWVvdXQgOiB0aW1lb3V0W29wdGlvbnMubW9kZV0gfHwgMCksXG4gICAgZWFzaW5nOiBzdHlsZS50cmFuc2l0aW9uVGltaW5nRnVuY3Rpb24gPz8gKHR5cGVvZiBlYXNpbmcgPT09ICdvYmplY3QnID8gZWFzaW5nW29wdGlvbnMubW9kZV0gOiBlYXNpbmcpLFxuICAgIGRlbGF5OiBzdHlsZS50cmFuc2l0aW9uRGVsYXlcbiAgfTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIENTUyB0aGF0IGRpc2FibGVzIGNvbXBvbmVudC1vd25lZCB0cmFuc2l0aW9ucyB3aGVuIHJlZHVjZWQgbW90aW9uIGlzIGFjdGl2ZS5cbiAqIFBhc3MgY3VzdG9tIHN0eWxlcyBvbmx5IHdoZW4gdGhlIGRlZmF1bHQgYHRyYW5zaXRpb246IG5vbmVgIHJlc2V0IGlzIG5vdCBlbm91Z2guXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRSZWR1Y2VkTW90aW9uU3R5bGVzKHRoZW1lLCBzdHlsZXMpIHtcbiAgY29uc3QgcmVzb2x2ZWRTdHlsZXMgPSBzdHlsZXMgPz8gZGVmYXVsdFN0eWxlcztcbiAgcmV0dXJuIHJlc29sdmVSZWR1Y2VkTW90aW9uU3R5bGVzKHRoZW1lLm1vdGlvbj8ucmVkdWNlZE1vdGlvbiwgcmVzb2x2ZWRTdHlsZXMpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRyYW5zaXRpb25TdHlsZXModGhlbWUsIHByb3BzID0gREVGQVVMVF9UUkFOU0lUSU9OX1BST1BTLCBvcHRpb25zID0gRU1QVFlfT1BUSU9OUykge1xuICBjb25zdCB0cmFuc2l0aW9uID0gdGhlbWUudHJhbnNpdGlvbnM/LmNyZWF0ZT8uKHByb3BzLCBvcHRpb25zKTtcbiAgY29uc3QgcmVkdWNlZE1vdGlvblN0eWxlcyA9IGdldFJlZHVjZWRNb3Rpb25TdHlsZXModGhlbWUpO1xuICBpZiAodHJhbnNpdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHJlZHVjZWRNb3Rpb25TdHlsZXMgPz8gRU1QVFlfU1RZTEU7XG4gIH1cbiAgY29uc3QgdHJhbnNpdGlvblN0eWxlcyA9IHtcbiAgICB0cmFuc2l0aW9uXG4gIH07XG4gIHJldHVybiByZWR1Y2VkTW90aW9uU3R5bGVzID8ge1xuICAgIC4uLnRyYW5zaXRpb25TdHlsZXMsXG4gICAgLi4ucmVkdWNlZE1vdGlvblN0eWxlc1xuICB9IDogdHJhbnNpdGlvblN0eWxlcztcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4JztcbmltcG9ydCBjb21wb3NlQ2xhc3NlcyBmcm9tICdAbXVpL3V0aWxzL2NvbXBvc2VDbGFzc2VzJztcbmltcG9ydCBjYXBpdGFsaXplIGZyb20gXCIuLi91dGlscy9jYXBpdGFsaXplLm1qc1wiO1xuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIi4uL3plcm8tc3R5bGVkL2luZGV4Lm1qc1wiO1xuaW1wb3J0IG1lbW9UaGVtZSBmcm9tIFwiLi4vdXRpbHMvbWVtb1RoZW1lLm1qc1wiO1xuaW1wb3J0IHsgdXNlRGVmYXVsdFByb3BzIH0gZnJvbSBcIi4uL0RlZmF1bHRQcm9wc1Byb3ZpZGVyL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0U3ZnSWNvblV0aWxpdHlDbGFzcyB9IGZyb20gXCIuL3N2Z0ljb25DbGFzc2VzLm1qc1wiO1xuaW1wb3J0IHsgZ2V0VHJhbnNpdGlvblN0eWxlcyB9IGZyb20gXCIuLi90cmFuc2l0aW9ucy91dGlscy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCB1c2VVdGlsaXR5Q2xhc3NlcyA9IG93bmVyU3RhdGUgPT4ge1xuICBjb25zdCB7XG4gICAgY29sb3IsXG4gICAgZm9udFNpemUsXG4gICAgY2xhc3Nlc1xuICB9ID0gb3duZXJTdGF0ZTtcbiAgY29uc3Qgc2xvdHMgPSB7XG4gICAgcm9vdDogWydyb290JywgY29sb3IgIT09ICdpbmhlcml0JyAmJiBgY29sb3Ike2NhcGl0YWxpemUoY29sb3IpfWAsIGBmb250U2l6ZSR7Y2FwaXRhbGl6ZShmb250U2l6ZSl9YF1cbiAgfTtcbiAgcmV0dXJuIGNvbXBvc2VDbGFzc2VzKHNsb3RzLCBnZXRTdmdJY29uVXRpbGl0eUNsYXNzLCBjbGFzc2VzKTtcbn07XG5jb25zdCBTdmdJY29uUm9vdCA9IHN0eWxlZCgnc3ZnJywge1xuICBuYW1lOiAnTXVpU3ZnSWNvbicsXG4gIHNsb3Q6ICdSb290JyxcbiAgb3ZlcnJpZGVzUmVzb2x2ZXI6IChwcm9wcywgc3R5bGVzKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgb3duZXJTdGF0ZVxuICAgIH0gPSBwcm9wcztcbiAgICByZXR1cm4gW3N0eWxlcy5yb290LCBvd25lclN0YXRlLmNvbG9yICE9PSAnaW5oZXJpdCcgJiYgc3R5bGVzW2Bjb2xvciR7Y2FwaXRhbGl6ZShvd25lclN0YXRlLmNvbG9yKX1gXSwgc3R5bGVzW2Bmb250U2l6ZSR7Y2FwaXRhbGl6ZShvd25lclN0YXRlLmZvbnRTaXplKX1gXV07XG4gIH1cbn0pKG1lbW9UaGVtZSgoe1xuICB0aGVtZVxufSkgPT4gKHtcbiAgdXNlclNlbGVjdDogJ25vbmUnLFxuICB3aWR0aDogJzFlbScsXG4gIGhlaWdodDogJzFlbScsXG4gIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICBmbGV4U2hyaW5rOiAwLFxuICAuLi5nZXRUcmFuc2l0aW9uU3R5bGVzKHRoZW1lLCAnZmlsbCcsIHtcbiAgICBkdXJhdGlvbjogKHRoZW1lLnZhcnMgPz8gdGhlbWUpLnRyYW5zaXRpb25zPy5kdXJhdGlvbj8uc2hvcnRlclxuICB9KSxcbiAgdmFyaWFudHM6IFt7XG4gICAgcHJvcHM6IHByb3BzID0+ICFwcm9wcy5oYXNTdmdBc0NoaWxkLFxuICAgIHN0eWxlOiB7XG4gICAgICAvLyB0aGUgPHN2Zz4gd2lsbCBkZWZpbmUgdGhlIHByb3BlcnR5IHRoYXQgaGFzIGBjdXJyZW50Q29sb3JgXG4gICAgICAvLyBmb3IgZXhhbXBsZSBoZXJvaWNvbnMgdXNlcyBmaWxsPVwibm9uZVwiIGFuZCBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgZmlsbDogJ2N1cnJlbnRDb2xvcidcbiAgICB9XG4gIH0sIHtcbiAgICBwcm9wczoge1xuICAgICAgZm9udFNpemU6ICdpbmhlcml0J1xuICAgIH0sXG4gICAgc3R5bGU6IHtcbiAgICAgIGZvbnRTaXplOiAnaW5oZXJpdCdcbiAgICB9XG4gIH0sIHtcbiAgICBwcm9wczoge1xuICAgICAgZm9udFNpemU6ICdzbWFsbCdcbiAgICB9LFxuICAgIHN0eWxlOiB7XG4gICAgICBmb250U2l6ZTogdGhlbWUudHlwb2dyYXBoeT8ucHhUb1JlbT8uKDIwKSB8fCAnMS4yNXJlbSdcbiAgICB9XG4gIH0sIHtcbiAgICBwcm9wczoge1xuICAgICAgZm9udFNpemU6ICdtZWRpdW0nXG4gICAgfSxcbiAgICBzdHlsZToge1xuICAgICAgZm9udFNpemU6IHRoZW1lLnR5cG9ncmFwaHk/LnB4VG9SZW0/LigyNCkgfHwgJzEuNXJlbSdcbiAgICB9XG4gIH0sIHtcbiAgICBwcm9wczoge1xuICAgICAgZm9udFNpemU6ICdsYXJnZSdcbiAgICB9LFxuICAgIHN0eWxlOiB7XG4gICAgICBmb250U2l6ZTogdGhlbWUudHlwb2dyYXBoeT8ucHhUb1JlbT8uKDM1KSB8fCAnMi4xODc1cmVtJ1xuICAgIH1cbiAgfSxcbiAgLy8gVE9ETyB2NSBkZXByZWNhdGUgY29sb3IgcHJvcCwgdjYgcmVtb3ZlIGZvciBzeFxuICAuLi5PYmplY3QuZW50cmllcygodGhlbWUudmFycyA/PyB0aGVtZSkucGFsZXR0ZSkuZmlsdGVyKChbLCB2YWx1ZV0pID0+IHZhbHVlICYmIHZhbHVlLm1haW4pLm1hcCgoW2NvbG9yXSkgPT4gKHtcbiAgICBwcm9wczoge1xuICAgICAgY29sb3JcbiAgICB9LFxuICAgIHN0eWxlOiB7XG4gICAgICBjb2xvcjogKHRoZW1lLnZhcnMgPz8gdGhlbWUpLnBhbGV0dGU/Lltjb2xvcl0/Lm1haW5cbiAgICB9XG4gIH0pKSwge1xuICAgIHByb3BzOiB7XG4gICAgICBjb2xvcjogJ2FjdGlvbidcbiAgICB9LFxuICAgIHN0eWxlOiB7XG4gICAgICBjb2xvcjogKHRoZW1lLnZhcnMgPz8gdGhlbWUpLnBhbGV0dGU/LmFjdGlvbj8uYWN0aXZlXG4gICAgfVxuICB9LCB7XG4gICAgcHJvcHM6IHtcbiAgICAgIGNvbG9yOiAnZGlzYWJsZWQnXG4gICAgfSxcbiAgICBzdHlsZToge1xuICAgICAgY29sb3I6ICh0aGVtZS52YXJzID8/IHRoZW1lKS5wYWxldHRlPy5hY3Rpb24/LmRpc2FibGVkXG4gICAgfVxuICB9LCB7XG4gICAgcHJvcHM6IHtcbiAgICAgIGNvbG9yOiAnaW5oZXJpdCdcbiAgICB9LFxuICAgIHN0eWxlOiB7XG4gICAgICBjb2xvcjogdW5kZWZpbmVkXG4gICAgfVxuICB9XVxufSkpKTtcbmNvbnN0IFN2Z0ljb24gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTdmdJY29uKGluUHJvcHMsIHJlZikge1xuICBjb25zdCBwcm9wcyA9IHVzZURlZmF1bHRQcm9wcyh7XG4gICAgcHJvcHM6IGluUHJvcHMsXG4gICAgbmFtZTogJ011aVN2Z0ljb24nXG4gIH0pO1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgY2xhc3NOYW1lLFxuICAgIGNvbG9yID0gJ2luaGVyaXQnLFxuICAgIGNvbXBvbmVudCA9ICdzdmcnLFxuICAgIGZvbnRTaXplID0gJ21lZGl1bScsXG4gICAgaHRtbENvbG9yLFxuICAgIGluaGVyaXRWaWV3Qm94ID0gZmFsc2UsXG4gICAgdGl0bGVBY2Nlc3MsXG4gICAgdmlld0JveCA9ICcwIDAgMjQgMjQnLFxuICAgIC4uLm90aGVyXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgaGFzU3ZnQXNDaGlsZCA9IC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChjaGlsZHJlbikgJiYgY2hpbGRyZW4udHlwZSA9PT0gJ3N2Zyc7XG4gIGNvbnN0IG93bmVyU3RhdGUgPSB7XG4gICAgLi4ucHJvcHMsXG4gICAgY29sb3IsXG4gICAgY29tcG9uZW50LFxuICAgIGZvbnRTaXplLFxuICAgIGluc3RhbmNlRm9udFNpemU6IGluUHJvcHMuZm9udFNpemUsXG4gICAgaW5oZXJpdFZpZXdCb3gsXG4gICAgdmlld0JveCxcbiAgICBoYXNTdmdBc0NoaWxkXG4gIH07XG4gIGNvbnN0IG1vcmUgPSB7fTtcbiAgaWYgKCFpbmhlcml0Vmlld0JveCkge1xuICAgIG1vcmUudmlld0JveCA9IHZpZXdCb3g7XG4gIH1cbiAgY29uc3QgY2xhc3NlcyA9IHVzZVV0aWxpdHlDbGFzc2VzKG93bmVyU3RhdGUpO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3hzKFN2Z0ljb25Sb290LCB7XG4gICAgYXM6IGNvbXBvbmVudCxcbiAgICBjbGFzc05hbWU6IGNsc3goY2xhc3Nlcy5yb290LCBjbGFzc05hbWUpLFxuICAgIGZvY3VzYWJsZTogXCJmYWxzZVwiLFxuICAgIGNvbG9yOiBodG1sQ29sb3IsXG4gICAgXCJhcmlhLWhpZGRlblwiOiB0aXRsZUFjY2VzcyA/IHVuZGVmaW5lZCA6IHRydWUsXG4gICAgcm9sZTogdGl0bGVBY2Nlc3MgPyAnaW1nJyA6IHVuZGVmaW5lZCxcbiAgICByZWY6IHJlZixcbiAgICAuLi5tb3JlLFxuICAgIC4uLm90aGVyLFxuICAgIC4uLihoYXNTdmdBc0NoaWxkICYmIGNoaWxkcmVuLnByb3BzKSxcbiAgICBvd25lclN0YXRlOiBvd25lclN0YXRlLFxuICAgIGNoaWxkcmVuOiBbaGFzU3ZnQXNDaGlsZCA/IGNoaWxkcmVuLnByb3BzLmNoaWxkcmVuIDogY2hpbGRyZW4sIHRpdGxlQWNjZXNzID8gLyojX19QVVJFX18qL19qc3goXCJ0aXRsZVwiLCB7XG4gICAgICBjaGlsZHJlbjogdGl0bGVBY2Nlc3NcbiAgICB9KSA6IG51bGxdXG4gIH0pO1xufSk7XG5wcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBTdmdJY29uLnByb3BUeXBlcyAvKiByZW1vdmUtcHJvcHR5cGVzICovID0ge1xuICAvLyDilIzilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgV2FybmluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJBcbiAgLy8g4pSCIFRoZXNlIFByb3BUeXBlcyBhcmUgZ2VuZXJhdGVkIGZyb20gdGhlIFR5cGVTY3JpcHQgdHlwZSBkZWZpbml0aW9ucy4g4pSCXG4gIC8vIOKUgiAgICBUbyB1cGRhdGUgdGhlbSwgZWRpdCB0aGUgZC50cyBmaWxlIGFuZCBydW4gYHBucG0gcHJvcHR5cGVzYC4gICAgIOKUglxuICAvLyDilJTilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJhcbiAgLyoqXG4gICAqIE5vZGUgcGFzc2VkIGludG8gdGhlIFNWRyBlbGVtZW50LlxuICAgKi9cbiAgY2hpbGRyZW46IFByb3BUeXBlcy5ub2RlLFxuICAvKipcbiAgICogT3ZlcnJpZGUgb3IgZXh0ZW5kIHRoZSBzdHlsZXMgYXBwbGllZCB0byB0aGUgY29tcG9uZW50LlxuICAgKi9cbiAgY2xhc3NlczogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgLyoqXG4gICAqIFRoZSBjb2xvciBvZiB0aGUgY29tcG9uZW50LlxuICAgKiBJdCBzdXBwb3J0cyBib3RoIGRlZmF1bHQgYW5kIGN1c3RvbSB0aGVtZSBjb2xvcnMsIHdoaWNoIGNhbiBiZSBhZGRlZCBhcyBzaG93biBpbiB0aGVcbiAgICogW3BhbGV0dGUgY3VzdG9taXphdGlvbiBndWlkZV0oaHR0cHM6Ly9tdWkuY29tL21hdGVyaWFsLXVpL2N1c3RvbWl6YXRpb24vcGFsZXR0ZS8jY3VzdG9tLWNvbG9ycykuXG4gICAqIFlvdSBjYW4gdXNlIHRoZSBgaHRtbENvbG9yYCBwcm9wIHRvIGFwcGx5IGEgY29sb3IgYXR0cmlidXRlIHRvIHRoZSBTVkcgZWxlbWVudC5cbiAgICogQGRlZmF1bHQgJ2luaGVyaXQnXG4gICAqL1xuICBjb2xvcjogUHJvcFR5cGVzIC8qIEB0eXBlc2NyaXB0LXRvLXByb3B0eXBlcy1pZ25vcmUgKi8ub25lT2ZUeXBlKFtQcm9wVHlwZXMub25lT2YoWydpbmhlcml0JywgJ2FjdGlvbicsICdkaXNhYmxlZCcsICdwcmltYXJ5JywgJ3NlY29uZGFyeScsICdlcnJvcicsICdpbmZvJywgJ3N1Y2Nlc3MnLCAnd2FybmluZyddKSwgUHJvcFR5cGVzLnN0cmluZ10pLFxuICAvKipcbiAgICogVGhlIGNvbXBvbmVudCB1c2VkIGZvciB0aGUgcm9vdCBub2RlLlxuICAgKiBFaXRoZXIgYSBzdHJpbmcgdG8gdXNlIGEgSFRNTCBlbGVtZW50IG9yIGEgY29tcG9uZW50LlxuICAgKi9cbiAgY29tcG9uZW50OiBQcm9wVHlwZXMuZWxlbWVudFR5cGUsXG4gIC8qKlxuICAgKiBUaGUgZm9udFNpemUgYXBwbGllZCB0byB0aGUgaWNvbi4gRGVmYXVsdHMgdG8gMjRweCwgYnV0IGNhbiBiZSBjb25maWd1cmUgdG8gaW5oZXJpdCBmb250IHNpemUuXG4gICAqIEBkZWZhdWx0ICdtZWRpdW0nXG4gICAqL1xuICBmb250U2l6ZTogUHJvcFR5cGVzIC8qIEB0eXBlc2NyaXB0LXRvLXByb3B0eXBlcy1pZ25vcmUgKi8ub25lT2ZUeXBlKFtQcm9wVHlwZXMub25lT2YoWydpbmhlcml0JywgJ2xhcmdlJywgJ21lZGl1bScsICdzbWFsbCddKSwgUHJvcFR5cGVzLnN0cmluZ10pLFxuICAvKipcbiAgICogQXBwbGllcyBhIGNvbG9yIGF0dHJpYnV0ZSB0byB0aGUgU1ZHIGVsZW1lbnQuXG4gICAqL1xuICBodG1sQ29sb3I6IFByb3BUeXBlcy5zdHJpbmcsXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSByb290IG5vZGUgd2lsbCBpbmhlcml0IHRoZSBjdXN0b20gYGNvbXBvbmVudGAncyB2aWV3Qm94IGFuZCB0aGUgYHZpZXdCb3hgXG4gICAqIHByb3Agd2lsbCBiZSBpZ25vcmVkLlxuICAgKiBVc2VmdWwgd2hlbiB5b3Ugd2FudCB0byByZWZlcmVuY2UgYSBjdXN0b20gYGNvbXBvbmVudGAgYW5kIGhhdmUgYFN2Z0ljb25gIHBhc3MgdGhhdFxuICAgKiBgY29tcG9uZW50YCdzIHZpZXdCb3ggdG8gdGhlIHJvb3Qgbm9kZS5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGluaGVyaXRWaWV3Qm94OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIFRoZSBzaGFwZS1yZW5kZXJpbmcgYXR0cmlidXRlLiBUaGUgYmVoYXZpb3Igb2YgdGhlIGRpZmZlcmVudCBvcHRpb25zIGlzIGRlc2NyaWJlZCBvbiB0aGVcbiAgICogW01ETiBXZWIgRG9jc10oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvU1ZHL1JlZmVyZW5jZS9BdHRyaWJ1dGUvc2hhcGUtcmVuZGVyaW5nKS5cbiAgICogSWYgeW91IGFyZSBoYXZpbmcgaXNzdWVzIHdpdGggYmx1cnJ5IGljb25zIHlvdSBzaG91bGQgaW52ZXN0aWdhdGUgdGhpcyBwcm9wLlxuICAgKi9cbiAgc2hhcGVSZW5kZXJpbmc6IFByb3BUeXBlcy5zdHJpbmcsXG4gIC8qKlxuICAgKiBUaGUgc3lzdGVtIHByb3AgdGhhdCBhbGxvd3MgZGVmaW5pbmcgc3lzdGVtIG92ZXJyaWRlcyBhcyB3ZWxsIGFzIGFkZGl0aW9uYWwgQ1NTIHN0eWxlcy5cbiAgICovXG4gIHN4OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuZnVuYywgUHJvcFR5cGVzLm9iamVjdCwgUHJvcFR5cGVzLmJvb2xdKSksIFByb3BUeXBlcy5mdW5jLCBQcm9wVHlwZXMub2JqZWN0XSksXG4gIC8qKlxuICAgKiBQcm92aWRlcyBhIGh1bWFuLXJlYWRhYmxlIHRpdGxlIGZvciB0aGUgZWxlbWVudCB0aGF0IGNvbnRhaW5zIGl0LlxuICAgKiBodHRwczovL3d3dy53My5vcmcvVFIvU1ZHLWFjY2Vzcy8jRXF1aXZhbGVudFxuICAgKi9cbiAgdGl0bGVBY2Nlc3M6IFByb3BUeXBlcy5zdHJpbmcsXG4gIC8qKlxuICAgKiBBbGxvd3MgeW91IHRvIHJlZGVmaW5lIHdoYXQgdGhlIGNvb3JkaW5hdGVzIHdpdGhvdXQgdW5pdHMgbWVhbiBpbnNpZGUgYW4gU1ZHIGVsZW1lbnQuXG4gICAqIEZvciBleGFtcGxlLCBpZiB0aGUgU1ZHIGVsZW1lbnQgaXMgNTAwICh3aWR0aCkgYnkgMjAwIChoZWlnaHQpLFxuICAgKiBhbmQgeW91IHBhc3Mgdmlld0JveD1cIjAgMCA1MCAyMFwiLFxuICAgKiB0aGlzIG1lYW5zIHRoYXQgdGhlIGNvb3JkaW5hdGVzIGluc2lkZSB0aGUgU1ZHIHdpbGwgZ28gZnJvbSB0aGUgdG9wIGxlZnQgY29ybmVyICgwLDApXG4gICAqIHRvIGJvdHRvbSByaWdodCAoNTAsMjApIGFuZCBlYWNoIHVuaXQgd2lsbCBiZSB3b3J0aCAxMHB4LlxuICAgKiBAZGVmYXVsdCAnMCAwIDI0IDI0J1xuICAgKi9cbiAgdmlld0JveDogUHJvcFR5cGVzLnN0cmluZ1xufSA6IHZvaWQgMDtcblN2Z0ljb24ubXVpTmFtZSA9ICdTdmdJY29uJztcbmV4cG9ydCBkZWZhdWx0IFN2Z0ljb247IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgU3ZnSWNvbiBmcm9tIFwiLi9TdmdJY29uLm1qc1wiO1xuXG4vKipcbiAqIFByaXZhdGUgbW9kdWxlIHJlc2VydmVkIGZvciBAbXVpIHBhY2thZ2VzLlxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY3JlYXRlU3ZnSWNvbihwYXRoLCBkaXNwbGF5TmFtZSkge1xuICBmdW5jdGlvbiBDb21wb25lbnQocHJvcHMsIHJlZikge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChTdmdJY29uLCB7XG4gICAgICBcImRhdGEtdGVzdGlkXCI6IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgPyBgJHtkaXNwbGF5TmFtZX1JY29uYCA6IHVuZGVmaW5lZCxcbiAgICAgIHJlZjogcmVmLFxuICAgICAgLi4ucHJvcHMsXG4gICAgICBjaGlsZHJlbjogcGF0aFxuICAgIH0pO1xuICB9XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgLy8gTmVlZCB0byBzZXQgYGRpc3BsYXlOYW1lYCBvbiB0aGUgaW5uZXIgY29tcG9uZW50IGZvciBSZWFjdC5tZW1vLlxuICAgIC8vIFJlYWN0IHByaW9yIHRvIDE2LjE0IGlnbm9yZXMgYGRpc3BsYXlOYW1lYCBvbiB0aGUgd3JhcHBlci5cbiAgICBDb21wb25lbnQuZGlzcGxheU5hbWUgPSBgJHtkaXNwbGF5TmFtZX1JY29uYDtcbiAgfVxuICBDb21wb25lbnQubXVpTmFtZSA9IFN2Z0ljb24ubXVpTmFtZTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5tZW1vKC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKENvbXBvbmVudCkpO1xufSJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDM2LDM3LDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzOCwzOSw0MCw0MSw0Miw0Myw0NCw0NSw0Niw0Nyw0OCw0OSw1MCw1MSw1Miw1Myw1NCw1NSw1Niw1Nyw1OCw1OSw2MCw2MSw2Miw2Myw2NCw2NSw2Niw2Nyw2OCw2OSw3MCw3MSw3Miw3Myw3NCw3NSw3Niw3Nyw3OCw3OSw4MCw4MSw4Miw4Myw4NCw4NSw4Niw4Nyw4OCw4OSw5MCw5MSw5Miw5Myw5NCw5NSw5Niw5Nyw5OCw5OSwxMDAsMTAxLDEwMiwxMDMsMTA0LDEwNSwxMDYsMTA3XSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztDQWNFLENBQUMsV0FBVztFQUNkO0VBSUEsSUFBSSxZQUFZLE9BQU8sV0FBVyxjQUFjLE9BQU87RUFDdkQsSUFBSSxxQkFBcUIsWUFBWSxPQUFPLElBQUksZUFBZSxJQUFJO0VBQ25FLElBQUksb0JBQW9CLFlBQVksT0FBTyxJQUFJLGNBQWMsSUFBSTtFQUNqRSxJQUFJLHNCQUFzQixZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtFQUNyRSxJQUFJLHlCQUF5QixZQUFZLE9BQU8sSUFBSSxtQkFBbUIsSUFBSTtFQUMzRSxJQUFJLHNCQUFzQixZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtFQUNyRSxJQUFJLHNCQUFzQixZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtFQUNyRSxJQUFJLHFCQUFxQixZQUFZLE9BQU8sSUFBSSxlQUFlLElBQUk7RUFHbkUsSUFBSSx3QkFBd0IsWUFBWSxPQUFPLElBQUksa0JBQWtCLElBQUk7RUFDekUsSUFBSSw2QkFBNkIsWUFBWSxPQUFPLElBQUksdUJBQXVCLElBQUk7RUFDbkYsSUFBSSx5QkFBeUIsWUFBWSxPQUFPLElBQUksbUJBQW1CLElBQUk7RUFDM0UsSUFBSSxzQkFBc0IsWUFBWSxPQUFPLElBQUksZ0JBQWdCLElBQUk7RUFDckUsSUFBSSwyQkFBMkIsWUFBWSxPQUFPLElBQUkscUJBQXFCLElBQUk7RUFDL0UsSUFBSSxrQkFBa0IsWUFBWSxPQUFPLElBQUksWUFBWSxJQUFJO0VBQzdELElBQUksa0JBQWtCLFlBQVksT0FBTyxJQUFJLFlBQVksSUFBSTtFQUM3RCxJQUFJLG1CQUFtQixZQUFZLE9BQU8sSUFBSSxhQUFhLElBQUk7RUFDL0QsSUFBSSx5QkFBeUIsWUFBWSxPQUFPLElBQUksbUJBQW1CLElBQUk7RUFDM0UsSUFBSSx1QkFBdUIsWUFBWSxPQUFPLElBQUksaUJBQWlCLElBQUk7RUFDdkUsSUFBSSxtQkFBbUIsWUFBWSxPQUFPLElBQUksYUFBYSxJQUFJO0VBRS9ELFNBQVMsbUJBQW1CLE1BQU07R0FDaEMsT0FBTyxPQUFPLFNBQVMsWUFBWSxPQUFPLFNBQVMsY0FDbkQsU0FBUyx1QkFBdUIsU0FBUyw4QkFBOEIsU0FBUyx1QkFBdUIsU0FBUywwQkFBMEIsU0FBUyx1QkFBdUIsU0FBUyw0QkFBNEIsT0FBTyxTQUFTLFlBQVksU0FBUyxTQUFTLEtBQUssYUFBYSxtQkFBbUIsS0FBSyxhQUFhLG1CQUFtQixLQUFLLGFBQWEsdUJBQXVCLEtBQUssYUFBYSxzQkFBc0IsS0FBSyxhQUFhLDBCQUEwQixLQUFLLGFBQWEsMEJBQTBCLEtBQUssYUFBYSx3QkFBd0IsS0FBSyxhQUFhLG9CQUFvQixLQUFLLGFBQWE7RUFDcGxCO0VBRUEsU0FBUyxPQUFPLFFBQVE7R0FDdEIsSUFBSSxPQUFPLFdBQVcsWUFBWSxXQUFXLE1BQU07SUFDakQsSUFBSSxXQUFXLE9BQU87SUFFdEIsUUFBUSxVQUFSO0tBQ0UsS0FBSztNQUNILElBQUksT0FBTyxPQUFPO01BRWxCLFFBQVEsTUFBUjtPQUNFLEtBQUs7T0FDTCxLQUFLO09BQ0wsS0FBSztPQUNMLEtBQUs7T0FDTCxLQUFLO09BQ0wsS0FBSyxxQkFDSCxPQUFPO09BRVQ7UUFDRSxJQUFJLGVBQWUsUUFBUSxLQUFLO1FBRWhDLFFBQVEsY0FBUjtTQUNFLEtBQUs7U0FDTCxLQUFLO1NBQ0wsS0FBSztTQUNMLEtBQUs7U0FDTCxLQUFLLHFCQUNILE9BQU87U0FFVCxTQUNFLE9BQU87UUFDWDtNQUVKO0tBRUYsS0FBSyxtQkFDSCxPQUFPO0lBQ1g7R0FDRjtFQUdGO0VBRUEsSUFBSSxZQUFZO0VBQ2hCLElBQUksaUJBQWlCO0VBQ3JCLElBQUksa0JBQWtCO0VBQ3RCLElBQUksa0JBQWtCO0VBQ3RCLElBQUksVUFBVTtFQUNkLElBQUksYUFBYTtFQUNqQixJQUFJLFdBQVc7RUFDZixJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxJQUFJLFNBQVM7RUFDYixJQUFJLFdBQVc7RUFDZixJQUFJLGFBQWE7RUFDakIsSUFBSSxXQUFXO0VBQ2YsSUFBSSxzQ0FBc0M7RUFFMUMsU0FBUyxZQUFZLFFBQVE7R0FFekIsSUFBSSxDQUFDLHFDQUFxQztJQUN4QyxzQ0FBc0M7SUFFdEMsUUFBUSxPQUFPLENBQUMsK0tBQXlMO0dBQzNNO0dBR0YsT0FBTyxpQkFBaUIsTUFBTSxLQUFLLE9BQU8sTUFBTSxNQUFNO0VBQ3hEO0VBQ0EsU0FBUyxpQkFBaUIsUUFBUTtHQUNoQyxPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxrQkFBa0IsUUFBUTtHQUNqQyxPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxrQkFBa0IsUUFBUTtHQUNqQyxPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxVQUFVLFFBQVE7R0FDekIsT0FBTyxPQUFPLFdBQVcsWUFBWSxXQUFXLFFBQVEsT0FBTyxhQUFhO0VBQzlFO0VBQ0EsU0FBUyxhQUFhLFFBQVE7R0FDNUIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsV0FBVyxRQUFRO0dBQzFCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFDQSxTQUFTLE9BQU8sUUFBUTtHQUN0QixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxPQUFPLFFBQVE7R0FDdEIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsU0FBUyxRQUFRO0dBQ3hCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFDQSxTQUFTLFdBQVcsUUFBUTtHQUMxQixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxhQUFhLFFBQVE7R0FDNUIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsV0FBVyxRQUFRO0dBQzFCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFFQSxRQUFRLFlBQVk7RUFDcEIsUUFBUSxpQkFBaUI7RUFDekIsUUFBUSxrQkFBa0I7RUFDMUIsUUFBUSxrQkFBa0I7RUFDMUIsUUFBUSxVQUFVO0VBQ2xCLFFBQVEsYUFBYTtFQUNyQixRQUFRLFdBQVc7RUFDbkIsUUFBUSxPQUFPO0VBQ2YsUUFBUSxPQUFPO0VBQ2YsUUFBUSxTQUFTO0VBQ2pCLFFBQVEsV0FBVztFQUNuQixRQUFRLGFBQWE7RUFDckIsUUFBUSxXQUFXO0VBQ25CLFFBQVEsY0FBYztFQUN0QixRQUFRLG1CQUFtQjtFQUMzQixRQUFRLG9CQUFvQjtFQUM1QixRQUFRLG9CQUFvQjtFQUM1QixRQUFRLFlBQVk7RUFDcEIsUUFBUSxlQUFlO0VBQ3ZCLFFBQVEsYUFBYTtFQUNyQixRQUFRLFNBQVM7RUFDakIsUUFBUSxTQUFTO0VBQ2pCLFFBQVEsV0FBVztFQUNuQixRQUFRLGFBQWE7RUFDckIsUUFBUSxlQUFlO0VBQ3ZCLFFBQVEsYUFBYTtFQUNyQixRQUFRLHFCQUFxQjtFQUM3QixRQUFRLFNBQVM7Q0FDZixFQUFBLENBQUc7Ozs7O0NDOUtILE9BQU8sVUFBQSwrQkFBQTs7Ozs7Ozs7OztDQ0dULElBQUksd0JBQXdCLE9BQU87Q0FDbkMsSUFBSSxpQkFBaUIsT0FBTyxVQUFVO0NBQ3RDLElBQUksbUJBQW1CLE9BQU8sVUFBVTtDQUV4QyxTQUFTLFNBQVMsS0FBSztFQUN0QixJQUFJLFFBQVEsUUFBUSxRQUFRLEtBQUEsR0FDM0IsTUFBTSxJQUFJLFVBQVUsdURBQXVEO0VBRzVFLE9BQU8sT0FBTyxHQUFHO0NBQ2xCO0NBRUEsU0FBUyxrQkFBa0I7RUFDMUIsSUFBSTtHQUNILElBQUksQ0FBQyxPQUFPLFFBQ1gsT0FBTztHQU1SLElBQUksd0JBQVEsSUFBSSxPQUFPLEtBQUs7R0FDNUIsTUFBTSxLQUFLO0dBQ1gsSUFBSSxPQUFPLG9CQUFvQixLQUFLLENBQUMsQ0FBQyxPQUFPLEtBQzVDLE9BQU87R0FJUixJQUFJLFFBQVEsQ0FBQztHQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQ3ZCLE1BQU0sTUFBTSxPQUFPLGFBQWEsQ0FBQyxLQUFLO0dBS3ZDLElBSGEsT0FBTyxvQkFBb0IsS0FBSyxDQUFDLENBQUMsSUFBSSxTQUFVLEdBQUc7SUFDL0QsT0FBTyxNQUFNO0dBQ2QsQ0FDUyxDQUFDLENBQUMsS0FBSyxFQUFFLE1BQU0sY0FDdkIsT0FBTztHQUlSLElBQUksUUFBUSxDQUFDO0dBQ2IsdUJBQXVCLE1BQU0sRUFBRSxDQUFDLENBQUMsUUFBUSxTQUFVLFFBQVE7SUFDMUQsTUFBTSxVQUFVO0dBQ2pCLENBQUM7R0FDRCxJQUFJLE9BQU8sS0FBSyxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLE1BQy9DLHdCQUNELE9BQU87R0FHUixPQUFPO0VBQ1IsU0FBUyxLQUFLO0dBRWIsT0FBTztFQUNSO0NBQ0Q7Q0FFQSxPQUFPLFVBQVUsZ0JBQWdCLElBQUksT0FBTyxTQUFTLFNBQVUsUUFBUSxRQUFRO0VBQzlFLElBQUk7RUFDSixJQUFJLEtBQUssU0FBUyxNQUFNO0VBQ3hCLElBQUk7RUFFSixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7R0FDMUMsT0FBTyxPQUFPLFVBQVUsRUFBRTtHQUUxQixLQUFLLElBQUksT0FBTyxNQUNmLElBQUksZUFBZSxLQUFLLE1BQU0sR0FBRyxHQUNoQyxHQUFHLE9BQU8sS0FBSztHQUlqQixJQUFJLHVCQUF1QjtJQUMxQixVQUFVLHNCQUFzQixJQUFJO0lBQ3BDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FDbkMsSUFBSSxpQkFBaUIsS0FBSyxNQUFNLFFBQVEsRUFBRSxHQUN6QyxHQUFHLFFBQVEsTUFBTSxLQUFLLFFBQVE7R0FHakM7RUFDRDtFQUVBLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7Q0M5RUEsT0FBTyxVQUFVOzs7OztDQ1hqQixPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssT0FBTyxVQUFVLGNBQWM7Ozs7Ozs7Ozs7O0NDU25FLElBQUksZUFBZSxXQUFXLENBQUM7Q0FHN0IsSUFBSSx1QkFBQSw2QkFBQTtDQUNKLElBQUkscUJBQXFCLENBQUM7Q0FDMUIsSUFBSSxNQUFBLFlBQUE7Q0FFSixlQUFlLFNBQVMsTUFBTTtFQUM1QixJQUFJLFVBQVUsY0FBYztFQUM1QixJQUFJLE9BQU8sWUFBWSxhQUNyQixRQUFRLE1BQU0sT0FBTztFQUV2QixJQUFJO0dBSUYsTUFBTSxJQUFJLE1BQU0sT0FBTztFQUN6QixTQUFTLEdBQUcsQ0FBTztDQUNyQjs7Ozs7Ozs7Ozs7O0NBY0YsU0FBUyxlQUFlLFdBQVcsUUFBUSxVQUFVLGVBQWUsVUFBVTtFQUUxRSxLQUFLLElBQUksZ0JBQWdCLFdBQ3ZCLElBQUksSUFBSSxXQUFXLFlBQVksR0FBRztHQUNoQyxJQUFJO0dBSUosSUFBSTtJQUdGLElBQUksT0FBTyxVQUFVLGtCQUFrQixZQUFZO0tBQ2pELElBQUksTUFBTSxPQUNQLGlCQUFpQixpQkFBaUIsT0FBTyxXQUFXLFlBQVksZUFBZSwrRkFDQyxPQUFPLFVBQVUsZ0JBQWdCLGlHQUVwSDtLQUNBLElBQUksT0FBTztLQUNYLE1BQU07SUFDUjtJQUNBLFFBQVEsVUFBVSxhQUFhLENBQUMsUUFBUSxjQUFjLGVBQWUsVUFBVSxNQUFNLG9CQUFvQjtHQUMzRyxTQUFTLElBQUk7SUFDWCxRQUFRO0dBQ1Y7R0FDQSxJQUFJLFNBQVMsRUFBRSxpQkFBaUIsUUFDOUIsY0FDRyxpQkFBaUIsaUJBQWlCLDZCQUNuQyxXQUFXLE9BQU8sZUFBZSw2RkFDNkIsT0FBTyxRQUFRLGdLQUkvRTtHQUVGLElBQUksaUJBQWlCLFNBQVMsRUFBRSxNQUFNLFdBQVcscUJBQXFCO0lBR3BFLG1CQUFtQixNQUFNLFdBQVc7SUFFcEMsSUFBSSxRQUFRLFdBQVcsU0FBUyxJQUFJO0lBRXBDLGFBQ0UsWUFBWSxXQUFXLFlBQVksTUFBTSxXQUFXLFNBQVMsT0FBTyxRQUFRLEdBQzlFO0dBQ0Y7RUFDRjtDQUdOOzs7Ozs7Q0FPQSxlQUFlLG9CQUFvQixXQUFXO0VBRTFDLHFCQUFxQixDQUFDO0NBRTFCO0NBRUEsT0FBTyxVQUFVOzs7Ozs7Ozs7OztDQzdGakIsSUFBSSxVQUFBLG1CQUFBO0NBQ0osSUFBSSxTQUFBLHNCQUFBO0NBRUosSUFBSSx1QkFBQSw2QkFBQTtDQUNKLElBQUksTUFBQSxZQUFBO0NBQ0osSUFBSSxpQkFBQSx1QkFBQTtDQUVKLElBQUksZUFBZSxXQUFXLENBQUM7Q0FHN0IsZUFBZSxTQUFTLE1BQU07RUFDNUIsSUFBSSxVQUFVLGNBQWM7RUFDNUIsSUFBSSxPQUFPLFlBQVksYUFDckIsUUFBUSxNQUFNLE9BQU87RUFFdkIsSUFBSTtHQUlGLE1BQU0sSUFBSSxNQUFNLE9BQU87RUFDekIsU0FBUyxHQUFHLENBQUM7Q0FDZjtDQUdGLFNBQVMsK0JBQStCO0VBQ3RDLE9BQU87Q0FDVDtDQUVBLE9BQU8sVUFBVSxTQUFTLGdCQUFnQixxQkFBcUI7RUFFN0QsSUFBSSxrQkFBa0IsT0FBTyxXQUFXLGNBQWMsT0FBTztFQUM3RCxJQUFJLHVCQUF1Qjs7Ozs7Ozs7Ozs7Ozs7O0VBZ0IzQixTQUFTLGNBQWMsZUFBZTtHQUNwQyxJQUFJLGFBQWEsa0JBQWtCLG1CQUFtQixjQUFjLG9CQUFvQixjQUFjO0dBQ3RHLElBQUksT0FBTyxlQUFlLFlBQ3hCLE9BQU87RUFFWDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFpREEsSUFBSSxZQUFZO0VBSWhCLElBQUksaUJBQWlCO0dBQ25CLE9BQU8sMkJBQTJCLE9BQU87R0FDekMsUUFBUSwyQkFBMkIsUUFBUTtHQUMzQyxNQUFNLDJCQUEyQixTQUFTO0dBQzFDLE1BQU0sMkJBQTJCLFVBQVU7R0FDM0MsUUFBUSwyQkFBMkIsUUFBUTtHQUMzQyxRQUFRLDJCQUEyQixRQUFRO0dBQzNDLFFBQVEsMkJBQTJCLFFBQVE7R0FDM0MsUUFBUSwyQkFBMkIsUUFBUTtHQUUzQyxLQUFLLHFCQUFxQjtHQUMxQixTQUFTO0dBQ1QsU0FBUyx5QkFBeUI7R0FDbEMsYUFBYSw2QkFBNkI7R0FDMUMsWUFBWTtHQUNaLE1BQU0sa0JBQWtCO0dBQ3hCLFVBQVU7R0FDVixPQUFPO0dBQ1AsV0FBVztHQUNYLE9BQU87R0FDUCxPQUFPO0VBQ1Q7Ozs7O0VBT0EsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUVoQixJQUFJLE1BQU0sR0FHUixPQUFPLE1BQU0sS0FBSyxJQUFJLE1BQU0sSUFBSTtRQUdoQyxPQUFPLE1BQU0sS0FBSyxNQUFNO0VBRTVCOzs7Ozs7OztFQVVBLFNBQVMsY0FBYyxTQUFTLE1BQU07R0FDcEMsS0FBSyxVQUFVO0dBQ2YsS0FBSyxPQUFPLFFBQVEsT0FBTyxTQUFTLFdBQVcsT0FBTSxDQUFDO0dBQ3RELEtBQUssUUFBUTtFQUNmO0VBRUEsY0FBYyxZQUFZLE1BQU07RUFFaEMsU0FBUywyQkFBMkIsVUFBVTtHQUUxQyxJQUFJLDBCQUEwQixDQUFDO0dBQy9CLElBQUksNkJBQTZCO0dBRW5DLFNBQVMsVUFBVSxZQUFZLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYyxRQUFRO0lBQzdGLGdCQUFnQixpQkFBaUI7SUFDakMsZUFBZSxnQkFBZ0I7SUFFL0IsSUFBSSxXQUFXO1NBQ1QscUJBQXFCO01BRXZCLElBQUksc0JBQU0sSUFBSSxNQUNaLG1MQUdGO01BQ0EsSUFBSSxPQUFPO01BQ1gsTUFBTTtLQUNSLE9BQU8sSUFBNkMsT0FBTyxZQUFZLGFBQWE7TUFFbEYsSUFBSSxXQUFXLGdCQUFnQixNQUFNO01BQ3JDLElBQ0UsQ0FBQyx3QkFBd0IsYUFFekIsNkJBQTZCLEdBQzdCO09BQ0EsYUFDRSw2RUFDdUIsZUFBZSxnQkFBZ0IsZ0JBQWdCLHNOQUl4RTtPQUNBLHdCQUF3QixZQUFZO09BQ3BDO01BQ0Y7S0FDRjs7SUFFRixJQUFJLE1BQU0sYUFBYSxNQUFNO0tBQzNCLElBQUksWUFBWTtNQUNkLElBQUksTUFBTSxjQUFjLE1BQ3RCLE9BQU8sSUFBSSxjQUFjLFNBQVMsV0FBVyxPQUFPLGVBQWUsOEJBQThCLFNBQVMsZ0JBQWdCLDhCQUE4QjtNQUUxSixPQUFPLElBQUksY0FBYyxTQUFTLFdBQVcsT0FBTyxlQUFlLGlDQUFpQyxNQUFNLGdCQUFnQixtQ0FBbUM7S0FDL0o7S0FDQSxPQUFPO0lBQ1QsT0FDRSxPQUFPLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxZQUFZO0dBRTFFO0dBRUEsSUFBSSxtQkFBbUIsVUFBVSxLQUFLLE1BQU0sS0FBSztHQUNqRCxpQkFBaUIsYUFBYSxVQUFVLEtBQUssTUFBTSxJQUFJO0dBRXZELE9BQU87RUFDVDtFQUVBLFNBQVMsMkJBQTJCLGNBQWM7R0FDaEQsU0FBUyxTQUFTLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYyxRQUFRO0lBQ2hGLElBQUksWUFBWSxNQUFNO0lBRXRCLElBRGUsWUFBWSxTQUNoQixNQUFNLGNBQWM7S0FJN0IsSUFBSSxjQUFjLGVBQWUsU0FBUztLQUUxQyxPQUFPLElBQUksY0FDVCxhQUFhLFdBQVcsT0FBTyxlQUFlLGdCQUFnQixNQUFNLGNBQWMsb0JBQW9CLGdCQUFnQixtQkFBbUIsTUFBTSxlQUFlLE9BQzlKLEVBQWUsYUFBWSxDQUM3QjtJQUNGO0lBQ0EsT0FBTztHQUNUO0dBQ0EsT0FBTywyQkFBMkIsUUFBUTtFQUM1QztFQUVBLFNBQVMsdUJBQXVCO0dBQzlCLE9BQU8sMkJBQTJCLDRCQUE0QjtFQUNoRTtFQUVBLFNBQVMseUJBQXlCLGFBQWE7R0FDN0MsU0FBUyxTQUFTLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYztJQUN4RSxJQUFJLE9BQU8sZ0JBQWdCLFlBQ3pCLE9BQU8sSUFBSSxjQUFjLGVBQWUsZUFBZSxxQkFBcUIsZ0JBQWdCLGlEQUFpRDtJQUUvSSxJQUFJLFlBQVksTUFBTTtJQUN0QixJQUFJLENBQUMsTUFBTSxRQUFRLFNBQVMsR0FBRztLQUM3QixJQUFJLFdBQVcsWUFBWSxTQUFTO0tBQ3BDLE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsZ0JBQWdCLE1BQU0sV0FBVyxvQkFBb0IsZ0JBQWdCLHdCQUF3QjtJQUN0SztJQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztLQUN6QyxJQUFJLFFBQVEsWUFBWSxXQUFXLEdBQUcsZUFBZSxVQUFVLGVBQWUsTUFBTSxJQUFJLEtBQUssb0JBQW9CO0tBQ2pILElBQUksaUJBQWlCLE9BQ25CLE9BQU87SUFFWDtJQUNBLE9BQU87R0FDVDtHQUNBLE9BQU8sMkJBQTJCLFFBQVE7RUFDNUM7RUFFQSxTQUFTLDJCQUEyQjtHQUNsQyxTQUFTLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxjQUFjO0lBQ3hFLElBQUksWUFBWSxNQUFNO0lBQ3RCLElBQUksQ0FBQyxlQUFlLFNBQVMsR0FBRztLQUM5QixJQUFJLFdBQVcsWUFBWSxTQUFTO0tBQ3BDLE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsZ0JBQWdCLE1BQU0sV0FBVyxvQkFBb0IsZ0JBQWdCLHFDQUFxQztJQUNuTDtJQUNBLE9BQU87R0FDVDtHQUNBLE9BQU8sMkJBQTJCLFFBQVE7RUFDNUM7RUFFQSxTQUFTLCtCQUErQjtHQUN0QyxTQUFTLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxjQUFjO0lBQ3hFLElBQUksWUFBWSxNQUFNO0lBQ3RCLElBQUksQ0FBQyxRQUFRLG1CQUFtQixTQUFTLEdBQUc7S0FDMUMsSUFBSSxXQUFXLFlBQVksU0FBUztLQUNwQyxPQUFPLElBQUksY0FBYyxhQUFhLFdBQVcsT0FBTyxlQUFlLGdCQUFnQixNQUFNLFdBQVcsb0JBQW9CLGdCQUFnQiwwQ0FBMEM7SUFDeEw7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxPQUFPLDJCQUEyQixRQUFRO0VBQzVDO0VBRUEsU0FBUywwQkFBMEIsZUFBZTtHQUNoRCxTQUFTLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxjQUFjO0lBQ3hFLElBQUksRUFBRSxNQUFNLHFCQUFxQixnQkFBZ0I7S0FDL0MsSUFBSSxvQkFBb0IsY0FBYyxRQUFRO0tBQzlDLElBQUksa0JBQWtCLGFBQWEsTUFBTSxTQUFTO0tBQ2xELE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsZ0JBQWdCLE1BQU0sa0JBQWtCLG9CQUFvQixnQkFBZ0IsbUJBQW1CLGtCQUFrQixvQkFBb0IsS0FBSztJQUNuTjtJQUNBLE9BQU87R0FDVDtHQUNBLE9BQU8sMkJBQTJCLFFBQVE7RUFDNUM7RUFFQSxTQUFTLHNCQUFzQixnQkFBZ0I7R0FDN0MsSUFBSSxDQUFDLE1BQU0sUUFBUSxjQUFjLEdBQUc7SUFFaEMsSUFBSSxVQUFVLFNBQVMsR0FDckIsYUFDRSxpRUFBaUUsVUFBVSxTQUFTLHNGQUV0RjtTQUVBLGFBQWEsd0RBQXdEO0lBR3pFLE9BQU87R0FDVDtHQUVBLFNBQVMsU0FBUyxPQUFPLFVBQVUsZUFBZSxVQUFVLGNBQWM7SUFDeEUsSUFBSSxZQUFZLE1BQU07SUFDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUN6QyxJQUFJLEdBQUcsV0FBVyxlQUFlLEVBQUUsR0FDakMsT0FBTztJQUlYLElBQUksZUFBZSxLQUFLLFVBQVUsZ0JBQWdCLFNBQVMsU0FBUyxLQUFLLE9BQU87S0FFOUUsSUFEVyxlQUFlLEtBQ25CLE1BQU0sVUFDWCxPQUFPLE9BQU8sS0FBSztLQUVyQixPQUFPO0lBQ1QsQ0FBQztJQUNELE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsaUJBQWlCLE9BQU8sU0FBUyxJQUFJLFFBQVEsa0JBQWtCLGdCQUFnQix3QkFBd0IsZUFBZSxJQUFJO0dBQ25NO0dBQ0EsT0FBTywyQkFBMkIsUUFBUTtFQUM1QztFQUVBLFNBQVMsMEJBQTBCLGFBQWE7R0FDOUMsU0FBUyxTQUFTLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYztJQUN4RSxJQUFJLE9BQU8sZ0JBQWdCLFlBQ3pCLE9BQU8sSUFBSSxjQUFjLGVBQWUsZUFBZSxxQkFBcUIsZ0JBQWdCLGtEQUFrRDtJQUVoSixJQUFJLFlBQVksTUFBTTtJQUN0QixJQUFJLFdBQVcsWUFBWSxTQUFTO0lBQ3BDLElBQUksYUFBYSxVQUNmLE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsZ0JBQWdCLE1BQU0sV0FBVyxvQkFBb0IsZ0JBQWdCLHlCQUF5QjtJQUV2SyxLQUFLLElBQUksT0FBTyxXQUNkLElBQUksSUFBSSxXQUFXLEdBQUcsR0FBRztLQUN2QixJQUFJLFFBQVEsWUFBWSxXQUFXLEtBQUssZUFBZSxVQUFVLGVBQWUsTUFBTSxLQUFLLG9CQUFvQjtLQUMvRyxJQUFJLGlCQUFpQixPQUNuQixPQUFPO0lBRVg7SUFFRixPQUFPO0dBQ1Q7R0FDQSxPQUFPLDJCQUEyQixRQUFRO0VBQzVDO0VBRUEsU0FBUyx1QkFBdUIscUJBQXFCO0dBQ25ELElBQUksQ0FBQyxNQUFNLFFBQVEsbUJBQW1CLEdBQUc7SUFDdkMsYUFBcUQsd0VBQXdFO0lBQzdILE9BQU87R0FDVDtHQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxvQkFBb0IsUUFBUSxLQUFLO0lBQ25ELElBQUksVUFBVSxvQkFBb0I7SUFDbEMsSUFBSSxPQUFPLFlBQVksWUFBWTtLQUNqQyxhQUNFLGdHQUNjLHlCQUF5QixPQUFPLElBQUksZUFBZSxJQUFJLEdBQ3ZFO0tBQ0EsT0FBTztJQUNUO0dBQ0Y7R0FFQSxTQUFTLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxjQUFjO0lBQ3hFLElBQUksZ0JBQWdCLENBQUM7SUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLG9CQUFvQixRQUFRLEtBQUs7S0FDbkQsSUFBSSxVQUFVLG9CQUFvQjtLQUNsQyxJQUFJLGdCQUFnQixRQUFRLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYyxvQkFBb0I7S0FDeEcsSUFBSSxpQkFBaUIsTUFDbkIsT0FBTztLQUVULElBQUksY0FBYyxRQUFRLElBQUksY0FBYyxNQUFNLGNBQWMsR0FDOUQsY0FBYyxLQUFLLGNBQWMsS0FBSyxZQUFZO0lBRXREO0lBQ0EsSUFBSSx1QkFBd0IsY0FBYyxTQUFTLElBQUssNkJBQTZCLGNBQWMsS0FBSyxJQUFJLElBQUksTUFBSztJQUNySCxPQUFPLElBQUksY0FBYyxhQUFhLFdBQVcsT0FBTyxlQUFlLG9CQUFvQixNQUFNLGdCQUFnQixNQUFNLHVCQUF1QixJQUFJO0dBQ3BKO0dBQ0EsT0FBTywyQkFBMkIsUUFBUTtFQUM1QztFQUVBLFNBQVMsb0JBQW9CO0dBQzNCLFNBQVMsU0FBUyxPQUFPLFVBQVUsZUFBZSxVQUFVLGNBQWM7SUFDeEUsSUFBSSxDQUFDLE9BQU8sTUFBTSxTQUFTLEdBQ3pCLE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsb0JBQW9CLE1BQU0sZ0JBQWdCLDJCQUEyQjtJQUU5SSxPQUFPO0dBQ1Q7R0FDQSxPQUFPLDJCQUEyQixRQUFRO0VBQzVDO0VBRUEsU0FBUyxzQkFBc0IsZUFBZSxVQUFVLGNBQWMsS0FBSyxNQUFNO0dBQy9FLE9BQU8sSUFBSSxlQUNSLGlCQUFpQixpQkFBaUIsT0FBTyxXQUFXLFlBQVksZUFBZSxNQUFNLE1BQU0sK0ZBQ1gsT0FBTyxJQUMxRjtFQUNGO0VBRUEsU0FBUyx1QkFBdUIsWUFBWTtHQUMxQyxTQUFTLFNBQVMsT0FBTyxVQUFVLGVBQWUsVUFBVSxjQUFjO0lBQ3hFLElBQUksWUFBWSxNQUFNO0lBQ3RCLElBQUksV0FBVyxZQUFZLFNBQVM7SUFDcEMsSUFBSSxhQUFhLFVBQ2YsT0FBTyxJQUFJLGNBQWMsYUFBYSxXQUFXLE9BQU8sZUFBZSxnQkFBZ0IsV0FBVyxRQUFRLGtCQUFrQixnQkFBZ0Isd0JBQXdCO0lBRXRLLEtBQUssSUFBSSxPQUFPLFlBQVk7S0FDMUIsSUFBSSxVQUFVLFdBQVc7S0FDekIsSUFBSSxPQUFPLFlBQVksWUFDckIsT0FBTyxzQkFBc0IsZUFBZSxVQUFVLGNBQWMsS0FBSyxlQUFlLE9BQU8sQ0FBQztLQUVsRyxJQUFJLFFBQVEsUUFBUSxXQUFXLEtBQUssZUFBZSxVQUFVLGVBQWUsTUFBTSxLQUFLLG9CQUFvQjtLQUMzRyxJQUFJLE9BQ0YsT0FBTztJQUVYO0lBQ0EsT0FBTztHQUNUO0dBQ0EsT0FBTywyQkFBMkIsUUFBUTtFQUM1QztFQUVBLFNBQVMsNkJBQTZCLFlBQVk7R0FDaEQsU0FBUyxTQUFTLE9BQU8sVUFBVSxlQUFlLFVBQVUsY0FBYztJQUN4RSxJQUFJLFlBQVksTUFBTTtJQUN0QixJQUFJLFdBQVcsWUFBWSxTQUFTO0lBQ3BDLElBQUksYUFBYSxVQUNmLE9BQU8sSUFBSSxjQUFjLGFBQWEsV0FBVyxPQUFPLGVBQWUsZ0JBQWdCLFdBQVcsUUFBUSxrQkFBa0IsZ0JBQWdCLHdCQUF3QjtJQUl0SyxLQUFLLElBQUksT0FESyxPQUFPLENBQUMsR0FBRyxNQUFNLFdBQVcsVUFDcEIsR0FBRztLQUN2QixJQUFJLFVBQVUsV0FBVztLQUN6QixJQUFJLElBQUksWUFBWSxHQUFHLEtBQUssT0FBTyxZQUFZLFlBQzdDLE9BQU8sc0JBQXNCLGVBQWUsVUFBVSxjQUFjLEtBQUssZUFBZSxPQUFPLENBQUM7S0FFbEcsSUFBSSxDQUFDLFNBQ0gsT0FBTyxJQUFJLGNBQ1QsYUFBYSxXQUFXLE9BQU8sZUFBZSxZQUFZLE1BQU0sb0JBQW9CLGdCQUFnQixxQkFDakYsS0FBSyxVQUFVLE1BQU0sV0FBVyxNQUFNLElBQUksSUFDN0QsbUJBQW1CLEtBQUssVUFBVSxPQUFPLEtBQUssVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUN2RTtLQUVGLElBQUksUUFBUSxRQUFRLFdBQVcsS0FBSyxlQUFlLFVBQVUsZUFBZSxNQUFNLEtBQUssb0JBQW9CO0tBQzNHLElBQUksT0FDRixPQUFPO0lBRVg7SUFDQSxPQUFPO0dBQ1Q7R0FFQSxPQUFPLDJCQUEyQixRQUFRO0VBQzVDO0VBRUEsU0FBUyxPQUFPLFdBQVc7R0FDekIsUUFBUSxPQUFPLFdBQWY7SUFDRSxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUssYUFDSCxPQUFPO0lBQ1QsS0FBSyxXQUNILE9BQU8sQ0FBQztJQUNWLEtBQUs7S0FDSCxJQUFJLE1BQU0sUUFBUSxTQUFTLEdBQ3pCLE9BQU8sVUFBVSxNQUFNLE1BQU07S0FFL0IsSUFBSSxjQUFjLFFBQVEsZUFBZSxTQUFTLEdBQ2hELE9BQU87S0FHVCxJQUFJLGFBQWEsY0FBYyxTQUFTO0tBQ3hDLElBQUksWUFBWTtNQUNkLElBQUksV0FBVyxXQUFXLEtBQUssU0FBUztNQUN4QyxJQUFJO01BQ0osSUFBSSxlQUFlLFVBQVU7Y0FDcEIsRUFBRSxPQUFPLFNBQVMsS0FBSyxFQUFBLENBQUcsTUFDL0IsSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLEdBQ3BCLE9BQU87TUFBQSxPQUtYLE9BQU8sRUFBRSxPQUFPLFNBQVMsS0FBSyxFQUFBLENBQUcsTUFBTTtPQUNyQyxJQUFJLFFBQVEsS0FBSztPQUNqQixJQUFJO1lBQ0UsQ0FBQyxPQUFPLE1BQU0sRUFBRSxHQUNsQixPQUFPO09BQUE7TUFHYjtLQUVKLE9BQ0UsT0FBTztLQUdULE9BQU87SUFDVCxTQUNFLE9BQU87R0FDWDtFQUNGO0VBRUEsU0FBUyxTQUFTLFVBQVUsV0FBVztHQUVyQyxJQUFJLGFBQWEsVUFDZixPQUFPO0dBSVQsSUFBSSxDQUFDLFdBQ0gsT0FBTztHQUlULElBQUksVUFBVSxxQkFBcUIsVUFDakMsT0FBTztHQUlULElBQUksT0FBTyxXQUFXLGNBQWMscUJBQXFCLFFBQ3ZELE9BQU87R0FHVCxPQUFPO0VBQ1Q7RUFHQSxTQUFTLFlBQVksV0FBVztHQUM5QixJQUFJLFdBQVcsT0FBTztHQUN0QixJQUFJLE1BQU0sUUFBUSxTQUFTLEdBQ3pCLE9BQU87R0FFVCxJQUFJLHFCQUFxQixRQUl2QixPQUFPO0dBRVQsSUFBSSxTQUFTLFVBQVUsU0FBUyxHQUM5QixPQUFPO0dBRVQsT0FBTztFQUNUO0VBSUEsU0FBUyxlQUFlLFdBQVc7R0FDakMsSUFBSSxPQUFPLGNBQWMsZUFBZSxjQUFjLE1BQ3BELE9BQU8sS0FBSztHQUVkLElBQUksV0FBVyxZQUFZLFNBQVM7R0FDcEMsSUFBSSxhQUFhO1FBQ1gscUJBQXFCLE1BQ3ZCLE9BQU87U0FDRixJQUFJLHFCQUFxQixRQUM5QixPQUFPO0dBQUE7R0FHWCxPQUFPO0VBQ1Q7RUFJQSxTQUFTLHlCQUF5QixPQUFPO0dBQ3ZDLElBQUksT0FBTyxlQUFlLEtBQUs7R0FDL0IsUUFBUSxNQUFSO0lBQ0UsS0FBSztJQUNMLEtBQUssVUFDSCxPQUFPLFFBQVE7SUFDakIsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLLFVBQ0gsT0FBTyxPQUFPO0lBQ2hCLFNBQ0UsT0FBTztHQUNYO0VBQ0Y7RUFHQSxTQUFTLGFBQWEsV0FBVztHQUMvQixJQUFJLENBQUMsVUFBVSxlQUFlLENBQUMsVUFBVSxZQUFZLE1BQ25ELE9BQU87R0FFVCxPQUFPLFVBQVUsWUFBWTtFQUMvQjtFQUVBLGVBQWUsaUJBQWlCO0VBQ2hDLGVBQWUsb0JBQW9CLGVBQWU7RUFDbEQsZUFBZSxZQUFZO0VBRTNCLE9BQU87Q0FDVDs7Ozs7Q0N6bEJFLElBQUksVUFBQSxtQkFBQTtDQUtKLE9BQU8sVUFBQSxnQ0FBQSxDQUFBLENBQStDLFFBQVEsV0FBVyxJQUFtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNvQjlGLFNBQXdCLGVBQWUsT0FBTyxpQkFBaUIsVUFBVSxLQUFBLEdBQVc7Q0FDbEYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLFlBQVksT0FBTztFQUM1QixNQUFNLE9BQU8sTUFBTTtFQUNuQixJQUFJLFNBQVM7RUFDYixJQUFJLFFBQVE7RUFDWixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssR0FBRztHQUN2QyxNQUFNLFFBQVEsS0FBSztHQUNuQixJQUFJLE9BQU87SUFDVCxXQUFXLFVBQVUsT0FBTyxLQUFLLE9BQU8sZ0JBQWdCLEtBQUs7SUFDN0QsUUFBUTtJQUNSLElBQUksV0FBVyxRQUFRLFFBQ3JCLFVBQVUsTUFBTSxRQUFRO0dBRTVCO0VBQ0Y7RUFDQSxPQUFPLFlBQVk7Q0FDckI7Q0FDQSxPQUFPO0FBQ1Q7OztBQy9DQSxTQUF3QixXQUFXLFFBQVE7Q0FDekMsSUFBSSxPQUFPLFdBQVcsVUFDcEIsTUFBTSxJQUFJLE1BQThDLHNEQUErRTtDQUV6SSxPQUFPLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxZQUFZLElBQUksT0FBTyxNQUFNLENBQUM7QUFDeEQ7Ozs7OztBQ1RBLElBQUEscUJBQWU7Ozs7Ozs7QUNVZixTQUF3QixlQUFlLFFBQVEsUUFBUTtDQUNyRCxNQUFNLGdCQUFnQixNQUFNLFFBQVEsTUFBTTtDQUMxQyxNQUFNLGdCQUFnQixNQUFNLFFBQVEsTUFBTTtDQUMxQyxJQUFJLFlBQVksTUFBTSxHQUNwQixPQUFPO01BQ0YsSUFBSSxxQkFBcUIsTUFBTSxHQUNwQyxPQUFPLE1BQU0sTUFBTTtNQUNkLElBQUksaUJBQWlCLGVBQzFCLE9BQU8sV0FBVyxRQUFRLE1BQU07TUFDM0IsSUFBSSxrQkFBa0IsZUFDM0IsT0FBTyxNQUFNLE1BQU07TUFFbkIsT0FBTyxZQUFZLFFBQVEsTUFBTTtBQUVyQztBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLElBQUksSUFBSTtDQUNSLE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE1BQU0sU0FBUyxJQUFJLE1BQU0sRUFBRTtDQUMzQixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksS0FBSyxHQUN2QixPQUFPLEtBQUssTUFBTSxNQUFNLEVBQUU7Q0FFNUIsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLFFBQVE7Q0FDM0IsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sUUFBUTtFQUN4QixJQUFJLFFBQVEsZUFBZSxRQUFRLGlCQUFpQixRQUFRLGFBQzFEO0VBRUYsT0FBTyxPQUFPLE1BQU0sT0FBTyxJQUFJO0NBQ2pDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLFFBQVEsUUFBUTtDQUNsQyxNQUFNLEtBQUssT0FBTztDQUNsQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUssR0FDdEMsT0FBTyxLQUFLLEtBQUssTUFBTSxPQUFPLEVBQUU7Q0FFbEMsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxPQUFPLE9BQU8sVUFBVSxZQUFZLFVBQVUsUUFBUSxFQUFFLGlCQUFpQixXQUFXLEVBQUUsaUJBQWlCO0FBQ3pHO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVO0FBQ2hEO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztDQUNuQyxPQUFPLE9BQU8sVUFBVSxZQUFZLFVBQVUsUUFBUSxpQkFBaUIsVUFBVSxpQkFBaUI7QUFDcEc7QUFDQSxTQUFTLE1BQU0sT0FBTztDQUVwQixPQUFPLGtCQUFrQixLQUFLLElBQUksTUFBTSxRQUFRLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSSxZQUFZLEtBQUssSUFBSTtBQUNwRztBQUNBLFNBQVMsWUFBWSxRQUFRLFFBQVE7Q0FDbkMsS0FBSyxNQUFNLE9BQU8sUUFBUTtFQUN4QixJQUFJLFFBQVEsZUFBZSxRQUFRLGlCQUFpQixRQUFRLGFBQzFEO0VBRUYsSUFBSSxPQUFPLFFBQ1QsT0FBTyxPQUFPLGVBQWUsT0FBTyxNQUFNLE9BQU8sSUFBSTtPQUVyRCxPQUFPLE9BQU8sTUFBTSxPQUFPLElBQUk7Q0FFbkM7Q0FDQSxPQUFPO0FBQ1Q7OztBQzVFQSxJQUFNLHFCQUE2REEsa0JBQUFBLFFBQVUsVUFBVTtDQUFDQSxrQkFBQUEsUUFBVTtDQUFRQSxrQkFBQUEsUUFBVTtDQUFRQSxrQkFBQUEsUUFBVTtDQUFRQSxrQkFBQUEsUUFBVTtBQUFLLENBQUM7OztBQ0Q5SixTQUF3QixjQUFjLFFBQVE7Q0FDNUMsSUFBSSxVQUFVLE1BQ1osT0FBTztDQUdULEtBQUssTUFBTSxLQUFLLFFBQ2QsT0FBTztDQUVULE9BQU87QUFDVDs7OztBQ0xBLFNBQWdCLGNBQWMsTUFBTTtDQUNsQyxJQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsTUFDdkMsT0FBTztDQUVULE1BQU0sWUFBWSxPQUFPLGVBQWUsSUFBSTtDQUM1QyxRQUFRLGNBQWMsUUFBUSxjQUFjLE9BQU8sYUFBYSxPQUFPLGVBQWUsU0FBUyxNQUFNLFNBQVMsRUFBRSxPQUFPLGVBQWUsU0FBUyxFQUFFLE9BQU8sWUFBWTtBQUN0SztBQUNBLFNBQVMsVUFBVSxRQUFRO0NBQ3pCLElBQWlCLDJCQUFNLGVBQWUsTUFBTSxNQUFBLEdBQUEsZ0JBQUEsbUJBQUEsQ0FBd0IsTUFBTSxLQUFLLENBQUMsY0FBYyxNQUFNLEdBQ2xHLE9BQU87Q0FFVCxNQUFNLFNBQVMsQ0FBQztDQUNoQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUSxRQUFPO0VBQ2pDLE9BQU8sT0FBTyxVQUFVLE9BQU8sSUFBSTtDQUNyQyxDQUFDO0NBQ0QsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JBLFNBQXdCLFVBQVUsUUFBUSxRQUFRLFVBQVUsRUFDMUQsT0FBTyxLQUNULEdBQUc7Q0FDRCxNQUFNLFNBQVMsUUFBUSxRQUFRLEVBQzdCLEdBQUcsT0FDTCxJQUFJO0NBQ0osSUFBSSxjQUFjLE1BQU0sS0FBSyxjQUFjLE1BQU0sR0FDL0MsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVEsUUFBTztFQUNqQyxJQUFpQiwyQkFBTSxlQUFlLE9BQU8sSUFBSSxNQUFBLEdBQUEsZ0JBQUEsbUJBQUEsQ0FBd0IsT0FBTyxJQUFJLEdBQ2xGLE9BQU8sT0FBTyxPQUFPO09BQ2hCLElBQUksY0FBYyxPQUFPLElBQUksS0FFcEMsT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLEdBQUcsS0FBSyxjQUFjLE9BQU8sSUFBSSxHQUU1RSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU87T0FDcEQsSUFBSSxRQUFRLE9BQ2pCLE9BQU8sT0FBTyxjQUFjLE9BQU8sSUFBSSxJQUFJLFVBQVUsT0FBTyxJQUFJLElBQUksT0FBTztPQUUzRSxPQUFPLE9BQU8sT0FBTztDQUV6QixDQUFDO0NBRUgsT0FBTztBQUNUOzs7QUMvREEsSUFBTSxvQkFBb0I7Ozs7Ozs7O0FBUzFCLFNBQWdCLHFCQUFxQixPQUFPLEtBQUs7Q0FDL0MsSUFBSSxDQUFDLE1BQU0sb0JBQW9CLENBQUMsa0JBQWtCLEdBQUcsR0FDbkQsT0FBTztDQUVULE1BQU0sT0FBTyxDQUFDO0NBQ2QsS0FBSyxNQUFNLE9BQU8sS0FDaEIsSUFBSSxJQUFJLFdBQVcsWUFBWSxHQUM3QixLQUFLLEtBQUssR0FBRztDQUdqQixLQUFLLE1BQU0sR0FBRyxNQUFNO0VBQ2xCLE9BQU8sRUFBRSxFQUFFLE1BQU0saUJBQWlCLENBQUMsR0FBRyxNQUFNLEtBQUssRUFBRSxFQUFFLE1BQU0saUJBQWlCLENBQUMsR0FBRyxNQUFNO0NBQ3hGLENBQUM7Q0FDRCxNQUFNLFNBQVM7Q0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssR0FBRztFQUN2QyxNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLFFBQVEsT0FBTztFQUNyQixPQUFPLE9BQU87RUFDZCxPQUFPLE9BQU87Q0FDaEI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixLQUFLO0NBQzlCLEtBQUssTUFBTSxPQUFPLEtBQ2hCLElBQUksSUFBSSxXQUFXLFlBQVksR0FDN0IsT0FBTztDQUdYLE9BQU87QUFDVDtBQUNBLFNBQWdCLGNBQWMsZ0JBQWdCLE9BQU87Q0FDbkQsT0FBTyxVQUFVLE9BQU8sTUFBTSxXQUFXLEdBQUcsTUFBTSxlQUFlLE1BQUssUUFBTyxNQUFNLFdBQVcsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxNQUFNLE1BQU07QUFDbkk7QUFDQSxTQUFnQixrQkFBa0IsT0FBTyxXQUFXO0NBQ2xELE1BQU0sVUFBVSxVQUFVLE1BQU0scUJBQXFCO0NBQ3JELElBQUksQ0FBQyxTQUlELE1BQXdCLElBQUksTUFBTSwrQkFBK0IsSUFBSSxVQUFVLEdBQUcsaUtBQWdLO0NBSXRQLE1BQU0sR0FBRyxnQkFBZ0IsaUJBQWlCO0NBQzFDLE1BQU0sUUFBUSxPQUFPLE1BQU0sQ0FBQyxjQUFjLElBQUksa0JBQWtCLElBQUksQ0FBQztDQUNyRSxPQUFPLE1BQU0saUJBQWlCLGFBQWEsQ0FBQyxDQUFDLEdBQUcsS0FBSztBQUN2RDtBQUNBLFNBQXdCLG9CQUFvQixZQUFZO0NBQ3RELE1BQU0sb0JBQW9CLFlBQVksU0FBUyxXQUFXLFFBQVEsVUFBVSxPQUFPLGNBQWMsU0FBUyxZQUFZO0NBQ3RILFNBQVMsU0FBUyxNQUFNLE1BQU07RUFDNUIsS0FBSyxNQUFNLEdBQUcsU0FBUyxpQkFBaUIsV0FBVyxZQUFZLEdBQUcsR0FBRyxJQUFJLEdBQUcsSUFBSTtFQUNoRixLQUFLLFFBQVEsR0FBRyxTQUFTLGlCQUFpQixXQUFXLFlBQVksS0FBSyxHQUFHLElBQUksR0FBRyxJQUFJO0VBQ3BGLEtBQUssV0FBVyxHQUFHLFNBQVMsaUJBQWlCLFdBQVcsWUFBWSxRQUFRLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDMUYsS0FBSyxRQUFRLEdBQUcsU0FBUyxpQkFBaUIsV0FBVyxZQUFZLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSTtFQUNwRixLQUFLLE9BQU8sR0FBRyxTQUFTO0dBQ3RCLE1BQU0sU0FBUyxpQkFBaUIsV0FBVyxZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSTtHQUN6RSxJQUFJLE9BQU8sU0FBUyxhQUFhLEdBRS9CLE9BQU8sT0FBTyxRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxRQUFRLGNBQWMsUUFBUSxDQUFDLENBQUMsUUFBUSxjQUFjLFFBQVEsQ0FBQyxDQUFDLFFBQVEsT0FBTyxJQUFJO0dBRS9ILE9BQU87RUFDVDtDQUNGO0NBQ0EsTUFBTSxPQUFPLENBQUM7Q0FDZCxNQUFNLG9CQUFtQixTQUFRO0VBQy9CLFNBQVMsTUFBTSxJQUFJO0VBQ25CLE9BQU87Q0FDVDtDQUNBLFNBQVMsZ0JBQWdCO0NBQ3pCLE9BQU87RUFDTCxHQUFHO0VBQ0g7Q0FDRjtBQUNGOzs7QUMzRUEsSUFBTSx5QkFBd0IsV0FBVTtDQUN0QyxNQUFNLHFCQUFxQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSSxTQUFRO0VBQ3pEO0VBQ0EsS0FBSyxPQUFPO0NBQ2QsRUFBRSxLQUFLLENBQUM7Q0FFUixtQkFBbUIsTUFBTSxhQUFhLGdCQUFnQixZQUFZLE1BQU0sWUFBWSxHQUFHO0NBQ3ZGLE9BQU8sbUJBQW1CLFFBQVEsS0FBSyxRQUFRO0VBQzdDLE9BQU87R0FDTCxHQUFHO0lBQ0YsSUFBSSxNQUFNLElBQUk7RUFDakI7Q0FDRixHQUFHLENBQUMsQ0FBQztBQUNQO0FBR0EsU0FBd0Isa0JBQWtCLGFBQWE7Q0FDckQsTUFBTSxFQUNKLFNBQVM7RUFDUCxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtDQUNOLEdBQ0EsT0FBTyxNQUNQLE9BQU8sR0FDUCxHQUFHLFVBQ0Q7Q0FDSixNQUFNLGVBQWUsc0JBQXNCLE1BQU07Q0FDakQsTUFBTSxPQUFPLE9BQU8sS0FBSyxZQUFZO0NBQ3JDLFNBQVMsR0FBRyxLQUFLO0VBRWYsT0FBTyxxQkFETyxPQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sT0FBTyxNQUMxQixLQUFLO0NBQzNDO0NBQ0EsU0FBUyxLQUFLLEtBQUs7RUFFakIsT0FBTyxzQkFETyxPQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sT0FBTyxPQUMxQixPQUFPLE1BQU0sS0FBSztDQUN4RDtDQUNBLFNBQVMsUUFBUSxPQUFPLEtBQUs7RUFDM0IsTUFBTSxXQUFXLEtBQUssUUFBUSxHQUFHO0VBQ2pDLE9BQU8scUJBQXFCLE9BQU8sT0FBTyxXQUFXLFdBQVcsT0FBTyxTQUFTLFFBQVEsS0FBSyxvQkFBeUIsYUFBYSxNQUFNLE9BQU8sT0FBTyxLQUFLLGVBQWUsV0FBVyxPQUFPLEtBQUssYUFBYSxPQUFPLE9BQU8sTUFBTSxLQUFLO0NBQzFPO0NBQ0EsU0FBUyxLQUFLLEtBQUs7RUFDakIsSUFBSSxLQUFLLFFBQVEsR0FBRyxJQUFJLElBQUksS0FBSyxRQUMvQixPQUFPLFFBQVEsS0FBSyxLQUFLLEtBQUssUUFBUSxHQUFHLElBQUksRUFBRTtFQUVqRCxPQUFPLEdBQUcsR0FBRztDQUNmO0NBQ0EsU0FBUyxJQUFJLEtBQUs7RUFFaEIsTUFBTSxXQUFXLEtBQUssUUFBUSxHQUFHO0VBQ2pDLElBQUksYUFBYSxHQUNmLE9BQU8sR0FBRyxLQUFLLEVBQUU7RUFFbkIsSUFBSSxhQUFhLEtBQUssU0FBUyxHQUM3QixPQUFPLEtBQUssS0FBSyxTQUFTO0VBRTVCLE9BQU8sUUFBUSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxRQUFRLFVBQVUsb0JBQW9CO0NBQ3pGO0NBQ0EsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLEdBQ3BDLFVBQVUsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDO0NBRTVCLE9BQU87RUFDQztFQUNOLFFBQVE7RUFDUjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxvQkFBb0I7RUFDcEIsR0FBRztDQUNMO0FBQ0Y7OztBQzVFQSxJQUFNQyxnQkFBYyxDQUFDOztBQUtyQixJQUFhLFNBQVM7Q0FDcEIsSUFBSTtDQUVKLElBQUk7Q0FFSixJQUFJO0NBRUosSUFBSTtDQUVKLElBQUk7QUFDTjtBQUNBLElBQWEsc0JBQXNCLGtCQUFrQixFQUMzQyxPQUNWLENBQUM7QUFDRCxJQUFNLDBCQUEwQixFQUM5QixtQkFBa0IsbUJBQWtCLEVBQ2xDLEtBQUksUUFBTztDQUNULElBQUksU0FBUyxPQUFPLFFBQVEsV0FBVyxNQUFNLE9BQU8sUUFBUTtDQUM1RCxJQUFJLE9BQU8sV0FBVyxVQUNwQixTQUFTLEdBQUcsT0FBTztDQUVyQixPQUFPLGdCQUFnQixjQUFjLGNBQWMsY0FBYyxPQUFPLEtBQUsseUJBQXlCLE9BQU87QUFDL0csRUFDRixHQUNGO0FBQ0EsU0FBZ0Isa0JBQWtCLE9BQU8sV0FBVyxvQkFBb0I7Q0FDdEUsTUFBTSxTQUFTLENBQUM7Q0FDaEIsT0FBTyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sWUFBWSxVQUFVLE9BQU8sZUFBZTtFQUN6RixNQUFNLGFBQWEsbUJBQW1CLE9BQU8sVUFBVTtFQUN2RCxJQUFJLFVBQ0YsT0FBTyxZQUFZO09BRW5CLGVBQWUsUUFBUSxVQUFVO0NBRXJDLENBQUM7QUFDSDtBQUNBLFNBQWdCLG1CQUFtQixRQUFRLE9BQU8sV0FBVyxVQUFVO0NBQ3JFLFVBQVVBO0NBQ1YsSUFBSSxNQUFNLFFBQVEsU0FBUyxHQUFHO0VBQzVCLE1BQU0sY0FBYyxNQUFNLGVBQWU7RUFDekMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLLEdBQ3pDLGdCQUFnQixRQUFRLFlBQVksR0FBRyxZQUFZLEtBQUssRUFBRSxHQUFHLFVBQVUsSUFBSSxLQUFBLEdBQVcsUUFBUTtFQUVoRyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU8sY0FBYyxVQUFVO0VBQ2pDLE1BQU0sY0FBYyxNQUFNLGVBQWU7RUFDekMsTUFBTSxtQkFBbUIsWUFBWSxVQUFVO0VBQy9DLEtBQUssTUFBTSxPQUFPLFdBQ2hCLElBQUksY0FBYyxZQUFZLE1BQU0sR0FBRyxHQUFHO0dBQ3hDLE1BQU0sZUFBZSxrQkFBa0IsTUFBTSxtQkFBbUIsUUFBUSx5QkFBeUIsR0FBRztHQUNwRyxJQUFJLGNBQ0YsZ0JBQWdCLFFBQVEsY0FBYyxVQUFVLE1BQU0sS0FBSyxRQUFRO0VBRXZFLE9BQU8sSUFBSSxPQUFPLGtCQUVoQixnQkFBZ0IsUUFEQyxZQUFZLEdBQUcsR0FDRCxHQUFHLFVBQVUsTUFBTSxLQUFLLFFBQVE7T0FDMUQ7R0FDTCxNQUFNLFNBQVM7R0FDZixPQUFPLFVBQVUsVUFBVTtFQUM3QjtFQUVGLE9BQU87Q0FDVDtDQUNBLFNBQVMsS0FBQSxHQUFXLFNBQVM7Q0FDN0IsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUSxVQUFVLE9BQU8sWUFBWSxVQUFVO0NBQ3RFLE9BQU8sY0FBYyxDQUFDO0NBQ3RCLFNBQVMsVUFBVSxPQUFPLFVBQVU7QUFDdEM7O0FBK0JBLFNBQWdCLDRCQUE0QixjQUFjLHFCQUFxQjtDQUM3RSxNQUFNLEVBQ0osb0JBQW9CLGNBQ2xCO0NBQ0osTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLLEdBQ3pDLE9BQU8sVUFBVSxNQUFNLENBQUM7Q0FFMUIsT0FBTztBQUNUOztBQUdBLFNBQWdCLHdCQUF3QixhQUFhLE9BQU87Q0FDMUQsTUFBTSxpQkFBaUIsWUFBWTtDQUNuQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxRQUFRLEtBQUssR0FBRztFQUNqRCxNQUFNLE1BQU0sZUFBZTtFQUMzQixJQUFJLGNBQWMsTUFBTSxJQUFJLEdBQzFCLE9BQU8sTUFBTTtDQUVqQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQWdCLHdCQUF3QixhQUFhLEdBQUcsUUFBUTtDQUc5RCxPQUFPLHdCQUF3QixhQURWLENBREksNEJBQTRCLFdBQ2hCLEdBQUcsR0FBRyxNQUFNLENBQUMsQ0FBQyxRQUFRLE1BQU0sU0FBUyxVQUFVLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FDM0MsQ0FBQztBQUMxRDs7QUFHQSxTQUFnQix1QkFBdUIsa0JBQWtCLGtCQUFrQjtDQUN6RSxJQUFJLE9BQU8scUJBQXFCLFVBQzlCLE9BQU8sQ0FBQztDQUVWLE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxrQkFBa0IsT0FBTyxLQUFLLGdCQUFnQjtDQUNwRCxJQUFJLE1BQU0sUUFBUSxnQkFBZ0IsR0FDaEMsZ0JBQWdCLFNBQVMsWUFBWSxNQUFNO0VBQ3pDLElBQUksSUFBSSxpQkFBaUIsUUFDdkIsS0FBSyxjQUFjO0NBRXZCLENBQUM7TUFFRCxnQkFBZ0IsU0FBUSxlQUFjO0VBQ3BDLElBQUksaUJBQWlCLGVBQWUsTUFDbEMsS0FBSyxjQUFjO0NBRXZCLENBQUM7Q0FFSCxPQUFPO0FBQ1Q7QUFDQSxTQUFnQix3QkFBd0IsU0FBUztDQUMvQyxNQUFNLEVBQ0osUUFBUSxrQkFDUixhQUFhLGtCQUNiLE1BQU0sZUFDSjtDQUNKLE1BQU0sT0FBTyxjQUFjLHVCQUF1QixrQkFBa0IsZ0JBQWdCO0NBQ3BGLE1BQU0sT0FBTyxPQUFPLEtBQUssSUFBSTtDQUM3QixJQUFJLEtBQUssV0FBVyxHQUNsQixPQUFPO0NBRVQsSUFBSTtDQUNKLE9BQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxNQUFNO0VBQ3pDLElBQUksTUFBTSxRQUFRLGdCQUFnQixHQUFHO0dBQ25DLElBQUksY0FBYyxpQkFBaUIsTUFBTSxPQUFPLGlCQUFpQixLQUFLLGlCQUFpQjtHQUN2RixXQUFXO0VBQ2IsT0FBTyxJQUFJLE9BQU8scUJBQXFCLFlBQVksa0JBQWtCO0dBQ25FLE1BQU0sS0FBSztHQUNYLElBQUksY0FBYyxHQUFHLGVBQWUsT0FBTyxHQUFHLGNBQWMsR0FBRztHQUMvRCxXQUFXO0VBQ2IsT0FDRSxJQUFJLGNBQWM7RUFFcEIsT0FBTztDQUNULEdBQUcsQ0FBQyxDQUFDO0FBQ1A7QUFDQSxTQUFnQixjQUFjLGFBQWEsT0FBTztDQUNoRCxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLE9BQU87Q0FFVCxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsTUFBTTtFQUMvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxLQUFLLFFBQVEsS0FBSyxHQUNoRCxJQUFJLFlBQVksS0FBSyxNQUFNLE9BQ3pCLE9BQU87RUFHWCxNQUFNLFlBQVksT0FBTyxLQUFLLEtBQUs7RUFDbkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLLEdBQ3pDLElBQUksY0FBYyxZQUFZLE1BQU0sVUFBVSxFQUFFLEdBQzlDLE9BQU87Q0FHYjtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xLQSxTQUFnQixlQUFlLGNBQWMsV0FBVyxXQUFXLGVBQWU7Q0FDaEYsSUFBSTtDQUNKLElBQUksT0FBTyxpQkFBaUIsWUFDMUIsUUFBUSxhQUFhLFNBQVM7TUFDekIsSUFBSSxNQUFNLFFBQVEsWUFBWSxHQUNuQyxRQUFRLGFBQWEsY0FBYztNQUM5QixJQUFJLE9BQU8sY0FBYyxVQUM5QixRQUFRLFFBQVEsY0FBYyxXQUFXLE1BQU0sYUFBYSxLQUFLO01BRWpFLFFBQVE7Q0FFVixJQUFJLFdBQ0YsUUFBUSxVQUFVLE9BQU8sV0FBVyxZQUFZO0NBRWxELE9BQU87QUFDVDtBQUNBLFNBQWdCLFFBQVEsS0FBSyxXQUFXLFlBQVksTUFBTSxnQkFBZ0IsS0FBQSxHQUFXO0NBQ25GLElBQUksQ0FBQyxPQUFPLENBQUMsV0FDWCxPQUFPO0NBRVQsTUFBTSxPQUFPLFVBQVUsTUFBTSxHQUFHO0NBR2hDLElBQUksSUFBSSxRQUFRLFdBQVc7RUFDekIsTUFBTSxNQUFNLFlBQVksSUFBSSxNQUFNLE1BQU0sYUFBYTtFQUNyRCxJQUFJLE9BQU8sTUFDVCxPQUFPO0NBRVg7Q0FDQSxPQUFPLFlBQVksS0FBSyxNQUFNLGFBQWE7QUFDN0M7QUFDQSxTQUFTLFlBQVksUUFBUSxNQUFNLGdCQUFnQixLQUFBLEdBQVc7Q0FDNUQsSUFBSSxhQUFhLEtBQUE7Q0FDakIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxRQUFRO0NBQ1osT0FBTyxRQUFRLEtBQUssUUFBUTtFQUMxQixJQUFJLFdBQVcsUUFBUSxXQUFXLEtBQUEsR0FDaEMsT0FBTztFQUVULGFBQWE7RUFDYixTQUFTLE9BQU8sS0FBSztFQUNyQixTQUFTO0NBQ1g7Q0FDQSxJQUFJLGlCQUFpQixXQUFXLEtBQUEsR0FBVztFQUN6QyxNQUFNLFVBQVUsS0FBSyxLQUFLLFNBQVM7RUFDbkMsTUFBTSxlQUFlLEdBQUcsZ0JBQWdCLFlBQVksWUFBWSxLQUFLLFdBQVcsT0FBTztFQUN2RixPQUFPLGFBQWE7Q0FDdEI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUF3QkMsUUFBTSxTQUFTO0NBQ3JDLE1BQU0sRUFDSixNQUNBLGNBQWMsUUFBUSxNQUN0QixVQUNBLGNBQ0U7Q0FHSixNQUFNLE1BQUssVUFBUztFQUNsQixJQUFJLE1BQU0sU0FBUyxNQUNqQixPQUFPO0VBRVQsTUFBTSxZQUFZLE1BQU07RUFDeEIsTUFBTSxRQUFRLE1BQU07RUFDcEIsTUFBTSxlQUFlLFFBQVEsT0FBTyxRQUFRLEtBQUssQ0FBQztFQUNsRCxNQUFNLHNCQUFxQixlQUFjO0dBQ3ZDLE1BQU0sUUFBUSxlQUFlLGNBQWMsV0FBVyxZQUFZLElBQUk7R0FDdEUsT0FBTyxnQkFBZ0IsUUFBUSxRQUFRLEdBQ3BDLGNBQWMsTUFDakI7RUFDRjtFQUNBLE9BQU8sa0JBQWtCLE9BQU8sV0FBVyxrQkFBa0I7Q0FDL0Q7Q0FDQSxHQUFHLFlBQW9ELEdBQ3BELE9BQU8sbUJBQ1Y7Q0FDQSxHQUFHLGNBQWMsQ0FBQyxJQUFJO0NBQ3RCLE9BQU87QUFDVDs7O0FDdEhBLElBQU1DLGdCQUFjLEVBQ2xCLGdCQUFnQixDQUFDLEVBQ25CO0FBQ0EsSUFBTSxhQUFhO0NBQ2pCLEdBQUc7Q0FDSCxHQUFHO0FBQ0w7QUFDQSxJQUFNLGFBQWE7Q0FDakIsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUcsQ0FBQyxRQUFRLE9BQU87Q0FDbkIsR0FBRyxDQUFDLE9BQU8sUUFBUTtBQUNyQjtBQUNBLElBQU0sVUFBVTtDQUNkLFNBQVM7Q0FDVCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7QUFDWjtBQUNBLElBQU0saUJBQWlCLENBQUM7QUFDeEIsS0FBSyxNQUFNLE9BQU8sWUFDaEIsZUFBZSxPQUFPLENBQUMsV0FBVyxJQUFJO0FBRXhDLEtBQUssTUFBTSxlQUFlLFlBQ3hCLEtBQUssTUFBTSxnQkFBZ0IsWUFBWTtDQUNyQyxNQUFNLFdBQVcsV0FBVztDQUM1QixNQUFNLFlBQVksV0FBVztDQUM3QixNQUFNLFFBQVEsTUFBTSxRQUFRLFNBQVMsSUFBSSxVQUFVLEtBQUksUUFBTyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsU0FBUztDQUNyRyxlQUFlLGNBQWMsZ0JBQWdCO0FBQy9DO0FBRUYsS0FBSyxNQUFNLE9BQU8sU0FDaEIsZUFBZSxPQUFPLGVBQWUsUUFBUTs7QUFJL0MsSUFBYSw2QkFBYSxJQUFJLElBQUk7Q0FBQztDQUFLO0NBQU07Q0FBTTtDQUFNO0NBQU07Q0FBTTtDQUFNO0NBQVU7Q0FBYTtDQUFlO0NBQWdCO0NBQWM7Q0FBVztDQUFXO0NBQWdCO0NBQXFCO0NBQW1CO0NBQWU7Q0FBb0I7QUFBZ0IsQ0FBQzs7QUFHbFIsSUFBYSw4QkFBYyxJQUFJLElBQUk7Q0FBQztDQUFLO0NBQU07Q0FBTTtDQUFNO0NBQU07Q0FBTTtDQUFNO0NBQVc7Q0FBYztDQUFnQjtDQUFpQjtDQUFlO0NBQVk7Q0FBWTtDQUFpQjtDQUFzQjtDQUFvQjtDQUFnQjtDQUFxQjtBQUFpQixDQUFDO0FBQ2hTLElBQU0sOEJBQWMsSUFBSSxJQUFJLENBQUMsR0FBRyxZQUFZLEdBQUcsV0FBVyxDQUFDO0FBQzNELFNBQWdCLGdCQUFnQixPQUFPLFVBQVUsY0FBYyxVQUFVO0NBQ3ZFLE1BQU0sZUFBZSxRQUFRLE9BQU8sVUFBVSxJQUFJLEtBQUs7Q0FDdkQsSUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8saUJBQWlCLFVBQzlELFFBQU8sUUFBTztFQUNaLElBQUksT0FBTyxRQUFRLFVBQ2pCLE9BQU87RUFHUCxJQUFJLE9BQU8sUUFBUSxVQUNqQixRQUFRLE1BQU0saUJBQWlCLFNBQVMsNENBQTRDLElBQUksRUFBRTtFQUc5RixJQUFJLE9BQU8saUJBQWlCLFVBQVU7R0FDcEMsSUFBSSxhQUFhLFdBQVcsTUFBTSxLQUFLLFFBQVEsR0FDN0MsT0FBTztHQUVULElBQUksYUFBYSxXQUFXLE1BQU0sS0FBSyxRQUFRLEdBQzdDLE9BQU87R0FFVCxPQUFPLFFBQVEsSUFBSSxLQUFLLGFBQWE7RUFDdkM7RUFDQSxPQUFPLGVBQWU7Q0FDeEI7Q0FFRixJQUFJLE1BQU0sUUFBUSxZQUFZLEdBQzVCLFFBQU8sUUFBTztFQUNaLElBQUksT0FBTyxRQUFRLFVBQ2pCLE9BQU87RUFFVCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUc7RUFFdEIsSUFBSSxDQUFDLE9BQU8sVUFBVSxHQUFHLEdBQ3ZCLFFBQVEsTUFBTSxDQUFDLG9CQUFvQixTQUFTLG1KQUF3SixTQUFTLGdCQUFnQixDQUFDLENBQUMsS0FBSyxJQUFJLENBQUM7T0FDcE8sSUFBSSxNQUFNLGFBQWEsU0FBUyxHQUNyQyxRQUFRLE1BQU07R0FBQyw0QkFBNEIsSUFBSTtHQUFlLDZCQUE2QixLQUFLLFVBQVUsWUFBWSxFQUFFO0dBQUksR0FBRyxJQUFJLEtBQUssYUFBYSxTQUFTLEVBQUU7RUFBc0MsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0VBR3ROLE1BQU0sY0FBYyxhQUFhO0VBQ2pDLElBQUksT0FBTyxHQUNULE9BQU87RUFFVCxJQUFJLE9BQU8sZ0JBQWdCLFVBQ3pCLE9BQU8sQ0FBQztFQUVWLElBQUksT0FBTyxnQkFBZ0IsWUFBWSxZQUFZLFdBQVcsTUFBTSxHQUNsRSxPQUFPLGFBQWEsWUFBWTtFQUVsQyxPQUFPLElBQUk7Q0FDYjtDQUVGLElBQUksT0FBTyxpQkFBaUIsWUFDMUIsT0FBTztDQUdQLFFBQVEsTUFBTSxDQUFDLG9CQUFvQixTQUFTLFlBQVksYUFBYSxnQkFBZ0IsZ0RBQWdELENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQztDQUVuSixhQUFhLEtBQUE7QUFDZjtBQUNBLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE9BQU8sZ0JBQWdCLE9BQU8sV0FBVyxHQUFHLFNBQVM7QUFDdkQ7QUFDQSxTQUFnQixTQUFTLGFBQWEsV0FBVztDQUMvQyxJQUFJLE9BQU8sY0FBYyxZQUFZLGFBQWEsTUFDaEQsT0FBTztDQUVULE9BQU8sWUFBWSxTQUFTO0FBQzlCO0FBR0EsSUFBTSxZQUFZLENBQUMsRUFBRTtBQUNyQixTQUFTLE1BQU0sT0FBTyxNQUFNO0NBQzFCLE1BQU0sUUFBUSxNQUFNLFNBQVNBO0NBQzdCLE1BQU0sY0FBYyxPQUFPLGdCQUFnQixnQkFBZ0IsbUJBQW1CLEtBQUs7Q0FDbkYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN4QixJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksR0FDaEI7RUFFRixNQUFNLGdCQUFnQixlQUFlLFVBQVUsVUFBVSxLQUFLLE1BQU07RUFDcEUsTUFBTSxZQUFZLE1BQU07RUFDeEIsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLFlBQVksVUFBVSxVQUFVO0dBQ3RFLE1BQU0sU0FBUyxXQUFXLE9BQU8sWUFBWTtHQUM3QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUssR0FDN0MsT0FBTyxjQUFjLE1BQU0sU0FBUyxhQUFhLEtBQUs7RUFFMUQsQ0FBQztDQUNIO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxTQUFTLE9BQU87Q0FDdkIsT0FBTyxNQUFNLE9BQU8sVUFBVTtBQUNoQztBQUNBLFNBQVMsWUFBb0QsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDLFFBQVEsS0FBSyxRQUFRO0NBQ3ZHLElBQUksT0FBTztDQUNYLE9BQU87QUFDVCxHQUFHLENBQUMsQ0FBQztBQUNMLFNBQVMsY0FBYztBQUN2QixJQUFhLFNBQVM7QUFDdEIsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxNQUFNLE9BQU8sV0FBVztBQUNqQztBQUNBLFVBQVUsWUFBb0QsTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLFFBQVEsS0FBSyxRQUFRO0NBQ3pHLElBQUksT0FBTztDQUNYLE9BQU87QUFDVCxHQUFHLENBQUMsQ0FBQztBQUNMLFVBQVUsY0FBYztBQUN4QixJQUFhLFVBQVU7QUFDdkIsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxNQUFNLE9BQU8sV0FBVztBQUNqQztBQUNBLFVBQVUsWUFBb0QsTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLFFBQVEsS0FBSyxRQUFRO0NBQ3pHLElBQUksT0FBTztDQUNYLE9BQU87QUFDVCxHQUFHLENBQUMsQ0FBQztBQUNMLFVBQVUsY0FBYzs7O0FDbEt4QixTQUFTLFFBQVEsR0FBRyxRQUFRO0NBQzFCLE1BQU0sV0FBVyxPQUFPLFFBQVEsS0FBSyxVQUFVO0VBQzdDLE1BQU0sWUFBWSxTQUFRLFNBQVE7R0FDaEMsSUFBSSxRQUFRO0VBQ2QsQ0FBQztFQUNELE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBQztDQUNMLE1BQU0sTUFBSyxVQUFTO0VBQ2xCLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLEtBQUssTUFBTSxRQUFRLE9BQ2pCLElBQUksU0FBUyxPQUNYLGVBQWUsUUFBUSxTQUFTLEtBQUssQ0FBQyxLQUFLLENBQUM7RUFHaEQsT0FBTztDQUNUO0NBQ0EsR0FBRyxZQUFvRCxPQUFPLFFBQVEsS0FBSyxVQUFVLE9BQU8sT0FBTyxLQUFLLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQztDQUM1SCxHQUFHLGNBQWMsT0FBTyxRQUFRLEtBQUssVUFBVSxJQUFJLE9BQU8sTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDO0NBQ2hGLE9BQU87QUFDVDs7OztBQ2JBLFNBQWdCLGdCQUFnQixPQUFPO0NBQ3JDLElBQUksT0FBTyxVQUFVLFVBQ25CLE9BQU87Q0FFVCxPQUFPLEdBQUcsTUFBTTtBQUNsQjtBQUNBLFNBQVMsa0JBQWtCLE1BQU0sV0FBVztDQUMxQyxPQUFPQyxRQUFNO0VBQ1g7RUFDQSxVQUFVO0VBQ0M7Q0FDYixDQUFDO0FBQ0g7QUFDQSxJQUFhLFNBQVMsa0JBQWtCLFVBQVUsZUFBZTtBQUNqRSxJQUFhLFlBQVksa0JBQWtCLGFBQWEsZUFBZTtBQUN2RSxJQUFhLGNBQWMsa0JBQWtCLGVBQWUsZUFBZTtBQUMzRSxJQUFhLGVBQWUsa0JBQWtCLGdCQUFnQixlQUFlO0FBQzdFLElBQWEsYUFBYSxrQkFBa0IsY0FBYyxlQUFlO0FBQ3pFLElBQWEsY0FBYyxrQkFBa0IsYUFBYTtBQUMxRCxJQUFhLGlCQUFpQixrQkFBa0IsZ0JBQWdCO0FBQ2hFLElBQWEsbUJBQW1CLGtCQUFrQixrQkFBa0I7QUFDcEUsSUFBYSxvQkFBb0Isa0JBQWtCLG1CQUFtQjtBQUN0RSxJQUFhLGtCQUFrQixrQkFBa0IsaUJBQWlCO0FBQ2xFLElBQWEsVUFBVSxrQkFBa0IsV0FBVyxlQUFlO0FBQ25FLElBQWEsZUFBZSxrQkFBa0IsY0FBYztBQUM1RCxJQUFhLGdCQUFlLFVBQVM7Q0FDbkMsSUFBSSxNQUFNLGlCQUFpQixLQUFBLEtBQWEsTUFBTSxpQkFBaUIsTUFBTTtFQUNuRSxNQUFNLGNBQWMsZ0JBQWdCLE1BQU0sT0FBTyxzQkFBc0IsR0FBRyxjQUFjO0VBQ3hGLE1BQU0sc0JBQXFCLGVBQWMsRUFDdkMsY0FBYyxTQUFTLGFBQWEsU0FBUyxFQUMvQztFQUNBLE9BQU8sa0JBQWtCLE9BQU8sTUFBTSxjQUFjLGtCQUFrQjtDQUN4RTtDQUNBLE9BQU87QUFDVDtBQUNBLGFBQWEsWUFBb0QsRUFDL0QsY0FBYyxtQkFDaEI7QUFDQSxhQUFhLGNBQWMsQ0FBQyxjQUFjO0FBQzFCLFFBQVEsUUFBUSxXQUFXLGFBQWEsY0FBYyxZQUFZLGFBQWEsZ0JBQWdCLGtCQUFrQixtQkFBbUIsaUJBQWlCLGNBQWMsU0FBUyxZQUFZOzs7QUN6Q3hNLElBQWEsT0FBTSxVQUFTO0NBQzFCLElBQUksTUFBTSxRQUFRLEtBQUEsS0FBYSxNQUFNLFFBQVEsTUFBTTtFQUNqRCxNQUFNLGNBQWMsZ0JBQWdCLE1BQU0sT0FBTyxXQUFXLEdBQUcsS0FBSztFQUNwRSxNQUFNLHNCQUFxQixlQUFjLEVBQ3ZDLEtBQUssU0FBUyxhQUFhLFNBQVMsRUFDdEM7RUFDQSxPQUFPLGtCQUFrQixPQUFPLE1BQU0sS0FBSyxrQkFBa0I7Q0FDL0Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFJLFlBQW9ELEVBQ3RELEtBQUssbUJBQ1A7QUFDQSxJQUFJLGNBQWMsQ0FBQyxLQUFLO0FBQ3hCLElBQWEsYUFBWSxVQUFTO0NBQ2hDLElBQUksTUFBTSxjQUFjLEtBQUEsS0FBYSxNQUFNLGNBQWMsTUFBTTtFQUM3RCxNQUFNLGNBQWMsZ0JBQWdCLE1BQU0sT0FBTyxXQUFXLEdBQUcsV0FBVztFQUMxRSxNQUFNLHNCQUFxQixlQUFjLEVBQ3ZDLFdBQVcsU0FBUyxhQUFhLFNBQVMsRUFDNUM7RUFDQSxPQUFPLGtCQUFrQixPQUFPLE1BQU0sV0FBVyxrQkFBa0I7Q0FDckU7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxVQUFVLFlBQW9ELEVBQzVELFdBQVcsbUJBQ2I7QUFDQSxVQUFVLGNBQWMsQ0FBQyxXQUFXO0FBQ3BDLElBQWEsVUFBUyxVQUFTO0NBQzdCLElBQUksTUFBTSxXQUFXLEtBQUEsS0FBYSxNQUFNLFdBQVcsTUFBTTtFQUN2RCxNQUFNLGNBQWMsZ0JBQWdCLE1BQU0sT0FBTyxXQUFXLEdBQUcsUUFBUTtFQUN2RSxNQUFNLHNCQUFxQixlQUFjLEVBQ3ZDLFFBQVEsU0FBUyxhQUFhLFNBQVMsRUFDekM7RUFDQSxPQUFPLGtCQUFrQixPQUFPLE1BQU0sUUFBUSxrQkFBa0I7Q0FDbEU7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxPQUFPLFlBQW9ELEVBQ3pELFFBQVEsbUJBQ1Y7QUFDQSxPQUFPLGNBQWMsQ0FBQyxRQUFRO0FBNEJqQixRQUFRLEtBQUssV0FBVyxRQTNCWEMsUUFBTSxFQUM5QixNQUFNLGFBQ1IsQ0F5QjZDLEdBeEJ0QkEsUUFBTSxFQUMzQixNQUFNLFVBQ1IsQ0FzQnlELEdBckI3QkEsUUFBTSxFQUNoQyxNQUFNLGVBQ1IsQ0FtQmtFLEdBbEJuQ0EsUUFBTSxFQUNuQyxNQUFNLGtCQUNSLENBZ0JnRixHQWZwREEsUUFBTSxFQUNoQyxNQUFNLGVBQ1IsQ0FhaUcsR0FaOURBLFFBQU0sRUFDdkMsTUFBTSxzQkFDUixDQVUrRyxHQVQvRUEsUUFBTSxFQUNwQyxNQUFNLG1CQUNSLENBT29JLEdBTm5HQSxRQUFNLEVBQ3JDLE1BQU0sb0JBQ1IsQ0FJc0osR0FIOUhBLFFBQU0sRUFDNUIsTUFBTSxXQUNSLENBQ3lLLENBQVE7Ozs7QUN0RWpMLFNBQWdCLGlCQUFpQixPQUFPLFdBQVc7Q0FDakQsSUFBSSxjQUFjLFFBQ2hCLE9BQU87Q0FFVCxPQUFPO0FBQ1Q7QUFpQmdCLFFBaEJLQyxRQUFNO0NBQ3pCLE1BQU07Q0FDTixVQUFVO0NBQ1YsV0FBVztBQUNiLENBWXdCLEdBWERBLFFBQU07Q0FDM0IsTUFBTTtDQUNOLGFBQWE7Q0FDYixVQUFVO0NBQ1YsV0FBVztBQUNiLENBTStCLEdBTEFBLFFBQU07Q0FDbkMsTUFBTTtDQUNOLFVBQVU7Q0FDVixXQUFXO0FBQ2IsQ0FDd0MsQ0FBZTs7O0FDdEJ2RCxJQUFNLG9CQUFvQkM7O0FBRzFCLFNBQWdCLGdCQUFnQixPQUFPO0NBQ3JDLE9BQU8sU0FBUyxLQUFLLFVBQVUsSUFBSSxHQUFHLFFBQVEsSUFBSSxLQUFLO0FBQ3pEO0FBQ0EsSUFBYSxRQUFRQyxRQUFNO0NBQ3pCLE1BQU07Q0FDTixXQUFXO0FBQ2IsQ0FBQztBQUNELElBQWEsWUFBVyxVQUFTO0NBQy9CLElBQUksTUFBTSxhQUFhLEtBQUEsS0FBYSxNQUFNLGFBQWEsTUFBTTtFQUMzRCxNQUFNLHNCQUFxQixjQUFhO0dBQ3RDLE1BQU0sYUFBYSxNQUFNLE9BQU8sYUFBYSxTQUFTLGNBQWMsa0JBQWtCO0dBQ3RGLElBQUksQ0FBQyxZQUNILE9BQU8sRUFDTCxVQUFVLGdCQUFnQixTQUFTLEVBQ3JDO0dBRUYsSUFBSSxNQUFNLE9BQU8sYUFBYSxTQUFTLE1BQ3JDLE9BQU8sRUFDTCxVQUFVLEdBQUcsYUFBYSxNQUFNLE1BQU0sWUFBWSxPQUNwRDtHQUVGLE9BQU8sRUFDTCxVQUFVLFdBQ1o7RUFDRjtFQUNBLE9BQU8sa0JBQWtCLE9BQU8sTUFBTSxVQUFVLGtCQUFrQjtDQUNwRTtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxDQUFDLFVBQVU7QUFDbEMsSUFBYSxXQUFXQSxRQUFNO0NBQzVCLE1BQU07Q0FDTixXQUFXO0FBQ2IsQ0FBQztBQUNELElBQWEsU0FBU0EsUUFBTTtDQUMxQixNQUFNO0NBQ04sV0FBVztBQUNiLENBQUM7QUFDRCxJQUFhLFlBQVlBLFFBQU07Q0FDN0IsTUFBTTtDQUNOLFdBQVc7QUFDYixDQUFDO0FBQ0QsSUFBYSxZQUFZQSxRQUFNO0NBQzdCLE1BQU07Q0FDTixXQUFXO0FBQ2IsQ0FBQztBQUN3QkEsUUFBTTtDQUM3QixNQUFNO0NBQ04sYUFBYTtDQUNiLFdBQVc7QUFDYixDQUFDO0FBQ3lCQSxRQUFNO0NBQzlCLE1BQU07Q0FDTixhQUFhO0NBQ2IsV0FBVztBQUNiLENBQUM7QUFJYyxRQUFRLE9BQU8sVUFBVSxVQUFVLFFBQVEsV0FBVyxXQUg1Q0EsUUFBTSxFQUM3QixNQUFNLFlBQ1IsQ0FDZ0YsQ0FBUzs7O0FDN0R6RixJQUFNLGtCQUFrQjtDQUV0QixRQUFRO0VBQ04sVUFBVTtFQUNWLFdBQVc7Q0FDYjtDQUNBLFdBQVc7RUFDVCxVQUFVO0VBQ1YsV0FBVztDQUNiO0NBQ0EsYUFBYTtFQUNYLFVBQVU7RUFDVixXQUFXO0NBQ2I7Q0FDQSxjQUFjO0VBQ1osVUFBVTtFQUNWLFdBQVc7Q0FDYjtDQUNBLFlBQVk7RUFDVixVQUFVO0VBQ1YsV0FBVztDQUNiO0NBQ0EsYUFBYSxFQUNYLFVBQVUsVUFDWjtDQUNBLGdCQUFnQixFQUNkLFVBQVUsVUFDWjtDQUNBLGtCQUFrQixFQUNoQixVQUFVLFVBQ1o7Q0FDQSxtQkFBbUIsRUFDakIsVUFBVSxVQUNaO0NBQ0EsaUJBQWlCLEVBQ2YsVUFBVSxVQUNaO0NBQ0EsU0FBUztFQUNQLFVBQVU7RUFDVixXQUFXO0NBQ2I7Q0FDQSxjQUFjLEVBQ1osVUFBVSxVQUNaO0NBQ0EsY0FBYztFQUNaLFVBQVU7RUFDVixPQUFPO0NBQ1Q7Q0FFQSxPQUFPO0VBQ0wsVUFBVTtFQUNWLFdBQVc7Q0FDYjtDQUNBLFNBQVM7RUFDUCxVQUFVO0VBQ1YsYUFBYTtFQUNiLFdBQVc7Q0FDYjtDQUNBLGlCQUFpQjtFQUNmLFVBQVU7RUFDVixXQUFXO0NBQ2I7Q0FFQSxHQUFHLEVBQ0QsT0FBTyxRQUNUO0NBQ0EsSUFBSSxFQUNGLE9BQU8sUUFDVDtDQUNBLElBQUksRUFDRixPQUFPLFFBQ1Q7Q0FDQSxJQUFJLEVBQ0YsT0FBTyxRQUNUO0NBQ0EsSUFBSSxFQUNGLE9BQU8sUUFDVDtDQUNBLElBQUksRUFDRixPQUFPLFFBQ1Q7Q0FDQSxJQUFJLEVBQ0YsT0FBTyxRQUNUO0NBQ0EsU0FBUyxFQUNQLE9BQU8sUUFDVDtDQUNBLFlBQVksRUFDVixPQUFPLFFBQ1Q7Q0FDQSxjQUFjLEVBQ1osT0FBTyxRQUNUO0NBQ0EsZUFBZSxFQUNiLE9BQU8sUUFDVDtDQUNBLGFBQWEsRUFDWCxPQUFPLFFBQ1Q7Q0FDQSxVQUFVLEVBQ1IsT0FBTyxRQUNUO0NBQ0EsVUFBVSxFQUNSLE9BQU8sUUFDVDtDQUNBLGVBQWUsRUFDYixPQUFPLFFBQ1Q7Q0FDQSxvQkFBb0IsRUFDbEIsT0FBTyxRQUNUO0NBQ0Esa0JBQWtCLEVBQ2hCLE9BQU8sUUFDVDtDQUNBLGNBQWMsRUFDWixPQUFPLFFBQ1Q7Q0FDQSxtQkFBbUIsRUFDakIsT0FBTyxRQUNUO0NBQ0EsaUJBQWlCLEVBQ2YsT0FBTyxRQUNUO0NBQ0EsR0FBRyxFQUNELE9BQU8sT0FDVDtDQUNBLElBQUksRUFDRixPQUFPLE9BQ1Q7Q0FDQSxJQUFJLEVBQ0YsT0FBTyxPQUNUO0NBQ0EsSUFBSSxFQUNGLE9BQU8sT0FDVDtDQUNBLElBQUksRUFDRixPQUFPLE9BQ1Q7Q0FDQSxJQUFJLEVBQ0YsT0FBTyxPQUNUO0NBQ0EsSUFBSSxFQUNGLE9BQU8sT0FDVDtDQUNBLFFBQVEsRUFDTixPQUFPLE9BQ1Q7Q0FDQSxXQUFXLEVBQ1QsT0FBTyxPQUNUO0NBQ0EsYUFBYSxFQUNYLE9BQU8sT0FDVDtDQUNBLGNBQWMsRUFDWixPQUFPLE9BQ1Q7Q0FDQSxZQUFZLEVBQ1YsT0FBTyxPQUNUO0NBQ0EsU0FBUyxFQUNQLE9BQU8sT0FDVDtDQUNBLFNBQVMsRUFDUCxPQUFPLE9BQ1Q7Q0FDQSxjQUFjLEVBQ1osT0FBTyxPQUNUO0NBQ0EsbUJBQW1CLEVBQ2pCLE9BQU8sT0FDVDtDQUNBLGlCQUFpQixFQUNmLE9BQU8sT0FDVDtDQUNBLGFBQWEsRUFDWCxPQUFPLE9BQ1Q7Q0FDQSxrQkFBa0IsRUFDaEIsT0FBTyxPQUNUO0NBQ0EsZ0JBQWdCLEVBQ2QsT0FBTyxPQUNUO0NBRUEsY0FBYztFQUNaLGFBQWE7RUFDYixZQUFXLFdBQVUsRUFDbkIsZ0JBQWdCLEVBQ2QsU0FBUyxNQUNYLEVBQ0Y7Q0FDRjtDQUNBLFNBQVMsQ0FBQztDQUNWLFVBQVUsQ0FBQztDQUNYLGNBQWMsQ0FBQztDQUNmLFlBQVksQ0FBQztDQUNiLFlBQVksQ0FBQztDQUViLFdBQVcsQ0FBQztDQUNaLGVBQWUsQ0FBQztDQUNoQixVQUFVLENBQUM7Q0FDWCxnQkFBZ0IsQ0FBQztDQUNqQixZQUFZLENBQUM7Q0FDYixjQUFjLENBQUM7Q0FDZixPQUFPLENBQUM7Q0FDUixNQUFNLENBQUM7Q0FDUCxVQUFVLENBQUM7Q0FDWCxZQUFZLENBQUM7Q0FDYixXQUFXLENBQUM7Q0FDWixjQUFjLENBQUM7Q0FDZixhQUFhLENBQUM7Q0FFZCxLQUFLLEVBQ0gsT0FBTyxJQUNUO0NBQ0EsUUFBUSxFQUNOLE9BQU8sT0FDVDtDQUNBLFdBQVcsRUFDVCxPQUFPLFVBQ1Q7Q0FDQSxZQUFZLENBQUM7Q0FDYixTQUFTLENBQUM7Q0FDVixjQUFjLENBQUM7Q0FDZixpQkFBaUIsQ0FBQztDQUNsQixjQUFjLENBQUM7Q0FDZixxQkFBcUIsQ0FBQztDQUN0QixrQkFBa0IsQ0FBQztDQUNuQixtQkFBbUIsQ0FBQztDQUNwQixVQUFVLENBQUM7Q0FFWCxVQUFVLENBQUM7Q0FDWCxRQUFRLEVBQ04sVUFBVSxTQUNaO0NBQ0EsS0FBSyxDQUFDO0NBQ04sT0FBTyxDQUFDO0NBQ1IsUUFBUSxDQUFDO0NBQ1QsTUFBTSxDQUFDO0NBRVAsV0FBVyxFQUNULFVBQVUsVUFDWjtDQUVBLE9BQU8sRUFDTCxXQUFXLGdCQUNiO0NBQ0EsVUFBVSxFQUNSLE9BQU8sU0FDVDtDQUNBLFVBQVUsRUFDUixXQUFXLGdCQUNiO0NBQ0EsUUFBUSxFQUNOLFdBQVcsZ0JBQ2I7Q0FDQSxXQUFXLEVBQ1QsV0FBVyxnQkFDYjtDQUNBLFdBQVcsRUFDVCxXQUFXLGdCQUNiO0NBQ0EsV0FBVyxDQUFDO0NBRVosTUFBTSxFQUNKLFVBQVUsT0FDWjtDQUNBLFlBQVksRUFDVixVQUFVLGFBQ1o7Q0FDQSxVQUFVLEVBQ1IsVUFBVSxhQUNaO0NBQ0EsV0FBVyxFQUNULFVBQVUsYUFDWjtDQUNBLFlBQVksRUFDVixVQUFVLGFBQ1o7Q0FDQSxlQUFlLENBQUM7Q0FDaEIsZUFBZSxDQUFDO0NBQ2hCLFlBQVksQ0FBQztDQUNiLFdBQVcsQ0FBQztDQUNaLFlBQVk7RUFDVixhQUFhO0VBQ2IsVUFBVTtDQUNaO0FBQ0Y7OztBQzVSQSxJQUFNLGNBQWMsQ0FBQztBQUdyQixTQUFnQixpQ0FBaUM7Q0FDL0MsU0FBUyxnQkFBZ0IsT0FBTztFQUM5QixJQUFJLENBQUMsTUFBTSxJQUNULE9BQU87RUFFVCxNQUFNLEVBQ0osSUFDQSxRQUFRLGFBQ1IsV0FDRTtFQUNKLE1BQU0sU0FBUyxNQUFNLHFCQUFxQjtFQUcxQyxNQUFNLFVBQVU7R0FDZCxJQUFJO0dBQ0o7R0FDQSxRQUFRO0VBQ1Y7RUFDQSxTQUFTLFFBQVEsU0FBUztHQUN4QixJQUFJLFdBQVc7R0FDZixJQUFJLE9BQU8sWUFBWSxZQUNyQixXQUFXLFFBQVEsS0FBSztRQUNuQixJQUFJLE9BQU8sWUFBWSxVQUU1QixPQUFPO0dBRVQsSUFBSSxDQUFDLFVBQ0gsT0FBTztHQUVULE1BQU0sY0FBYyxNQUFNLGVBQWU7R0FDekMsTUFBTSxNQUFNLDRCQUE0QixXQUFXO0dBQ25ELEtBQUssTUFBTSxZQUFZLFVBQVU7SUFDL0IsTUFBTSxRQUFRLFNBQVMsU0FBUyxXQUFXLEtBQUs7SUFDaEQsSUFBSSxVQUFVLFFBQVEsVUFBVSxLQUFBLEdBQzlCO0lBRUYsSUFBSSxPQUFPLFVBQVUsVUFBVTtLQUM3QixjQUFjLEtBQUssVUFBVSxPQUFPLE9BQU8sTUFBTTtLQUNqRDtJQUNGO0lBQ0EsSUFBSSxPQUFPLFdBQVc7S0FDcEIsY0FBYyxLQUFLLFVBQVUsT0FBTyxPQUFPLE1BQU07S0FDakQ7SUFDRjtJQUNBLElBQUksY0FBYyxhQUFhLEtBQUssR0FDbEMsbUJBQW1CLEtBQUssTUFBTSxPQUFPLFFBQVEsVUFBVSxlQUFlO0tBQ3BFLElBQUksU0FBUyxDQUFDLFlBQVk7SUFDNUIsQ0FBQztTQUNJO0tBQ0wsUUFBUSxLQUFLO0tBQ2IsSUFBSSxZQUFZLGdCQUFnQixPQUFPO0lBQ3pDO0dBQ0Y7R0FDQSxJQUFJLENBQUMsVUFBVSxNQUFNLGtCQUNuQixPQUFPLEVBQ0wsYUFBYSxxQkFBcUIsT0FBTyx3QkFBd0IsYUFBYSxHQUFHLENBQUMsRUFDcEY7R0FFRixPQUFPLHFCQUFxQixPQUFPLHdCQUF3QixhQUFhLEdBQUcsQ0FBQztFQUM5RTtFQUNBLE9BQU8sTUFBTSxRQUFRLEVBQUUsSUFBSSxHQUFHLElBQUksT0FBTyxJQUFJLFFBQVEsRUFBRTtDQUN6RDtDQUNBLGdCQUFnQixjQUFjLENBQUMsSUFBSTtDQUNuQyxPQUFPO0FBQ1Q7QUFDQSxJQUFBLDBCQUFlLCtCQUErQjtBQUM5QyxTQUFTLGNBQWMsS0FBSyxNQUFNLE9BQU8sT0FBTyxRQUFRO0NBQ3RELE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLElBQUksQ0FBQyxTQUFTO0VBQ1osSUFBSSxRQUFRO0VBQ1o7Q0FDRjtDQUNBLElBQUksU0FBUyxNQUNYO0NBRUYsTUFBTSxFQUNKLGFBQ0U7Q0FFSixJQUFJLGFBQWEsZ0JBQWdCLFVBQVUsV0FBVztFQUNwRCxJQUFJLFFBQVE7RUFDWjtDQUNGO0NBQ0EsTUFBTSxFQUNKLFVBQ0U7Q0FDSixJQUFJLE9BQU87RUFDVCxlQUFNLEtBQUssTUFBTTtJQUNkLE9BQU87R0FDUjtFQUNGLENBQUMsQ0FBQztFQUNGO0NBQ0Y7Q0FDQSxNQUFNLEVBQ0osY0FBYyxNQUNkLGNBQ0U7Q0FDSixNQUFNLGVBQWUsUUFBUSxPQUFPLFFBQVE7Q0FDNUMsbUJBQW1CLEtBQUssT0FBTyxRQUFRLFVBQVUsZUFBZTtFQUM5RCxNQUFNLGFBQWEsZUFBZSxjQUFjLFdBQVcsWUFBWSxJQUFJO0VBQzNFLElBQUksZ0JBQWdCLE9BQ2xCLElBQUksVUFDRixlQUFNLElBQUksV0FBVyxVQUFVO09BRS9CLGVBQU0sS0FBSyxVQUFVO09BSXZCLElBQUksVUFDRixJQUFJLFNBQVMsQ0FBQyxlQUFlO09BRTdCLElBQUksZUFBZTtDQUd6QixDQUFDO0FBQ0g7QUFDQSxTQUFTLFNBQVMsU0FBUyxLQUFLO0NBQzlCLE9BQU8sT0FBTyxZQUFZLGFBQWEsUUFBUSxHQUFHLElBQUk7QUFDeEQ7OztBQ3hHQSxTQUFTLFlBQVksS0FBSztDQUN4QixJQUFJLElBQUksT0FDTixPQUFPLElBQUk7O0NBTWIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsWUFBWSxRQUFRLEtBQy9DLElBQUksU0FBUyxZQUFZLEVBQUUsQ0FBQyxjQUFjLEtBQ3hDLE9BQU8sU0FBUyxZQUFZO0FBT2xDO0FBRUEsU0FBUyxtQkFBbUIsU0FBUztDQUNuQyxJQUFJLE1BQU0sU0FBUyxjQUFjLE9BQU87Q0FDeEMsSUFBSSxhQUFhLGdCQUFnQixRQUFRLEdBQUc7Q0FFNUMsSUFBSSxRQUFRLFVBQVUsS0FBQSxHQUNwQixJQUFJLGFBQWEsU0FBUyxRQUFRLEtBQUs7Q0FHekMsSUFBSSxZQUFZLFNBQVMsZUFBZSxFQUFFLENBQUM7Q0FDM0MsSUFBSSxhQUFhLFVBQVUsRUFBRTtDQUM3QixPQUFPO0FBQ1Q7QUFFQSxJQUFJLGFBQTBCLHlCQUFZO0NBRXhDLFNBQVMsV0FBVyxTQUFTO0VBQzNCLElBQUksUUFBUTtFQUVaLEtBQUssYUFBYSxTQUFVLEtBQUs7R0FDL0IsSUFBSTtHQUVKLElBQUksTUFBTSxLQUFLLFdBQVcsR0FDeEIsSUFBSSxNQUFNLGdCQUNSLFNBQVMsTUFBTSxlQUFlO1FBQ3pCLElBQUksTUFBTSxTQUNmLFNBQVMsTUFBTSxVQUFVO1FBRXpCLFNBQVMsTUFBTTtRQUdqQixTQUFTLE1BQU0sS0FBSyxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7R0FHN0MsTUFBTSxVQUFVLGFBQWEsS0FBSyxNQUFNO0dBRXhDLE1BQU0sS0FBSyxLQUFLLEdBQUc7RUFDckI7RUFFQSxLQUFLLFdBQVcsUUFBUSxXQUFXLEtBQUEsSUFBWSxRQUFpQixRQUFRO0VBQ3hFLEtBQUssT0FBTyxDQUFDO0VBQ2IsS0FBSyxNQUFNO0VBQ1gsS0FBSyxRQUFRLFFBQVE7RUFFckIsS0FBSyxNQUFNLFFBQVE7RUFDbkIsS0FBSyxZQUFZLFFBQVE7RUFDekIsS0FBSyxVQUFVLFFBQVE7RUFDdkIsS0FBSyxpQkFBaUIsUUFBUTtFQUM5QixLQUFLLFNBQVM7Q0FDaEI7Q0FFQSxJQUFJLFNBQVMsV0FBVztDQUV4QixPQUFPLFVBQVUsU0FBUyxRQUFRLE9BQU87RUFDdkMsTUFBTSxRQUFRLEtBQUssVUFBVTtDQUMvQjtDQUVBLE9BQU8sU0FBUyxTQUFTLE9BQU8sTUFBTTtFQUlwQyxJQUFJLEtBQUssT0FBTyxLQUFLLFdBQVcsT0FBUSxPQUFPLEdBQzdDLEtBQUssV0FBVyxtQkFBbUIsSUFBSSxDQUFDO0VBRzFDLElBQUksTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLLFNBQVM7RUFHckMsSUFBSSxlQUFlLEtBQUssV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsQ0FBQyxNQUFNO0VBRXZFLElBQUksZ0JBQWdCLEtBQUssc0NBSXZCLFFBQVEsTUFBTSxzREFBc0QsT0FBTyx3TEFBd0w7RUFHclEsS0FBSyx1Q0FBdUMsS0FBSyx3Q0FBd0MsQ0FBQztFQUc1RixJQUFJLEtBQUssVUFBVTtHQUNqQixJQUFJLFFBQVEsWUFBWSxHQUFHO0dBRTNCLElBQUk7SUFHRixNQUFNLFdBQVcsTUFBTSxNQUFNLFNBQVMsTUFBTTtHQUM5QyxTQUFTLEdBQUc7SUFDVixJQUFJLENBQUMsNElBQTRJLEtBQUssSUFBSSxHQUN4SixRQUFRLE1BQU0seURBQXlELE9BQU8sTUFBTSxDQUFDO0dBRXpGO0VBQ0YsT0FDRSxJQUFJLFlBQVksU0FBUyxlQUFlLElBQUksQ0FBQztFQUcvQyxLQUFLO0NBQ1A7Q0FFQSxPQUFPLFFBQVEsU0FBUyxRQUFRO0VBQzlCLEtBQUssS0FBSyxRQUFRLFNBQVUsS0FBSztHQUMvQixJQUFJO0dBRUosUUFBUSxrQkFBa0IsSUFBSSxlQUFlLE9BQU8sS0FBSyxJQUFJLGdCQUFnQixZQUFZLEdBQUc7RUFDOUYsQ0FBQztFQUNELEtBQUssT0FBTyxDQUFDO0VBQ2IsS0FBSyxNQUFNO0VBR1QsS0FBSyx1Q0FBdUM7Q0FFaEQ7Q0FFQSxPQUFPO0FBQ1QsRUFBRTs7O0FDN0pGLElBQVcsS0FBSztBQUNoQixJQUFXLE1BQU07QUFDakIsSUFBVyxTQUFTO0FBRXBCLElBQVcsVUFBVTtBQUNyQixJQUFXLFVBQVU7QUFDckIsSUFBVyxjQUFjO0FBSXpCLElBQVcsU0FBUztBQU1wQixJQUFXLFlBQVk7QUFJdkIsSUFBVyxRQUFROzs7Ozs7O0FDaEJuQixJQUFXLE1BQU0sS0FBSzs7Ozs7QUFNdEIsSUFBVyxPQUFPLE9BQU87Ozs7O0FBTXpCLElBQVcsU0FBUyxPQUFPOzs7Ozs7QUFPM0IsU0FBZ0IsS0FBTSxPQUFPLFFBQVE7Q0FDcEMsT0FBTyxPQUFPLE9BQU8sQ0FBQyxJQUFJLFFBQVksVUFBVSxJQUFLLE9BQU8sT0FBTyxDQUFDLE1BQU0sSUFBSyxPQUFPLE9BQU8sQ0FBQyxNQUFNLElBQUssT0FBTyxPQUFPLENBQUMsTUFBTSxJQUFLLE9BQU8sT0FBTyxDQUFDLElBQUk7QUFDdko7Ozs7O0FBTUEsU0FBZ0IsS0FBTSxPQUFPO0NBQzVCLE9BQU8sTUFBTSxLQUFLO0FBQ25COzs7Ozs7QUFPQSxTQUFnQixNQUFPLE9BQU8sU0FBUztDQUN0QyxRQUFRLFFBQVEsUUFBUSxLQUFLLEtBQUssS0FBSyxNQUFNLEtBQUs7QUFDbkQ7Ozs7Ozs7QUFRQSxTQUFnQixRQUFTLE9BQU8sU0FBUyxhQUFhO0NBQ3JELE9BQU8sTUFBTSxRQUFRLFNBQVMsV0FBVztBQUMxQzs7Ozs7O0FBT0EsU0FBZ0IsUUFBUyxPQUFPLFFBQVE7Q0FDdkMsT0FBTyxNQUFNLFFBQVEsTUFBTTtBQUM1Qjs7Ozs7O0FBT0EsU0FBZ0IsT0FBUSxPQUFPLE9BQU87Q0FDckMsT0FBTyxNQUFNLFdBQVcsS0FBSyxJQUFJO0FBQ2xDOzs7Ozs7O0FBUUEsU0FBZ0IsT0FBUSxPQUFPLE9BQU8sS0FBSztDQUMxQyxPQUFPLE1BQU0sTUFBTSxPQUFPLEdBQUc7QUFDOUI7Ozs7O0FBTUEsU0FBZ0IsT0FBUSxPQUFPO0NBQzlCLE9BQU8sTUFBTTtBQUNkOzs7OztBQU1BLFNBQWdCLE9BQVEsT0FBTztDQUM5QixPQUFPLE1BQU07QUFDZDs7Ozs7O0FBT0EsU0FBZ0IsT0FBUSxPQUFPLE9BQU87Q0FDckMsT0FBTyxNQUFNLEtBQUssS0FBSyxHQUFHO0FBQzNCOzs7Ozs7QUFPQSxTQUFnQixRQUFTLE9BQU8sVUFBVTtDQUN6QyxPQUFPLE1BQU0sSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLEVBQUU7QUFDbkM7OztBQ2hIQSxJQUFXLE9BQU87QUFDbEIsSUFBVyxTQUFTO0FBQ3BCLElBQVcsU0FBUztBQUNwQixJQUFXLFdBQVc7QUFDdEIsSUFBVyxZQUFZO0FBQ3ZCLElBQVcsYUFBYTs7Ozs7Ozs7OztBQVd4QixTQUFnQixLQUFNLE9BQU8sTUFBTSxRQUFRLE1BQU0sT0FBTyxVQUFVLFFBQVE7Q0FDekUsT0FBTztFQUFRO0VBQWE7RUFBYztFQUFjO0VBQWE7RUFBaUI7RUFBZ0I7RUFBYztFQUFnQjtFQUFRLFFBQVE7Q0FBRTtBQUN2Sjs7Ozs7O0FBT0EsU0FBZ0IsS0FBTSxNQUFNLE9BQU87Q0FDbEMsT0FBTyxPQUFPLEtBQUssSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLE1BQU0sQ0FBQyxHQUFHLE1BQU0sRUFBQyxRQUFRLENBQUMsS0FBSyxPQUFNLEdBQUcsS0FBSztBQUMzRjs7OztBQUtBLFNBQWdCLE9BQVE7Q0FDdkIsT0FBTztBQUNSOzs7O0FBS0EsU0FBZ0IsT0FBUTtDQUN2QixZQUFZLFdBQVcsSUFBSSxPQUFPLFlBQVksRUFBRSxRQUFRLElBQUk7Q0FFNUQsSUFBSSxVQUFVLGNBQWMsSUFDM0IsU0FBUyxHQUFHO0NBRWIsT0FBTztBQUNSOzs7O0FBS0EsU0FBZ0IsT0FBUTtDQUN2QixZQUFZLFdBQVcsU0FBUyxPQUFPLFlBQVksVUFBVSxJQUFJO0NBRWpFLElBQUksVUFBVSxjQUFjLElBQzNCLFNBQVMsR0FBRztDQUViLE9BQU87QUFDUjs7OztBQUtBLFNBQWdCLE9BQVE7Q0FDdkIsT0FBTyxPQUFPLFlBQVksUUFBUTtBQUNuQzs7OztBQUtBLFNBQWdCLFFBQVM7Q0FDeEIsT0FBTztBQUNSOzs7Ozs7QUFPQSxTQUFnQixNQUFPLE9BQU8sS0FBSztDQUNsQyxPQUFPLE9BQU8sWUFBWSxPQUFPLEdBQUc7QUFDckM7Ozs7O0FBTUEsU0FBZ0IsTUFBTyxNQUFNO0NBQzVCLFFBQVEsTUFBUjtFQUVDLEtBQUs7RUFBRyxLQUFLO0VBQUcsS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLLElBQ3RDLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLO0VBRTNELEtBQUs7RUFBSSxLQUFLO0VBQUssS0FBSyxLQUN2QixPQUFPO0VBRVIsS0FBSyxJQUNKLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLLElBQy9CLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSyxJQUNiLE9BQU87Q0FDVDtDQUVBLE9BQU87QUFDUjs7Ozs7QUFNQSxTQUFnQixNQUFPLE9BQU87Q0FDN0IsT0FBTyxPQUFPLFNBQVMsR0FBRyxTQUFTLE9BQU8sYUFBYSxLQUFLLEdBQUcsV0FBVyxHQUFHLENBQUM7QUFDL0U7Ozs7O0FBTUEsU0FBZ0IsUUFBUyxPQUFPO0NBQy9CLE9BQU8sYUFBYSxJQUFJO0FBQ3pCOzs7OztBQU1BLFNBQWdCLFFBQVMsTUFBTTtDQUM5QixPQUFPLEtBQUssTUFBTSxXQUFXLEdBQUcsVUFBVSxTQUFTLEtBQUssT0FBTyxJQUFJLFNBQVMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUM7QUFDbkc7Ozs7O0FBY0EsU0FBZ0IsV0FBWSxNQUFNO0NBQ2pDLE9BQU8sWUFBWSxLQUFLLEdBQ3ZCLElBQUksWUFBWSxJQUNmLEtBQUs7TUFFTDtDQUVGLE9BQU8sTUFBTSxJQUFJLElBQUksS0FBSyxNQUFNLFNBQVMsSUFBSSxJQUFJLEtBQUs7QUFDdkQ7Ozs7OztBQXdCQSxTQUFnQixTQUFVLE9BQU8sT0FBTztDQUN2QyxPQUFPLEVBQUUsU0FBUyxLQUFLLEdBRXRCLElBQUksWUFBWSxNQUFNLFlBQVksT0FBUSxZQUFZLE1BQU0sWUFBWSxNQUFRLFlBQVksTUFBTSxZQUFZLElBQzdHO0NBRUYsT0FBTyxNQUFNLE9BQU8sTUFBTSxLQUFLLFFBQVEsS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztBQUMxRTs7Ozs7QUFNQSxTQUFnQixVQUFXLE1BQU07Q0FDaEMsT0FBTyxLQUFLLEdBQ1gsUUFBUSxXQUFSO0VBRUMsS0FBSyxNQUNKLE9BQU87RUFFUixLQUFLO0VBQUksS0FBSztHQUNiLElBQUksU0FBUyxNQUFNLFNBQVMsSUFDM0IsVUFBVSxTQUFTO0dBQ3BCO0VBRUQsS0FBSztHQUNKLElBQUksU0FBUyxJQUNaLFVBQVUsSUFBSTtHQUNmO0VBRUQsS0FBSztHQUNKLEtBQUs7R0FDTDtDQUNGO0NBRUQsT0FBTztBQUNSOzs7Ozs7QUFPQSxTQUFnQixVQUFXLE1BQU0sT0FBTztDQUN2QyxPQUFPLEtBQUssR0FFWCxJQUFJLE9BQU8sY0FBYyxJQUN4QjtNQUVJLElBQUksT0FBTyxjQUFjLE1BQVcsS0FBSyxNQUFNLElBQ25EO0NBRUYsT0FBTyxPQUFPLE1BQU0sT0FBTyxXQUFXLENBQUMsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxDQUFDO0FBQ2xGOzs7OztBQU1BLFNBQWdCLFdBQVksT0FBTztDQUNsQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsR0FDbkIsS0FBSztDQUVOLE9BQU8sTUFBTSxPQUFPLFFBQVE7QUFDN0I7Ozs7Ozs7QUM3T0EsU0FBZ0IsUUFBUyxPQUFPO0NBQy9CLE9BQU8sUUFBUSxNQUFNLElBQUksTUFBTSxNQUFNLE1BQU0sQ0FBQyxFQUFFLEdBQUcsUUFBUSxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztBQUN0Rjs7Ozs7Ozs7Ozs7OztBQWNBLFNBQWdCLE1BQU8sT0FBTyxNQUFNLFFBQVEsTUFBTSxPQUFPLFVBQVUsUUFBUSxRQUFRLGNBQWM7Q0FDaEcsSUFBSSxRQUFRO0NBQ1osSUFBSSxTQUFTO0NBQ2IsSUFBSSxTQUFTO0NBQ2IsSUFBSSxTQUFTO0NBQ2IsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZO0NBQ2hCLElBQUksWUFBWTtDQUNoQixJQUFJLE9BQU87Q0FDWCxJQUFJLFFBQVE7Q0FDWixJQUFJLFdBQVc7Q0FDZixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxhQUFhO0NBRWpCLE9BQU8sVUFDTixRQUFRLFdBQVcsV0FBVyxZQUFZLEtBQUssR0FBL0M7RUFFQyxLQUFLLElBQ0osSUFBSSxZQUFZLE9BQU8sT0FBTyxZQUFZLFNBQVMsQ0FBQyxLQUFLLElBQUk7R0FDNUQsSUFBSSxRQUFRLGNBQWMsUUFBUSxRQUFRLFNBQVMsR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssSUFDNUUsWUFBWTtHQUNiO0VBQ0Q7RUFFRCxLQUFLO0VBQUksS0FBSztFQUFJLEtBQUs7R0FDdEIsY0FBYyxRQUFRLFNBQVM7R0FDL0I7RUFFRCxLQUFLO0VBQUcsS0FBSztFQUFJLEtBQUs7RUFBSSxLQUFLO0dBQzlCLGNBQWMsV0FBVyxRQUFRO0dBQ2pDO0VBRUQsS0FBSztHQUNKLGNBQWMsU0FBUyxNQUFNLElBQUksR0FBRyxDQUFDO0dBQ3JDO0VBRUQsS0FBSztHQUNKLFFBQVEsS0FBSyxHQUFiO0lBQ0MsS0FBSztJQUFJLEtBQUs7S0FDYixPQUFPLFFBQVEsVUFBVSxLQUFLLEdBQUcsTUFBTSxDQUFDLEdBQUcsTUFBTSxNQUFNLEdBQUcsWUFBWTtLQUN0RTtJQUNELFNBQ0MsY0FBYztHQUNoQjtHQUNBO0VBRUQsS0FBSyxNQUFNLFVBQ1YsT0FBTyxXQUFXLE9BQU8sVUFBVSxJQUFJO0VBRXhDLEtBQUssTUFBTTtFQUFVLEtBQUs7RUFBSSxLQUFLO0dBQ2xDLFFBQVEsV0FBUjtJQUVDLEtBQUs7SUFBRyxLQUFLLEtBQUssV0FBVztJQUU3QixLQUFLLEtBQUs7S0FBUSxJQUFJLGFBQWEsSUFBSSxhQUFhLFFBQVEsWUFBWSxPQUFPLEVBQUU7S0FDaEYsSUFBSSxXQUFXLEtBQU0sT0FBTyxVQUFVLElBQUksUUFDekMsT0FBTyxXQUFXLEtBQUssWUFBWSxhQUFhLEtBQUssTUFBTSxRQUFRLFNBQVMsQ0FBQyxJQUFJLFlBQVksUUFBUSxZQUFZLEtBQUssRUFBRSxJQUFJLEtBQUssTUFBTSxRQUFRLFNBQVMsQ0FBQyxHQUFHLFlBQVk7S0FDeks7SUFFRCxLQUFLLElBQUksY0FBYztJQUV2QjtLQUNDLE9BQU8sWUFBWSxRQUFRLFlBQVksTUFBTSxRQUFRLE9BQU8sUUFBUSxPQUFPLFFBQVEsTUFBTSxRQUFRLENBQUMsR0FBRyxXQUFXLENBQUMsR0FBRyxNQUFNLEdBQUcsUUFBUTtLQUVySSxJQUFJLGNBQWMsS0FDakIsSUFBSSxXQUFXLEdBQ2QsTUFBTSxZQUFZLE1BQU0sV0FBVyxXQUFXLE9BQU8sVUFBVSxRQUFRLFFBQVEsUUFBUTtVQUV2RixRQUFRLFdBQVcsTUFBTSxPQUFPLFlBQVksQ0FBQyxNQUFNLE1BQU0sTUFBTSxRQUEvRDtNQUVDLEtBQUs7TUFBSyxLQUFLO01BQUssS0FBSztNQUFLLEtBQUs7T0FDbEMsTUFBTSxPQUFPLFdBQVcsV0FBVyxRQUFRLE9BQU8sUUFBUSxPQUFPLFdBQVcsV0FBVyxHQUFHLEdBQUcsT0FBTyxRQUFRLE1BQU0sT0FBTyxRQUFRLENBQUMsR0FBRyxNQUFNLEdBQUcsUUFBUSxHQUFHLE9BQU8sVUFBVSxRQUFRLFFBQVEsT0FBTyxRQUFRLFFBQVE7T0FDak47TUFDRCxTQUNDLE1BQU0sWUFBWSxXQUFXLFdBQVcsV0FBVyxDQUFDLEVBQUUsR0FBRyxVQUFVLEdBQUcsUUFBUSxRQUFRO0tBQ3hGO0dBQ0o7R0FFQSxRQUFRLFNBQVMsV0FBVyxHQUFHLFdBQVcsWUFBWSxHQUFHLE9BQU8sYUFBYSxJQUFJLFNBQVM7R0FDMUY7RUFFRCxLQUFLLElBQ0osU0FBUyxJQUFJLE9BQU8sVUFBVSxHQUFHLFdBQVc7RUFDN0M7R0FDQyxJQUFJLFdBQVc7UUFDVixhQUFhLEtBQ2hCLEVBQUU7U0FDRSxJQUFJLGFBQWEsT0FBTyxjQUFjLEtBQUssS0FBSyxLQUFLLEtBQ3pEO0dBQUE7R0FFRixRQUFRLGNBQWMsS0FBSyxTQUFTLEdBQUcsWUFBWSxVQUFuRDtJQUVDLEtBQUs7S0FDSixZQUFZLFNBQVMsSUFBSSxLQUFLLGNBQWMsTUFBTTtLQUNsRDtJQUVELEtBQUs7S0FDSixPQUFPLFlBQVksT0FBTyxVQUFVLElBQUksS0FBSyxXQUFXLFlBQVk7S0FDcEU7SUFFRCxLQUFLO0tBRUosSUFBSSxLQUFLLE1BQU0sSUFDZCxjQUFjLFFBQVEsS0FBSyxDQUFDO0tBRTdCLFNBQVMsS0FBSyxHQUFHLFNBQVMsU0FBUyxPQUFPLE9BQU8sY0FBYyxXQUFXLE1BQU0sQ0FBQyxDQUFDLEdBQUc7S0FDckY7SUFFRCxLQUFLLElBQ0osSUFBSSxhQUFhLE1BQU0sT0FBTyxVQUFVLEtBQUssR0FDNUMsV0FBVztHQUNkO0NBQ0Y7Q0FFRCxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFnQixRQUFTLE9BQU8sTUFBTSxRQUFRLE9BQU8sUUFBUSxPQUFPLFFBQVEsTUFBTSxPQUFPLFVBQVUsUUFBUTtDQUMxRyxJQUFJLE9BQU8sU0FBUztDQUNwQixJQUFJLE9BQU8sV0FBVyxJQUFJLFFBQVEsQ0FBQyxFQUFFO0NBQ3JDLElBQUksT0FBTyxPQUFPLElBQUk7Q0FFdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLEdBQzFDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLE9BQU8sT0FBTyxHQUFHLE9BQU8sSUFBSSxJQUFJLE9BQU8sRUFBRSxDQUFDLEdBQUcsSUFBSSxPQUFPLElBQUksTUFBTSxFQUFFLEdBQzlGLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssRUFBRSxDQUFDLEdBQ25FLE1BQU0sT0FBTztDQUVoQixPQUFPLEtBQUssT0FBTyxNQUFNLFFBQVEsV0FBVyxJQUFJLFVBQVUsTUFBTSxPQUFPLFVBQVUsTUFBTTtBQUN4Rjs7Ozs7OztBQVFBLFNBQWdCLFFBQVMsT0FBTyxNQUFNLFFBQVE7Q0FDN0MsT0FBTyxLQUFLLE9BQU8sTUFBTSxRQUFRLFNBQVMsS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPLE9BQU8sR0FBRyxFQUFFLEdBQUcsQ0FBQztBQUNoRjs7Ozs7Ozs7QUFTQSxTQUFnQixZQUFhLE9BQU8sTUFBTSxRQUFRLFFBQVE7Q0FDekQsT0FBTyxLQUFLLE9BQU8sTUFBTSxRQUFRLGFBQWEsT0FBTyxPQUFPLEdBQUcsTUFBTSxHQUFHLE9BQU8sT0FBTyxTQUFTLEdBQUcsRUFBRSxHQUFHLE1BQU07QUFDOUc7Ozs7Ozs7O0FDdExBLFNBQWdCLFVBQVcsVUFBVSxVQUFVO0NBQzlDLElBQUksU0FBUztDQUNiLElBQUksU0FBUyxPQUFPLFFBQVE7Q0FFNUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDM0IsVUFBVSxTQUFTLFNBQVMsSUFBSSxHQUFHLFVBQVUsUUFBUSxLQUFLO0NBRTNELE9BQU87QUFDUjs7Ozs7Ozs7QUFTQSxTQUFnQixVQUFXLFNBQVMsT0FBTyxVQUFVLFVBQVU7Q0FDOUQsUUFBUSxRQUFRLE1BQWhCO0VBQ0MsS0FBSyxPQUFPLElBQUksUUFBUSxTQUFTLFFBQVE7RUFDekMsS0FBSztFQUFRLEtBQUssYUFBYSxPQUFPLFFBQVEsU0FBUyxRQUFRLFVBQVUsUUFBUTtFQUNqRixLQUFLLFNBQVMsT0FBTztFQUNyQixLQUFLLFdBQVcsT0FBTyxRQUFRLFNBQVMsUUFBUSxRQUFRLE1BQU0sVUFBVSxRQUFRLFVBQVUsUUFBUSxJQUFJO0VBQ3RHLEtBQUssU0FBUyxRQUFRLFFBQVEsUUFBUSxNQUFNLEtBQUssR0FBRztDQUNyRDtDQUVBLE9BQU8sT0FBTyxXQUFXLFVBQVUsUUFBUSxVQUFVLFFBQVEsQ0FBQyxJQUFJLFFBQVEsU0FBUyxRQUFRLFFBQVEsTUFBTSxXQUFXLE1BQU07QUFDM0g7Ozs7Ozs7QUN6QkEsU0FBZ0IsV0FBWSxZQUFZO0NBQ3ZDLElBQUksU0FBUyxPQUFPLFVBQVU7Q0FFOUIsT0FBTyxTQUFVLFNBQVMsT0FBTyxVQUFVLFVBQVU7RUFDcEQsSUFBSSxTQUFTO0VBRWIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDM0IsVUFBVSxXQUFXLEVBQUUsQ0FBQyxTQUFTLE9BQU8sVUFBVSxRQUFRLEtBQUs7RUFFaEUsT0FBTztDQUNSO0FBQ0Q7OztBQ3JCQSxTQUFTLFFBQVEsSUFBSTtDQUNuQixJQUFJLFFBQVEsT0FBTyxPQUFPLElBQUk7Q0FDOUIsT0FBTyxTQUFVLEtBQUs7RUFDcEIsSUFBSSxNQUFNLFNBQVMsS0FBQSxHQUFXLE1BQU0sT0FBTyxHQUFHLEdBQUc7RUFDakQsT0FBTyxNQUFNO0NBQ2Y7QUFDRjs7O0FDREEsSUFBSSw4QkFBOEIsU0FBUyw0QkFBNEIsT0FBTyxRQUFRLE9BQU87Q0FDM0YsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZO0NBRWhCLE9BQU8sTUFBTTtFQUNYLFdBQVc7RUFDWCxZQUFZLEtBQUs7RUFFakIsSUFBSSxhQUFhLE1BQU0sY0FBYyxJQUNuQyxPQUFPLFNBQVM7RUFHbEIsSUFBSSxNQUFNLFNBQVMsR0FDakI7RUFHRixLQUFLO0NBQ1A7Q0FFQSxPQUFPLE1BQU0sT0FBTyxRQUFRO0FBQzlCO0FBRUEsSUFBSSxVQUFVLFNBQVMsUUFBUSxRQUFRLFFBQVE7Q0FFN0MsSUFBSSxRQUFRO0NBQ1osSUFBSSxZQUFZO0NBRWhCO0VBQ0UsUUFBUSxNQUFNLFNBQVMsR0FBdkI7R0FDRSxLQUFLO0lBRUgsSUFBSSxjQUFjLE1BQU0sS0FBSyxNQUFNLElBS2pDLE9BQU8sU0FBUztJQUdsQixPQUFPLFVBQVUsNEJBQTRCLFdBQVcsR0FBRyxRQUFRLEtBQUs7SUFDeEU7R0FFRixLQUFLO0lBQ0gsT0FBTyxVQUFVLFFBQVEsU0FBUztJQUNsQztHQUVGLEtBQUssR0FFSCxJQUFJLGNBQWMsSUFBSTtJQUVwQixPQUFPLEVBQUUsU0FBUyxLQUFLLE1BQU0sS0FBSyxRQUFRO0lBQzFDLE9BQU8sU0FBUyxPQUFPLE1BQU0sQ0FBQztJQUM5QjtHQUNGO0dBSUYsU0FDRSxPQUFPLFVBQVUsS0FBSyxTQUFTO0VBQ25DO1FBQ08sWUFBWSxLQUFLO0NBRTFCLE9BQU87QUFDVDtBQUVBLElBQUksV0FBVyxTQUFTLFNBQVMsT0FBTyxRQUFRO0NBQzlDLE9BQU8sUUFBUSxRQUFRLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQztBQUM5QztBQUdBLElBQUksZ0NBQStCLElBQUksUUFBUTtBQUMvQyxJQUFJLFNBQVMsU0FBUyxPQUFPLFNBQVM7Q0FDcEMsSUFBSSxRQUFRLFNBQVMsVUFBVSxDQUFDLFFBQVEsVUFFeEMsUUFBUSxTQUFTLEdBQ2Y7Q0FHRixJQUFJLFFBQVEsUUFBUTtDQUNwQixJQUFJLFNBQVMsUUFBUTtDQUNyQixJQUFJLGlCQUFpQixRQUFRLFdBQVcsT0FBTyxVQUFVLFFBQVEsU0FBUyxPQUFPO0NBRWpGLE9BQU8sT0FBTyxTQUFTLFFBQVE7RUFDN0IsU0FBUyxPQUFPO0VBQ2hCLElBQUksQ0FBQyxRQUFRO0NBQ2Y7Q0FHQSxJQUFJLFFBQVEsTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXLENBQUMsTUFBTSxNQUV2RCxDQUFDLGNBQWMsSUFBSSxNQUFNLEdBQzFCO0NBS0YsSUFBSSxnQkFDRjtDQUdGLGNBQWMsSUFBSSxTQUFTLElBQUk7Q0FDL0IsSUFBSSxTQUFTLENBQUM7Q0FDZCxJQUFJLFFBQVEsU0FBUyxPQUFPLE1BQU07Q0FDbEMsSUFBSSxjQUFjLE9BQU87Q0FFekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDdkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLLEtBQzNDLFFBQVEsTUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQyxRQUFRLFFBQVEsWUFBWSxFQUFFLElBQUksWUFBWSxLQUFLLE1BQU0sTUFBTTtBQUc3RztBQUNBLElBQUksY0FBYyxTQUFTLFlBQVksU0FBUztDQUM5QyxJQUFJLFFBQVEsU0FBUyxRQUFRO0VBQzNCLElBQUksUUFBUSxRQUFRO0VBRXBCLElBQ0EsTUFBTSxXQUFXLENBQUMsTUFBTSxPQUN4QixNQUFNLFdBQVcsQ0FBQyxNQUFNLElBQUk7R0FFMUIsUUFBUSxZQUFZO0dBQ3BCLFFBQVEsUUFBUTtFQUNsQjtDQUNGO0FBQ0Y7QUFDQSxJQUFJLGFBQWE7QUFFakIsSUFBSSxvQkFBb0IsU0FBUyxrQkFBa0IsU0FBUztDQUMxRCxPQUFPLFFBQVEsU0FBUyxVQUFVLFFBQVEsU0FBUyxRQUFRLFVBQVUsSUFBSTtBQUMzRTtBQUVBLElBQUksNkJBQTZCLFNBQVMsMkJBQTJCLE9BQU87Q0FDMUUsT0FBTyxTQUFVLFNBQVMsT0FBTyxVQUFVO0VBQ3pDLElBQUksUUFBUSxTQUFTLFVBQVUsTUFBTSxRQUFRO0VBQzdDLElBQUksc0JBQXNCLFFBQVEsTUFBTSxNQUFNLGdDQUFnQztFQUU5RSxJQUFJLHFCQUFxQjtHQWlCdkIsSUFBSSxtQkFBbUIsQ0FoQlAsQ0FBQyxRQUFRLFNBZ0JTLFFBQVEsT0FBTyxXQUNqRDtHQUVBLEtBQUssSUFBSSxJQUFJLGlCQUFpQixTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDckQsSUFBSSxPQUFPLGlCQUFpQjtJQUU1QixJQUFJLEtBQUssT0FBTyxRQUFRLE1BQ3RCO0lBbUJGLElBQUksS0FBSyxTQUFTLFFBQVEsUUFBUTtLQUNoQyxJQUFJLGtCQUFrQixJQUFJLEdBQ3hCO0tBR0Y7SUFDRjtHQUNGO0dBRUEsb0JBQW9CLFFBQVEsU0FBVSxtQkFBbUI7SUFDdkQsUUFBUSxNQUFNLHdCQUF3QixvQkFBb0IscUZBQXFGLGtCQUFrQixNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssYUFBYTtHQUNyTSxDQUFDO0VBQ0g7Q0FDRjtBQUNGO0FBRUEsSUFBSSxlQUFlLFNBQVMsYUFBYSxTQUFTO0NBQ2hELE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxNQUFNLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxNQUFNO0FBQzlFO0FBRUEsSUFBSSw4QkFBOEIsU0FBUyw0QkFBNEIsT0FBTyxVQUFVO0NBQ3RGLEtBQUssSUFBSSxJQUFJLFFBQVEsR0FBRyxLQUFLLEdBQUcsS0FDOUIsSUFBSSxDQUFDLGFBQWEsU0FBUyxFQUFFLEdBQzNCLE9BQU87Q0FJWCxPQUFPO0FBQ1Q7QUFLQSxJQUFJLGlCQUFpQixTQUFTLGVBQWUsU0FBUztDQUNwRCxRQUFRLE9BQU87Q0FDZixRQUFRLFFBQVE7Q0FDaEIsUUFBUSxZQUFZO0NBQ3BCLFFBQVEsV0FBVztDQUNuQixRQUFRLFFBQVE7QUFDbEI7QUFFQSxJQUFJLHVCQUF1QixTQUFTLHFCQUFxQixTQUFTLE9BQU8sVUFBVTtDQUNqRixJQUFJLENBQUMsYUFBYSxPQUFPLEdBQ3ZCO0NBR0YsSUFBSSxRQUFRLFFBQVE7RUFDbEIsUUFBUSxNQUFNLG9MQUFvTDtFQUNsTSxlQUFlLE9BQU87Q0FDeEIsT0FBTyxJQUFJLDRCQUE0QixPQUFPLFFBQVEsR0FBRztFQUN2RCxRQUFRLE1BQU0sc0dBQXNHO0VBQ3BILGVBQWUsT0FBTztDQUN4QjtBQUNGO0FBSUEsU0FBUyxPQUFPLE9BQU8sUUFBUTtDQUM3QixRQUFRLEtBQUssT0FBTyxNQUFNLEdBQTFCO0VBRUUsS0FBSyxNQUNILE9BQU8sU0FBUyxXQUFXLFFBQVE7RUFHckMsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUVMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUVMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUVMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxNQUNILE9BQU8sU0FBUyxRQUFRO0VBRzFCLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLLE1BQ0gsT0FBTyxTQUFTLFFBQVEsTUFBTSxRQUFRLEtBQUssUUFBUTtFQUdyRCxLQUFLO0VBQ0wsS0FBSyxNQUNILE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUTtFQUd2QyxLQUFLLE1BQ0gsT0FBTyxTQUFTLFFBQVEsS0FBSyxVQUFVLFFBQVE7RUFHakQsS0FBSyxNQUNILE9BQU8sU0FBUyxRQUFRLFFBQVEsT0FBTyxrQkFBa0IsU0FBUyxhQUFhLEtBQUssV0FBVyxJQUFJO0VBR3JHLEtBQUssTUFDSCxPQUFPLFNBQVMsUUFBUSxLQUFLLGVBQWUsUUFBUSxPQUFPLGVBQWUsRUFBRSxJQUFJO0VBR2xGLEtBQUssTUFDSCxPQUFPLFNBQVMsUUFBUSxLQUFLLG1CQUFtQixRQUFRLE9BQU8sNkJBQTZCLEVBQUUsSUFBSTtFQUdwRyxLQUFLLE1BQ0gsT0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sVUFBVSxVQUFVLElBQUk7RUFHdEUsS0FBSyxNQUNILE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUSxPQUFPLFNBQVMsZ0JBQWdCLElBQUk7RUFHM0UsS0FBSyxNQUNILE9BQU8sU0FBUyxTQUFTLFFBQVEsT0FBTyxTQUFTLEVBQUUsSUFBSSxTQUFTLFFBQVEsS0FBSyxRQUFRLE9BQU8sUUFBUSxVQUFVLElBQUk7RUFHcEgsS0FBSyxNQUNILE9BQU8sU0FBUyxRQUFRLE9BQU8sc0JBQXNCLE9BQU8sU0FBUyxJQUFJLElBQUk7RUFHL0UsS0FBSyxNQUNILE9BQU8sUUFBUSxRQUFRLFFBQVEsT0FBTyxnQkFBZ0IsU0FBUyxJQUFJLEdBQUcsZUFBZSxTQUFTLElBQUksR0FBRyxPQUFPLEVBQUUsSUFBSTtFQUdwSCxLQUFLO0VBQ0wsS0FBSyxNQUNILE9BQU8sUUFBUSxPQUFPLHFCQUFxQixTQUFTLFFBQWE7RUFHbkUsS0FBSyxNQUNILE9BQU8sUUFBUSxRQUFRLE9BQU8scUJBQXFCLFNBQVMsZ0JBQWdCLEtBQUssY0FBYyxHQUFHLGNBQWMsU0FBUyxJQUFJLFNBQVMsUUFBUTtFQUdoSixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLLE1BQ0gsT0FBTyxRQUFRLE9BQU8sbUJBQW1CLFNBQVMsTUFBTSxJQUFJO0VBRzlELEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztHQUVILElBQUksT0FBTyxLQUFLLElBQUksSUFBSSxTQUFTLEdBQUcsUUFBUSxPQUFPLE9BQU8sU0FBUyxDQUFDLEdBQWhDO0lBRWxDLEtBQUssS0FFSCxJQUFJLE9BQU8sT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJO0lBR3hDLEtBQUssS0FDSCxPQUFPLFFBQVEsT0FBTyxvQkFBb0IsT0FBTyxTQUFTLFlBQWlCLE9BQU8sT0FBTyxPQUFPLFNBQVMsQ0FBQyxLQUFLLE1BQU0sT0FBTyxRQUFRLElBQUk7SUFHMUksS0FBSyxLQUNILE9BQU8sQ0FBQyxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sUUFBUSxPQUFPLFdBQVcsZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLFFBQVE7R0FDOUc7R0FDQTtFQUdGLEtBQUssTUFFSCxJQUFJLE9BQU8sT0FBTyxTQUFTLENBQUMsTUFBTSxLQUFLO0VBR3pDLEtBQUs7R0FDSCxRQUFRLE9BQU8sT0FBTyxPQUFPLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxPQUFPLFlBQVksS0FBSyxHQUFHLEdBQS9FO0lBRUUsS0FBSyxLQUNILE9BQU8sUUFBUSxPQUFPLEtBQUssTUFBTSxNQUFNLElBQUk7SUFHN0MsS0FBSyxLQUNILE9BQU8sUUFBUSxPQUFPLHlCQUF5QixPQUFPLFVBQVUsT0FBTyxPQUFPLEVBQUUsTUFBTSxLQUFLLFlBQVksTUFBTSxZQUFpQixTQUFTLFdBQWdCLEtBQUssU0FBUyxJQUFJO0dBQzdLO0dBRUE7RUFHRixLQUFLO0dBQ0gsUUFBUSxPQUFPLE9BQU8sU0FBUyxFQUFFLEdBQWpDO0lBRUUsS0FBSyxLQUNILE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUSxPQUFPLHNCQUFzQixJQUFJLElBQUk7SUFHNUUsS0FBSyxLQUNILE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUSxPQUFPLHNCQUFzQixPQUFPLElBQUk7SUFHL0UsS0FBSyxJQUNILE9BQU8sU0FBUyxRQUFRLEtBQUssUUFBUSxPQUFPLHNCQUFzQixJQUFJLElBQUk7R0FDOUU7R0FFQSxPQUFPLFNBQVMsUUFBUSxLQUFLLFFBQVE7Q0FDekM7Q0FFQSxPQUFPO0FBQ1Q7QUF1Q0EsSUFBSSx1QkFBdUIsQ0FBQyxTQXJDSixTQUFTLFNBQVMsT0FBTyxVQUFVLFVBQVU7Q0FDbkUsSUFBSSxRQUFRLFNBQVM7TUFBUSxDQUFDLFFBQVEsV0FBVyxRQUFRLFFBQVEsTUFBaEI7R0FDL0MsS0FBSztJQUNILFFBQVEsWUFBWSxPQUFPLFFBQVEsT0FBTyxRQUFRLE1BQU07SUFDeEQ7R0FFRixLQUFLLFdBQ0gsT0FBTyxVQUFVLENBQUMsS0FBSyxTQUFTLEVBQzlCLE9BQU8sUUFBUSxRQUFRLE9BQU8sS0FBSyxNQUFNLE1BQU0sRUFDakQsQ0FBQyxDQUFDLEdBQUcsUUFBUTtHQUVmLEtBQUssU0FDSCxJQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsUUFBUSxPQUFPLFNBQVUsT0FBTztJQUNqRSxRQUFRLE1BQU0sT0FBTyx1QkFBdUIsR0FBNUM7S0FFRSxLQUFLO0tBQ0wsS0FBSyxlQUNILE9BQU8sVUFBVSxDQUFDLEtBQUssU0FBUyxFQUM5QixPQUFPLENBQUMsUUFBUSxPQUFPLGVBQWUsTUFBTSxNQUFNLElBQUksQ0FBQyxFQUN6RCxDQUFDLENBQUMsR0FBRyxRQUFRO0tBR2YsS0FBSyxpQkFDSCxPQUFPLFVBQVU7TUFBQyxLQUFLLFNBQVMsRUFDOUIsT0FBTyxDQUFDLFFBQVEsT0FBTyxjQUFjLE1BQU0sU0FBUyxVQUFVLENBQUMsRUFDakUsQ0FBQztNQUFHLEtBQUssU0FBUyxFQUNoQixPQUFPLENBQUMsUUFBUSxPQUFPLGNBQWMsTUFBTSxNQUFNLElBQUksQ0FBQyxFQUN4RCxDQUFDO01BQUcsS0FBSyxTQUFTLEVBQ2hCLE9BQU8sQ0FBQyxRQUFRLE9BQU8sY0FBYyxLQUFLLFVBQVUsQ0FBQyxFQUN2RCxDQUFDO0tBQUMsR0FBRyxRQUFRO0lBQ2pCO0lBRUEsT0FBTztHQUNULENBQUM7RUFDTDs7QUFDRixDQUVvQztBQUNwQyxJQUFJO0FBR0YsSUFBSSxtQkFBbUI7QUFFdkIsZUFBZSxTQUFTLGFBQWEsUUFBUTtDQUMzQyxJQUFJLFVBQVUsT0FBTyxNQUFNLGdCQUFnQjtDQUMzQyxJQUFJLENBQUMsU0FBUztDQUNkLE9BQU8sUUFBUSxRQUFRLFNBQVM7QUFDbEM7QUFHRixJQUFJLGNBQWMsU0FBUyxZQUFZLFNBQVM7Q0FDOUMsSUFBSSxNQUFNLFFBQVE7Q0FFbEIsSUFBSSxDQUFDLEtBQ0gsTUFBTSxJQUFJLE1BQU0sK09BQW9QO0NBR3RRLElBQUksUUFBUSxPQUFPO0VBQ2pCLElBQUksWUFBWSxTQUFTLGlCQUFpQixtQ0FBbUM7RUFLN0UsTUFBTSxVQUFVLFFBQVEsS0FBSyxXQUFXLFNBQVUsTUFBTTtHQVN0RCxJQUYyQixLQUFLLGFBQWEsY0FFdEIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxNQUFNLElBQ3hDO0dBR0YsU0FBUyxLQUFLLFlBQVksSUFBSTtHQUM5QixLQUFLLGFBQWEsVUFBVSxFQUFFO0VBQ2hDLENBQUM7Q0FDSDtDQUVBLElBQUksZ0JBQWdCLFFBQVEsaUJBQWlCO0NBRzNDLElBQUksVUFBVSxLQUFLLEdBQUcsR0FDcEIsTUFBTSxJQUFJLE1BQU0sa0ZBQWtGLE1BQU0sZUFBZTtDQUkzSCxJQUFJLFdBQVcsQ0FBQztDQUNoQixJQUFJO0NBQ0osSUFBSSxpQkFBaUIsQ0FBQztDQUdwQixZQUFZLFFBQVEsYUFBYSxTQUFTO0NBQzFDLE1BQU0sVUFBVSxRQUFRLEtBRXhCLFNBQVMsaUJBQWlCLDJCQUEyQixNQUFNLE1BQU0sR0FBRyxTQUFVLE1BQU07RUFDbEYsSUFBSSxTQUFTLEtBQUssYUFBYSxjQUFjLENBQUMsQ0FBQyxNQUFNLEdBQUc7RUFFeEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUNqQyxTQUFTLE9BQU8sTUFBTTtFQUd4QixlQUFlLEtBQUssSUFBSTtDQUMxQixDQUFDO0NBR0gsSUFBSTtDQUVKLElBQUkscUJBQXFCLENBQUMsUUFBUSxXQUFXO0NBRzNDLG1CQUFtQixLQUFLLDJCQUEyQixFQUNqRCxJQUFJLFNBQVM7RUFDWCxPQUFPLE1BQU07Q0FDZixFQUVGLENBQUMsR0FBRyxvQkFBb0I7Q0FJeEIsSUFBSTtDQUNKLElBQUksb0JBQW9CLENBQUMsV0FBVyxTQUFVLFNBQVM7RUFDckQsSUFBSSxDQUFDLFFBQVE7T0FDUCxRQUFRLFdBQ1YsYUFBYSxPQUFPLFFBQVEsU0FBUztRQUNoQyxJQUFJLFFBQVEsU0FBUyxRQUFRLFNBQUEsUUFHbEMsYUFBYSxPQUFPLFFBQVEsUUFBUSxJQUFJO0VBQUE7Q0FHOUMsQ0FBRTtDQUNGLElBQUksYUFBYSxXQUFXLG1CQUFtQixPQUFPLGVBQWUsaUJBQWlCLENBQUM7Q0FFdkYsSUFBSSxTQUFTLFNBQVMsT0FBTyxRQUFRO0VBQ25DLE9BQU8sVUFBVSxRQUFRLE1BQU0sR0FBRyxVQUFVO0NBQzlDO0NBRUEsVUFBVSxTQUFTLE9BQU8sVUFBVSxZQUFZLE9BQU8sYUFBYTtFQUNsRSxlQUFlO0VBRWYsSUFBSSxjQUFjO0dBQ2hCLElBQUksWUFBWSxhQUFhLFdBQVcsTUFBTTtHQUU5QyxJQUFJLFdBQ0YsZUFBZSxFQUNiLFFBQVEsU0FBUyxPQUFPLE1BQU07SUFDNUIsTUFBTSxPQUFPLE9BQU8sU0FBUztHQUMvQixFQUNGO0VBRUo7RUFFQSxPQUFPLFdBQVcsV0FBVyxNQUFNLFdBQVcsU0FBUyxNQUFNLFdBQVcsTUFBTTtFQUU5RSxJQUFJLGFBQ0YsTUFBTSxTQUFTLFdBQVcsUUFBUTtDQUV0QztDQUdGLElBQUksUUFBUTtFQUNMO0VBQ0wsT0FBTyxJQUFJLFdBQVc7R0FDZjtHQUNNO0dBQ1gsT0FBTyxRQUFRO0dBQ2YsUUFBUSxRQUFRO0dBQ2hCLFNBQVMsUUFBUTtHQUNqQixnQkFBZ0IsUUFBUTtFQUMxQixDQUFDO0VBQ0QsT0FBTyxRQUFRO0VBQ0w7RUFDVixZQUFZLENBQUM7RUFDYixRQUFRO0NBQ1Y7Q0FDQSxNQUFNLE1BQU0sUUFBUSxjQUFjO0NBQ2xDLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7O0NDbmtCRSxDQUFDLFdBQVc7RUFDZDtFQUlBLElBQUksWUFBWSxPQUFPLFdBQVcsY0FBYyxPQUFPO0VBQ3ZELElBQUkscUJBQXFCLFlBQVksT0FBTyxJQUFJLGVBQWUsSUFBSTtFQUNuRSxJQUFJLG9CQUFvQixZQUFZLE9BQU8sSUFBSSxjQUFjLElBQUk7RUFDakUsSUFBSSxzQkFBc0IsWUFBWSxPQUFPLElBQUksZ0JBQWdCLElBQUk7RUFDckUsSUFBSSx5QkFBeUIsWUFBWSxPQUFPLElBQUksbUJBQW1CLElBQUk7RUFDM0UsSUFBSSxzQkFBc0IsWUFBWSxPQUFPLElBQUksZ0JBQWdCLElBQUk7RUFDckUsSUFBSSxzQkFBc0IsWUFBWSxPQUFPLElBQUksZ0JBQWdCLElBQUk7RUFDckUsSUFBSSxxQkFBcUIsWUFBWSxPQUFPLElBQUksZUFBZSxJQUFJO0VBR25FLElBQUksd0JBQXdCLFlBQVksT0FBTyxJQUFJLGtCQUFrQixJQUFJO0VBQ3pFLElBQUksNkJBQTZCLFlBQVksT0FBTyxJQUFJLHVCQUF1QixJQUFJO0VBQ25GLElBQUkseUJBQXlCLFlBQVksT0FBTyxJQUFJLG1CQUFtQixJQUFJO0VBQzNFLElBQUksc0JBQXNCLFlBQVksT0FBTyxJQUFJLGdCQUFnQixJQUFJO0VBQ3JFLElBQUksMkJBQTJCLFlBQVksT0FBTyxJQUFJLHFCQUFxQixJQUFJO0VBQy9FLElBQUksa0JBQWtCLFlBQVksT0FBTyxJQUFJLFlBQVksSUFBSTtFQUM3RCxJQUFJLGtCQUFrQixZQUFZLE9BQU8sSUFBSSxZQUFZLElBQUk7RUFDN0QsSUFBSSxtQkFBbUIsWUFBWSxPQUFPLElBQUksYUFBYSxJQUFJO0VBQy9ELElBQUkseUJBQXlCLFlBQVksT0FBTyxJQUFJLG1CQUFtQixJQUFJO0VBQzNFLElBQUksdUJBQXVCLFlBQVksT0FBTyxJQUFJLGlCQUFpQixJQUFJO0VBQ3ZFLElBQUksbUJBQW1CLFlBQVksT0FBTyxJQUFJLGFBQWEsSUFBSTtFQUUvRCxTQUFTLG1CQUFtQixNQUFNO0dBQ2hDLE9BQU8sT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLGNBQ25ELFNBQVMsdUJBQXVCLFNBQVMsOEJBQThCLFNBQVMsdUJBQXVCLFNBQVMsMEJBQTBCLFNBQVMsdUJBQXVCLFNBQVMsNEJBQTRCLE9BQU8sU0FBUyxZQUFZLFNBQVMsU0FBUyxLQUFLLGFBQWEsbUJBQW1CLEtBQUssYUFBYSxtQkFBbUIsS0FBSyxhQUFhLHVCQUF1QixLQUFLLGFBQWEsc0JBQXNCLEtBQUssYUFBYSwwQkFBMEIsS0FBSyxhQUFhLDBCQUEwQixLQUFLLGFBQWEsd0JBQXdCLEtBQUssYUFBYSxvQkFBb0IsS0FBSyxhQUFhO0VBQ3BsQjtFQUVBLFNBQVMsT0FBTyxRQUFRO0dBQ3RCLElBQUksT0FBTyxXQUFXLFlBQVksV0FBVyxNQUFNO0lBQ2pELElBQUksV0FBVyxPQUFPO0lBRXRCLFFBQVEsVUFBUjtLQUNFLEtBQUs7TUFDSCxJQUFJLE9BQU8sT0FBTztNQUVsQixRQUFRLE1BQVI7T0FDRSxLQUFLO09BQ0wsS0FBSztPQUNMLEtBQUs7T0FDTCxLQUFLO09BQ0wsS0FBSztPQUNMLEtBQUsscUJBQ0gsT0FBTztPQUVUO1FBQ0UsSUFBSSxlQUFlLFFBQVEsS0FBSztRQUVoQyxRQUFRLGNBQVI7U0FDRSxLQUFLO1NBQ0wsS0FBSztTQUNMLEtBQUs7U0FDTCxLQUFLO1NBQ0wsS0FBSyxxQkFDSCxPQUFPO1NBRVQsU0FDRSxPQUFPO1FBQ1g7TUFFSjtLQUVGLEtBQUssbUJBQ0gsT0FBTztJQUNYO0dBQ0Y7RUFHRjtFQUVBLElBQUksWUFBWTtFQUNoQixJQUFJLGlCQUFpQjtFQUNyQixJQUFJLGtCQUFrQjtFQUN0QixJQUFJLGtCQUFrQjtFQUN0QixJQUFJLFVBQVU7RUFDZCxJQUFJLGFBQWE7RUFDakIsSUFBSSxXQUFXO0VBQ2YsSUFBSSxPQUFPO0VBQ1gsSUFBSSxPQUFPO0VBQ1gsSUFBSSxTQUFTO0VBQ2IsSUFBSSxXQUFXO0VBQ2YsSUFBSSxhQUFhO0VBQ2pCLElBQUksV0FBVztFQUNmLElBQUksc0NBQXNDO0VBRTFDLFNBQVMsWUFBWSxRQUFRO0dBRXpCLElBQUksQ0FBQyxxQ0FBcUM7SUFDeEMsc0NBQXNDO0lBRXRDLFFBQVEsT0FBTyxDQUFDLCtLQUF5TDtHQUMzTTtHQUdGLE9BQU8saUJBQWlCLE1BQU0sS0FBSyxPQUFPLE1BQU0sTUFBTTtFQUN4RDtFQUNBLFNBQVMsaUJBQWlCLFFBQVE7R0FDaEMsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsa0JBQWtCLFFBQVE7R0FDakMsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsa0JBQWtCLFFBQVE7R0FDakMsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsVUFBVSxRQUFRO0dBQ3pCLE9BQU8sT0FBTyxXQUFXLFlBQVksV0FBVyxRQUFRLE9BQU8sYUFBYTtFQUM5RTtFQUNBLFNBQVMsYUFBYSxRQUFRO0dBQzVCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFDQSxTQUFTLFdBQVcsUUFBUTtHQUMxQixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxPQUFPLFFBQVE7R0FDdEIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsT0FBTyxRQUFRO0dBQ3RCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFDQSxTQUFTLFNBQVMsUUFBUTtHQUN4QixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBQ0EsU0FBUyxXQUFXLFFBQVE7R0FDMUIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM1QjtFQUNBLFNBQVMsYUFBYSxRQUFRO0dBQzVCLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDNUI7RUFDQSxTQUFTLFdBQVcsUUFBUTtHQUMxQixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzVCO0VBRUEsUUFBUSxZQUFZO0VBQ3BCLFFBQVEsaUJBQWlCO0VBQ3pCLFFBQVEsa0JBQWtCO0VBQzFCLFFBQVEsa0JBQWtCO0VBQzFCLFFBQVEsVUFBVTtFQUNsQixRQUFRLGFBQWE7RUFDckIsUUFBUSxXQUFXO0VBQ25CLFFBQVEsT0FBTztFQUNmLFFBQVEsT0FBTztFQUNmLFFBQVEsU0FBUztFQUNqQixRQUFRLFdBQVc7RUFDbkIsUUFBUSxhQUFhO0VBQ3JCLFFBQVEsV0FBVztFQUNuQixRQUFRLGNBQWM7RUFDdEIsUUFBUSxtQkFBbUI7RUFDM0IsUUFBUSxvQkFBb0I7RUFDNUIsUUFBUSxvQkFBb0I7RUFDNUIsUUFBUSxZQUFZO0VBQ3BCLFFBQVEsZUFBZTtFQUN2QixRQUFRLGFBQWE7RUFDckIsUUFBUSxTQUFTO0VBQ2pCLFFBQVEsU0FBUztFQUNqQixRQUFRLFdBQVc7RUFDbkIsUUFBUSxhQUFhO0VBQ3JCLFFBQVEsZUFBZTtFQUN2QixRQUFRLGFBQWE7RUFDckIsUUFBUSxxQkFBcUI7RUFDN0IsUUFBUSxTQUFTO0NBQ2YsRUFBQSxDQUFHOzs7OztDQzlLSCxPQUFPLFVBQUEsNkJBQUE7Ozs7O0NDSFQsSUFBSSxVQUFBLGlCQUFBOzs7OztDQU1KLElBQUksZ0JBQWdCO0VBQ2xCLG1CQUFtQjtFQUNuQixhQUFhO0VBQ2IsY0FBYztFQUNkLGNBQWM7RUFDZCxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLDBCQUEwQjtFQUMxQiwwQkFBMEI7RUFDMUIsUUFBUTtFQUNSLFdBQVc7RUFDWCxNQUFNO0NBQ1I7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixNQUFNO0VBQ04sUUFBUTtFQUNSLFdBQVc7RUFDWCxRQUFRO0VBQ1IsUUFBUTtFQUNSLFdBQVc7RUFDWCxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLHNCQUFzQjtFQUN4QixZQUFZO0VBQ1osUUFBUTtFQUNSLGNBQWM7RUFDZCxhQUFhO0VBQ2IsV0FBVztDQUNiO0NBQ0EsSUFBSSxlQUFlO0VBQ2pCLFlBQVk7RUFDWixTQUFTO0VBQ1QsY0FBYztFQUNkLGFBQWE7RUFDYixXQUFXO0VBQ1gsTUFBTTtDQUNSO0NBQ0EsSUFBSSxlQUFlLENBQUM7Q0FDcEIsYUFBYSxRQUFRLGNBQWM7Q0FDbkMsYUFBYSxRQUFRLFFBQVE7Q0FFN0IsU0FBUyxXQUFXLFdBQVc7RUFFN0IsSUFBSSxRQUFRLE9BQU8sU0FBUyxHQUMxQixPQUFPO0VBSVQsT0FBTyxhQUFhLFVBQVUsZ0JBQWdCO0NBQ2hEO0NBRUEsSUFBSSxpQkFBaUIsT0FBTztDQUM1QixJQUFJLHNCQUFzQixPQUFPO0NBQ2pDLElBQUksd0JBQXdCLE9BQU87Q0FDbkMsSUFBSSwyQkFBMkIsT0FBTztDQUN0QyxJQUFJLGlCQUFpQixPQUFPO0NBQzVCLElBQUksa0JBQWtCLE9BQU87Q0FDN0IsU0FBUyxxQkFBcUIsaUJBQWlCLGlCQUFpQixXQUFXO0VBQ3pFLElBQUksT0FBTyxvQkFBb0IsVUFBVTtHQUV2QyxJQUFJLGlCQUFpQjtJQUNuQixJQUFJLHFCQUFxQixlQUFlLGVBQWU7SUFFdkQsSUFBSSxzQkFBc0IsdUJBQXVCLGlCQUMvQyxxQkFBcUIsaUJBQWlCLG9CQUFvQixTQUFTO0dBRXZFO0dBRUEsSUFBSSxPQUFPLG9CQUFvQixlQUFlO0dBRTlDLElBQUksdUJBQ0YsT0FBTyxLQUFLLE9BQU8sc0JBQXNCLGVBQWUsQ0FBQztHQUczRCxJQUFJLGdCQUFnQixXQUFXLGVBQWU7R0FDOUMsSUFBSSxnQkFBZ0IsV0FBVyxlQUFlO0dBRTlDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUFHO0lBQ3BDLElBQUksTUFBTSxLQUFLO0lBRWYsSUFBSSxDQUFDLGNBQWMsUUFBUSxFQUFFLGFBQWEsVUFBVSxTQUFTLEVBQUUsaUJBQWlCLGNBQWMsU0FBUyxFQUFFLGlCQUFpQixjQUFjLE9BQU87S0FDN0ksSUFBSSxhQUFhLHlCQUF5QixpQkFBaUIsR0FBRztLQUU5RCxJQUFJO01BRUYsZUFBZSxpQkFBaUIsS0FBSyxVQUFVO0tBQ2pELFNBQVMsR0FBRyxDQUFDO0lBQ2Y7R0FDRjtFQUNGO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FBTyxVQUFVOzs7O0FDcEdqQixTQUFTLG9CQUFvQixZQUFZLGtCQUFrQixZQUFZO0NBQ3JFLElBQUksZUFBZTtDQUNuQixXQUFXLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxTQUFVLFdBQVc7RUFDakQsSUFBSSxXQUFXLGVBQWUsS0FBQSxHQUM1QixpQkFBaUIsS0FBSyxXQUFXLGFBQWEsR0FBRztPQUM1QyxJQUFJLFdBQ1QsZ0JBQWdCLFlBQVk7Q0FFaEMsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQUksaUJBQWlCLFNBQVMsZUFBZSxPQUFPLFlBQVksYUFBYTtDQUMzRSxJQUFJLFlBQVksTUFBTSxNQUFNLE1BQU0sV0FBVztDQUU3QyxLQUtDLGdCQUFnQixTQUlqQixVQUF5QixNQUFNLFdBQVcsZUFBZSxLQUFBLEdBQ3ZELE1BQU0sV0FBVyxhQUFhLFdBQVc7QUFFN0M7QUFDQSxJQUFJLGVBQWUsU0FBUyxhQUFhLE9BQU8sWUFBWSxhQUFhO0NBQ3ZFLGVBQWUsT0FBTyxZQUFZLFdBQVc7Q0FDN0MsSUFBSSxZQUFZLE1BQU0sTUFBTSxNQUFNLFdBQVc7Q0FFN0MsSUFBSSxNQUFNLFNBQVMsV0FBVyxVQUFVLEtBQUEsR0FBVztFQUNqRCxJQUFJLFVBQVU7RUFFZCxHQUFHO0dBQ0QsTUFBTSxPQUFPLGVBQWUsVUFBVSxNQUFNLFlBQVksSUFBSSxTQUFTLE1BQU0sT0FBTyxJQUFJO0dBRXRGLFVBQVUsUUFBUTtFQUNwQixTQUFTLFlBQVksS0FBQTtDQUN2QjtBQUNGOzs7QUN2Q0EsU0FBUyxRQUFRLEtBQUs7Q0FNcEIsSUFBSSxJQUFJO0NBRVIsSUFBSSxHQUNBLElBQUksR0FDSixNQUFNLElBQUk7Q0FFZCxPQUFPLE9BQU8sR0FBRyxFQUFFLEdBQUcsT0FBTyxHQUFHO0VBQzlCLElBQUksSUFBSSxXQUFXLENBQUMsSUFBSSxPQUFRLElBQUksV0FBVyxFQUFFLENBQUMsSUFBSSxRQUFTLEtBQUssSUFBSSxXQUFXLEVBQUUsQ0FBQyxJQUFJLFFBQVMsTUFBTSxJQUFJLFdBQVcsRUFBRSxDQUFDLElBQUksUUFBUztFQUN4SSxLQUVDLElBQUksU0FBVSxlQUFlLE1BQU0sTUFBTSxTQUFVO0VBQ3BELEtBRUEsTUFBTTtFQUNOLEtBRUMsSUFBSSxTQUFVLGVBQWUsTUFBTSxNQUFNLFNBQVUsT0FFbkQsSUFBSSxTQUFVLGVBQWUsTUFBTSxNQUFNLFNBQVU7Q0FDdEQ7Q0FHQSxRQUFRLEtBQVI7RUFDRSxLQUFLLEdBQ0gsTUFBTSxJQUFJLFdBQVcsSUFBSSxDQUFDLElBQUksUUFBUztFQUV6QyxLQUFLLEdBQ0gsTUFBTSxJQUFJLFdBQVcsSUFBSSxDQUFDLElBQUksUUFBUztFQUV6QyxLQUFLO0dBQ0gsS0FBSyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0dBQ3pCLEtBRUMsSUFBSSxTQUFVLGVBQWUsTUFBTSxNQUFNLFNBQVU7Q0FDeEQ7Q0FJQSxLQUFLLE1BQU07Q0FDWCxLQUVDLElBQUksU0FBVSxlQUFlLE1BQU0sTUFBTSxTQUFVO0NBQ3BELFNBQVMsSUFBSSxNQUFNLFFBQVEsRUFBQSxDQUFHLFNBQVMsRUFBRTtBQUMzQzs7O0FDcERBLElBQUksZUFBZTtDQUNqQix5QkFBeUI7Q0FDekIsYUFBYTtDQUNiLG1CQUFtQjtDQUNuQixrQkFBa0I7Q0FDbEIsa0JBQWtCO0NBQ2xCLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsaUJBQWlCO0NBQ2pCLGFBQWE7Q0FDYixTQUFTO0NBQ1QsTUFBTTtDQUNOLFVBQVU7Q0FDVixjQUFjO0NBQ2QsWUFBWTtDQUNaLGNBQWM7Q0FDZCxXQUFXO0NBQ1gsU0FBUztDQUNULFlBQVk7Q0FDWixhQUFhO0NBQ2IsY0FBYztDQUNkLFlBQVk7Q0FDWixlQUFlO0NBQ2YsZ0JBQWdCO0NBQ2hCLGlCQUFpQjtDQUNqQixXQUFXO0NBQ1gsZUFBZTtDQUNmLGNBQWM7Q0FDZCxrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLFlBQVk7Q0FDWixTQUFTO0NBQ1QsT0FBTztDQUNQLFNBQVM7Q0FDVCxPQUFPO0NBQ1AsU0FBUztDQUNULFFBQVE7Q0FDUixRQUFRO0NBQ1IsTUFBTTtDQUNOLGlCQUFpQjtDQUVqQixhQUFhO0NBQ2IsY0FBYztDQUNkLGFBQWE7Q0FDYixpQkFBaUI7Q0FDakIsa0JBQWtCO0NBQ2xCLGtCQUFrQjtDQUNsQixlQUFlO0NBQ2YsYUFBYTtBQUNmOzs7QUM3Q0EsSUFBSUMsa0JBQWdCO0FBRXBCLElBQUlDLGtDQUFnQztBQUNwQyxJQUFJLGdDQUFnQztBQUNwQyxJQUFJLGlCQUFpQjtBQUNyQixJQUFJLGlCQUFpQjtBQUVyQixJQUFJLG1CQUFtQixTQUFTLGlCQUFpQixVQUFVO0NBQ3pELE9BQU8sU0FBUyxXQUFXLENBQUMsTUFBTTtBQUNwQztBQUVBLElBQUkscUJBQXFCLFNBQVMsbUJBQW1CLE9BQU87Q0FDMUQsT0FBTyxTQUFTLFFBQVEsT0FBTyxVQUFVO0FBQzNDO0FBRUEsSUFBSSxtQkFBa0Msd0JBQVEsU0FBVSxXQUFXO0NBQ2pFLE9BQU8saUJBQWlCLFNBQVMsSUFBSSxZQUFZLFVBQVUsUUFBUSxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsWUFBWTtBQUN4RyxDQUFDO0FBRUQsSUFBSSxvQkFBb0IsU0FBUyxrQkFBa0IsS0FBSyxPQUFPO0NBQzdELFFBQVEsS0FBUjtFQUNFLEtBQUs7RUFDTCxLQUFLLGlCQUVELElBQUksT0FBTyxVQUFVLFVBQ25CLE9BQU8sTUFBTSxRQUFRLGdCQUFnQixTQUFVLE9BQU8sSUFBSSxJQUFJO0dBQzVELFNBQVM7SUFDUCxNQUFNO0lBQ04sUUFBUTtJQUNSLE1BQU07R0FDUjtHQUNBLE9BQU87RUFDVCxDQUFDO0NBR1Q7Q0FFQSxJQUFJQyxhQUFTLFNBQVMsS0FBSyxDQUFDLGlCQUFpQixHQUFHLEtBQUssT0FBTyxVQUFVLFlBQVksVUFBVSxHQUMxRixPQUFPLFFBQVE7Q0FHakIsT0FBTztBQUNUO0FBR0UsSUFBSSxzQkFBc0I7QUFDMUIsSUFBSSxnQkFBZ0I7Q0FBQztDQUFVO0NBQVE7Q0FBVztDQUFXO0FBQU87QUFDcEUsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxZQUFZO0FBQ2hCLElBQUksZ0JBQWdCO0FBQ3BCLElBQUksa0JBQWtCLENBQUM7QUFFdkIsb0JBQW9CLFNBQVMsa0JBQWtCLEtBQUssT0FBTztDQUN6RCxJQUFJLFFBQVE7TUFDTixPQUFPLFVBQVUsWUFBWSxjQUFjLFFBQVEsS0FBSyxNQUFNLE1BQU0sQ0FBQyxvQkFBb0IsS0FBSyxLQUFLLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxNQUFNLE9BQU8sTUFBTSxTQUFTLENBQUMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFNLFFBQU8sTUFBTSxPQUFPLENBQUMsTUFBTSxNQUNoTixNQUFNLElBQUksTUFBTSxtR0FBbUcsUUFBUSxNQUFNO0NBQUE7Q0FJckksSUFBSSxZQUFZLHFCQUFxQixLQUFLLEtBQUs7Q0FFL0MsSUFBSSxjQUFjLE1BQU0sQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLElBQUksUUFBUSxHQUFHLE1BQU0sTUFBTSxnQkFBZ0IsU0FBUyxLQUFBLEdBQVc7RUFDL0csZ0JBQWdCLE9BQU87RUFDdkIsUUFBUSxNQUFNLG1GQUFtRixJQUFJLFFBQVEsV0FBVyxLQUFLLENBQUMsQ0FBQyxRQUFRLGVBQWUsU0FBVSxLQUFLLE9BQU87R0FDMUssT0FBTyxNQUFNLFlBQVk7RUFDM0IsQ0FBQyxJQUFJLEdBQUc7Q0FDVjtDQUVBLE9BQU87QUFDVDtBQUdGLElBQUksNkJBQTZCO0FBRWpDLFNBQVMsb0JBQW9CLGFBQWEsWUFBWSxlQUFlO0NBQ25FLElBQUksaUJBQWlCLE1BQ25CLE9BQU87Q0FHVCxJQUFJLG9CQUFvQjtDQUV4QixJQUFJLGtCQUFrQixxQkFBcUIsS0FBQSxHQUFXO0VBQ3BELElBQUksT0FBTyxpQkFBaUIsTUFBTSx5QkFDaEMsTUFBTSxJQUFJLE1BQU0sMEJBQTBCO0VBRzVDLE9BQU87Q0FDVDtDQUVBLFFBQVEsT0FBTyxlQUFmO0VBQ0UsS0FBSyxXQUVELE9BQU87RUFHWCxLQUFLO0dBRUQsSUFBSSxZQUFZO0dBRWhCLElBQUksVUFBVSxTQUFTLEdBQUc7SUFDeEIsU0FBUztLQUNQLE1BQU0sVUFBVTtLQUNoQixRQUFRLFVBQVU7S0FDbEIsTUFBTTtJQUNSO0lBQ0EsT0FBTyxVQUFVO0dBQ25CO0dBRUEsSUFBSSxtQkFBbUI7R0FFdkIsSUFBSSxpQkFBaUIsV0FBVyxLQUFBLEdBQVc7SUFDekMsSUFBSSxPQUFPLGlCQUFpQjtJQUU1QixJQUFJLFNBQVMsS0FBQSxHQUdYLE9BQU8sU0FBUyxLQUFBLEdBQVc7S0FDekIsU0FBUztNQUNQLE1BQU0sS0FBSztNQUNYLFFBQVEsS0FBSztNQUNiLE1BQU07S0FDUjtLQUNBLE9BQU8sS0FBSztJQUNkO0lBSUYsT0FEYSxpQkFBaUIsU0FBUztHQUV6QztHQUVBLE9BQU8sdUJBQXVCLGFBQWEsWUFBWSxhQUFhO0VBR3hFLEtBQUs7R0FFRCxJQUFJLGdCQUFnQixLQUFBLEdBQVc7SUFDN0IsSUFBSSxpQkFBaUI7SUFDckIsSUFBSSxTQUFTLGNBQWMsV0FBVztJQUN0QyxTQUFTO0lBQ1QsT0FBTyxvQkFBb0IsYUFBYSxZQUFZLE1BQU07R0FDNUQsT0FDRSxRQUFRLE1BQU0sc1dBQTBYO0dBRzFZO0VBR0osS0FBSztHQUVELElBQUksVUFBVSxDQUFDO0dBQ2YsSUFBSSxXQUFXLGNBQWMsUUFBUSxnQkFBZ0IsU0FBVSxRQUFRLEtBQUssSUFBSTtJQUM5RSxJQUFJLGNBQWMsY0FBYyxRQUFRO0lBQ3hDLFFBQVEsS0FBSyxXQUFXLGNBQWMsa0JBQWtCLEdBQUcsUUFBUSw2QkFBNkIsRUFBRSxJQUFJLEdBQUc7SUFDekcsT0FBTyxPQUFPLGNBQWM7R0FDOUIsQ0FBQztHQUVELElBQUksUUFBUSxRQUNWLFFBQVEsTUFBTSxvSEFBb0gsQ0FBQyxDQUFDLENBQUMsT0FBTyxTQUFTLENBQUMsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUkseURBQXlELFdBQVcsR0FBRztHQUlyUTtDQUNKO0NBR0EsSUFBSSxXQUFXO0NBRWYsSUFBSSxjQUFjLE1BQ2hCLE9BQU87Q0FHVCxJQUFJLFNBQVMsV0FBVztDQUN4QixPQUFPLFdBQVcsS0FBQSxJQUFZLFNBQVM7QUFDekM7QUFFQSxTQUFTLHVCQUF1QixhQUFhLFlBQVksS0FBSztDQUM1RCxJQUFJLFNBQVM7Q0FFYixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FDOUIsVUFBVSxvQkFBb0IsYUFBYSxZQUFZLElBQUksRUFBRSxJQUFJO01BR25FLEtBQUssSUFBSSxPQUFPLEtBQUs7RUFDbkIsSUFBSSxRQUFRLElBQUk7RUFFaEIsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM3QixJQUFJLFdBQVc7R0FFZixJQUFJLGNBQWMsUUFBUSxXQUFXLGNBQWMsS0FBQSxHQUNqRCxVQUFVLE1BQU0sTUFBTSxXQUFXLFlBQVk7UUFDeEMsSUFBSSxtQkFBbUIsUUFBUSxHQUNwQyxVQUFVLGlCQUFpQixHQUFHLElBQUksTUFBTSxrQkFBa0IsS0FBSyxRQUFRLElBQUk7RUFFL0UsT0FBTztHQUNMLElBQUksUUFBUSwyQkFBMkJGLGlCQUNyQyxNQUFNLElBQUksTUFBTSwwQkFBMEI7R0FHNUMsSUFBSSxNQUFNLFFBQVEsS0FBSyxLQUFLLE9BQU8sTUFBTSxPQUFPLGFBQWEsY0FBYyxRQUFRLFdBQVcsTUFBTSxRQUFRLEtBQUE7U0FDckcsSUFBSSxLQUFLLEdBQUcsS0FBSyxNQUFNLFFBQVEsTUFDbEMsSUFBSSxtQkFBbUIsTUFBTSxHQUFHLEdBQzlCLFVBQVUsaUJBQWlCLEdBQUcsSUFBSSxNQUFNLGtCQUFrQixLQUFLLE1BQU0sR0FBRyxJQUFJO0dBQUEsT0FHM0U7SUFDTCxJQUFJLGVBQWUsb0JBQW9CLGFBQWEsWUFBWSxLQUFLO0lBRXJFLFFBQVEsS0FBUjtLQUNFLEtBQUs7S0FDTCxLQUFLO01BRUQsVUFBVSxpQkFBaUIsR0FBRyxJQUFJLE1BQU0sZUFBZTtNQUN2RDtLQUdKO01BRUksSUFBSSxRQUFRLGFBQ1YsUUFBUSxNQUFNLDZCQUE2QjtNQUc3QyxVQUFVLE1BQU0sTUFBTSxlQUFlO0lBRTNDO0dBQ0Y7RUFDRjtDQUNGO0NBR0YsT0FBTztBQUNUO0FBRUEsSUFBSSxlQUFlO0FBR25CLElBQUk7QUFDSixTQUFTLGdCQUFnQixNQUFNLFlBQVksYUFBYTtDQUN0RCxJQUFJLEtBQUssV0FBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyxPQUFPLFFBQVEsS0FBSyxFQUFFLENBQUMsV0FBVyxLQUFBLEdBQzdGLE9BQU8sS0FBSztDQUdkLElBQUksYUFBYTtDQUNqQixJQUFJLFNBQVM7Q0FDYixTQUFTLEtBQUE7Q0FDVCxJQUFJLFVBQVUsS0FBSztDQUVuQixJQUFJLFdBQVcsUUFBUSxRQUFRLFFBQVEsS0FBQSxHQUFXO0VBQ2hELGFBQWE7RUFDYixVQUFVLG9CQUFvQixhQUFhLFlBQVksT0FBTztDQUNoRSxPQUFPO0VBQ0wsSUFBSSx1QkFBdUI7RUFFM0IsSUFBSSxxQkFBcUIsT0FBTyxLQUFBLEdBQzlCLFFBQVEsTUFBTUMsK0JBQTZCO0VBRzdDLFVBQVUscUJBQXFCO0NBQ2pDO0NBR0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0VBQ3BDLFVBQVUsb0JBQW9CLGFBQWEsWUFBWSxLQUFLLEVBQUU7RUFFOUQsSUFBSSxZQUFZO0dBQ2QsSUFBSSxxQkFBcUI7R0FFekIsSUFBSSxtQkFBbUIsT0FBTyxLQUFBLEdBQzVCLFFBQVEsTUFBTUEsK0JBQTZCO0dBRzdDLFVBQVUsbUJBQW1CO0VBQy9CO0NBQ0Y7Q0FHQSxhQUFhLFlBQVk7Q0FDekIsSUFBSSxpQkFBaUI7Q0FDckIsSUFBSTtDQUVKLFFBQVEsUUFBUSxhQUFhLEtBQUssTUFBTSxPQUFPLE1BQzdDLGtCQUFrQixNQUFNLE1BQU07Q0FjOUIsT0FBTztFQVBMLE1BSk9FLFFBQVcsTUFBTSxJQUFJO0VBS3BCO0VBQ1IsTUFBTTtFQUNOLFVBQVUsU0FBUyxXQUFXO0dBQzVCLE9BQU87RUFDVDtDQUVhO0FBRW5COzs7QUMzU0EsSUFBSSxlQUFlLFNBQVMsYUFBYSxRQUFRO0NBQy9DLE9BQU8sT0FBTztBQUNoQjtBQUVBLElBQUkscUJBQUEsYUFBMkJDLHFCQUFBQSxhQUFtQ0EscUJBQTZCO0FBQy9GLElBQUksMkNBQTJDLHNCQUFzQjtBQUNyRSxJQUFJLHVDQUF1QyxzQkFBQSxhQUE0Qjs7O0FDRXZFLElBQUksc0JBQXFDLDZCQUFNLGNBTS9DLE9BQU8sZ0JBQWdCLGNBQTZCLDRCQUFZLEVBQzlELEtBQUssTUFDUCxDQUFDLElBQUksSUFBSTtBQUdQLG9CQUFvQixjQUFjO0FBR3BDLElBQUksZ0JBQWdCLG9CQUFvQjtBQUt4QyxJQUFJLG1CQUFtQixTQUFTLGlCQUFpQixNQUFNO0NBQ3JELE9BQW9CLGVBQUEsR0FBQSxhQUFBLFdBQUEsQ0FBVyxTQUFVLE9BQU8sS0FBSztFQUduRCxPQUFPLEtBQUssUUFBQSxHQUFBLGFBQUEsV0FBQSxDQURXLG1CQUNBLEdBQUcsR0FBRztDQUMvQixDQUFDO0FBQ0g7QUFFQSxJQUFJLGVBQThCLDZCQUFNLGNBQWMsQ0FBQyxDQUFDO0FBR3RELGFBQWEsY0FBYztBQXNEN0IsSUFBSSxTQUFTLENBQUMsRUFBRTtBQUVoQixJQUFJLGNBQWMsU0FBUyxZQUFZLGNBQWM7Q0FHbkQsSUFBSSxRQUFRLGFBQWEsTUFBTSxHQUFHO0NBQ2xDLE9BQU8sTUFBTSxNQUFNLFNBQVM7QUFDOUI7QUFFQSxJQUFJLG9DQUFvQyxTQUFTLGtDQUFrQyxNQUFNO0NBRXZGLElBQUksUUFBUSw4QkFBOEIsS0FBSyxJQUFJO0NBQ25ELElBQUksT0FBTyxPQUFPLFlBQVksTUFBTSxFQUFFO0NBRXRDLFFBQVEscUJBQXFCLEtBQUssSUFBSTtDQUN0QyxJQUFJLE9BQU8sT0FBTyxZQUFZLE1BQU0sRUFBRTtBQUV4QztBQUVBLElBQUksNkNBQTRDLElBQUksSUFBSTtDQUFDO0NBQW1CO0NBQWdCO0NBQXdCO0FBQWdCLENBQUM7QUFJckksSUFBSSxxQkFBcUIsU0FBUyxtQkFBbUIsWUFBWTtDQUMvRCxPQUFPLFdBQVcsUUFBUSxPQUFPLEdBQUc7QUFDdEM7QUFFQSxJQUFJLHlCQUF5QixTQUFTLHVCQUF1QixZQUFZO0NBQ3ZFLElBQUksQ0FBQyxZQUFZLE9BQU8sS0FBQTtDQUN4QixJQUFJLFFBQVEsV0FBVyxNQUFNLElBQUk7Q0FFakMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0VBQ3JDLElBQUksZUFBZSxrQ0FBa0MsTUFBTSxFQUFFO0VBRTdELElBQUksQ0FBQyxjQUFjO0VBRW5CLElBQUksMkJBQTJCLElBQUksWUFBWSxHQUFHO0VBR2xELElBQUksU0FBUyxLQUFLLFlBQVksR0FBRyxPQUFPLG1CQUFtQixZQUFZO0NBQ3pFO0FBR0Y7QUFFQSxJQUFJLGVBQWU7QUFDbkIsSUFBSSxnQkFBZ0I7QUFDcEIsSUFBSSxxQkFBcUIsU0FBUyxtQkFBbUIsTUFBTSxPQUFPO0NBQ2hFLElBQUksT0FBTyxNQUFNLFFBQVEsWUFDekIsTUFBTSxJQUFJLFFBQVEsR0FBRyxNQUFNLElBQ3pCLE1BQU0sSUFBSSxNQUFNLCtIQUErSCxNQUFNLE1BQU0sR0FBRztDQUdoSyxJQUFJLFdBQVcsQ0FBQztDQUVoQixLQUFLLElBQUksUUFBUSxPQUNmLElBQUksT0FBTyxLQUFLLE9BQU8sSUFBSSxHQUN6QixTQUFTLFFBQVEsTUFBTTtDQUkzQixTQUFTLGdCQUFnQjtDQU96QixJQUFJLE9BQU8sZUFBZSxlQUFlLENBQUMsQ0FBQyxXQUFXLDhCQUE4QixDQUFDLENBQUMsTUFBTSxRQUFRLE9BQU8sTUFBTSxRQUFRLFlBQVksRUFBRSxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sSUFBSSxTQUFTLFlBQVksTUFBTSxJQUFJLEtBQUssUUFBUSxHQUFHLE1BQU0sS0FBSztFQUN4TyxJQUFJLFFBQVEsd0NBQXVCLElBQUksTUFBTSxFQUFBLENBQUUsS0FBSztFQUNwRCxJQUFJLE9BQU8sU0FBUyxpQkFBaUI7Q0FDdkM7Q0FFQSxPQUFPO0FBQ1Q7QUFFQSxJQUFJQyxjQUFZLFNBQVMsVUFBVSxNQUFNO0NBQ3ZDLElBQUksUUFBUSxLQUFLLE9BQ2IsYUFBYSxLQUFLLFlBQ2xCLGNBQWMsS0FBSztDQUN2QixlQUFlLE9BQU8sWUFBWSxXQUFXO0NBQzdDLHlDQUF5QyxXQUFZO0VBQ25ELE9BQU8sYUFBYSxPQUFPLFlBQVksV0FBVztDQUNwRCxDQUFDO0NBRUQsT0FBTztBQUNUO0FBRUEsSUFBSSxVQUF5QixpQ0FBaUIsU0FBVSxPQUFPLE9BQU8sS0FBSztDQUN6RSxJQUFJLFVBQVUsTUFBTTtDQUlwQixJQUFJLE9BQU8sWUFBWSxZQUFZLE1BQU0sV0FBVyxhQUFhLEtBQUEsR0FDL0QsVUFBVSxNQUFNLFdBQVc7Q0FHN0IsSUFBSSxtQkFBbUIsTUFBTTtDQUM3QixJQUFJLG1CQUFtQixDQUFDLE9BQU87Q0FDL0IsSUFBSSxZQUFZO0NBRWhCLElBQUksT0FBTyxNQUFNLGNBQWMsVUFDN0IsWUFBWSxvQkFBb0IsTUFBTSxZQUFZLGtCQUFrQixNQUFNLFNBQVM7TUFDOUUsSUFBSSxNQUFNLGFBQWEsTUFDNUIsWUFBWSxNQUFNLFlBQVk7Q0FHaEMsSUFBSSxhQUFhLGdCQUFnQixrQkFBa0IsS0FBQSxHQUFBLGFBQWlCLFdBQVcsWUFBWSxDQUFDO0NBRTVGLElBQUksV0FBVyxLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUk7RUFDdkMsSUFBSSxpQkFBaUIsTUFBTTtFQUUzQixJQUFJLGdCQUNGLGFBQWEsZ0JBQWdCLENBQUMsWUFBWSxXQUFXLGlCQUFpQixHQUFHLENBQUM7Q0FFOUU7Q0FFQSxhQUFhLE1BQU0sTUFBTSxNQUFNLFdBQVc7Q0FDMUMsSUFBSSxXQUFXLENBQUM7Q0FFaEIsS0FBSyxJQUFJLFNBQVMsT0FDaEIsSUFBSSxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUssVUFBVSxTQUFTLFVBQVUsZ0JBQWlCLFVBQVUsZUFDdkYsU0FBUyxTQUFTLE1BQU07Q0FJNUIsU0FBUyxZQUFZO0NBRXJCLElBQUksS0FDRixTQUFTLE1BQU07Q0FHakIsT0FBb0IsMkJBQU0sY0FBQSxhQUFvQixVQUFVLE1BQW1CLDJCQUFNLGNBQWNBLGFBQVc7RUFDakc7RUFDSztFQUNaLGFBQWEsT0FBTyxxQkFBcUI7Q0FDM0MsQ0FBQyxHQUFnQiwyQkFBTSxjQUFjLGtCQUFrQixRQUFRLENBQUM7QUFDbEUsQ0FBQztBQUdDLFFBQVEsY0FBYztBQUd4QixJQUFJLFlBQVk7O0FDak9oQixJQUFJQyxrQkFBZ0I7QUFFcEIsSUFBSSxNQUFNO0NBQ1QsTUFBTTtDQUNOLFNBQVM7Q0FDVCxNQUFNO0NBQ04sUUFBUTtDQUNSLE9BQU87Q0FDUCxTQUFTO0VBQ1IsS0FBSztHQUNKLE9BQU87SUFDTixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsYUFBYTtJQUNaLGNBQWM7S0FDYixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFFBQVE7S0FDUCxRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFNBQVM7S0FDUixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFNBQVM7S0FDUixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsY0FBYztJQUNiLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsUUFBUTtJQUNQLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsU0FBUztJQUNSLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsU0FBUztJQUNSLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsUUFBUTtHQUNSLFVBQVU7R0FDVixXQUFXO0VBQ1o7RUFDQSxpQkFBaUI7R0FDaEIsT0FBTztJQUNOLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxhQUFhO0lBQ1osY0FBYztLQUNiLFFBQVE7S0FDUixVQUFVO0tBQ1YsV0FBVztJQUNaO0lBQ0EsUUFBUTtLQUNQLFFBQVE7S0FDUixVQUFVO0tBQ1YsV0FBVztJQUNaO0lBQ0EsU0FBUztLQUNSLFFBQVE7S0FDUixVQUFVO0tBQ1YsV0FBVztJQUNaO0lBQ0EsU0FBUztLQUNSLFFBQVE7S0FDUixVQUFVO0tBQ1YsV0FBVztJQUNaO0lBQ0EsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxjQUFjO0lBQ2IsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxRQUFRO0lBQ1AsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxTQUFTO0lBQ1IsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxTQUFTO0lBQ1IsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0dBQ1o7R0FDQSxRQUFRO0dBQ1IsVUFBVTtHQUNWLFdBQVc7RUFDWjtFQUNBLG9CQUFvQjtHQUNuQixPQUFPO0lBQ04sVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLGFBQWE7SUFDWixjQUFjO0tBQ2IsUUFBUTtLQUNSLFVBQVU7S0FDVixXQUFXO0lBQ1o7SUFDQSxRQUFRO0tBQ1AsUUFBUTtLQUNSLFVBQVU7S0FDVixXQUFXO0lBQ1o7SUFDQSxTQUFTO0tBQ1IsUUFBUTtLQUNSLFVBQVU7S0FDVixXQUFXO0lBQ1o7SUFDQSxTQUFTO0tBQ1IsUUFBUTtLQUNSLFVBQVU7S0FDVixXQUFXO0lBQ1o7SUFDQSxRQUFRO0lBQ1IsVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLGNBQWM7SUFDYixRQUFRO0lBQ1IsVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLFFBQVE7SUFDUCxRQUFRO0lBQ1IsVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLFNBQVM7SUFDUixRQUFRO0lBQ1IsVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLFNBQVM7SUFDUixRQUFRO0lBQ1IsVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLFFBQVE7R0FDUixVQUFVO0dBQ1YsV0FBVztFQUNaO0VBQ0EscUJBQXFCO0dBQ3BCLE9BQU87SUFDTixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsYUFBYTtJQUNaLGNBQWM7S0FDYixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFFBQVE7S0FDUCxRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFNBQVM7S0FDUixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFNBQVM7S0FDUixRQUFRO0tBQ1IsVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsY0FBYztJQUNiLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsUUFBUTtJQUNQLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsU0FBUztJQUNSLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsU0FBUztJQUNSLFFBQVE7SUFDUixVQUFVO0lBQ1YsV0FBVztHQUNaO0dBQ0EsUUFBUTtHQUNSLFVBQVU7R0FDVixXQUFXO0VBQ1o7RUFDQSxrQkFBa0I7RUFDbEIsb0JBQW9CO0VBQ3BCLFdBQVc7R0FDVixPQUFPO0lBQ04sVUFBVTtJQUNWLFdBQVc7R0FDWjtHQUNBLFdBQVc7RUFDWjtDQUNEO0NBQ0EsU0FBUztFQUNSLG1CQUFtQjtHQUNsQixhQUFhO0dBQ2IsV0FBVztFQUNaO0VBQ0EsZUFBZTtHQUNkLGNBQWM7R0FDZCxTQUFTO0dBQ1QsUUFBUTtHQUNSLFNBQVM7R0FDVCxXQUFXO0VBQ1o7Q0FDRDtDQUNBLE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0NBQ0EsYUFBYTtDQUNiLFFBQVE7Q0FDUixTQUFTO0NBQ1QsU0FBUyxFQUNSLG1CQUFtQixnQkFDcEI7Q0FDQSxjQUFjO0VBQ2Isa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QixrQkFBa0I7RUFDbEIsc0JBQXNCO0VBQ3RCLGdEQUFnRDtFQUNoRCxrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLDJCQUEyQjtDQUM1QjtDQUNBLGtCQUFrQixFQUNqQixPQUFPLFdBQ1I7Q0FDQSxzQkFBc0IsRUFDckIsZ0JBQWdCLEVBQ2YsVUFBVSxLQUNYLEVBQ0Q7Q0FDQSxpQkFBaUI7RUFDaEIsNEJBQTRCO0VBQzVCLGdCQUFnQjtFQUNoQiwyQkFBMkI7RUFDM0IsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQixrQ0FBa0M7RUFDbEMsa0JBQWtCO0VBQ2xCLE9BQU87RUFDUCxpQkFBaUI7RUFDakIsWUFBWTtDQUNiO0NBQ0EsWUFBWTtDQUNaLGVBQWUsRUFDZCxRQUFRLFNBQ1Q7Q0FDQSxZQUFZO0NBQ1osY0FBYztFQUNiLGFBQWE7R0FDWjtHQUNBO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsU0FBUztFQUNULFNBQVMsRUFDUixPQUFPO0dBQ04sb0JBQW9CO0dBQ3BCLFdBQVc7SUFDVixPQUFPO0tBQ04sVUFBVTtLQUNWLFdBQVc7SUFDWjtJQUNBLFdBQVc7R0FDWjtFQUNELEVBQ0Q7Q0FDRDtBQUNEO0FBRUEsSUFBSSxNQUFNLFNBQVMsSUFBSSxNQUFNLE9BQU87Q0FFbEMsSUFBSSxPQUFPO0NBRVgsSUFBSSxTQUFTLFFBQVEsQ0FBQyxPQUFPLEtBQUssT0FBTyxLQUFLLEdBQzVDLE9BQUEsYUFBYSxjQUFjLE1BQU0sS0FBQSxHQUFXLElBQUk7Q0FHbEQsSUFBSSxhQUFhLEtBQUs7Q0FDdEIsSUFBSSx3QkFBd0IsSUFBSSxNQUFNLFVBQVU7Q0FDaEQsc0JBQXNCLEtBQUtDO0NBQzNCLHNCQUFzQixLQUFLLG1CQUFtQixNQUFNLEtBQUs7Q0FFekQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksS0FDOUIsc0JBQXNCLEtBQUssS0FBSztDQUdsQyxPQUFBLGFBQWEsY0FBYyxNQUFNLE1BQU0scUJBQXFCO0FBQzlEO0NBRUMsU0FBVSxNQUFNO0NBQ2YsSUFBSTtDQUVpQixRQUFRLE1BQU0sS0FBSyxRQUFRLEtBQUssTUFBTSxDQUFDO0FBQzlELEVBQUEsQ0FBRyxRQUFRLE1BQU0sQ0FBQyxFQUFFO0FBRXBCLElBQUksOEJBQThCO0FBSWxDLElBQUksU0FBd0IsaUNBQWlCLFNBQVUsT0FBTyxPQUFPO0NBQ25FLElBQUksQ0FBQyxnQ0FJTCxlQUFlLFNBQVMsTUFBTSxhQUFhLFNBQVMsU0FBUyxNQUFNLE1BQU07RUFDdkUsUUFBUSxNQUFNLGlHQUFpRztFQUMvRyw4QkFBOEI7Q0FDaEM7Q0FFQSxJQUFJLFNBQVMsTUFBTTtDQUNuQixJQUFJLGFBQWEsZ0JBQWdCLENBQUMsTUFBTSxHQUFHLEtBQUEsR0FBQSxhQUFpQixXQUFXLFlBQVksQ0FBQztDQU1wRixJQUFJLFdBQUEsYUFBaUIsT0FBTztDQUM1QixxQ0FBcUMsV0FBWTtFQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNO0VBRXRCLElBQUksUUFBUSxJQUFJLE1BQU0sTUFBTSxZQUFZO0dBQ2pDO0dBQ0wsT0FBTyxNQUFNLE1BQU07R0FDbkIsV0FBVyxNQUFNLE1BQU07R0FDdkIsUUFBUSxNQUFNLE1BQU07RUFDdEIsQ0FBQztFQUNELElBQUksY0FBYztFQUNsQixJQUFJLE9BQU8sU0FBUyxjQUFjLDBCQUEwQixNQUFNLE1BQU0sV0FBVyxPQUFPLEtBQUs7RUFFL0YsSUFBSSxNQUFNLE1BQU0sS0FBSyxRQUNuQixNQUFNLFNBQVMsTUFBTSxNQUFNLEtBQUs7RUFHbEMsSUFBSSxTQUFTLE1BQU07R0FDakIsY0FBYztHQUVkLEtBQUssYUFBYSxnQkFBZ0IsR0FBRztHQUNyQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUM7RUFDdEI7RUFFQSxTQUFTLFVBQVUsQ0FBQyxPQUFPLFdBQVc7RUFDdEMsT0FBTyxXQUFZO0dBQ2pCLE1BQU0sTUFBTTtFQUNkO0NBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUNWLHFDQUFxQyxXQUFZO0VBQy9DLElBQUksa0JBQWtCLFNBQVM7RUFDL0IsSUFBSSxRQUFRLGdCQUFnQjtFQUc1QixJQUZrQixnQkFBZ0IsSUFFakI7R0FDZixnQkFBZ0IsS0FBSztHQUNyQjtFQUNGO0VBRUEsSUFBSSxXQUFXLFNBQVMsS0FBQSxHQUV0QixhQUFhLE9BQU8sV0FBVyxNQUFNLElBQUk7RUFHM0MsSUFBSSxNQUFNLEtBQUssUUFBUTtHQUdyQixNQUFNLFNBRFEsTUFBTSxLQUFLLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztHQUVoRCxNQUFNLE1BQU07RUFDZDtFQUVBLE1BQU0sT0FBTyxJQUFJLFlBQVksT0FBTyxLQUFLO0NBQzNDLEdBQUcsQ0FBQyxPQUFPLFdBQVcsSUFBSSxDQUFDO0NBQzNCLE9BQU87QUFDVCxDQUFDO0FBR0MsT0FBTyxjQUFjO0FBR3ZCLFNBQVMsTUFBTTtDQUNiLEtBQUssSUFBSSxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUksTUFBTSxJQUFJLEdBQUcsT0FBTyxHQUFHLE9BQU8sTUFBTSxRQUMvRSxLQUFLLFFBQVEsVUFBVTtDQUd6QixPQUFPLGdCQUFnQixJQUFJO0FBQzdCO0FBRUEsU0FBUyxZQUFZO0NBQ25CLElBQUksYUFBYSxJQUFJLE1BQU0sS0FBSyxHQUFHLFNBQVM7Q0FDNUMsSUFBSSxPQUFPLGVBQWUsV0FBVztDQUNyQyxPQUFPO0VBQ0M7RUFDTixRQUFRLGdCQUFnQixPQUFPLE1BQU0sV0FBVyxTQUFTO0VBQ3pELE1BQU07RUFDTixVQUFVLFNBQVMsV0FBVztHQUM1QixPQUFPLFVBQVUsS0FBSyxPQUFPLE1BQU0sS0FBSyxTQUFTO0VBQ25EO0NBQ0Y7QUFDRjtBQUVBLElBQUksYUFBYSxTQUFTLFdBQVcsTUFBTTtDQUN6QyxJQUFJLE1BQU0sS0FBSztDQUNmLElBQUksSUFBSTtDQUNSLElBQUksTUFBTTtDQUVWLE9BQU8sSUFBSSxLQUFLLEtBQUs7RUFDbkIsSUFBSSxNQUFNLEtBQUs7RUFDZixJQUFJLE9BQU8sTUFBTTtFQUNqQixJQUFJLFFBQVEsS0FBSztFQUVqQixRQUFRLE9BQU8sS0FBZjtHQUNFLEtBQUssV0FDSDtHQUVGLEtBQUs7SUFFRCxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ25CLFFBQVEsV0FBVyxHQUFHO1NBQ2pCO0tBQ0wsSUFBSSxJQUFJLFdBQVcsS0FBQSxLQUFhLElBQUksU0FBUyxLQUFBLEdBQzNDLFFBQVEsTUFBTSw2UEFBa1E7S0FHbFIsUUFBUTtLQUVSLEtBQUssSUFBSSxLQUFLLEtBQ1osSUFBSSxJQUFJLE1BQU0sR0FBRztNQUNmLFVBQVUsU0FBUztNQUNuQixTQUFTO0tBQ1g7SUFFSjtJQUVBO0dBR0osU0FFSSxRQUFRO0VBRWQ7RUFFQSxJQUFJLE9BQU87R0FDVCxRQUFRLE9BQU87R0FDZixPQUFPO0VBQ1Q7Q0FDRjtDQUVBLE9BQU87QUFDVDtBQUVBLFNBQVMsTUFBTSxZQUFZLEtBQUssV0FBVztDQUN6QyxJQUFJLG1CQUFtQixDQUFDO0NBQ3hCLElBQUksZUFBZSxvQkFBb0IsWUFBWSxrQkFBa0IsU0FBUztDQUU5RSxJQUFJLGlCQUFpQixTQUFTLEdBQzVCLE9BQU87Q0FHVCxPQUFPLGVBQWUsSUFBSSxnQkFBZ0I7QUFDNUM7QUFFQSxJQUFJQyxjQUFZLFNBQVMsVUFBVSxNQUFNO0NBQ3ZDLElBQUksUUFBUSxLQUFLLE9BQ2IsZ0JBQWdCLEtBQUs7Q0FDekIseUNBQXlDLFdBQVk7RUFFbkQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUN4QyxhQUFhLE9BQU8sY0FBYyxJQUFJLEtBQUs7Q0FFL0MsQ0FBQztDQUVELE9BQU87QUFDVDtBQUVBLElBQUksYUFBNEIsaUNBQWlCLFNBQVUsT0FBTyxPQUFPO0NBQ3ZFLElBQUksY0FBYztDQUNsQixJQUFJLGdCQUFnQixDQUFDO0NBRXJCLElBQUksTUFBTSxTQUFTLE1BQU07RUFDdkIsSUFBSSxlQUFlRixpQkFDakIsTUFBTSxJQUFJLE1BQU0sb0NBQW9DO0VBR3RELEtBQUssSUFBSSxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUksTUFBTSxJQUFJLEdBQUcsT0FBTyxHQUFHLE9BQU8sTUFBTSxRQUMvRSxLQUFLLFFBQVEsVUFBVTtFQUd6QixJQUFJLGFBQWEsZ0JBQWdCLE1BQU0sTUFBTSxVQUFVO0VBQ3ZELGNBQWMsS0FBSyxVQUFVO0VBRTdCLGVBQWUsT0FBTyxZQUFZLEtBQUs7RUFDdkMsT0FBTyxNQUFNLE1BQU0sTUFBTSxXQUFXO0NBQ3RDO0NBY0EsSUFBSSxVQUFVO0VBQ1A7RUFDTCxJQUFJLFNBZFksS0FBSztHQUNyQixJQUFJLGVBQWVBLGlCQUNqQixNQUFNLElBQUksTUFBTSxtQ0FBbUM7R0FHckQsS0FBSyxJQUFJLFFBQVEsVUFBVSxRQUFRLE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRyxRQUFRLEdBQUcsUUFBUSxPQUFPLFNBQ3BGLEtBQUssU0FBUyxVQUFVO0dBRzFCLE9BQU8sTUFBTSxNQUFNLFlBQVksS0FBSyxXQUFXLElBQUksQ0FBQztFQUN0RDtFQUtFLE9BQUEsYUFBYSxXQUFXLFlBQVk7Q0FDdEM7Q0FDQSxJQUFJLE1BQU0sTUFBTSxTQUFTLE9BQU87Q0FDaEMsY0FBYztDQUNkLE9BQW9CLDJCQUFNLGNBQUEsYUFBb0IsVUFBVSxNQUFtQiwyQkFBTSxjQUFjRSxhQUFXO0VBQ2pHO0VBQ1E7Q0FDakIsQ0FBQyxHQUFHLEdBQUc7QUFDVCxDQUFDO0FBR0MsV0FBVyxjQUFjO0FBSXpCLElBQUksWUFBWSxPQUFPLGFBQWE7QUFJcEMsSUFBSSxhQUFhLEVBRkQsT0FBTyxTQUFTLGVBQWUsT0FBTyxPQUFPLGNBRWhDO0NBRTNCLElBQUksZ0JBQWdCLE9BQU8sZUFBZSxjQUFjLGFBQ3RELFlBQVksU0FBUztDQUN2QixJQUFJLFlBQVkscUJBQXFCLElBQUksUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUs7Q0FFakUsSUFBSSxjQUFjLFlBQ2hCLFFBQVEsS0FBSyw2TUFBNE47Q0FHM08sY0FBYyxhQUFhO0FBQzdCOzs7QUN0bEJGLElBQUksa0JBQWtCO0FBRXRCLElBQUksY0FBNkIsd0JBQVEsU0FBVSxNQUFNO0NBQ3ZELE9BQU8sZ0JBQWdCLEtBQUssSUFBSSxLQUFLLEtBQUssV0FBVyxDQUFDLE1BQU0sT0FFekQsS0FBSyxXQUFXLENBQUMsTUFBTSxPQUV2QixLQUFLLFdBQVcsQ0FBQyxJQUFJO0FBQzFCLENBRUE7OztBQ0xBLElBQUksZ0JBQWdCO0FBRXBCLElBQUksMkJBQTJCO0FBRS9CLElBQUksMkJBQTJCLFNBQVMseUJBQXlCLEtBQUs7Q0FDcEUsT0FBTyxRQUFRO0FBQ2pCO0FBRUEsSUFBSSw4QkFBOEIsU0FBUyw0QkFBNEIsS0FBSztDQUMxRSxPQUFPLE9BQU8sUUFBUSxZQUd0QixJQUFJLFdBQVcsQ0FBQyxJQUFJLEtBQUssMkJBQTJCO0FBQ3REO0FBQ0EsSUFBSSw0QkFBNEIsU0FBUywwQkFBMEIsS0FBSyxTQUFTLFFBQVE7Q0FDdkYsSUFBSTtDQUVKLElBQUksU0FBUztFQUNYLElBQUksMkJBQTJCLFFBQVE7RUFDdkMsb0JBQW9CLElBQUkseUJBQXlCLDJCQUEyQixTQUFVLFVBQVU7R0FDOUYsT0FBTyxJQUFJLHNCQUFzQixRQUFRLEtBQUsseUJBQXlCLFFBQVE7RUFDakYsSUFBSTtDQUNOO0NBRUEsSUFBSSxPQUFPLHNCQUFzQixjQUFjLFFBQzdDLG9CQUFvQixJQUFJO0NBRzFCLE9BQU87QUFDVDtBQUVBLElBQUksZ0NBQWdDO0FBRXBDLElBQUksWUFBWSxTQUFTLFVBQVUsTUFBTTtDQUN2QyxJQUFJLFFBQVEsS0FBSyxPQUNiLGFBQWEsS0FBSyxZQUNsQixjQUFjLEtBQUs7Q0FDdkIsZUFBZSxPQUFPLFlBQVksV0FBVztDQUM3Qyx5Q0FBeUMsV0FBWTtFQUNuRCxPQUFPLGFBQWEsT0FBTyxZQUFZLFdBQVc7Q0FDcEQsQ0FBQztDQUVELE9BQU87QUFDVDtBQUVBLElBQUlDLGlCQUFlLFNBQVMsYUFBYSxLQUFLLFNBQVM7Q0FFbkQsSUFBSSxRQUFRLEtBQUEsR0FDVixNQUFNLElBQUksTUFBTSw4R0FBOEc7Q0FJbEksSUFBSSxTQUFTLElBQUksbUJBQW1CO0NBQ3BDLElBQUksVUFBVSxVQUFVLElBQUksa0JBQWtCO0NBQzlDLElBQUk7Q0FDSixJQUFJO0NBRUosSUFBSSxZQUFZLEtBQUEsR0FBVztFQUN6QixpQkFBaUIsUUFBUTtFQUN6QixrQkFBa0IsUUFBUTtDQUM1QjtDQUVBLElBQUksb0JBQW9CLDBCQUEwQixLQUFLLFNBQVMsTUFBTTtDQUN0RSxJQUFJLDJCQUEyQixxQkFBcUIsNEJBQTRCLE9BQU87Q0FDdkYsSUFBSSxjQUFjLENBQUMseUJBQXlCLElBQUk7Q0FDaEQsT0FBTyxXQUFZO0VBRWpCLElBQUksT0FBTztFQUNYLElBQUksU0FBUyxVQUFVLElBQUkscUJBQXFCLEtBQUEsSUFBWSxJQUFJLGlCQUFpQixNQUFNLENBQUMsSUFBSSxDQUFDO0VBRTdGLElBQUksbUJBQW1CLEtBQUEsR0FDckIsT0FBTyxLQUFLLFdBQVcsaUJBQWlCLEdBQUc7RUFHN0MsSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLLEVBQUUsQ0FBQyxRQUFRLEtBQUEsR0FFckMsT0FBTyxLQUFLLE1BQU0sUUFBUSxJQUFJO09BQ3pCO0dBQ0wsSUFBSSxxQkFBcUIsS0FBSztHQUU5QixJQUFJLG1CQUFtQixPQUFPLEtBQUEsR0FDNUIsUUFBUSxNQUFNLDZCQUE2QjtHQUc3QyxPQUFPLEtBQUssbUJBQW1CLEVBQUU7R0FDakMsSUFBSSxNQUFNLEtBQUs7R0FDZixJQUFJLElBQUk7R0FFUixPQUFPLElBQUksS0FBSyxLQUFLO0lBQ25CLElBQUksbUJBQW1CLE9BQU8sS0FBQSxHQUM1QixRQUFRLE1BQU0sNkJBQTZCO0lBRzdDLE9BQU8sS0FBSyxLQUFLLElBQUksbUJBQW1CLEVBQUU7R0FDNUM7RUFDRjtFQUVBLElBQUksU0FBUyxpQkFBaUIsU0FBVSxPQUFPLE9BQU8sS0FBSztHQUN6RCxJQUFJLFdBQVcsZUFBZSxNQUFNLE1BQU07R0FDMUMsSUFBSSxZQUFZO0dBQ2hCLElBQUksc0JBQXNCLENBQUM7R0FDM0IsSUFBSSxjQUFjO0dBRWxCLElBQUksTUFBTSxTQUFTLE1BQU07SUFDdkIsY0FBYyxDQUFDO0lBRWYsS0FBSyxJQUFJLE9BQU8sT0FDZCxZQUFZLE9BQU8sTUFBTTtJQUczQixZQUFZLFFBQUEsYUFBYyxXQUFXLFlBQVk7R0FDbkQ7R0FFQSxJQUFJLE9BQU8sTUFBTSxjQUFjLFVBQzdCLFlBQVksb0JBQW9CLE1BQU0sWUFBWSxxQkFBcUIsTUFBTSxTQUFTO1FBQ2pGLElBQUksTUFBTSxhQUFhLE1BQzVCLFlBQVksTUFBTSxZQUFZO0dBR2hDLElBQUksYUFBYSxnQkFBZ0IsT0FBTyxPQUFPLG1CQUFtQixHQUFHLE1BQU0sWUFBWSxXQUFXO0dBQ2xHLGFBQWEsTUFBTSxNQUFNLE1BQU0sV0FBVztHQUUxQyxJQUFJLG9CQUFvQixLQUFBLEdBQ3RCLGFBQWEsTUFBTTtHQUdyQixJQUFJLHlCQUF5QixlQUFlLHNCQUFzQixLQUFBLElBQVksNEJBQTRCLFFBQVEsSUFBSTtHQUN0SCxJQUFJLFdBQVcsQ0FBQztHQUVoQixLQUFLLElBQUksUUFBUSxPQUFPO0lBQ3RCLElBQUksZUFBZSxTQUFTLE1BQU07SUFFbEMsSUFBSSx1QkFBdUIsSUFBSSxHQUM3QixTQUFTLFFBQVEsTUFBTTtHQUUzQjtHQUVBLFNBQVMsWUFBWTtHQUVyQixJQUFJLEtBQ0YsU0FBUyxNQUFNO0dBR2pCLE9BQW9CLDJCQUFNLGNBQUEsYUFBb0IsVUFBVSxNQUFtQiwyQkFBTSxjQUFjLFdBQVc7SUFDakc7SUFDSztJQUNaLGFBQWEsT0FBTyxhQUFhO0dBQ25DLENBQUMsR0FBZ0IsMkJBQU0sY0FBYyxVQUFVLFFBQVEsQ0FBQztFQUMxRCxDQUFDO0VBQ0QsT0FBTyxjQUFjLG1CQUFtQixLQUFBLElBQVksaUJBQWlCLGFBQWEsT0FBTyxZQUFZLFdBQVcsVUFBVSxRQUFRLGVBQWUsUUFBUSxRQUFRLGVBQWU7RUFDaEwsT0FBTyxlQUFlLElBQUk7RUFDMUIsT0FBTyxpQkFBaUI7RUFDeEIsT0FBTyxpQkFBaUI7RUFDeEIsT0FBTyxtQkFBbUI7RUFDMUIsT0FBTyx3QkFBd0I7RUFDL0IsT0FBTyxlQUFlLFFBQVEsWUFBWSxFQUN4QyxPQUFPLFNBQVMsUUFBUTtHQUN0QixJQUFJLG9CQUFvQixLQUFBLEtBQWEsZUFDbkMsT0FBTztHQUdULE9BQU8sTUFBTTtFQUNmLEVBQ0YsQ0FBQztFQUVELE9BQU8sZ0JBQWdCLFNBQVUsU0FBUyxhQUFhO0dBSXJELE9BSGdCLGFBQWEsU0FBUyxTQUFTLENBQUMsR0FBRyxTQUFTLGFBQWEsRUFDdkUsbUJBQW1CLDBCQUEwQixRQUFRLGFBQWEsSUFBSSxFQUN4RSxDQUFDLENBQ2MsQ0FBQyxDQUFDLE1BQU0sS0FBSyxHQUFHLE1BQU07RUFDdkM7RUFFQSxPQUFPO0NBQ1Q7QUFDRjs7O0FDN0tBLElBQUksT0FBTztDQUFDO0NBQUs7Q0FBUTtDQUFXO0NBQVE7Q0FBVztDQUFTO0NBQVM7Q0FBSztDQUFRO0NBQU87Q0FBTztDQUFPO0NBQWM7Q0FBUTtDQUFNO0NBQVU7Q0FBVTtDQUFXO0NBQVE7Q0FBUTtDQUFPO0NBQVk7Q0FBUTtDQUFZO0NBQU07Q0FBTztDQUFXO0NBQU87Q0FBVTtDQUFPO0NBQU07Q0FBTTtDQUFNO0NBQVM7Q0FBWTtDQUFjO0NBQVU7Q0FBVTtDQUFRO0NBQU07Q0FBTTtDQUFNO0NBQU07Q0FBTTtDQUFNO0NBQVE7Q0FBVTtDQUFVO0NBQU07Q0FBUTtDQUFLO0NBQVU7Q0FBTztDQUFTO0NBQU87Q0FBTztDQUFVO0NBQVM7Q0FBVTtDQUFNO0NBQVE7Q0FBUTtDQUFPO0NBQVE7Q0FBVztDQUFRO0NBQVk7Q0FBUTtDQUFTO0NBQU87Q0FBWTtDQUFVO0NBQU07Q0FBWTtDQUFVO0NBQVU7Q0FBSztDQUFTO0NBQVc7Q0FBTztDQUFZO0NBQUs7Q0FBTTtDQUFNO0NBQVE7Q0FBSztDQUFRO0NBQVU7Q0FBVztDQUFVO0NBQVM7Q0FBVTtDQUFRO0NBQVU7Q0FBUztDQUFPO0NBQVc7Q0FBTztDQUFTO0NBQVM7Q0FBTTtDQUFZO0NBQVM7Q0FBTTtDQUFTO0NBQVE7Q0FBUztDQUFNO0NBQVM7Q0FBSztDQUFNO0NBQU87Q0FBUztDQUM3N0I7Q0FBVTtDQUFZO0NBQVE7Q0FBVztDQUFpQjtDQUFLO0NBQVM7Q0FBUTtDQUFrQjtDQUFRO0NBQVE7Q0FBVztDQUFXO0NBQVk7Q0FBa0I7Q0FBUTtDQUFRO0NBQU87Q0FBUTtBQUFPO0FBRzVNLElBQUlDLFdBQVNDLGVBQWEsS0FBSyxJQUFJO0FBQ25DLEtBQUssUUFBUSxTQUFVLFNBQVM7Q0FDOUIsU0FBTyxXQUFXRCxTQUFPLE9BQU87QUFDbEMsQ0FBQzs7Ozs7Ozs7OztBQ0VELFNBQVNFLFNBQU8sS0FBSyxTQUFTO0NBRzVCLE1BQU0sZ0JBQWdCQyxTQUFTLEtBQUssT0FBTztDQUV6QyxRQUFRLEdBQUcsV0FBVztFQUNwQixNQUFNLFlBQVksT0FBTyxRQUFRLFdBQVcsSUFBSSxJQUFJLEtBQUs7RUFDekQsSUFBSSxPQUFPLFdBQVcsR0FDcEIsUUFBUSxNQUFNLENBQUMsdUNBQXVDLFVBQVUsc0NBQXNDLGdGQUE4RSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUM7T0FDM0wsSUFBSSxPQUFPLE1BQUssVUFBUyxVQUFVLEtBQUEsQ0FBUyxHQUNqRCxRQUFRLE1BQU0sbUJBQW1CLFVBQVUsb0RBQW9EO0VBRWpHLE9BQU8sY0FBYyxHQUFHLE1BQU07Q0FDaEM7QUFHSjs7OztBQU9BLFNBQWdCLHNCQUFzQixLQUFLLFdBQVc7Q0FHcEQsSUFBSSxNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsR0FDcEMsSUFBSSxtQkFBbUIsVUFBVSxJQUFJLGdCQUFnQjtBQUV6RDtBQUdBLElBQU0sVUFBVSxDQUFDO0FBRWpCLFNBQWdCLHlCQUF5QixRQUFRO0NBQy9DLFFBQVEsS0FBSztDQUNiLE9BQU9DLGdCQUFrQixPQUFPO0FBQ2xDOzs7Ozs7OztBQ3ZEQSxJQUFNLFFBQVEsRUFDWixjQUFjLEVBQ2hCOzs7QUNHQSxTQUF3QixjQUFjLGVBQWUsR0FJckQsWUFBWSxtQkFBbUIsRUFDN0IsU0FBUyxhQUNYLENBQUMsR0FBRztDQUVGLElBQUksYUFBYSxLQUNmLE9BQU87Q0FFVCxNQUFNLFdBQVcsR0FBRyxjQUFjO0VBRTlCLElBQUksRUFBRSxVQUFVLFVBQVUsSUFDeEIsUUFBUSxNQUFNLG1FQUFtRSxVQUFVLFFBQVE7RUFJdkcsUUFEYSxVQUFVLFdBQVcsSUFBSSxDQUFDLENBQUMsSUFBSSxVQUFBLENBQ2hDLEtBQUksYUFBWTtHQUMxQixNQUFNLFNBQVMsVUFBVSxRQUFRO0dBQ2pDLE9BQU8sT0FBTyxXQUFXLFdBQVcsR0FBRyxPQUFPLE1BQU07RUFDdEQsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ2I7Q0FDQSxRQUFRLE1BQU07Q0FDZCxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZ0NBLFNBQXdCLFlBQVksS0FBSyxRQUFRO0NBRS9DLE1BQU0sUUFBUTtDQUNkLElBQUksTUFBTSxNQUFNO0VBQ2QsSUFBSSxDQUFDLE1BQU0sZUFBZSxRQUFRLE9BQU8sTUFBTSwyQkFBMkIsWUFDeEUsT0FBTyxDQUFDO0VBR1YsSUFBSSxXQUFXLE1BQU0sdUJBQXVCLEdBQUc7RUFDL0MsSUFBSSxhQUFhLEtBQ2YsT0FBTztFQUVULElBQUksU0FBUyxTQUFTLE9BQU8sS0FBSyxTQUFTLFNBQVMsR0FBRyxHQUVyRCxXQUFXLFdBQVcsU0FBUyxRQUFRLFNBQVMsRUFBRSxFQUFFO0VBRXRELE9BQU8sR0FDSixXQUFXLE9BQ2Q7Q0FDRjtDQUNBLElBQUksTUFBTSxRQUFRLFNBQVMsS0FDekIsT0FBTztDQUVULE9BQU8sQ0FBQztBQUNWOzs7QUM5RUEsU0FBU0MsY0FBWSxVQUFVLENBQUMsR0FBRyxHQUFHLE1BQU07Q0FDMUMsTUFBTSxFQUNKLGFBQWEsbUJBQW1CLENBQUMsR0FDakMsU0FBUyxlQUFlLENBQUMsR0FDekIsU0FBUyxjQUNULE9BQU8sYUFBYSxDQUFDLEdBQ3JCLEdBQUcsVUFDRDtDQUNKLE1BQU0sY0FBYyxrQkFBa0IsZ0JBQWdCO0NBQ3RELE1BQU0sVUFBVSxjQUFjLFlBQVk7Q0FDMUMsSUFBSSxXQUFXLFVBQVU7RUFDdkI7RUFDQSxXQUFXO0VBQ1gsWUFBWSxDQUFDO0VBRWIsU0FBUztHQUNQLE1BQU07R0FDTixHQUFHO0VBQ0w7RUFDQTtFQUNBLE9BQU87R0FDTCxHQUFHO0dBQ0gsR0FBRztFQUNMO0NBQ0YsR0FBRyxLQUFLO0NBQ1IsV0FBVyxvQkFBb0IsUUFBUTtDQUN2QyxTQUFTLGNBQWM7Q0FDdkIsV0FBVyxLQUFLLFFBQVEsS0FBSyxhQUFhLFVBQVUsS0FBSyxRQUFRLEdBQUcsUUFBUTtDQUM1RSxTQUFTLG9CQUFvQjtFQUMzQixHQUFHO0VBQ0gsR0FBRyxPQUFPO0NBQ1o7Q0FDQSxTQUFTLGNBQWMsU0FBUyxHQUFHLE9BQU87RUFDeEMsT0FBT0Msd0JBQWdCO0dBQ3JCLElBQUk7R0FDSixPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsU0FBUyxpQkFBaUIsQ0FBQztDQUMzQixPQUFPO0FBQ1Q7OztBQ2hEQSxJQUFNLG9CQUFtQixrQkFBaUI7QUFDMUMsSUFBTSxpQ0FBaUM7Q0FDckMsSUFBSSxXQUFXO0NBQ2YsT0FBTztFQUNMLFVBQVUsV0FBVztHQUNuQixXQUFXO0VBQ2I7RUFDQSxTQUFTLGVBQWU7R0FDdEIsT0FBTyxTQUFTLGFBQWE7RUFDL0I7RUFDQSxRQUFRO0dBQ04sV0FBVztFQUNiO0NBQ0Y7QUFDRjtBQUNBLElBQU0scUJBQXFCLHlCQUF5Qjs7O0FDZHBELElBQWEscUJBQXFCO0NBQ2hDLFFBQVE7Q0FDUixTQUFTO0NBQ1QsV0FBVztDQUNYLFVBQVU7Q0FDVixPQUFPO0NBQ1AsVUFBVTtDQUNWLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsTUFBTTtDQUNOLFVBQVU7Q0FDVixVQUFVO0NBQ1YsVUFBVTtBQUNaO0FBQ0EsU0FBd0IscUJBQXFCLGVBQWUsTUFBTSxvQkFBb0IsT0FBTztDQUMzRixNQUFNLG1CQUFtQixtQkFBbUI7Q0FDNUMsT0FBTyxtQkFBbUIsR0FBRyxrQkFBa0IsR0FBRyxxQkFBcUIsR0FBRyxtQkFBbUIsU0FBUyxhQUFhLEVBQUUsR0FBRztBQUMxSDs7O0FDakJBLFNBQXdCLHVCQUF1QixlQUFlLE9BQU8sb0JBQW9CLE9BQU87Q0FDOUYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsTUFBTSxTQUFRLFNBQVE7RUFDcEIsT0FBTyxRQUFRLHFCQUFxQixlQUFlLE1BQU0saUJBQWlCO0NBQzVFLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7OztBQ05BLFNBQVMseUJBQXlCLFdBQVcsV0FBVyxJQUFJO0NBQzFELE9BQU8sVUFBVSxlQUFlLFVBQVUsUUFBUTtBQUNwRDtBQUNBLFNBQVMsZUFBZSxXQUFXLFdBQVcsYUFBYTtDQUN6RCxNQUFNLGVBQWUseUJBQXlCLFNBQVM7Q0FDdkQsT0FBTyxVQUFVLGdCQUFnQixpQkFBaUIsS0FBSyxHQUFHLFlBQVksR0FBRyxhQUFhLEtBQUs7QUFDN0Y7Ozs7OztBQU9BLFNBQXdCLGVBQWUsV0FBVztDQUNoRCxJQUFJLGFBQWEsTUFDZjtDQUVGLElBQUksT0FBTyxjQUFjLFVBQ3ZCLE9BQU87Q0FFVCxJQUFJLE9BQU8sY0FBYyxZQUN2QixPQUFPLHlCQUF5QixXQUFXLFdBQVc7Q0FJeEQsSUFBSSxPQUFPLGNBQWMsVUFDdkIsUUFBUSxVQUFVLFVBQWxCO0VBQ0UsS0FBS0MsZ0JBQUFBLFlBQ0gsT0FBTyxlQUFlLFdBQVcsVUFBVSxRQUFRLFlBQVk7RUFDakUsS0FBS0MsZ0JBQUFBLE1BQ0gsT0FBTyxlQUFlLFdBQVcsVUFBVSxNQUFNLE1BQU07RUFDekQsU0FDRTtDQUNKO0FBR0o7OztBQ3BDQSxTQUF3QixpQkFBaUIsT0FBTztDQUM5QyxNQUFNLEVBQ0osVUFDQSxHQUFHLFVBQ0Q7Q0FDSixNQUFNLFNBQVM7RUFDYjtFQUNBLE9BQU8seUJBQXlCLEtBQUs7RUFDckMsYUFBYTtDQUNmO0NBR0EsSUFBSSxPQUFPLFVBQVUsT0FDbkIsT0FBTztDQUVULElBQUksVUFDRixTQUFTLFNBQVEsWUFBVztFQUMxQixJQUFJLE9BQU8sUUFBUSxVQUFVLFlBQzNCLFFBQVEsUUFBUSx5QkFBeUIsUUFBUSxLQUFLO0NBRTFELENBQUM7Q0FFSCxPQUFPO0FBQ1Q7OztBQ1hBLElBQWEscUJBQXFCQyxjQUFZO0FBRzlDLFNBQWdCLGtCQUFrQixNQUFNO0NBQ3RDLE9BQU8sU0FBUyxnQkFBZ0IsU0FBUyxXQUFXLFNBQVMsUUFBUSxTQUFTO0FBQ2hGO0FBQ0EsU0FBUyxhQUFhLFlBQVksV0FBVztDQUMzQyxJQUFJLGFBQWEsY0FBYyxPQUFPLGVBQWUsWUFBWSxXQUFXLFVBQVUsQ0FBQyxXQUFXLE9BQU8sV0FBVyxRQUFRLEdBRTFILFdBQVcsU0FBUyxVQUFVLFVBQVUsR0FBRyxPQUFPLFdBQVcsTUFBTSxFQUFFO0NBRXZFLE9BQU87QUFDVDtBQUNBLFNBQVMseUJBQXlCLE1BQU07Q0FDdEMsSUFBSSxDQUFDLE1BQ0gsT0FBTztDQUVULFFBQVEsUUFBUSxXQUFXLE9BQU87QUFDcEM7QUFDQSxTQUFTLFlBQVksT0FBTyxTQUFTLGNBQWM7Q0FDakQsTUFBTSxRQUFRLGNBQWMsTUFBTSxLQUFLLElBQUksZUFBZSxNQUFNLE1BQU0sWUFBWSxNQUFNO0FBQzFGO0FBQ0EsU0FBUyxhQUFhLE9BQU8sT0FBTyxXQUFXO0NBVTdDLE1BQU0sZ0JBQWdCLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0NBQ25FLElBQUksTUFBTSxRQUFRLGFBQWEsR0FDN0IsT0FBTyxjQUFjLFNBQVEsYUFBWSxhQUFhLE9BQU8sVUFBVSxTQUFTLENBQUM7Q0FFbkYsSUFBSSxNQUFNLFFBQVEsZUFBZSxRQUFRLEdBQUc7RUFDMUMsSUFBSTtFQUNKLElBQUksY0FBYyxhQUNoQixZQUFZLFlBQVksYUFBYSxjQUFjLE9BQU8sU0FBUyxJQUFJLGNBQWM7T0FDaEY7R0FDTCxNQUFNLEVBQ0osVUFDQSxHQUFHLGdCQUNEO0dBQ0osWUFBWSxZQUFZLGFBQWFDLHlCQUFnQixXQUFXLEdBQUcsU0FBUyxJQUFJO0VBQ2xGO0VBQ0EsT0FBTyxxQkFBcUIsT0FBTyxjQUFjLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUztDQUNuRjtDQUNBLElBQUksZUFBZSxhQUNqQixPQUFPLFlBQVksYUFBYUEseUJBQWdCLGNBQWMsS0FBSyxHQUFHLFNBQVMsSUFBSSxjQUFjO0NBRW5HLE9BQU8sWUFBWSxhQUFhQSx5QkFBZ0IsYUFBYSxHQUFHLFNBQVMsSUFBSTtBQUMvRTtBQUNBLFNBQVMscUJBQXFCLE9BQU8sVUFBVSxVQUFVLENBQUMsR0FBRyxZQUFZLEtBQUEsR0FBVztDQUNsRixJQUFJO0NBRUosYUFBYSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssR0FBRztFQUN4RCxNQUFNLFVBQVUsU0FBUztFQUN6QixJQUFJLE9BQU8sUUFBUSxVQUFVLFlBQVk7R0FDdkMsZ0JBQWdCO0lBQ2QsR0FBRztJQUNILEdBQUcsTUFBTTtJQUNULFlBQVksTUFBTTtHQUNwQjtHQUNBLElBQUksQ0FBQyxRQUFRLE1BQU0sV0FBVyxHQUM1QjtFQUVKLE9BQ0UsS0FBSyxNQUFNLE9BQU8sUUFBUSxPQUN4QixJQUFJLE1BQU0sU0FBUyxRQUFRLE1BQU0sUUFBUSxNQUFNLGFBQWEsU0FBUyxRQUFRLE1BQU0sTUFDakYsU0FBUztFQUlmLElBQUksT0FBTyxRQUFRLFVBQVUsWUFBWTtHQUN2QyxnQkFBZ0I7SUFDZCxHQUFHO0lBQ0gsR0FBRyxNQUFNO0lBQ1QsWUFBWSxNQUFNO0dBQ3BCO0dBQ0EsUUFBUSxLQUFLLFlBQVksYUFBYUEseUJBQWdCLFFBQVEsTUFBTSxXQUFXLENBQUMsR0FBRyxTQUFTLElBQUksUUFBUSxNQUFNLFdBQVcsQ0FBQztFQUM1SCxPQUNFLFFBQVEsS0FBSyxZQUFZLGFBQWFBLHlCQUFnQixRQUFRLEtBQUssR0FBRyxTQUFTLElBQUksUUFBUSxLQUFLO0NBRXBHO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBd0IsYUFBYSxRQUFRLENBQUMsR0FBRztDQUMvQyxNQUFNLEVBQ0osU0FDQSxlQUFlLG9CQUNmLHdCQUF3QixtQkFDeEIsd0JBQXdCLHNCQUN0QjtDQUNKLFNBQVMsaUJBQWlCLE9BQU87RUFDL0IsWUFBWSxPQUFPLFNBQVMsWUFBWTtDQUMxQztDQUNBLE1BQU0sVUFBVSxLQUFLLGVBQWUsQ0FBQyxNQUFNO0VBR3pDLHNCQUFhLE1BQUssV0FBVSxPQUFPLFFBQU8sVUFBUyxVQUFVQyx1QkFBZSxDQUFDO0VBQzdFLE1BQU0sRUFDSixNQUFNLGVBQ04sTUFBTSxlQUNOLHNCQUFzQiwyQkFDdEIsUUFBUSxhQUdSLG9CQUFvQix5QkFBeUIscUJBQXFCLGFBQWEsQ0FBQyxHQUNoRixHQUFHLFlBQ0Q7RUFDSixNQUFNLFlBQVksaUJBQWlCLGNBQWMsV0FBVyxLQUFLLEtBQUssQ0FBQyxDQUFDLGdCQUFnQixlQUFlO0VBR3ZHLE1BQU0sdUJBQXVCLDhCQUE4QixLQUFBLElBQVksNEJBR3ZFLGlCQUFpQixrQkFBa0IsVUFBVSxrQkFBa0IsVUFBVTtFQUN6RSxNQUFNLFNBQVMsZUFBZTtFQUM5QixJQUFJLDBCQUEwQjtFQUk5QixJQUFJLGtCQUFrQixVQUFVLGtCQUFrQixRQUNoRCwwQkFBMEI7T0FDckIsSUFBSSxlQUVULDBCQUEwQjtPQUNyQixJQUFJLFlBQVksR0FBRyxHQUV4QiwwQkFBMEIsS0FBQTtFQUU1QixNQUFNLHdCQUF3QkMsU0FBbUIsS0FBSztHQUNwRCxtQkFBbUI7R0FDbkIsT0FBTyxvQkFBb0IsZUFBZSxhQUFhO0dBQ3ZELEdBQUc7RUFDTCxDQUFDO0VBQ0QsTUFBTSxrQkFBaUIsVUFBUztHQU05QixJQUFJLE1BQU0sbUJBQW1CLE9BQzNCLE9BQU87R0FFVCxJQUFJLE9BQU8sVUFBVSxZQUNuQixPQUFPLFNBQVMsdUJBQXVCLE9BQU87SUFDNUMsT0FBTyxhQUFhLE9BQU8sT0FBTyxNQUFNLE1BQU0sbUJBQW1CLFlBQVksS0FBQSxDQUFTO0dBQ3hGO0dBRUYsSUFBSSxjQUFjLEtBQUssR0FBRztJQUN4QixNQUFNLGFBQWEsaUJBQWlCLEtBQUs7SUFDekMsT0FBTyxTQUFTLHFCQUFxQixPQUFPO0tBQzFDLElBQUksQ0FBQyxXQUFXLFVBQ2QsT0FBTyxNQUFNLE1BQU0sbUJBQW1CLGFBQWEsV0FBVyxPQUFPLFNBQVMsSUFBSSxXQUFXO0tBRS9GLE9BQU8sYUFBYSxPQUFPLFlBQVksTUFBTSxNQUFNLG1CQUFtQixZQUFZLEtBQUEsQ0FBUztJQUM3RjtHQUNGO0dBQ0EsT0FBTztFQUNUO0VBQ0EsTUFBTSxxQkFBcUIsR0FBRyxxQkFBcUI7R0FDakQsTUFBTSxrQkFBa0IsQ0FBQztHQUN6QixNQUFNLGtCQUFrQixpQkFBaUIsSUFBSSxjQUFjO0dBQzNELE1BQU0sa0JBQWtCLENBQUM7R0FJekIsZ0JBQWdCLEtBQUssZ0JBQWdCO0dBQ3JDLElBQUksaUJBQWlCLG1CQUNuQixnQkFBZ0IsS0FBSyxTQUFTLG9CQUFvQixPQUFPO0lBRXZELE1BQU0saUJBRFEsTUFBTSxNQUNTLGFBQWEsY0FBYyxFQUFFO0lBQzFELElBQUksQ0FBQyxnQkFDSCxPQUFPO0lBRVQsTUFBTSx5QkFBeUIsQ0FBQztJQUloQyxLQUFLLE1BQU0sV0FBVyxnQkFDcEIsdUJBQXVCLFdBQVcsYUFBYSxPQUFPLGVBQWUsVUFBVSxNQUFNLE1BQU0sbUJBQW1CLFVBQVUsS0FBQSxDQUFTO0lBRW5JLE9BQU8sa0JBQWtCLE9BQU8sc0JBQXNCO0dBQ3hELENBQUM7R0FFSCxJQUFJLGlCQUFpQixDQUFDLHNCQUNwQixnQkFBZ0IsS0FBSyxTQUFTLG1CQUFtQixPQUFPO0lBRXRELE1BQU0sZ0JBRFEsTUFBTSxPQUNTLGFBQWEsY0FBYyxFQUFFO0lBQzFELElBQUksQ0FBQyxlQUNILE9BQU87SUFFVCxPQUFPLHFCQUFxQixPQUFPLGVBQWUsQ0FBQyxHQUFHLE1BQU0sTUFBTSxtQkFBbUIsVUFBVSxLQUFBLENBQVM7R0FDMUcsQ0FBQztHQUVILElBQUksQ0FBQyxRQUNILGdCQUFnQixLQUFLRCx1QkFBZTtHQUt0QyxJQUFJLE1BQU0sUUFBUSxnQkFBZ0IsRUFBRSxHQUFHO0lBQ3JDLE1BQU0sZUFBZSxnQkFBZ0IsTUFBTTtJQUkzQyxNQUFNLG1CQUFtQixJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRTtJQUNsRSxNQUFNLG1CQUFtQixJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRTtJQUNsRSxJQUFJO0lBR0YsZ0JBQWdCO0tBQUMsR0FBRztLQUFrQixHQUFHO0tBQWMsR0FBRztJQUFnQjtJQUMxRSxjQUFjLE1BQU07S0FBQyxHQUFHO0tBQWtCLEdBQUcsYUFBYTtLQUFLLEdBQUc7SUFBZ0I7SUFJcEYsZ0JBQWdCLFFBQVEsYUFBYTtHQUN2QztHQUNBLE1BQU0sY0FBYztJQUFDLEdBQUc7SUFBaUIsR0FBRztJQUFpQixHQUFHO0dBQWU7R0FDL0UsTUFBTSxZQUFZLHNCQUFzQixHQUFHLFdBQVc7R0FDdEQsSUFBSSxJQUFJLFNBQ04sVUFBVSxVQUFVLElBQUk7R0FHeEIsVUFBVSxjQUFjLG9CQUFvQixlQUFlLGVBQWUsR0FBRztHQUUvRSxPQUFPO0VBQ1Q7RUFDQSxJQUFJLHNCQUFzQixZQUN4QixrQkFBa0IsYUFBYSxzQkFBc0I7RUFFdkQsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsZUFBZSxlQUFlLEtBQUs7Q0FDOUQsSUFBSSxlQUNGLE9BQU8sR0FBRyxnQkFBZ0IsV0FBVyxpQkFBaUIsRUFBRTtDQUUxRCxPQUFPLFVBQVUsZUFBZSxHQUFHLEVBQUU7QUFDdkM7QUFDQSxTQUFTLG9CQUFvQixlQUFlLGVBQWU7Q0FDekQsSUFBSTtDQUVGLElBQUksZUFHRixRQUFRLEdBQUcsY0FBYyxHQUFHLHFCQUFxQixpQkFBaUIsTUFBTTtDQUc1RSxPQUFPO0FBQ1Q7QUFHQSxTQUFTLFlBQVksS0FBSztDQUN4QixPQUFPLE9BQU8sUUFBUSxZQUl0QixJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQ3RCO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUTtDQUNwQyxJQUFJLENBQUMsUUFDSCxPQUFPO0NBRVQsT0FBTyxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDO0FBQ3hEOzs7Ozs7Ozs7Ozs7QUMvUUEsU0FBd0IsYUFBYSxjQUFjLE9BQU8seUJBQXlCLE9BQU87Q0FDeEYsTUFBTSxTQUFTLEVBQ2IsR0FBRyxNQUNMO0NBQ0EsS0FBSyxNQUFNLE9BQU8sY0FDaEIsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLGNBQWMsR0FBRyxHQUFHO0VBQzNELE1BQU0sV0FBVztFQUNqQixJQUFJLGFBQWEsZ0JBQWdCLGFBQWEsU0FDNUMsT0FBTyxZQUFZO0dBQ2pCLEdBQUcsYUFBYTtHQUNoQixHQUFHLE9BQU87RUFDWjtPQUNLLElBQUksYUFBYSxxQkFBcUIsYUFBYSxhQUFhO0dBQ3JFLE1BQU0sbUJBQW1CLGFBQWE7R0FDdEMsTUFBTSxZQUFZLE1BQU07R0FDeEIsSUFBSSxDQUFDLFdBQ0gsT0FBTyxZQUFZLG9CQUFvQixDQUFDO1FBQ25DLElBQUksQ0FBQyxrQkFDVixPQUFPLFlBQVk7UUFDZDtJQUNMLE9BQU8sWUFBWSxFQUNqQixHQUFHLFVBQ0w7SUFDQSxLQUFLLE1BQU0sV0FBVyxrQkFDcEIsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLGtCQUFrQixPQUFPLEdBQUc7S0FDbkUsTUFBTSxlQUFlO0tBQ3JCLE9BQU8sU0FBUyxDQUFDLGdCQUFnQixhQUFhLGlCQUFpQixlQUFlLFVBQVUsZUFBZSxzQkFBc0I7SUFDL0g7R0FFSjtFQUNGLE9BQU8sSUFBSSxhQUFhLGVBQWUsMEJBQTBCLE1BQU0sY0FBYyxLQUFBLEdBQ25GLE9BQU8sWUFBWSxLQUFLLGNBQWMsV0FBVyxPQUFPLFNBQVM7T0FDNUQsSUFBSSxhQUFhLFdBQVcsMEJBQTBCLE1BQU0sT0FDakUsT0FBTyxRQUFRO0dBQ2IsR0FBRyxjQUFjO0dBQ2pCLEdBQUcsT0FBTztFQUNaO09BQ0ssSUFBSSxPQUFPLGNBQWMsS0FBQSxHQUM5QixPQUFPLFlBQVksYUFBYTtDQUVwQztDQUVGLE9BQU87QUFDVDs7O0FDdERBLFNBQVMsTUFBTSxLQUFLLE1BQU0sT0FBTyxrQkFBa0IsTUFBTSxPQUFPLGtCQUFrQjtDQUNoRixPQUFPLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQztBQUN6Qzs7Ozs7Ozs7OztBQ1NBLFNBQVMsYUFBYSxPQUFPLE1BQU0sR0FBRyxNQUFNLEdBQUc7Q0FFM0MsSUFBSSxRQUFRLE9BQU8sUUFBUSxLQUN6QixRQUFRLE1BQU0sMkJBQTJCLE1BQU0sb0JBQW9CLElBQUksSUFBSSxJQUFJLEdBQUc7Q0FHdEYsT0FBTyxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQzlCOzs7Ozs7QUFPQSxTQUFnQixTQUFTLE9BQU87Q0FDOUIsUUFBUSxNQUFNLE1BQU0sQ0FBQztDQUNyQixNQUFNLEtBQUssSUFBSSxPQUFPLE9BQU8sTUFBTSxVQUFVLElBQUksSUFBSSxFQUFFLElBQUksR0FBRztDQUM5RCxJQUFJLFNBQVMsTUFBTSxNQUFNLEVBQUU7Q0FDM0IsSUFBSSxVQUFVLE9BQU8sRUFBRSxDQUFDLFdBQVcsR0FDakMsU0FBUyxPQUFPLEtBQUksTUFBSyxJQUFJLENBQUM7Q0FHOUIsSUFBSSxNQUFNLFdBQVcsTUFBTSxLQUFLLENBQUMsQ0FBQyxRQUNoQyxRQUFRLE1BQU0sb0JBQW9CLE1BQU0sZ0ZBQWdGO0NBRzVILE9BQU8sU0FBUyxNQUFNLE9BQU8sV0FBVyxJQUFJLE1BQU0sR0FBRyxHQUFHLE9BQU8sS0FBSyxHQUFHLFVBQVU7RUFDL0UsT0FBTyxRQUFRLElBQUksU0FBUyxHQUFHLEVBQUUsSUFBSSxLQUFLLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxNQUFNLEdBQUksSUFBSTtDQUNsRixDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxLQUFLO0FBQ3JCO0FBQ0EsU0FBUyxTQUFTLEtBQUs7Q0FDckIsTUFBTSxNQUFNLElBQUksU0FBUyxFQUFFO0NBQzNCLE9BQU8sSUFBSSxXQUFXLElBQUksSUFBSSxRQUFRO0FBQ3hDOzs7Ozs7OztBQVNBLFNBQWdCLGVBQWUsT0FBTztDQUVwQyxJQUFJLE1BQU0sTUFDUixPQUFPO0NBRVQsSUFBSSxNQUFNLE9BQU8sQ0FBQyxNQUFNLEtBQ3RCLE9BQU8sZUFBZSxTQUFTLEtBQUssQ0FBQztDQUV2QyxNQUFNLFNBQVMsTUFBTSxRQUFRLEdBQUc7Q0FDaEMsTUFBTSxPQUFPLE1BQU0sVUFBVSxHQUFHLE1BQU07Q0FDdEMsSUFBSSxDQUFDO0VBQUM7RUFBTztFQUFRO0VBQU87RUFBUTtDQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksR0FDeEQsTUFBTSxJQUFJLE1BQThDLHNCQUFzQixNQUFNLHNHQUEySTtDQUVqTyxJQUFJLFNBQVMsTUFBTSxVQUFVLFNBQVMsR0FBRyxNQUFNLFNBQVMsQ0FBQztDQUN6RCxJQUFJO0NBQ0osSUFBSSxTQUFTLFNBQVM7RUFDcEIsU0FBUyxPQUFPLE1BQU0sR0FBRztFQUN6QixhQUFhLE9BQU8sTUFBTTtFQUMxQixJQUFJLE9BQU8sV0FBVyxLQUFLLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQ2pELE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUM7RUFFL0IsSUFBSSxDQUFDO0dBQUM7R0FBUTtHQUFjO0dBQVc7R0FBZ0I7RUFBVSxDQUFDLENBQUMsU0FBUyxVQUFVLEdBQ3BGLE1BQU0sSUFBSSxNQUE4QyxzQkFBc0IsV0FBVyw4R0FBeUo7Q0FFdFAsT0FDRSxTQUFTLE9BQU8sTUFBTSxHQUFHO0NBRTNCLFNBQVMsT0FBTyxLQUFJLFVBQVMsV0FBVyxLQUFLLENBQUM7Q0FDOUMsT0FBTztFQUNMO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7Ozs7Ozs7QUFRQSxJQUFhLGdCQUFlLFVBQVM7Q0FDbkMsTUFBTSxrQkFBa0IsZUFBZSxLQUFLO0NBQzVDLE9BQU8sZ0JBQWdCLE9BQU8sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxRQUFRLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDM0k7QUFDQSxJQUFhLDRCQUE0QixPQUFPLFlBQVk7Q0FDMUQsSUFBSTtFQUNGLE9BQU8sYUFBYSxLQUFLO0NBQzNCLFNBQVMsT0FBTztFQUNkLElBQUksV0FBVyxNQUNiLFFBQVEsS0FBSyxPQUFPO0VBRXRCLE9BQU87Q0FDVDtBQUNGOzs7Ozs7OztBQVNBLFNBQWdCLGVBQWUsT0FBTztDQUNwQyxNQUFNLEVBQ0osTUFDQSxlQUNFO0NBQ0osSUFBSSxFQUNGLFdBQ0U7Q0FDSixJQUFJLEtBQUssU0FBUyxLQUFLLEdBRXJCLFNBQVMsT0FBTyxLQUFLLEdBQUcsTUFBTSxJQUFJLElBQUksU0FBUyxHQUFHLEVBQUUsSUFBSSxDQUFDO01BQ3BELElBQUksS0FBSyxTQUFTLEtBQUssR0FBRztFQUMvQixPQUFPLEtBQUssR0FBRyxPQUFPLEdBQUc7RUFDekIsT0FBTyxLQUFLLEdBQUcsT0FBTyxHQUFHO0NBQzNCO0NBQ0EsSUFBSSxLQUFLLFNBQVMsT0FBTyxHQUN2QixTQUFTLEdBQUcsV0FBVyxHQUFHLE9BQU8sS0FBSyxHQUFHO01BRXpDLFNBQVMsR0FBRyxPQUFPLEtBQUssSUFBSTtDQUU5QixPQUFPLEdBQUcsS0FBSyxHQUFHLE9BQU87QUFDM0I7Ozs7OztBQU9BLFNBQWdCLFNBQVMsT0FBTztDQUU5QixJQUFJLE1BQU0sV0FBVyxHQUFHLEdBQ3RCLE9BQU87Q0FFVCxNQUFNLEVBQ0osV0FDRSxlQUFlLEtBQUs7Q0FDeEIsT0FBTyxJQUFJLE9BQU8sS0FBSyxHQUFHLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO0FBQ3RGOzs7Ozs7QUFPQSxTQUFnQixTQUFTLE9BQU87Q0FDOUIsUUFBUSxlQUFlLEtBQUs7Q0FDNUIsTUFBTSxFQUNKLFdBQ0U7Q0FDSixNQUFNLElBQUksT0FBTztDQUNqQixNQUFNLElBQUksT0FBTyxLQUFLO0NBQ3RCLE1BQU0sSUFBSSxPQUFPLEtBQUs7Q0FDdEIsTUFBTSxJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDO0NBQy9CLE1BQU0sS0FBSyxHQUFHLEtBQUssSUFBSSxJQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFO0NBQ3RGLElBQUksT0FBTztDQUNYLE1BQU0sTUFBTTtFQUFDLEtBQUssTUFBTSxFQUFFLENBQUMsSUFBSSxHQUFHO0VBQUcsS0FBSyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEdBQUc7RUFBRyxLQUFLLE1BQU0sRUFBRSxDQUFDLElBQUksR0FBRztDQUFDO0NBQ25GLElBQUksTUFBTSxTQUFTLFFBQVE7RUFDekIsUUFBUTtFQUNSLElBQUksS0FBSyxPQUFPLEVBQUU7Q0FDcEI7Q0FDQSxPQUFPLGVBQWU7RUFDcEI7RUFDQSxRQUFRO0NBQ1YsQ0FBQztBQUNIOzs7Ozs7Ozs7QUFTQSxTQUFnQixhQUFhLE9BQU87Q0FDbEMsUUFBUSxlQUFlLEtBQUs7Q0FDNUIsSUFBSSxNQUFNLE1BQU0sU0FBUyxTQUFTLE1BQU0sU0FBUyxTQUFTLGVBQWUsU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsTUFBTTtDQUN6RyxNQUFNLElBQUksS0FBSSxRQUFPO0VBQ25CLElBQUksTUFBTSxTQUFTLFNBQ2pCLE9BQU87RUFFVCxPQUFPLE9BQU8sU0FBVSxNQUFNLFVBQVUsTUFBTSxRQUFTLFVBQVU7Q0FDbkUsQ0FBQztDQUdELE9BQU8sUUFBUSxRQUFTLElBQUksS0FBSyxRQUFTLElBQUksS0FBSyxRQUFTLElBQUksR0FBQSxDQUFJLFFBQVEsQ0FBQyxDQUFDO0FBQ2hGOzs7Ozs7Ozs7QUFVQSxTQUFnQixpQkFBaUIsWUFBWSxZQUFZO0NBQ3ZELE1BQU0sT0FBTyxhQUFhLFVBQVU7Q0FDcEMsTUFBTSxPQUFPLGFBQWEsVUFBVTtDQUNwQyxRQUFRLEtBQUssSUFBSSxNQUFNLElBQUksSUFBSSxRQUFTLEtBQUssSUFBSSxNQUFNLElBQUksSUFBSTtBQUNqRTs7Ozs7Ozs7QUFTQSxTQUFnQixNQUFNLE9BQU8sT0FBTztDQUNsQyxRQUFRLGVBQWUsS0FBSztDQUM1QixRQUFRLGFBQWEsS0FBSztDQUMxQixJQUFJLE1BQU0sU0FBUyxTQUFTLE1BQU0sU0FBUyxPQUN6QyxNQUFNLFFBQVE7Q0FFaEIsSUFBSSxNQUFNLFNBQVMsU0FDakIsTUFBTSxPQUFPLEtBQUssSUFBSTtNQUV0QixNQUFNLE9BQU8sS0FBSztDQUVwQixPQUFPLGVBQWUsS0FBSztBQUM3QjtBQUNBLFNBQWdCLGtCQUFrQixPQUFPLE9BQU8sU0FBUztDQUN2RCxJQUFJO0VBQ0YsT0FBTyxNQUFNLE9BQU8sS0FBSztDQUMzQixTQUFTLE9BQU87RUFDZCxJQUFJLFdBQVcsTUFDYixRQUFRLEtBQUssT0FBTztFQUV0QixPQUFPO0NBQ1Q7QUFDRjs7Ozs7OztBQVFBLFNBQWdCLE9BQU8sT0FBTyxhQUFhO0NBQ3pDLFFBQVEsZUFBZSxLQUFLO0NBQzVCLGNBQWMsYUFBYSxXQUFXO0NBQ3RDLElBQUksTUFBTSxLQUFLLFNBQVMsS0FBSyxHQUMzQixNQUFNLE9BQU8sTUFBTSxJQUFJO01BQ2xCLElBQUksTUFBTSxLQUFLLFNBQVMsS0FBSyxLQUFLLE1BQU0sS0FBSyxTQUFTLE9BQU8sR0FDbEUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUMxQixNQUFNLE9BQU8sTUFBTSxJQUFJO0NBRzNCLE9BQU8sZUFBZSxLQUFLO0FBQzdCO0FBQ0EsU0FBZ0IsbUJBQW1CLE9BQU8sYUFBYSxTQUFTO0NBQzlELElBQUk7RUFDRixPQUFPLE9BQU8sT0FBTyxXQUFXO0NBQ2xDLFNBQVMsT0FBTztFQUNkLElBQUksV0FBVyxNQUNiLFFBQVEsS0FBSyxPQUFPO0VBRXRCLE9BQU87Q0FDVDtBQUNGOzs7Ozs7O0FBUUEsU0FBZ0IsUUFBUSxPQUFPLGFBQWE7Q0FDMUMsUUFBUSxlQUFlLEtBQUs7Q0FDNUIsY0FBYyxhQUFhLFdBQVc7Q0FDdEMsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLEdBQzNCLE1BQU0sT0FBTyxPQUFPLE1BQU0sTUFBTSxPQUFPLE1BQU07TUFDeEMsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLEdBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FDMUIsTUFBTSxPQUFPLE9BQU8sTUFBTSxNQUFNLE9BQU8sTUFBTTtNQUUxQyxJQUFJLE1BQU0sS0FBSyxTQUFTLE9BQU8sR0FDcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUMxQixNQUFNLE9BQU8sT0FBTyxJQUFJLE1BQU0sT0FBTyxNQUFNO0NBRy9DLE9BQU8sZUFBZSxLQUFLO0FBQzdCO0FBQ0EsU0FBZ0Isb0JBQW9CLE9BQU8sYUFBYSxTQUFTO0NBQy9ELElBQUk7RUFDRixPQUFPLFFBQVEsT0FBTyxXQUFXO0NBQ25DLFNBQVMsT0FBTztFQUNkLElBQUksV0FBVyxNQUNiLFFBQVEsS0FBSyxPQUFPO0VBRXRCLE9BQU87Q0FDVDtBQUNGOzs7Ozs7OztBQVNBLFNBQWdCLFVBQVUsT0FBTyxjQUFjLEtBQU07Q0FDbkQsT0FBTyxhQUFhLEtBQUssSUFBSSxLQUFNLE9BQU8sT0FBTyxXQUFXLElBQUksUUFBUSxPQUFPLFdBQVc7QUFDNUY7QUFDQSxTQUFnQixzQkFBc0IsT0FBTyxhQUFhLFNBQVM7Q0FDakUsSUFBSTtFQUNGLE9BQU8sVUFBVSxPQUFPLFdBQVc7Q0FDckMsU0FBUyxPQUFPO0VBQ2QsSUFBSSxXQUFXLE1BQ2IsUUFBUSxLQUFLLE9BQU87RUFFdEIsT0FBTztDQUNUO0FBQ0Y7OztBQ3BVQSxJQUFNLGFBQTBCLDJCQUFNLGNBQWM7QUFDcEQsU0FBUyxZQUFZLEVBQ25CLE9BQ0EsR0FBRyxTQUNGO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxXQUFXLFVBQVU7RUFDNUMsT0FBTyxTQUFTO0VBQ2hCLEdBQUc7Q0FDTCxDQUFDO0FBQ0g7QUFDd0MsWUFBWSxZQUFZO0NBQzlELFVBQVVFLGtCQUFBQSxRQUFVO0NBQ3BCLE9BQU9BLGtCQUFBQSxRQUFVO0FBQ25CO0FBQ0EsSUFBYSxlQUFlO0NBRTFCLE9BQUEsYUFEb0IsV0FBVyxVQUNwQixLQUFLO0FBQ2xCOzs7QUNoQkEsSUFBTSxlQUE0QiwyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUMvRCxTQUFTQyx1QkFBcUIsRUFDNUIsT0FDQSxZQUNDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxhQUFhLFVBQVU7RUFDdkM7RUFDRztDQUNaLENBQUM7QUFDSDtBQUN3Qyx1QkFBcUIsWUFBbUM7Ozs7Q0FROUYsVUFBVUMsa0JBQUFBLFFBQVU7Ozs7Q0FJcEIsT0FBT0Esa0JBQUFBLFFBQVU7QUFDbkI7QUFDQSxTQUFTLGNBQWMsUUFBUTtDQUM3QixNQUFNLEVBQ0osT0FDQSxNQUNBLFVBQ0U7Q0FDSixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sY0FBYyxDQUFDLE1BQU0sV0FBVyxPQUNuRCxPQUFPO0NBRVQsTUFBTSxTQUFTLE1BQU0sV0FBVztDQUNoQyxJQUFJLE9BQU8sY0FFVCxPQUFPLGFBQWEsT0FBTyxjQUFjLE9BQU8sTUFBTSxXQUFXLHNCQUFzQjtDQUV6RixJQUFJLENBQUMsT0FBTyxrQkFBa0IsQ0FBQyxPQUFPLFVBRXBDLE9BQU8sYUFBYSxRQUFRLE9BQU8sTUFBTSxXQUFXLHNCQUFzQjtDQUU1RSxPQUFPO0FBQ1Q7QUFDQSxTQUFnQkMsa0JBQWdCLEVBQzlCLE9BQ0EsUUFDQztDQUVELE9BQU8sY0FBYztFQUNuQjtFQUNBO0VBQ0EsT0FBTyxFQUNMLFlBQUEsYUFMYyxXQUFXLFlBS1gsRUFDaEI7Q0FDRixDQUFDO0FBQ0g7OztBQ3hEQSxJQUFNLE1BQU0sRUFDVixPQUFPLEtBQUEsRUFDVDs7Ozs7QUFNQSxTQUF3QixtQkFBbUIsU0FBUztDQUNsRCxJQUFJO0NBQ0osSUFBSTtDQUNKLE9BQU8sU0FBUyxjQUFjLE9BQU87RUFDbkMsSUFBSSxRQUFRO0VBQ1osSUFBSSxVQUFVLEtBQUEsS0FBYSxNQUFNLFVBQVUsV0FBVztHQUNwRCxJQUFJLFFBQVEsTUFBTTtHQUNsQixRQUFRLGlCQUFpQixRQUFRLEdBQUcsQ0FBQztHQUNyQyxZQUFZO0dBQ1osWUFBWSxNQUFNO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7Ozs7Ozs7QUN2QkEsU0FBd0JDLGtCQUFnQixTQUFTLElBQUk7Q0FDbkQsU0FBUyxVQUFVLEdBQUcsTUFBTTtFQUMxQixJQUFJLENBQUMsS0FBSyxRQUNSLE9BQU87RUFFVCxNQUFNLFFBQVEsS0FBSztFQUNuQixJQUFJLE9BQU8sVUFBVSxZQUFZLENBQUMsTUFBTSxNQUFNLDZHQUE2RyxHQUN6SixPQUFPLFdBQVcsU0FBUyxHQUFHLE9BQU8sS0FBSyxLQUFLLFFBQVEsVUFBVSxHQUFHLEtBQUssTUFBTSxDQUFDLENBQUMsRUFBRTtFQUVyRixPQUFPLEtBQUs7Q0FDZDtDQUdBLE1BQU0sYUFBYSxPQUFPLEdBQUcsY0FBYztFQUN6QyxPQUFPLFNBQVMsU0FBUyxHQUFHLE9BQU8sS0FBSyxLQUFLLFFBQVEsVUFBVSxHQUFHLFNBQVMsRUFBRTtDQUMvRTtDQUNBLE9BQU87QUFDVDs7O0FDckJBLElBQU0seUNBQXlCLElBQUksSUFBSTtDQUFDO0NBQWE7Q0FBZTtBQUFXLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CaEYsSUFBYSxvQkFBb0IsS0FBSyxNQUFNLE9BQU8sWUFBWSxDQUFDLE1BQU07Q0FDcEUsSUFBSSxPQUFPO0NBQ1gsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssUUFBUSxTQUFTLEdBQUc7RUFDbkQsTUFBTSxJQUFJLEtBQUs7RUFHZixJQUFJLHVCQUF1QixJQUFJLENBQUMsR0FDOUI7RUFFRixJQUFJLFVBQVUsS0FBSyxTQUFTO09BQ3RCLE1BQU0sUUFBUSxJQUFJLEdBQ3BCLEtBQUssT0FBTyxDQUFDLEtBQUs7UUFDYixJQUFJLFFBQVEsT0FBTyxTQUFTLFVBQ2pDLEtBQUssS0FBSztFQUFBLE9BRVAsSUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVO0dBQzNDLElBQUksQ0FBQyxLQUFLLElBQ1IsS0FBSyxLQUFLLFVBQVUsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7R0FFMUMsT0FBTyxLQUFLO0VBQ2Q7Q0FDRjtBQUNGOzs7Ozs7Ozs7Ozs7QUFhQSxJQUFhLGtCQUFrQixLQUFLLFVBQVUsb0JBQW9CO0NBQ2hFLFNBQVMsUUFBUSxRQUFRLGFBQWEsQ0FBQyxHQUFHLFlBQVksQ0FBQyxHQUFHO0VBQ3hELE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO0dBQy9DLElBQUksQ0FBQyxtQkFBbUIsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxZQUFZLEdBQUcsQ0FBQztRQUMxRSxVQUFVLEtBQUEsS0FBYSxVQUFVLE1BQ25DLElBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FDM0QsUUFBUSxPQUFPLENBQUMsR0FBRyxZQUFZLEdBQUcsR0FBRyxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxXQUFXLEdBQUcsSUFBSSxTQUFTO1NBRTNGLFNBQVMsQ0FBQyxHQUFHLFlBQVksR0FBRyxHQUFHLE9BQU8sU0FBUztHQUFBO0VBSXZELENBQUM7Q0FDSDtDQUNBLFFBQVEsR0FBRztBQUNiO0FBQ0EsSUFBTSxlQUFlLE1BQU0sVUFBVTtDQUNuQyxJQUFJLE9BQU8sVUFBVSxVQUFVO0VBQzdCLElBQUk7R0FBQztHQUFjO0dBQWM7R0FBVztFQUFRLENBQUMsQ0FBQyxNQUFLLFNBQVEsS0FBSyxTQUFTLElBQUksQ0FBQyxHQUVwRixPQUFPO0VBR1QsSUFEZ0IsS0FBSyxLQUFLLFNBQVMsRUFDeEIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLFNBQVMsR0FFMUMsT0FBTztFQUVULE9BQU8sR0FBRyxNQUFNO0NBQ2xCO0NBQ0EsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXdCQSxTQUF3QixjQUFjLE9BQU8sU0FBUztDQUNwRCxNQUFNLEVBQ0osUUFDQSw0QkFDRSxXQUFXLENBQUM7Q0FDaEIsTUFBTSxNQUFNLENBQUM7Q0FDYixNQUFNLE9BQU8sQ0FBQztDQUNkLE1BQU0sbUJBQW1CLENBQUM7Q0FDMUIsZUFBZSxRQUFRLE1BQU0sT0FBTyxjQUFjO0VBQ2hELElBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVO09BQzVDLENBQUMsMkJBQTJCLENBQUMsd0JBQXdCLE1BQU0sS0FBSyxHQUFHO0lBRXJFLE1BQU0sU0FBUyxLQUFLLFNBQVMsR0FBRyxPQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBRztJQUM5RCxNQUFNLGdCQUFnQixZQUFZLE1BQU0sS0FBSztJQUM3QyxPQUFPLE9BQU8sS0FBSyxHQUNoQixTQUFTLGNBQ1osQ0FBQztJQUNELGlCQUFpQixNQUFNLE1BQU0sT0FBTyxPQUFPLElBQUksU0FBUztJQUN4RCxpQkFBaUIsa0JBQWtCLE1BQU0sT0FBTyxPQUFPLElBQUksY0FBYyxJQUFJLFNBQVM7R0FDeEY7O0NBRUosSUFBRyxTQUFRLEtBQUssT0FBTyxNQUN2QjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGOzs7QUN0SUEsU0FBUyxlQUFlLE9BQU8sZUFBZSxDQUFDLEdBQUc7Q0FDaEQsTUFBTSxFQUNKLGNBQWMsb0JBQ2QsdUJBQ0EscUJBQXFCLFVBQ3JCLHVCQUNFO0NBRUosTUFBTSxFQUNKLGVBQWUsQ0FBQyxHQUNoQixZQUNBLHFCQUFxQixTQUNyQixHQUFHLGVBQ0Q7Q0FDSixNQUFNLEVBQ0osTUFBTSxVQUNOLEtBQUssU0FDTCxrQkFBa0IseUJBQ2hCLGNBQWMsWUFBWSxZQUFZO0NBQzFDLElBQUksWUFBWTtDQUNoQixNQUFNLGtCQUFrQixDQUFDO0NBQ3pCLE1BQU0sR0FDSCxxQkFBcUIsZUFDdEIsR0FBRyxzQkFDRDtDQUNKLE9BQU8sUUFBUSxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxZQUFZO0VBQ2pFLE1BQU0sRUFDSixNQUNBLEtBQ0EscUJBQ0UsY0FBYyxRQUFRLFlBQVk7RUFDdEMsWUFBWSxVQUFVLFdBQVcsZ0JBQWdCO0VBQ2pELGdCQUFnQixPQUFPO0dBQ3JCO0dBQ0E7RUFDRjtDQUNGLENBQUM7Q0FDRCxJQUFJLGVBQWU7RUFFakIsTUFBTSxFQUNKLEtBQ0EsTUFDQSxxQkFDRSxjQUFjLGVBQWUsWUFBWTtFQUM3QyxZQUFZLFVBQVUsV0FBVyxnQkFBZ0I7RUFDakQsZ0JBQWdCLHNCQUFzQjtHQUNwQztHQUNBO0VBQ0Y7Q0FDRjtDQUNBLFNBQVMsbUJBQW1CLGFBQWEsV0FBVztFQUNsRCxJQUFJLE9BQU87RUFDWCxJQUFJLGFBQWEsU0FDZixPQUFPO0VBRVQsSUFBSSxhQUFhLFFBQ2YsT0FBTztFQUVULElBQUksVUFBVSxXQUFXLE9BQU8sS0FBSyxDQUFDLFNBQVMsU0FBUyxJQUFJLEdBRTFELE9BQU8sSUFBSSxTQUFTO0VBRXRCLElBQUksYUFBYTtHQUNmLElBQUksU0FBUyxTQUFTO0lBQ3BCLElBQUksTUFBTSx1QkFBdUIsYUFDL0IsT0FBTztJQUdULE9BQU8sR0FDSixpQ0FGVSxhQUFhLFlBQVksRUFBRSxTQUFTLFFBQVEsWUFFaEIsS0FBSyxFQUMxQyxTQUFTLFVBQ1gsRUFDRjtHQUNGO0dBQ0EsSUFBSSxNQUFNO0lBQ1IsSUFBSSxNQUFNLHVCQUF1QixhQUMvQixPQUFPLFVBQVUsS0FBSyxRQUFRLE1BQU0sT0FBTyxXQUFXLENBQUM7SUFFekQsT0FBTyxLQUFLLFFBQVEsTUFBTSxPQUFPLFdBQVcsQ0FBQztHQUMvQztFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSwwQkFBMEI7RUFDOUIsSUFBSSxPQUFPLEVBQ1QsR0FBRyxTQUNMO0VBQ0EsT0FBTyxRQUFRLGVBQWUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxFQUMxQyxNQUFNLGtCQUNEO0dBQ0wsT0FBTyxVQUFVLE1BQU0sVUFBVTtFQUNuQyxDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsTUFBTSw0QkFBNEI7RUFDaEMsTUFBTSxjQUFjLENBQUM7RUFDckIsTUFBTSxjQUFjLE1BQU0sc0JBQXNCO0VBQ2hELFNBQVMsaUJBQWlCLEtBQUssS0FBSztHQUNsQyxJQUFJLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUNuQixZQUFZLEtBQUssT0FBTyxRQUFRLFdBQVcsR0FDeEMsTUFBTSxFQUNMLEdBQUcsSUFDTCxFQUNGLElBQUksR0FBRztFQUVYO0VBQ0EsaUJBQWlCLFlBQVksS0FBQSxHQUFXLEVBQ3RDLEdBQUcsUUFDTCxDQUFDLEdBQUcsT0FBTztFQUNYLE1BQU0sR0FDSCxjQUFjLGtCQUNmLEdBQUcsVUFDRDtFQUNKLElBQUksa0JBQWtCO0dBRXBCLE1BQU0sRUFDSixRQUNFO0dBQ0osTUFBTSxnQkFBZ0IsYUFBYSxZQUFZLEVBQUUsU0FBUztHQUMxRCxNQUFNLFdBQVcsQ0FBQyx5QkFBeUIsZ0JBQWdCO0lBQ3pELGFBQWE7SUFDYixHQUFHO0dBQ0wsSUFBSSxFQUNGLEdBQUcsSUFDTDtHQUNBLGlCQUFpQixZQUFZLGFBQWEsRUFDeEMsR0FBRyxTQUNMLENBQUMsR0FBRyxRQUFRO0VBQ2Q7RUFDQSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssRUFDbkMsV0FDSztHQUNMLE1BQU0sZ0JBQWdCLGFBQWEsSUFBSSxFQUFFLFNBQVM7R0FDbEQsTUFBTSxXQUFXLENBQUMseUJBQXlCLGdCQUFnQjtJQUN6RCxhQUFhO0lBQ2IsR0FBRztHQUNMLElBQUksRUFDRixHQUFHLElBQ0w7R0FDQSxpQkFBaUIsWUFBWSxLQUFLLEVBQ2hDLEdBQUcsU0FDTCxDQUFDLEdBQUcsUUFBUTtFQUNkLENBQUM7RUFDRCxJQUFJLG9CQUNGLFlBQVksS0FBSyxFQUNmLFNBQVM7R0FFUCxtQkFBbUI7R0FDbkIsU0FBUztHQUNULFNBQVM7RUFDWCxFQUNGLENBQUM7RUFFSCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0VBQ0wsTUFBTTtFQUNOO0VBQ0E7Q0FDRjtBQUNGOzs7QUNqS0EsU0FBZ0IsNkJBQTZCLFVBQVU7Q0FDckQsT0FBTyxTQUFTLHVCQUF1QixhQUFhO0VBQ2xELElBQUksYUFBYSxTQUFTO0dBRXRCLElBQUksZ0JBQWdCLFdBQVcsZ0JBQWdCLFFBQzdDLFFBQVEsTUFBTSxvRkFBb0YsWUFBWSxHQUFHO0dBR3JILE9BQU8saUNBQWlDLFlBQVk7RUFDdEQ7RUFDQSxJQUFJLFVBQVU7R0FDWixJQUFJLFNBQVMsV0FBVyxPQUFPLEtBQUssQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUN6RCxPQUFPLElBQUksU0FBUyxJQUFJLFlBQVk7R0FFdEMsSUFBSSxhQUFhLFNBQ2YsT0FBTyxJQUFJLFlBQVk7R0FFekIsSUFBSSxhQUFhLFFBQ2YsT0FBTyxTQUFTLFlBQVk7R0FFOUIsT0FBTyxHQUFHLFNBQVMsUUFBUSxNQUFNLFdBQVcsRUFBRTtFQUNoRDtFQUNBLE9BQU87Q0FDVDtBQUNGOzs7Ozs7Ozs7Ozs7QUV6QkEsSUFBTSxTQUFTO0NBQ2IsT0FBTztDQUNQLE9BQU87QUFDVDs7O0FDSEEsSUFBTSxPQUFPO0NBQ1gsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07QUFDUjs7O0FDZkEsSUFBTSxTQUFTO0NBQ2IsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07QUFDUjs7O0FDZkEsSUFBTSxNQUFNO0NBQ1YsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07QUFDUjs7O0FDZkEsSUFBTSxTQUFTO0NBQ2IsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07QUFDUjs7O0FDZkEsSUFBTSxPQUFPO0NBQ1gsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07QUFDUjs7O0FDZkEsSUFBTSxZQUFZO0NBQ2hCLElBQUk7Q0FDSixLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0FBQ1I7OztBQ2ZBLElBQU0sUUFBUTtDQUNaLElBQUk7Q0FDSixLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0FBQ1I7OztBQ0pBLFNBQVMsV0FBVztDQUNsQixPQUFPO0VBRUwsTUFBTTtHQUVKLFNBQVM7R0FFVCxXQUFXO0dBRVgsVUFBVTtFQUNaO0VBRUEsU0FBUztFQUdULFlBQVk7R0FDVixPQUFPLE9BQU87R0FDZCxTQUFTLE9BQU87RUFDbEI7RUFFQSxRQUFRO0dBRU4sUUFBUTtHQUVSLE9BQU87R0FDUCxjQUFjO0dBRWQsVUFBVTtHQUNWLGlCQUFpQjtHQUVqQixVQUFVO0dBRVYsb0JBQW9CO0dBQ3BCLGlCQUFpQjtHQUNqQixPQUFPO0dBQ1AsY0FBYztHQUNkLGtCQUFrQjtFQUNwQjtDQUNGO0FBQ0Y7QUFDQSxJQUFhLFFBQVEsU0FBUztBQUM5QixTQUFTLFVBQVU7Q0FDakIsT0FBTztFQUNMLE1BQU07R0FDSixTQUFTLE9BQU87R0FDaEIsV0FBVztHQUNYLFVBQVU7R0FDVixNQUFNO0VBQ1I7RUFDQSxTQUFTO0VBQ1QsWUFBWTtHQUNWLE9BQU87R0FDUCxTQUFTO0VBQ1g7RUFDQSxRQUFRO0dBQ04sUUFBUSxPQUFPO0dBQ2YsT0FBTztHQUNQLGNBQWM7R0FDZCxVQUFVO0dBQ1YsaUJBQWlCO0dBQ2pCLFVBQVU7R0FDVixvQkFBb0I7R0FDcEIsaUJBQWlCO0dBQ2pCLE9BQU87R0FDUCxjQUFjO0dBQ2Qsa0JBQWtCO0VBQ3BCO0NBQ0Y7QUFDRjtBQUNBLElBQWEsT0FBTyxRQUFRO0FBQzVCLFNBQVMsZUFBZSxRQUFRLFdBQVcsT0FBTyxhQUFhO0NBQzdELE1BQU0sbUJBQW1CLFlBQVksU0FBUztDQUM5QyxNQUFNLGtCQUFrQixZQUFZLFFBQVEsY0FBYztDQUMxRCxJQUFJLENBQUMsT0FBTztNQUNOLE9BQU8sZUFBZSxLQUFLLEdBQzdCLE9BQU8sYUFBYSxPQUFPO09BQ3RCLElBQUksY0FBYyxTQUN2QixPQUFPLFFBQVEsUUFBUSxPQUFPLE1BQU0sZ0JBQWdCO09BQy9DLElBQUksY0FBYyxRQUN2QixPQUFPLE9BQU8sT0FBTyxPQUFPLE1BQU0sZUFBZTtDQUFBO0FBR3ZEO0FBQ0EsU0FBUyxlQUFlLFlBQVksUUFBUSxXQUFXLE9BQU8sYUFBYTtDQUN6RSxNQUFNLG1CQUFtQixZQUFZLFNBQVM7Q0FDOUMsTUFBTSxrQkFBa0IsWUFBWSxRQUFRLGNBQWM7Q0FDMUQsSUFBSSxDQUFDLE9BQU87TUFDTixPQUFPLGVBQWUsS0FBSyxHQUM3QixPQUFPLGFBQWEsT0FBTztPQUN0QixJQUFJLGNBQWMsU0FDdkIsT0FBTyxRQUFRLGdCQUFnQixXQUFXLElBQUksT0FBTyxLQUFLLFVBQVUsbUJBQW1CLElBQUEsQ0FBSyxRQUFRLENBQUMsRUFBRTtPQUNsRyxJQUFJLGNBQWMsUUFDdkIsT0FBTyxPQUFPLGdCQUFnQixXQUFXLElBQUksT0FBTyxLQUFLLFVBQVUsa0JBQWtCLElBQUEsQ0FBSyxRQUFRLENBQUMsRUFBRTtDQUFBO0FBRzNHO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQ3pDLElBQUksU0FBUyxRQUNYLE9BQU87RUFDTCxNQUFNLEtBQUs7RUFDWCxPQUFPLEtBQUs7RUFDWixNQUFNLEtBQUs7Q0FDYjtDQUVGLE9BQU87RUFDTCxNQUFNLEtBQUs7RUFDWCxPQUFPLEtBQUs7RUFDWixNQUFNLEtBQUs7Q0FDYjtBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTyxTQUFTO0NBQzNDLElBQUksU0FBUyxRQUNYLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixPQUFPLE9BQU87RUFDZCxNQUFNLE9BQU87Q0FDZjtDQUVGLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixPQUFPLE9BQU87RUFDZCxNQUFNLE9BQU87Q0FDZjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTyxTQUFTO0NBQ3ZDLElBQUksU0FBUyxRQUNYLE9BQU87RUFDTCxNQUFNLElBQUk7RUFDVixPQUFPLElBQUk7RUFDWCxNQUFNLElBQUk7Q0FDWjtDQUVGLE9BQU87RUFDTCxNQUFNLElBQUk7RUFDVixPQUFPLElBQUk7RUFDWCxNQUFNLElBQUk7Q0FDWjtBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU8sU0FBUztDQUN0QyxJQUFJLFNBQVMsUUFDWCxPQUFPO0VBQ0wsTUFBTSxVQUFVO0VBQ2hCLE9BQU8sVUFBVTtFQUNqQixNQUFNLFVBQVU7Q0FDbEI7Q0FFRixPQUFPO0VBQ0wsTUFBTSxVQUFVO0VBQ2hCLE9BQU8sVUFBVTtFQUNqQixNQUFNLFVBQVU7Q0FDbEI7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sU0FBUztDQUN6QyxJQUFJLFNBQVMsUUFDWCxPQUFPO0VBQ0wsTUFBTSxNQUFNO0VBQ1osT0FBTyxNQUFNO0VBQ2IsTUFBTSxNQUFNO0NBQ2Q7Q0FFRixPQUFPO0VBQ0wsTUFBTSxNQUFNO0VBQ1osT0FBTyxNQUFNO0VBQ2IsTUFBTSxNQUFNO0NBQ2Q7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sU0FBUztDQUN6QyxJQUFJLFNBQVMsUUFDWCxPQUFPO0VBQ0wsTUFBTSxPQUFPO0VBQ2IsT0FBTyxPQUFPO0VBQ2QsTUFBTSxPQUFPO0NBQ2Y7Q0FFRixPQUFPO0VBQ0wsTUFBTTtFQUVOLE9BQU8sT0FBTztFQUNkLE1BQU0sT0FBTztDQUNmO0FBQ0Y7QUFHQSxTQUFnQixjQUFjLFlBQVk7Q0FDeEMsT0FBTyxjQUFjLFdBQVc7QUFDbEM7QUFDQSxTQUF3QixjQUFjLFNBQVM7Q0FDN0MsTUFBTSxFQUNKLE9BQU8sU0FDUCxvQkFBb0IsR0FDcEIsY0FBYyxJQUNkLFlBQ0EsR0FBRyxVQUNEO0NBQ0osTUFBTSxVQUFVLFFBQVEsV0FBVyxrQkFBa0IsSUFBSTtDQUN6RCxNQUFNLFlBQVksUUFBUSxhQUFhLG9CQUFvQixJQUFJO0NBQy9ELE1BQU0sUUFBUSxRQUFRLFNBQVMsZ0JBQWdCLElBQUk7Q0FDbkQsTUFBTSxPQUFPLFFBQVEsUUFBUSxlQUFlLElBQUk7Q0FDaEQsTUFBTSxVQUFVLFFBQVEsV0FBVyxrQkFBa0IsSUFBSTtDQUN6RCxNQUFNLFVBQVUsUUFBUSxXQUFXLGtCQUFrQixJQUFJO0NBS3pELFNBQVMsZ0JBQWdCLFlBQVk7RUFDbkMsSUFBSSxZQUNGLE9BQU8sY0FBYyxVQUFVO0VBRWpDLE1BQU0sZUFBZSxpQkFBaUIsWUFBWSxLQUFLLEtBQUssT0FBTyxLQUFLLG9CQUFvQixLQUFLLEtBQUssVUFBVSxNQUFNLEtBQUs7RUFDaEY7R0FDekMsTUFBTSxXQUFXLGlCQUFpQixZQUFZLFlBQVk7R0FDMUQsSUFBSSxXQUFXLEdBQ2IsUUFBUSxNQUFNO0lBQUMsOEJBQThCLFNBQVMsU0FBUyxhQUFhLE1BQU07SUFBYztJQUE0RTtHQUFnRixDQUFDLENBQUMsS0FBSyxJQUFJLENBQUM7RUFFNVE7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGdCQUFnQixFQUNwQixPQUNBLE1BQ0EsWUFBWSxLQUNaLGFBQWEsS0FDYixZQUFZLFVBQ1I7RUFDSixRQUFRLEVBQ04sR0FBRyxNQUNMO0VBQ0EsSUFBSSxDQUFDLE1BQU0sUUFBUSxNQUFNLFlBQ3ZCLE1BQU0sT0FBTyxNQUFNO0VBRXJCLElBQUksQ0FBQyxNQUFNLGVBQWUsTUFBTSxHQUM5QixNQUFNLElBQUksTUFBOEMsaUJBQWlCLE9BQU8sS0FBSyxLQUFLLEtBQUssR0FBRywwR0FBK0csVUFBVSxhQUE0RTtFQUV6UyxJQUFJLE9BQU8sTUFBTSxTQUFTLFVBQ3hCLE1BQU0sSUFBSSxNQUE4QyxpQkFBaUIsT0FBTyxLQUFLLEtBQUssS0FBSyxHQUFHLHlGQUE4RixLQUFLLFVBQVUsTUFBTSxJQUFJLEVBQUU7Ozs7Ozs7Ozs7O01BQXlhO0VBRXRvQixJQUFJLFlBQVk7R0FDZCxlQUFlLFlBQVksT0FBTyxTQUFTLFlBQVksV0FBVztHQUNsRSxlQUFlLFlBQVksT0FBTyxRQUFRLFdBQVcsV0FBVztFQUNsRSxPQUFPO0dBQ0wsZUFBZSxPQUFPLFNBQVMsWUFBWSxXQUFXO0dBQ3RELGVBQWUsT0FBTyxRQUFRLFdBQVcsV0FBVztFQUN0RDtFQUNBLElBQUksQ0FBQyxNQUFNLGNBQ1QsTUFBTSxlQUFlLGdCQUFnQixNQUFNLElBQUk7RUFFakQsT0FBTztDQUNUO0NBQ0EsSUFBSTtDQUNKLElBQUksU0FBUyxTQUNYLGVBQWUsU0FBUztNQUNuQixJQUFJLFNBQVMsUUFDbEIsZUFBZSxRQUFRO0NBR3ZCLElBQUksQ0FBQyxjQUNILFFBQVEsTUFBTSwyQkFBMkIsS0FBSyxxQkFBcUI7Q0E0RHZFLE9BekRzQixVQUFVO0VBRTlCLFFBQVEsRUFDTixHQUFHLE9BQ0w7RUFHQTtFQUVBLFNBQVMsYUFBYTtHQUNwQixPQUFPO0dBQ1AsTUFBTTtFQUNSLENBQUM7RUFFRCxXQUFXLGFBQWE7R0FDdEIsT0FBTztHQUNQLE1BQU07R0FDTixXQUFXO0dBQ1gsWUFBWTtHQUNaLFdBQVc7RUFDYixDQUFDO0VBRUQsT0FBTyxhQUFhO0dBQ2xCLE9BQU87R0FDUCxNQUFNO0VBQ1IsQ0FBQztFQUVELFNBQVMsYUFBYTtHQUNwQixPQUFPO0dBQ1AsTUFBTTtFQUNSLENBQUM7RUFFRCxNQUFNLGFBQWE7R0FDakIsT0FBTztHQUNQLE1BQU07RUFDUixDQUFDO0VBRUQsU0FBUyxhQUFhO0dBQ3BCLE9BQU87R0FDUCxNQUFNO0VBQ1IsQ0FBQztFQUVEO0VBR0E7RUFFQTtFQUVBO0VBSUE7RUFFQSxHQUFHO0NBQ0wsR0FBRyxLQUNnQjtBQUNyQjs7O0FDeFVBLFNBQXdCLHNCQUFzQixZQUFZO0NBQ3hELE1BQU0sT0FBTyxDQUFDO0NBRWQsT0FEdUIsUUFBUSxVQUN6QixDQUFDLENBQUMsU0FBUSxVQUFTO0VBQ3ZCLE1BQU0sQ0FBQyxLQUFLLFNBQVM7RUFDckIsSUFBSSxPQUFPLFVBQVUsVUFDbkIsS0FBSyxPQUFPLEdBQUcsTUFBTSxZQUFZLEdBQUcsTUFBTSxVQUFVLEtBQUssS0FBSyxNQUFNLGNBQWMsR0FBRyxNQUFNLFlBQVksS0FBSyxLQUFLLE1BQU0sYUFBYSxHQUFHLE1BQU0sV0FBVyxLQUFLLEtBQUssTUFBTSxjQUFjLEdBQUcsTUFBTSxZQUFZLEtBQUssS0FBSyxNQUFNLFlBQVksS0FBSyxNQUFNLGFBQWEsSUFBSSxNQUFNLFdBQVcsS0FBSyxLQUFLLE1BQU0sY0FBYztDQUV0VCxDQUFDO0NBQ0QsT0FBTztBQUNUOzs7QUNWQSxTQUF3QixhQUFhLGFBQWEsUUFBUTtDQUN4RCxPQUFPO0VBQ0wsU0FBUztHQUNQLFdBQVc7SUFDVixZQUFZLEdBQUcsSUFBSSxJQUFJLEVBQ3RCLG1DQUFtQyxFQUNqQyxXQUFXLEdBQ2IsRUFDRjtJQUNDLFlBQVksR0FBRyxJQUFJLElBQUksRUFDdEIsV0FBVyxHQUNiO0VBQ0Y7RUFDQSxHQUFHO0NBQ0w7QUFDRjs7O0FDZEEsU0FBUyxNQUFNLE9BQU87Q0FDcEIsT0FBTyxLQUFLLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDbkM7QUFDQSxJQUFNLGNBQWMsRUFDbEIsZUFBZSxZQUNqQjtBQUNBLElBQU0sb0JBQW9COzs7OztBQU0xQixTQUF3QixpQkFBaUIsU0FBUyxZQUFZO0NBQzVELE1BQU0sRUFDSixhQUFhLG1CQUViLFdBQVcsSUFFWCxrQkFBa0IsS0FDbEIsb0JBQW9CLEtBQ3BCLG1CQUFtQixLQUNuQixpQkFBaUIsS0FHakIsZUFBZSxJQUVmLGFBQ0EsU0FBUyxVQUNULEdBQUcsVUFDRCxPQUFPLGVBQWUsYUFBYSxXQUFXLE9BQU8sSUFBSTtDQUUzRCxJQUFJLE9BQU8sYUFBYSxVQUN0QixRQUFRLE1BQU0sNkNBQTZDO0NBRTdELElBQUksT0FBTyxpQkFBaUIsVUFDMUIsUUFBUSxNQUFNLGlEQUFpRDtDQUduRSxNQUFNLE9BQU8sV0FBVztDQUN4QixNQUFNLFVBQVUsY0FBYSxTQUFRLEdBQUcsT0FBTyxlQUFlLEtBQUs7Q0FDbkUsTUFBTSxnQkFBZ0IsWUFBWSxNQUFNLFlBQVksZUFBZSxZQUFZO0VBQzdFO0VBQ0E7RUFDQSxVQUFVLFFBQVEsSUFBSTtFQUV0QjtFQUdBLEdBQUksZUFBZSxvQkFBb0IsRUFDckMsZUFBZSxHQUFHLE1BQU0sZ0JBQWdCLElBQUksRUFBRSxJQUNoRCxJQUFJLENBQUM7RUFDTCxHQUFHO0VBQ0gsR0FBRztDQUNMO0NBd0JBLE9BQU8sVUFBVTtFQUNmO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUE5QkEsSUFBSSxhQUFhLGlCQUFpQixJQUFJLE9BQU8sSUFBSTtFQUNqRCxJQUFJLGFBQWEsaUJBQWlCLElBQUksS0FBSyxHQUFJO0VBQy9DLElBQUksYUFBYSxtQkFBbUIsSUFBSSxPQUFPLENBQUM7RUFDaEQsSUFBSSxhQUFhLG1CQUFtQixJQUFJLE9BQU8sR0FBSTtFQUNuRCxJQUFJLGFBQWEsbUJBQW1CLElBQUksT0FBTyxDQUFDO0VBQ2hELElBQUksYUFBYSxrQkFBa0IsSUFBSSxLQUFLLEdBQUk7RUFDaEQsV0FBVyxhQUFhLG1CQUFtQixJQUFJLE1BQU0sR0FBSTtFQUN6RCxXQUFXLGFBQWEsa0JBQWtCLElBQUksTUFBTSxFQUFHO0VBQ3ZELE9BQU8sYUFBYSxtQkFBbUIsSUFBSSxLQUFLLEdBQUk7RUFDcEQsT0FBTyxhQUFhLG1CQUFtQixJQUFJLE1BQU0sR0FBSTtFQUNyRCxRQUFRLGFBQWEsa0JBQWtCLElBQUksTUFBTSxJQUFLLFdBQVc7RUFDakUsU0FBUyxhQUFhLG1CQUFtQixJQUFJLE1BQU0sRUFBRztFQUN0RCxVQUFVLGFBQWEsbUJBQW1CLElBQUksTUFBTSxHQUFHLFdBQVc7RUFFbEUsU0FBUztHQUNQLFlBQVk7R0FDWixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixlQUFlO0VBQ2pCO0NBWUYsR0FBRyxPQUFPLEVBQ1IsT0FBTyxNQUNULENBQUM7QUFDSDs7O0FDM0ZBLElBQU0sd0JBQXdCO0FBQzlCLElBQU0sMkJBQTJCO0FBQ2pDLElBQU0sNkJBQTZCO0FBQ25DLFNBQVMsYUFBYSxHQUFHLElBQUk7Q0FDM0IsT0FBTztFQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLGdCQUFnQixzQkFBc0I7RUFBSSxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxnQkFBZ0IseUJBQXlCO0VBQUksR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLElBQUksS0FBSyxHQUFHLElBQUksZ0JBQWdCLDJCQUEyQjtDQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDeFI7QUFHQSxJQUFNLFVBQVU7Q0FBQztDQUFRLGFBQWEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHLGFBQWEsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FBRyxhQUFhLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQUcsYUFBYSxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztBQUFDOzs7QUNScHlDLElBQU1DLDZCQUEyQixDQUFDLEtBQUs7QUFDdkMsSUFBTUMsa0JBQWdCLENBQUM7QUFJdkIsSUFBYSxTQUFTO0NBRXBCLFdBQVc7Q0FHWCxTQUFTO0NBRVQsUUFBUTtDQUVSLE9BQU87QUFDVDtBQUlBLElBQWEsV0FBVztDQUN0QixVQUFVO0NBQ1YsU0FBUztDQUNULE9BQU87Q0FFUCxVQUFVO0NBRVYsU0FBUztDQUVULGdCQUFnQjtDQUVoQixlQUFlO0FBQ2pCO0FBQ0EsU0FBUyxTQUFTLGNBQWM7Q0FDOUIsT0FBTyxHQUFHLEtBQUssTUFBTSxZQUFZLEVBQUU7QUFDckM7QUFDQSxTQUFTLHNCQUFzQixRQUFRO0NBQ3JDLElBQUksQ0FBQyxRQUNILE9BQU87Q0FFVCxNQUFNLFdBQVcsU0FBUztDQUcxQixPQUFPLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLFlBQVksTUFBTyxXQUFXLEtBQUssRUFBRSxHQUFHLEdBQUk7QUFDbkY7QUFDQSxTQUF3QixrQkFBa0Isa0JBQWtCO0NBQzFELE1BQU0sY0FBYyxFQUNsQixHQUFHLGlCQUNMO0NBQ0EsT0FBTyxZQUFZO0NBQ25CLE1BQU0sZUFBZTtFQUNuQixHQUFHO0VBQ0gsR0FBRyxZQUFZO0NBQ2pCO0NBQ0EsTUFBTSxpQkFBaUI7RUFDckIsR0FBRztFQUNILEdBQUcsWUFBWTtDQUNqQjtDQUNBLE1BQU0seUJBQXlCLFFBQVFELDRCQUEwQixVQUFVQyxvQkFBa0I7RUFDM0YsTUFBTSxFQUNKLFVBQVUsaUJBQWlCLGVBQWUsVUFDMUMsUUFBUSxlQUFlLGFBQWEsV0FDcEMsUUFBUSxHQUNSLEdBQUcsVUFDRDtFQUN1QztHQUN6QyxNQUFNLFlBQVcsVUFBUyxPQUFPLFVBQVU7R0FDM0MsTUFBTSxZQUFXLFVBQVMsQ0FBQyxPQUFPLE1BQU0sV0FBVyxLQUFLLENBQUM7R0FDekQsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsTUFBTSxRQUFRLEtBQUssR0FDMUMsUUFBUSxNQUFNLG9EQUFrRDtHQUVsRSxJQUFJLENBQUMsU0FBUyxjQUFjLEtBQUssQ0FBQyxTQUFTLGNBQWMsR0FDdkQsUUFBUSxNQUFNLG1FQUFtRSxlQUFlLEVBQUU7R0FFcEcsSUFBSSxDQUFDLFNBQVMsWUFBWSxHQUN4QixRQUFRLE1BQU0sNENBQTBDO0dBRTFELElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDLFNBQVMsS0FBSyxHQUNyQyxRQUFRLE1BQU0sdURBQXFEO0dBRXJFLElBQUksT0FBTyxZQUFZLFVBQ3JCLFFBQVEsTUFBTSxDQUFDLGdFQUFnRSxnR0FBZ0csQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0dBRTdMLElBQUksT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLFdBQVcsR0FDaEMsUUFBUSxNQUFNLGtDQUFrQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRztFQUVwRjtFQUNBLFFBQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFBLENBQUcsS0FBSSxpQkFBZ0IsR0FBRyxhQUFhLEdBQUcsT0FBTyxtQkFBbUIsV0FBVyxpQkFBaUIsU0FBUyxjQUFjLEVBQUUsR0FBRyxhQUFhLEdBQUcsT0FBTyxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzFQO0NBRUEsT0FBTztFQUNMO0VBQ0EsUUFIYSxZQUFZLFVBQVU7RUFJbkMsR0FBRztFQUNILFFBQVE7RUFDUixVQUFVO0NBQ1o7QUFDRjs7O0FDaEdBLElBQU0sZUFBZSxDQUFDO0FBQ3RCLFNBQXdCLGFBQWEsY0FBYyxjQUFjO0NBQy9ELE9BQU87RUFDTCxlQUFlO0VBQ2YsR0FBRztDQUNMO0FBQ0Y7OztBQ0pBLElBQU0sU0FBUztDQUNiLGVBQWU7Q0FDZixLQUFLO0NBQ0wsV0FBVztDQUNYLFFBQVE7Q0FDUixRQUFRO0NBQ1IsT0FBTztDQUNQLFVBQVU7Q0FDVixTQUFTO0FBQ1g7OztBQ1RBLFNBQVMsZUFBZSxLQUFLO0NBQzNCLE9BQU8sY0FBYyxHQUFHLEtBQUssT0FBTyxRQUFRLGVBQWUsT0FBTyxRQUFRLFlBQVksT0FBTyxRQUFRLGFBQWEsT0FBTyxRQUFRLFlBQVksTUFBTSxRQUFRLEdBQUc7QUFDaEs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJBLFNBQWdCLGVBQWUsWUFBWSxDQUFDLEdBQUc7Q0FDN0MsTUFBTSxvQkFBb0IsRUFDeEIsR0FBRyxVQUNMO0NBQ0EsU0FBUyxlQUFlLFFBQVE7RUFDOUIsTUFBTSxRQUFRLE9BQU8sUUFBUSxNQUFNO0VBRW5DLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFNLFFBQVEsU0FBUztHQUNqRCxNQUFNLENBQUMsS0FBSyxTQUFTLE1BQU07R0FDM0IsSUFBSSxDQUFDLGVBQWUsS0FBSyxLQUFLLElBQUksV0FBVyxXQUFXLEtBQUssSUFBSSxXQUFXLFdBQVcsR0FDckYsT0FBTyxPQUFPO1FBQ1QsSUFBSSxjQUFjLEtBQUssR0FBRztJQUMvQixPQUFPLE9BQU8sRUFDWixHQUFHLE1BQ0w7SUFDQSxlQUFlLE9BQU8sSUFBSTtHQUM1QjtFQUNGO0NBQ0Y7Q0FDQSxlQUFlLGlCQUFpQjtDQUNoQyxPQUFPOztnQkFFTyxLQUFLLFVBQVUsbUJBQW1CLE1BQU0sQ0FBQyxFQUFFOzs7Ozs7O0FBTzNEOzs7QUN4Q0EsU0FBUyx3QkFBd0IsYUFBYTtDQUM1QyxJQUFJLE9BQU8sZ0JBQWdCLFVBQ3pCLE9BQU8sSUFBSSxjQUFjLElBQUEsQ0FBSyxRQUFRLENBQUMsRUFBRTtDQUUzQyxPQUFPLFNBQVMsWUFBWTtBQUM5QjtBQUdBLElBQU0saUJBQWdCLFFBQU87Q0FDM0IsSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsR0FDcEIsT0FBTyxDQUFDO0NBRVYsTUFBTSxVQUFVLElBQUksTUFBTSxZQUFZO0NBQ3RDLElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxJQUFJLE1BQU07Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUssR0FDdkMsT0FBTyxDQUFDLFFBQVE7Q0FFbEIsT0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0IsT0FBTztDQUN0QyxPQUFPLE9BQU8sT0FBTztFQUNuQixNQUFNLE9BQU8sYUFBYTtHQUN4QixNQUFNLE1BQU0sUUFBUTtHQUNwQixJQUFJLElBQUksWUFDTixPQUFPLGNBQWMsTUFBTSxXQUFXLE9BQU8sZ0JBQWdCLFdBQVcsUUFBUSxZQUFZLEtBQUssWUFBWTtHQUUvRyxJQUFJLElBQUksTUFHTixPQUFPLFFBQVEsTUFBTSxRQUFRLG9DQUFvQyxrQkFBa0IsRUFBRSxLQUFLLE9BQU8sZ0JBQWdCLFdBQVcsUUFBUSxZQUFZLEtBQUssWUFBWTtHQUVuSyxPQUFPQyxNQUFZLE9BQU8sY0FBYyxXQUFXLENBQUM7RUFDdEQ7RUFDQSxRQUFRLE9BQU8sYUFBYTtHQUMxQixNQUFNLE1BQU0sUUFBUTtHQUNwQixJQUFJLElBQUksWUFDTixPQUFPLGdCQUFnQixJQUFJLFdBQVcsSUFBSSxNQUFNLFNBQVMsd0JBQXdCLFdBQVcsRUFBRTtHQUVoRyxPQUFPQyxRQUFjLE9BQU8sV0FBVztFQUN6QztFQUNBLE9BQU8sT0FBTyxhQUFhO0dBQ3pCLE1BQU0sTUFBTSxRQUFRO0dBQ3BCLElBQUksSUFBSSxZQUNOLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxJQUFJLE1BQU0sU0FBUyx3QkFBd0IsV0FBVyxFQUFFO0dBRWhHLE9BQU9DLE9BQWEsT0FBTyxXQUFXO0VBQ3hDO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxDQUFDLEdBQUcsR0FBRyxNQUFNO0NBQ2hELE1BQU0sRUFDSixhQUFhLGtCQUNiLFFBQVEsY0FBYyxDQUFDLEdBQ3ZCLFNBQVMsY0FDVCxTQUFTLGVBQWUsQ0FBQyxHQUN6QixRQUFRLGNBQWMsQ0FBQyxHQUN2QixhQUFhLG1CQUFtQixDQUFDLEdBQ2pDLFlBQVksa0JBQWtCLENBQUMsR0FDL0IsT0FBTyxZQUNQLFlBQ0EsR0FBRyxVQUNEO0NBQ0osSUFBSSxRQUFRLFFBR1osUUFBUSxzQkFBc0IsS0FBQSxHQUM1QixNQUFNLElBQUksTUFBOEMsMk1BRTZHO0NBRXZLLE1BQU0sVUFBVSxjQUFjO0VBQzVCLEdBQUc7RUFDSDtDQUNGLENBQUM7Q0FDRCxNQUFNLGNBQWNDLGNBQWtCLE9BQU87Q0FDN0MsSUFBSSxXQUFXLFVBQVUsYUFBYTtFQUNwQyxRQUFRLGFBQWEsWUFBWSxhQUFhLFdBQVc7RUFDekQ7RUFFQSxTQUFTLFFBQVEsTUFBTTtFQUN2QixZQUFZLGlCQUFpQixTQUFTLGVBQWU7RUFDckQsUUFBUSxhQUFhLFdBQVc7RUFDaEMsYUFBYSxrQkFBa0IsZ0JBQWdCO0VBQy9DLFFBQVEsRUFDTixHQUFHLE9BQ0w7Q0FDRixDQUFDO0NBQ0QsV0FBVyxVQUFVLFVBQVUsS0FBSztDQUNwQyxXQUFXLEtBQUssUUFBUSxLQUFLLGFBQWEsVUFBVSxLQUFLLFFBQVEsR0FBRyxRQUFRO0NBRTVFLE9BQU8sU0FBUyxZQUFZO0NBQ2U7RUFFekMsTUFBTSxlQUFlO0dBQUM7R0FBVTtHQUFXO0dBQWE7R0FBWTtHQUFTO0dBQVk7R0FBVztHQUFnQjtHQUFZO0VBQVU7RUFDMUksTUFBTSxZQUFZLE1BQU0sY0FBYztHQUNwQyxJQUFJO0dBR0osS0FBSyxPQUFPLE1BQU07SUFDaEIsTUFBTSxRQUFRLEtBQUs7SUFDbkIsSUFBSSxhQUFhLFNBQVMsR0FBRyxLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQUc7S0FDcEI7TUFDekMsTUFBTSxhQUFhLHFCQUFxQixJQUFJLEdBQUc7TUFDL0MsUUFBUSxNQUFNO09BQUMsY0FBYyxVQUFVLHNEQUEyRCxJQUFJO09BQXFCO09BQXVDLEtBQUssVUFBVSxNQUFNLE1BQU0sQ0FBQztPQUFHO09BQUksbUNBQW1DLFdBQVc7T0FBWSxLQUFLLFVBQVUsRUFDNVEsTUFBTSxHQUNILEtBQUssZUFBZSxNQUN2QixFQUNGLEdBQUcsTUFBTSxDQUFDO09BQUc7T0FBSTtNQUF1QyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUM7S0FDdEU7S0FFQSxLQUFLLE9BQU8sQ0FBQztJQUNmO0dBQ0Y7RUFDRjtFQUNBLE9BQU8sS0FBSyxTQUFTLFVBQVUsQ0FBQyxDQUFDLFNBQVEsY0FBYTtHQUNwRCxNQUFNLGlCQUFpQixTQUFTLFdBQVcsVUFBVSxDQUFDO0dBQ3RELElBQUksa0JBQWtCLFVBQVUsV0FBVyxLQUFLLEdBQzlDLFNBQVMsZ0JBQWdCLFNBQVM7RUFFdEMsQ0FBQztDQUNIO0NBQ0EsU0FBUyxvQkFBb0I7RUFDM0IsR0FBRztFQUNILEdBQUcsT0FBTztDQUNaO0NBQ0EsU0FBUyxjQUFjLFNBQVMsR0FBRyxPQUFPO0VBQ3hDLE9BQU9DLHdCQUFnQjtHQUNyQixJQUFJO0dBQ0osT0FBTztFQUNULENBQUM7Q0FDSDtDQUNBLFNBQVMsa0JBQWtCO0NBRTNCLHdCQUF3QixRQUFRO0NBQ2hDLE9BQU87QUFDVDs7O0FDdkpBLFNBQXdCLGdCQUFnQixXQUFXO0NBQ2pELElBQUk7Q0FDSixJQUFJLFlBQVksR0FDZCxhQUFhLFVBQVUsYUFBYTtNQUVwQyxhQUFhLE1BQU0sS0FBSyxJQUFJLFlBQVksQ0FBQyxJQUFJO0NBRS9DLE9BQU8sS0FBSyxNQUFNLGFBQWEsRUFBRSxJQUFJO0FBQ3ZDOzs7QUNQQSxJQUFNLHNCQUFzQixDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxVQUFVO0NBQzNELElBQUksVUFBVSxHQUNaLE9BQU87Q0FFVCxNQUFNLFVBQVUsZ0JBQWdCLEtBQUs7Q0FDckMsT0FBTyxzQ0FBc0MsUUFBUSx3QkFBd0IsUUFBUTtBQUN2RixDQUFDO0FBQ0QsU0FBZ0IsV0FBVyxNQUFNO0NBQy9CLE9BQU87RUFDTCxrQkFBa0IsU0FBUyxTQUFTLEtBQU07RUFDMUMsZ0JBQWdCLFNBQVMsU0FBUyxLQUFNO0VBQ3hDLHFCQUFxQixTQUFTLFNBQVMsS0FBTTtFQUM3QyxhQUFhLFNBQVMsU0FBUyxLQUFNO0NBQ3ZDO0FBQ0Y7QUFDQSxTQUFnQixZQUFZLE1BQU07Q0FDaEMsT0FBTyxTQUFTLFNBQVMsc0JBQXNCLENBQUM7QUFDbEQ7QUFDQSxTQUF3QixrQkFBa0IsU0FBUztDQUNqRCxNQUFNLEVBQ0osU0FBUyxlQUFlLEVBQ3RCLE1BQU0sUUFDUixHQUVBLFNBQ0EsVUFDQSxZQUNBLEdBQUcsVUFDRDtDQUVKLE1BQU0sVUFBVSxjQUFjO0VBQzVCLEdBQUc7RUFDSDtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQSxTQUFTO0dBQ1AsR0FBRyxXQUFXLFFBQVEsSUFBSTtHQUMxQixHQUFHO0VBQ0w7RUFDQSxVQUFVLFlBQVksWUFBWSxRQUFRLElBQUk7RUFDOUMsR0FBRztDQUNMO0FBQ0Y7OztBQzdDQSxTQUF3Qix3QkFBd0IsTUFBTTtDQUNwRCxPQUFPLEtBQUssT0FBTyxZQUFZLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLHNIQUFzSCxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLFdBQVcsS0FFck0sS0FBSyxPQUFPLGFBQWEsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sc0NBQXNDO0FBQ2xGOzs7Ozs7QUNEQSxJQUFNLDRCQUEyQixpQkFBZ0I7Q0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFVBQVUsS0FBSyxlQUFlLEdBQUcsYUFBYSxLQUFLLEdBQUcsV0FBVyxPQUFPO0NBQUcsS0FBSyxlQUFlLEdBQUcsYUFBYSxLQUFLLEdBQUc7Q0FBd0IsS0FBSyxlQUFlLEdBQUcsYUFBYSxLQUFLLEdBQUc7QUFBeUI7OztBQ0ZoUyxJQUFBLDZCQUFlLFdBQVUsYUFBYSxRQUFRO0NBQzVDLE1BQU0sT0FBTyxNQUFNLGdCQUFnQjtDQUNuQyxNQUFNLFdBQVcsTUFBTTtDQUN2QixJQUFJLE9BQU87Q0FDWCxJQUFJLGFBQWEsU0FDZixPQUFPO0NBRVQsSUFBSSxhQUFhLFFBQ2YsT0FBTztDQUVULElBQUksVUFBVSxXQUFXLE9BQU8sS0FBSyxDQUFDLFNBQVMsU0FBUyxJQUFJLEdBRTFELE9BQU8sSUFBSSxTQUFTO0NBRXRCLElBQUksTUFBTSx1QkFBdUIsYUFBYTtFQUM1QyxJQUFJLGdCQUFnQixRQUFRO0dBQzFCLE1BQU0sb0JBQW9CLENBQUM7R0FDM0IseUJBQXlCLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUSxXQUFVO0lBQzdELGtCQUFrQixVQUFVLElBQUk7SUFDaEMsT0FBTyxJQUFJO0dBQ2IsQ0FBQztHQUNELElBQUksU0FBUyxTQUNYLE9BQU87S0FDSixPQUFPO0tBQ1Asd0NBQXdDLEdBQ3RDLE9BQU8sa0JBQ1Y7R0FDRjtHQUVGLElBQUksTUFDRixPQUFPO0tBQ0osS0FBSyxRQUFRLE1BQU0sV0FBVyxJQUFJO0tBQ2xDLEdBQUcsS0FBSyxJQUFJLEtBQUssUUFBUSxNQUFNLFdBQVcsTUFBTTtHQUNuRDtHQUVGLE9BQU8sR0FDSixPQUFPO0lBQ04sR0FBRztJQUNILEdBQUc7R0FDTCxFQUNGO0VBQ0Y7RUFDQSxJQUFJLFFBQVEsU0FBUyxTQUNuQixPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssUUFBUSxNQUFNLE9BQU8sV0FBVyxDQUFDO0NBRTdELE9BQU8sSUFBSSxhQUFhO0VBQ3RCLElBQUksU0FBUyxTQUNYLE9BQU8sR0FDSixpQ0FBaUMsT0FBTyxXQUFXLEVBQUUsS0FBSyxHQUN4RCxPQUFPLElBQ1YsRUFDRjtFQUVGLElBQUksTUFDRixPQUFPLEtBQUssUUFBUSxNQUFNLE9BQU8sV0FBVyxDQUFDO0NBRWpEO0NBQ0EsT0FBTztBQUNUOzs7QUM5Q0EsU0FBUyxXQUFXLEtBQUssTUFBTTtDQUM3QixLQUFLLFNBQVEsTUFBSztFQUNoQixJQUFJLENBQUMsSUFBSSxJQUNQLElBQUksS0FBSyxDQUFDO0NBRWQsQ0FBQztBQUNIO0FBQ0EsU0FBUyxTQUFTLEtBQUssS0FBSyxjQUFjO0NBQ3hDLElBQUksQ0FBQyxJQUFJLFFBQVEsY0FDZixJQUFJLE9BQU87QUFFZjtBQUNBLFNBQVMsTUFBTSxPQUFPO0NBQ3BCLElBQUksT0FBTyxVQUFVLFlBQVksQ0FBQyxNQUFNLFdBQVcsS0FBSyxHQUN0RCxPQUFPO0NBRVQsT0FBTyxTQUFTLEtBQUs7QUFDdkI7QUFDQSxTQUFTLGdCQUFnQixLQUFLLEtBQUs7Q0FDakMsSUFBSSxFQUFFLEdBQUcsSUFBSSxZQUFZLE1BR3ZCLElBQUksR0FBRyxJQUFJLFlBQVlDLHlCQUFpQixNQUFNLElBQUksSUFBSSxHQUFHLCtCQUErQixJQUFJLDhCQUE4QixJQUFJO3lFQUEwSyxJQUFJLG9IQUFvSDtBQUVwYTtBQUNBLFNBQVMsY0FBYyxjQUFjO0NBQ25DLElBQUksT0FBTyxpQkFBaUIsVUFDMUIsT0FBTyxHQUFHLGFBQWE7Q0FFekIsSUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8saUJBQWlCLGNBQWMsTUFBTSxRQUFRLFlBQVksR0FDdEcsT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLElBQU0sVUFBUyxPQUFNO0NBQ25CLElBQUk7RUFDRixPQUFPLEdBQUc7Q0FDWixTQUFTLE9BQU8sQ0FFaEI7QUFFRjtBQUNBLElBQWEsbUJBQW1CLGVBQWUsVUFBVUMsa0JBQXNCLFlBQVk7QUFDM0YsU0FBU0Msb0JBQWtCLFlBQVksY0FBYyxRQUFRLFdBQVcsYUFBYTtDQUNuRixJQUFJLENBQUMsUUFDSDtDQUVGLFNBQVMsV0FBVyxPQUFPLENBQUMsSUFBSTtDQUNoQyxNQUFNLE9BQU8sZ0JBQWdCLFNBQVMsU0FBUztDQUMvQyxJQUFJLENBQUMsV0FBVztFQUNkLGFBQWEsZUFBZSxrQkFBa0I7R0FDNUMsR0FBRztHQUNILFNBQVM7SUFDUDtJQUNBLEdBQUcsUUFBUTtHQUNiO0dBQ0E7RUFDRixDQUFDO0VBQ0Q7Q0FDRjtDQUNBLE1BQU0sRUFDSixTQUNBLEdBQUcsYUFDRCxrQkFBa0I7RUFDcEIsR0FBRztFQUNILFNBQVM7R0FDUDtHQUNBLEdBQUcsUUFBUTtFQUNiO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsYUFBYSxlQUFlO0VBQzFCLEdBQUc7RUFDSDtFQUNBLFNBQVM7R0FDUCxHQUFHLFdBQVcsSUFBSTtHQUNsQixHQUFHLFFBQVE7RUFDYjtFQUNBLFVBQVUsUUFBUSxZQUFZLFlBQVksSUFBSTtDQUNoRDtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7O0FBVUEsU0FBd0Isb0JBQW9CLFVBQVUsQ0FBQyxHQUFHLEdBQUcsTUFBTTtDQUNqRSxNQUFNLEVBQ0osY0FBYyxvQkFBb0IsRUFDaEMsT0FBTyxLQUNULEdBQ0Esb0JBQW9CLHlCQUNwQix3QkFBd0IsT0FDeEIsZUFBZSxPQUNmLGNBQWMsT0FDZCx5QkFBQSw0QkFBMEJDLHlCQUMxQixxQkFBcUIsV0FBVyxrQkFBa0IsU0FBUyxrQkFBa0IsT0FBTyxVQUFVLEtBQUEsR0FDOUYsZUFBZSxTQUNmLEdBQUcsVUFDRDtDQUNKLE1BQU0sbUJBQW1CLE9BQU8sS0FBSyxpQkFBaUIsQ0FBQyxDQUFDO0NBQ3hELE1BQU0scUJBQXFCLDRCQUE0QixrQkFBa0IsU0FBUyxxQkFBcUIsVUFBVSxVQUFVO0NBQzNILE1BQU0sWUFBWSxnQkFBZ0IsWUFBWTtDQUM5QyxNQUFNLEdBQ0gscUJBQXFCLG9CQUN0QixPQUFPLGNBQ1AsTUFBTSxhQUNOLEdBQUcsdUJBQ0Q7Q0FDSixNQUFNLGVBQWUsRUFDbkIsR0FBRyxtQkFDTDtDQUNBLElBQUksZ0JBQWdCO0NBR3BCLElBQUksdUJBQXVCLFVBQVUsRUFBRSxVQUFVLHNCQUFzQix1QkFBdUIsV0FBVyxFQUFFLFdBQVcsb0JBQ3BILGdCQUFnQjtDQUVsQixJQUFJLENBQUMsZUFDSCxNQUFNLElBQUksTUFBOEMsMkJBQTJCLG1CQUFtQix3Q0FBc0Y7Q0FJOUwsSUFBSTtDQUNKLElBQUksYUFDRixhQUFhO0NBSWYsTUFBTSxXQUFXRCxvQkFBa0IsWUFBWSxjQUFjLGVBQWUsT0FBTyxrQkFBa0I7Q0FDckcsSUFBSSxnQkFBZ0IsQ0FBQyxhQUFhLE9BQ2hDLG9CQUFrQixZQUFZLGNBQWMsY0FBYyxLQUFBLEdBQVcsT0FBTztDQUU5RSxJQUFJLGVBQWUsQ0FBQyxhQUFhLE1BQy9CLG9CQUFrQixZQUFZLGNBQWMsYUFBYSxLQUFBLEdBQVcsTUFBTTtDQUU1RSxJQUFJLFFBQVE7RUFDVjtFQUNBLEdBQUc7RUFDSDtFQUNBLHFCQUFxQjtFQUNyQjtFQUNBO0VBQ0E7RUFDQSxNQUFNO0dBQ0osR0FBRyxzQkFBc0IsU0FBUyxVQUFVO0dBQzVDLEdBQUcsU0FBUztFQUNkO0VBQ0EsU0FBUyxjQUFjLE1BQU0sT0FBTztDQUN0QztDQUNBLE9BQU8sS0FBSyxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVEsUUFBTztFQUM3QyxNQUFNLFVBQVUsTUFBTSxhQUFhLElBQUksQ0FBQztFQUN4QyxNQUFNLGtCQUFpQixXQUFVO0dBQy9CLE1BQU0sU0FBUyxPQUFPLE1BQU0sR0FBRztHQUMvQixNQUFNLFFBQVEsT0FBTztHQUNyQixNQUFNLGFBQWEsT0FBTztHQUMxQixPQUFPLFVBQVUsUUFBUSxRQUFRLE1BQU0sQ0FBQyxXQUFXO0VBQ3JEO0VBR0EsSUFBSSxRQUFRLFNBQVMsU0FBUztHQUM1QixTQUFTLFFBQVEsUUFBUSxjQUFjLE1BQU07R0FDN0MsU0FBUyxRQUFRLFFBQVEsZ0JBQWdCLE1BQU07RUFDakQ7RUFDQSxJQUFJLFFBQVEsU0FBUyxRQUFRO0dBQzNCLFNBQVMsUUFBUSxRQUFRLGNBQWMsTUFBTTtHQUM3QyxTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsTUFBTTtFQUNqRDtFQUNBLFNBQVMsU0FBUyxRQUFRLE9BQU8sYUFBYTtHQUM1QyxJQUFJLFlBQVk7SUFDZCxJQUFJO0lBQ0osSUFBSSxXQUFXRSxtQkFDYixRQUFRLGlCQUFpQixJQUFJLGVBQWUsSUFBQSxDQUFLLFFBQVEsQ0FBQyxFQUFFO0lBRTlELElBQUksV0FBV0Msb0JBQ2IsUUFBUSxTQUFTLGNBQWMsSUFBQSxDQUFLLFFBQVEsQ0FBQyxFQUFFO0lBRWpELElBQUksV0FBV0MscUJBQ2IsUUFBUSxTQUFTLGNBQWMsSUFBQSxDQUFLLFFBQVEsQ0FBQyxFQUFFO0lBRWpELE9BQU8sZ0JBQWdCLFdBQVcsSUFBSSxNQUFNLElBQUksTUFBTTtHQUN4RDtHQUNBLE9BQU8sT0FBTyxPQUFPLFdBQVc7RUFDbEM7RUFHQSxXQUFXLFNBQVM7R0FBQztHQUFTO0dBQVU7R0FBVTtHQUFVO0dBQVE7R0FBZTtHQUFrQjtHQUFZO0dBQVU7R0FBbUI7R0FBbUI7R0FBaUI7R0FBZTtHQUFVO0dBQWE7RUFBUyxDQUFDO0VBQ2xPLElBQUksUUFBUSxTQUFTLFNBQVM7R0FDNUIsU0FBUyxRQUFRLE9BQU8sY0FBYyxTQUFTRCxvQkFBWSxjQUFjLFVBQVUscUJBQXFCLElBQUksUUFBUSxNQUFNLE9BQU8sRUFBRyxDQUFDO0dBQ3JJLFNBQVMsUUFBUSxPQUFPLGFBQWEsU0FBU0Esb0JBQVksY0FBYyxVQUFVLG9CQUFvQixJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUcsQ0FBQztHQUNsSSxTQUFTLFFBQVEsT0FBTyxnQkFBZ0IsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxPQUFPLEVBQUcsQ0FBQztHQUMzSSxTQUFTLFFBQVEsT0FBTyxnQkFBZ0IsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxPQUFPLEVBQUcsQ0FBQztHQUMzSSxTQUFTLFFBQVEsT0FBTyxpQkFBaUIsZUFBZSxvQkFBb0IsQ0FBQztHQUM3RSxTQUFTLFFBQVEsT0FBTyxnQkFBZ0IsZUFBZSxtQkFBbUIsQ0FBQztHQUMzRSxTQUFTLFFBQVEsT0FBTyxtQkFBbUIsZUFBZSxzQkFBc0IsQ0FBQztHQUNqRixTQUFTLFFBQVEsT0FBTyxtQkFBbUIsZUFBZSxzQkFBc0IsQ0FBQztHQUNqRixTQUFTLFFBQVEsT0FBTyxvQkFBb0IsYUFBYSxRQUFRLGdCQUFnQixRQUFRLE1BQU0sSUFBSSxDQUFDLENBQUM7R0FDckcsU0FBUyxRQUFRLE9BQU8sbUJBQW1CLGFBQWEsUUFBUSxnQkFBZ0IsUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDO0dBQ25HLFNBQVMsUUFBUSxPQUFPLHNCQUFzQixhQUFhLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUSxJQUFJLENBQUMsQ0FBQztHQUN6RyxTQUFTLFFBQVEsT0FBTyxzQkFBc0IsYUFBYSxRQUFRLGdCQUFnQixRQUFRLFFBQVEsSUFBSSxDQUFDLENBQUM7R0FDekcsU0FBUyxRQUFRLE9BQU8sbUJBQW1CLFNBQVNDLHFCQUFhLGNBQWMsVUFBVSxxQkFBcUIsSUFBSSxRQUFRLE1BQU0sT0FBTyxFQUFHLENBQUM7R0FDM0ksU0FBUyxRQUFRLE9BQU8sa0JBQWtCLFNBQVNBLHFCQUFhLGNBQWMsVUFBVSxvQkFBb0IsSUFBSSxRQUFRLEtBQUssT0FBTyxFQUFHLENBQUM7R0FDeEksU0FBUyxRQUFRLE9BQU8scUJBQXFCLFNBQVNBLHFCQUFhLGNBQWMsVUFBVSx1QkFBdUIsSUFBSSxRQUFRLFFBQVEsT0FBTyxFQUFHLENBQUM7R0FDakosU0FBUyxRQUFRLE9BQU8scUJBQXFCLFNBQVNBLHFCQUFhLGNBQWMsVUFBVSx1QkFBdUIsSUFBSSxRQUFRLFFBQVEsT0FBTyxFQUFHLENBQUM7R0FDakosU0FBUyxRQUFRLE9BQU8sa0JBQWtCLGVBQWUsb0JBQW9CLENBQUM7R0FDOUUsU0FBUyxRQUFRLE9BQU8saUJBQWlCLGVBQWUsbUJBQW1CLENBQUM7R0FDNUUsU0FBUyxRQUFRLE9BQU8sb0JBQW9CLGVBQWUsc0JBQXNCLENBQUM7R0FDbEYsU0FBUyxRQUFRLE9BQU8sb0JBQW9CLGVBQWUsc0JBQXNCLENBQUM7R0FDbEYsU0FBUyxRQUFRLFFBQVEsYUFBYSxlQUFlLGtCQUFrQixDQUFDO0dBQ3hFLFNBQVMsUUFBUSxRQUFRLGFBQWEsZUFBZSxrQkFBa0IsQ0FBQztHQUN4RSxTQUFTLFFBQVEsUUFBUSxzQkFBc0IsZUFBZSxrQkFBa0IsQ0FBQztHQUNqRixTQUFTLFFBQVEsUUFBUSwyQkFBMkIsZUFBZSxtQkFBbUIsQ0FBQztHQUN2RixTQUFTLFFBQVEsTUFBTSxpQkFBaUIsZUFBZSxrQkFBa0IsQ0FBQztHQUMxRSxTQUFTLFFBQVEsTUFBTSxzQkFBc0IsZUFBZSxrQkFBa0IsQ0FBQztHQUMvRSxTQUFTLFFBQVEsTUFBTSxvQkFBb0IsZUFBZSxrQkFBa0IsQ0FBQztHQUM3RSxTQUFTLFFBQVEsYUFBYSxNQUFNLHFCQUFxQjtHQUN6RCxTQUFTLFFBQVEsYUFBYSxXQUFXLHFCQUFxQjtHQUM5RCxTQUFTLFFBQVEsYUFBYSxjQUFjLHFCQUFxQjtHQUNqRSxTQUFTLFFBQVEsZ0JBQWdCLGFBQWEsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNqSixTQUFTLFFBQVEsZ0JBQWdCLGVBQWUsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHdCQUF3QixJQUFJLFFBQVEsVUFBVSxNQUFNLEdBQUksQ0FBQztHQUN2SixTQUFTLFFBQVEsZ0JBQWdCLFdBQVcsU0FBU0EscUJBQWEsY0FBYyxVQUFVLG9CQUFvQixJQUFJLFFBQVEsTUFBTSxNQUFNLEdBQUksQ0FBQztHQUMzSSxTQUFTLFFBQVEsZ0JBQWdCLFVBQVUsU0FBU0EscUJBQWEsY0FBYyxVQUFVLG1CQUFtQixJQUFJLFFBQVEsS0FBSyxNQUFNLEdBQUksQ0FBQztHQUN4SSxTQUFTLFFBQVEsZ0JBQWdCLGFBQWEsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNqSixTQUFTLFFBQVEsZ0JBQWdCLGFBQWEsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNsSixTQUFTLFFBQVEsVUFBVSxNQUFNLGFBQWEsU0FBU0YsbUJBQVcsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsS0FBSyxTQUFTLEdBQUksSUFBSSxRQUFRLGVBQWUsNkJBQTZCLEVBQUUsU0FBUztHQUNqTixTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsU0FBU0UscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUM1SSxTQUFTLFFBQVEsUUFBUSxrQkFBa0IsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHdCQUF3QixJQUFJLFFBQVEsVUFBVSxNQUFNLEdBQUksQ0FBQztHQUNsSixTQUFTLFFBQVEsUUFBUSxjQUFjLFNBQVNBLHFCQUFhLGNBQWMsVUFBVSxvQkFBb0IsSUFBSSxRQUFRLE1BQU0sTUFBTSxHQUFJLENBQUM7R0FDdEksU0FBUyxRQUFRLFFBQVEsYUFBYSxTQUFTQSxxQkFBYSxjQUFjLFVBQVUsbUJBQW1CLElBQUksUUFBUSxLQUFLLE1BQU0sR0FBSSxDQUFDO0dBQ25JLFNBQVMsUUFBUSxRQUFRLGdCQUFnQixTQUFTQSxxQkFBYSxjQUFjLFVBQVUsc0JBQXNCLElBQUksUUFBUSxRQUFRLE1BQU0sR0FBSSxDQUFDO0dBQzVJLFNBQVMsUUFBUSxRQUFRLGdCQUFnQixTQUFTQSxxQkFBYSxjQUFjLFVBQVUsc0JBQXNCLElBQUksUUFBUSxRQUFRLE1BQU0sR0FBSSxDQUFDO0dBQzVJLE1BQU0sNEJBQTRCLGFBQWEsU0FBU0Qsb0JBQVksY0FBYyxVQUFVLDRCQUE0QixJQUFJLFFBQVEsV0FBVyxTQUFTLEtBQU0sSUFDNUpFLHNCQUFjLFFBQVEsV0FBVyxTQUFTLEVBQUc7R0FDL0MsU0FBUyxRQUFRLGlCQUFpQixNQUFNLHlCQUF5QjtHQUNqRSxTQUFTLFFBQVEsaUJBQWlCLFNBQVMsYUFBYSxhQUFhLEtBQUssS0FBSyxVQUFVLFFBQVEsZ0JBQWdCLHlCQUF5QixDQUFDLENBQUM7R0FDNUksU0FBUyxRQUFRLGlCQUFpQixjQUFjQSxzQkFBYyxRQUFRLFdBQVcsT0FBTyxHQUFJLENBQUM7R0FDN0YsU0FBUyxRQUFRLGVBQWUsVUFBVSxlQUFlLGtCQUFrQixDQUFDO0dBQzVFLFNBQVMsUUFBUSxhQUFhLFVBQVUsZUFBZSxrQkFBa0IsQ0FBQztHQUMxRSxTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsZUFBZSxzQkFBc0IsQ0FBQztHQUMvRSxTQUFTLFFBQVEsUUFBUSx3QkFBd0IsZUFBZSxrQkFBa0IsQ0FBQztHQUNuRixTQUFTLFFBQVEsUUFBUSx3QkFBd0IsU0FBU0QscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNwSixTQUFTLFFBQVEsUUFBUSwwQkFBMEIsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHdCQUF3QixJQUFJLFFBQVEsVUFBVSxNQUFNLEdBQUksQ0FBQztHQUMxSixTQUFTLFFBQVEsUUFBUSxzQkFBc0IsU0FBU0EscUJBQWEsY0FBYyxVQUFVLG9CQUFvQixJQUFJLFFBQVEsTUFBTSxNQUFNLEdBQUksQ0FBQztHQUM5SSxTQUFTLFFBQVEsUUFBUSxxQkFBcUIsU0FBU0EscUJBQWEsY0FBYyxVQUFVLG1CQUFtQixJQUFJLFFBQVEsS0FBSyxNQUFNLEdBQUksQ0FBQztHQUMzSSxTQUFTLFFBQVEsUUFBUSx3QkFBd0IsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNwSixTQUFTLFFBQVEsUUFBUSx3QkFBd0IsU0FBU0EscUJBQWEsY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUksQ0FBQztHQUNwSixTQUFTLFFBQVEsV0FBVyxVQUFVLFNBQVNBLHFCQUFhRixrQkFBVSxjQUFjLFVBQVUsaUJBQWlCLElBQUksUUFBUSxTQUFTLENBQUMsR0FBRyxHQUFJLENBQUM7R0FDN0ksU0FBUyxRQUFRLFNBQVMsTUFBTSxTQUFTQSxtQkFBVyxjQUFjLFVBQVUsa0JBQWtCLElBQUksUUFBUSxLQUFLLE1BQU0sR0FBSSxDQUFDO0VBQzVIO0VBQ0EsSUFBSSxRQUFRLFNBQVMsUUFBUTtHQUMzQixTQUFTLFFBQVEsT0FBTyxjQUFjLFNBQVNFLHFCQUFhLGNBQWMsVUFBVSxxQkFBcUIsSUFBSSxRQUFRLE1BQU0sT0FBTyxFQUFHLENBQUM7R0FDdEksU0FBUyxRQUFRLE9BQU8sYUFBYSxTQUFTQSxxQkFBYSxjQUFjLFVBQVUsb0JBQW9CLElBQUksUUFBUSxLQUFLLE9BQU8sRUFBRyxDQUFDO0dBQ25JLFNBQVMsUUFBUSxPQUFPLGdCQUFnQixTQUFTQSxxQkFBYSxjQUFjLFVBQVUsdUJBQXVCLElBQUksUUFBUSxRQUFRLE9BQU8sRUFBRyxDQUFDO0dBQzVJLFNBQVMsUUFBUSxPQUFPLGdCQUFnQixTQUFTQSxxQkFBYSxjQUFjLFVBQVUsdUJBQXVCLElBQUksUUFBUSxRQUFRLE9BQU8sRUFBRyxDQUFDO0dBQzVJLFNBQVMsUUFBUSxPQUFPLGlCQUFpQixlQUFlLG9CQUFvQixDQUFDO0dBQzdFLFNBQVMsUUFBUSxPQUFPLGdCQUFnQixlQUFlLG1CQUFtQixDQUFDO0dBQzNFLFNBQVMsUUFBUSxPQUFPLG1CQUFtQixlQUFlLHNCQUFzQixDQUFDO0dBQ2pGLFNBQVMsUUFBUSxPQUFPLG1CQUFtQixlQUFlLHNCQUFzQixDQUFDO0dBQ2pGLFNBQVMsUUFBUSxPQUFPLG9CQUFvQixhQUFhLFFBQVEsZ0JBQWdCLFFBQVEsTUFBTSxJQUFJLENBQUMsQ0FBQztHQUNyRyxTQUFTLFFBQVEsT0FBTyxtQkFBbUIsYUFBYSxRQUFRLGdCQUFnQixRQUFRLEtBQUssSUFBSSxDQUFDLENBQUM7R0FDbkcsU0FBUyxRQUFRLE9BQU8sc0JBQXNCLGFBQWEsUUFBUSxnQkFBZ0IsUUFBUSxRQUFRLElBQUksQ0FBQyxDQUFDO0dBQ3pHLFNBQVMsUUFBUSxPQUFPLHNCQUFzQixhQUFhLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUSxJQUFJLENBQUMsQ0FBQztHQUN6RyxTQUFTLFFBQVEsT0FBTyxtQkFBbUIsU0FBU0Qsb0JBQVksY0FBYyxVQUFVLHFCQUFxQixJQUFJLFFBQVEsTUFBTSxPQUFPLEVBQUcsQ0FBQztHQUMxSSxTQUFTLFFBQVEsT0FBTyxrQkFBa0IsU0FBU0Esb0JBQVksY0FBYyxVQUFVLG9CQUFvQixJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUcsQ0FBQztHQUN2SSxTQUFTLFFBQVEsT0FBTyxxQkFBcUIsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxPQUFPLEVBQUcsQ0FBQztHQUNoSixTQUFTLFFBQVEsT0FBTyxxQkFBcUIsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxPQUFPLEVBQUcsQ0FBQztHQUNoSixTQUFTLFFBQVEsT0FBTyxrQkFBa0IsZUFBZSxvQkFBb0IsQ0FBQztHQUM5RSxTQUFTLFFBQVEsT0FBTyxpQkFBaUIsZUFBZSxtQkFBbUIsQ0FBQztHQUM1RSxTQUFTLFFBQVEsT0FBTyxvQkFBb0IsZUFBZSxzQkFBc0IsQ0FBQztHQUNsRixTQUFTLFFBQVEsT0FBTyxvQkFBb0IsZUFBZSxzQkFBc0IsQ0FBQztHQUNsRixTQUFTLFFBQVEsUUFBUSxhQUFhLGVBQWUsa0JBQWtCLENBQUM7R0FDeEUsU0FBUyxRQUFRLFFBQVEsVUFBVSxlQUFlLDBCQUEwQixDQUFDO0dBQzdFLFNBQVMsUUFBUSxRQUFRLGFBQWEsZUFBZSxzQkFBc0IsQ0FBQztHQUM1RSxTQUFTLFFBQVEsUUFBUSxhQUFhLGVBQWUsa0JBQWtCLENBQUM7R0FDeEUsU0FBUyxRQUFRLFFBQVEsc0JBQXNCLGVBQWUsa0JBQWtCLENBQUM7R0FDakYsU0FBUyxRQUFRLFFBQVEsMkJBQTJCLGVBQWUsa0JBQWtCLENBQUM7R0FDdEYsU0FBUyxRQUFRLE1BQU0saUJBQWlCLGVBQWUsa0JBQWtCLENBQUM7R0FDMUUsU0FBUyxRQUFRLE1BQU0sc0JBQXNCLGVBQWUsa0JBQWtCLENBQUM7R0FDL0UsU0FBUyxRQUFRLE1BQU0sb0JBQW9CLGVBQWUsa0JBQWtCLENBQUM7R0FDN0UsU0FBUyxRQUFRLGFBQWEsTUFBTSwyQkFBMkI7R0FDL0QsU0FBUyxRQUFRLGFBQWEsV0FBVywyQkFBMkI7R0FDcEUsU0FBUyxRQUFRLGFBQWEsY0FBYywyQkFBMkI7R0FDdkUsU0FBUyxRQUFRLGdCQUFnQixhQUFhLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxFQUFHLENBQUM7R0FDL0ksU0FBUyxRQUFRLGdCQUFnQixlQUFlLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSx3QkFBd0IsSUFBSSxRQUFRLFVBQVUsTUFBTSxFQUFHLENBQUM7R0FDckosU0FBUyxRQUFRLGdCQUFnQixXQUFXLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxvQkFBb0IsSUFBSSxRQUFRLE1BQU0sTUFBTSxFQUFHLENBQUM7R0FDekksU0FBUyxRQUFRLGdCQUFnQixVQUFVLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxtQkFBbUIsSUFBSSxRQUFRLEtBQUssTUFBTSxFQUFHLENBQUM7R0FDdEksU0FBUyxRQUFRLGdCQUFnQixhQUFhLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxFQUFHLENBQUM7R0FDL0ksU0FBUyxRQUFRLGdCQUFnQixhQUFhLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxFQUFHLENBQUM7R0FDL0ksU0FBUyxRQUFRLFVBQVUsTUFBTSxhQUFhLFNBQVNELG1CQUFXLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLEtBQUssU0FBUyxHQUFJLElBQUksUUFBUSxlQUFlLDZCQUE2QixFQUFFLFNBQVM7R0FDak4sU0FBUyxRQUFRLFFBQVEsZ0JBQWdCLFNBQVNDLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxFQUFHLENBQUM7R0FDMUksU0FBUyxRQUFRLFFBQVEsa0JBQWtCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSx3QkFBd0IsSUFBSSxRQUFRLFVBQVUsTUFBTSxFQUFHLENBQUM7R0FDaEosU0FBUyxRQUFRLFFBQVEsY0FBYyxTQUFTQSxvQkFBWSxjQUFjLFVBQVUsb0JBQW9CLElBQUksUUFBUSxNQUFNLE1BQU0sRUFBRyxDQUFDO0dBQ3BJLFNBQVMsUUFBUSxRQUFRLGFBQWEsU0FBU0Esb0JBQVksY0FBYyxVQUFVLG1CQUFtQixJQUFJLFFBQVEsS0FBSyxNQUFNLEVBQUcsQ0FBQztHQUNqSSxTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHNCQUFzQixJQUFJLFFBQVEsUUFBUSxNQUFNLEVBQUcsQ0FBQztHQUMxSSxTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsU0FBU0Esb0JBQVksY0FBYyxVQUFVLHVCQUF1QixJQUFJLFFBQVEsUUFBUSxNQUFNLEVBQUcsQ0FBQztHQUMzSSxNQUFNLDRCQUE0QixhQUFhLFNBQVNDLHFCQUFhLGNBQWMsVUFBVSw0QkFBNEIsSUFBSSxRQUFRLFdBQVcsU0FBUyxJQUFLLElBQzVKQyxzQkFBYyxRQUFRLFdBQVcsU0FBUyxHQUFJO0dBQ2hELFNBQVMsUUFBUSxpQkFBaUIsTUFBTSx5QkFBeUI7R0FDakUsU0FBUyxRQUFRLGlCQUFpQixTQUFTLGFBQWEsYUFBYSxNQUFNLEtBQUssVUFBVSxRQUFRLGdCQUFnQix5QkFBeUIsQ0FBQyxDQUFDO0dBQzdJLFNBQVMsUUFBUSxpQkFBaUIsY0FBY0Esc0JBQWMsUUFBUSxXQUFXLE9BQU8sR0FBSSxDQUFDO0dBQzdGLFNBQVMsUUFBUSxlQUFlLFVBQVUsZUFBZSxrQkFBa0IsQ0FBQztHQUM1RSxTQUFTLFFBQVEsYUFBYSxVQUFVLGVBQWUsa0JBQWtCLENBQUM7R0FDMUUsU0FBUyxRQUFRLFFBQVEsZ0JBQWdCLGVBQWUsa0JBQWtCLENBQUM7R0FDM0UsU0FBUyxRQUFRLFFBQVEsd0JBQXdCLGVBQWUsa0JBQWtCLENBQUM7R0FDbkYsU0FBUyxRQUFRLFFBQVEsd0JBQXdCLFNBQVNGLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxHQUFJLENBQUM7R0FDbkosU0FBUyxRQUFRLFFBQVEsMEJBQTBCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSx3QkFBd0IsSUFBSSxRQUFRLFVBQVUsTUFBTSxHQUFJLENBQUM7R0FDekosU0FBUyxRQUFRLFFBQVEsc0JBQXNCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxvQkFBb0IsSUFBSSxRQUFRLE1BQU0sTUFBTSxHQUFJLENBQUM7R0FDN0ksU0FBUyxRQUFRLFFBQVEscUJBQXFCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxtQkFBbUIsSUFBSSxRQUFRLEtBQUssTUFBTSxHQUFJLENBQUM7R0FDMUksU0FBUyxRQUFRLFFBQVEsd0JBQXdCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSxzQkFBc0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxHQUFJLENBQUM7R0FDbkosU0FBUyxRQUFRLFFBQVEsd0JBQXdCLFNBQVNBLG9CQUFZLGNBQWMsVUFBVSx1QkFBdUIsSUFBSSxRQUFRLFFBQVEsTUFBTSxHQUFJLENBQUM7R0FDcEosU0FBUyxRQUFRLFdBQVcsVUFBVSxTQUFTQSxvQkFBWUQsa0JBQVUsY0FBYyxVQUFVLGlCQUFpQixJQUFJLFFBQVEsU0FBUyxDQUFDLEdBQUcsR0FBSSxDQUFDO0dBQzVJLFNBQVMsUUFBUSxTQUFTLE1BQU0sU0FBU0EsbUJBQVcsY0FBYyxVQUFVLGtCQUFrQixJQUFJLFFBQVEsS0FBSyxNQUFNLEdBQUksQ0FBQztFQUM1SDtFQUNBLElBQUksQ0FBQyxhQUFhO0dBQ2hCLGdCQUFnQixRQUFRLFlBQVksU0FBUztHQUc3QyxnQkFBZ0IsUUFBUSxZQUFZLE9BQU87R0FDM0MsZ0JBQWdCLFFBQVEsUUFBUSxZQUFZO0dBQzVDLGdCQUFnQixRQUFRLFFBQVEsY0FBYztHQUM5QyxnQkFBZ0IsU0FBUyxTQUFTO0VBQ3BDO0VBQ0EsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVEsVUFBUztHQUNwQyxNQUFNLFNBQVMsUUFBUTtHQUl2QixJQUFJLFVBQVUsaUJBQWlCLENBQUMsZUFBZSxVQUFVLE9BQU8sV0FBVyxVQUFVO0lBRW5GLElBQUksT0FBTyxNQUNULFNBQVMsUUFBUSxRQUFRLGVBQWVKLHlCQUFpQixNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFFOUUsSUFBSSxPQUFPLE9BQ1QsU0FBUyxRQUFRLFFBQVEsZ0JBQWdCQSx5QkFBaUIsTUFBTSxPQUFPLEtBQUssQ0FBQyxDQUFDO0lBRWhGLElBQUksT0FBTyxNQUNULFNBQVMsUUFBUSxRQUFRLGVBQWVBLHlCQUFpQixNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFFOUUsSUFBSSxPQUFPLGNBQ1QsU0FBUyxRQUFRLFFBQVEsdUJBQXVCQSx5QkFBaUIsTUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0lBRTlGLElBQUksVUFBVSxRQUFRO0tBRXBCLGdCQUFnQixRQUFRLFFBQVEsU0FBUztLQUN6QyxnQkFBZ0IsUUFBUSxRQUFRLFdBQVc7SUFDN0M7SUFDQSxJQUFJLFVBQVUsVUFBVTtLQUV0QixJQUFJLE9BQU8sUUFDVCxnQkFBZ0IsUUFBUSxRQUFRLFFBQVE7S0FFMUMsSUFBSSxPQUFPLFVBQ1QsZ0JBQWdCLFFBQVEsUUFBUSxVQUFVO0lBRTlDO0dBQ0Y7RUFDRixDQUFDO0NBQ0gsQ0FBQztDQUNELFFBQVEsS0FBSyxRQUFRLEtBQUssYUFBYSxVQUFVLEtBQUssUUFBUSxHQUFHLEtBQUs7Q0FDdEUsTUFBTSxlQUFlO0VBQ25CLFFBQVE7RUFDUjtFQUNBLHlCQUFBO0VBQ0EsYUFBYVEsMEJBQW1CLEtBQUs7RUFDckMsb0JBQW9CO0NBQ3RCO0NBQ0EsTUFBTSxFQUNKLE1BQ0EsbUJBQ0Esd0JBQ0UsZUFBZSxPQUFPLFlBQVk7Q0FDdEMsTUFBTSxPQUFPO0NBQ2IsT0FBTyxRQUFRLE1BQU0sYUFBYSxNQUFNLG1CQUFtQixDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVztFQUNyRixNQUFNLE9BQU87Q0FDZixDQUFDO0NBQ0QsTUFBTSxvQkFBb0I7Q0FDMUIsTUFBTSxzQkFBc0I7Q0FDNUIsTUFBTSxrQkFBa0IsU0FBUyxrQkFBa0I7RUFDakQsT0FBTyxjQUFjLE1BQU0sU0FBUyxtQkFBbUIsSUFBSSxDQUFDO0NBQzlEO0NBQ0EsTUFBTSx5QkFBeUIsNkJBQTZCLFFBQVE7Q0FDcEUsTUFBTSxVQUFVLE1BQU0sZ0JBQWdCO0NBQ3RDLE1BQU0sMEJBQTBCQztDQUNoQyxNQUFNLG9CQUFvQjtFQUN4QixHQUFHO0VBQ0gsR0FBRyxPQUFPO0NBQ1o7Q0FDQSxNQUFNLGNBQWMsU0FBUyxHQUFHLE9BQU87RUFDckMsT0FBT0Msd0JBQWdCO0dBQ3JCLElBQUk7R0FDSixPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixNQUFNLGtCQUFrQjtDQUV4QixPQUFPO0FBQ1Q7OztBQzNaQSxTQUFTLGtCQUFrQixPQUFPLFFBQVEsYUFBYTtDQUNyRCxJQUFJLENBQUMsTUFBTSxjQUNUO0NBRUYsSUFBSSxhQUNGLE1BQU0sYUFBYSxVQUFVO0VBQzNCLEdBQUksZ0JBQWdCLFFBQVE7RUFDNUIsU0FBUyxjQUFjO0dBQ3JCLEdBQUksZ0JBQWdCLE9BQU8sQ0FBQyxJQUFJLFlBQVk7R0FDNUMsTUFBTTtFQUNSLENBQUM7Q0FDSDtBQUVKOzs7Ozs7O0FBUUEsU0FBd0IsWUFBWSxVQUFVLENBQUMsR0FFL0MsR0FBRyxNQUFNO0NBQ1AsTUFBTSxFQUNKLFNBQ0EsZUFBZSxPQUNmLGNBQWMsc0JBQXNCLENBQUMsVUFBVSxFQUM3QyxPQUFPLEtBQ1QsSUFBSSxLQUFBLEdBQ0osb0JBQW9CLDRCQUE0QixTQUFTLE1BQ3pELEdBQUcsVUFDRDtDQUNKLE1BQU0sMEJBQTBCLDZCQUE2QjtDQUM3RCxNQUFNLGdCQUFnQixzQkFBc0I7Q0FDNUMsTUFBTSxvQkFBb0I7RUFDeEIsR0FBRztFQUNILEdBQUksVUFBVSxHQUNYLDBCQUEwQjtHQUN6QixHQUFJLE9BQU8sa0JBQWtCLGFBQWE7R0FDMUM7RUFDRixFQUNGLElBQUksS0FBQTtDQUNOO0NBQ0EsSUFBSSxpQkFBaUIsT0FBTztFQUMxQixJQUFJLEVBQUUsa0JBQWtCLFVBRXRCLE9BQU8sa0JBQWtCLFNBQVMsR0FBRyxJQUFJO0VBRTNDLElBQUksaUJBQWlCO0VBQ3JCLElBQUksRUFBRSxhQUFhO09BQ2Isa0JBQWtCO1FBQ2hCLGtCQUFrQiw2QkFBNkIsTUFDakQsaUJBQWlCLGtCQUFrQix3QkFBd0IsQ0FBQztTQUN2RCxJQUFJLDRCQUE0QixRQUVyQyxpQkFBaUIsRUFDZixNQUFNLE9BQ1I7R0FBQTtFQUNGO0VBR0osTUFBTSxRQUFRLGtCQUFrQjtHQUM5QixHQUFHO0dBQ0gsU0FBUztFQUNYLEdBQUcsR0FBRyxJQUFJO0VBQ1YsTUFBTSxxQkFBcUI7RUFDM0IsTUFBTSxlQUFlO0VBQ3JCLElBQUksTUFBTSxRQUFRLFNBQVMsU0FBUztHQUNsQyxNQUFNLGFBQWEsUUFBUTtJQUN6QixHQUFJLGtCQUFrQixVQUFVLFFBQVEsa0JBQWtCO0lBQzFELFNBQVMsTUFBTTtHQUNqQjtHQUNBLGtCQUFrQixPQUFPLFFBQVEsa0JBQWtCLElBQUk7RUFDekQ7RUFDQSxJQUFJLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDakMsTUFBTSxhQUFhLE9BQU87SUFDeEIsR0FBSSxrQkFBa0IsU0FBUyxRQUFRLGtCQUFrQjtJQUN6RCxTQUFTLE1BQU07R0FDakI7R0FDQSxrQkFBa0IsT0FBTyxTQUFTLGtCQUFrQixLQUFLO0VBQzNEO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLHNCQUFzQiw0QkFBNEIsU0FDN0Usa0JBQWtCLFFBQVE7Q0FFNUIsT0FBTyxvQkFBb0I7RUFDekIsR0FBRztFQUNILGNBQWM7RUFDZCxvQkFBb0I7RUFDcEIsR0FBSSxPQUFPLGlCQUFpQixhQUFhO0NBQzNDLEdBQUcsR0FBRyxJQUFJO0FBQ1o7OztBQzlGQSxJQUFNLGVBQWUsWUFBWTs7O0FDSGpDLElBQUEscUJBQWU7OztBQ0NmLFNBQVMsc0JBQXNCLE1BQU07Q0FDbkMsT0FBTyxTQUFTLGdCQUFnQixTQUFTLFdBQVcsU0FBUyxRQUFRLFNBQVM7QUFDaEY7OztBQ0ZBLElBQU0seUJBQXdCLFNBQVEsc0JBQXNCLElBQUksS0FBSyxTQUFTOzs7QUNPOUUsSUFBTSxTQUFTLGFBQWE7Q0FDMUIsU0FBU0M7Q0FDVDtDQUNBO0FBQ0YsQ0FBQzs7O0FDWEQsSUFBTSxZQUFZOzs7QUNLbEIsU0FBUyxxQkFBcUIsT0FBTztDQUNuQyxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLQyx3QkFBNEIsRUFDbkQsR0FBRyxNQUNMLENBQUM7QUFDSDtBQUN3QyxxQkFBcUIsWUFBbUM7Ozs7Q0FROUYsVUFBVUMsa0JBQUFBLFFBQVU7Ozs7Q0FJcEIsT0FBT0Esa0JBQUFBLFFBQVUsT0FBTztBQUMxQjtBQUVBLFNBQWdCLGdCQUFnQixRQUFRO0NBQ3RDLE9BQU9DLGtCQUFzQixNQUFNO0FBQ3JDOzs7QUMxQkEsU0FBZ0IsdUJBQXVCLE1BQU07Q0FDM0MsT0FBTyxxQkFBcUIsY0FBYyxJQUFJO0FBQ2hEO0FBQ0EsSUFBTSxpQkFBaUIsdUJBQXVCLGNBQWM7Q0FBQztDQUFRO0NBQWdCO0NBQWtCO0NBQWU7Q0FBYztDQUFpQjtDQUFtQjtDQUFpQjtDQUFrQjtBQUFlLENBQUM7OztBQ0wzTixJQUFhLGdCQUFnQixFQUMzQixZQUFZLE9BQ2Q7QUFDQSxTQUFnQiwyQkFBMkIsZUFBZSxRQUFRO0NBQ2hFLElBQUksa0JBQWtCLFVBQ3BCLE9BQU87Q0FFVCxJQUFJLGtCQUFrQixVQUNwQixPQUFPLEVBQ0wsMkNBQTJDLE9BQzdDO0NBRUYsT0FBTztBQUNUOzs7QUNaQSxJQUFhLFVBQVMsU0FBUSxLQUFLO0FBQ25DLElBQU0sMkJBQTJCO0NBQy9CLFNBQVM7Q0FDVCxTQUFTO0FBQ1g7QUFDQSxJQUFNLGNBQWMsQ0FBQztBQUNyQixJQUFNLDJCQUEyQixDQUFDLEtBQUs7QUFDdkMsSUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixJQUFNLHlCQUF5QjtDQUM3QixRQUFRLENBQUMsR0FBRyxDQUFDO0NBQ2IsVUFBVSxDQUFDLElBQUksRUFBRTtDQUNqQixXQUFXLENBQUMsR0FBRyxDQUFDO0NBQ2hCLGFBQWEsQ0FBQyxHQUFHLENBQUM7Q0FDbEIsWUFBWSxDQUFDLEdBQUcsSUFBSTtDQUNwQixZQUFZLENBQUMsTUFBTSxDQUFDO0FBQ3RCO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxNQUFNLGNBQWMsV0FBVyxTQUFTLEVBQUU7Q0FDMUMsT0FBTyxPQUFPLE1BQU0sV0FBVyxJQUFJLElBQUk7QUFDekM7QUFDQSxTQUFTLGVBQWUsV0FBVztDQUNqQyxNQUFNLFFBQVEsVUFBVSxNQUFNLHlFQUF5RTtDQUN2RyxJQUFJLENBQUMsT0FDSCxPQUFPO0NBRVQsT0FBTztFQUNMLE1BQU0sTUFBTTtFQUNaLFFBQVEsTUFBTSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLG1CQUFtQjtDQUNyRDtBQUNGO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUSxPQUFPO0NBQzlDLE9BQU8sVUFBVSxPQUFPLElBQUksT0FBTyxVQUFVO0FBQy9DOzs7Ozs7Ozs7Ozs7O0FBY0EsU0FBZ0Isb0JBQW9CLFdBQVc7Q0FDN0MsSUFBSSxDQUFDLGFBQWEsY0FBYyxRQUM5QixPQUFPO0NBRVQsTUFBTSxrQkFBa0IsZUFBZSxTQUFTO0NBQ2hELElBQUksQ0FBQyxpQkFDSCxPQUFPO0NBRVQsTUFBTSxFQUNKLE1BQ0EsV0FDRTtDQUNKLE1BQU0sZ0JBQWdCLHVCQUF1QjtDQUM3QyxJQUFJLENBQUMsZUFDSCxPQUFPO0NBRVQsT0FBTztFQUNMLFNBQVMsd0JBQXdCLFFBQVEsY0FBYyxFQUFFO0VBQ3pELFNBQVMsd0JBQXdCLFFBQVEsY0FBYyxFQUFFO0NBQzNEO0FBQ0Y7QUFDQSxTQUFnQiw2QkFBNkIsU0FBUyxVQUFVO0NBQzlELFFBQU8scUJBQW9CO0VBQ3pCLElBQUksVUFBVTtHQUNaLE1BQU0sT0FBTyxRQUFRO0dBRXJCLElBQUkscUJBQXFCLEtBQUEsR0FDdkIsU0FBUyxJQUFJO1FBRWIsU0FBUyxNQUFNLGdCQUFnQjtFQUVuQztDQUNGO0FBQ0Y7Ozs7O0FBS0EsU0FBZ0Isd0JBQXdCLE9BQU8sUUFBUSxZQUFZLGNBQWMsV0FBVyxZQUFZO0NBQ3RHLE1BQU0sT0FBTyxVQUFVLFlBQVksQ0FBQyxTQUFTLGVBQWUsV0FBVyxVQUFVLFdBQVc7Q0FDNUYsT0FBTyxhQUFhLGFBQWE7RUFDL0IsR0FBRztFQUNILEdBQUc7RUFDSCxHQUFHO0NBQ0wsSUFBSTtBQUNOO0FBQ0EsU0FBZ0IsbUJBQW1CLE9BQU8sU0FBUztDQUNqRCxNQUFNLEVBQ0osU0FDQSxRQUNBLFFBQVEsZ0JBQ047Q0FDSixPQUFPO0VBQ0wsVUFBVSxNQUFNLHVCQUF1QixPQUFPLFlBQVksV0FBVyxVQUFVLFFBQVEsUUFBUSxTQUFTO0VBQ3hHLFFBQVEsTUFBTSw2QkFBNkIsT0FBTyxXQUFXLFdBQVcsT0FBTyxRQUFRLFFBQVE7RUFDL0YsT0FBTyxNQUFNO0NBQ2Y7QUFDRjs7Ozs7QUFNQSxTQUFnQix1QkFBdUIsT0FBTyxRQUFRO0NBQ3BELE1BQU0saUJBQWlCLFVBQVU7Q0FDakMsT0FBTywyQkFBMkIsTUFBTSxRQUFRLGVBQWUsY0FBYztBQUMvRTtBQUNBLFNBQWdCLG9CQUFvQixPQUFPLFFBQVEsMEJBQTBCLFVBQVUsZUFBZTtDQUNwRyxNQUFNLGFBQWEsTUFBTSxhQUFhLFNBQVMsT0FBTyxPQUFPO0NBQzdELE1BQU0sc0JBQXNCLHVCQUF1QixLQUFLO0NBQ3hELElBQUksZUFBZSxLQUFBLEdBQ2pCLE9BQU8sdUJBQXVCO0NBRWhDLE1BQU0sbUJBQW1CLEVBQ3ZCLFdBQ0Y7Q0FDQSxPQUFPLHNCQUFzQjtFQUMzQixHQUFHO0VBQ0gsR0FBRztDQUNMLElBQUk7QUFDTjs7O0FDbEhBLElBQU0scUJBQW9CLGVBQWM7Q0FDdEMsTUFBTSxFQUNKLE9BQ0EsVUFDQSxZQUNFO0NBSUosT0FBTyxlQUFlLEVBRnBCLE1BQU07RUFBQztFQUFRLFVBQVUsYUFBYSxRQUFRQyxtQkFBVyxLQUFLO0VBQUssV0FBV0EsbUJBQVcsUUFBUTtDQUFHLEVBRTVFLEdBQUcsd0JBQXdCLE9BQU87QUFDOUQ7QUFDQSxJQUFNLGNBQWMsT0FBTyxPQUFPO0NBQ2hDLE1BQU07Q0FDTixNQUFNO0NBQ04sb0JBQW9CLE9BQU8sV0FBVztFQUNwQyxNQUFNLEVBQ0osZUFDRTtFQUNKLE9BQU87R0FBQyxPQUFPO0dBQU0sV0FBVyxVQUFVLGFBQWEsT0FBTyxRQUFRQSxtQkFBVyxXQUFXLEtBQUs7R0FBTSxPQUFPLFdBQVdBLG1CQUFXLFdBQVcsUUFBUTtFQUFJO0NBQzdKO0FBQ0YsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUNaLGFBQ0s7Q0FDTCxZQUFZO0NBQ1osT0FBTztDQUNQLFFBQVE7Q0FDUixTQUFTO0NBQ1QsWUFBWTtDQUNaLEdBQUcsb0JBQW9CLE9BQU8sUUFBUSxFQUNwQyxXQUFXLE1BQU0sUUFBUSxNQUFBLENBQU8sYUFBYSxVQUFVLFFBQ3pELENBQUM7Q0FDRCxVQUFVO0VBQUM7R0FDVCxRQUFPLFVBQVMsQ0FBQyxNQUFNO0dBQ3ZCLE9BQU8sRUFHTCxNQUFNLGVBQ1I7RUFDRjtFQUFHO0dBQ0QsT0FBTyxFQUNMLFVBQVUsVUFDWjtHQUNBLE9BQU8sRUFDTCxVQUFVLFVBQ1o7RUFDRjtFQUFHO0dBQ0QsT0FBTyxFQUNMLFVBQVUsUUFDWjtHQUNBLE9BQU8sRUFDTCxVQUFVLE1BQU0sWUFBWSxVQUFVLEVBQUUsS0FBSyxVQUMvQztFQUNGO0VBQUc7R0FDRCxPQUFPLEVBQ0wsVUFBVSxTQUNaO0dBQ0EsT0FBTyxFQUNMLFVBQVUsTUFBTSxZQUFZLFVBQVUsRUFBRSxLQUFLLFNBQy9DO0VBQ0Y7RUFBRztHQUNELE9BQU8sRUFDTCxVQUFVLFFBQ1o7R0FDQSxPQUFPLEVBQ0wsVUFBVSxNQUFNLFlBQVksVUFBVSxFQUFFLEtBQUssWUFDL0M7RUFDRjtFQUVBLEdBQUcsT0FBTyxTQUFTLE1BQU0sUUFBUSxNQUFBLENBQU8sT0FBTyxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsU0FBUyxNQUFNLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZO0dBQzVHLE9BQU8sRUFDTCxNQUNGO0dBQ0EsT0FBTyxFQUNMLFFBQVEsTUFBTSxRQUFRLE1BQUEsQ0FBTyxVQUFVLE1BQU0sRUFBRSxLQUNqRDtFQUNGLEVBQUU7RUFBRztHQUNILE9BQU8sRUFDTCxPQUFPLFNBQ1Q7R0FDQSxPQUFPLEVBQ0wsUUFBUSxNQUFNLFFBQVEsTUFBQSxDQUFPLFNBQVMsUUFBUSxPQUNoRDtFQUNGO0VBQUc7R0FDRCxPQUFPLEVBQ0wsT0FBTyxXQUNUO0dBQ0EsT0FBTyxFQUNMLFFBQVEsTUFBTSxRQUFRLE1BQUEsQ0FBTyxTQUFTLFFBQVEsU0FDaEQ7RUFDRjtFQUFHO0dBQ0QsT0FBTyxFQUNMLE9BQU8sVUFDVDtHQUNBLE9BQU8sRUFDTCxPQUFPLEtBQUEsRUFDVDtFQUNGO0NBQUM7QUFDSCxFQUFFLENBQUM7QUFDSCxJQUFNLFVBQXVCLDJCQUFNLFdBQVcsU0FBUyxRQUFRLFNBQVMsS0FBSztDQUMzRSxNQUFNLFFBQVEsZ0JBQWdCO0VBQzVCLE9BQU87RUFDUCxNQUFNO0NBQ1IsQ0FBQztDQUNELE1BQU0sRUFDSixVQUNBLFdBQ0EsUUFBUSxXQUNSLFlBQVksT0FDWixXQUFXLFVBQ1gsV0FDQSxpQkFBaUIsT0FDakIsYUFDQSxVQUFVLGFBQ1YsR0FBRyxVQUNEO0NBQ0osTUFBTSxnQkFBNkIsMkJBQU0sZUFBZSxRQUFRLEtBQUssU0FBUyxTQUFTO0NBQ3ZGLE1BQU0sYUFBYTtFQUNqQixHQUFHO0VBQ0g7RUFDQTtFQUNBO0VBQ0Esa0JBQWtCLFFBQVE7RUFDMUI7RUFDQTtFQUNBO0NBQ0Y7Q0FDQSxNQUFNLE9BQU8sQ0FBQztDQUNkLElBQUksQ0FBQyxnQkFDSCxLQUFLLFVBQVU7Q0FFakIsTUFBTSxVQUFVLGtCQUFrQixVQUFVO0NBQzVDLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxLQUFBLENBQU0sYUFBYTtFQUNyQyxJQUFJO0VBQ0osV0FBVyxLQUFLLFFBQVEsTUFBTSxTQUFTO0VBQ3ZDLFdBQVc7RUFDWCxPQUFPO0VBQ1AsZUFBZSxjQUFjLEtBQUEsSUFBWTtFQUN6QyxNQUFNLGNBQWMsUUFBUSxLQUFBO0VBQ3ZCO0VBQ0wsR0FBRztFQUNILEdBQUc7RUFDSCxHQUFJLGlCQUFpQixTQUFTO0VBQ2xCO0VBQ1osVUFBVSxDQUFDLGdCQUFnQixTQUFTLE1BQU0sV0FBVyxVQUFVLGNBQTJCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssU0FBUyxFQUN0RyxVQUFVLFlBQ1osQ0FBQyxJQUFJLElBQUk7Q0FDWCxDQUFDO0FBQ0gsQ0FBQztBQUN1QyxRQUFRLFlBQW1DOzs7O0NBUWpGLFVBQVVDLGtCQUFBQSxRQUFVOzs7O0NBSXBCLFNBQVNBLGtCQUFBQSxRQUFVOzs7O0NBSW5CLFdBQVdBLGtCQUFBQSxRQUFVOzs7Ozs7OztDQVFyQixPQUFPQSxrQkFBQUEsUUFBZ0QsVUFBVSxDQUFDQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBVztFQUFVO0VBQVk7RUFBVztFQUFhO0VBQVM7RUFBUTtFQUFXO0NBQVMsQ0FBQyxHQUFHQSxrQkFBQUEsUUFBVSxNQUFNLENBQUM7Ozs7O0NBS3RNLFdBQVdBLGtCQUFBQSxRQUFVOzs7OztDQUtyQixVQUFVQSxrQkFBQUEsUUFBZ0QsVUFBVSxDQUFDQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBVztFQUFTO0VBQVU7Q0FBTyxDQUFDLEdBQUdBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQzs7OztDQUloSixXQUFXQSxrQkFBQUEsUUFBVTs7Ozs7Ozs7Q0FRckIsZ0JBQWdCQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTTFCLGdCQUFnQkEsa0JBQUFBLFFBQVU7Ozs7Q0FJMUIsSUFBSUEsa0JBQUFBLFFBQVUsVUFBVTtFQUFDQSxrQkFBQUEsUUFBVSxRQUFRQSxrQkFBQUEsUUFBVSxVQUFVO0dBQUNBLGtCQUFBQSxRQUFVO0dBQU1BLGtCQUFBQSxRQUFVO0dBQVFBLGtCQUFBQSxRQUFVO0VBQUksQ0FBQyxDQUFDO0VBQUdBLGtCQUFBQSxRQUFVO0VBQU1BLGtCQUFBQSxRQUFVO0NBQU0sQ0FBQzs7Ozs7Q0FLdEosYUFBYUEsa0JBQUFBLFFBQVU7Ozs7Ozs7OztDQVN2QixTQUFTQSxrQkFBQUEsUUFBVTtBQUNyQjtBQUNBLFFBQVEsVUFBVTs7Ozs7O0FDaE9sQixTQUF3QixjQUFjLE1BQU0sYUFBYTtDQUN2RCxTQUFTLFVBQVUsT0FBTyxLQUFLO0VBQzdCLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssU0FBUztHQUNoQyxlQUF1RCxHQUFHLFlBQVk7R0FDakU7R0FDTCxHQUFHO0dBQ0gsVUFBVTtFQUNaLENBQUM7Q0FDSDtDQUlFLFVBQVUsY0FBYyxHQUFHLFlBQVk7Q0FFekMsVUFBVSxVQUFVLFFBQVE7Q0FDNUIsT0FBb0IsMkJBQU0sS0FBa0IsMkJBQU0sV0FBVyxTQUFTLENBQUM7QUFDekUifQ==