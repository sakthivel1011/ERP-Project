import { i as __toESM, t as __commonJSMin } from "/ERP-Project/node_modules/.vite/deps/rolldown-runtime-B4lejLz5.js?v=15f5f1b8";
import { t as _extends } from "/ERP-Project/node_modules/.vite/deps/extends-DrH2PCIy.js?v=15f5f1b8";
import { t as warnOnce } from "/ERP-Project/node_modules/.vite/deps/warning-ci_nFDcC.js?v=15f5f1b8";
//#region node_modules/dayjs/dayjs.min.js
var require_dayjs_min = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(t, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
	})(exports, (function() {
		"use strict";
		var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = {
			name: "en",
			weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
			months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
			ordinal: function(t) {
				var e = [
					"th",
					"st",
					"nd",
					"rd"
				], n = t % 100;
				return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]";
			}
		}, m = function(t, e, n) {
			var r = String(t);
			return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
		}, v = {
			s: m,
			z: function(t) {
				var e = -t.utcOffset(), n = Math.abs(e), r = Math.floor(n / 60), i = n % 60;
				return (e <= 0 ? "+" : "-") + m(r, 2, "0") + ":" + m(i, 2, "0");
			},
			m: function t(e, n) {
				if (e.date() < n.date()) return -t(n, e);
				var r = 12 * (n.year() - e.year()) + (n.month() - e.month()), i = e.clone().add(r, c), s = n - i < 0, u = e.clone().add(r + (s ? -1 : 1), c);
				return +(-(r + (n - i) / (s ? i - u : u - i)) || 0);
			},
			a: function(t) {
				return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
			},
			p: function(t) {
				return {
					M: c,
					y: h,
					w: o,
					d: a,
					D: d,
					h: u,
					m: s,
					s: i,
					ms: r,
					Q: f
				}[t] || String(t || "").toLowerCase().replace(/s$/, "");
			},
			u: function(t) {
				return void 0 === t;
			}
		}, g = "en", D = {};
		D[g] = M;
		var p = "$isDayjsObject", S = function(t) {
			return t instanceof _ || !(!t || !t[p]);
		}, w = function t(e, n, r) {
			var i;
			if (!e) return g;
			if ("string" == typeof e) {
				var s = e.toLowerCase();
				D[s] && (i = s), n && (D[s] = n, i = s);
				var u = e.split("-");
				if (!i && u.length > 1) return t(u[0]);
			} else {
				var a = e.name;
				D[a] = e, i = a;
			}
			return !r && i && (g = i), i || !r && g;
		}, O = function(t, e) {
			if (S(t)) return t.clone();
			var n = "object" == typeof e ? e : {};
			return n.date = t, n.args = arguments, new _(n);
		}, b = v;
		b.l = w, b.i = S, b.w = function(t, e) {
			return O(t, {
				locale: e.$L,
				utc: e.$u,
				x: e.$x,
				$offset: e.$offset
			});
		};
		var _ = function() {
			function M(t) {
				this.$L = w(t.locale, null, !0), this.parse(t), this.$x = this.$x || t.x || {}, this[p] = !0;
			}
			var m = M.prototype;
			return m.parse = function(t) {
				this.$d = function(t) {
					var e = t.date, n = t.utc;
					if (null === e) return /* @__PURE__ */ new Date(NaN);
					if (b.u(e)) return /* @__PURE__ */ new Date();
					if (e instanceof Date) return new Date(e);
					if ("string" == typeof e && !/Z$/i.test(e)) {
						var r = e.match($);
						if (r) {
							var i = r[2] - 1 || 0, s = (r[7] || "0").substring(0, 3);
							return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
						}
					}
					return new Date(e);
				}(t), this.init();
			}, m.init = function() {
				var t = this.$d;
				this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
			}, m.$utils = function() {
				return b;
			}, m.isValid = function() {
				return !(this.$d.toString() === l);
			}, m.isSame = function(t, e) {
				var n = O(t);
				return this.startOf(e) <= n && n <= this.endOf(e);
			}, m.isAfter = function(t, e) {
				return O(t) < this.startOf(e);
			}, m.isBefore = function(t, e) {
				return this.endOf(e) < O(t);
			}, m.$g = function(t, e, n) {
				return b.u(t) ? this[e] : this.set(n, t);
			}, m.unix = function() {
				return Math.floor(this.valueOf() / 1e3);
			}, m.valueOf = function() {
				return this.$d.getTime();
			}, m.startOf = function(t, e) {
				var n = this, r = !!b.u(e) || e, f = b.p(t), l = function(t, e) {
					var i = b.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
					return r ? i : i.endOf(a);
				}, $ = function(t, e) {
					return b.w(n.toDate()[t].apply(n.toDate("s"), (r ? [
						0,
						0,
						0,
						0
					] : [
						23,
						59,
						59,
						999
					]).slice(e)), n);
				}, y = this.$W, M = this.$M, m = this.$D, v = "set" + (this.$u ? "UTC" : "");
				switch (f) {
					case h: return r ? l(1, 0) : l(31, 11);
					case c: return r ? l(1, M) : l(0, M + 1);
					case o:
						var g = this.$locale().weekStart || 0, D = (y < g ? y + 7 : y) - g;
						return l(r ? m - D : m + (6 - D), M);
					case a:
					case d: return $(v + "Hours", 0);
					case u: return $(v + "Minutes", 1);
					case s: return $(v + "Seconds", 2);
					case i: return $(v + "Milliseconds", 3);
					default: return this.clone();
				}
			}, m.endOf = function(t) {
				return this.startOf(t, !1);
			}, m.$set = function(t, e) {
				var n, o = b.p(t), f = "set" + (this.$u ? "UTC" : ""), l = (n = {}, n[a] = f + "Date", n[d] = f + "Date", n[c] = f + "Month", n[h] = f + "FullYear", n[u] = f + "Hours", n[s] = f + "Minutes", n[i] = f + "Seconds", n[r] = f + "Milliseconds", n)[o], $ = o === a ? this.$D + (e - this.$W) : e;
				if (o === c || o === h) {
					var y = this.clone().set(d, 1);
					y.$d[l]($), y.init(), this.$d = y.set(d, Math.min(this.$D, y.daysInMonth())).$d;
				} else l && this.$d[l]($);
				return this.init(), this;
			}, m.set = function(t, e) {
				return this.clone().$set(t, e);
			}, m.get = function(t) {
				return this[b.p(t)]();
			}, m.add = function(r, f) {
				var d, l = this;
				r = Number(r);
				var $ = b.p(f), y = function(t) {
					var e = O(l);
					return b.w(e.date(e.date() + Math.round(t * r)), l);
				};
				if ($ === c) return this.set(c, this.$M + r);
				if ($ === h) return this.set(h, this.$y + r);
				if ($ === a) return y(1);
				if ($ === o) return y(7);
				var M = (d = {}, d[s] = e, d[u] = n, d[i] = t, d)[$] || 1, m = this.$d.getTime() + r * M;
				return b.w(m, this);
			}, m.subtract = function(t, e) {
				return this.add(-1 * t, e);
			}, m.format = function(t) {
				var e = this, n = this.$locale();
				if (!this.isValid()) return n.invalidDate || l;
				var r = t || "YYYY-MM-DDTHH:mm:ssZ", i = b.z(this), s = this.$H, u = this.$m, a = this.$M, o = n.weekdays, c = n.months, f = n.meridiem, h = function(t, n, i, s) {
					return t && (t[n] || t(e, r)) || i[n].slice(0, s);
				}, d = function(t) {
					return b.s(s % 12 || 12, t, "0");
				}, $ = f || function(t, e, n) {
					var r = t < 12 ? "AM" : "PM";
					return n ? r.toLowerCase() : r;
				};
				return r.replace(y, (function(t, r) {
					return r || function(t) {
						switch (t) {
							case "YY": return String(e.$y).slice(-2);
							case "YYYY": return b.s(e.$y, 4, "0");
							case "M": return a + 1;
							case "MM": return b.s(a + 1, 2, "0");
							case "MMM": return h(n.monthsShort, a, c, 3);
							case "MMMM": return h(c, a);
							case "D": return e.$D;
							case "DD": return b.s(e.$D, 2, "0");
							case "d": return String(e.$W);
							case "dd": return h(n.weekdaysMin, e.$W, o, 2);
							case "ddd": return h(n.weekdaysShort, e.$W, o, 3);
							case "dddd": return o[e.$W];
							case "H": return String(s);
							case "HH": return b.s(s, 2, "0");
							case "h": return d(1);
							case "hh": return d(2);
							case "a": return $(s, u, !0);
							case "A": return $(s, u, !1);
							case "m": return String(u);
							case "mm": return b.s(u, 2, "0");
							case "s": return String(e.$s);
							case "ss": return b.s(e.$s, 2, "0");
							case "SSS": return b.s(e.$ms, 3, "0");
							case "Z": return i;
						}
						return null;
					}(t) || i.replace(":", "");
				}));
			}, m.utcOffset = function() {
				return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
			}, m.diff = function(r, d, l) {
				var $, y = this, M = b.p(d), m = O(r), v = (m.utcOffset() - this.utcOffset()) * e, g = this - m, D = function() {
					return b.m(y, m);
				};
				switch (M) {
					case h:
						$ = D() / 12;
						break;
					case c:
						$ = D();
						break;
					case f:
						$ = D() / 3;
						break;
					case o:
						$ = (g - v) / 6048e5;
						break;
					case a:
						$ = (g - v) / 864e5;
						break;
					case u:
						$ = g / n;
						break;
					case s:
						$ = g / e;
						break;
					case i:
						$ = g / t;
						break;
					default: $ = g;
				}
				return l ? $ : b.a($);
			}, m.daysInMonth = function() {
				return this.endOf(c).$D;
			}, m.$locale = function() {
				return D[this.$L];
			}, m.locale = function(t, e) {
				if (!t) return this.$L;
				var n = this.clone(), r = w(t, e, !0);
				return r && (n.$L = r), n;
			}, m.clone = function() {
				return b.w(this.$d, this);
			}, m.toDate = function() {
				return new Date(this.valueOf());
			}, m.toJSON = function() {
				return this.isValid() ? this.toISOString() : null;
			}, m.toISOString = function() {
				return this.$d.toISOString();
			}, m.toString = function() {
				return this.$d.toUTCString();
			}, M;
		}(), Y = _.prototype;
		return O.prototype = Y, [
			["$ms", r],
			["$s", i],
			["$m", s],
			["$H", u],
			["$W", a],
			["$M", c],
			["$y", h],
			["$D", d]
		].forEach((function(t) {
			Y[t[1]] = function(e) {
				return this.$g(e, t[0], t[1]);
			};
		})), O.extend = function(t, e) {
			return t.$i || (t(e, _, O), t.$i = !0), O;
		}, O.locale = w, O.isDayjs = S, O.unix = function(t) {
			return O(1e3 * t);
		}, O.en = D[g], O.Ls = D, O.p = {}, O;
	}));
}));
//#endregion
//#region node_modules/dayjs/plugin/weekOfYear.js
var require_weekOfYear = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_weekOfYear = t();
	})(exports, (function() {
		"use strict";
		var e = "week", t = "year";
		return function(i, n, r) {
			var f = n.prototype;
			f.week = function(i) {
				if (void 0 === i && (i = null), null !== i) return this.add(7 * (i - this.week()), "day");
				var n = this.$locale().yearStart || 1;
				if (11 === this.month() && this.date() > 25) {
					var f = r(this).startOf(t).add(1, t).date(n), s = r(this).endOf(e);
					if (f.isBefore(s)) return 1;
				}
				var a = r(this).startOf(t).date(n).startOf(e).subtract(1, "millisecond"), o = this.diff(a, e, !0);
				return o < 0 ? r(this).startOf("week").week() : Math.ceil(o);
			}, f.weeks = function(e) {
				return void 0 === e && (e = null), this.week(e);
			};
		};
	}));
}));
//#endregion
//#region node_modules/dayjs/plugin/customParseFormat.js
var require_customParseFormat = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_customParseFormat = t();
	})(exports, (function() {
		"use strict";
		var e = {
			LTS: "h:mm:ss A",
			LT: "h:mm A",
			L: "MM/DD/YYYY",
			LL: "MMMM D, YYYY",
			LLL: "MMMM D, YYYY h:mm A",
			LLLL: "dddd, MMMM D, YYYY h:mm A"
		}, t = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g, n = /\d/, r = /\d\d/, i = /\d\d?/, o = /\d*[^-_:/,()\s\d]+/, s = {}, a = function(e) {
			return (e = +e) + (e > 68 ? 1900 : 2e3);
		};
		var f = function(e) {
			return function(t) {
				this[e] = +t;
			};
		}, h = [/[+-]\d\d:?(\d\d)?|Z/, function(e) {
			(this.zone || (this.zone = {})).offset = function(e) {
				if (!e) return 0;
				if ("Z" === e) return 0;
				var t = e.match(/([+-]|\d\d)/g), n = 60 * t[1] + (+t[2] || 0);
				return 0 === n ? 0 : "+" === t[0] ? -n : n;
			}(e);
		}], u = function(e) {
			var t = s[e];
			return t && (t.indexOf ? t : t.s.concat(t.f));
		}, d = function(e, t) {
			var n, r = s.meridiem;
			if (r) {
				for (var i = 1; i <= 24; i += 1) if (e.indexOf(r(i, 0, t)) > -1) {
					n = i > 12;
					break;
				}
			} else n = e === (t ? "pm" : "PM");
			return n;
		}, c = {
			A: [o, function(e) {
				this.afternoon = d(e, !1);
			}],
			a: [o, function(e) {
				this.afternoon = d(e, !0);
			}],
			Q: [n, function(e) {
				this.month = 3 * (e - 1) + 1;
			}],
			S: [n, function(e) {
				this.milliseconds = 100 * +e;
			}],
			SS: [r, function(e) {
				this.milliseconds = 10 * +e;
			}],
			SSS: [/\d{3}/, function(e) {
				this.milliseconds = +e;
			}],
			s: [i, f("seconds")],
			ss: [i, f("seconds")],
			m: [i, f("minutes")],
			mm: [i, f("minutes")],
			H: [i, f("hours")],
			h: [i, f("hours")],
			HH: [i, f("hours")],
			hh: [i, f("hours")],
			D: [i, f("day")],
			DD: [r, f("day")],
			Do: [o, function(e) {
				var t = s.ordinal, n = e.match(/\d+/);
				if (this.day = n[0], t) for (var r = 1; r <= 31; r += 1) t(r).replace(/\[|\]/g, "") === e && (this.day = r);
			}],
			w: [i, f("week")],
			ww: [r, f("week")],
			M: [i, f("month")],
			MM: [r, f("month")],
			MMM: [o, function(e) {
				var t = u("months"), n = (u("monthsShort") || t.map((function(e) {
					return e.slice(0, 3);
				}))).indexOf(e) + 1;
				if (n < 1) throw new Error();
				this.month = n % 12 || n;
			}],
			MMMM: [o, function(e) {
				var t = u("months").indexOf(e) + 1;
				if (t < 1) throw new Error();
				this.month = t % 12 || t;
			}],
			Y: [/[+-]?\d+/, f("year")],
			YY: [r, function(e) {
				this.year = a(e);
			}],
			YYYY: [/\d{4}/, f("year")],
			Z: h,
			ZZ: h
		};
		function l(n) {
			var r = n, i = s && s.formats;
			for (var o = (n = r.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(t, n, r) {
				var o = r && r.toUpperCase();
				return n || i[r] || e[r] || i[o].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(e, t, n) {
					return t || n.slice(1);
				}));
			}))).match(t), a = o.length, f = 0; f < a; f += 1) {
				var h = o[f], u = c[h], d = u && u[0], l = u && u[1];
				o[f] = l ? {
					regex: d,
					parser: l
				} : h.replace(/^\[|\]$/g, "");
			}
			return function(e) {
				for (var t = {}, n = 0, r = 0; n < a; n += 1) {
					var i = o[n];
					if ("string" == typeof i) r += i.length;
					else {
						var s = i.regex, f = i.parser, h = e.slice(r), u = s.exec(h)[0];
						f.call(t, u), e = e.replace(u, "");
					}
				}
				return function(e) {
					var t = e.afternoon;
					if (void 0 !== t) {
						var n = e.hours;
						t ? n < 12 && (e.hours += 12) : 12 === n && (e.hours = 0), delete e.afternoon;
					}
				}(t), t;
			};
		}
		return function(e, t, n) {
			n.p.customParseFormat = !0, e && e.parseTwoDigitYear && (a = e.parseTwoDigitYear);
			var r = t.prototype, i = r.parse;
			r.parse = function(e) {
				var t = e.date, r = e.utc, o = e.args;
				this.$u = r;
				var a = o[1];
				if ("string" == typeof a) {
					var f = !0 === o[2], h = !0 === o[3], u = f || h, d = o[2];
					h && (d = o[2]), s = this.$locale(), !f && d && (s = n.Ls[d]), this.$d = function(e, t, n, r) {
						try {
							if (["x", "X"].indexOf(t) > -1) return /* @__PURE__ */ new Date(("X" === t ? 1e3 : 1) * e);
							var i = l(t)(e), o = i.year, s = i.month, a = i.day, f = i.hours, h = i.minutes, u = i.seconds, d = i.milliseconds, c = i.zone, m = i.week, M = /* @__PURE__ */ new Date(), Y = a || (o || s ? 1 : M.getDate()), p = o || M.getFullYear(), v = 0;
							o && !s || (v = s > 0 ? s - 1 : M.getMonth());
							var D, w = f || 0, g = h || 0, y = u || 0, L = d || 0;
							return c ? new Date(Date.UTC(p, v, Y, w, g, y, L + 60 * c.offset * 1e3)) : n ? new Date(Date.UTC(p, v, Y, w, g, y, L)) : (D = new Date(p, v, Y, w, g, y, L), m && (D = r(D).week(m).toDate()), D);
						} catch (e) {
							return /* @__PURE__ */ new Date("");
						}
					}(t, a, r, n), this.init(), d && !0 !== d && (this.$L = this.locale(d).$L), u && t != this.format(a) && (this.$d = /* @__PURE__ */ new Date("")), s = {};
				} else if (a instanceof Array) for (var c = a.length, m = 1; m <= c; m += 1) {
					o[1] = a[m - 1];
					var M = n.apply(this, o);
					if (M.isValid()) {
						this.$d = M.$d, this.$L = M.$L, this.init();
						break;
					}
					m === c && (this.$d = /* @__PURE__ */ new Date(""));
				}
				else i.call(this, e);
			};
		};
	}));
}));
//#endregion
//#region node_modules/dayjs/plugin/localizedFormat.js
var require_localizedFormat = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_localizedFormat = t();
	})(exports, (function() {
		"use strict";
		var e = {
			LTS: "h:mm:ss A",
			LT: "h:mm A",
			L: "MM/DD/YYYY",
			LL: "MMMM D, YYYY",
			LLL: "MMMM D, YYYY h:mm A",
			LLLL: "dddd, MMMM D, YYYY h:mm A"
		};
		return function(t, o, n) {
			var r = o.prototype, i = r.format;
			n.en.formats = e, r.format = function(t) {
				void 0 === t && (t = "YYYY-MM-DDTHH:mm:ssZ");
				var o = this.$locale().formats, n = function(t, o) {
					return t.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(t, n, r) {
						var i = r && r.toUpperCase();
						return n || o[r] || e[r] || o[i].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(e, t, o) {
							return t || o.slice(1);
						}));
					}));
				}(t, void 0 === o ? {} : o);
				return i.call(this, n);
			};
		};
	}));
}));
//#endregion
//#region node_modules/dayjs/plugin/isBetween.js
var require_isBetween = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, i) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = i() : "function" == typeof define && define.amd ? define(i) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_isBetween = i();
	})(exports, (function() {
		"use strict";
		return function(e, i, t) {
			i.prototype.isBetween = function(e, i, s, f) {
				var n = t(e), o = t(i), r = "(" === (f = f || "()")[0], u = ")" === f[1];
				return (r ? this.isAfter(n, s) : !this.isBefore(n, s)) && (u ? this.isBefore(o, s) : !this.isAfter(o, s)) || (r ? this.isBefore(n, s) : !this.isAfter(n, s)) && (u ? this.isAfter(o, s) : !this.isBefore(o, s));
			};
		};
	}));
}));
//#endregion
//#region node_modules/dayjs/plugin/advancedFormat.js
var require_advancedFormat = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_advancedFormat = t();
	})(exports, (function() {
		"use strict";
		return function(e, t) {
			var r = t.prototype, n = r.format;
			r.format = function(e) {
				var t = this, r = this.$locale();
				if (!this.isValid()) return n.bind(this)(e);
				var s = this.$utils(), a = (e || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, (function(e) {
					switch (e) {
						case "Q": return Math.ceil((t.$M + 1) / 3);
						case "Do": return r.ordinal(t.$D);
						case "gggg": return t.weekYear();
						case "GGGG": return t.isoWeekYear();
						case "wo": return r.ordinal(t.week(), "W");
						case "w":
						case "ww": return s.s(t.week(), "w" === e ? 1 : 2, "0");
						case "W":
						case "WW": return s.s(t.isoWeek(), "W" === e ? 1 : 2, "0");
						case "k":
						case "kk": return s.s(String(0 === t.$H ? 24 : t.$H), "k" === e ? 1 : 2, "0");
						case "X": return Math.floor(t.$d.getTime() / 1e3);
						case "x": return t.$d.getTime();
						case "z": return "[" + t.offsetName() + "]";
						case "zzz": return "[" + t.offsetName("long") + "]";
						default: return e;
					}
				}));
				return n.bind(this)(a);
			};
		};
	}));
}));
//#endregion
//#region node_modules/@mui/x-date-pickers/AdapterDayjs/AdapterDayjs.mjs
/* v8 ignore stop */
var import_dayjs_min = /* @__PURE__ */ __toESM(require_dayjs_min(), 1);
var import_weekOfYear = /* @__PURE__ */ __toESM(require_weekOfYear(), 1);
var import_customParseFormat = /* @__PURE__ */ __toESM(require_customParseFormat(), 1);
var import_localizedFormat = /* @__PURE__ */ __toESM(require_localizedFormat(), 1);
var import_isBetween = /* @__PURE__ */ __toESM(require_isBetween(), 1);
var import_advancedFormat = /* @__PURE__ */ __toESM(require_advancedFormat(), 1);
import_dayjs_min.default.extend(import_localizedFormat.default);
import_dayjs_min.default.extend(import_weekOfYear.default);
import_dayjs_min.default.extend(import_isBetween.default);
import_dayjs_min.default.extend(import_advancedFormat.default);
var formatTokenMap = {
	YY: "year",
	YYYY: {
		sectionType: "year",
		contentType: "digit",
		maxLength: 4
	},
	M: {
		sectionType: "month",
		contentType: "digit",
		maxLength: 2
	},
	MM: "month",
	MMM: {
		sectionType: "month",
		contentType: "letter"
	},
	MMMM: {
		sectionType: "month",
		contentType: "letter"
	},
	D: {
		sectionType: "day",
		contentType: "digit",
		maxLength: 2
	},
	DD: "day",
	Do: {
		sectionType: "day",
		contentType: "digit-with-letter"
	},
	d: {
		sectionType: "weekDay",
		contentType: "digit",
		maxLength: 2
	},
	dd: {
		sectionType: "weekDay",
		contentType: "letter"
	},
	ddd: {
		sectionType: "weekDay",
		contentType: "letter"
	},
	dddd: {
		sectionType: "weekDay",
		contentType: "letter"
	},
	A: "meridiem",
	a: "meridiem",
	H: {
		sectionType: "hours",
		contentType: "digit",
		maxLength: 2
	},
	HH: "hours",
	h: {
		sectionType: "hours",
		contentType: "digit",
		maxLength: 2
	},
	hh: "hours",
	m: {
		sectionType: "minutes",
		contentType: "digit",
		maxLength: 2
	},
	mm: "minutes",
	s: {
		sectionType: "seconds",
		contentType: "digit",
		maxLength: 2
	},
	ss: "seconds"
};
var defaultFormats = {
	year: "YYYY",
	month: "MMMM",
	monthShort: "MMM",
	dayOfMonth: "D",
	dayOfMonthFull: "Do",
	weekday: "dddd",
	weekdayShort: "dd",
	hours24h: "HH",
	hours12h: "hh",
	meridiem: "A",
	minutes: "mm",
	seconds: "ss",
	fullDate: "ll",
	keyboardDate: "L",
	shortDate: "MMM D",
	normalDate: "D MMMM",
	normalDateWithWeekday: "ddd, MMM D",
	fullTime12h: "hh:mm A",
	fullTime24h: "HH:mm",
	keyboardDateTime12h: "L hh:mm A",
	keyboardDateTime24h: "L HH:mm"
};
function throwMissingUTCPluginError() {
	throw new Error("MUI X Date Pickers: Missing dayjs UTC plugin. UTC and timezone support requires the dayjs UTC plugin to be enabled. See https://mui.com/x/react-date-pickers/timezone/#day-js-and-utc for setup instructions.");
}
function throwMissingTimezonePluginError() {
	throw new Error("MUI X Date Pickers: Missing dayjs timezone plugin. Timezone support requires both the dayjs UTC and timezone plugins to be enabled. See https://mui.com/x/react-date-pickers/timezone/#day-js-and-timezone for setup instructions.");
}
/**
* Based on `@date-io/dayjs`
*
* MIT License
*
* Copyright (c) 2017 Dmitriy Kovalenko
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/
var AdapterDayjs = class {
	isMUIAdapter = true;
	isTimezoneCompatible = true;
	lib = "dayjs";
	escapedCharacters = {
		start: "[",
		end: "]"
	};
	formatTokenMap = formatTokenMap;
	constructor({ locale, formats } = {}) {
		this.locale = locale;
		this.formats = _extends({}, defaultFormats, formats);
		import_dayjs_min.default.extend(import_customParseFormat.default);
	}
	setLocaleToValue = (value) => {
		const expectedLocale = this.getCurrentLocaleCode();
		if (expectedLocale === value.locale()) return value;
		return value.locale(expectedLocale);
	};
	hasUTCPlugin = () => typeof import_dayjs_min.default.utc !== "undefined";
	hasTimezonePlugin = () => typeof import_dayjs_min.default.tz !== "undefined";
	isSame = (value, comparing, comparisonTemplate) => {
		const comparingInValueTimezone = this.setTimezone(comparing, this.getTimezone(value));
		return value.format(comparisonTemplate) === comparingInValueTimezone.format(comparisonTemplate);
	};
	/**
	* Replaces "default" by undefined and "system" by the system timezone before passing it to `dayjs`.
	*/
	cleanTimezone = (timezone) => {
		switch (timezone) {
			case "default": return;
			case "system": return import_dayjs_min.default.tz.guess();
			default: return timezone;
		}
	};
	createSystemDate = (value) => {
		return this.setLocaleToValue((0, import_dayjs_min.default)(value));
	};
	createUTCDate = (value) => {
		/* v8 ignore next 3 */
		if (!this.hasUTCPlugin()) throwMissingUTCPluginError();
		return this.setLocaleToValue(import_dayjs_min.default.utc(value));
	};
	createTZDate = (value, timezone) => {
		/* v8 ignore next 3 */
		if (!this.hasUTCPlugin()) throwMissingUTCPluginError();
		/* v8 ignore next 3 */
		if (!this.hasTimezonePlugin()) throwMissingTimezonePluginError();
		const keepLocalTime = value !== void 0 && !value.endsWith("Z");
		return this.setLocaleToValue((0, import_dayjs_min.default)(value).tz(this.cleanTimezone(timezone), keepLocalTime));
	};
	getLocaleFormats = () => {
		const locales = import_dayjs_min.default.Ls;
		let localeObject = locales[this.locale || "en"];
		if (localeObject === void 0) {
			warnOnce([
				"MUI X: Your locale has not been found.",
				"Either the locale key is not a supported one. Locales supported by dayjs are available here: https://github.com/iamkun/dayjs/tree/dev/src/locale.",
				"Or you forget to import the locale from 'dayjs/locale/{localeUsed}'",
				"fallback on English locale."
			]);
			/* v8 ignore stop */
			localeObject = locales.en;
		}
		return localeObject.formats;
	};
	/**
	* If the new day does not have the same offset as the old one (when switching to summer day time for example),
	* Then dayjs will not automatically adjust the offset (moment does).
	* We have to parse again the value to make sure the `fixOffset` method is applied.
	* See https://github.com/iamkun/dayjs/blob/b3624de619d6e734cd0ffdbbd3502185041c1b60/src/plugin/timezone/index.js#L72
	*/
	adjustOffset = (value) => {
		if (!this.hasTimezonePlugin()) return value;
		const timezone = this.getTimezone(value);
		if (timezone !== "UTC") {
			const fixedValue = value.tz(this.cleanTimezone(timezone), true);
			/* v8 ignore next 3 */
			if (fixedValue.$offset === (value.$offset ?? 0)) return value;
			value.$offset = fixedValue.$offset;
		}
		return value;
	};
	/**
	* On dates predating the timezone standardization, IANA falls back on the Local Mean Time of the
	* location, whose offset is not a round number of minutes (`Asia/Kolkata` is `GMT+05:53:28`).
	* `dayjs` then moves the day of the month when only the year or the month was meant to change.
	* `daysInMonth()` is unusable on such a value because it derives from the equally broken
	* `endOf('month')`, hence computing it on a plain UTC value instead.
	* See https://github.com/mui/mui-x/issues/23163
	*/
	restoreDayOfMonth = (value, reference) => {
		const timezone = this.getTimezone(value);
		if (!this.hasUTCPlugin() || timezone === "system" || timezone === "UTC") return value;
		const wallClock = import_dayjs_min.default.utc(value.format("YYYY-MM-DDTHH:mm:ss.SSS"));
		if (!wallClock.isValid()) return value;
		const expectedDayOfMonth = Math.min(reference.date(), wallClock.daysInMonth());
		if (value.date() === expectedDayOfMonth) return value;
		return value.set("date", expectedDayOfMonth);
	};
	date = (value, timezone = "default") => {
		if (value === null) return null;
		if (timezone === "UTC") return this.createUTCDate(value);
		if (timezone === "system" || timezone === "default" && !this.hasTimezonePlugin()) return this.createSystemDate(value);
		return this.createTZDate(value, timezone);
	};
	getInvalidDate = () => (0, import_dayjs_min.default)(/* @__PURE__ */ new Date("Invalid date"));
	getTimezone = (value) => {
		if (this.hasTimezonePlugin()) {
			const zone = value.$x?.$timezone;
			if (zone) return zone;
		}
		if (this.hasUTCPlugin() && value.isUTC()) return "UTC";
		return "system";
	};
	setTimezone = (value, timezone) => {
		if (this.getTimezone(value) === timezone) return value;
		if (timezone === "UTC") {
			/* v8 ignore next 3 */
			if (!this.hasUTCPlugin()) throwMissingUTCPluginError();
			return value.utc();
		}
		if (timezone === "system") return value.local();
		if (!this.hasTimezonePlugin()) {
			if (timezone === "default") return value;
			/* v8 ignore next */
			throwMissingTimezonePluginError();
		}
		return this.setLocaleToValue(import_dayjs_min.default.tz(value, this.cleanTimezone(timezone)));
	};
	toJsDate = (value) => {
		return value.toDate();
	};
	parse = (value, format) => {
		if (value === "") return null;
		return (0, import_dayjs_min.default)(value, format, this.locale, true);
	};
	getCurrentLocaleCode = () => {
		return this.locale || "en";
	};
	is12HourCycleInCurrentLocale = () => {
		/* v8 ignore next */
		return /A|a/.test(this.getLocaleFormats().LT || "");
	};
	expandFormat = (format) => {
		const localeFormats = this.getLocaleFormats();
		const t = (formatBis) => formatBis.replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (_, a, b) => a || b.slice(1));
		return format.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (_, a, b) => {
			const B = b && b.toUpperCase();
			return a || localeFormats[b] || t(localeFormats[B]);
		});
	};
	isValid = (value) => {
		if (value == null) return false;
		return value.isValid();
	};
	format = (value, formatKey) => {
		return this.formatByString(value, this.formats[formatKey]);
	};
	formatByString = (value, formatString) => {
		return this.setLocaleToValue(value).format(formatString);
	};
	formatNumber = (numberToFormat) => {
		return numberToFormat;
	};
	isEqual = (value, comparing) => {
		if (value === null && comparing === null) return true;
		if (value === null || comparing === null) return false;
		return value.toDate().getTime() === comparing.toDate().getTime();
	};
	isSameYear = (value, comparing) => {
		return this.isSame(value, comparing, "YYYY");
	};
	isSameMonth = (value, comparing) => {
		return this.isSame(value, comparing, "YYYY-MM");
	};
	isSameDay = (value, comparing) => {
		return this.isSame(value, comparing, "YYYY-MM-DD");
	};
	isSameHour = (value, comparing) => {
		return value.isSame(comparing, "hour");
	};
	isAfter = (value, comparing) => {
		return value > comparing;
	};
	isAfterYear = (value, comparing) => {
		if (!this.hasUTCPlugin()) return value.isAfter(comparing, "year");
		return !this.isSameYear(value, comparing) && value.utc() > comparing.utc();
	};
	isAfterDay = (value, comparing) => {
		if (!this.hasUTCPlugin()) return value.isAfter(comparing, "day");
		return !this.isSameDay(value, comparing) && value.utc() > comparing.utc();
	};
	isBefore = (value, comparing) => {
		return value < comparing;
	};
	isBeforeYear = (value, comparing) => {
		if (!this.hasUTCPlugin()) return value.isBefore(comparing, "year");
		return !this.isSameYear(value, comparing) && value.utc() < comparing.utc();
	};
	isBeforeDay = (value, comparing) => {
		if (!this.hasUTCPlugin()) return value.isBefore(comparing, "day");
		return !this.isSameDay(value, comparing) && value.utc() < comparing.utc();
	};
	isWithinRange = (value, [start, end]) => {
		return value >= start && value <= end;
	};
	startOfYear = (value) => {
		return this.adjustOffset(value.startOf("year"));
	};
	startOfMonth = (value) => {
		return this.adjustOffset(value.startOf("month"));
	};
	startOfWeek = (value) => {
		return this.adjustOffset(this.setLocaleToValue(value).startOf("week"));
	};
	startOfDay = (value) => {
		return this.adjustOffset(value.startOf("day"));
	};
	endOfYear = (value) => {
		return this.adjustOffset(value.endOf("year"));
	};
	endOfMonth = (value) => {
		return this.adjustOffset(value.endOf("month"));
	};
	endOfWeek = (value) => {
		return this.adjustOffset(this.setLocaleToValue(value).endOf("week"));
	};
	endOfDay = (value) => {
		return this.adjustOffset(value.endOf("day"));
	};
	addYears = (value, amount) => {
		return this.adjustOffset(this.restoreDayOfMonth(value.add(amount, "year"), value));
	};
	addMonths = (value, amount) => {
		return this.adjustOffset(this.restoreDayOfMonth(value.add(amount, "month"), value));
	};
	addWeeks = (value, amount) => {
		return this.adjustOffset(value.add(amount, "week"));
	};
	addDays = (value, amount) => {
		return this.adjustOffset(value.add(amount, "day"));
	};
	addHours = (value, amount) => {
		return this.adjustOffset(value.add(amount, "hour"));
	};
	addMinutes = (value, amount) => {
		return this.adjustOffset(value.add(amount, "minute"));
	};
	addSeconds = (value, amount) => {
		return this.adjustOffset(value.add(amount, "second"));
	};
	getYear = (value) => {
		return value.year();
	};
	getMonth = (value) => {
		return value.month();
	};
	getDate = (value) => {
		return value.date();
	};
	getHours = (value) => {
		return value.hour();
	};
	getMinutes = (value) => {
		return value.minute();
	};
	getSeconds = (value) => {
		return value.second();
	};
	getMilliseconds = (value) => {
		return value.millisecond();
	};
	setYear = (value, year) => {
		return this.adjustOffset(this.restoreDayOfMonth(value.set("year", year), value));
	};
	setMonth = (value, month) => {
		return this.adjustOffset(this.restoreDayOfMonth(value.set("month", month), value));
	};
	setDate = (value, date) => {
		return this.adjustOffset(value.set("date", date));
	};
	setHours = (value, hours) => {
		return this.adjustOffset(value.set("hour", hours));
	};
	setMinutes = (value, minutes) => {
		return this.adjustOffset(value.set("minute", minutes));
	};
	setSeconds = (value, seconds) => {
		return this.adjustOffset(value.set("second", seconds));
	};
	setMilliseconds = (value, milliseconds) => {
		return this.adjustOffset(value.set("millisecond", milliseconds));
	};
	getDaysInMonth = (value) => {
		return value.daysInMonth();
	};
	getWeekArray = (value) => {
		const start = this.startOfWeek(this.startOfMonth(value));
		const end = this.endOfWeek(this.endOfMonth(value));
		let count = 0;
		let current = start;
		const nestedWeeks = [];
		while (current < end) {
			const weekNumber = Math.floor(count / 7);
			nestedWeeks[weekNumber] = nestedWeeks[weekNumber] || [];
			nestedWeeks[weekNumber].push(current);
			current = this.addDays(current, 1);
			count += 1;
		}
		return nestedWeeks;
	};
	getWeekNumber = (value) => {
		return value.week();
	};
	getDayOfWeek(value) {
		return value.day() + 1;
	}
	getYearRange = ([start, end]) => {
		const startDate = this.startOfYear(start);
		const endDate = this.endOfYear(end);
		const years = [];
		let current = startDate;
		while (this.isBefore(current, endDate)) {
			years.push(current);
			current = this.addYears(current, 1);
		}
		return years;
	};
};
//#endregion
export { AdapterDayjs };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQG11aV94LWRhdGUtcGlja2Vyc19BZGFwdGVyRGF5anMuanMiLCJuYW1lcyI6WyJkYXlqcyIsImxvY2FsaXplZEZvcm1hdFBsdWdpbiIsIndlZWtPZlllYXJQbHVnaW4iLCJpc0JldHdlZW5QbHVnaW4iLCJhZHZhbmNlZEZvcm1hdFBsdWdpbiIsImN1c3RvbVBhcnNlRm9ybWF0UGx1Z2luIl0sInNvdXJjZXMiOlsiLi4vLi4vZGF5anMvZGF5anMubWluLmpzIiwiLi4vLi4vZGF5anMvcGx1Z2luL3dlZWtPZlllYXIuanMiLCIuLi8uLi9kYXlqcy9wbHVnaW4vY3VzdG9tUGFyc2VGb3JtYXQuanMiLCIuLi8uLi9kYXlqcy9wbHVnaW4vbG9jYWxpemVkRm9ybWF0LmpzIiwiLi4vLi4vZGF5anMvcGx1Z2luL2lzQmV0d2Vlbi5qcyIsIi4uLy4uL2RheWpzL3BsdWdpbi9hZHZhbmNlZEZvcm1hdC5qcyIsIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvQWRhcHRlckRheWpzL0FkYXB0ZXJEYXlqcy5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiIWZ1bmN0aW9uKHQsZSl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9ZSgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoZSk6KHQ9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczp0fHxzZWxmKS5kYXlqcz1lKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9MWUzLGU9NmU0LG49MzZlNSxyPVwibWlsbGlzZWNvbmRcIixpPVwic2Vjb25kXCIscz1cIm1pbnV0ZVwiLHU9XCJob3VyXCIsYT1cImRheVwiLG89XCJ3ZWVrXCIsYz1cIm1vbnRoXCIsZj1cInF1YXJ0ZXJcIixoPVwieWVhclwiLGQ9XCJkYXRlXCIsbD1cIkludmFsaWQgRGF0ZVwiLCQ9L14oXFxkezR9KVstL10/KFxcZHsxLDJ9KT9bLS9dPyhcXGR7MCwyfSlbVHRcXHNdKihcXGR7MSwyfSk/Oj8oXFxkezEsMn0pPzo/KFxcZHsxLDJ9KT9bLjpdPyhcXGQrKT8kLyx5PS9cXFsoW15cXF1dKyldfFlZWVl8WVl8TXsxLDR9fER7MSwyfXxkezEsNH18SHsxLDJ9fGh7MSwyfXxhfEF8bXsxLDJ9fHN7MSwyfXxaezEsMn18U1NTL2csTT17bmFtZTpcImVuXCIsd2Vla2RheXM6XCJTdW5kYXlfTW9uZGF5X1R1ZXNkYXlfV2VkbmVzZGF5X1RodXJzZGF5X0ZyaWRheV9TYXR1cmRheVwiLnNwbGl0KFwiX1wiKSxtb250aHM6XCJKYW51YXJ5X0ZlYnJ1YXJ5X01hcmNoX0FwcmlsX01heV9KdW5lX0p1bHlfQXVndXN0X1NlcHRlbWJlcl9PY3RvYmVyX05vdmVtYmVyX0RlY2VtYmVyXCIuc3BsaXQoXCJfXCIpLG9yZGluYWw6ZnVuY3Rpb24odCl7dmFyIGU9W1widGhcIixcInN0XCIsXCJuZFwiLFwicmRcIl0sbj10JTEwMDtyZXR1cm5cIltcIit0KyhlWyhuLTIwKSUxMF18fGVbbl18fGVbMF0pK1wiXVwifX0sbT1mdW5jdGlvbih0LGUsbil7dmFyIHI9U3RyaW5nKHQpO3JldHVybiFyfHxyLmxlbmd0aD49ZT90OlwiXCIrQXJyYXkoZSsxLXIubGVuZ3RoKS5qb2luKG4pK3R9LHY9e3M6bSx6OmZ1bmN0aW9uKHQpe3ZhciBlPS10LnV0Y09mZnNldCgpLG49TWF0aC5hYnMoZSkscj1NYXRoLmZsb29yKG4vNjApLGk9biU2MDtyZXR1cm4oZTw9MD9cIitcIjpcIi1cIikrbShyLDIsXCIwXCIpK1wiOlwiK20oaSwyLFwiMFwiKX0sbTpmdW5jdGlvbiB0KGUsbil7aWYoZS5kYXRlKCk8bi5kYXRlKCkpcmV0dXJuLXQobixlKTt2YXIgcj0xMioobi55ZWFyKCktZS55ZWFyKCkpKyhuLm1vbnRoKCktZS5tb250aCgpKSxpPWUuY2xvbmUoKS5hZGQocixjKSxzPW4taTwwLHU9ZS5jbG9uZSgpLmFkZChyKyhzPy0xOjEpLGMpO3JldHVybisoLShyKyhuLWkpLyhzP2ktdTp1LWkpKXx8MCl9LGE6ZnVuY3Rpb24odCl7cmV0dXJuIHQ8MD9NYXRoLmNlaWwodCl8fDA6TWF0aC5mbG9vcih0KX0scDpmdW5jdGlvbih0KXtyZXR1cm57TTpjLHk6aCx3Om8sZDphLEQ6ZCxoOnUsbTpzLHM6aSxtczpyLFE6Zn1bdF18fFN0cmluZyh0fHxcIlwiKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL3MkLyxcIlwiKX0sdTpmdW5jdGlvbih0KXtyZXR1cm4gdm9pZCAwPT09dH19LGc9XCJlblwiLEQ9e307RFtnXT1NO3ZhciBwPVwiJGlzRGF5anNPYmplY3RcIixTPWZ1bmN0aW9uKHQpe3JldHVybiB0IGluc3RhbmNlb2YgX3x8ISghdHx8IXRbcF0pfSx3PWZ1bmN0aW9uIHQoZSxuLHIpe3ZhciBpO2lmKCFlKXJldHVybiBnO2lmKFwic3RyaW5nXCI9PXR5cGVvZiBlKXt2YXIgcz1lLnRvTG93ZXJDYXNlKCk7RFtzXSYmKGk9cyksbiYmKERbc109bixpPXMpO3ZhciB1PWUuc3BsaXQoXCItXCIpO2lmKCFpJiZ1Lmxlbmd0aD4xKXJldHVybiB0KHVbMF0pfWVsc2V7dmFyIGE9ZS5uYW1lO0RbYV09ZSxpPWF9cmV0dXJuIXImJmkmJihnPWkpLGl8fCFyJiZnfSxPPWZ1bmN0aW9uKHQsZSl7aWYoUyh0KSlyZXR1cm4gdC5jbG9uZSgpO3ZhciBuPVwib2JqZWN0XCI9PXR5cGVvZiBlP2U6e307cmV0dXJuIG4uZGF0ZT10LG4uYXJncz1hcmd1bWVudHMsbmV3IF8obil9LGI9djtiLmw9dyxiLmk9UyxiLnc9ZnVuY3Rpb24odCxlKXtyZXR1cm4gTyh0LHtsb2NhbGU6ZS4kTCx1dGM6ZS4kdSx4OmUuJHgsJG9mZnNldDplLiRvZmZzZXR9KX07dmFyIF89ZnVuY3Rpb24oKXtmdW5jdGlvbiBNKHQpe3RoaXMuJEw9dyh0LmxvY2FsZSxudWxsLCEwKSx0aGlzLnBhcnNlKHQpLHRoaXMuJHg9dGhpcy4keHx8dC54fHx7fSx0aGlzW3BdPSEwfXZhciBtPU0ucHJvdG90eXBlO3JldHVybiBtLnBhcnNlPWZ1bmN0aW9uKHQpe3RoaXMuJGQ9ZnVuY3Rpb24odCl7dmFyIGU9dC5kYXRlLG49dC51dGM7aWYobnVsbD09PWUpcmV0dXJuIG5ldyBEYXRlKE5hTik7aWYoYi51KGUpKXJldHVybiBuZXcgRGF0ZTtpZihlIGluc3RhbmNlb2YgRGF0ZSlyZXR1cm4gbmV3IERhdGUoZSk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIGUmJiEvWiQvaS50ZXN0KGUpKXt2YXIgcj1lLm1hdGNoKCQpO2lmKHIpe3ZhciBpPXJbMl0tMXx8MCxzPShyWzddfHxcIjBcIikuc3Vic3RyaW5nKDAsMyk7cmV0dXJuIG4/bmV3IERhdGUoRGF0ZS5VVEMoclsxXSxpLHJbM118fDEscls0XXx8MCxyWzVdfHwwLHJbNl18fDAscykpOm5ldyBEYXRlKHJbMV0saSxyWzNdfHwxLHJbNF18fDAscls1XXx8MCxyWzZdfHwwLHMpfX1yZXR1cm4gbmV3IERhdGUoZSl9KHQpLHRoaXMuaW5pdCgpfSxtLmluaXQ9ZnVuY3Rpb24oKXt2YXIgdD10aGlzLiRkO3RoaXMuJHk9dC5nZXRGdWxsWWVhcigpLHRoaXMuJE09dC5nZXRNb250aCgpLHRoaXMuJEQ9dC5nZXREYXRlKCksdGhpcy4kVz10LmdldERheSgpLHRoaXMuJEg9dC5nZXRIb3VycygpLHRoaXMuJG09dC5nZXRNaW51dGVzKCksdGhpcy4kcz10LmdldFNlY29uZHMoKSx0aGlzLiRtcz10LmdldE1pbGxpc2Vjb25kcygpfSxtLiR1dGlscz1mdW5jdGlvbigpe3JldHVybiBifSxtLmlzVmFsaWQ9ZnVuY3Rpb24oKXtyZXR1cm4hKHRoaXMuJGQudG9TdHJpbmcoKT09PWwpfSxtLmlzU2FtZT1mdW5jdGlvbih0LGUpe3ZhciBuPU8odCk7cmV0dXJuIHRoaXMuc3RhcnRPZihlKTw9biYmbjw9dGhpcy5lbmRPZihlKX0sbS5pc0FmdGVyPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIE8odCk8dGhpcy5zdGFydE9mKGUpfSxtLmlzQmVmb3JlPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHRoaXMuZW5kT2YoZSk8Tyh0KX0sbS4kZz1mdW5jdGlvbih0LGUsbil7cmV0dXJuIGIudSh0KT90aGlzW2VdOnRoaXMuc2V0KG4sdCl9LG0udW5peD1mdW5jdGlvbigpe3JldHVybiBNYXRoLmZsb29yKHRoaXMudmFsdWVPZigpLzFlMyl9LG0udmFsdWVPZj1mdW5jdGlvbigpe3JldHVybiB0aGlzLiRkLmdldFRpbWUoKX0sbS5zdGFydE9mPWZ1bmN0aW9uKHQsZSl7dmFyIG49dGhpcyxyPSEhYi51KGUpfHxlLGY9Yi5wKHQpLGw9ZnVuY3Rpb24odCxlKXt2YXIgaT1iLncobi4kdT9EYXRlLlVUQyhuLiR5LGUsdCk6bmV3IERhdGUobi4keSxlLHQpLG4pO3JldHVybiByP2k6aS5lbmRPZihhKX0sJD1mdW5jdGlvbih0LGUpe3JldHVybiBiLncobi50b0RhdGUoKVt0XS5hcHBseShuLnRvRGF0ZShcInNcIiksKHI/WzAsMCwwLDBdOlsyMyw1OSw1OSw5OTldKS5zbGljZShlKSksbil9LHk9dGhpcy4kVyxNPXRoaXMuJE0sbT10aGlzLiRELHY9XCJzZXRcIisodGhpcy4kdT9cIlVUQ1wiOlwiXCIpO3N3aXRjaChmKXtjYXNlIGg6cmV0dXJuIHI/bCgxLDApOmwoMzEsMTEpO2Nhc2UgYzpyZXR1cm4gcj9sKDEsTSk6bCgwLE0rMSk7Y2FzZSBvOnZhciBnPXRoaXMuJGxvY2FsZSgpLndlZWtTdGFydHx8MCxEPSh5PGc/eSs3OnkpLWc7cmV0dXJuIGwocj9tLUQ6bSsoNi1EKSxNKTtjYXNlIGE6Y2FzZSBkOnJldHVybiAkKHYrXCJIb3Vyc1wiLDApO2Nhc2UgdTpyZXR1cm4gJCh2K1wiTWludXRlc1wiLDEpO2Nhc2UgczpyZXR1cm4gJCh2K1wiU2Vjb25kc1wiLDIpO2Nhc2UgaTpyZXR1cm4gJCh2K1wiTWlsbGlzZWNvbmRzXCIsMyk7ZGVmYXVsdDpyZXR1cm4gdGhpcy5jbG9uZSgpfX0sbS5lbmRPZj1mdW5jdGlvbih0KXtyZXR1cm4gdGhpcy5zdGFydE9mKHQsITEpfSxtLiRzZXQ9ZnVuY3Rpb24odCxlKXt2YXIgbixvPWIucCh0KSxmPVwic2V0XCIrKHRoaXMuJHU/XCJVVENcIjpcIlwiKSxsPShuPXt9LG5bYV09ZitcIkRhdGVcIixuW2RdPWYrXCJEYXRlXCIsbltjXT1mK1wiTW9udGhcIixuW2hdPWYrXCJGdWxsWWVhclwiLG5bdV09ZitcIkhvdXJzXCIsbltzXT1mK1wiTWludXRlc1wiLG5baV09ZitcIlNlY29uZHNcIixuW3JdPWYrXCJNaWxsaXNlY29uZHNcIixuKVtvXSwkPW89PT1hP3RoaXMuJEQrKGUtdGhpcy4kVyk6ZTtpZihvPT09Y3x8bz09PWgpe3ZhciB5PXRoaXMuY2xvbmUoKS5zZXQoZCwxKTt5LiRkW2xdKCQpLHkuaW5pdCgpLHRoaXMuJGQ9eS5zZXQoZCxNYXRoLm1pbih0aGlzLiRELHkuZGF5c0luTW9udGgoKSkpLiRkfWVsc2UgbCYmdGhpcy4kZFtsXSgkKTtyZXR1cm4gdGhpcy5pbml0KCksdGhpc30sbS5zZXQ9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5jbG9uZSgpLiRzZXQodCxlKX0sbS5nZXQ9ZnVuY3Rpb24odCl7cmV0dXJuIHRoaXNbYi5wKHQpXSgpfSxtLmFkZD1mdW5jdGlvbihyLGYpe3ZhciBkLGw9dGhpcztyPU51bWJlcihyKTt2YXIgJD1iLnAoZikseT1mdW5jdGlvbih0KXt2YXIgZT1PKGwpO3JldHVybiBiLncoZS5kYXRlKGUuZGF0ZSgpK01hdGgucm91bmQodCpyKSksbCl9O2lmKCQ9PT1jKXJldHVybiB0aGlzLnNldChjLHRoaXMuJE0rcik7aWYoJD09PWgpcmV0dXJuIHRoaXMuc2V0KGgsdGhpcy4keStyKTtpZigkPT09YSlyZXR1cm4geSgxKTtpZigkPT09bylyZXR1cm4geSg3KTt2YXIgTT0oZD17fSxkW3NdPWUsZFt1XT1uLGRbaV09dCxkKVskXXx8MSxtPXRoaXMuJGQuZ2V0VGltZSgpK3IqTTtyZXR1cm4gYi53KG0sdGhpcyl9LG0uc3VidHJhY3Q9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5hZGQoLTEqdCxlKX0sbS5mb3JtYXQ9ZnVuY3Rpb24odCl7dmFyIGU9dGhpcyxuPXRoaXMuJGxvY2FsZSgpO2lmKCF0aGlzLmlzVmFsaWQoKSlyZXR1cm4gbi5pbnZhbGlkRGF0ZXx8bDt2YXIgcj10fHxcIllZWVktTU0tRERUSEg6bW06c3NaXCIsaT1iLnoodGhpcykscz10aGlzLiRILHU9dGhpcy4kbSxhPXRoaXMuJE0sbz1uLndlZWtkYXlzLGM9bi5tb250aHMsZj1uLm1lcmlkaWVtLGg9ZnVuY3Rpb24odCxuLGkscyl7cmV0dXJuIHQmJih0W25dfHx0KGUscikpfHxpW25dLnNsaWNlKDAscyl9LGQ9ZnVuY3Rpb24odCl7cmV0dXJuIGIucyhzJTEyfHwxMix0LFwiMFwiKX0sJD1mfHxmdW5jdGlvbih0LGUsbil7dmFyIHI9dDwxMj9cIkFNXCI6XCJQTVwiO3JldHVybiBuP3IudG9Mb3dlckNhc2UoKTpyfTtyZXR1cm4gci5yZXBsYWNlKHksKGZ1bmN0aW9uKHQscil7cmV0dXJuIHJ8fGZ1bmN0aW9uKHQpe3N3aXRjaCh0KXtjYXNlXCJZWVwiOnJldHVybiBTdHJpbmcoZS4keSkuc2xpY2UoLTIpO2Nhc2VcIllZWVlcIjpyZXR1cm4gYi5zKGUuJHksNCxcIjBcIik7Y2FzZVwiTVwiOnJldHVybiBhKzE7Y2FzZVwiTU1cIjpyZXR1cm4gYi5zKGErMSwyLFwiMFwiKTtjYXNlXCJNTU1cIjpyZXR1cm4gaChuLm1vbnRoc1Nob3J0LGEsYywzKTtjYXNlXCJNTU1NXCI6cmV0dXJuIGgoYyxhKTtjYXNlXCJEXCI6cmV0dXJuIGUuJEQ7Y2FzZVwiRERcIjpyZXR1cm4gYi5zKGUuJEQsMixcIjBcIik7Y2FzZVwiZFwiOnJldHVybiBTdHJpbmcoZS4kVyk7Y2FzZVwiZGRcIjpyZXR1cm4gaChuLndlZWtkYXlzTWluLGUuJFcsbywyKTtjYXNlXCJkZGRcIjpyZXR1cm4gaChuLndlZWtkYXlzU2hvcnQsZS4kVyxvLDMpO2Nhc2VcImRkZGRcIjpyZXR1cm4gb1tlLiRXXTtjYXNlXCJIXCI6cmV0dXJuIFN0cmluZyhzKTtjYXNlXCJISFwiOnJldHVybiBiLnMocywyLFwiMFwiKTtjYXNlXCJoXCI6cmV0dXJuIGQoMSk7Y2FzZVwiaGhcIjpyZXR1cm4gZCgyKTtjYXNlXCJhXCI6cmV0dXJuICQocyx1LCEwKTtjYXNlXCJBXCI6cmV0dXJuICQocyx1LCExKTtjYXNlXCJtXCI6cmV0dXJuIFN0cmluZyh1KTtjYXNlXCJtbVwiOnJldHVybiBiLnModSwyLFwiMFwiKTtjYXNlXCJzXCI6cmV0dXJuIFN0cmluZyhlLiRzKTtjYXNlXCJzc1wiOnJldHVybiBiLnMoZS4kcywyLFwiMFwiKTtjYXNlXCJTU1NcIjpyZXR1cm4gYi5zKGUuJG1zLDMsXCIwXCIpO2Nhc2VcIlpcIjpyZXR1cm4gaX1yZXR1cm4gbnVsbH0odCl8fGkucmVwbGFjZShcIjpcIixcIlwiKX0pKX0sbS51dGNPZmZzZXQ9ZnVuY3Rpb24oKXtyZXR1cm4gMTUqLU1hdGgucm91bmQodGhpcy4kZC5nZXRUaW1lem9uZU9mZnNldCgpLzE1KX0sbS5kaWZmPWZ1bmN0aW9uKHIsZCxsKXt2YXIgJCx5PXRoaXMsTT1iLnAoZCksbT1PKHIpLHY9KG0udXRjT2Zmc2V0KCktdGhpcy51dGNPZmZzZXQoKSkqZSxnPXRoaXMtbSxEPWZ1bmN0aW9uKCl7cmV0dXJuIGIubSh5LG0pfTtzd2l0Y2goTSl7Y2FzZSBoOiQ9RCgpLzEyO2JyZWFrO2Nhc2UgYzokPUQoKTticmVhaztjYXNlIGY6JD1EKCkvMzticmVhaztjYXNlIG86JD0oZy12KS82MDQ4ZTU7YnJlYWs7Y2FzZSBhOiQ9KGctdikvODY0ZTU7YnJlYWs7Y2FzZSB1OiQ9Zy9uO2JyZWFrO2Nhc2UgczokPWcvZTticmVhaztjYXNlIGk6JD1nL3Q7YnJlYWs7ZGVmYXVsdDokPWd9cmV0dXJuIGw/JDpiLmEoJCl9LG0uZGF5c0luTW9udGg9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5lbmRPZihjKS4kRH0sbS4kbG9jYWxlPWZ1bmN0aW9uKCl7cmV0dXJuIERbdGhpcy4kTF19LG0ubG9jYWxlPWZ1bmN0aW9uKHQsZSl7aWYoIXQpcmV0dXJuIHRoaXMuJEw7dmFyIG49dGhpcy5jbG9uZSgpLHI9dyh0LGUsITApO3JldHVybiByJiYobi4kTD1yKSxufSxtLmNsb25lPWZ1bmN0aW9uKCl7cmV0dXJuIGIudyh0aGlzLiRkLHRoaXMpfSxtLnRvRGF0ZT1mdW5jdGlvbigpe3JldHVybiBuZXcgRGF0ZSh0aGlzLnZhbHVlT2YoKSl9LG0udG9KU09OPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuaXNWYWxpZCgpP3RoaXMudG9JU09TdHJpbmcoKTpudWxsfSxtLnRvSVNPU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQudG9JU09TdHJpbmcoKX0sbS50b1N0cmluZz1mdW5jdGlvbigpe3JldHVybiB0aGlzLiRkLnRvVVRDU3RyaW5nKCl9LE19KCksWT1fLnByb3RvdHlwZTtyZXR1cm4gTy5wcm90b3R5cGU9WSxbW1wiJG1zXCIscl0sW1wiJHNcIixpXSxbXCIkbVwiLHNdLFtcIiRIXCIsdV0sW1wiJFdcIixhXSxbXCIkTVwiLGNdLFtcIiR5XCIsaF0sW1wiJERcIixkXV0uZm9yRWFjaCgoZnVuY3Rpb24odCl7WVt0WzFdXT1mdW5jdGlvbihlKXtyZXR1cm4gdGhpcy4kZyhlLHRbMF0sdFsxXSl9fSkpLE8uZXh0ZW5kPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHQuJGl8fCh0KGUsXyxPKSx0LiRpPSEwKSxPfSxPLmxvY2FsZT13LE8uaXNEYXlqcz1TLE8udW5peD1mdW5jdGlvbih0KXtyZXR1cm4gTygxZTMqdCl9LE8uZW49RFtnXSxPLkxzPUQsTy5wPXt9LE99KSk7IiwiIWZ1bmN0aW9uKGUsdCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9dCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUodCk6KGU9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczplfHxzZWxmKS5kYXlqc19wbHVnaW5fd2Vla09mWWVhcj10KCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIGU9XCJ3ZWVrXCIsdD1cInllYXJcIjtyZXR1cm4gZnVuY3Rpb24oaSxuLHIpe3ZhciBmPW4ucHJvdG90eXBlO2Yud2Vlaz1mdW5jdGlvbihpKXtpZih2b2lkIDA9PT1pJiYoaT1udWxsKSxudWxsIT09aSlyZXR1cm4gdGhpcy5hZGQoNyooaS10aGlzLndlZWsoKSksXCJkYXlcIik7dmFyIG49dGhpcy4kbG9jYWxlKCkueWVhclN0YXJ0fHwxO2lmKDExPT09dGhpcy5tb250aCgpJiZ0aGlzLmRhdGUoKT4yNSl7dmFyIGY9cih0aGlzKS5zdGFydE9mKHQpLmFkZCgxLHQpLmRhdGUobikscz1yKHRoaXMpLmVuZE9mKGUpO2lmKGYuaXNCZWZvcmUocykpcmV0dXJuIDF9dmFyIGE9cih0aGlzKS5zdGFydE9mKHQpLmRhdGUobikuc3RhcnRPZihlKS5zdWJ0cmFjdCgxLFwibWlsbGlzZWNvbmRcIiksbz10aGlzLmRpZmYoYSxlLCEwKTtyZXR1cm4gbzwwP3IodGhpcykuc3RhcnRPZihcIndlZWtcIikud2VlaygpOk1hdGguY2VpbChvKX0sZi53ZWVrcz1mdW5jdGlvbihlKXtyZXR1cm4gdm9pZCAwPT09ZSYmKGU9bnVsbCksdGhpcy53ZWVrKGUpfX19KSk7IiwiIWZ1bmN0aW9uKGUsdCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9dCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUodCk6KGU9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczplfHxzZWxmKS5kYXlqc19wbHVnaW5fY3VzdG9tUGFyc2VGb3JtYXQ9dCgpfSh0aGlzLChmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBlPXtMVFM6XCJoOm1tOnNzIEFcIixMVDpcImg6bW0gQVwiLEw6XCJNTS9ERC9ZWVlZXCIsTEw6XCJNTU1NIEQsIFlZWVlcIixMTEw6XCJNTU1NIEQsIFlZWVkgaDptbSBBXCIsTExMTDpcImRkZGQsIE1NTU0gRCwgWVlZWSBoOm1tIEFcIn0sdD0vKFxcW1teW10qXFxdKXwoWy1fOi8uLCgpXFxzXSspfChBfGF8UXxZWVlZfFlZP3x3dz98TU0/TT9NP3xEb3xERD98aGg/fEhIP3xtbT98c3M/fFN7MSwzfXx6fFpaPykvZyxuPS9cXGQvLHI9L1xcZFxcZC8saT0vXFxkXFxkPy8sbz0vXFxkKlteLV86LywoKVxcc1xcZF0rLyxzPXt9LGE9ZnVuY3Rpb24oZSl7cmV0dXJuKGU9K2UpKyhlPjY4PzE5MDA6MmUzKX07dmFyIGY9ZnVuY3Rpb24oZSl7cmV0dXJuIGZ1bmN0aW9uKHQpe3RoaXNbZV09K3R9fSxoPVsvWystXVxcZFxcZDo/KFxcZFxcZCk/fFovLGZ1bmN0aW9uKGUpeyh0aGlzLnpvbmV8fCh0aGlzLnpvbmU9e30pKS5vZmZzZXQ9ZnVuY3Rpb24oZSl7aWYoIWUpcmV0dXJuIDA7aWYoXCJaXCI9PT1lKXJldHVybiAwO3ZhciB0PWUubWF0Y2goLyhbKy1dfFxcZFxcZCkvZyksbj02MCp0WzFdKygrdFsyXXx8MCk7cmV0dXJuIDA9PT1uPzA6XCIrXCI9PT10WzBdPy1uOm59KGUpfV0sdT1mdW5jdGlvbihlKXt2YXIgdD1zW2VdO3JldHVybiB0JiYodC5pbmRleE9mP3Q6dC5zLmNvbmNhdCh0LmYpKX0sZD1mdW5jdGlvbihlLHQpe3ZhciBuLHI9cy5tZXJpZGllbTtpZihyKXtmb3IodmFyIGk9MTtpPD0yNDtpKz0xKWlmKGUuaW5kZXhPZihyKGksMCx0KSk+LTEpe249aT4xMjticmVha319ZWxzZSBuPWU9PT0odD9cInBtXCI6XCJQTVwiKTtyZXR1cm4gbn0sYz17QTpbbyxmdW5jdGlvbihlKXt0aGlzLmFmdGVybm9vbj1kKGUsITEpfV0sYTpbbyxmdW5jdGlvbihlKXt0aGlzLmFmdGVybm9vbj1kKGUsITApfV0sUTpbbixmdW5jdGlvbihlKXt0aGlzLm1vbnRoPTMqKGUtMSkrMX1dLFM6W24sZnVuY3Rpb24oZSl7dGhpcy5taWxsaXNlY29uZHM9MTAwKitlfV0sU1M6W3IsZnVuY3Rpb24oZSl7dGhpcy5taWxsaXNlY29uZHM9MTAqK2V9XSxTU1M6Wy9cXGR7M30vLGZ1bmN0aW9uKGUpe3RoaXMubWlsbGlzZWNvbmRzPStlfV0sczpbaSxmKFwic2Vjb25kc1wiKV0sc3M6W2ksZihcInNlY29uZHNcIildLG06W2ksZihcIm1pbnV0ZXNcIildLG1tOltpLGYoXCJtaW51dGVzXCIpXSxIOltpLGYoXCJob3Vyc1wiKV0saDpbaSxmKFwiaG91cnNcIildLEhIOltpLGYoXCJob3Vyc1wiKV0saGg6W2ksZihcImhvdXJzXCIpXSxEOltpLGYoXCJkYXlcIildLEREOltyLGYoXCJkYXlcIildLERvOltvLGZ1bmN0aW9uKGUpe3ZhciB0PXMub3JkaW5hbCxuPWUubWF0Y2goL1xcZCsvKTtpZih0aGlzLmRheT1uWzBdLHQpZm9yKHZhciByPTE7cjw9MzE7cis9MSl0KHIpLnJlcGxhY2UoL1xcW3xcXF0vZyxcIlwiKT09PWUmJih0aGlzLmRheT1yKX1dLHc6W2ksZihcIndlZWtcIildLHd3OltyLGYoXCJ3ZWVrXCIpXSxNOltpLGYoXCJtb250aFwiKV0sTU06W3IsZihcIm1vbnRoXCIpXSxNTU06W28sZnVuY3Rpb24oZSl7dmFyIHQ9dShcIm1vbnRoc1wiKSxuPSh1KFwibW9udGhzU2hvcnRcIil8fHQubWFwKChmdW5jdGlvbihlKXtyZXR1cm4gZS5zbGljZSgwLDMpfSkpKS5pbmRleE9mKGUpKzE7aWYobjwxKXRocm93IG5ldyBFcnJvcjt0aGlzLm1vbnRoPW4lMTJ8fG59XSxNTU1NOltvLGZ1bmN0aW9uKGUpe3ZhciB0PXUoXCJtb250aHNcIikuaW5kZXhPZihlKSsxO2lmKHQ8MSl0aHJvdyBuZXcgRXJyb3I7dGhpcy5tb250aD10JTEyfHx0fV0sWTpbL1srLV0/XFxkKy8sZihcInllYXJcIildLFlZOltyLGZ1bmN0aW9uKGUpe3RoaXMueWVhcj1hKGUpfV0sWVlZWTpbL1xcZHs0fS8sZihcInllYXJcIildLFo6aCxaWjpofTtmdW5jdGlvbiBsKG4pe3ZhciByLGk7cj1uLGk9cyYmcy5mb3JtYXRzO2Zvcih2YXIgbz0obj1yLnJlcGxhY2UoLyhcXFtbXlxcXV0rXSl8KExUUz98bHsxLDR9fEx7MSw0fSkvZywoZnVuY3Rpb24odCxuLHIpe3ZhciBvPXImJnIudG9VcHBlckNhc2UoKTtyZXR1cm4gbnx8aVtyXXx8ZVtyXXx8aVtvXS5yZXBsYWNlKC8oXFxbW15cXF1dK10pfChNTU1NfE1NfEREfGRkZGQpL2csKGZ1bmN0aW9uKGUsdCxuKXtyZXR1cm4gdHx8bi5zbGljZSgxKX0pKX0pKSkubWF0Y2godCksYT1vLmxlbmd0aCxmPTA7ZjxhO2YrPTEpe3ZhciBoPW9bZl0sdT1jW2hdLGQ9dSYmdVswXSxsPXUmJnVbMV07b1tmXT1sP3tyZWdleDpkLHBhcnNlcjpsfTpoLnJlcGxhY2UoL15cXFt8XFxdJC9nLFwiXCIpfXJldHVybiBmdW5jdGlvbihlKXtmb3IodmFyIHQ9e30sbj0wLHI9MDtuPGE7bis9MSl7dmFyIGk9b1tuXTtpZihcInN0cmluZ1wiPT10eXBlb2YgaSlyKz1pLmxlbmd0aDtlbHNle3ZhciBzPWkucmVnZXgsZj1pLnBhcnNlcixoPWUuc2xpY2UociksdT1zLmV4ZWMoaClbMF07Zi5jYWxsKHQsdSksZT1lLnJlcGxhY2UodSxcIlwiKX19cmV0dXJuIGZ1bmN0aW9uKGUpe3ZhciB0PWUuYWZ0ZXJub29uO2lmKHZvaWQgMCE9PXQpe3ZhciBuPWUuaG91cnM7dD9uPDEyJiYoZS5ob3Vycys9MTIpOjEyPT09biYmKGUuaG91cnM9MCksZGVsZXRlIGUuYWZ0ZXJub29ufX0odCksdH19cmV0dXJuIGZ1bmN0aW9uKGUsdCxuKXtuLnAuY3VzdG9tUGFyc2VGb3JtYXQ9ITAsZSYmZS5wYXJzZVR3b0RpZ2l0WWVhciYmKGE9ZS5wYXJzZVR3b0RpZ2l0WWVhcik7dmFyIHI9dC5wcm90b3R5cGUsaT1yLnBhcnNlO3IucGFyc2U9ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5kYXRlLHI9ZS51dGMsbz1lLmFyZ3M7dGhpcy4kdT1yO3ZhciBhPW9bMV07aWYoXCJzdHJpbmdcIj09dHlwZW9mIGEpe3ZhciBmPSEwPT09b1syXSxoPSEwPT09b1szXSx1PWZ8fGgsZD1vWzJdO2gmJihkPW9bMl0pLHM9dGhpcy4kbG9jYWxlKCksIWYmJmQmJihzPW4uTHNbZF0pLHRoaXMuJGQ9ZnVuY3Rpb24oZSx0LG4scil7dHJ5e2lmKFtcInhcIixcIlhcIl0uaW5kZXhPZih0KT4tMSlyZXR1cm4gbmV3IERhdGUoKFwiWFwiPT09dD8xZTM6MSkqZSk7dmFyIGk9bCh0KShlKSxvPWkueWVhcixzPWkubW9udGgsYT1pLmRheSxmPWkuaG91cnMsaD1pLm1pbnV0ZXMsdT1pLnNlY29uZHMsZD1pLm1pbGxpc2Vjb25kcyxjPWkuem9uZSxtPWkud2VlayxNPW5ldyBEYXRlLFk9YXx8KG98fHM/MTpNLmdldERhdGUoKSkscD1vfHxNLmdldEZ1bGxZZWFyKCksdj0wO28mJiFzfHwodj1zPjA/cy0xOk0uZ2V0TW9udGgoKSk7dmFyIEQsdz1mfHwwLGc9aHx8MCx5PXV8fDAsTD1kfHwwO3JldHVybiBjP25ldyBEYXRlKERhdGUuVVRDKHAsdixZLHcsZyx5LEwrNjAqYy5vZmZzZXQqMWUzKSk6bj9uZXcgRGF0ZShEYXRlLlVUQyhwLHYsWSx3LGcseSxMKSk6KEQ9bmV3IERhdGUocCx2LFksdyxnLHksTCksbSYmKEQ9cihEKS53ZWVrKG0pLnRvRGF0ZSgpKSxEKX1jYXRjaChlKXtyZXR1cm4gbmV3IERhdGUoXCJcIil9fSh0LGEscixuKSx0aGlzLmluaXQoKSxkJiYhMCE9PWQmJih0aGlzLiRMPXRoaXMubG9jYWxlKGQpLiRMKSx1JiZ0IT10aGlzLmZvcm1hdChhKSYmKHRoaXMuJGQ9bmV3IERhdGUoXCJcIikpLHM9e319ZWxzZSBpZihhIGluc3RhbmNlb2YgQXJyYXkpZm9yKHZhciBjPWEubGVuZ3RoLG09MTttPD1jO20rPTEpe29bMV09YVttLTFdO3ZhciBNPW4uYXBwbHkodGhpcyxvKTtpZihNLmlzVmFsaWQoKSl7dGhpcy4kZD1NLiRkLHRoaXMuJEw9TS4kTCx0aGlzLmluaXQoKTticmVha31tPT09YyYmKHRoaXMuJGQ9bmV3IERhdGUoXCJcIikpfWVsc2UgaS5jYWxsKHRoaXMsZSl9fX0pKTsiLCIhZnVuY3Rpb24oZSx0KXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz10KCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZSh0KTooZT1cInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsVGhpcz9nbG9iYWxUaGlzOmV8fHNlbGYpLmRheWpzX3BsdWdpbl9sb2NhbGl6ZWRGb3JtYXQ9dCgpfSh0aGlzLChmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBlPXtMVFM6XCJoOm1tOnNzIEFcIixMVDpcImg6bW0gQVwiLEw6XCJNTS9ERC9ZWVlZXCIsTEw6XCJNTU1NIEQsIFlZWVlcIixMTEw6XCJNTU1NIEQsIFlZWVkgaDptbSBBXCIsTExMTDpcImRkZGQsIE1NTU0gRCwgWVlZWSBoOm1tIEFcIn07cmV0dXJuIGZ1bmN0aW9uKHQsbyxuKXt2YXIgcj1vLnByb3RvdHlwZSxpPXIuZm9ybWF0O24uZW4uZm9ybWF0cz1lLHIuZm9ybWF0PWZ1bmN0aW9uKHQpe3ZvaWQgMD09PXQmJih0PVwiWVlZWS1NTS1ERFRISDptbTpzc1pcIik7dmFyIG89dGhpcy4kbG9jYWxlKCkuZm9ybWF0cyxuPWZ1bmN0aW9uKHQsbyl7cmV0dXJuIHQucmVwbGFjZSgvKFxcW1teXFxdXStdKXwoTFRTP3xsezEsNH18THsxLDR9KS9nLChmdW5jdGlvbih0LG4scil7dmFyIGk9ciYmci50b1VwcGVyQ2FzZSgpO3JldHVybiBufHxvW3JdfHxlW3JdfHxvW2ldLnJlcGxhY2UoLyhcXFtbXlxcXV0rXSl8KE1NTU18TU18RER8ZGRkZCkvZywoZnVuY3Rpb24oZSx0LG8pe3JldHVybiB0fHxvLnNsaWNlKDEpfSkpfSkpfSh0LHZvaWQgMD09PW8/e306byk7cmV0dXJuIGkuY2FsbCh0aGlzLG4pfX19KSk7IiwiIWZ1bmN0aW9uKGUsaSl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9aSgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoaSk6KGU9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczplfHxzZWxmKS5kYXlqc19wbHVnaW5faXNCZXR3ZWVuPWkoKX0odGhpcywoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtyZXR1cm4gZnVuY3Rpb24oZSxpLHQpe2kucHJvdG90eXBlLmlzQmV0d2Vlbj1mdW5jdGlvbihlLGkscyxmKXt2YXIgbj10KGUpLG89dChpKSxyPVwiKFwiPT09KGY9Znx8XCIoKVwiKVswXSx1PVwiKVwiPT09ZlsxXTtyZXR1cm4ocj90aGlzLmlzQWZ0ZXIobixzKTohdGhpcy5pc0JlZm9yZShuLHMpKSYmKHU/dGhpcy5pc0JlZm9yZShvLHMpOiF0aGlzLmlzQWZ0ZXIobyxzKSl8fChyP3RoaXMuaXNCZWZvcmUobixzKTohdGhpcy5pc0FmdGVyKG4scykpJiYodT90aGlzLmlzQWZ0ZXIobyxzKTohdGhpcy5pc0JlZm9yZShvLHMpKX19fSkpOyIsIiFmdW5jdGlvbihlLHQpe1wib2JqZWN0XCI9PXR5cGVvZiBleHBvcnRzJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPXQoKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKHQpOihlPVwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWxUaGlzP2dsb2JhbFRoaXM6ZXx8c2VsZikuZGF5anNfcGx1Z2luX2FkdmFuY2VkRm9ybWF0PXQoKX0odGhpcywoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtyZXR1cm4gZnVuY3Rpb24oZSx0KXt2YXIgcj10LnByb3RvdHlwZSxuPXIuZm9ybWF0O3IuZm9ybWF0PWZ1bmN0aW9uKGUpe3ZhciB0PXRoaXMscj10aGlzLiRsb2NhbGUoKTtpZighdGhpcy5pc1ZhbGlkKCkpcmV0dXJuIG4uYmluZCh0aGlzKShlKTt2YXIgcz10aGlzLiR1dGlscygpLGE9KGV8fFwiWVlZWS1NTS1ERFRISDptbTpzc1pcIikucmVwbGFjZSgvXFxbKFteXFxdXSspXXxRfHdvfHd3fHd8V1d8V3x6enp8enxnZ2dnfEdHR0d8RG98WHx4fGt7MSwyfXxTL2csKGZ1bmN0aW9uKGUpe3N3aXRjaChlKXtjYXNlXCJRXCI6cmV0dXJuIE1hdGguY2VpbCgodC4kTSsxKS8zKTtjYXNlXCJEb1wiOnJldHVybiByLm9yZGluYWwodC4kRCk7Y2FzZVwiZ2dnZ1wiOnJldHVybiB0LndlZWtZZWFyKCk7Y2FzZVwiR0dHR1wiOnJldHVybiB0Lmlzb1dlZWtZZWFyKCk7Y2FzZVwid29cIjpyZXR1cm4gci5vcmRpbmFsKHQud2VlaygpLFwiV1wiKTtjYXNlXCJ3XCI6Y2FzZVwid3dcIjpyZXR1cm4gcy5zKHQud2VlaygpLFwid1wiPT09ZT8xOjIsXCIwXCIpO2Nhc2VcIldcIjpjYXNlXCJXV1wiOnJldHVybiBzLnModC5pc29XZWVrKCksXCJXXCI9PT1lPzE6MixcIjBcIik7Y2FzZVwia1wiOmNhc2VcImtrXCI6cmV0dXJuIHMucyhTdHJpbmcoMD09PXQuJEg/MjQ6dC4kSCksXCJrXCI9PT1lPzE6MixcIjBcIik7Y2FzZVwiWFwiOnJldHVybiBNYXRoLmZsb29yKHQuJGQuZ2V0VGltZSgpLzFlMyk7Y2FzZVwieFwiOnJldHVybiB0LiRkLmdldFRpbWUoKTtjYXNlXCJ6XCI6cmV0dXJuXCJbXCIrdC5vZmZzZXROYW1lKCkrXCJdXCI7Y2FzZVwienp6XCI6cmV0dXJuXCJbXCIrdC5vZmZzZXROYW1lKFwibG9uZ1wiKStcIl1cIjtkZWZhdWx0OnJldHVybiBlfX0pKTtyZXR1cm4gbi5iaW5kKHRoaXMpKGEpfX19KSk7IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS9leHRlbmRzXCI7XG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQG11aS94LWludGVybmFscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbi8qIHY4IGlnbm9yZSBzdGFydCAqL1xuXG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMnO1xuLy8gZGF5anMgaGFzIG5vIGV4cG9ydHMgZmllbGQgZGVmaW5lZFxuLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9pYW1rdW4vZGF5anMvaXNzdWVzLzI1NjJcbi8qIGVzbGludC1kaXNhYmxlIGltcG9ydC9leHRlbnNpb25zICovXG5pbXBvcnQgd2Vla09mWWVhclBsdWdpbiBmcm9tICdkYXlqcy9wbHVnaW4vd2Vla09mWWVhci5qcyc7XG5pbXBvcnQgY3VzdG9tUGFyc2VGb3JtYXRQbHVnaW4gZnJvbSAnZGF5anMvcGx1Z2luL2N1c3RvbVBhcnNlRm9ybWF0LmpzJztcbmltcG9ydCBsb2NhbGl6ZWRGb3JtYXRQbHVnaW4gZnJvbSAnZGF5anMvcGx1Z2luL2xvY2FsaXplZEZvcm1hdC5qcyc7XG5pbXBvcnQgaXNCZXR3ZWVuUGx1Z2luIGZyb20gJ2RheWpzL3BsdWdpbi9pc0JldHdlZW4uanMnO1xuaW1wb3J0IGFkdmFuY2VkRm9ybWF0UGx1Z2luIGZyb20gJ2RheWpzL3BsdWdpbi9hZHZhbmNlZEZvcm1hdC5qcyc7XG4vKiB2OCBpZ25vcmUgc3RvcCAqL1xuLyogZXNsaW50LWVuYWJsZSBpbXBvcnQvZXh0ZW5zaW9ucyAqL1xuaW1wb3J0IHsgd2Fybk9uY2UgfSBmcm9tICdAbXVpL3gtaW50ZXJuYWxzL3dhcm5pbmcnO1xuZGF5anMuZXh0ZW5kKGxvY2FsaXplZEZvcm1hdFBsdWdpbik7XG5kYXlqcy5leHRlbmQod2Vla09mWWVhclBsdWdpbik7XG5kYXlqcy5leHRlbmQoaXNCZXR3ZWVuUGx1Z2luKTtcbmRheWpzLmV4dGVuZChhZHZhbmNlZEZvcm1hdFBsdWdpbik7XG5jb25zdCBmb3JtYXRUb2tlbk1hcCA9IHtcbiAgLy8gWWVhclxuICBZWTogJ3llYXInLFxuICBZWVlZOiB7XG4gICAgc2VjdGlvblR5cGU6ICd5ZWFyJyxcbiAgICBjb250ZW50VHlwZTogJ2RpZ2l0JyxcbiAgICBtYXhMZW5ndGg6IDRcbiAgfSxcbiAgLy8gTW9udGhcbiAgTToge1xuICAgIHNlY3Rpb25UeXBlOiAnbW9udGgnLFxuICAgIGNvbnRlbnRUeXBlOiAnZGlnaXQnLFxuICAgIG1heExlbmd0aDogMlxuICB9LFxuICBNTTogJ21vbnRoJyxcbiAgTU1NOiB7XG4gICAgc2VjdGlvblR5cGU6ICdtb250aCcsXG4gICAgY29udGVudFR5cGU6ICdsZXR0ZXInXG4gIH0sXG4gIE1NTU06IHtcbiAgICBzZWN0aW9uVHlwZTogJ21vbnRoJyxcbiAgICBjb250ZW50VHlwZTogJ2xldHRlcidcbiAgfSxcbiAgLy8gRGF5IG9mIHRoZSBtb250aFxuICBEOiB7XG4gICAgc2VjdGlvblR5cGU6ICdkYXknLFxuICAgIGNvbnRlbnRUeXBlOiAnZGlnaXQnLFxuICAgIG1heExlbmd0aDogMlxuICB9LFxuICBERDogJ2RheScsXG4gIERvOiB7XG4gICAgc2VjdGlvblR5cGU6ICdkYXknLFxuICAgIGNvbnRlbnRUeXBlOiAnZGlnaXQtd2l0aC1sZXR0ZXInXG4gIH0sXG4gIC8vIERheSBvZiB0aGUgd2Vla1xuICBkOiB7XG4gICAgc2VjdGlvblR5cGU6ICd3ZWVrRGF5JyxcbiAgICBjb250ZW50VHlwZTogJ2RpZ2l0JyxcbiAgICBtYXhMZW5ndGg6IDJcbiAgfSxcbiAgZGQ6IHtcbiAgICBzZWN0aW9uVHlwZTogJ3dlZWtEYXknLFxuICAgIGNvbnRlbnRUeXBlOiAnbGV0dGVyJ1xuICB9LFxuICBkZGQ6IHtcbiAgICBzZWN0aW9uVHlwZTogJ3dlZWtEYXknLFxuICAgIGNvbnRlbnRUeXBlOiAnbGV0dGVyJ1xuICB9LFxuICBkZGRkOiB7XG4gICAgc2VjdGlvblR5cGU6ICd3ZWVrRGF5JyxcbiAgICBjb250ZW50VHlwZTogJ2xldHRlcidcbiAgfSxcbiAgLy8gTWVyaWRpZW1cbiAgQTogJ21lcmlkaWVtJyxcbiAgYTogJ21lcmlkaWVtJyxcbiAgLy8gSG91cnNcbiAgSDoge1xuICAgIHNlY3Rpb25UeXBlOiAnaG91cnMnLFxuICAgIGNvbnRlbnRUeXBlOiAnZGlnaXQnLFxuICAgIG1heExlbmd0aDogMlxuICB9LFxuICBISDogJ2hvdXJzJyxcbiAgaDoge1xuICAgIHNlY3Rpb25UeXBlOiAnaG91cnMnLFxuICAgIGNvbnRlbnRUeXBlOiAnZGlnaXQnLFxuICAgIG1heExlbmd0aDogMlxuICB9LFxuICBoaDogJ2hvdXJzJyxcbiAgLy8gTWludXRlc1xuICBtOiB7XG4gICAgc2VjdGlvblR5cGU6ICdtaW51dGVzJyxcbiAgICBjb250ZW50VHlwZTogJ2RpZ2l0JyxcbiAgICBtYXhMZW5ndGg6IDJcbiAgfSxcbiAgbW06ICdtaW51dGVzJyxcbiAgLy8gU2Vjb25kc1xuICBzOiB7XG4gICAgc2VjdGlvblR5cGU6ICdzZWNvbmRzJyxcbiAgICBjb250ZW50VHlwZTogJ2RpZ2l0JyxcbiAgICBtYXhMZW5ndGg6IDJcbiAgfSxcbiAgc3M6ICdzZWNvbmRzJ1xufTtcbmNvbnN0IGRlZmF1bHRGb3JtYXRzID0ge1xuICB5ZWFyOiAnWVlZWScsXG4gIG1vbnRoOiAnTU1NTScsXG4gIG1vbnRoU2hvcnQ6ICdNTU0nLFxuICBkYXlPZk1vbnRoOiAnRCcsXG4gIGRheU9mTW9udGhGdWxsOiAnRG8nLFxuICB3ZWVrZGF5OiAnZGRkZCcsXG4gIHdlZWtkYXlTaG9ydDogJ2RkJyxcbiAgaG91cnMyNGg6ICdISCcsXG4gIGhvdXJzMTJoOiAnaGgnLFxuICBtZXJpZGllbTogJ0EnLFxuICBtaW51dGVzOiAnbW0nLFxuICBzZWNvbmRzOiAnc3MnLFxuICBmdWxsRGF0ZTogJ2xsJyxcbiAga2V5Ym9hcmREYXRlOiAnTCcsXG4gIHNob3J0RGF0ZTogJ01NTSBEJyxcbiAgbm9ybWFsRGF0ZTogJ0QgTU1NTScsXG4gIG5vcm1hbERhdGVXaXRoV2Vla2RheTogJ2RkZCwgTU1NIEQnLFxuICBmdWxsVGltZTEyaDogJ2hoOm1tIEEnLFxuICBmdWxsVGltZTI0aDogJ0hIOm1tJyxcbiAga2V5Ym9hcmREYXRlVGltZTEyaDogJ0wgaGg6bW0gQScsXG4gIGtleWJvYXJkRGF0ZVRpbWUyNGg6ICdMIEhIOm1tJ1xufTtcbmZ1bmN0aW9uIHRocm93TWlzc2luZ1VUQ1BsdWdpbkVycm9yKCkge1xuICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ01VSSBYIERhdGUgUGlja2VyczogTWlzc2luZyBkYXlqcyBVVEMgcGx1Z2luLiAnICsgJ1VUQyBhbmQgdGltZXpvbmUgc3VwcG9ydCByZXF1aXJlcyB0aGUgZGF5anMgVVRDIHBsdWdpbiB0byBiZSBlbmFibGVkLiAnICsgJ1NlZSBodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvdGltZXpvbmUvI2RheS1qcy1hbmQtdXRjIGZvciBzZXR1cCBpbnN0cnVjdGlvbnMuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTM4KSk7XG59XG5mdW5jdGlvbiB0aHJvd01pc3NpbmdUaW1lem9uZVBsdWdpbkVycm9yKCkge1xuICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ01VSSBYIERhdGUgUGlja2VyczogTWlzc2luZyBkYXlqcyB0aW1lem9uZSBwbHVnaW4uICcgKyAnVGltZXpvbmUgc3VwcG9ydCByZXF1aXJlcyBib3RoIHRoZSBkYXlqcyBVVEMgYW5kIHRpbWV6b25lIHBsdWdpbnMgdG8gYmUgZW5hYmxlZC4gJyArICdTZWUgaHR0cHM6Ly9tdWkuY29tL3gvcmVhY3QtZGF0ZS1waWNrZXJzL3RpbWV6b25lLyNkYXktanMtYW5kLXRpbWV6b25lIGZvciBzZXR1cCBpbnN0cnVjdGlvbnMuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTM5KSk7XG59XG4vKipcbiAqIEJhc2VkIG9uIGBAZGF0ZS1pby9kYXlqc2BcbiAqXG4gKiBNSVQgTGljZW5zZVxuICpcbiAqIENvcHlyaWdodCAoYykgMjAxNyBEbWl0cml5IEtvdmFsZW5rb1xuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHlcbiAqIG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWxcbiAqIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHNcbiAqIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGxcbiAqIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpc1xuICogZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczpcbiAqXG4gKiBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZCBpbiBhbGxcbiAqIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4gKlxuICogVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUlxuICogSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksXG4gKiBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEVcbiAqIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVJcbiAqIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sXG4gKiBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRVxuICogU09GVFdBUkUuXG4gKi9cbmV4cG9ydCBjbGFzcyBBZGFwdGVyRGF5anMge1xuICBpc01VSUFkYXB0ZXIgPSB0cnVlO1xuICBpc1RpbWV6b25lQ29tcGF0aWJsZSA9IHRydWU7XG4gIGxpYiA9ICdkYXlqcyc7XG4gIGVzY2FwZWRDaGFyYWN0ZXJzID0ge1xuICAgIHN0YXJ0OiAnWycsXG4gICAgZW5kOiAnXSdcbiAgfTtcbiAgZm9ybWF0VG9rZW5NYXAgPSBmb3JtYXRUb2tlbk1hcDtcbiAgY29uc3RydWN0b3Ioe1xuICAgIGxvY2FsZSxcbiAgICBmb3JtYXRzXG4gIH0gPSB7fSkge1xuICAgIHRoaXMubG9jYWxlID0gbG9jYWxlO1xuICAgIHRoaXMuZm9ybWF0cyA9IF9leHRlbmRzKHt9LCBkZWZhdWx0Rm9ybWF0cywgZm9ybWF0cyk7XG5cbiAgICAvLyBNb3ZlZCBwbHVnaW5zIHRvIHRoZSBjb25zdHJ1Y3RvciB0byBhbGxvdyBmb3IgdXNlcnMgdG8gdXNlIG9wdGlvbnMgb24gdGhlIGxpYnJhcnlcbiAgICAvLyBmb3IgcmVmZXJlbmNlOiBodHRwczovL2dpdGh1Yi5jb20vbXVpL211aS14L3B1bGwvMTExNTFcbiAgICBkYXlqcy5leHRlbmQoY3VzdG9tUGFyc2VGb3JtYXRQbHVnaW4pO1xuICB9XG4gIHNldExvY2FsZVRvVmFsdWUgPSB2YWx1ZSA9PiB7XG4gICAgY29uc3QgZXhwZWN0ZWRMb2NhbGUgPSB0aGlzLmdldEN1cnJlbnRMb2NhbGVDb2RlKCk7XG4gICAgaWYgKGV4cGVjdGVkTG9jYWxlID09PSB2YWx1ZS5sb2NhbGUoKSkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWUubG9jYWxlKGV4cGVjdGVkTG9jYWxlKTtcbiAgfTtcbiAgaGFzVVRDUGx1Z2luID0gKCkgPT4gdHlwZW9mIGRheWpzLnV0YyAhPT0gJ3VuZGVmaW5lZCc7XG4gIGhhc1RpbWV6b25lUGx1Z2luID0gKCkgPT4gdHlwZW9mIGRheWpzLnR6ICE9PSAndW5kZWZpbmVkJztcbiAgaXNTYW1lID0gKHZhbHVlLCBjb21wYXJpbmcsIGNvbXBhcmlzb25UZW1wbGF0ZSkgPT4ge1xuICAgIGNvbnN0IGNvbXBhcmluZ0luVmFsdWVUaW1lem9uZSA9IHRoaXMuc2V0VGltZXpvbmUoY29tcGFyaW5nLCB0aGlzLmdldFRpbWV6b25lKHZhbHVlKSk7XG4gICAgcmV0dXJuIHZhbHVlLmZvcm1hdChjb21wYXJpc29uVGVtcGxhdGUpID09PSBjb21wYXJpbmdJblZhbHVlVGltZXpvbmUuZm9ybWF0KGNvbXBhcmlzb25UZW1wbGF0ZSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJlcGxhY2VzIFwiZGVmYXVsdFwiIGJ5IHVuZGVmaW5lZCBhbmQgXCJzeXN0ZW1cIiBieSB0aGUgc3lzdGVtIHRpbWV6b25lIGJlZm9yZSBwYXNzaW5nIGl0IHRvIGBkYXlqc2AuXG4gICAqL1xuICBjbGVhblRpbWV6b25lID0gdGltZXpvbmUgPT4ge1xuICAgIHN3aXRjaCAodGltZXpvbmUpIHtcbiAgICAgIGNhc2UgJ2RlZmF1bHQnOlxuICAgICAgICB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgY2FzZSAnc3lzdGVtJzpcbiAgICAgICAge1xuICAgICAgICAgIHJldHVybiBkYXlqcy50ei5ndWVzcygpO1xuICAgICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB7XG4gICAgICAgICAgcmV0dXJuIHRpbWV6b25lO1xuICAgICAgICB9XG4gICAgfVxuICB9O1xuICBjcmVhdGVTeXN0ZW1EYXRlID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB0aGlzLnNldExvY2FsZVRvVmFsdWUoZGF5anModmFsdWUpKTtcbiAgfTtcbiAgY3JlYXRlVVRDRGF0ZSA9IHZhbHVlID0+IHtcbiAgICAvKiB2OCBpZ25vcmUgbmV4dCAzICovXG4gICAgaWYgKCF0aGlzLmhhc1VUQ1BsdWdpbigpKSB7XG4gICAgICB0aHJvd01pc3NpbmdVVENQbHVnaW5FcnJvcigpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zZXRMb2NhbGVUb1ZhbHVlKGRheWpzLnV0Yyh2YWx1ZSkpO1xuICB9O1xuICBjcmVhdGVUWkRhdGUgPSAodmFsdWUsIHRpbWV6b25lKSA9PiB7XG4gICAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICAgIGlmICghdGhpcy5oYXNVVENQbHVnaW4oKSkge1xuICAgICAgdGhyb3dNaXNzaW5nVVRDUGx1Z2luRXJyb3IoKTtcbiAgICB9XG5cbiAgICAvKiB2OCBpZ25vcmUgbmV4dCAzICovXG4gICAgaWYgKCF0aGlzLmhhc1RpbWV6b25lUGx1Z2luKCkpIHtcbiAgICAgIHRocm93TWlzc2luZ1RpbWV6b25lUGx1Z2luRXJyb3IoKTtcbiAgICB9XG4gICAgY29uc3Qga2VlcExvY2FsVGltZSA9IHZhbHVlICE9PSB1bmRlZmluZWQgJiYgIXZhbHVlLmVuZHNXaXRoKCdaJyk7XG4gICAgcmV0dXJuIHRoaXMuc2V0TG9jYWxlVG9WYWx1ZShkYXlqcyh2YWx1ZSkudHoodGhpcy5jbGVhblRpbWV6b25lKHRpbWV6b25lKSwga2VlcExvY2FsVGltZSkpO1xuICB9O1xuICBnZXRMb2NhbGVGb3JtYXRzID0gKCkgPT4ge1xuICAgIGNvbnN0IGxvY2FsZXMgPSBkYXlqcy5McztcbiAgICBjb25zdCBsb2NhbGUgPSB0aGlzLmxvY2FsZSB8fCAnZW4nO1xuICAgIGxldCBsb2NhbGVPYmplY3QgPSBsb2NhbGVzW2xvY2FsZV07XG4gICAgaWYgKGxvY2FsZU9iamVjdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAvKiB2OCBpZ25vcmUgc3RhcnQgKi9cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIHdhcm5PbmNlKFsnTVVJIFg6IFlvdXIgbG9jYWxlIGhhcyBub3QgYmVlbiBmb3VuZC4nLCAnRWl0aGVyIHRoZSBsb2NhbGUga2V5IGlzIG5vdCBhIHN1cHBvcnRlZCBvbmUuIExvY2FsZXMgc3VwcG9ydGVkIGJ5IGRheWpzIGFyZSBhdmFpbGFibGUgaGVyZTogaHR0cHM6Ly9naXRodWIuY29tL2lhbWt1bi9kYXlqcy90cmVlL2Rldi9zcmMvbG9jYWxlLicsIFwiT3IgeW91IGZvcmdldCB0byBpbXBvcnQgdGhlIGxvY2FsZSBmcm9tICdkYXlqcy9sb2NhbGUve2xvY2FsZVVzZWR9J1wiLCAnZmFsbGJhY2sgb24gRW5nbGlzaCBsb2NhbGUuJ10pO1xuICAgICAgfVxuICAgICAgLyogdjggaWdub3JlIHN0b3AgKi9cbiAgICAgIGxvY2FsZU9iamVjdCA9IGxvY2FsZXMuZW47XG4gICAgfVxuICAgIHJldHVybiBsb2NhbGVPYmplY3QuZm9ybWF0cztcbiAgfTtcblxuICAvKipcbiAgICogSWYgdGhlIG5ldyBkYXkgZG9lcyBub3QgaGF2ZSB0aGUgc2FtZSBvZmZzZXQgYXMgdGhlIG9sZCBvbmUgKHdoZW4gc3dpdGNoaW5nIHRvIHN1bW1lciBkYXkgdGltZSBmb3IgZXhhbXBsZSksXG4gICAqIFRoZW4gZGF5anMgd2lsbCBub3QgYXV0b21hdGljYWxseSBhZGp1c3QgdGhlIG9mZnNldCAobW9tZW50IGRvZXMpLlxuICAgKiBXZSBoYXZlIHRvIHBhcnNlIGFnYWluIHRoZSB2YWx1ZSB0byBtYWtlIHN1cmUgdGhlIGBmaXhPZmZzZXRgIG1ldGhvZCBpcyBhcHBsaWVkLlxuICAgKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2lhbWt1bi9kYXlqcy9ibG9iL2IzNjI0ZGU2MTlkNmU3MzRjZDBmZmRiYmQzNTAyMTg1MDQxYzFiNjAvc3JjL3BsdWdpbi90aW1lem9uZS9pbmRleC5qcyNMNzJcbiAgICovXG4gIGFkanVzdE9mZnNldCA9IHZhbHVlID0+IHtcbiAgICBpZiAoIXRoaXMuaGFzVGltZXpvbmVQbHVnaW4oKSkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBjb25zdCB0aW1lem9uZSA9IHRoaXMuZ2V0VGltZXpvbmUodmFsdWUpO1xuICAgIGlmICh0aW1lem9uZSAhPT0gJ1VUQycpIHtcbiAgICAgIGNvbnN0IGZpeGVkVmFsdWUgPSB2YWx1ZS50eih0aGlzLmNsZWFuVGltZXpvbmUodGltZXpvbmUpLCB0cnVlKTtcbiAgICAgIC8vIFRPRE86IFNpbXBsaWZ5IHRoZSBjYXNlIHdoZW4gd2UgcmFpc2UgdGhlIGBkYXlqc2AgcGVlciBkZXAgdG8gMS4xMS4xMiAoaHR0cHM6Ly9naXRodWIuY29tL2lhbWt1bi9kYXlqcy9yZWxlYXNlcy90YWcvdjEuMTEuMTIpXG4gICAgICAvKiB2OCBpZ25vcmUgbmV4dCAzICovXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBpZiAoZml4ZWRWYWx1ZS4kb2Zmc2V0ID09PSAodmFsdWUuJG9mZnNldCA/PyAwKSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgICAvLyBDaGFuZ2Ugb25seSB3aGF0IGlzIG5lZWRlZCB0byBhdm9pZCBjcmVhdGluZyBhIG5ldyBvYmplY3Qgd2l0aCB1bndhbnRlZCBkYXRhXG4gICAgICAvLyBFc3BlY2lhbGx5IGltcG9ydGFudCB3aGVuIHVzZWQgaW4gYW4gZW52aXJvbm1lbnQgd2hlcmUgdXRjIG9yIHRpbWV6b25lIGRhdGVzIGFyZSB1c2VkIG9ubHkgaW4gc29tZSBwbGFjZXNcbiAgICAgIC8vIFJlZmVyZW5jZTogaHR0cHM6Ly9naXRodWIuY29tL211aS9tdWkteC9pc3N1ZXMvMTMyOTBcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIHZhbHVlLiRvZmZzZXQgPSBmaXhlZFZhbHVlLiRvZmZzZXQ7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICAvKipcbiAgICogT24gZGF0ZXMgcHJlZGF0aW5nIHRoZSB0aW1lem9uZSBzdGFuZGFyZGl6YXRpb24sIElBTkEgZmFsbHMgYmFjayBvbiB0aGUgTG9jYWwgTWVhbiBUaW1lIG9mIHRoZVxuICAgKiBsb2NhdGlvbiwgd2hvc2Ugb2Zmc2V0IGlzIG5vdCBhIHJvdW5kIG51bWJlciBvZiBtaW51dGVzIChgQXNpYS9Lb2xrYXRhYCBpcyBgR01UKzA1OjUzOjI4YCkuXG4gICAqIGBkYXlqc2AgdGhlbiBtb3ZlcyB0aGUgZGF5IG9mIHRoZSBtb250aCB3aGVuIG9ubHkgdGhlIHllYXIgb3IgdGhlIG1vbnRoIHdhcyBtZWFudCB0byBjaGFuZ2UuXG4gICAqIGBkYXlzSW5Nb250aCgpYCBpcyB1bnVzYWJsZSBvbiBzdWNoIGEgdmFsdWUgYmVjYXVzZSBpdCBkZXJpdmVzIGZyb20gdGhlIGVxdWFsbHkgYnJva2VuXG4gICAqIGBlbmRPZignbW9udGgnKWAsIGhlbmNlIGNvbXB1dGluZyBpdCBvbiBhIHBsYWluIFVUQyB2YWx1ZSBpbnN0ZWFkLlxuICAgKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL211aS9tdWkteC9pc3N1ZXMvMjMxNjNcbiAgICovXG4gIHJlc3RvcmVEYXlPZk1vbnRoID0gKHZhbHVlLCByZWZlcmVuY2UpID0+IHtcbiAgICBjb25zdCB0aW1lem9uZSA9IHRoaXMuZ2V0VGltZXpvbmUodmFsdWUpO1xuICAgIC8vIGBzeXN0ZW1gIGFuZCBgVVRDYCB2YWx1ZXMga2VlcCBhbiBvZmZzZXQgdGhhdCBtYXRjaGVzIHRoZWlyIGluc3RhbnQsIHNvIHRoZXkgYXJlIG5ldmVyIGFmZmVjdGVkLlxuICAgIGlmICghdGhpcy5oYXNVVENQbHVnaW4oKSB8fCB0aW1lem9uZSA9PT0gJ3N5c3RlbScgfHwgdGltZXpvbmUgPT09ICdVVEMnKSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGNvbnN0IHdhbGxDbG9jayA9IGRheWpzLnV0Yyh2YWx1ZS5mb3JtYXQoJ1lZWVktTU0tRERUSEg6bW06c3MuU1NTJykpO1xuXG4gICAgLy8gWWVhcnMgYWJvdmUgOTk5OSBkb24ndCByb3VuZC10cmlwIHRocm91Z2ggdGhlIElTTyBmb3JtYXQsIGFuZCBhbiBpbnZhbGlkIHZhbHVlIGZvcm1hdHMgdG9cbiAgICAvLyBgSW52YWxpZCBEYXRlYC4gQm90aCB3b3VsZCBtYWtlIHRoZSBjb21wYXJpc29uIGJlbG93IGBOYU5gLlxuICAgIGlmICghd2FsbENsb2NrLmlzVmFsaWQoKSkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cblxuICAgIC8vIEEgc2hvcnRlciB0YXJnZXQgbW9udGggbGVnaXRpbWF0ZWx5IGNsYW1wcyB0aGUgZGF5IChgSmFuIDMxYCArIDEgbW9udGggaXMgYEZlYiAyOGApLlxuICAgIGNvbnN0IGV4cGVjdGVkRGF5T2ZNb250aCA9IE1hdGgubWluKHJlZmVyZW5jZS5kYXRlKCksIHdhbGxDbG9jay5kYXlzSW5Nb250aCgpKTtcbiAgICBpZiAodmFsdWUuZGF0ZSgpID09PSBleHBlY3RlZERheU9mTW9udGgpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlLnNldCgnZGF0ZScsIGV4cGVjdGVkRGF5T2ZNb250aCk7XG4gIH07XG4gIGRhdGUgPSAodmFsdWUsIHRpbWV6b25lID0gJ2RlZmF1bHQnKSA9PiB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKHRpbWV6b25lID09PSAnVVRDJykge1xuICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlVVRDRGF0ZSh2YWx1ZSk7XG4gICAgfVxuICAgIGlmICh0aW1lem9uZSA9PT0gJ3N5c3RlbScgfHwgdGltZXpvbmUgPT09ICdkZWZhdWx0JyAmJiAhdGhpcy5oYXNUaW1lem9uZVBsdWdpbigpKSB7XG4gICAgICByZXR1cm4gdGhpcy5jcmVhdGVTeXN0ZW1EYXRlKHZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY3JlYXRlVFpEYXRlKHZhbHVlLCB0aW1lem9uZSk7XG4gIH07XG4gIGdldEludmFsaWREYXRlID0gKCkgPT4gZGF5anMobmV3IERhdGUoJ0ludmFsaWQgZGF0ZScpKTtcbiAgZ2V0VGltZXpvbmUgPSB2YWx1ZSA9PiB7XG4gICAgaWYgKHRoaXMuaGFzVGltZXpvbmVQbHVnaW4oKSkge1xuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgY29uc3Qgem9uZSA9IHZhbHVlLiR4Py4kdGltZXpvbmU7XG4gICAgICBpZiAoem9uZSkge1xuICAgICAgICByZXR1cm4gem9uZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuaGFzVVRDUGx1Z2luKCkgJiYgdmFsdWUuaXNVVEMoKSkge1xuICAgICAgcmV0dXJuICdVVEMnO1xuICAgIH1cbiAgICByZXR1cm4gJ3N5c3RlbSc7XG4gIH07XG4gIHNldFRpbWV6b25lID0gKHZhbHVlLCB0aW1lem9uZSkgPT4ge1xuICAgIGlmICh0aGlzLmdldFRpbWV6b25lKHZhbHVlKSA9PT0gdGltZXpvbmUpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKHRpbWV6b25lID09PSAnVVRDJykge1xuICAgICAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICAgICAgaWYgKCF0aGlzLmhhc1VUQ1BsdWdpbigpKSB7XG4gICAgICAgIHRocm93TWlzc2luZ1VUQ1BsdWdpbkVycm9yKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsdWUudXRjKCk7XG4gICAgfVxuXG4gICAgLy8gV2Uga25vdyB0aGF0IHdlIGhhdmUgdGhlIFVUQyBwbHVnaW4uXG4gICAgLy8gT3RoZXJ3aXNlLCB0aGUgdmFsdWUgdGltZXpvbmUgd291bGQgYWx3YXlzIGVxdWFsIFwic3lzdGVtXCIuXG4gICAgLy8gQW5kIGl0IHdvdWxkIGJlIGNhdWdodCBieSB0aGUgZmlyc3QgXCJpZlwiIG9mIHRoaXMgbWV0aG9kLlxuICAgIGlmICh0aW1lem9uZSA9PT0gJ3N5c3RlbScpIHtcbiAgICAgIHJldHVybiB2YWx1ZS5sb2NhbCgpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuaGFzVGltZXpvbmVQbHVnaW4oKSkge1xuICAgICAgaWYgKHRpbWV6b25lID09PSAnZGVmYXVsdCcpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuXG4gICAgICAvKiB2OCBpZ25vcmUgbmV4dCAqL1xuICAgICAgdGhyb3dNaXNzaW5nVGltZXpvbmVQbHVnaW5FcnJvcigpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zZXRMb2NhbGVUb1ZhbHVlKGRheWpzLnR6KHZhbHVlLCB0aGlzLmNsZWFuVGltZXpvbmUodGltZXpvbmUpKSk7XG4gIH07XG4gIHRvSnNEYXRlID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB2YWx1ZS50b0RhdGUoKTtcbiAgfTtcbiAgcGFyc2UgPSAodmFsdWUsIGZvcm1hdCkgPT4ge1xuICAgIGlmICh2YWx1ZSA9PT0gJycpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gZGF5anModmFsdWUsIGZvcm1hdCwgdGhpcy5sb2NhbGUsIHRydWUpO1xuICB9O1xuICBnZXRDdXJyZW50TG9jYWxlQ29kZSA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5sb2NhbGUgfHwgJ2VuJztcbiAgfTtcbiAgaXMxMkhvdXJDeWNsZUluQ3VycmVudExvY2FsZSA9ICgpID0+IHtcbiAgICAvKiB2OCBpZ25vcmUgbmV4dCAqL1xuICAgIHJldHVybiAvQXxhLy50ZXN0KHRoaXMuZ2V0TG9jYWxlRm9ybWF0cygpLkxUIHx8ICcnKTtcbiAgfTtcbiAgZXhwYW5kRm9ybWF0ID0gZm9ybWF0ID0+IHtcbiAgICBjb25zdCBsb2NhbGVGb3JtYXRzID0gdGhpcy5nZXRMb2NhbGVGb3JtYXRzKCk7XG5cbiAgICAvLyBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9pYW1rdW4vZGF5anMvYmxvYi9kZXYvc3JjL3BsdWdpbi9sb2NhbGl6ZWRGb3JtYXQvaW5kZXguanNcbiAgICBjb25zdCB0ID0gZm9ybWF0QmlzID0+IGZvcm1hdEJpcy5yZXBsYWNlKC8oXFxbW15cXF1dK10pfChNTU1NfE1NfEREfGRkZGQpL2csIChfLCBhLCBiKSA9PiBhIHx8IGIuc2xpY2UoMSkpO1xuICAgIHJldHVybiBmb3JtYXQucmVwbGFjZSgvKFxcW1teXFxdXStdKXwoTFRTP3xsezEsNH18THsxLDR9KS9nLCAoXywgYSwgYikgPT4ge1xuICAgICAgY29uc3QgQiA9IGIgJiYgYi50b1VwcGVyQ2FzZSgpO1xuICAgICAgcmV0dXJuIGEgfHwgbG9jYWxlRm9ybWF0c1tiXSB8fCB0KGxvY2FsZUZvcm1hdHNbQl0pO1xuICAgIH0pO1xuICB9O1xuICBpc1ZhbGlkID0gdmFsdWUgPT4ge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZS5pc1ZhbGlkKCk7XG4gIH07XG4gIGZvcm1hdCA9ICh2YWx1ZSwgZm9ybWF0S2V5KSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybWF0QnlTdHJpbmcodmFsdWUsIHRoaXMuZm9ybWF0c1tmb3JtYXRLZXldKTtcbiAgfTtcbiAgZm9ybWF0QnlTdHJpbmcgPSAodmFsdWUsIGZvcm1hdFN0cmluZykgPT4ge1xuICAgIHJldHVybiB0aGlzLnNldExvY2FsZVRvVmFsdWUodmFsdWUpLmZvcm1hdChmb3JtYXRTdHJpbmcpO1xuICB9O1xuICBmb3JtYXROdW1iZXIgPSBudW1iZXJUb0Zvcm1hdCA9PiB7XG4gICAgcmV0dXJuIG51bWJlclRvRm9ybWF0O1xuICB9O1xuICBpc0VxdWFsID0gKHZhbHVlLCBjb21wYXJpbmcpID0+IHtcbiAgICBpZiAodmFsdWUgPT09IG51bGwgJiYgY29tcGFyaW5nID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IGNvbXBhcmluZyA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWUudG9EYXRlKCkuZ2V0VGltZSgpID09PSBjb21wYXJpbmcudG9EYXRlKCkuZ2V0VGltZSgpO1xuICB9O1xuICBpc1NhbWVZZWFyID0gKHZhbHVlLCBjb21wYXJpbmcpID0+IHtcbiAgICByZXR1cm4gdGhpcy5pc1NhbWUodmFsdWUsIGNvbXBhcmluZywgJ1lZWVknKTtcbiAgfTtcbiAgaXNTYW1lTW9udGggPSAodmFsdWUsIGNvbXBhcmluZykgPT4ge1xuICAgIHJldHVybiB0aGlzLmlzU2FtZSh2YWx1ZSwgY29tcGFyaW5nLCAnWVlZWS1NTScpO1xuICB9O1xuICBpc1NhbWVEYXkgPSAodmFsdWUsIGNvbXBhcmluZykgPT4ge1xuICAgIHJldHVybiB0aGlzLmlzU2FtZSh2YWx1ZSwgY29tcGFyaW5nLCAnWVlZWS1NTS1ERCcpO1xuICB9O1xuICBpc1NhbWVIb3VyID0gKHZhbHVlLCBjb21wYXJpbmcpID0+IHtcbiAgICByZXR1cm4gdmFsdWUuaXNTYW1lKGNvbXBhcmluZywgJ2hvdXInKTtcbiAgfTtcbiAgaXNBZnRlciA9ICh2YWx1ZSwgY29tcGFyaW5nKSA9PiB7XG4gICAgcmV0dXJuIHZhbHVlID4gY29tcGFyaW5nO1xuICB9O1xuICBpc0FmdGVyWWVhciA9ICh2YWx1ZSwgY29tcGFyaW5nKSA9PiB7XG4gICAgaWYgKCF0aGlzLmhhc1VUQ1BsdWdpbigpKSB7XG4gICAgICByZXR1cm4gdmFsdWUuaXNBZnRlcihjb21wYXJpbmcsICd5ZWFyJyk7XG4gICAgfVxuICAgIHJldHVybiAhdGhpcy5pc1NhbWVZZWFyKHZhbHVlLCBjb21wYXJpbmcpICYmIHZhbHVlLnV0YygpID4gY29tcGFyaW5nLnV0YygpO1xuICB9O1xuICBpc0FmdGVyRGF5ID0gKHZhbHVlLCBjb21wYXJpbmcpID0+IHtcbiAgICBpZiAoIXRoaXMuaGFzVVRDUGx1Z2luKCkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS5pc0FmdGVyKGNvbXBhcmluZywgJ2RheScpO1xuICAgIH1cbiAgICByZXR1cm4gIXRoaXMuaXNTYW1lRGF5KHZhbHVlLCBjb21wYXJpbmcpICYmIHZhbHVlLnV0YygpID4gY29tcGFyaW5nLnV0YygpO1xuICB9O1xuICBpc0JlZm9yZSA9ICh2YWx1ZSwgY29tcGFyaW5nKSA9PiB7XG4gICAgcmV0dXJuIHZhbHVlIDwgY29tcGFyaW5nO1xuICB9O1xuICBpc0JlZm9yZVllYXIgPSAodmFsdWUsIGNvbXBhcmluZykgPT4ge1xuICAgIGlmICghdGhpcy5oYXNVVENQbHVnaW4oKSkge1xuICAgICAgcmV0dXJuIHZhbHVlLmlzQmVmb3JlKGNvbXBhcmluZywgJ3llYXInKTtcbiAgICB9XG4gICAgcmV0dXJuICF0aGlzLmlzU2FtZVllYXIodmFsdWUsIGNvbXBhcmluZykgJiYgdmFsdWUudXRjKCkgPCBjb21wYXJpbmcudXRjKCk7XG4gIH07XG4gIGlzQmVmb3JlRGF5ID0gKHZhbHVlLCBjb21wYXJpbmcpID0+IHtcbiAgICBpZiAoIXRoaXMuaGFzVVRDUGx1Z2luKCkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS5pc0JlZm9yZShjb21wYXJpbmcsICdkYXknKTtcbiAgICB9XG4gICAgcmV0dXJuICF0aGlzLmlzU2FtZURheSh2YWx1ZSwgY29tcGFyaW5nKSAmJiB2YWx1ZS51dGMoKSA8IGNvbXBhcmluZy51dGMoKTtcbiAgfTtcbiAgaXNXaXRoaW5SYW5nZSA9ICh2YWx1ZSwgW3N0YXJ0LCBlbmRdKSA9PiB7XG4gICAgcmV0dXJuIHZhbHVlID49IHN0YXJ0ICYmIHZhbHVlIDw9IGVuZDtcbiAgfTtcbiAgc3RhcnRPZlllYXIgPSB2YWx1ZSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLnN0YXJ0T2YoJ3llYXInKSk7XG4gIH07XG4gIHN0YXJ0T2ZNb250aCA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuc3RhcnRPZignbW9udGgnKSk7XG4gIH07XG4gIHN0YXJ0T2ZXZWVrID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh0aGlzLnNldExvY2FsZVRvVmFsdWUodmFsdWUpLnN0YXJ0T2YoJ3dlZWsnKSk7XG4gIH07XG4gIHN0YXJ0T2ZEYXkgPSB2YWx1ZSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLnN0YXJ0T2YoJ2RheScpKTtcbiAgfTtcbiAgZW5kT2ZZZWFyID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh2YWx1ZS5lbmRPZigneWVhcicpKTtcbiAgfTtcbiAgZW5kT2ZNb250aCA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuZW5kT2YoJ21vbnRoJykpO1xuICB9O1xuICBlbmRPZldlZWsgPSB2YWx1ZSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHRoaXMuc2V0TG9jYWxlVG9WYWx1ZSh2YWx1ZSkuZW5kT2YoJ3dlZWsnKSk7XG4gIH07XG4gIGVuZE9mRGF5ID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh2YWx1ZS5lbmRPZignZGF5JykpO1xuICB9O1xuICBhZGRZZWFycyA9ICh2YWx1ZSwgYW1vdW50KSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHRoaXMucmVzdG9yZURheU9mTW9udGgodmFsdWUuYWRkKGFtb3VudCwgJ3llYXInKSwgdmFsdWUpKTtcbiAgfTtcbiAgYWRkTW9udGhzID0gKHZhbHVlLCBhbW91bnQpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodGhpcy5yZXN0b3JlRGF5T2ZNb250aCh2YWx1ZS5hZGQoYW1vdW50LCAnbW9udGgnKSwgdmFsdWUpKTtcbiAgfTtcbiAgYWRkV2Vla3MgPSAodmFsdWUsIGFtb3VudCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh2YWx1ZS5hZGQoYW1vdW50LCAnd2VlaycpKTtcbiAgfTtcbiAgYWRkRGF5cyA9ICh2YWx1ZSwgYW1vdW50KSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLmFkZChhbW91bnQsICdkYXknKSk7XG4gIH07XG4gIGFkZEhvdXJzID0gKHZhbHVlLCBhbW91bnQpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuYWRkKGFtb3VudCwgJ2hvdXInKSk7XG4gIH07XG4gIGFkZE1pbnV0ZXMgPSAodmFsdWUsIGFtb3VudCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh2YWx1ZS5hZGQoYW1vdW50LCAnbWludXRlJykpO1xuICB9O1xuICBhZGRTZWNvbmRzID0gKHZhbHVlLCBhbW91bnQpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuYWRkKGFtb3VudCwgJ3NlY29uZCcpKTtcbiAgfTtcbiAgZ2V0WWVhciA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUueWVhcigpO1xuICB9O1xuICBnZXRNb250aCA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUubW9udGgoKTtcbiAgfTtcbiAgZ2V0RGF0ZSA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUuZGF0ZSgpO1xuICB9O1xuICBnZXRIb3VycyA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUuaG91cigpO1xuICB9O1xuICBnZXRNaW51dGVzID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB2YWx1ZS5taW51dGUoKTtcbiAgfTtcbiAgZ2V0U2Vjb25kcyA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUuc2Vjb25kKCk7XG4gIH07XG4gIGdldE1pbGxpc2Vjb25kcyA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUubWlsbGlzZWNvbmQoKTtcbiAgfTtcbiAgc2V0WWVhciA9ICh2YWx1ZSwgeWVhcikgPT4ge1xuICAgIHJldHVybiB0aGlzLmFkanVzdE9mZnNldCh0aGlzLnJlc3RvcmVEYXlPZk1vbnRoKHZhbHVlLnNldCgneWVhcicsIHllYXIpLCB2YWx1ZSkpO1xuICB9O1xuICBzZXRNb250aCA9ICh2YWx1ZSwgbW9udGgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodGhpcy5yZXN0b3JlRGF5T2ZNb250aCh2YWx1ZS5zZXQoJ21vbnRoJywgbW9udGgpLCB2YWx1ZSkpO1xuICB9O1xuICBzZXREYXRlID0gKHZhbHVlLCBkYXRlKSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLnNldCgnZGF0ZScsIGRhdGUpKTtcbiAgfTtcbiAgc2V0SG91cnMgPSAodmFsdWUsIGhvdXJzKSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLnNldCgnaG91cicsIGhvdXJzKSk7XG4gIH07XG4gIHNldE1pbnV0ZXMgPSAodmFsdWUsIG1pbnV0ZXMpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuc2V0KCdtaW51dGUnLCBtaW51dGVzKSk7XG4gIH07XG4gIHNldFNlY29uZHMgPSAodmFsdWUsIHNlY29uZHMpID0+IHtcbiAgICByZXR1cm4gdGhpcy5hZGp1c3RPZmZzZXQodmFsdWUuc2V0KCdzZWNvbmQnLCBzZWNvbmRzKSk7XG4gIH07XG4gIHNldE1pbGxpc2Vjb25kcyA9ICh2YWx1ZSwgbWlsbGlzZWNvbmRzKSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuYWRqdXN0T2Zmc2V0KHZhbHVlLnNldCgnbWlsbGlzZWNvbmQnLCBtaWxsaXNlY29uZHMpKTtcbiAgfTtcbiAgZ2V0RGF5c0luTW9udGggPSB2YWx1ZSA9PiB7XG4gICAgcmV0dXJuIHZhbHVlLmRheXNJbk1vbnRoKCk7XG4gIH07XG4gIGdldFdlZWtBcnJheSA9IHZhbHVlID0+IHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuc3RhcnRPZldlZWsodGhpcy5zdGFydE9mTW9udGgodmFsdWUpKTtcbiAgICBjb25zdCBlbmQgPSB0aGlzLmVuZE9mV2Vlayh0aGlzLmVuZE9mTW9udGgodmFsdWUpKTtcbiAgICBsZXQgY291bnQgPSAwO1xuICAgIGxldCBjdXJyZW50ID0gc3RhcnQ7XG4gICAgY29uc3QgbmVzdGVkV2Vla3MgPSBbXTtcbiAgICB3aGlsZSAoY3VycmVudCA8IGVuZCkge1xuICAgICAgY29uc3Qgd2Vla051bWJlciA9IE1hdGguZmxvb3IoY291bnQgLyA3KTtcbiAgICAgIG5lc3RlZFdlZWtzW3dlZWtOdW1iZXJdID0gbmVzdGVkV2Vla3Nbd2Vla051bWJlcl0gfHwgW107XG4gICAgICBuZXN0ZWRXZWVrc1t3ZWVrTnVtYmVyXS5wdXNoKGN1cnJlbnQpO1xuICAgICAgY3VycmVudCA9IHRoaXMuYWRkRGF5cyhjdXJyZW50LCAxKTtcbiAgICAgIGNvdW50ICs9IDE7XG4gICAgfVxuICAgIHJldHVybiBuZXN0ZWRXZWVrcztcbiAgfTtcbiAgZ2V0V2Vla051bWJlciA9IHZhbHVlID0+IHtcbiAgICByZXR1cm4gdmFsdWUud2VlaygpO1xuICB9O1xuICBnZXREYXlPZldlZWsodmFsdWUpIHtcbiAgICByZXR1cm4gdmFsdWUuZGF5KCkgKyAxO1xuICB9XG4gIGdldFllYXJSYW5nZSA9IChbc3RhcnQsIGVuZF0pID0+IHtcbiAgICBjb25zdCBzdGFydERhdGUgPSB0aGlzLnN0YXJ0T2ZZZWFyKHN0YXJ0KTtcbiAgICBjb25zdCBlbmREYXRlID0gdGhpcy5lbmRPZlllYXIoZW5kKTtcbiAgICBjb25zdCB5ZWFycyA9IFtdO1xuICAgIGxldCBjdXJyZW50ID0gc3RhcnREYXRlO1xuICAgIHdoaWxlICh0aGlzLmlzQmVmb3JlKGN1cnJlbnQsIGVuZERhdGUpKSB7XG4gICAgICB5ZWFycy5wdXNoKGN1cnJlbnQpO1xuICAgICAgY3VycmVudCA9IHRoaXMuYWRkWWVhcnMoY3VycmVudCwgMSk7XG4gICAgfVxuICAgIHJldHVybiB5ZWFycztcbiAgfTtcbn0iXSwibWFwcGluZ3MiOiI7Ozs7O0NBQUEsQ0FBQyxTQUFTLEdBQUUsR0FBRTtFQUFDLFlBQVUsT0FBTyxXQUFTLGVBQWEsT0FBTyxTQUFPLE9BQU8sVUFBUSxFQUFFLElBQUUsY0FBWSxPQUFPLFVBQVEsT0FBTyxNQUFJLE9BQU8sQ0FBQyxJQUFFLENBQUMsSUFBRSxlQUFhLE9BQU8sYUFBVyxhQUFXLEtBQUcsS0FBQSxDQUFNLFFBQU0sRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLElBQUksSUFBRSxLQUFJLElBQUUsS0FBSSxJQUFFLE1BQUssSUFBRSxlQUFjLElBQUUsVUFBUyxJQUFFLFVBQVMsSUFBRSxRQUFPLElBQUUsT0FBTSxJQUFFLFFBQU8sSUFBRSxTQUFRLElBQUUsV0FBVSxJQUFFLFFBQU8sSUFBRSxRQUFPLElBQUUsZ0JBQWUsSUFBRSw4RkFBNkYsSUFBRSx3RkFBdUYsSUFBRTtHQUFDLE1BQUs7R0FBSyxVQUFTLDJEQUEyRCxNQUFNLEdBQUc7R0FBRSxRQUFPLHdGQUF3RixNQUFNLEdBQUc7R0FBRSxTQUFRLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRTtLQUFDO0tBQUs7S0FBSztLQUFLO0lBQUksR0FBRSxJQUFFLElBQUU7SUFBSSxPQUFNLE1BQUksS0FBRyxHQUFHLElBQUUsTUFBSSxPQUFLLEVBQUUsTUFBSSxFQUFFLE1BQUk7R0FBRztFQUFDLEdBQUUsSUFBRSxTQUFTLEdBQUUsR0FBRSxHQUFFO0dBQUMsSUFBSSxJQUFFLE9BQU8sQ0FBQztHQUFFLE9BQU0sQ0FBQyxLQUFHLEVBQUUsVUFBUSxJQUFFLElBQUUsS0FBRyxNQUFNLElBQUUsSUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFFO0VBQUMsR0FBRSxJQUFFO0dBQUMsR0FBRTtHQUFFLEdBQUUsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLENBQUMsRUFBRSxVQUFVLEdBQUUsSUFBRSxLQUFLLElBQUksQ0FBQyxHQUFFLElBQUUsS0FBSyxNQUFNLElBQUUsRUFBRSxHQUFFLElBQUUsSUFBRTtJQUFHLFFBQU8sS0FBRyxJQUFFLE1BQUksT0FBSyxFQUFFLEdBQUUsR0FBRSxHQUFHLElBQUUsTUFBSSxFQUFFLEdBQUUsR0FBRSxHQUFHO0dBQUM7R0FBRSxHQUFFLFNBQVMsRUFBRSxHQUFFLEdBQUU7SUFBQyxJQUFHLEVBQUUsS0FBSyxJQUFFLEVBQUUsS0FBSyxHQUFFLE9BQU0sQ0FBQyxFQUFFLEdBQUUsQ0FBQztJQUFFLElBQUksSUFBRSxNQUFJLEVBQUUsS0FBSyxJQUFFLEVBQUUsS0FBSyxNQUFJLEVBQUUsTUFBTSxJQUFFLEVBQUUsTUFBTSxJQUFHLElBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLEdBQUUsQ0FBQyxHQUFFLElBQUUsSUFBRSxJQUFFLEdBQUUsSUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksS0FBRyxJQUFFLEtBQUcsSUFBRyxDQUFDO0lBQUUsT0FBTSxFQUFFLEVBQUUsS0FBRyxJQUFFLE1BQUksSUFBRSxJQUFFLElBQUUsSUFBRSxPQUFLO0dBQUU7R0FBRSxHQUFFLFNBQVMsR0FBRTtJQUFDLE9BQU8sSUFBRSxJQUFFLEtBQUssS0FBSyxDQUFDLEtBQUcsSUFBRSxLQUFLLE1BQU0sQ0FBQztHQUFDO0dBQUUsR0FBRSxTQUFTLEdBQUU7SUFBQyxPQUFNO0tBQUMsR0FBRTtLQUFFLEdBQUU7S0FBRSxHQUFFO0tBQUUsR0FBRTtLQUFFLEdBQUU7S0FBRSxHQUFFO0tBQUUsR0FBRTtLQUFFLEdBQUU7S0FBRSxJQUFHO0tBQUUsR0FBRTtJQUFDLEVBQUUsTUFBSSxPQUFPLEtBQUcsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxNQUFLLEVBQUU7R0FBQztHQUFFLEdBQUUsU0FBUyxHQUFFO0lBQUMsT0FBTyxLQUFLLE1BQUk7R0FBQztFQUFDLEdBQUUsSUFBRSxNQUFLLElBQUUsQ0FBQztFQUFFLEVBQUUsS0FBRztFQUFFLElBQUksSUFBRSxrQkFBaUIsSUFBRSxTQUFTLEdBQUU7R0FBQyxPQUFPLGFBQWEsS0FBRyxFQUFFLENBQUMsS0FBRyxDQUFDLEVBQUU7RUFBRyxHQUFFLElBQUUsU0FBUyxFQUFFLEdBQUUsR0FBRSxHQUFFO0dBQUMsSUFBSTtHQUFFLElBQUcsQ0FBQyxHQUFFLE9BQU87R0FBRSxJQUFHLFlBQVUsT0FBTyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsWUFBWTtJQUFFLEVBQUUsT0FBSyxJQUFFLElBQUcsTUFBSSxFQUFFLEtBQUcsR0FBRSxJQUFFO0lBQUcsSUFBSSxJQUFFLEVBQUUsTUFBTSxHQUFHO0lBQUUsSUFBRyxDQUFDLEtBQUcsRUFBRSxTQUFPLEdBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTtHQUFDLE9BQUs7SUFBQyxJQUFJLElBQUUsRUFBRTtJQUFLLEVBQUUsS0FBRyxHQUFFLElBQUU7R0FBQztHQUFDLE9BQU0sQ0FBQyxLQUFHLE1BQUksSUFBRSxJQUFHLEtBQUcsQ0FBQyxLQUFHO0VBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFO0dBQUMsSUFBRyxFQUFFLENBQUMsR0FBRSxPQUFPLEVBQUUsTUFBTTtHQUFFLElBQUksSUFBRSxZQUFVLE9BQU8sSUFBRSxJQUFFLENBQUM7R0FBRSxPQUFPLEVBQUUsT0FBSyxHQUFFLEVBQUUsT0FBSyxXQUFVLElBQUksRUFBRSxDQUFDO0VBQUMsR0FBRSxJQUFFO0VBQUUsRUFBRSxJQUFFLEdBQUUsRUFBRSxJQUFFLEdBQUUsRUFBRSxJQUFFLFNBQVMsR0FBRSxHQUFFO0dBQUMsT0FBTyxFQUFFLEdBQUU7SUFBQyxRQUFPLEVBQUU7SUFBRyxLQUFJLEVBQUU7SUFBRyxHQUFFLEVBQUU7SUFBRyxTQUFRLEVBQUU7R0FBTyxDQUFDO0VBQUM7RUFBRSxJQUFJLElBQUUsV0FBVTtHQUFDLFNBQVMsRUFBRSxHQUFFO0lBQUMsS0FBSyxLQUFHLEVBQUUsRUFBRSxRQUFPLE1BQUssQ0FBQyxDQUFDLEdBQUUsS0FBSyxNQUFNLENBQUMsR0FBRSxLQUFLLEtBQUcsS0FBSyxNQUFJLEVBQUUsS0FBRyxDQUFDLEdBQUUsS0FBSyxLQUFHLENBQUM7R0FBQztHQUFDLElBQUksSUFBRSxFQUFFO0dBQVUsT0FBTyxFQUFFLFFBQU0sU0FBUyxHQUFFO0lBQUMsS0FBSyxLQUFHLFNBQVMsR0FBRTtLQUFDLElBQUksSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFO0tBQUksSUFBRyxTQUFPLEdBQUUsdUJBQU8sSUFBSSxLQUFLLEdBQUc7S0FBRSxJQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUUsdUJBQU8sSUFBSSxLQUFHO0tBQUUsSUFBRyxhQUFhLE1BQUssT0FBTyxJQUFJLEtBQUssQ0FBQztLQUFFLElBQUcsWUFBVSxPQUFPLEtBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxHQUFFO01BQUMsSUFBSSxJQUFFLEVBQUUsTUFBTSxDQUFDO01BQUUsSUFBRyxHQUFFO09BQUMsSUFBSSxJQUFFLEVBQUUsS0FBRyxLQUFHLEdBQUUsS0FBRyxFQUFFLE1BQUksSUFBQSxDQUFLLFVBQVUsR0FBRSxDQUFDO09BQUUsT0FBTyxJQUFFLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxJQUFHLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsRUFBRSxNQUFJLEdBQUUsQ0FBQyxDQUFDLElBQUUsSUFBSSxLQUFLLEVBQUUsSUFBRyxHQUFFLEVBQUUsTUFBSSxHQUFFLEVBQUUsTUFBSSxHQUFFLEVBQUUsTUFBSSxHQUFFLEVBQUUsTUFBSSxHQUFFLENBQUM7TUFBQztLQUFDO0tBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQztJQUFDLEVBQUUsQ0FBQyxHQUFFLEtBQUssS0FBSztHQUFDLEdBQUUsRUFBRSxPQUFLLFdBQVU7SUFBQyxJQUFJLElBQUUsS0FBSztJQUFHLEtBQUssS0FBRyxFQUFFLFlBQVksR0FBRSxLQUFLLEtBQUcsRUFBRSxTQUFTLEdBQUUsS0FBSyxLQUFHLEVBQUUsUUFBUSxHQUFFLEtBQUssS0FBRyxFQUFFLE9BQU8sR0FBRSxLQUFLLEtBQUcsRUFBRSxTQUFTLEdBQUUsS0FBSyxLQUFHLEVBQUUsV0FBVyxHQUFFLEtBQUssS0FBRyxFQUFFLFdBQVcsR0FBRSxLQUFLLE1BQUksRUFBRSxnQkFBZ0I7R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTztHQUFDLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFNLEVBQUUsS0FBSyxHQUFHLFNBQVMsTUFBSTtHQUFFLEdBQUUsRUFBRSxTQUFPLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsQ0FBQztJQUFFLE9BQU8sS0FBSyxRQUFRLENBQUMsS0FBRyxLQUFHLEtBQUcsS0FBSyxNQUFNLENBQUM7R0FBQyxHQUFFLEVBQUUsVUFBUSxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sRUFBRSxDQUFDLElBQUUsS0FBSyxRQUFRLENBQUM7R0FBQyxHQUFFLEVBQUUsV0FBUyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sS0FBSyxNQUFNLENBQUMsSUFBRSxFQUFFLENBQUM7R0FBQyxHQUFFLEVBQUUsS0FBRyxTQUFTLEdBQUUsR0FBRSxHQUFFO0lBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxJQUFFLEtBQUssS0FBRyxLQUFLLElBQUksR0FBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLE9BQUssV0FBVTtJQUFDLE9BQU8sS0FBSyxNQUFNLEtBQUssUUFBUSxJQUFFLEdBQUc7R0FBQyxHQUFFLEVBQUUsVUFBUSxXQUFVO0lBQUMsT0FBTyxLQUFLLEdBQUcsUUFBUTtHQUFDLEdBQUUsRUFBRSxVQUFRLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBSSxJQUFFLE1BQUssSUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBRyxHQUFFLElBQUUsRUFBRSxFQUFFLENBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxHQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUcsS0FBSyxJQUFJLEVBQUUsSUFBRyxHQUFFLENBQUMsSUFBRSxJQUFJLEtBQUssRUFBRSxJQUFHLEdBQUUsQ0FBQyxHQUFFLENBQUM7S0FBRSxPQUFPLElBQUUsSUFBRSxFQUFFLE1BQU0sQ0FBQztJQUFDLEdBQUUsSUFBRSxTQUFTLEdBQUUsR0FBRTtLQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLEdBQUcsSUFBRyxJQUFFO01BQUM7TUFBRTtNQUFFO01BQUU7S0FBQyxJQUFFO01BQUM7TUFBRztNQUFHO01BQUc7S0FBRyxFQUFBLENBQUcsTUFBTSxDQUFDLENBQUMsR0FBRSxDQUFDO0lBQUMsR0FBRSxJQUFFLEtBQUssSUFBRyxJQUFFLEtBQUssSUFBRyxJQUFFLEtBQUssSUFBRyxJQUFFLFNBQU8sS0FBSyxLQUFHLFFBQU07SUFBSSxRQUFPLEdBQVA7S0FBVSxLQUFLLEdBQUUsT0FBTyxJQUFFLEVBQUUsR0FBRSxDQUFDLElBQUUsRUFBRSxJQUFHLEVBQUU7S0FBRSxLQUFLLEdBQUUsT0FBTyxJQUFFLEVBQUUsR0FBRSxDQUFDLElBQUUsRUFBRSxHQUFFLElBQUUsQ0FBQztLQUFFLEtBQUs7TUFBRSxJQUFJLElBQUUsS0FBSyxRQUFRLENBQUMsQ0FBQyxhQUFXLEdBQUUsS0FBRyxJQUFFLElBQUUsSUFBRSxJQUFFLEtBQUc7TUFBRSxPQUFPLEVBQUUsSUFBRSxJQUFFLElBQUUsS0FBRyxJQUFFLElBQUcsQ0FBQztLQUFFLEtBQUs7S0FBRSxLQUFLLEdBQUUsT0FBTyxFQUFFLElBQUUsU0FBUSxDQUFDO0tBQUUsS0FBSyxHQUFFLE9BQU8sRUFBRSxJQUFFLFdBQVUsQ0FBQztLQUFFLEtBQUssR0FBRSxPQUFPLEVBQUUsSUFBRSxXQUFVLENBQUM7S0FBRSxLQUFLLEdBQUUsT0FBTyxFQUFFLElBQUUsZ0JBQWUsQ0FBQztLQUFFLFNBQVEsT0FBTyxLQUFLLE1BQU07SUFBQztHQUFDLEdBQUUsRUFBRSxRQUFNLFNBQVMsR0FBRTtJQUFDLE9BQU8sS0FBSyxRQUFRLEdBQUUsQ0FBQyxDQUFDO0dBQUMsR0FBRSxFQUFFLE9BQUssU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFJLEdBQUUsSUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUUsU0FBTyxLQUFLLEtBQUcsUUFBTSxLQUFJLEtBQUcsSUFBRSxDQUFDLEdBQUUsRUFBRSxLQUFHLElBQUUsUUFBTyxFQUFFLEtBQUcsSUFBRSxRQUFPLEVBQUUsS0FBRyxJQUFFLFNBQVEsRUFBRSxLQUFHLElBQUUsWUFBVyxFQUFFLEtBQUcsSUFBRSxTQUFRLEVBQUUsS0FBRyxJQUFFLFdBQVUsRUFBRSxLQUFHLElBQUUsV0FBVSxFQUFFLEtBQUcsSUFBRSxnQkFBZSxFQUFBLENBQUcsSUFBRyxJQUFFLE1BQUksSUFBRSxLQUFLLE1BQUksSUFBRSxLQUFLLE1BQUk7SUFBRSxJQUFHLE1BQUksS0FBRyxNQUFJLEdBQUU7S0FBQyxJQUFJLElBQUUsS0FBSyxNQUFNLENBQUMsQ0FBQyxJQUFJLEdBQUUsQ0FBQztLQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFFLEVBQUUsS0FBSyxHQUFFLEtBQUssS0FBRyxFQUFFLElBQUksR0FBRSxLQUFLLElBQUksS0FBSyxJQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUUsT0FBTSxLQUFHLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztJQUFFLE9BQU8sS0FBSyxLQUFLLEdBQUU7R0FBSSxHQUFFLEVBQUUsTUFBSSxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUUsQ0FBQztHQUFDLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRTtJQUFDLE9BQU8sS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUM7R0FBQyxHQUFFLEVBQUUsTUFBSSxTQUFTLEdBQUUsR0FBRTtJQUFDLElBQUksR0FBRSxJQUFFO0lBQUssSUFBRSxPQUFPLENBQUM7SUFBRSxJQUFJLElBQUUsRUFBRSxFQUFFLENBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRTtLQUFDLElBQUksSUFBRSxFQUFFLENBQUM7S0FBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUUsS0FBSyxNQUFNLElBQUUsQ0FBQyxDQUFDLEdBQUUsQ0FBQztJQUFDO0lBQUUsSUFBRyxNQUFJLEdBQUUsT0FBTyxLQUFLLElBQUksR0FBRSxLQUFLLEtBQUcsQ0FBQztJQUFFLElBQUcsTUFBSSxHQUFFLE9BQU8sS0FBSyxJQUFJLEdBQUUsS0FBSyxLQUFHLENBQUM7SUFBRSxJQUFHLE1BQUksR0FBRSxPQUFPLEVBQUUsQ0FBQztJQUFFLElBQUcsTUFBSSxHQUFFLE9BQU8sRUFBRSxDQUFDO0lBQUUsSUFBSSxLQUFHLElBQUUsQ0FBQyxHQUFFLEVBQUUsS0FBRyxHQUFFLEVBQUUsS0FBRyxHQUFFLEVBQUUsS0FBRyxHQUFFLEVBQUEsQ0FBRyxNQUFJLEdBQUUsSUFBRSxLQUFLLEdBQUcsUUFBUSxJQUFFLElBQUU7SUFBRSxPQUFPLEVBQUUsRUFBRSxHQUFFLElBQUk7R0FBQyxHQUFFLEVBQUUsV0FBUyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sS0FBSyxJQUFJLEtBQUcsR0FBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLFNBQU8sU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLE1BQUssSUFBRSxLQUFLLFFBQVE7SUFBRSxJQUFHLENBQUMsS0FBSyxRQUFRLEdBQUUsT0FBTyxFQUFFLGVBQWE7SUFBRSxJQUFJLElBQUUsS0FBRyx3QkFBdUIsSUFBRSxFQUFFLEVBQUUsSUFBSSxHQUFFLElBQUUsS0FBSyxJQUFHLElBQUUsS0FBSyxJQUFHLElBQUUsS0FBSyxJQUFHLElBQUUsRUFBRSxVQUFTLElBQUUsRUFBRSxRQUFPLElBQUUsRUFBRSxVQUFTLElBQUUsU0FBUyxHQUFFLEdBQUUsR0FBRSxHQUFFO0tBQUMsT0FBTyxNQUFJLEVBQUUsTUFBSSxFQUFFLEdBQUUsQ0FBQyxNQUFJLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRSxDQUFDO0lBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRTtLQUFDLE9BQU8sRUFBRSxFQUFFLElBQUUsTUFBSSxJQUFHLEdBQUUsR0FBRztJQUFDLEdBQUUsSUFBRSxLQUFHLFNBQVMsR0FBRSxHQUFFLEdBQUU7S0FBQyxJQUFJLElBQUUsSUFBRSxLQUFHLE9BQUs7S0FBSyxPQUFPLElBQUUsRUFBRSxZQUFZLElBQUU7SUFBQztJQUFFLE9BQU8sRUFBRSxRQUFRLElBQUcsU0FBUyxHQUFFLEdBQUU7S0FBQyxPQUFPLEtBQUcsU0FBUyxHQUFFO01BQUMsUUFBTyxHQUFQO09BQVUsS0FBSSxNQUFLLE9BQU8sT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRTtPQUFFLEtBQUksUUFBTyxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUcsR0FBRSxHQUFHO09BQUUsS0FBSSxLQUFJLE9BQU8sSUFBRTtPQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxJQUFFLEdBQUUsR0FBRSxHQUFHO09BQUUsS0FBSSxPQUFNLE9BQU8sRUFBRSxFQUFFLGFBQVksR0FBRSxHQUFFLENBQUM7T0FBRSxLQUFJLFFBQU8sT0FBTyxFQUFFLEdBQUUsQ0FBQztPQUFFLEtBQUksS0FBSSxPQUFPLEVBQUU7T0FBRyxLQUFJLE1BQUssT0FBTyxFQUFFLEVBQUUsRUFBRSxJQUFHLEdBQUUsR0FBRztPQUFFLEtBQUksS0FBSSxPQUFPLE9BQU8sRUFBRSxFQUFFO09BQUUsS0FBSSxNQUFLLE9BQU8sRUFBRSxFQUFFLGFBQVksRUFBRSxJQUFHLEdBQUUsQ0FBQztPQUFFLEtBQUksT0FBTSxPQUFPLEVBQUUsRUFBRSxlQUFjLEVBQUUsSUFBRyxHQUFFLENBQUM7T0FBRSxLQUFJLFFBQU8sT0FBTyxFQUFFLEVBQUU7T0FBSSxLQUFJLEtBQUksT0FBTyxPQUFPLENBQUM7T0FBRSxLQUFJLE1BQUssT0FBTyxFQUFFLEVBQUUsR0FBRSxHQUFFLEdBQUc7T0FBRSxLQUFJLEtBQUksT0FBTyxFQUFFLENBQUM7T0FBRSxLQUFJLE1BQUssT0FBTyxFQUFFLENBQUM7T0FBRSxLQUFJLEtBQUksT0FBTyxFQUFFLEdBQUUsR0FBRSxDQUFDLENBQUM7T0FBRSxLQUFJLEtBQUksT0FBTyxFQUFFLEdBQUUsR0FBRSxDQUFDLENBQUM7T0FBRSxLQUFJLEtBQUksT0FBTyxPQUFPLENBQUM7T0FBRSxLQUFJLE1BQUssT0FBTyxFQUFFLEVBQUUsR0FBRSxHQUFFLEdBQUc7T0FBRSxLQUFJLEtBQUksT0FBTyxPQUFPLEVBQUUsRUFBRTtPQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUcsR0FBRSxHQUFHO09BQUUsS0FBSSxPQUFNLE9BQU8sRUFBRSxFQUFFLEVBQUUsS0FBSSxHQUFFLEdBQUc7T0FBRSxLQUFJLEtBQUksT0FBTztNQUFDO01BQUMsT0FBTztLQUFJLEVBQUUsQ0FBQyxLQUFHLEVBQUUsUUFBUSxLQUFJLEVBQUU7SUFBQyxFQUFFO0dBQUMsR0FBRSxFQUFFLFlBQVUsV0FBVTtJQUFDLE9BQU8sS0FBRyxDQUFDLEtBQUssTUFBTSxLQUFLLEdBQUcsa0JBQWtCLElBQUUsRUFBRTtHQUFDLEdBQUUsRUFBRSxPQUFLLFNBQVMsR0FBRSxHQUFFLEdBQUU7SUFBQyxJQUFJLEdBQUUsSUFBRSxNQUFLLElBQUUsRUFBRSxFQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsQ0FBQyxHQUFFLEtBQUcsRUFBRSxVQUFVLElBQUUsS0FBSyxVQUFVLEtBQUcsR0FBRSxJQUFFLE9BQUssR0FBRSxJQUFFLFdBQVU7S0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFFLENBQUM7SUFBQztJQUFFLFFBQU8sR0FBUDtLQUFVLEtBQUs7TUFBRSxJQUFFLEVBQUUsSUFBRTtNQUFHO0tBQU0sS0FBSztNQUFFLElBQUUsRUFBRTtNQUFFO0tBQU0sS0FBSztNQUFFLElBQUUsRUFBRSxJQUFFO01BQUU7S0FBTSxLQUFLO01BQUUsS0FBRyxJQUFFLEtBQUc7TUFBTztLQUFNLEtBQUs7TUFBRSxLQUFHLElBQUUsS0FBRztNQUFNO0tBQU0sS0FBSztNQUFFLElBQUUsSUFBRTtNQUFFO0tBQU0sS0FBSztNQUFFLElBQUUsSUFBRTtNQUFFO0tBQU0sS0FBSztNQUFFLElBQUUsSUFBRTtNQUFFO0tBQU0sU0FBUSxJQUFFO0lBQUM7SUFBQyxPQUFPLElBQUUsSUFBRSxFQUFFLEVBQUUsQ0FBQztHQUFDLEdBQUUsRUFBRSxjQUFZLFdBQVU7SUFBQyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQztHQUFFLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFPLEVBQUUsS0FBSztHQUFHLEdBQUUsRUFBRSxTQUFPLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBRyxDQUFDLEdBQUUsT0FBTyxLQUFLO0lBQUcsSUFBSSxJQUFFLEtBQUssTUFBTSxHQUFFLElBQUUsRUFBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDO0lBQUUsT0FBTyxNQUFJLEVBQUUsS0FBRyxJQUFHO0dBQUMsR0FBRSxFQUFFLFFBQU0sV0FBVTtJQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssSUFBRyxJQUFJO0dBQUMsR0FBRSxFQUFFLFNBQU8sV0FBVTtJQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssUUFBUSxDQUFDO0dBQUMsR0FBRSxFQUFFLFNBQU8sV0FBVTtJQUFDLE9BQU8sS0FBSyxRQUFRLElBQUUsS0FBSyxZQUFZLElBQUU7R0FBSSxHQUFFLEVBQUUsY0FBWSxXQUFVO0lBQUMsT0FBTyxLQUFLLEdBQUcsWUFBWTtHQUFDLEdBQUUsRUFBRSxXQUFTLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxZQUFZO0dBQUMsR0FBRTtFQUFDLEVBQUUsR0FBRSxJQUFFLEVBQUU7RUFBVSxPQUFPLEVBQUUsWUFBVSxHQUFFO0dBQUMsQ0FBQyxPQUFNLENBQUM7R0FBRSxDQUFDLE1BQUssQ0FBQztHQUFFLENBQUMsTUFBSyxDQUFDO0dBQUUsQ0FBQyxNQUFLLENBQUM7R0FBRSxDQUFDLE1BQUssQ0FBQztHQUFFLENBQUMsTUFBSyxDQUFDO0dBQUUsQ0FBQyxNQUFLLENBQUM7R0FBRSxDQUFDLE1BQUssQ0FBQztFQUFDLENBQUMsQ0FBQyxTQUFTLFNBQVMsR0FBRTtHQUFDLEVBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRTtJQUFDLE9BQU8sS0FBSyxHQUFHLEdBQUUsRUFBRSxJQUFHLEVBQUUsRUFBRTtHQUFDO0VBQUMsRUFBRSxHQUFFLEVBQUUsU0FBTyxTQUFTLEdBQUUsR0FBRTtHQUFDLE9BQU8sRUFBRSxPQUFLLEVBQUUsR0FBRSxHQUFFLENBQUMsR0FBRSxFQUFFLEtBQUcsQ0FBQyxJQUFHO0VBQUMsR0FBRSxFQUFFLFNBQU8sR0FBRSxFQUFFLFVBQVEsR0FBRSxFQUFFLE9BQUssU0FBUyxHQUFFO0dBQUMsT0FBTyxFQUFFLE1BQUksQ0FBQztFQUFDLEdBQUUsRUFBRSxLQUFHLEVBQUUsSUFBRyxFQUFFLEtBQUcsR0FBRSxFQUFFLElBQUUsQ0FBQyxHQUFFO0NBQUMsRUFBRTs7Ozs7Q0NBdi9OLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSwwQkFBd0IsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLElBQUksSUFBRSxRQUFPLElBQUU7RUFBTyxPQUFPLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRTtHQUFVLEVBQUUsT0FBSyxTQUFTLEdBQUU7SUFBQyxJQUFHLEtBQUssTUFBSSxNQUFJLElBQUUsT0FBTSxTQUFPLEdBQUUsT0FBTyxLQUFLLElBQUksS0FBRyxJQUFFLEtBQUssS0FBSyxJQUFHLEtBQUs7SUFBRSxJQUFJLElBQUUsS0FBSyxRQUFRLENBQUMsQ0FBQyxhQUFXO0lBQUUsSUFBRyxPQUFLLEtBQUssTUFBTSxLQUFHLEtBQUssS0FBSyxJQUFFLElBQUc7S0FBQyxJQUFJLElBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRSxJQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0tBQUUsSUFBRyxFQUFFLFNBQVMsQ0FBQyxHQUFFLE9BQU87SUFBQztJQUFDLElBQUksSUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxhQUFhLEdBQUUsSUFBRSxLQUFLLEtBQUssR0FBRSxHQUFFLENBQUMsQ0FBQztJQUFFLE9BQU8sSUFBRSxJQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUUsS0FBSyxLQUFLLENBQUM7R0FBQyxHQUFFLEVBQUUsUUFBTSxTQUFTLEdBQUU7SUFBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsT0FBTSxLQUFLLEtBQUssQ0FBQztHQUFDO0VBQUM7Q0FBQyxFQUFFOzs7OztDQ0Fyd0IsQ0FBQyxTQUFTLEdBQUUsR0FBRTtFQUFDLFlBQVUsT0FBTyxXQUFTLGVBQWEsT0FBTyxTQUFPLE9BQU8sVUFBUSxFQUFFLElBQUUsY0FBWSxPQUFPLFVBQVEsT0FBTyxNQUFJLE9BQU8sQ0FBQyxJQUFFLENBQUMsSUFBRSxlQUFhLE9BQU8sYUFBVyxhQUFXLEtBQUcsS0FBQSxDQUFNLGlDQUErQixFQUFFO0NBQUMsRUFBQSxDQUFDLFVBQU8sV0FBVTtFQUFDO0VBQWEsSUFBSSxJQUFFO0dBQUMsS0FBSTtHQUFZLElBQUc7R0FBUyxHQUFFO0dBQWEsSUFBRztHQUFlLEtBQUk7R0FBc0IsTUFBSztFQUEyQixHQUFFLElBQUUsaUdBQWdHLElBQUUsTUFBSyxJQUFFLFFBQU8sSUFBRSxTQUFRLElBQUUsc0JBQXFCLElBQUUsQ0FBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0dBQUMsUUFBTyxJQUFFLENBQUMsTUFBSSxJQUFFLEtBQUcsT0FBSztFQUFJO0VBQUUsSUFBSSxJQUFFLFNBQVMsR0FBRTtHQUFDLE9BQU8sU0FBUyxHQUFFO0lBQUMsS0FBSyxLQUFHLENBQUM7R0FBQztFQUFDLEdBQUUsSUFBRSxDQUFDLHVCQUFzQixTQUFTLEdBQUU7R0FBQyxDQUFDLEtBQUssU0FBTyxLQUFLLE9BQUssQ0FBQyxHQUFBLENBQUksU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFHLENBQUMsR0FBRSxPQUFPO0lBQUUsSUFBRyxRQUFNLEdBQUUsT0FBTztJQUFFLElBQUksSUFBRSxFQUFFLE1BQU0sY0FBYyxHQUFFLElBQUUsS0FBRyxFQUFFLE1BQUksQ0FBQyxFQUFFLE1BQUk7SUFBRyxPQUFPLE1BQUksSUFBRSxJQUFFLFFBQU0sRUFBRSxLQUFHLENBQUMsSUFBRTtHQUFDLEVBQUUsQ0FBQztFQUFDLENBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFO0dBQUcsT0FBTyxNQUFJLEVBQUUsVUFBUSxJQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQztFQUFFLEdBQUUsSUFBRSxTQUFTLEdBQUUsR0FBRTtHQUFDLElBQUksR0FBRSxJQUFFLEVBQUU7R0FBUyxJQUFHO1NBQU8sSUFBSSxJQUFFLEdBQUUsS0FBRyxJQUFHLEtBQUcsR0FBRSxJQUFHLEVBQUUsUUFBUSxFQUFFLEdBQUUsR0FBRSxDQUFDLENBQUMsSUFBRSxJQUFHO0tBQUMsSUFBRSxJQUFFO0tBQUc7SUFBSztVQUFPLElBQUUsT0FBSyxJQUFFLE9BQUs7R0FBTSxPQUFPO0VBQUMsR0FBRSxJQUFFO0dBQUMsR0FBRSxDQUFDLEdBQUUsU0FBUyxHQUFFO0lBQUMsS0FBSyxZQUFVLEVBQUUsR0FBRSxDQUFDLENBQUM7R0FBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsU0FBUyxHQUFFO0lBQUMsS0FBSyxZQUFVLEVBQUUsR0FBRSxDQUFDLENBQUM7R0FBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsU0FBUyxHQUFFO0lBQUMsS0FBSyxRQUFNLEtBQUcsSUFBRSxLQUFHO0dBQUMsQ0FBQztHQUFFLEdBQUUsQ0FBQyxHQUFFLFNBQVMsR0FBRTtJQUFDLEtBQUssZUFBYSxNQUFJLENBQUM7R0FBQyxDQUFDO0dBQUUsSUFBRyxDQUFDLEdBQUUsU0FBUyxHQUFFO0lBQUMsS0FBSyxlQUFhLEtBQUcsQ0FBQztHQUFDLENBQUM7R0FBRSxLQUFJLENBQUMsU0FBUSxTQUFTLEdBQUU7SUFBQyxLQUFLLGVBQWEsQ0FBQztHQUFDLENBQUM7R0FBRSxHQUFFLENBQUMsR0FBRSxFQUFFLFNBQVMsQ0FBQztHQUFFLElBQUcsQ0FBQyxHQUFFLEVBQUUsU0FBUyxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxTQUFTLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxFQUFFLFNBQVMsQ0FBQztHQUFFLEdBQUUsQ0FBQyxHQUFFLEVBQUUsT0FBTyxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxPQUFPLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxFQUFFLE9BQU8sQ0FBQztHQUFFLElBQUcsQ0FBQyxHQUFFLEVBQUUsT0FBTyxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxLQUFLLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxFQUFFLEtBQUssQ0FBQztHQUFFLElBQUcsQ0FBQyxHQUFFLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLFNBQVEsSUFBRSxFQUFFLE1BQU0sS0FBSztJQUFFLElBQUcsS0FBSyxNQUFJLEVBQUUsSUFBRyxHQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsS0FBRyxJQUFHLEtBQUcsR0FBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsVUFBUyxFQUFFLE1BQUksTUFBSSxLQUFLLE1BQUk7R0FBRSxDQUFDO0dBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxNQUFNLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxFQUFFLE1BQU0sQ0FBQztHQUFFLEdBQUUsQ0FBQyxHQUFFLEVBQUUsT0FBTyxDQUFDO0dBQUUsSUFBRyxDQUFDLEdBQUUsRUFBRSxPQUFPLENBQUM7R0FBRSxLQUFJLENBQUMsR0FBRSxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxRQUFRLEdBQUUsS0FBRyxFQUFFLGFBQWEsS0FBRyxFQUFFLEtBQUssU0FBUyxHQUFFO0tBQUMsT0FBTyxFQUFFLE1BQU0sR0FBRSxDQUFDO0lBQUMsRUFBRSxFQUFBLENBQUcsUUFBUSxDQUFDLElBQUU7SUFBRSxJQUFHLElBQUUsR0FBRSxNQUFNLElBQUksTUFBSTtJQUFFLEtBQUssUUFBTSxJQUFFLE1BQUk7R0FBQyxDQUFDO0dBQUUsTUFBSyxDQUFDLEdBQUUsU0FBUyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUU7SUFBRSxJQUFHLElBQUUsR0FBRSxNQUFNLElBQUksTUFBSTtJQUFFLEtBQUssUUFBTSxJQUFFLE1BQUk7R0FBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLFlBQVcsRUFBRSxNQUFNLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxTQUFTLEdBQUU7SUFBQyxLQUFLLE9BQUssRUFBRSxDQUFDO0dBQUMsQ0FBQztHQUFFLE1BQUssQ0FBQyxTQUFRLEVBQUUsTUFBTSxDQUFDO0dBQUUsR0FBRTtHQUFFLElBQUc7RUFBQztFQUFFLFNBQVMsRUFBRSxHQUFFO0dBQUMsSUFBSSxJQUFNLEdBQUosSUFBUSxLQUFHLEVBQUU7R0FBUSxLQUFJLElBQUksS0FBRyxJQUFFLEVBQUUsUUFBUSxzQ0FBcUMsU0FBUyxHQUFFLEdBQUUsR0FBRTtJQUFDLElBQUksSUFBRSxLQUFHLEVBQUUsWUFBWTtJQUFFLE9BQU8sS0FBRyxFQUFFLE1BQUksRUFBRSxNQUFJLEVBQUUsRUFBRSxDQUFDLFFBQVEsbUNBQWtDLFNBQVMsR0FBRSxHQUFFLEdBQUU7S0FBQyxPQUFPLEtBQUcsRUFBRSxNQUFNLENBQUM7SUFBQyxFQUFFO0dBQUMsRUFBRSxFQUFBLENBQUcsTUFBTSxDQUFDLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFHLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxJQUFHLElBQUUsRUFBRSxJQUFHLElBQUUsS0FBRyxFQUFFLElBQUcsSUFBRSxLQUFHLEVBQUU7SUFBRyxFQUFFLEtBQUcsSUFBRTtLQUFDLE9BQU07S0FBRSxRQUFPO0lBQUMsSUFBRSxFQUFFLFFBQVEsWUFBVyxFQUFFO0dBQUM7R0FBQyxPQUFPLFNBQVMsR0FBRTtJQUFDLEtBQUksSUFBSSxJQUFFLENBQUMsR0FBRSxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFHLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRTtLQUFHLElBQUcsWUFBVSxPQUFPLEdBQUUsS0FBRyxFQUFFO1VBQVc7TUFBQyxJQUFJLElBQUUsRUFBRSxPQUFNLElBQUUsRUFBRSxRQUFPLElBQUUsRUFBRSxNQUFNLENBQUMsR0FBRSxJQUFFLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztNQUFHLEVBQUUsS0FBSyxHQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsUUFBUSxHQUFFLEVBQUU7S0FBQztJQUFDO0lBQUMsT0FBTyxTQUFTLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRTtLQUFVLElBQUcsS0FBSyxNQUFJLEdBQUU7TUFBQyxJQUFJLElBQUUsRUFBRTtNQUFNLElBQUUsSUFBRSxPQUFLLEVBQUUsU0FBTyxNQUFJLE9BQUssTUFBSSxFQUFFLFFBQU0sSUFBRyxPQUFPLEVBQUU7S0FBUztJQUFDLEVBQUUsQ0FBQyxHQUFFO0dBQUM7RUFBQztFQUFDLE9BQU8sU0FBUyxHQUFFLEdBQUUsR0FBRTtHQUFDLEVBQUUsRUFBRSxvQkFBa0IsQ0FBQyxHQUFFLEtBQUcsRUFBRSxzQkFBb0IsSUFBRSxFQUFFO0dBQW1CLElBQUksSUFBRSxFQUFFLFdBQVUsSUFBRSxFQUFFO0dBQU0sRUFBRSxRQUFNLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLE1BQUssSUFBRSxFQUFFLEtBQUksSUFBRSxFQUFFO0lBQUssS0FBSyxLQUFHO0lBQUUsSUFBSSxJQUFFLEVBQUU7SUFBRyxJQUFHLFlBQVUsT0FBTyxHQUFFO0tBQUMsSUFBSSxJQUFFLENBQUMsTUFBSSxFQUFFLElBQUcsSUFBRSxDQUFDLE1BQUksRUFBRSxJQUFHLElBQUUsS0FBRyxHQUFFLElBQUUsRUFBRTtLQUFHLE1BQUksSUFBRSxFQUFFLEtBQUksSUFBRSxLQUFLLFFBQVEsR0FBRSxDQUFDLEtBQUcsTUFBSSxJQUFFLEVBQUUsR0FBRyxLQUFJLEtBQUssS0FBRyxTQUFTLEdBQUUsR0FBRSxHQUFFLEdBQUU7TUFBQyxJQUFHO09BQUMsSUFBRyxDQUFDLEtBQUksR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUUsSUFBRyx1QkFBTyxJQUFJLE1BQU0sUUFBTSxJQUFFLE1BQUksS0FBRyxDQUFDO09BQUUsSUFBSSxJQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFFLElBQUUsRUFBRSxNQUFLLElBQUUsRUFBRSxPQUFNLElBQUUsRUFBRSxLQUFJLElBQUUsRUFBRSxPQUFNLElBQUUsRUFBRSxTQUFRLElBQUUsRUFBRSxTQUFRLElBQUUsRUFBRSxjQUFhLElBQUUsRUFBRSxNQUFLLElBQUUsRUFBRSxNQUFLLG9CQUFFLElBQUksS0FBRyxHQUFFLElBQUUsTUFBSSxLQUFHLElBQUUsSUFBRSxFQUFFLFFBQVEsSUFBRyxJQUFFLEtBQUcsRUFBRSxZQUFZLEdBQUUsSUFBRTtPQUFFLEtBQUcsQ0FBQyxNQUFJLElBQUUsSUFBRSxJQUFFLElBQUUsSUFBRSxFQUFFLFNBQVM7T0FBRyxJQUFJLEdBQUUsSUFBRSxLQUFHLEdBQUUsSUFBRSxLQUFHLEdBQUUsSUFBRSxLQUFHLEdBQUUsSUFBRSxLQUFHO09BQUUsT0FBTyxJQUFFLElBQUksS0FBSyxLQUFLLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRSxLQUFHLEVBQUUsU0FBTyxHQUFHLENBQUMsSUFBRSxJQUFFLElBQUksS0FBSyxLQUFLLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDLEtBQUcsSUFBRSxJQUFJLEtBQUssR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLE1BQUksSUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFHO01BQUUsU0FBTyxHQUFFO09BQUMsdUJBQU8sSUFBSSxLQUFLLEVBQUU7TUFBQztLQUFDLEVBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUssS0FBSyxHQUFFLEtBQUcsQ0FBQyxNQUFJLE1BQUksS0FBSyxLQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFJLEtBQUcsS0FBRyxLQUFLLE9BQU8sQ0FBQyxNQUFJLEtBQUsscUJBQUcsSUFBSSxLQUFLLEVBQUUsSUFBRyxJQUFFLENBQUM7SUFBQyxPQUFNLElBQUcsYUFBYSxPQUFNLEtBQUksSUFBSSxJQUFFLEVBQUUsUUFBTyxJQUFFLEdBQUUsS0FBRyxHQUFFLEtBQUcsR0FBRTtLQUFDLEVBQUUsS0FBRyxFQUFFLElBQUU7S0FBRyxJQUFJLElBQUUsRUFBRSxNQUFNLE1BQUssQ0FBQztLQUFFLElBQUcsRUFBRSxRQUFRLEdBQUU7TUFBQyxLQUFLLEtBQUcsRUFBRSxJQUFHLEtBQUssS0FBRyxFQUFFLElBQUcsS0FBSyxLQUFLO01BQUU7S0FBSztLQUFDLE1BQUksTUFBSSxLQUFLLHFCQUFHLElBQUksS0FBSyxFQUFFO0lBQUU7U0FBTSxFQUFFLEtBQUssTUFBSyxDQUFDO0dBQUM7RUFBQztDQUFDLEVBQUU7Ozs7O0NDQXJ5SCxDQUFDLFNBQVMsR0FBRSxHQUFFO0VBQUMsWUFBVSxPQUFPLFdBQVMsZUFBYSxPQUFPLFNBQU8sT0FBTyxVQUFRLEVBQUUsSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLElBQUUsQ0FBQyxJQUFFLGVBQWEsT0FBTyxhQUFXLGFBQVcsS0FBRyxLQUFBLENBQU0sK0JBQTZCLEVBQUU7Q0FBQyxFQUFBLENBQUMsVUFBTyxXQUFVO0VBQUM7RUFBYSxJQUFJLElBQUU7R0FBQyxLQUFJO0dBQVksSUFBRztHQUFTLEdBQUU7R0FBYSxJQUFHO0dBQWUsS0FBSTtHQUFzQixNQUFLO0VBQTJCO0VBQUUsT0FBTyxTQUFTLEdBQUUsR0FBRSxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsV0FBVSxJQUFFLEVBQUU7R0FBTyxFQUFFLEdBQUcsVUFBUSxHQUFFLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxLQUFLLE1BQUksTUFBSSxJQUFFO0lBQXdCLElBQUksSUFBRSxLQUFLLFFBQVEsQ0FBQyxDQUFDLFNBQVEsSUFBRSxTQUFTLEdBQUUsR0FBRTtLQUFDLE9BQU8sRUFBRSxRQUFRLHNDQUFxQyxTQUFTLEdBQUUsR0FBRSxHQUFFO01BQUMsSUFBSSxJQUFFLEtBQUcsRUFBRSxZQUFZO01BQUUsT0FBTyxLQUFHLEVBQUUsTUFBSSxFQUFFLE1BQUksRUFBRSxFQUFFLENBQUMsUUFBUSxtQ0FBa0MsU0FBUyxHQUFFLEdBQUUsR0FBRTtPQUFDLE9BQU8sS0FBRyxFQUFFLE1BQU0sQ0FBQztNQUFDLEVBQUU7S0FBQyxFQUFFO0lBQUMsRUFBRSxHQUFFLEtBQUssTUFBSSxJQUFFLENBQUMsSUFBRSxDQUFDO0lBQUUsT0FBTyxFQUFFLEtBQUssTUFBSyxDQUFDO0dBQUM7RUFBQztDQUFDLEVBQUU7Ozs7O0NDQXJ5QixDQUFDLFNBQVMsR0FBRSxHQUFFO0VBQUMsWUFBVSxPQUFPLFdBQVMsZUFBYSxPQUFPLFNBQU8sT0FBTyxVQUFRLEVBQUUsSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLElBQUUsQ0FBQyxJQUFFLGVBQWEsT0FBTyxhQUFXLGFBQVcsS0FBRyxLQUFBLENBQU0seUJBQXVCLEVBQUU7Q0FBQyxFQUFBLENBQUMsVUFBTyxXQUFVO0VBQUM7RUFBYSxPQUFPLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxFQUFFLFVBQVUsWUFBVSxTQUFTLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsRUFBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLENBQUMsR0FBRSxJQUFFLFNBQU8sSUFBRSxLQUFHLEtBQUEsQ0FBTSxJQUFHLElBQUUsUUFBTSxFQUFFO0lBQUcsUUFBTyxJQUFFLEtBQUssUUFBUSxHQUFFLENBQUMsSUFBRSxDQUFDLEtBQUssU0FBUyxHQUFFLENBQUMsT0FBSyxJQUFFLEtBQUssU0FBUyxHQUFFLENBQUMsSUFBRSxDQUFDLEtBQUssUUFBUSxHQUFFLENBQUMsT0FBSyxJQUFFLEtBQUssU0FBUyxHQUFFLENBQUMsSUFBRSxDQUFDLEtBQUssUUFBUSxHQUFFLENBQUMsT0FBSyxJQUFFLEtBQUssUUFBUSxHQUFFLENBQUMsSUFBRSxDQUFDLEtBQUssU0FBUyxHQUFFLENBQUM7R0FBRTtFQUFDO0NBQUMsRUFBRTs7Ozs7Q0NBaGlCLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSw4QkFBNEIsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLE9BQU8sU0FBUyxHQUFFLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRSxXQUFVLElBQUUsRUFBRTtHQUFPLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsTUFBSyxJQUFFLEtBQUssUUFBUTtJQUFFLElBQUcsQ0FBQyxLQUFLLFFBQVEsR0FBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQUUsSUFBSSxJQUFFLEtBQUssT0FBTyxHQUFFLEtBQUcsS0FBRyx1QkFBQSxDQUF3QixRQUFRLGdFQUErRCxTQUFTLEdBQUU7S0FBQyxRQUFPLEdBQVA7TUFBVSxLQUFJLEtBQUksT0FBTyxLQUFLLE1BQU0sRUFBRSxLQUFHLEtBQUcsQ0FBQztNQUFFLEtBQUksTUFBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7TUFBRSxLQUFJLFFBQU8sT0FBTyxFQUFFLFNBQVM7TUFBRSxLQUFJLFFBQU8sT0FBTyxFQUFFLFlBQVk7TUFBRSxLQUFJLE1BQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxLQUFLLEdBQUUsR0FBRztNQUFFLEtBQUk7TUFBSSxLQUFJLE1BQUssT0FBTyxFQUFFLEVBQUUsRUFBRSxLQUFLLEdBQUUsUUFBTSxJQUFFLElBQUUsR0FBRSxHQUFHO01BQUUsS0FBSTtNQUFJLEtBQUksTUFBSyxPQUFPLEVBQUUsRUFBRSxFQUFFLFFBQVEsR0FBRSxRQUFNLElBQUUsSUFBRSxHQUFFLEdBQUc7TUFBRSxLQUFJO01BQUksS0FBSSxNQUFLLE9BQU8sRUFBRSxFQUFFLE9BQU8sTUFBSSxFQUFFLEtBQUcsS0FBRyxFQUFFLEVBQUUsR0FBRSxRQUFNLElBQUUsSUFBRSxHQUFFLEdBQUc7TUFBRSxLQUFJLEtBQUksT0FBTyxLQUFLLE1BQU0sRUFBRSxHQUFHLFFBQVEsSUFBRSxHQUFHO01BQUUsS0FBSSxLQUFJLE9BQU8sRUFBRSxHQUFHLFFBQVE7TUFBRSxLQUFJLEtBQUksT0FBTSxNQUFJLEVBQUUsV0FBVyxJQUFFO01BQUksS0FBSSxPQUFNLE9BQU0sTUFBSSxFQUFFLFdBQVcsTUFBTSxJQUFFO01BQUksU0FBUSxPQUFPO0tBQUM7SUFBQyxFQUFFO0lBQUUsT0FBTyxFQUFFLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztHQUFDO0VBQUM7Q0FBQyxFQUFFOzs7Ozs7Ozs7OztBQ2dCeGtDQSxpQkFBQUEsUUFBTSxPQUFPQyx1QkFBQUEsT0FBcUI7QUFDbENELGlCQUFBQSxRQUFNLE9BQU9FLGtCQUFBQSxPQUFnQjtBQUM3QkYsaUJBQUFBLFFBQU0sT0FBT0csaUJBQUFBLE9BQWU7QUFDNUJILGlCQUFBQSxRQUFNLE9BQU9JLHNCQUFBQSxPQUFvQjtBQUNqQyxJQUFNLGlCQUFpQjtDQUVyQixJQUFJO0NBQ0osTUFBTTtFQUNKLGFBQWE7RUFDYixhQUFhO0VBQ2IsV0FBVztDQUNiO0NBRUEsR0FBRztFQUNELGFBQWE7RUFDYixhQUFhO0VBQ2IsV0FBVztDQUNiO0NBQ0EsSUFBSTtDQUNKLEtBQUs7RUFDSCxhQUFhO0VBQ2IsYUFBYTtDQUNmO0NBQ0EsTUFBTTtFQUNKLGFBQWE7RUFDYixhQUFhO0NBQ2Y7Q0FFQSxHQUFHO0VBQ0QsYUFBYTtFQUNiLGFBQWE7RUFDYixXQUFXO0NBQ2I7Q0FDQSxJQUFJO0NBQ0osSUFBSTtFQUNGLGFBQWE7RUFDYixhQUFhO0NBQ2Y7Q0FFQSxHQUFHO0VBQ0QsYUFBYTtFQUNiLGFBQWE7RUFDYixXQUFXO0NBQ2I7Q0FDQSxJQUFJO0VBQ0YsYUFBYTtFQUNiLGFBQWE7Q0FDZjtDQUNBLEtBQUs7RUFDSCxhQUFhO0VBQ2IsYUFBYTtDQUNmO0NBQ0EsTUFBTTtFQUNKLGFBQWE7RUFDYixhQUFhO0NBQ2Y7Q0FFQSxHQUFHO0NBQ0gsR0FBRztDQUVILEdBQUc7RUFDRCxhQUFhO0VBQ2IsYUFBYTtFQUNiLFdBQVc7Q0FDYjtDQUNBLElBQUk7Q0FDSixHQUFHO0VBQ0QsYUFBYTtFQUNiLGFBQWE7RUFDYixXQUFXO0NBQ2I7Q0FDQSxJQUFJO0NBRUosR0FBRztFQUNELGFBQWE7RUFDYixhQUFhO0VBQ2IsV0FBVztDQUNiO0NBQ0EsSUFBSTtDQUVKLEdBQUc7RUFDRCxhQUFhO0VBQ2IsYUFBYTtFQUNiLFdBQVc7Q0FDYjtDQUNBLElBQUk7QUFDTjtBQUNBLElBQU0saUJBQWlCO0NBQ3JCLE1BQU07Q0FDTixPQUFPO0NBQ1AsWUFBWTtDQUNaLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsU0FBUztDQUNULGNBQWM7Q0FDZCxVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixTQUFTO0NBQ1QsU0FBUztDQUNULFVBQVU7Q0FDVixjQUFjO0NBQ2QsV0FBVztDQUNYLFlBQVk7Q0FDWix1QkFBdUI7Q0FDdkIsYUFBYTtDQUNiLGFBQWE7Q0FDYixxQkFBcUI7Q0FDckIscUJBQXFCO0FBQ3ZCO0FBQ0EsU0FBUyw2QkFBNkI7Q0FDcEMsTUFBTSxJQUFJLE1BQThDLCtNQUFvUDtBQUM5UztBQUNBLFNBQVMsa0NBQWtDO0NBQ3pDLE1BQU0sSUFBSSxNQUE4QyxvT0FBeVE7QUFDblU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBMEJBLElBQWEsZUFBYixNQUEwQjtDQUN4QixlQUFlO0NBQ2YsdUJBQXVCO0NBQ3ZCLE1BQU07Q0FDTixvQkFBb0I7RUFDbEIsT0FBTztFQUNQLEtBQUs7Q0FDUDtDQUNBLGlCQUFpQjtDQUNqQixZQUFZLEVBQ1YsUUFDQSxZQUNFLENBQUMsR0FBRztFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxnQkFBZ0IsT0FBTztFQUluRCxpQkFBQSxRQUFNLE9BQU9DLHlCQUFBQSxPQUF1QjtDQUN0QztDQUNBLG9CQUFtQixVQUFTO0VBQzFCLE1BQU0saUJBQWlCLEtBQUsscUJBQXFCO0VBQ2pELElBQUksbUJBQW1CLE1BQU0sT0FBTyxHQUNsQyxPQUFPO0VBRVQsT0FBTyxNQUFNLE9BQU8sY0FBYztDQUNwQztDQUNBLHFCQUFxQixPQUFPTCxpQkFBQUEsUUFBTSxRQUFRO0NBQzFDLDBCQUEwQixPQUFPQSxpQkFBQUEsUUFBTSxPQUFPO0NBQzlDLFVBQVUsT0FBTyxXQUFXLHVCQUF1QjtFQUNqRCxNQUFNLDJCQUEyQixLQUFLLFlBQVksV0FBVyxLQUFLLFlBQVksS0FBSyxDQUFDO0VBQ3BGLE9BQU8sTUFBTSxPQUFPLGtCQUFrQixNQUFNLHlCQUF5QixPQUFPLGtCQUFrQjtDQUNoRzs7OztDQUtBLGlCQUFnQixhQUFZO0VBQzFCLFFBQVEsVUFBUjtHQUNFLEtBQUssV0FFRDtHQUVKLEtBQUssVUFFRCxPQUFPQSxpQkFBQUEsUUFBTSxHQUFHLE1BQU07R0FFMUIsU0FFSSxPQUFPO0VBRWI7Q0FDRjtDQUNBLG9CQUFtQixVQUFTO0VBQzFCLE9BQU8sS0FBSyxrQkFBQSxHQUFBLGlCQUFBLFFBQUEsQ0FBdUIsS0FBSyxDQUFDO0NBQzNDO0NBQ0EsaUJBQWdCLFVBQVM7O0VBRXZCLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FDckIsMkJBQTJCO0VBRTdCLE9BQU8sS0FBSyxpQkFBaUJBLGlCQUFBQSxRQUFNLElBQUksS0FBSyxDQUFDO0NBQy9DO0NBQ0EsZ0JBQWdCLE9BQU8sYUFBYTs7RUFFbEMsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUNyQiwyQkFBMkI7O0VBSTdCLElBQUksQ0FBQyxLQUFLLGtCQUFrQixHQUMxQixnQ0FBZ0M7RUFFbEMsTUFBTSxnQkFBZ0IsVUFBVSxLQUFBLEtBQWEsQ0FBQyxNQUFNLFNBQVMsR0FBRztFQUNoRSxPQUFPLEtBQUssa0JBQUEsR0FBQSxpQkFBQSxRQUFBLENBQXVCLEtBQUssQ0FBQyxDQUFDLEdBQUcsS0FBSyxjQUFjLFFBQVEsR0FBRyxhQUFhLENBQUM7Q0FDM0Y7Q0FDQSx5QkFBeUI7RUFDdkIsTUFBTSxVQUFVQSxpQkFBQUEsUUFBTTtFQUV0QixJQUFJLGVBQWUsUUFESixLQUFLLFVBQVU7RUFFOUIsSUFBSSxpQkFBaUIsS0FBQSxHQUFXO0dBRzVCLFNBQVM7SUFBQztJQUEwQztJQUFxSjtJQUF1RTtHQUE2QixDQUFDOztHQUdoVCxlQUFlLFFBQVE7RUFDekI7RUFDQSxPQUFPLGFBQWE7Q0FDdEI7Ozs7Ozs7Q0FRQSxnQkFBZSxVQUFTO0VBQ3RCLElBQUksQ0FBQyxLQUFLLGtCQUFrQixHQUMxQixPQUFPO0VBRVQsTUFBTSxXQUFXLEtBQUssWUFBWSxLQUFLO0VBQ3ZDLElBQUksYUFBYSxPQUFPO0dBQ3RCLE1BQU0sYUFBYSxNQUFNLEdBQUcsS0FBSyxjQUFjLFFBQVEsR0FBRyxJQUFJOztHQUk5RCxJQUFJLFdBQVcsYUFBYSxNQUFNLFdBQVcsSUFDM0MsT0FBTztHQU1ULE1BQU0sVUFBVSxXQUFXO0VBQzdCO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Q0FVQSxxQkFBcUIsT0FBTyxjQUFjO0VBQ3hDLE1BQU0sV0FBVyxLQUFLLFlBQVksS0FBSztFQUV2QyxJQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssYUFBYSxZQUFZLGFBQWEsT0FDaEUsT0FBTztFQUVULE1BQU0sWUFBWUEsaUJBQUFBLFFBQU0sSUFBSSxNQUFNLE9BQU8seUJBQXlCLENBQUM7RUFJbkUsSUFBSSxDQUFDLFVBQVUsUUFBUSxHQUNyQixPQUFPO0VBSVQsTUFBTSxxQkFBcUIsS0FBSyxJQUFJLFVBQVUsS0FBSyxHQUFHLFVBQVUsWUFBWSxDQUFDO0VBQzdFLElBQUksTUFBTSxLQUFLLE1BQU0sb0JBQ25CLE9BQU87RUFFVCxPQUFPLE1BQU0sSUFBSSxRQUFRLGtCQUFrQjtDQUM3QztDQUNBLFFBQVEsT0FBTyxXQUFXLGNBQWM7RUFDdEMsSUFBSSxVQUFVLE1BQ1osT0FBTztFQUVULElBQUksYUFBYSxPQUNmLE9BQU8sS0FBSyxjQUFjLEtBQUs7RUFFakMsSUFBSSxhQUFhLFlBQVksYUFBYSxhQUFhLENBQUMsS0FBSyxrQkFBa0IsR0FDN0UsT0FBTyxLQUFLLGlCQUFpQixLQUFLO0VBRXBDLE9BQU8sS0FBSyxhQUFhLE9BQU8sUUFBUTtDQUMxQztDQUNBLHdCQUFBLEdBQUEsaUJBQUEsUUFBQSxpQkFBNkIsSUFBSSxLQUFLLGNBQWMsQ0FBQztDQUNyRCxlQUFjLFVBQVM7RUFDckIsSUFBSSxLQUFLLGtCQUFrQixHQUFHO0dBRTVCLE1BQU0sT0FBTyxNQUFNLElBQUk7R0FDdkIsSUFBSSxNQUNGLE9BQU87RUFFWDtFQUNBLElBQUksS0FBSyxhQUFhLEtBQUssTUFBTSxNQUFNLEdBQ3JDLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxlQUFlLE9BQU8sYUFBYTtFQUNqQyxJQUFJLEtBQUssWUFBWSxLQUFLLE1BQU0sVUFDOUIsT0FBTztFQUVULElBQUksYUFBYSxPQUFPOztHQUV0QixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQ3JCLDJCQUEyQjtHQUU3QixPQUFPLE1BQU0sSUFBSTtFQUNuQjtFQUtBLElBQUksYUFBYSxVQUNmLE9BQU8sTUFBTSxNQUFNO0VBRXJCLElBQUksQ0FBQyxLQUFLLGtCQUFrQixHQUFHO0dBQzdCLElBQUksYUFBYSxXQUNmLE9BQU87O0dBSVQsZ0NBQWdDO0VBQ2xDO0VBQ0EsT0FBTyxLQUFLLGlCQUFpQkEsaUJBQUFBLFFBQU0sR0FBRyxPQUFPLEtBQUssY0FBYyxRQUFRLENBQUMsQ0FBQztDQUM1RTtDQUNBLFlBQVcsVUFBUztFQUNsQixPQUFPLE1BQU0sT0FBTztDQUN0QjtDQUNBLFNBQVMsT0FBTyxXQUFXO0VBQ3pCLElBQUksVUFBVSxJQUNaLE9BQU87RUFFVCxRQUFBLEdBQUEsaUJBQUEsUUFBQSxDQUFhLE9BQU8sUUFBUSxLQUFLLFFBQVEsSUFBSTtDQUMvQztDQUNBLDZCQUE2QjtFQUMzQixPQUFPLEtBQUssVUFBVTtDQUN4QjtDQUNBLHFDQUFxQzs7RUFFbkMsT0FBTyxNQUFNLEtBQUssS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sRUFBRTtDQUNwRDtDQUNBLGdCQUFlLFdBQVU7RUFDdkIsTUFBTSxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFHNUMsTUFBTSxLQUFJLGNBQWEsVUFBVSxRQUFRLG1DQUFtQyxHQUFHLEdBQUcsTUFBTSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7RUFDdkcsT0FBTyxPQUFPLFFBQVEsc0NBQXNDLEdBQUcsR0FBRyxNQUFNO0dBQ3RFLE1BQU0sSUFBSSxLQUFLLEVBQUUsWUFBWTtHQUM3QixPQUFPLEtBQUssY0FBYyxNQUFNLEVBQUUsY0FBYyxFQUFFO0VBQ3BELENBQUM7Q0FDSDtDQUNBLFdBQVUsVUFBUztFQUNqQixJQUFJLFNBQVMsTUFDWCxPQUFPO0VBRVQsT0FBTyxNQUFNLFFBQVE7Q0FDdkI7Q0FDQSxVQUFVLE9BQU8sY0FBYztFQUM3QixPQUFPLEtBQUssZUFBZSxPQUFPLEtBQUssUUFBUSxVQUFVO0NBQzNEO0NBQ0Esa0JBQWtCLE9BQU8saUJBQWlCO0VBQ3hDLE9BQU8sS0FBSyxpQkFBaUIsS0FBSyxDQUFDLENBQUMsT0FBTyxZQUFZO0NBQ3pEO0NBQ0EsZ0JBQWUsbUJBQWtCO0VBQy9CLE9BQU87Q0FDVDtDQUNBLFdBQVcsT0FBTyxjQUFjO0VBQzlCLElBQUksVUFBVSxRQUFRLGNBQWMsTUFDbEMsT0FBTztFQUVULElBQUksVUFBVSxRQUFRLGNBQWMsTUFDbEMsT0FBTztFQUVULE9BQU8sTUFBTSxPQUFPLENBQUMsQ0FBQyxRQUFRLE1BQU0sVUFBVSxPQUFPLENBQUMsQ0FBQyxRQUFRO0NBQ2pFO0NBQ0EsY0FBYyxPQUFPLGNBQWM7RUFDakMsT0FBTyxLQUFLLE9BQU8sT0FBTyxXQUFXLE1BQU07Q0FDN0M7Q0FDQSxlQUFlLE9BQU8sY0FBYztFQUNsQyxPQUFPLEtBQUssT0FBTyxPQUFPLFdBQVcsU0FBUztDQUNoRDtDQUNBLGFBQWEsT0FBTyxjQUFjO0VBQ2hDLE9BQU8sS0FBSyxPQUFPLE9BQU8sV0FBVyxZQUFZO0NBQ25EO0NBQ0EsY0FBYyxPQUFPLGNBQWM7RUFDakMsT0FBTyxNQUFNLE9BQU8sV0FBVyxNQUFNO0NBQ3ZDO0NBQ0EsV0FBVyxPQUFPLGNBQWM7RUFDOUIsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsZUFBZSxPQUFPLGNBQWM7RUFDbEMsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUNyQixPQUFPLE1BQU0sUUFBUSxXQUFXLE1BQU07RUFFeEMsT0FBTyxDQUFDLEtBQUssV0FBVyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksSUFBSSxVQUFVLElBQUk7Q0FDM0U7Q0FDQSxjQUFjLE9BQU8sY0FBYztFQUNqQyxJQUFJLENBQUMsS0FBSyxhQUFhLEdBQ3JCLE9BQU8sTUFBTSxRQUFRLFdBQVcsS0FBSztFQUV2QyxPQUFPLENBQUMsS0FBSyxVQUFVLE9BQU8sU0FBUyxLQUFLLE1BQU0sSUFBSSxJQUFJLFVBQVUsSUFBSTtDQUMxRTtDQUNBLFlBQVksT0FBTyxjQUFjO0VBQy9CLE9BQU8sUUFBUTtDQUNqQjtDQUNBLGdCQUFnQixPQUFPLGNBQWM7RUFDbkMsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUNyQixPQUFPLE1BQU0sU0FBUyxXQUFXLE1BQU07RUFFekMsT0FBTyxDQUFDLEtBQUssV0FBVyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksSUFBSSxVQUFVLElBQUk7Q0FDM0U7Q0FDQSxlQUFlLE9BQU8sY0FBYztFQUNsQyxJQUFJLENBQUMsS0FBSyxhQUFhLEdBQ3JCLE9BQU8sTUFBTSxTQUFTLFdBQVcsS0FBSztFQUV4QyxPQUFPLENBQUMsS0FBSyxVQUFVLE9BQU8sU0FBUyxLQUFLLE1BQU0sSUFBSSxJQUFJLFVBQVUsSUFBSTtDQUMxRTtDQUNBLGlCQUFpQixPQUFPLENBQUMsT0FBTyxTQUFTO0VBQ3ZDLE9BQU8sU0FBUyxTQUFTLFNBQVM7Q0FDcEM7Q0FDQSxlQUFjLFVBQVM7RUFDckIsT0FBTyxLQUFLLGFBQWEsTUFBTSxRQUFRLE1BQU0sQ0FBQztDQUNoRDtDQUNBLGdCQUFlLFVBQVM7RUFDdEIsT0FBTyxLQUFLLGFBQWEsTUFBTSxRQUFRLE9BQU8sQ0FBQztDQUNqRDtDQUNBLGVBQWMsVUFBUztFQUNyQixPQUFPLEtBQUssYUFBYSxLQUFLLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxRQUFRLE1BQU0sQ0FBQztDQUN2RTtDQUNBLGNBQWEsVUFBUztFQUNwQixPQUFPLEtBQUssYUFBYSxNQUFNLFFBQVEsS0FBSyxDQUFDO0NBQy9DO0NBQ0EsYUFBWSxVQUFTO0VBQ25CLE9BQU8sS0FBSyxhQUFhLE1BQU0sTUFBTSxNQUFNLENBQUM7Q0FDOUM7Q0FDQSxjQUFhLFVBQVM7RUFDcEIsT0FBTyxLQUFLLGFBQWEsTUFBTSxNQUFNLE9BQU8sQ0FBQztDQUMvQztDQUNBLGFBQVksVUFBUztFQUNuQixPQUFPLEtBQUssYUFBYSxLQUFLLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxNQUFNLE1BQU0sQ0FBQztDQUNyRTtDQUNBLFlBQVcsVUFBUztFQUNsQixPQUFPLEtBQUssYUFBYSxNQUFNLE1BQU0sS0FBSyxDQUFDO0NBQzdDO0NBQ0EsWUFBWSxPQUFPLFdBQVc7RUFDNUIsT0FBTyxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsTUFBTSxJQUFJLFFBQVEsTUFBTSxHQUFHLEtBQUssQ0FBQztDQUNuRjtDQUNBLGFBQWEsT0FBTyxXQUFXO0VBQzdCLE9BQU8sS0FBSyxhQUFhLEtBQUssa0JBQWtCLE1BQU0sSUFBSSxRQUFRLE9BQU8sR0FBRyxLQUFLLENBQUM7Q0FDcEY7Q0FDQSxZQUFZLE9BQU8sV0FBVztFQUM1QixPQUFPLEtBQUssYUFBYSxNQUFNLElBQUksUUFBUSxNQUFNLENBQUM7Q0FDcEQ7Q0FDQSxXQUFXLE9BQU8sV0FBVztFQUMzQixPQUFPLEtBQUssYUFBYSxNQUFNLElBQUksUUFBUSxLQUFLLENBQUM7Q0FDbkQ7Q0FDQSxZQUFZLE9BQU8sV0FBVztFQUM1QixPQUFPLEtBQUssYUFBYSxNQUFNLElBQUksUUFBUSxNQUFNLENBQUM7Q0FDcEQ7Q0FDQSxjQUFjLE9BQU8sV0FBVztFQUM5QixPQUFPLEtBQUssYUFBYSxNQUFNLElBQUksUUFBUSxRQUFRLENBQUM7Q0FDdEQ7Q0FDQSxjQUFjLE9BQU8sV0FBVztFQUM5QixPQUFPLEtBQUssYUFBYSxNQUFNLElBQUksUUFBUSxRQUFRLENBQUM7Q0FDdEQ7Q0FDQSxXQUFVLFVBQVM7RUFDakIsT0FBTyxNQUFNLEtBQUs7Q0FDcEI7Q0FDQSxZQUFXLFVBQVM7RUFDbEIsT0FBTyxNQUFNLE1BQU07Q0FDckI7Q0FDQSxXQUFVLFVBQVM7RUFDakIsT0FBTyxNQUFNLEtBQUs7Q0FDcEI7Q0FDQSxZQUFXLFVBQVM7RUFDbEIsT0FBTyxNQUFNLEtBQUs7Q0FDcEI7Q0FDQSxjQUFhLFVBQVM7RUFDcEIsT0FBTyxNQUFNLE9BQU87Q0FDdEI7Q0FDQSxjQUFhLFVBQVM7RUFDcEIsT0FBTyxNQUFNLE9BQU87Q0FDdEI7Q0FDQSxtQkFBa0IsVUFBUztFQUN6QixPQUFPLE1BQU0sWUFBWTtDQUMzQjtDQUNBLFdBQVcsT0FBTyxTQUFTO0VBQ3pCLE9BQU8sS0FBSyxhQUFhLEtBQUssa0JBQWtCLE1BQU0sSUFBSSxRQUFRLElBQUksR0FBRyxLQUFLLENBQUM7Q0FDakY7Q0FDQSxZQUFZLE9BQU8sVUFBVTtFQUMzQixPQUFPLEtBQUssYUFBYSxLQUFLLGtCQUFrQixNQUFNLElBQUksU0FBUyxLQUFLLEdBQUcsS0FBSyxDQUFDO0NBQ25GO0NBQ0EsV0FBVyxPQUFPLFNBQVM7RUFDekIsT0FBTyxLQUFLLGFBQWEsTUFBTSxJQUFJLFFBQVEsSUFBSSxDQUFDO0NBQ2xEO0NBQ0EsWUFBWSxPQUFPLFVBQVU7RUFDM0IsT0FBTyxLQUFLLGFBQWEsTUFBTSxJQUFJLFFBQVEsS0FBSyxDQUFDO0NBQ25EO0NBQ0EsY0FBYyxPQUFPLFlBQVk7RUFDL0IsT0FBTyxLQUFLLGFBQWEsTUFBTSxJQUFJLFVBQVUsT0FBTyxDQUFDO0NBQ3ZEO0NBQ0EsY0FBYyxPQUFPLFlBQVk7RUFDL0IsT0FBTyxLQUFLLGFBQWEsTUFBTSxJQUFJLFVBQVUsT0FBTyxDQUFDO0NBQ3ZEO0NBQ0EsbUJBQW1CLE9BQU8saUJBQWlCO0VBQ3pDLE9BQU8sS0FBSyxhQUFhLE1BQU0sSUFBSSxlQUFlLFlBQVksQ0FBQztDQUNqRTtDQUNBLGtCQUFpQixVQUFTO0VBQ3hCLE9BQU8sTUFBTSxZQUFZO0NBQzNCO0NBQ0EsZ0JBQWUsVUFBUztFQUN0QixNQUFNLFFBQVEsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLENBQUM7RUFDdkQsTUFBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsS0FBSyxDQUFDO0VBQ2pELElBQUksUUFBUTtFQUNaLElBQUksVUFBVTtFQUNkLE1BQU0sY0FBYyxDQUFDO0VBQ3JCLE9BQU8sVUFBVSxLQUFLO0dBQ3BCLE1BQU0sYUFBYSxLQUFLLE1BQU0sUUFBUSxDQUFDO0dBQ3ZDLFlBQVksY0FBYyxZQUFZLGVBQWUsQ0FBQztHQUN0RCxZQUFZLFdBQVcsQ0FBQyxLQUFLLE9BQU87R0FDcEMsVUFBVSxLQUFLLFFBQVEsU0FBUyxDQUFDO0dBQ2pDLFNBQVM7RUFDWDtFQUNBLE9BQU87Q0FDVDtDQUNBLGlCQUFnQixVQUFTO0VBQ3ZCLE9BQU8sTUFBTSxLQUFLO0NBQ3BCO0NBQ0EsYUFBYSxPQUFPO0VBQ2xCLE9BQU8sTUFBTSxJQUFJLElBQUk7Q0FDdkI7Q0FDQSxnQkFBZ0IsQ0FBQyxPQUFPLFNBQVM7RUFDL0IsTUFBTSxZQUFZLEtBQUssWUFBWSxLQUFLO0VBQ3hDLE1BQU0sVUFBVSxLQUFLLFVBQVUsR0FBRztFQUNsQyxNQUFNLFFBQVEsQ0FBQztFQUNmLElBQUksVUFBVTtFQUNkLE9BQU8sS0FBSyxTQUFTLFNBQVMsT0FBTyxHQUFHO0dBQ3RDLE1BQU0sS0FBSyxPQUFPO0dBQ2xCLFVBQVUsS0FBSyxTQUFTLFNBQVMsQ0FBQztFQUNwQztFQUNBLE9BQU87Q0FDVDtBQUNGIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDZdfQ==