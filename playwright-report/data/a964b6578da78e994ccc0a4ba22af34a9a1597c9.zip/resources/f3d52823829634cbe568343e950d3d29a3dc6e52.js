import { i as __toESM } from "/ERP-Project/node_modules/.vite/deps/rolldown-runtime-B4lejLz5.js?v=15f5f1b8";
import { t as require_react } from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import { t as require_jsx_runtime } from "/ERP-Project/node_modules/.vite/deps/react_jsx-runtime.js?v=f54b3fc7";
import { Dt as composeClasses, Ot as require_prop_types, m as styled, nt as generateUtilityClasses, rt as generateUtilityClass } from "/ERP-Project/node_modules/.vite/deps/createSvgIcon-BVsc3q4M.js?v=15f5f1b8";
import { n as clsx } from "/ERP-Project/node_modules/.vite/deps/react-is-D18V6qXv.js?v=15f5f1b8";
import { t as _extends } from "/ERP-Project/node_modules/.vite/deps/extends-DrH2PCIy.js?v=15f5f1b8";
import { Dn as useThemeProps, p as Skeleton } from "/ERP-Project/node_modules/.vite/deps/useMediaQuery-C6jIoXQI.js?v=15f5f1b8";
import { $ as DateField, $t as ArrowRightIcon, A as pickersLayoutClasses, At as PickerDay, B as YearCalendar, Bt as extractRootForwardedProps, C as createNonRangePickerStepNavigation, Ct as useDateTimeManager, D as usePickerLayout, Dt as validateDateTime, E as PickersLayoutRoot, Et as useValidation, F as DateCalendar, Ft as getMultiSectionDigitalClockUtilityClass, G as monthCalendarClasses, Gt as singleItemValueManager, H as yearCalendarClasses, Ht as digitalClockClasses, I as dateCalendarClasses, It as multiSectionDigitalClockClasses, J as pickersFadeTransitionGroupClasses, Jt as clockPointerClasses, K as dayCalendarClasses, Kt as clockNumberClasses, L as getDateCalendarUtilityClass, Lt as DigitalClock, M as useDatePickerDefaultizedProps, Mt as pickerDayClasses, N as DatePickerToolbar, Nt as MultiSectionDigitalClock, O as PickersShortcuts, Ot as validateTime, P as datePickerToolbarClasses, Pt as multiSectionDigitalClockSectionClasses, Q as useTimeField, Qt as ArrowLeftIcon, R as PickersCalendarHeader, Rt as DigitalClockItem, S as renderDateViewCalendar, St as useDateField, T as PickersLayoutContentWrapper, Tt as useDateManager, U as MonthCalendar, Ut as getDigitalClockUtilityClass, V as getYearCalendarUtilityClass, Vt as mergeSx, W as getMonthCalendarUtilityClass, Wt as TimeClock, X as useDateTimeField, Xt as timeClockClasses, Y as DateTimeField, Yt as getTimeClockUtilityClass, Z as TimeField, Zt as ArrowDropDownIcon, _ as TimePickerToolbar, _n as usePickerAdapter, _t as pickersSectionListClasses, a as useDateTimePickerDefaultizedProps, an as usePickerActionsContext, at as getPickersFilledInputUtilityClass, b as MobileDatePicker, bt as getPickersTextFieldUtilityClass, c as DateTimePickerTabs, cn as useNullablePickerContext, ct as getPickersOutlinedInputUtilityClass, d as MobileTimePicker, dn as getLocalizedDigits, dt as PickersSectionList, en as CalendarIcon, et as PickersTextField, f as DesktopTimePicker, fn as EXPORTED_TIME_VIEWS, ft as PickersSectionListRoot, g as useTimePickerDefaultizedProps, gn as usePickerTranslations, gt as getPickersSectionListUtilityClass, h as renderTimeViewClock, hn as extractValidationProps, ht as PickersSectionListSectionSeparator, i as DesktopDateTimePickerLayout, in as TimeIcon, it as PickersFilledInput, j as usePicker, jt as getPickerDayUtilityClass, k as PickersActionBar, kt as validateDate, l as dateTimePickerTabsClasses, ln as usePickerContext, lt as pickersOutlinedInputClasses, m as renderMultiSectionDigitalClockTimeView, mn as useSplitFieldProps, mt as PickersSectionListSectionContent, n as MobileDateTimePicker, nn as ClockIcon, nt as getPickersInputUtilityClass, o as DateTimePickerToolbar, on as PickerProvider, ot as pickersFilledInputClasses, p as renderDigitalClockTimeView, pn as DATE_VIEWS, pt as PickersSectionListSection, q as pickersSlideTransitionClasses, qt as clockClasses, r as DesktopDateTimePicker, rn as DateRangeIcon, rt as pickersInputClasses, s as dateTimePickerToolbarClasses, sn as useIsValidValue, st as PickersOutlinedInput, t as DateTimePicker, tn as ClearIcon, tt as PickersInput, u as TimePicker, un as buildSectionsFromFormat, ut as PickersInputBase, v as timePickerToolbarClasses, vn as LocalizationProvider, vt as getPickersInputBaseUtilityClass, w as PickersLayout, wt as useTimeManager, x as DesktopDatePicker, xt as pickersTextFieldClasses, y as DatePicker, yn as _objectWithoutPropertiesLoose, yt as pickersInputBaseClasses, z as pickersCalendarHeaderClasses, zt as DEFAULT_DESKTOP_MODE_MEDIA_QUERY } from "/ERP-Project/node_modules/.vite/deps/DateTimePicker-B1CrOhGD.js?v=15f5f1b8";
//#region node_modules/@mui/x-date-pickers/hooks/useParsedFormat.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Returns the parsed format to be rendered in the field when there is no value or in other parts of the Picker.
* This format is localized (for example `AAAA` for the year with the French locale) and cannot be parsed by your date library.
* @param {object} The parameters needed to build the placeholder.
* @param {string} params.format Format to parse.
* @returns
*/
var useParsedFormat = (parameters = {}) => {
	const pickerContext = useNullablePickerContext();
	const adapter = usePickerAdapter();
	const translations = usePickerTranslations();
	const localizedDigits = import_react.useMemo(() => getLocalizedDigits(adapter), [adapter]);
	const { format = pickerContext?.fieldFormat ?? adapter.formats.fullDate } = parameters;
	return import_react.useMemo(() => {
		return buildSectionsFromFormat({
			adapter,
			format,
			formatDensity: "dense",
			isRtl: false,
			shouldRespectLeadingZeros: true,
			localeText: translations,
			localizedDigits,
			date: null
		}).map((section) => `${section.startSeparator}${section.placeholder}${section.endSeparator}`).join("");
	}, [
		adapter,
		translations,
		localizedDigits,
		format
	]);
};
//#endregion
//#region node_modules/@mui/x-date-pickers/DayCalendarSkeleton/dayCalendarSkeletonClasses.mjs
var getDayCalendarSkeletonUtilityClass = (slot) => generateUtilityClass("MuiDayCalendarSkeleton", slot);
var dayCalendarSkeletonClasses = generateUtilityClasses("MuiDayCalendarSkeleton", [
	"root",
	"week",
	"daySkeleton"
]);
//#endregion
//#region node_modules/@mui/x-date-pickers/DayCalendarSkeleton/DayCalendarSkeleton.mjs
var import_prop_types = /* @__PURE__ */ __toESM(require_prop_types(), 1);
var import_jsx_runtime = require_jsx_runtime();
var _excluded$1 = ["className", "classes"];
var useUtilityClasses = (classes) => {
	return composeClasses({
		root: ["root"],
		week: ["week"],
		daySkeleton: ["daySkeleton"]
	}, getDayCalendarSkeletonUtilityClass, classes);
};
var DayCalendarSkeletonRoot = styled("div", {
	name: "MuiDayCalendarSkeleton",
	slot: "Root"
})({ alignSelf: "start" });
var DayCalendarSkeletonWeek = styled("div", {
	name: "MuiDayCalendarSkeleton",
	slot: "Week"
})({
	margin: `2px 0`,
	display: "flex",
	justifyContent: "center"
});
var DayCalendarSkeletonDay = styled(Skeleton, {
	name: "MuiDayCalendarSkeleton",
	slot: "DaySkeleton"
})({
	margin: `0 2px`,
	"&[data-day-in-month=\"0\"]": { visibility: "hidden" }
});
var monthMap = [
	[
		0,
		1,
		1,
		1,
		1,
		1,
		1
	],
	[
		1,
		1,
		1,
		1,
		1,
		1,
		1
	],
	[
		1,
		1,
		1,
		1,
		1,
		1,
		1
	],
	[
		1,
		1,
		1,
		1,
		1,
		1,
		1
	],
	[
		1,
		1,
		1,
		1,
		0,
		0,
		0
	]
];
/**
* Demos:
*
* - [DateCalendar](https://mui.com/x/react-date-pickers/date-calendar/)
*
* API:
*
* - [CalendarPickerSkeleton API](https://mui.com/x/api/date-pickers/calendar-picker-skeleton/)
*/
function DayCalendarSkeleton(inProps) {
	const props = useThemeProps({
		props: inProps,
		name: "MuiDayCalendarSkeleton"
	});
	const { className, classes: classesProp } = props, other = _objectWithoutPropertiesLoose(props, _excluded$1);
	const classes = useUtilityClasses(classesProp);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DayCalendarSkeletonRoot, _extends({
		className: clsx(classes.root, className),
		ownerState: props
	}, other, { children: monthMap.map((week, index) => /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DayCalendarSkeletonWeek, {
		className: classes.week,
		children: week.map((dayInMonth, index2) => /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DayCalendarSkeletonDay, {
			variant: "circular",
			width: 36,
			height: 36,
			className: classes.daySkeleton,
			"data-day-in-month": dayInMonth
		}, index2))
	}, index)) }));
}
DayCalendarSkeleton.propTypes = {
	/**
	* Override or extend the styles applied to the component.
	*/
	classes: import_prop_types.default.object,
	/**
	* The system prop that allows defining system overrides as well as additional CSS styles.
	*/
	sx: import_prop_types.default.oneOfType([
		import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([
			import_prop_types.default.func,
			import_prop_types.default.object,
			import_prop_types.default.bool
		])),
		import_prop_types.default.func,
		import_prop_types.default.object
	])
};
//#endregion
//#region node_modules/@mui/x-date-pickers/internals/hooks/useStaticPicker/useStaticPicker.mjs
var _excluded = ["props", "steps"];
var PickerStaticLayout = styled(PickersLayout, { slot: "internal" })(({ theme }) => ({
	overflow: "hidden",
	minWidth: 320,
	backgroundColor: (theme.vars || theme).palette.background.paper
}));
/**
* Hook managing all the single-date static pickers:
* - StaticDatePicker
* - StaticDateTimePicker
* - StaticTimePicker
*/
var useStaticPicker = (_ref) => {
	let { props, steps } = _ref, pickerParams = _objectWithoutPropertiesLoose(_ref, _excluded);
	const { localeText, slots, slotProps, displayStaticWrapperAs, autoFocus } = props;
	const getStepNavigation = createNonRangePickerStepNavigation({ steps });
	const { providerProps, renderCurrentView } = usePicker(_extends({}, pickerParams, {
		props,
		variant: displayStaticWrapperAs,
		autoFocusView: autoFocus ?? false,
		viewContainerRole: null,
		localeText,
		getStepNavigation
	}));
	const Layout = slots?.layout ?? PickerStaticLayout;
	const renderPicker = () => /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PickerProvider, _extends({}, providerProps, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Layout, _extends({}, extractRootForwardedProps(props), slotProps?.layout, {
		slots,
		slotProps,
		sx: mergeSx(providerProps.contextValue.rootSx, slotProps?.layout?.sx),
		className: clsx(providerProps.contextValue.rootClassName, slotProps?.layout?.className),
		ref: providerProps.contextValue.rootRef,
		children: renderCurrentView()
	})) }));
	renderPicker.displayName = "renderPicker";
	return { renderPicker };
};
//#endregion
//#region node_modules/@mui/x-date-pickers/StaticDatePicker/StaticDatePicker.mjs
/**
* Demos:
*
* - [DatePicker](https://mui.com/x/react-date-pickers/date-picker/)
* - [Validation](https://mui.com/x/react-date-pickers/validation/)
*
* API:
*
* - [StaticDatePicker API](https://mui.com/x/api/date-pickers/static-date-picker/)
*/
var StaticDatePicker = /*#__PURE__*/ import_react.forwardRef(function StaticDatePicker(inProps, ref) {
	const defaultizedProps = useDatePickerDefaultizedProps(inProps, "MuiStaticDatePicker");
	const displayStaticWrapperAs = defaultizedProps.displayStaticWrapperAs ?? "mobile";
	const { renderPicker } = useStaticPicker({
		ref,
		props: _extends({}, defaultizedProps, {
			viewRenderers: _extends({
				day: renderDateViewCalendar,
				month: renderDateViewCalendar,
				year: renderDateViewCalendar
			}, defaultizedProps.viewRenderers),
			displayStaticWrapperAs,
			yearsPerRow: defaultizedProps.yearsPerRow ?? (displayStaticWrapperAs === "mobile" ? 3 : 4),
			slotProps: _extends({}, defaultizedProps.slotProps, { toolbar: _extends({ hidden: displayStaticWrapperAs === "desktop" }, defaultizedProps.slotProps?.toolbar) })
		}),
		valueManager: singleItemValueManager,
		valueType: "date",
		validator: validateDate,
		steps: null
	});
	return renderPicker();
});
StaticDatePicker.displayName = "StaticDatePicker";
StaticDatePicker.propTypes = {
	/**
	* If `true`, the main element is focused during the first mount.
	* This main element is:
	* - the element chosen by the visible view if any (i.e: the selected day on the `day` view).
	* - the `input` element if there is a field rendered.
	*/
	autoFocus: import_prop_types.default.bool,
	className: import_prop_types.default.string,
	/**
	* Formats the day of week displayed in the calendar header.
	* @param {PickerValidDate} date The date of the day of week provided by the adapter.
	* @returns {string} The name to display.
	* @default (date: PickerValidDate) => adapter.format(date, 'weekdayShort').charAt(0).toUpperCase()
	*/
	dayOfWeekFormatter: import_prop_types.default.func,
	/**
	* The default value.
	* Used when the component is not controlled.
	*/
	defaultValue: import_prop_types.default.object,
	/**
	* If `true`, the component is disabled.
	* When disabled, the value cannot be changed and no interaction is possible.
	* @default false
	*/
	disabled: import_prop_types.default.bool,
	/**
	* If `true`, disable values after the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disableFuture: import_prop_types.default.bool,
	/**
	* If `true`, today's day is not highlighted.
	* @default false
	*/
	disableHighlightToday: import_prop_types.default.bool,
	/**
	* If `true`, disable values before the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disablePast: import_prop_types.default.bool,
	/**
	* Force static wrapper inner components to be rendered in mobile or desktop mode.
	* @default "mobile"
	*/
	displayStaticWrapperAs: import_prop_types.default.oneOf(["desktop", "mobile"]),
	/**
	* If `true`, the week number will be display in the calendar.
	*/
	displayWeekNumber: import_prop_types.default.bool,
	/**
	* The day view will show as many weeks as needed after the end of the current month to match this value.
	* Put it to 6 to have a fixed number of weeks in Gregorian calendars
	*/
	fixedWeekNumber: import_prop_types.default.number,
	/**
	* If `true`, calls `renderLoading` instead of rendering the day calendar.
	* Can be used to preload information and show it in calendar.
	* @default false
	*/
	loading: import_prop_types.default.bool,
	/**
	* Locale for components texts.
	* Allows overriding texts coming from `LocalizationProvider` and `theme`.
	*/
	localeText: import_prop_types.default.object,
	/**
	* Maximal selectable date.
	* @default 2099-12-31
	*/
	maxDate: import_prop_types.default.object,
	/**
	* Minimal selectable date.
	* @default 1900-01-01
	*/
	minDate: import_prop_types.default.object,
	/**
	* Months rendered per row.
	* @default 3
	*/
	monthsPerRow: import_prop_types.default.oneOf([3, 4]),
	/**
	* Callback fired when the value is accepted.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The value that was just accepted.
	* @param {FieldChangeHandlerContext<TError>} context Context about this acceptance:
	* - `validationError`: validation result of the current value
	* - `source`: source of the acceptance. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the value was accepted via a shortcut selection
	*/
	onAccept: import_prop_types.default.func,
	/**
	* Callback fired when the value changes.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The new value.
	* @param {FieldChangeHandlerContext<TError>} context Context about this change:
	* - `validationError`: validation result of the current value
	* - `source`: source of the change. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the change was triggered by a shortcut selection
	*/
	onChange: import_prop_types.default.func,
	/**
	* Callback fired when component requests to be closed.
	* Can be fired when selecting (by default on `desktop` mode) or clearing a value.
	* @deprecated Please avoid using as it will be removed in next major version.
	*/
	onClose: import_prop_types.default.func,
	/**
	* Callback fired when the error associated with the current value changes.
	* When a validation error is detected, the `error` parameter contains a non-null value.
	* This can be used to render an appropriate form error.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @param {TError} error The reason why the current value is not valid.
	* @param {TValue} value The value associated with the error.
	*/
	onError: import_prop_types.default.func,
	/**
	* Callback fired on month change.
	* @param {PickerValidDate} month The new month.
	*/
	onMonthChange: import_prop_types.default.func,
	/**
	* Callback fired on view change.
	* @template TView Type of the view. It will vary based on the Picker type and the `views` it uses.
	* @param {TView} view The new view.
	*/
	onViewChange: import_prop_types.default.func,
	/**
	* Callback fired on year change.
	* @param {PickerValidDate} year The new year.
	*/
	onYearChange: import_prop_types.default.func,
	/**
	* The default visible view.
	* Used when the component view is not controlled.
	* Must be a valid option from `views` list.
	*/
	openTo: import_prop_types.default.oneOf([
		"day",
		"month",
		"year"
	]),
	/**
	* Force rendering in particular orientation.
	*/
	orientation: import_prop_types.default.oneOf(["landscape", "portrait"]),
	/**
	* If `true`, the component is read-only.
	* When read-only, the value cannot be changed but the user can interact with the interface.
	* @default false
	*/
	readOnly: import_prop_types.default.bool,
	/**
	* If `true`, disable heavy animations.
	* @default `@media(prefers-reduced-motion: reduce)` || `navigator.userAgent` matches Android <10 or iOS <13
	*/
	reduceAnimations: import_prop_types.default.bool,
	/**
	* The date used to generate the new value when both `value` and `defaultValue` are empty.
	* @default The closest valid date-time using the validation props, except callbacks like `shouldDisable<...>`.
	*/
	referenceDate: import_prop_types.default.object,
	/**
	* Component displaying when passed `loading` true.
	* @returns {React.ReactNode} The node to render when loading.
	* @default () => <span>…</span>
	*/
	renderLoading: import_prop_types.default.func,
	/**
	* Disable specific date.
	*
	* Warning: This function can be called multiple times (for example when rendering date calendar, checking if focus can be moved to a certain date, etc.). Expensive computations can impact performance.
	*
	* @param {PickerValidDate} day The date to test.
	* @returns {boolean} If `true` the date will be disabled.
	*/
	shouldDisableDate: import_prop_types.default.func,
	/**
	* Disable specific month.
	* @param {PickerValidDate} month The month to test.
	* @returns {boolean} If `true`, the month will be disabled.
	*/
	shouldDisableMonth: import_prop_types.default.func,
	/**
	* Disable specific year.
	* @param {PickerValidDate} year The year to test.
	* @returns {boolean} If `true`, the year will be disabled.
	*/
	shouldDisableYear: import_prop_types.default.func,
	/**
	* If `true`, days outside the current month are rendered:
	*
	* - if `fixedWeekNumber` is defined, renders days to have the weeks requested.
	*
	* - if `fixedWeekNumber` is not defined, renders day to fill the first and last week of the current month.
	*
	* - ignored if `calendars` equals more than `1` on range pickers.
	* @default false
	*/
	showDaysOutsideCurrentMonth: import_prop_types.default.bool,
	/**
	* The props used for each component slot.
	* @default {}
	*/
	slotProps: import_prop_types.default.object,
	/**
	* Overridable component slots.
	* @default {}
	*/
	slots: import_prop_types.default.object,
	/**
	* The system prop that allows defining system overrides as well as additional CSS styles.
	*/
	sx: import_prop_types.default.oneOfType([
		import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([
			import_prop_types.default.func,
			import_prop_types.default.object,
			import_prop_types.default.bool
		])),
		import_prop_types.default.func,
		import_prop_types.default.object
	]),
	/**
	* Choose which timezone to use for the value.
	* Example: "default", "system", "UTC", "America/New_York".
	* If you pass values from other timezones to some props, they will be converted to this timezone before being used.
	* @see See the {@link https://mui.com/x/react-date-pickers/timezone/ timezones documentation} for more details.
	* @default The timezone of the `value` or `defaultValue` prop is defined, 'default' otherwise.
	*/
	timezone: import_prop_types.default.string,
	/**
	* The selected value.
	* Used when the component is controlled.
	*/
	value: import_prop_types.default.object,
	/**
	* The visible view.
	* Used when the component view is controlled.
	* Must be a valid option from `views` list.
	*/
	view: import_prop_types.default.oneOf([
		"day",
		"month",
		"year"
	]),
	/**
	* Define custom view renderers for each section.
	* If `null`, the section will only have field editing.
	* If `undefined`, internally defined view will be used.
	*/
	viewRenderers: import_prop_types.default.shape({
		day: import_prop_types.default.func,
		month: import_prop_types.default.func,
		year: import_prop_types.default.func
	}),
	/**
	* Available views.
	*/
	views: import_prop_types.default.arrayOf(import_prop_types.default.oneOf([
		"day",
		"month",
		"year"
	]).isRequired),
	/**
	* Years are displayed in ascending (chronological) order by default.
	* If `desc`, years are displayed in descending order.
	* @default 'asc'
	*/
	yearsOrder: import_prop_types.default.oneOf(["asc", "desc"]),
	/**
	* Years rendered per row.
	* @default `4` when `displayStaticWrapperAs === 'desktop'`, `3` otherwise.
	*/
	yearsPerRow: import_prop_types.default.oneOf([3, 4])
};
//#endregion
//#region node_modules/@mui/x-date-pickers/StaticTimePicker/StaticTimePicker.mjs
/**
* Demos:
*
* - [TimePicker](https://mui.com/x/react-date-pickers/time-picker/)
* - [Validation](https://mui.com/x/react-date-pickers/validation/)
*
* API:
*
* - [StaticTimePicker API](https://mui.com/x/api/date-pickers/static-time-picker/)
*/
var StaticTimePicker = /*#__PURE__*/ import_react.forwardRef(function StaticTimePicker(inProps, ref) {
	const defaultizedProps = useTimePickerDefaultizedProps(inProps, "MuiStaticTimePicker");
	const displayStaticWrapperAs = defaultizedProps.displayStaticWrapperAs ?? "mobile";
	const ampmInClock = defaultizedProps.ampmInClock ?? displayStaticWrapperAs === "desktop";
	const { renderPicker } = useStaticPicker({
		ref,
		props: _extends({}, defaultizedProps, {
			viewRenderers: _extends({
				hours: renderTimeViewClock,
				minutes: renderTimeViewClock,
				seconds: renderTimeViewClock
			}, defaultizedProps.viewRenderers),
			displayStaticWrapperAs,
			ampmInClock,
			slotProps: _extends({}, defaultizedProps.slotProps, { toolbar: _extends({
				hidden: displayStaticWrapperAs === "desktop",
				ampmInClock
			}, defaultizedProps.slotProps?.toolbar) })
		}),
		valueManager: singleItemValueManager,
		valueType: "time",
		validator: validateTime,
		steps: null
	});
	return renderPicker();
});
StaticTimePicker.displayName = "StaticTimePicker";
StaticTimePicker.propTypes = {
	/**
	* 12h/24h view for hour selection clock.
	* @default adapter.is12HourCycleInCurrentLocale()
	*/
	ampm: import_prop_types.default.bool,
	/**
	* Display ampm controls under the clock (instead of in the toolbar).
	* @default true on desktop, false on mobile
	*/
	ampmInClock: import_prop_types.default.bool,
	/**
	* If `true`, the main element is focused during the first mount.
	* This main element is:
	* - the element chosen by the visible view if any (i.e: the selected day on the `day` view).
	* - the `input` element if there is a field rendered.
	*/
	autoFocus: import_prop_types.default.bool,
	className: import_prop_types.default.string,
	/**
	* The default value.
	* Used when the component is not controlled.
	*/
	defaultValue: import_prop_types.default.object,
	/**
	* If `true`, the component is disabled.
	* When disabled, the value cannot be changed and no interaction is possible.
	* @default false
	*/
	disabled: import_prop_types.default.bool,
	/**
	* If `true`, disable values after the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disableFuture: import_prop_types.default.bool,
	/**
	* Do not ignore date part when validating min/max time.
	* @default false
	*/
	disableIgnoringDatePartForTimeValidation: import_prop_types.default.bool,
	/**
	* If `true`, disable values before the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disablePast: import_prop_types.default.bool,
	/**
	* Force static wrapper inner components to be rendered in mobile or desktop mode.
	* @default "mobile"
	*/
	displayStaticWrapperAs: import_prop_types.default.oneOf(["desktop", "mobile"]),
	/**
	* Locale for components texts.
	* Allows overriding texts coming from `LocalizationProvider` and `theme`.
	*/
	localeText: import_prop_types.default.object,
	/**
	* Maximal selectable time.
	* The date part of the object will be ignored unless `props.disableIgnoringDatePartForTimeValidation === true`.
	*/
	maxTime: import_prop_types.default.object,
	/**
	* Minimal selectable time.
	* The date part of the object will be ignored unless `props.disableIgnoringDatePartForTimeValidation === true`.
	*/
	minTime: import_prop_types.default.object,
	/**
	* Step over minutes.
	* @default 1
	*/
	minutesStep: import_prop_types.default.number,
	/**
	* Callback fired when the value is accepted.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The value that was just accepted.
	* @param {FieldChangeHandlerContext<TError>} context Context about this acceptance:
	* - `validationError`: validation result of the current value
	* - `source`: source of the acceptance. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the value was accepted via a shortcut selection
	*/
	onAccept: import_prop_types.default.func,
	/**
	* Callback fired when the value changes.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The new value.
	* @param {FieldChangeHandlerContext<TError>} context Context about this change:
	* - `validationError`: validation result of the current value
	* - `source`: source of the change. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the change was triggered by a shortcut selection
	*/
	onChange: import_prop_types.default.func,
	/**
	* Callback fired when component requests to be closed.
	* Can be fired when selecting (by default on `desktop` mode) or clearing a value.
	* @deprecated Please avoid using as it will be removed in next major version.
	*/
	onClose: import_prop_types.default.func,
	/**
	* Callback fired when the error associated with the current value changes.
	* When a validation error is detected, the `error` parameter contains a non-null value.
	* This can be used to render an appropriate form error.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @param {TError} error The reason why the current value is not valid.
	* @param {TValue} value The value associated with the error.
	*/
	onError: import_prop_types.default.func,
	/**
	* Callback fired on view change.
	* @template TView Type of the view. It will vary based on the Picker type and the `views` it uses.
	* @param {TView} view The new view.
	*/
	onViewChange: import_prop_types.default.func,
	/**
	* The default visible view.
	* Used when the component view is not controlled.
	* Must be a valid option from `views` list.
	*/
	openTo: import_prop_types.default.oneOf([
		"hours",
		"minutes",
		"seconds"
	]),
	/**
	* Force rendering in particular orientation.
	*/
	orientation: import_prop_types.default.oneOf(["landscape", "portrait"]),
	/**
	* If `true`, the component is read-only.
	* When read-only, the value cannot be changed but the user can interact with the interface.
	* @default false
	*/
	readOnly: import_prop_types.default.bool,
	/**
	* If `true`, disable heavy animations.
	* @default `@media(prefers-reduced-motion: reduce)` || `navigator.userAgent` matches Android <10 or iOS <13
	*/
	reduceAnimations: import_prop_types.default.bool,
	/**
	* The date used to generate the new value when both `value` and `defaultValue` are empty.
	* @default The closest valid date-time using the validation props, except callbacks like `shouldDisable<...>`.
	*/
	referenceDate: import_prop_types.default.object,
	/**
	* Disable specific time.
	* @param {PickerValidDate} value The value to check.
	* @param {TimeView} view The clock type of the timeValue.
	* @returns {boolean} If `true` the time will be disabled.
	*/
	shouldDisableTime: import_prop_types.default.func,
	/**
	* The props used for each component slot.
	* @default {}
	*/
	slotProps: import_prop_types.default.object,
	/**
	* Overridable component slots.
	* @default {}
	*/
	slots: import_prop_types.default.object,
	/**
	* The system prop that allows defining system overrides as well as additional CSS styles.
	*/
	sx: import_prop_types.default.oneOfType([
		import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([
			import_prop_types.default.func,
			import_prop_types.default.object,
			import_prop_types.default.bool
		])),
		import_prop_types.default.func,
		import_prop_types.default.object
	]),
	/**
	* Choose which timezone to use for the value.
	* Example: "default", "system", "UTC", "America/New_York".
	* If you pass values from other timezones to some props, they will be converted to this timezone before being used.
	* @see See the {@link https://mui.com/x/react-date-pickers/timezone/ timezones documentation} for more details.
	* @default The timezone of the `value` or `defaultValue` prop is defined, 'default' otherwise.
	*/
	timezone: import_prop_types.default.string,
	/**
	* The selected value.
	* Used when the component is controlled.
	*/
	value: import_prop_types.default.object,
	/**
	* The visible view.
	* Used when the component view is controlled.
	* Must be a valid option from `views` list.
	*/
	view: import_prop_types.default.oneOf([
		"hours",
		"minutes",
		"seconds"
	]),
	/**
	* Define custom view renderers for each section.
	* If `null`, the section will only have field editing.
	* If `undefined`, internally defined view will be used.
	*/
	viewRenderers: import_prop_types.default.shape({
		hours: import_prop_types.default.func,
		minutes: import_prop_types.default.func,
		seconds: import_prop_types.default.func
	}),
	/**
	* Available views.
	*/
	views: import_prop_types.default.arrayOf(import_prop_types.default.oneOf([
		"hours",
		"minutes",
		"seconds"
	]).isRequired)
};
//#endregion
//#region node_modules/@mui/x-date-pickers/StaticDateTimePicker/StaticDateTimePicker.mjs
var STEPS = [{ views: DATE_VIEWS }, { views: EXPORTED_TIME_VIEWS }];
/**
* Demos:
*
* - [DateTimePicker](https://mui.com/x/react-date-pickers/date-time-picker/)
* - [Validation](https://mui.com/x/react-date-pickers/validation/)
*
* API:
*
* - [StaticDateTimePicker API](https://mui.com/x/api/date-pickers/static-date-time-picker/)
*/
var StaticDateTimePicker = /*#__PURE__*/ import_react.forwardRef(function StaticDateTimePicker(inProps, ref) {
	const defaultizedProps = useDateTimePickerDefaultizedProps(inProps, "MuiStaticDateTimePicker");
	const displayStaticWrapperAs = defaultizedProps.displayStaticWrapperAs ?? "mobile";
	const ampmInClock = defaultizedProps.ampmInClock ?? displayStaticWrapperAs === "desktop";
	const renderTimeView = defaultizedProps.shouldRenderTimeInASingleColumn ? renderDigitalClockTimeView : renderMultiSectionDigitalClockTimeView;
	const viewRenderers = _extends({
		day: renderDateViewCalendar,
		month: renderDateViewCalendar,
		year: renderDateViewCalendar,
		hours: renderTimeView,
		minutes: renderTimeView,
		seconds: renderTimeView,
		meridiem: renderTimeView
	}, defaultizedProps.viewRenderers);
	const { renderPicker } = useStaticPicker({
		ref,
		props: _extends({}, defaultizedProps, {
			viewRenderers,
			displayStaticWrapperAs,
			views: !(viewRenderers.hours?.name === renderMultiSectionDigitalClockTimeView.name) ? defaultizedProps.views.filter((view) => view !== "meridiem") : defaultizedProps.views,
			ampmInClock,
			yearsPerRow: defaultizedProps.yearsPerRow ?? (displayStaticWrapperAs === "mobile" ? 3 : 4),
			slotProps: _extends({}, defaultizedProps.slotProps, {
				tabs: _extends({ hidden: displayStaticWrapperAs === "desktop" }, defaultizedProps.slotProps?.tabs),
				toolbar: _extends({
					hidden: displayStaticWrapperAs === "desktop",
					ampmInClock
				}, defaultizedProps.slotProps?.toolbar)
			}),
			sx: mergeSx([{
				[`& .${multiSectionDigitalClockClasses.root}`]: { width: 320 },
				[`& .${multiSectionDigitalClockSectionClasses.root}`]: {
					flex: 1,
					maxHeight: 335,
					[`.${multiSectionDigitalClockSectionClasses.item}`]: { width: "auto" }
				},
				[`& .${digitalClockClasses.root}`]: {
					width: 320,
					maxHeight: 336,
					flex: 1,
					[`.${digitalClockClasses.item}`]: { justifyContent: "center" }
				}
			}], defaultizedProps?.sx)
		}),
		valueManager: singleItemValueManager,
		valueType: "date-time",
		validator: validateDateTime,
		steps: STEPS
	});
	return renderPicker();
});
StaticDateTimePicker.displayName = "StaticDateTimePicker";
StaticDateTimePicker.propTypes = {
	/**
	* 12h/24h view for hour selection clock.
	* @default adapter.is12HourCycleInCurrentLocale()
	*/
	ampm: import_prop_types.default.bool,
	/**
	* Display ampm controls under the clock (instead of in the toolbar).
	* @default true on desktop, false on mobile
	*/
	ampmInClock: import_prop_types.default.bool,
	/**
	* If `true`, the main element is focused during the first mount.
	* This main element is:
	* - the element chosen by the visible view if any (i.e: the selected day on the `day` view).
	* - the `input` element if there is a field rendered.
	*/
	autoFocus: import_prop_types.default.bool,
	className: import_prop_types.default.string,
	/**
	* Formats the day of week displayed in the calendar header.
	* @param {PickerValidDate} date The date of the day of week provided by the adapter.
	* @returns {string} The name to display.
	* @default (date: PickerValidDate) => adapter.format(date, 'weekdayShort').charAt(0).toUpperCase()
	*/
	dayOfWeekFormatter: import_prop_types.default.func,
	/**
	* The default value.
	* Used when the component is not controlled.
	*/
	defaultValue: import_prop_types.default.object,
	/**
	* If `true`, the component is disabled.
	* When disabled, the value cannot be changed and no interaction is possible.
	* @default false
	*/
	disabled: import_prop_types.default.bool,
	/**
	* If `true`, disable values after the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disableFuture: import_prop_types.default.bool,
	/**
	* If `true`, today's day is not highlighted.
	* @default false
	*/
	disableHighlightToday: import_prop_types.default.bool,
	/**
	* Do not ignore date part when validating min/max time.
	* @default false
	*/
	disableIgnoringDatePartForTimeValidation: import_prop_types.default.bool,
	/**
	* If `true`, disable values before the current date for date components, time for time components and both for date time components.
	* @default false
	*/
	disablePast: import_prop_types.default.bool,
	/**
	* Force static wrapper inner components to be rendered in mobile or desktop mode.
	* @default "mobile"
	*/
	displayStaticWrapperAs: import_prop_types.default.oneOf(["desktop", "mobile"]),
	/**
	* If `true`, the week number will be display in the calendar.
	*/
	displayWeekNumber: import_prop_types.default.bool,
	/**
	* The day view will show as many weeks as needed after the end of the current month to match this value.
	* Put it to 6 to have a fixed number of weeks in Gregorian calendars
	*/
	fixedWeekNumber: import_prop_types.default.number,
	/**
	* If `true`, calls `renderLoading` instead of rendering the day calendar.
	* Can be used to preload information and show it in calendar.
	* @default false
	*/
	loading: import_prop_types.default.bool,
	/**
	* Locale for components texts.
	* Allows overriding texts coming from `LocalizationProvider` and `theme`.
	*/
	localeText: import_prop_types.default.object,
	/**
	* Maximal selectable date.
	* @default 2099-12-31
	*/
	maxDate: import_prop_types.default.object,
	/**
	* Maximal selectable moment of time with binding to date, to set max time in each day use `maxTime`.
	*/
	maxDateTime: import_prop_types.default.object,
	/**
	* Maximal selectable time.
	* The date part of the object will be ignored unless `props.disableIgnoringDatePartForTimeValidation === true`.
	*/
	maxTime: import_prop_types.default.object,
	/**
	* Minimal selectable date.
	* @default 1900-01-01
	*/
	minDate: import_prop_types.default.object,
	/**
	* Minimal selectable moment of time with binding to date, to set min time in each day use `minTime`.
	*/
	minDateTime: import_prop_types.default.object,
	/**
	* Minimal selectable time.
	* The date part of the object will be ignored unless `props.disableIgnoringDatePartForTimeValidation === true`.
	*/
	minTime: import_prop_types.default.object,
	/**
	* Step over minutes.
	* @default 1
	*/
	minutesStep: import_prop_types.default.number,
	/**
	* Months rendered per row.
	* @default 3
	*/
	monthsPerRow: import_prop_types.default.oneOf([3, 4]),
	/**
	* Callback fired when the value is accepted.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The value that was just accepted.
	* @param {FieldChangeHandlerContext<TError>} context Context about this acceptance:
	* - `validationError`: validation result of the current value
	* - `source`: source of the acceptance. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the value was accepted via a shortcut selection
	*/
	onAccept: import_prop_types.default.func,
	/**
	* Callback fired when the value changes.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @param {TValue} value The new value.
	* @param {FieldChangeHandlerContext<TError>} context Context about this change:
	* - `validationError`: validation result of the current value
	* - `source`: source of the change. One of 'field' | 'view' | 'unknown'
	* - `shortcut` (optional): the shortcut metadata if the change was triggered by a shortcut selection
	*/
	onChange: import_prop_types.default.func,
	/**
	* Callback fired when component requests to be closed.
	* Can be fired when selecting (by default on `desktop` mode) or clearing a value.
	* @deprecated Please avoid using as it will be removed in next major version.
	*/
	onClose: import_prop_types.default.func,
	/**
	* Callback fired when the error associated with the current value changes.
	* When a validation error is detected, the `error` parameter contains a non-null value.
	* This can be used to render an appropriate form error.
	* @template TError The validation error type. It will be either `string` or a `null`. It can be in `[start, end]` format in case of range value.
	* @template TValue The value type. It will be the same type as `value` or `null`. It can be in `[start, end]` format in case of range value.
	* @param {TError} error The reason why the current value is not valid.
	* @param {TValue} value The value associated with the error.
	*/
	onError: import_prop_types.default.func,
	/**
	* Callback fired on month change.
	* @param {PickerValidDate} month The new month.
	*/
	onMonthChange: import_prop_types.default.func,
	/**
	* Callback fired on view change.
	* @template TView Type of the view. It will vary based on the Picker type and the `views` it uses.
	* @param {TView} view The new view.
	*/
	onViewChange: import_prop_types.default.func,
	/**
	* Callback fired on year change.
	* @param {PickerValidDate} year The new year.
	*/
	onYearChange: import_prop_types.default.func,
	/**
	* The default visible view.
	* Used when the component view is not controlled.
	* Must be a valid option from `views` list.
	*/
	openTo: import_prop_types.default.oneOf([
		"day",
		"hours",
		"meridiem",
		"minutes",
		"month",
		"seconds",
		"year"
	]),
	/**
	* Force rendering in particular orientation.
	*/
	orientation: import_prop_types.default.oneOf(["landscape", "portrait"]),
	/**
	* If `true`, the component is read-only.
	* When read-only, the value cannot be changed but the user can interact with the interface.
	* @default false
	*/
	readOnly: import_prop_types.default.bool,
	/**
	* If `true`, disable heavy animations.
	* @default `@media(prefers-reduced-motion: reduce)` || `navigator.userAgent` matches Android <10 or iOS <13
	*/
	reduceAnimations: import_prop_types.default.bool,
	/**
	* The date used to generate the new value when both `value` and `defaultValue` are empty.
	* @default The closest valid date-time using the validation props, except callbacks like `shouldDisable<...>`.
	*/
	referenceDate: import_prop_types.default.object,
	/**
	* Component displaying when passed `loading` true.
	* @returns {React.ReactNode} The node to render when loading.
	* @default () => <span>…</span>
	*/
	renderLoading: import_prop_types.default.func,
	/**
	* Disable specific date.
	*
	* Warning: This function can be called multiple times (for example when rendering date calendar, checking if focus can be moved to a certain date, etc.). Expensive computations can impact performance.
	*
	* @param {PickerValidDate} day The date to test.
	* @returns {boolean} If `true` the date will be disabled.
	*/
	shouldDisableDate: import_prop_types.default.func,
	/**
	* Disable specific month.
	* @param {PickerValidDate} month The month to test.
	* @returns {boolean} If `true`, the month will be disabled.
	*/
	shouldDisableMonth: import_prop_types.default.func,
	/**
	* Disable specific time.
	* @param {PickerValidDate} value The value to check.
	* @param {TimeView} view The clock type of the timeValue.
	* @returns {boolean} If `true` the time will be disabled.
	*/
	shouldDisableTime: import_prop_types.default.func,
	/**
	* Disable specific year.
	* @param {PickerValidDate} year The year to test.
	* @returns {boolean} If `true`, the year will be disabled.
	*/
	shouldDisableYear: import_prop_types.default.func,
	/**
	* If `true`, days outside the current month are rendered:
	*
	* - if `fixedWeekNumber` is defined, renders days to have the weeks requested.
	*
	* - if `fixedWeekNumber` is not defined, renders day to fill the first and last week of the current month.
	*
	* - ignored if `calendars` equals more than `1` on range pickers.
	* @default false
	*/
	showDaysOutsideCurrentMonth: import_prop_types.default.bool,
	/**
	* If `true`, disabled digital clock items will not be rendered.
	* @default false
	*/
	skipDisabled: import_prop_types.default.bool,
	/**
	* The props used for each component slot.
	* @default {}
	*/
	slotProps: import_prop_types.default.object,
	/**
	* Overridable component slots.
	* @default {}
	*/
	slots: import_prop_types.default.object,
	/**
	* The system prop that allows defining system overrides as well as additional CSS styles.
	*/
	sx: import_prop_types.default.oneOfType([
		import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([
			import_prop_types.default.func,
			import_prop_types.default.object,
			import_prop_types.default.bool
		])),
		import_prop_types.default.func,
		import_prop_types.default.object
	]),
	/**
	* Amount of time options below or at which the single column time renderer is used.
	* @default 24
	*/
	thresholdToRenderTimeInASingleColumn: import_prop_types.default.number,
	/**
	* The time steps between two time unit options.
	* For example, if `timeSteps.minutes = 8`, then the available minute options will be `[0, 8, 16, 24, 32, 40, 48, 56]`.
	* When single column time renderer is used, only `timeSteps.minutes` will be used.
	* @default{ hours: 1, minutes: 5, seconds: 5 }
	*/
	timeSteps: import_prop_types.default.shape({
		hours: import_prop_types.default.number,
		minutes: import_prop_types.default.number,
		seconds: import_prop_types.default.number
	}),
	/**
	* Choose which timezone to use for the value.
	* Example: "default", "system", "UTC", "America/New_York".
	* If you pass values from other timezones to some props, they will be converted to this timezone before being used.
	* @see See the {@link https://mui.com/x/react-date-pickers/timezone/ timezones documentation} for more details.
	* @default The timezone of the `value` or `defaultValue` prop is defined, 'default' otherwise.
	*/
	timezone: import_prop_types.default.string,
	/**
	* The selected value.
	* Used when the component is controlled.
	*/
	value: import_prop_types.default.object,
	/**
	* The visible view.
	* Used when the component view is controlled.
	* Must be a valid option from `views` list.
	*/
	view: import_prop_types.default.oneOf([
		"day",
		"hours",
		"meridiem",
		"minutes",
		"month",
		"seconds",
		"year"
	]),
	/**
	* Define custom view renderers for each section.
	* If `null`, the section will only have field editing.
	* If `undefined`, internally defined view will be used.
	*/
	viewRenderers: import_prop_types.default.shape({
		day: import_prop_types.default.func,
		hours: import_prop_types.default.func,
		meridiem: import_prop_types.default.func,
		minutes: import_prop_types.default.func,
		month: import_prop_types.default.func,
		seconds: import_prop_types.default.func,
		year: import_prop_types.default.func
	}),
	/**
	* Available views.
	*/
	views: import_prop_types.default.arrayOf(import_prop_types.default.oneOf([
		"day",
		"hours",
		"minutes",
		"month",
		"seconds",
		"year"
	]).isRequired),
	/**
	* Years are displayed in ascending (chronological) order by default.
	* If `desc`, years are displayed in descending order.
	* @default 'asc'
	*/
	yearsOrder: import_prop_types.default.oneOf(["asc", "desc"]),
	/**
	* Years rendered per row.
	* @default `4` when `displayStaticWrapperAs === 'desktop'`, `3` otherwise.
	*/
	yearsPerRow: import_prop_types.default.oneOf([3, 4])
};
//#endregion
//#region node_modules/@mui/x-date-pickers/index.mjs
/**
* @mui/x-date-pickers v9.11.0
*
* @license MIT
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
//#endregion
export { ArrowDropDownIcon, ArrowLeftIcon, ArrowRightIcon, CalendarIcon, ClearIcon, ClockIcon, DEFAULT_DESKTOP_MODE_MEDIA_QUERY, DateCalendar, DateField, DatePicker, DatePickerToolbar, DateRangeIcon, DateTimeField, DateTimePicker, DateTimePickerTabs, DateTimePickerToolbar, DayCalendarSkeleton, DesktopDatePicker, DesktopDateTimePicker, DesktopDateTimePickerLayout, DesktopTimePicker, DigitalClock, DigitalClockItem, LocalizationProvider, MobileDatePicker, MobileDateTimePicker, MobileTimePicker, MonthCalendar, MultiSectionDigitalClock, PickerDay, PickersActionBar, PickersCalendarHeader, PickersFilledInput, PickersInput, PickersInputBase, PickersLayout, PickersLayoutContentWrapper, PickersLayoutRoot, PickersOutlinedInput, PickersShortcuts, PickersTextField, StaticDatePicker, StaticDateTimePicker, StaticTimePicker, TimeClock, TimeField, TimeIcon, TimePicker, TimePickerToolbar, PickersSectionList as Unstable_PickersSectionList, PickersSectionListRoot as Unstable_PickersSectionListRoot, PickersSectionListSection as Unstable_PickersSectionListSection, PickersSectionListSectionContent as Unstable_PickersSectionListSectionContent, PickersSectionListSectionSeparator as Unstable_PickersSectionListSectionSeparator, YearCalendar, clockClasses, clockNumberClasses, clockPointerClasses, dateCalendarClasses, datePickerToolbarClasses, dateTimePickerTabsClasses, dateTimePickerToolbarClasses, dayCalendarClasses, dayCalendarSkeletonClasses, digitalClockClasses, extractValidationProps, getDateCalendarUtilityClass, getDayCalendarSkeletonUtilityClass, getDigitalClockUtilityClass, getMonthCalendarUtilityClass, getMultiSectionDigitalClockUtilityClass, getPickerDayUtilityClass, getPickersFilledInputUtilityClass, getPickersInputBaseUtilityClass, getPickersInputUtilityClass, getPickersOutlinedInputUtilityClass, getPickersSectionListUtilityClass, getPickersTextFieldUtilityClass, getTimeClockUtilityClass, getYearCalendarUtilityClass, monthCalendarClasses, multiSectionDigitalClockClasses, multiSectionDigitalClockSectionClasses, pickerDayClasses, pickersCalendarHeaderClasses, pickersFadeTransitionGroupClasses, pickersFilledInputClasses, pickersInputBaseClasses, pickersInputClasses, pickersLayoutClasses, pickersOutlinedInputClasses, pickersSectionListClasses, pickersSlideTransitionClasses, pickersTextFieldClasses, renderDateViewCalendar, renderDigitalClockTimeView, renderMultiSectionDigitalClockTimeView, renderTimeViewClock, timeClockClasses, timePickerToolbarClasses, useDateField as unstable_useDateField, useDateTimeField as unstable_useDateTimeField, useTimeField as unstable_useTimeField, useDateManager, useDateTimeManager, useIsValidValue, useParsedFormat, usePickerActionsContext, usePickerAdapter, usePickerContext, usePickerLayout, usePickerTranslations, useSplitFieldProps, useTimeManager, useValidation, validateDate, validateDateTime, validateTime, yearCalendarClasses };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQG11aV94LWRhdGUtcGlja2Vycy5qcyIsIm5hbWVzIjpbIl9leGNsdWRlZCIsIlByb3BUeXBlcyIsIlByb3BUeXBlcyIsIlByb3BUeXBlcyIsIlByb3BUeXBlcyJdLCJzb3VyY2VzIjpbIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvaG9va3MvdXNlUGFyc2VkRm9ybWF0Lm1qcyIsIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvRGF5Q2FsZW5kYXJTa2VsZXRvbi9kYXlDYWxlbmRhclNrZWxldG9uQ2xhc3Nlcy5tanMiLCIuLi8uLi9AbXVpL3gtZGF0ZS1waWNrZXJzL0RheUNhbGVuZGFyU2tlbGV0b24vRGF5Q2FsZW5kYXJTa2VsZXRvbi5tanMiLCIuLi8uLi9AbXVpL3gtZGF0ZS1waWNrZXJzL2ludGVybmFscy9ob29rcy91c2VTdGF0aWNQaWNrZXIvdXNlU3RhdGljUGlja2VyLm1qcyIsIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvU3RhdGljRGF0ZVBpY2tlci9TdGF0aWNEYXRlUGlja2VyLm1qcyIsIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvU3RhdGljVGltZVBpY2tlci9TdGF0aWNUaW1lUGlja2VyLm1qcyIsIi4uLy4uL0BtdWkveC1kYXRlLXBpY2tlcnMvU3RhdGljRGF0ZVRpbWVQaWNrZXIvU3RhdGljRGF0ZVRpbWVQaWNrZXIubWpzIiwiLi4vLi4vQG11aS94LWRhdGUtcGlja2Vycy9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQaWNrZXJBZGFwdGVyIH0gZnJvbSBcIi4vdXNlUGlja2VyQWRhcHRlci5tanNcIjtcbmltcG9ydCB7IGJ1aWxkU2VjdGlvbnNGcm9tRm9ybWF0IH0gZnJvbSBcIi4uL2ludGVybmFscy9ob29rcy91c2VGaWVsZC9idWlsZFNlY3Rpb25zRnJvbUZvcm1hdC5tanNcIjtcbmltcG9ydCB7IGdldExvY2FsaXplZERpZ2l0cyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvaG9va3MvdXNlRmllbGQvdXNlRmllbGQudXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VQaWNrZXJUcmFuc2xhdGlvbnMgfSBmcm9tIFwiLi91c2VQaWNrZXJUcmFuc2xhdGlvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VOdWxsYWJsZVBpY2tlckNvbnRleHQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL2hvb2tzL3VzZU51bGxhYmxlUGlja2VyQ29udGV4dC5tanNcIjtcbi8qKlxuICogUmV0dXJucyB0aGUgcGFyc2VkIGZvcm1hdCB0byBiZSByZW5kZXJlZCBpbiB0aGUgZmllbGQgd2hlbiB0aGVyZSBpcyBubyB2YWx1ZSBvciBpbiBvdGhlciBwYXJ0cyBvZiB0aGUgUGlja2VyLlxuICogVGhpcyBmb3JtYXQgaXMgbG9jYWxpemVkIChmb3IgZXhhbXBsZSBgQUFBQWAgZm9yIHRoZSB5ZWFyIHdpdGggdGhlIEZyZW5jaCBsb2NhbGUpIGFuZCBjYW5ub3QgYmUgcGFyc2VkIGJ5IHlvdXIgZGF0ZSBsaWJyYXJ5LlxuICogQHBhcmFtIHtvYmplY3R9IFRoZSBwYXJhbWV0ZXJzIG5lZWRlZCB0byBidWlsZCB0aGUgcGxhY2Vob2xkZXIuXG4gKiBAcGFyYW0ge3N0cmluZ30gcGFyYW1zLmZvcm1hdCBGb3JtYXQgdG8gcGFyc2UuXG4gKiBAcmV0dXJuc1xuICovXG5leHBvcnQgY29uc3QgdXNlUGFyc2VkRm9ybWF0ID0gKHBhcmFtZXRlcnMgPSB7fSkgPT4ge1xuICBjb25zdCBwaWNrZXJDb250ZXh0ID0gdXNlTnVsbGFibGVQaWNrZXJDb250ZXh0KCk7XG4gIGNvbnN0IGFkYXB0ZXIgPSB1c2VQaWNrZXJBZGFwdGVyKCk7XG4gIGNvbnN0IHRyYW5zbGF0aW9ucyA9IHVzZVBpY2tlclRyYW5zbGF0aW9ucygpO1xuICBjb25zdCBsb2NhbGl6ZWREaWdpdHMgPSBSZWFjdC51c2VNZW1vKCgpID0+IGdldExvY2FsaXplZERpZ2l0cyhhZGFwdGVyKSwgW2FkYXB0ZXJdKTtcbiAgY29uc3Qge1xuICAgIGZvcm1hdCA9IHBpY2tlckNvbnRleHQ/LmZpZWxkRm9ybWF0ID8/IGFkYXB0ZXIuZm9ybWF0cy5mdWxsRGF0ZVxuICB9ID0gcGFyYW1ldGVycztcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHNlY3Rpb25zID0gYnVpbGRTZWN0aW9uc0Zyb21Gb3JtYXQoe1xuICAgICAgYWRhcHRlcixcbiAgICAgIGZvcm1hdCxcbiAgICAgIGZvcm1hdERlbnNpdHk6ICdkZW5zZScsXG4gICAgICAvLyBQYXNzIGBpc1J0bDogZmFsc2VgIHRvIHByZXZlbnQgUlRMIGZvcm1hdCByZXZlcnNhbC5cbiAgICAgIC8vIGB1c2VQYXJzZWRGb3JtYXRgIGJ1aWxkcyBhIGRpc3BsYXkgc3RyaW5nLCBub3QgYSBmaWVsZCBsYXlvdXQuXG4gICAgICBpc1J0bDogZmFsc2UsXG4gICAgICBzaG91bGRSZXNwZWN0TGVhZGluZ1plcm9zOiB0cnVlLFxuICAgICAgbG9jYWxlVGV4dDogdHJhbnNsYXRpb25zLFxuICAgICAgbG9jYWxpemVkRGlnaXRzLFxuICAgICAgZGF0ZTogbnVsbFxuICAgIH0pO1xuICAgIHJldHVybiBzZWN0aW9ucy5tYXAoc2VjdGlvbiA9PiBgJHtzZWN0aW9uLnN0YXJ0U2VwYXJhdG9yfSR7c2VjdGlvbi5wbGFjZWhvbGRlcn0ke3NlY3Rpb24uZW5kU2VwYXJhdG9yfWApLmpvaW4oJycpO1xuICB9LCBbYWRhcHRlciwgdHJhbnNsYXRpb25zLCBsb2NhbGl6ZWREaWdpdHMsIGZvcm1hdF0pO1xufTsiLCJpbXBvcnQgZ2VuZXJhdGVVdGlsaXR5Q2xhc3MgZnJvbSAnQG11aS91dGlscy9nZW5lcmF0ZVV0aWxpdHlDbGFzcyc7XG5pbXBvcnQgZ2VuZXJhdGVVdGlsaXR5Q2xhc3NlcyBmcm9tICdAbXVpL3V0aWxzL2dlbmVyYXRlVXRpbGl0eUNsYXNzZXMnO1xuZXhwb3J0IGNvbnN0IGdldERheUNhbGVuZGFyU2tlbGV0b25VdGlsaXR5Q2xhc3MgPSBzbG90ID0+IGdlbmVyYXRlVXRpbGl0eUNsYXNzKCdNdWlEYXlDYWxlbmRhclNrZWxldG9uJywgc2xvdCk7XG5leHBvcnQgY29uc3QgZGF5Q2FsZW5kYXJTa2VsZXRvbkNsYXNzZXMgPSBnZW5lcmF0ZVV0aWxpdHlDbGFzc2VzKCdNdWlEYXlDYWxlbmRhclNrZWxldG9uJywgWydyb290JywgJ3dlZWsnLCAnZGF5U2tlbGV0b24nXSk7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2V4dGVuZHMgZnJvbSBcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL2V4dGVuZHNcIjtcbmltcG9ydCBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZSBmcm9tIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZVwiO1xuY29uc3QgX2V4Y2x1ZGVkID0gW1wiY2xhc3NOYW1lXCIsIFwiY2xhc3Nlc1wiXTtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4JztcbmltcG9ydCBTa2VsZXRvbiBmcm9tICdAbXVpL21hdGVyaWFsL1NrZWxldG9uJztcbmltcG9ydCB7IHN0eWxlZCwgdXNlVGhlbWVQcm9wcyB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvc3R5bGVzJztcbmltcG9ydCBjb21wb3NlQ2xhc3NlcyBmcm9tICdAbXVpL3V0aWxzL2NvbXBvc2VDbGFzc2VzJztcbmltcG9ydCB7IERBWV9TSVpFLCBEQVlfTUFSR0lOIH0gZnJvbSBcIi4uL2ludGVybmFscy9jb25zdGFudHMvZGltZW5zaW9ucy5tanNcIjtcbmltcG9ydCB7IGdldERheUNhbGVuZGFyU2tlbGV0b25VdGlsaXR5Q2xhc3MgfSBmcm9tIFwiLi9kYXlDYWxlbmRhclNrZWxldG9uQ2xhc3Nlcy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCB1c2VVdGlsaXR5Q2xhc3NlcyA9IGNsYXNzZXMgPT4ge1xuICBjb25zdCBzbG90cyA9IHtcbiAgICByb290OiBbJ3Jvb3QnXSxcbiAgICB3ZWVrOiBbJ3dlZWsnXSxcbiAgICBkYXlTa2VsZXRvbjogWydkYXlTa2VsZXRvbiddXG4gIH07XG4gIHJldHVybiBjb21wb3NlQ2xhc3NlcyhzbG90cywgZ2V0RGF5Q2FsZW5kYXJTa2VsZXRvblV0aWxpdHlDbGFzcywgY2xhc3Nlcyk7XG59O1xuY29uc3QgRGF5Q2FsZW5kYXJTa2VsZXRvblJvb3QgPSBzdHlsZWQoJ2RpdicsIHtcbiAgbmFtZTogJ011aURheUNhbGVuZGFyU2tlbGV0b24nLFxuICBzbG90OiAnUm9vdCdcbn0pKHtcbiAgYWxpZ25TZWxmOiAnc3RhcnQnXG59KTtcbmNvbnN0IERheUNhbGVuZGFyU2tlbGV0b25XZWVrID0gc3R5bGVkKCdkaXYnLCB7XG4gIG5hbWU6ICdNdWlEYXlDYWxlbmRhclNrZWxldG9uJyxcbiAgc2xvdDogJ1dlZWsnXG59KSh7XG4gIG1hcmdpbjogYCR7REFZX01BUkdJTn1weCAwYCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcidcbn0pO1xuY29uc3QgRGF5Q2FsZW5kYXJTa2VsZXRvbkRheSA9IHN0eWxlZChTa2VsZXRvbiwge1xuICBuYW1lOiAnTXVpRGF5Q2FsZW5kYXJTa2VsZXRvbicsXG4gIHNsb3Q6ICdEYXlTa2VsZXRvbidcbn0pKHtcbiAgbWFyZ2luOiBgMCAke0RBWV9NQVJHSU59cHhgLFxuICAnJltkYXRhLWRheS1pbi1tb250aD1cIjBcIl0nOiB7XG4gICAgdmlzaWJpbGl0eTogJ2hpZGRlbidcbiAgfVxufSk7XG5jb25zdCBtb250aE1hcCA9IFtbMCwgMSwgMSwgMSwgMSwgMSwgMV0sIFsxLCAxLCAxLCAxLCAxLCAxLCAxXSwgWzEsIDEsIDEsIDEsIDEsIDEsIDFdLCBbMSwgMSwgMSwgMSwgMSwgMSwgMV0sIFsxLCAxLCAxLCAxLCAwLCAwLCAwXV07XG5cbi8qKlxuICogRGVtb3M6XG4gKlxuICogLSBbRGF0ZUNhbGVuZGFyXShodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvZGF0ZS1jYWxlbmRhci8pXG4gKlxuICogQVBJOlxuICpcbiAqIC0gW0NhbGVuZGFyUGlja2VyU2tlbGV0b24gQVBJXShodHRwczovL211aS5jb20veC9hcGkvZGF0ZS1waWNrZXJzL2NhbGVuZGFyLXBpY2tlci1za2VsZXRvbi8pXG4gKi9cbmZ1bmN0aW9uIERheUNhbGVuZGFyU2tlbGV0b24oaW5Qcm9wcykge1xuICBjb25zdCBwcm9wcyA9IHVzZVRoZW1lUHJvcHMoe1xuICAgIHByb3BzOiBpblByb3BzLFxuICAgIG5hbWU6ICdNdWlEYXlDYWxlbmRhclNrZWxldG9uJ1xuICB9KTtcbiAgY29uc3Qge1xuICAgICAgY2xhc3NOYW1lLFxuICAgICAgY2xhc3NlczogY2xhc3Nlc1Byb3BcbiAgICB9ID0gcHJvcHMsXG4gICAgb3RoZXIgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShwcm9wcywgX2V4Y2x1ZGVkKTtcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVV0aWxpdHlDbGFzc2VzKGNsYXNzZXNQcm9wKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KERheUNhbGVuZGFyU2tlbGV0b25Sb290LCBfZXh0ZW5kcyh7XG4gICAgY2xhc3NOYW1lOiBjbHN4KGNsYXNzZXMucm9vdCwgY2xhc3NOYW1lKSxcbiAgICBvd25lclN0YXRlOiBwcm9wc1xuICB9LCBvdGhlciwge1xuICAgIGNoaWxkcmVuOiBtb250aE1hcC5tYXAoKHdlZWssIGluZGV4KSA9PiAvKiNfX1BVUkVfXyovX2pzeChEYXlDYWxlbmRhclNrZWxldG9uV2Vlaywge1xuICAgICAgY2xhc3NOYW1lOiBjbGFzc2VzLndlZWssXG4gICAgICBjaGlsZHJlbjogd2Vlay5tYXAoKGRheUluTW9udGgsIGluZGV4MikgPT4gLyojX19QVVJFX18qL19qc3goRGF5Q2FsZW5kYXJTa2VsZXRvbkRheSwge1xuICAgICAgICB2YXJpYW50OiBcImNpcmN1bGFyXCIsXG4gICAgICAgIHdpZHRoOiBEQVlfU0laRSxcbiAgICAgICAgaGVpZ2h0OiBEQVlfU0laRSxcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc2VzLmRheVNrZWxldG9uLFxuICAgICAgICBcImRhdGEtZGF5LWluLW1vbnRoXCI6IGRheUluTW9udGhcbiAgICAgIH0sIGluZGV4MikpXG4gICAgfSwgaW5kZXgpKVxuICB9KSk7XG59XG5wcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBEYXlDYWxlbmRhclNrZWxldG9uLnByb3BUeXBlcyAvKiByZW1vdmUtcHJvcHR5cGVzICovID0ge1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBXYXJuaW5nIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIHwgVGhlc2UgUHJvcFR5cGVzIGFyZSBnZW5lcmF0ZWQgZnJvbSB0aGUgVHlwZVNjcmlwdCB0eXBlIGRlZmluaXRpb25zIHxcbiAgLy8gfCBUbyB1cGRhdGUgdGhlbSBlZGl0IHRoZSBUeXBlU2NyaXB0IHR5cGVzIGFuZCBydW4gXCJwbnBtIHByb3B0eXBlc1wiICB8XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIE92ZXJyaWRlIG9yIGV4dGVuZCB0aGUgc3R5bGVzIGFwcGxpZWQgdG8gdGhlIGNvbXBvbmVudC5cbiAgICovXG4gIGNsYXNzZXM6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBUaGUgc3lzdGVtIHByb3AgdGhhdCBhbGxvd3MgZGVmaW5pbmcgc3lzdGVtIG92ZXJyaWRlcyBhcyB3ZWxsIGFzIGFkZGl0aW9uYWwgQ1NTIHN0eWxlcy5cbiAgICovXG4gIHN4OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuZnVuYywgUHJvcFR5cGVzLm9iamVjdCwgUHJvcFR5cGVzLmJvb2xdKSksIFByb3BUeXBlcy5mdW5jLCBQcm9wVHlwZXMub2JqZWN0XSlcbn0gOiB2b2lkIDA7XG5leHBvcnQgeyBEYXlDYWxlbmRhclNrZWxldG9uIH07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2V4dGVuZHMgZnJvbSBcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL2V4dGVuZHNcIjtcbmltcG9ydCBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZSBmcm9tIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZVwiO1xuY29uc3QgX2V4Y2x1ZGVkID0gW1wicHJvcHNcIiwgXCJzdGVwc1wiXTtcbmltcG9ydCBjbHN4IGZyb20gJ2Nsc3gnO1xuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSAnQG11aS9tYXRlcmlhbC9zdHlsZXMnO1xuaW1wb3J0IHsgdXNlUGlja2VyIH0gZnJvbSBcIi4uL3VzZVBpY2tlci9pbmRleC5tanNcIjtcbmltcG9ydCB7IFBpY2tlclByb3ZpZGVyIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUGlja2VyUHJvdmlkZXIubWpzXCI7XG5pbXBvcnQgeyBQaWNrZXJzTGF5b3V0IH0gZnJvbSBcIi4uLy4uLy4uL1BpY2tlcnNMYXlvdXQvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBESUFMT0dfV0lEVEggfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzL2RpbWVuc2lvbnMubWpzXCI7XG5pbXBvcnQgeyBleHRyYWN0Um9vdEZvcndhcmRlZFByb3BzLCBtZXJnZVN4IH0gZnJvbSBcIi4uLy4uL3V0aWxzL3V0aWxzLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlTm9uUmFuZ2VQaWNrZXJTdGVwTmF2aWdhdGlvbiB9IGZyb20gXCIuLi8uLi91dGlscy9jcmVhdGVOb25SYW5nZVBpY2tlclN0ZXBOYXZpZ2F0aW9uLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmNvbnN0IFBpY2tlclN0YXRpY0xheW91dCA9IHN0eWxlZChQaWNrZXJzTGF5b3V0LCB7XG4gIHNsb3Q6ICdpbnRlcm5hbCdcbn0pKCh7XG4gIHRoZW1lXG59KSA9PiAoe1xuICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gIG1pbldpZHRoOiBESUFMT0dfV0lEVEgsXG4gIGJhY2tncm91bmRDb2xvcjogKHRoZW1lLnZhcnMgfHwgdGhlbWUpLnBhbGV0dGUuYmFja2dyb3VuZC5wYXBlclxufSkpO1xuXG4vKipcbiAqIEhvb2sgbWFuYWdpbmcgYWxsIHRoZSBzaW5nbGUtZGF0ZSBzdGF0aWMgcGlja2VyczpcbiAqIC0gU3RhdGljRGF0ZVBpY2tlclxuICogLSBTdGF0aWNEYXRlVGltZVBpY2tlclxuICogLSBTdGF0aWNUaW1lUGlja2VyXG4gKi9cbmV4cG9ydCBjb25zdCB1c2VTdGF0aWNQaWNrZXIgPSBfcmVmID0+IHtcbiAgbGV0IHtcbiAgICAgIHByb3BzLFxuICAgICAgc3RlcHNcbiAgICB9ID0gX3JlZixcbiAgICBwaWNrZXJQYXJhbXMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShfcmVmLCBfZXhjbHVkZWQpO1xuICBjb25zdCB7XG4gICAgbG9jYWxlVGV4dCxcbiAgICBzbG90cyxcbiAgICBzbG90UHJvcHMsXG4gICAgZGlzcGxheVN0YXRpY1dyYXBwZXJBcyxcbiAgICBhdXRvRm9jdXNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBnZXRTdGVwTmF2aWdhdGlvbiA9IGNyZWF0ZU5vblJhbmdlUGlja2VyU3RlcE5hdmlnYXRpb24oe1xuICAgIHN0ZXBzXG4gIH0pO1xuICBjb25zdCB7XG4gICAgcHJvdmlkZXJQcm9wcyxcbiAgICByZW5kZXJDdXJyZW50Vmlld1xuICB9ID0gdXNlUGlja2VyKF9leHRlbmRzKHt9LCBwaWNrZXJQYXJhbXMsIHtcbiAgICBwcm9wcyxcbiAgICB2YXJpYW50OiBkaXNwbGF5U3RhdGljV3JhcHBlckFzLFxuICAgIGF1dG9Gb2N1c1ZpZXc6IGF1dG9Gb2N1cyA/PyBmYWxzZSxcbiAgICB2aWV3Q29udGFpbmVyUm9sZTogbnVsbCxcbiAgICBsb2NhbGVUZXh0LFxuICAgIGdldFN0ZXBOYXZpZ2F0aW9uXG4gIH0pKTtcbiAgY29uc3QgTGF5b3V0ID0gc2xvdHM/LmxheW91dCA/PyBQaWNrZXJTdGF0aWNMYXlvdXQ7XG4gIGNvbnN0IHJlbmRlclBpY2tlciA9ICgpID0+IC8qI19fUFVSRV9fKi9fanN4KFBpY2tlclByb3ZpZGVyLCBfZXh0ZW5kcyh7fSwgcHJvdmlkZXJQcm9wcywge1xuICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChMYXlvdXQsIF9leHRlbmRzKHt9LCBleHRyYWN0Um9vdEZvcndhcmRlZFByb3BzKHByb3BzKSwgc2xvdFByb3BzPy5sYXlvdXQsIHtcbiAgICAgIHNsb3RzOiBzbG90cyxcbiAgICAgIHNsb3RQcm9wczogc2xvdFByb3BzLFxuICAgICAgc3g6IG1lcmdlU3gocHJvdmlkZXJQcm9wcy5jb250ZXh0VmFsdWUucm9vdFN4LCBzbG90UHJvcHM/LmxheW91dD8uc3gpLFxuICAgICAgY2xhc3NOYW1lOiBjbHN4KHByb3ZpZGVyUHJvcHMuY29udGV4dFZhbHVlLnJvb3RDbGFzc05hbWUsIHNsb3RQcm9wcz8ubGF5b3V0Py5jbGFzc05hbWUpLFxuICAgICAgcmVmOiBwcm92aWRlclByb3BzLmNvbnRleHRWYWx1ZS5yb290UmVmLFxuICAgICAgY2hpbGRyZW46IHJlbmRlckN1cnJlbnRWaWV3KClcbiAgICB9KSlcbiAgfSkpO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSByZW5kZXJQaWNrZXIuZGlzcGxheU5hbWUgPSBcInJlbmRlclBpY2tlclwiO1xuICByZXR1cm4ge1xuICAgIHJlbmRlclBpY2tlclxuICB9O1xufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZXh0ZW5kcyBmcm9tIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZXh0ZW5kc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IHVzZURhdGVQaWNrZXJEZWZhdWx0aXplZFByb3BzIH0gZnJvbSBcIi4uL0RhdGVQaWNrZXIvc2hhcmVkLm1qc1wiO1xuaW1wb3J0IHsgcmVuZGVyRGF0ZVZpZXdDYWxlbmRhciB9IGZyb20gXCIuLi9kYXRlVmlld1JlbmRlcmVycy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZVN0YXRpY1BpY2tlciB9IGZyb20gXCIuLi9pbnRlcm5hbHMvaG9va3MvdXNlU3RhdGljUGlja2VyL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdmFsaWRhdGVEYXRlIH0gZnJvbSBcIi4uL3ZhbGlkYXRpb24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBzaW5nbGVJdGVtVmFsdWVNYW5hZ2VyIH0gZnJvbSBcIi4uL2ludGVybmFscy91dGlscy92YWx1ZU1hbmFnZXJzLm1qc1wiO1xuLyoqXG4gKiBEZW1vczpcbiAqXG4gKiAtIFtEYXRlUGlja2VyXShodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvZGF0ZS1waWNrZXIvKVxuICogLSBbVmFsaWRhdGlvbl0oaHR0cHM6Ly9tdWkuY29tL3gvcmVhY3QtZGF0ZS1waWNrZXJzL3ZhbGlkYXRpb24vKVxuICpcbiAqIEFQSTpcbiAqXG4gKiAtIFtTdGF0aWNEYXRlUGlja2VyIEFQSV0oaHR0cHM6Ly9tdWkuY29tL3gvYXBpL2RhdGUtcGlja2Vycy9zdGF0aWMtZGF0ZS1waWNrZXIvKVxuICovXG5jb25zdCBTdGF0aWNEYXRlUGlja2VyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU3RhdGljRGF0ZVBpY2tlcihpblByb3BzLCByZWYpIHtcbiAgY29uc3QgZGVmYXVsdGl6ZWRQcm9wcyA9IHVzZURhdGVQaWNrZXJEZWZhdWx0aXplZFByb3BzKGluUHJvcHMsICdNdWlTdGF0aWNEYXRlUGlja2VyJyk7XG4gIGNvbnN0IGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPSBkZWZhdWx0aXplZFByb3BzLmRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPz8gJ21vYmlsZSc7XG4gIGNvbnN0IHZpZXdSZW5kZXJlcnMgPSBfZXh0ZW5kcyh7XG4gICAgZGF5OiByZW5kZXJEYXRlVmlld0NhbGVuZGFyLFxuICAgIG1vbnRoOiByZW5kZXJEYXRlVmlld0NhbGVuZGFyLFxuICAgIHllYXI6IHJlbmRlckRhdGVWaWV3Q2FsZW5kYXJcbiAgfSwgZGVmYXVsdGl6ZWRQcm9wcy52aWV3UmVuZGVyZXJzKTtcblxuICAvLyBQcm9wcyB3aXRoIHRoZSBkZWZhdWx0IHZhbHVlcyBzcGVjaWZpYyB0byB0aGUgc3RhdGljIHZhcmlhbnRcbiAgY29uc3QgcHJvcHMgPSBfZXh0ZW5kcyh7fSwgZGVmYXVsdGl6ZWRQcm9wcywge1xuICAgIHZpZXdSZW5kZXJlcnMsXG4gICAgZGlzcGxheVN0YXRpY1dyYXBwZXJBcyxcbiAgICB5ZWFyc1BlclJvdzogZGVmYXVsdGl6ZWRQcm9wcy55ZWFyc1BlclJvdyA/PyAoZGlzcGxheVN0YXRpY1dyYXBwZXJBcyA9PT0gJ21vYmlsZScgPyAzIDogNCksXG4gICAgc2xvdFByb3BzOiBfZXh0ZW5kcyh7fSwgZGVmYXVsdGl6ZWRQcm9wcy5zbG90UHJvcHMsIHtcbiAgICAgIHRvb2xiYXI6IF9leHRlbmRzKHtcbiAgICAgICAgaGlkZGVuOiBkaXNwbGF5U3RhdGljV3JhcHBlckFzID09PSAnZGVza3RvcCdcbiAgICAgIH0sIGRlZmF1bHRpemVkUHJvcHMuc2xvdFByb3BzPy50b29sYmFyKVxuICAgIH0pXG4gIH0pO1xuICBjb25zdCB7XG4gICAgcmVuZGVyUGlja2VyXG4gIH0gPSB1c2VTdGF0aWNQaWNrZXIoe1xuICAgIHJlZixcbiAgICBwcm9wcyxcbiAgICB2YWx1ZU1hbmFnZXI6IHNpbmdsZUl0ZW1WYWx1ZU1hbmFnZXIsXG4gICAgdmFsdWVUeXBlOiAnZGF0ZScsXG4gICAgdmFsaWRhdG9yOiB2YWxpZGF0ZURhdGUsXG4gICAgc3RlcHM6IG51bGxcbiAgfSk7XG4gIHJldHVybiByZW5kZXJQaWNrZXIoKTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU3RhdGljRGF0ZVBpY2tlci5kaXNwbGF5TmFtZSA9IFwiU3RhdGljRGF0ZVBpY2tlclwiO1xucHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gU3RhdGljRGF0ZVBpY2tlci5wcm9wVHlwZXMgLyogcmVtb3ZlLXByb3B0eXBlcyAqLyA9IHtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gV2FybmluZyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyB8IFRoZXNlIFByb3BUeXBlcyBhcmUgZ2VuZXJhdGVkIGZyb20gdGhlIFR5cGVTY3JpcHQgdHlwZSBkZWZpbml0aW9ucyB8XG4gIC8vIHwgVG8gdXBkYXRlIHRoZW0gZWRpdCB0aGUgVHlwZVNjcmlwdCB0eXBlcyBhbmQgcnVuIFwicG5wbSBwcm9wdHlwZXNcIiAgfFxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSBtYWluIGVsZW1lbnQgaXMgZm9jdXNlZCBkdXJpbmcgdGhlIGZpcnN0IG1vdW50LlxuICAgKiBUaGlzIG1haW4gZWxlbWVudCBpczpcbiAgICogLSB0aGUgZWxlbWVudCBjaG9zZW4gYnkgdGhlIHZpc2libGUgdmlldyBpZiBhbnkgKGkuZTogdGhlIHNlbGVjdGVkIGRheSBvbiB0aGUgYGRheWAgdmlldykuXG4gICAqIC0gdGhlIGBpbnB1dGAgZWxlbWVudCBpZiB0aGVyZSBpcyBhIGZpZWxkIHJlbmRlcmVkLlxuICAgKi9cbiAgYXV0b0ZvY3VzOiBQcm9wVHlwZXMuYm9vbCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAvKipcbiAgICogRm9ybWF0cyB0aGUgZGF5IG9mIHdlZWsgZGlzcGxheWVkIGluIHRoZSBjYWxlbmRhciBoZWFkZXIuXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSBkYXRlIFRoZSBkYXRlIG9mIHRoZSBkYXkgb2Ygd2VlayBwcm92aWRlZCBieSB0aGUgYWRhcHRlci5cbiAgICogQHJldHVybnMge3N0cmluZ30gVGhlIG5hbWUgdG8gZGlzcGxheS5cbiAgICogQGRlZmF1bHQgKGRhdGU6IFBpY2tlclZhbGlkRGF0ZSkgPT4gYWRhcHRlci5mb3JtYXQoZGF0ZSwgJ3dlZWtkYXlTaG9ydCcpLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpXG4gICAqL1xuICBkYXlPZldlZWtGb3JtYXR0ZXI6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogVGhlIGRlZmF1bHQgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIG5vdCBjb250cm9sbGVkLlxuICAgKi9cbiAgZGVmYXVsdFZhbHVlOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogSWYgYHRydWVgLCB0aGUgY29tcG9uZW50IGlzIGRpc2FibGVkLlxuICAgKiBXaGVuIGRpc2FibGVkLCB0aGUgdmFsdWUgY2Fubm90IGJlIGNoYW5nZWQgYW5kIG5vIGludGVyYWN0aW9uIGlzIHBvc3NpYmxlLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZWQ6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBkaXNhYmxlIHZhbHVlcyBhZnRlciB0aGUgY3VycmVudCBkYXRlIGZvciBkYXRlIGNvbXBvbmVudHMsIHRpbWUgZm9yIHRpbWUgY29tcG9uZW50cyBhbmQgYm90aCBmb3IgZGF0ZSB0aW1lIGNvbXBvbmVudHMuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBkaXNhYmxlRnV0dXJlOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgdG9kYXkncyBkYXkgaXMgbm90IGhpZ2hsaWdodGVkLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZUhpZ2hsaWdodFRvZGF5OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZSB2YWx1ZXMgYmVmb3JlIHRoZSBjdXJyZW50IGRhdGUgZm9yIGRhdGUgY29tcG9uZW50cywgdGltZSBmb3IgdGltZSBjb21wb25lbnRzIGFuZCBib3RoIGZvciBkYXRlIHRpbWUgY29tcG9uZW50cy5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGRpc2FibGVQYXN0OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIEZvcmNlIHN0YXRpYyB3cmFwcGVyIGlubmVyIGNvbXBvbmVudHMgdG8gYmUgcmVuZGVyZWQgaW4gbW9iaWxlIG9yIGRlc2t0b3AgbW9kZS5cbiAgICogQGRlZmF1bHQgXCJtb2JpbGVcIlxuICAgKi9cbiAgZGlzcGxheVN0YXRpY1dyYXBwZXJBczogUHJvcFR5cGVzLm9uZU9mKFsnZGVza3RvcCcsICdtb2JpbGUnXSksXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSB3ZWVrIG51bWJlciB3aWxsIGJlIGRpc3BsYXkgaW4gdGhlIGNhbGVuZGFyLlxuICAgKi9cbiAgZGlzcGxheVdlZWtOdW1iZXI6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogVGhlIGRheSB2aWV3IHdpbGwgc2hvdyBhcyBtYW55IHdlZWtzIGFzIG5lZWRlZCBhZnRlciB0aGUgZW5kIG9mIHRoZSBjdXJyZW50IG1vbnRoIHRvIG1hdGNoIHRoaXMgdmFsdWUuXG4gICAqIFB1dCBpdCB0byA2IHRvIGhhdmUgYSBmaXhlZCBudW1iZXIgb2Ygd2Vla3MgaW4gR3JlZ29yaWFuIGNhbGVuZGFyc1xuICAgKi9cbiAgZml4ZWRXZWVrTnVtYmVyOiBQcm9wVHlwZXMubnVtYmVyLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBjYWxscyBgcmVuZGVyTG9hZGluZ2AgaW5zdGVhZCBvZiByZW5kZXJpbmcgdGhlIGRheSBjYWxlbmRhci5cbiAgICogQ2FuIGJlIHVzZWQgdG8gcHJlbG9hZCBpbmZvcm1hdGlvbiBhbmQgc2hvdyBpdCBpbiBjYWxlbmRhci5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGxvYWRpbmc6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogTG9jYWxlIGZvciBjb21wb25lbnRzIHRleHRzLlxuICAgKiBBbGxvd3Mgb3ZlcnJpZGluZyB0ZXh0cyBjb21pbmcgZnJvbSBgTG9jYWxpemF0aW9uUHJvdmlkZXJgIGFuZCBgdGhlbWVgLlxuICAgKi9cbiAgbG9jYWxlVGV4dDogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE1heGltYWwgc2VsZWN0YWJsZSBkYXRlLlxuICAgKiBAZGVmYXVsdCAyMDk5LTEyLTMxXG4gICAqL1xuICBtYXhEYXRlOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogTWluaW1hbCBzZWxlY3RhYmxlIGRhdGUuXG4gICAqIEBkZWZhdWx0IDE5MDAtMDEtMDFcbiAgICovXG4gIG1pbkRhdGU6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBNb250aHMgcmVuZGVyZWQgcGVyIHJvdy5cbiAgICogQGRlZmF1bHQgM1xuICAgKi9cbiAgbW9udGhzUGVyUm93OiBQcm9wVHlwZXMub25lT2YoWzMsIDRdKSxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gdGhlIHZhbHVlIGlzIGFjY2VwdGVkLlxuICAgKiBAdGVtcGxhdGUgVFZhbHVlIFRoZSB2YWx1ZSB0eXBlLiBJdCB3aWxsIGJlIHRoZSBzYW1lIHR5cGUgYXMgYHZhbHVlYCBvciBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHRlbXBsYXRlIFRFcnJvciBUaGUgdmFsaWRhdGlvbiBlcnJvciB0eXBlLiBJdCB3aWxsIGJlIGVpdGhlciBgc3RyaW5nYCBvciBhIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAcGFyYW0ge1RWYWx1ZX0gdmFsdWUgVGhlIHZhbHVlIHRoYXQgd2FzIGp1c3QgYWNjZXB0ZWQuXG4gICAqIEBwYXJhbSB7RmllbGRDaGFuZ2VIYW5kbGVyQ29udGV4dDxURXJyb3I+fSBjb250ZXh0IENvbnRleHQgYWJvdXQgdGhpcyBhY2NlcHRhbmNlOlxuICAgKiAtIGB2YWxpZGF0aW9uRXJyb3JgOiB2YWxpZGF0aW9uIHJlc3VsdCBvZiB0aGUgY3VycmVudCB2YWx1ZVxuICAgKiAtIGBzb3VyY2VgOiBzb3VyY2Ugb2YgdGhlIGFjY2VwdGFuY2UuIE9uZSBvZiAnZmllbGQnIHwgJ3ZpZXcnIHwgJ3Vua25vd24nXG4gICAqIC0gYHNob3J0Y3V0YCAob3B0aW9uYWwpOiB0aGUgc2hvcnRjdXQgbWV0YWRhdGEgaWYgdGhlIHZhbHVlIHdhcyBhY2NlcHRlZCB2aWEgYSBzaG9ydGN1dCBzZWxlY3Rpb25cbiAgICovXG4gIG9uQWNjZXB0OiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gdGhlIHZhbHVlIGNoYW5nZXMuXG4gICAqIEB0ZW1wbGF0ZSBUVmFsdWUgVGhlIHZhbHVlIHR5cGUuIEl0IHdpbGwgYmUgdGhlIHNhbWUgdHlwZSBhcyBgdmFsdWVgIG9yIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAdGVtcGxhdGUgVEVycm9yIFRoZSB2YWxpZGF0aW9uIGVycm9yIHR5cGUuIEl0IHdpbGwgYmUgZWl0aGVyIGBzdHJpbmdgIG9yIGEgYG51bGxgLiBJdCBjYW4gYmUgaW4gYFtzdGFydCwgZW5kXWAgZm9ybWF0IGluIGNhc2Ugb2YgcmFuZ2UgdmFsdWUuXG4gICAqIEBwYXJhbSB7VFZhbHVlfSB2YWx1ZSBUaGUgbmV3IHZhbHVlLlxuICAgKiBAcGFyYW0ge0ZpZWxkQ2hhbmdlSGFuZGxlckNvbnRleHQ8VEVycm9yPn0gY29udGV4dCBDb250ZXh0IGFib3V0IHRoaXMgY2hhbmdlOlxuICAgKiAtIGB2YWxpZGF0aW9uRXJyb3JgOiB2YWxpZGF0aW9uIHJlc3VsdCBvZiB0aGUgY3VycmVudCB2YWx1ZVxuICAgKiAtIGBzb3VyY2VgOiBzb3VyY2Ugb2YgdGhlIGNoYW5nZS4gT25lIG9mICdmaWVsZCcgfCAndmlldycgfCAndW5rbm93bidcbiAgICogLSBgc2hvcnRjdXRgIChvcHRpb25hbCk6IHRoZSBzaG9ydGN1dCBtZXRhZGF0YSBpZiB0aGUgY2hhbmdlIHdhcyB0cmlnZ2VyZWQgYnkgYSBzaG9ydGN1dCBzZWxlY3Rpb25cbiAgICovXG4gIG9uQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gY29tcG9uZW50IHJlcXVlc3RzIHRvIGJlIGNsb3NlZC5cbiAgICogQ2FuIGJlIGZpcmVkIHdoZW4gc2VsZWN0aW5nIChieSBkZWZhdWx0IG9uIGBkZXNrdG9wYCBtb2RlKSBvciBjbGVhcmluZyBhIHZhbHVlLlxuICAgKiBAZGVwcmVjYXRlZCBQbGVhc2UgYXZvaWQgdXNpbmcgYXMgaXQgd2lsbCBiZSByZW1vdmVkIGluIG5leHQgbWFqb3IgdmVyc2lvbi5cbiAgICovXG4gIG9uQ2xvc2U6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogQ2FsbGJhY2sgZmlyZWQgd2hlbiB0aGUgZXJyb3IgYXNzb2NpYXRlZCB3aXRoIHRoZSBjdXJyZW50IHZhbHVlIGNoYW5nZXMuXG4gICAqIFdoZW4gYSB2YWxpZGF0aW9uIGVycm9yIGlzIGRldGVjdGVkLCB0aGUgYGVycm9yYCBwYXJhbWV0ZXIgY29udGFpbnMgYSBub24tbnVsbCB2YWx1ZS5cbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byByZW5kZXIgYW4gYXBwcm9wcmlhdGUgZm9ybSBlcnJvci5cbiAgICogQHRlbXBsYXRlIFRFcnJvciBUaGUgdmFsaWRhdGlvbiBlcnJvciB0eXBlLiBJdCB3aWxsIGJlIGVpdGhlciBgc3RyaW5nYCBvciBhIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAdGVtcGxhdGUgVFZhbHVlIFRoZSB2YWx1ZSB0eXBlLiBJdCB3aWxsIGJlIHRoZSBzYW1lIHR5cGUgYXMgYHZhbHVlYCBvciBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHBhcmFtIHtURXJyb3J9IGVycm9yIFRoZSByZWFzb24gd2h5IHRoZSBjdXJyZW50IHZhbHVlIGlzIG5vdCB2YWxpZC5cbiAgICogQHBhcmFtIHtUVmFsdWV9IHZhbHVlIFRoZSB2YWx1ZSBhc3NvY2lhdGVkIHdpdGggdGhlIGVycm9yLlxuICAgKi9cbiAgb25FcnJvcjogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCBvbiBtb250aCBjaGFuZ2UuXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSBtb250aCBUaGUgbmV3IG1vbnRoLlxuICAgKi9cbiAgb25Nb250aENoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCBvbiB2aWV3IGNoYW5nZS5cbiAgICogQHRlbXBsYXRlIFRWaWV3IFR5cGUgb2YgdGhlIHZpZXcuIEl0IHdpbGwgdmFyeSBiYXNlZCBvbiB0aGUgUGlja2VyIHR5cGUgYW5kIHRoZSBgdmlld3NgIGl0IHVzZXMuXG4gICAqIEBwYXJhbSB7VFZpZXd9IHZpZXcgVGhlIG5ldyB2aWV3LlxuICAgKi9cbiAgb25WaWV3Q2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIG9uIHllYXIgY2hhbmdlLlxuICAgKiBAcGFyYW0ge1BpY2tlclZhbGlkRGF0ZX0geWVhciBUaGUgbmV3IHllYXIuXG4gICAqL1xuICBvblllYXJDaGFuZ2U6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogVGhlIGRlZmF1bHQgdmlzaWJsZSB2aWV3LlxuICAgKiBVc2VkIHdoZW4gdGhlIGNvbXBvbmVudCB2aWV3IGlzIG5vdCBjb250cm9sbGVkLlxuICAgKiBNdXN0IGJlIGEgdmFsaWQgb3B0aW9uIGZyb20gYHZpZXdzYCBsaXN0LlxuICAgKi9cbiAgb3BlblRvOiBQcm9wVHlwZXMub25lT2YoWydkYXknLCAnbW9udGgnLCAneWVhciddKSxcbiAgLyoqXG4gICAqIEZvcmNlIHJlbmRlcmluZyBpbiBwYXJ0aWN1bGFyIG9yaWVudGF0aW9uLlxuICAgKi9cbiAgb3JpZW50YXRpb246IFByb3BUeXBlcy5vbmVPZihbJ2xhbmRzY2FwZScsICdwb3J0cmFpdCddKSxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgdGhlIGNvbXBvbmVudCBpcyByZWFkLW9ubHkuXG4gICAqIFdoZW4gcmVhZC1vbmx5LCB0aGUgdmFsdWUgY2Fubm90IGJlIGNoYW5nZWQgYnV0IHRoZSB1c2VyIGNhbiBpbnRlcmFjdCB3aXRoIHRoZSBpbnRlcmZhY2UuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICByZWFkT25seTogUHJvcFR5cGVzLmJvb2wsXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIGRpc2FibGUgaGVhdnkgYW5pbWF0aW9ucy5cbiAgICogQGRlZmF1bHQgYEBtZWRpYShwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpYCB8fCBgbmF2aWdhdG9yLnVzZXJBZ2VudGAgbWF0Y2hlcyBBbmRyb2lkIDwxMCBvciBpT1MgPDEzXG4gICAqL1xuICByZWR1Y2VBbmltYXRpb25zOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIFRoZSBkYXRlIHVzZWQgdG8gZ2VuZXJhdGUgdGhlIG5ldyB2YWx1ZSB3aGVuIGJvdGggYHZhbHVlYCBhbmQgYGRlZmF1bHRWYWx1ZWAgYXJlIGVtcHR5LlxuICAgKiBAZGVmYXVsdCBUaGUgY2xvc2VzdCB2YWxpZCBkYXRlLXRpbWUgdXNpbmcgdGhlIHZhbGlkYXRpb24gcHJvcHMsIGV4Y2VwdCBjYWxsYmFja3MgbGlrZSBgc2hvdWxkRGlzYWJsZTwuLi4+YC5cbiAgICovXG4gIHJlZmVyZW5jZURhdGU6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBDb21wb25lbnQgZGlzcGxheWluZyB3aGVuIHBhc3NlZCBgbG9hZGluZ2AgdHJ1ZS5cbiAgICogQHJldHVybnMge1JlYWN0LlJlYWN0Tm9kZX0gVGhlIG5vZGUgdG8gcmVuZGVyIHdoZW4gbG9hZGluZy5cbiAgICogQGRlZmF1bHQgKCkgPT4gPHNwYW4+4oCmPC9zcGFuPlxuICAgKi9cbiAgcmVuZGVyTG9hZGluZzogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBEaXNhYmxlIHNwZWNpZmljIGRhdGUuXG4gICAqXG4gICAqIFdhcm5pbmc6IFRoaXMgZnVuY3Rpb24gY2FuIGJlIGNhbGxlZCBtdWx0aXBsZSB0aW1lcyAoZm9yIGV4YW1wbGUgd2hlbiByZW5kZXJpbmcgZGF0ZSBjYWxlbmRhciwgY2hlY2tpbmcgaWYgZm9jdXMgY2FuIGJlIG1vdmVkIHRvIGEgY2VydGFpbiBkYXRlLCBldGMuKS4gRXhwZW5zaXZlIGNvbXB1dGF0aW9ucyBjYW4gaW1wYWN0IHBlcmZvcm1hbmNlLlxuICAgKlxuICAgKiBAcGFyYW0ge1BpY2tlclZhbGlkRGF0ZX0gZGF5IFRoZSBkYXRlIHRvIHRlc3QuXG4gICAqIEByZXR1cm5zIHtib29sZWFufSBJZiBgdHJ1ZWAgdGhlIGRhdGUgd2lsbCBiZSBkaXNhYmxlZC5cbiAgICovXG4gIHNob3VsZERpc2FibGVEYXRlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIERpc2FibGUgc3BlY2lmaWMgbW9udGguXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSBtb250aCBUaGUgbW9udGggdG8gdGVzdC5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IElmIGB0cnVlYCwgdGhlIG1vbnRoIHdpbGwgYmUgZGlzYWJsZWQuXG4gICAqL1xuICBzaG91bGREaXNhYmxlTW9udGg6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogRGlzYWJsZSBzcGVjaWZpYyB5ZWFyLlxuICAgKiBAcGFyYW0ge1BpY2tlclZhbGlkRGF0ZX0geWVhciBUaGUgeWVhciB0byB0ZXN0LlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gSWYgYHRydWVgLCB0aGUgeWVhciB3aWxsIGJlIGRpc2FibGVkLlxuICAgKi9cbiAgc2hvdWxkRGlzYWJsZVllYXI6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBkYXlzIG91dHNpZGUgdGhlIGN1cnJlbnQgbW9udGggYXJlIHJlbmRlcmVkOlxuICAgKlxuICAgKiAtIGlmIGBmaXhlZFdlZWtOdW1iZXJgIGlzIGRlZmluZWQsIHJlbmRlcnMgZGF5cyB0byBoYXZlIHRoZSB3ZWVrcyByZXF1ZXN0ZWQuXG4gICAqXG4gICAqIC0gaWYgYGZpeGVkV2Vla051bWJlcmAgaXMgbm90IGRlZmluZWQsIHJlbmRlcnMgZGF5IHRvIGZpbGwgdGhlIGZpcnN0IGFuZCBsYXN0IHdlZWsgb2YgdGhlIGN1cnJlbnQgbW9udGguXG4gICAqXG4gICAqIC0gaWdub3JlZCBpZiBgY2FsZW5kYXJzYCBlcXVhbHMgbW9yZSB0aGFuIGAxYCBvbiByYW5nZSBwaWNrZXJzLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgc2hvd0RheXNPdXRzaWRlQ3VycmVudE1vbnRoOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIFRoZSBwcm9wcyB1c2VkIGZvciBlYWNoIGNvbXBvbmVudCBzbG90LlxuICAgKiBAZGVmYXVsdCB7fVxuICAgKi9cbiAgc2xvdFByb3BzOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogT3ZlcnJpZGFibGUgY29tcG9uZW50IHNsb3RzLlxuICAgKiBAZGVmYXVsdCB7fVxuICAgKi9cbiAgc2xvdHM6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBUaGUgc3lzdGVtIHByb3AgdGhhdCBhbGxvd3MgZGVmaW5pbmcgc3lzdGVtIG92ZXJyaWRlcyBhcyB3ZWxsIGFzIGFkZGl0aW9uYWwgQ1NTIHN0eWxlcy5cbiAgICovXG4gIHN4OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuZnVuYywgUHJvcFR5cGVzLm9iamVjdCwgUHJvcFR5cGVzLmJvb2xdKSksIFByb3BUeXBlcy5mdW5jLCBQcm9wVHlwZXMub2JqZWN0XSksXG4gIC8qKlxuICAgKiBDaG9vc2Ugd2hpY2ggdGltZXpvbmUgdG8gdXNlIGZvciB0aGUgdmFsdWUuXG4gICAqIEV4YW1wbGU6IFwiZGVmYXVsdFwiLCBcInN5c3RlbVwiLCBcIlVUQ1wiLCBcIkFtZXJpY2EvTmV3X1lvcmtcIi5cbiAgICogSWYgeW91IHBhc3MgdmFsdWVzIGZyb20gb3RoZXIgdGltZXpvbmVzIHRvIHNvbWUgcHJvcHMsIHRoZXkgd2lsbCBiZSBjb252ZXJ0ZWQgdG8gdGhpcyB0aW1lem9uZSBiZWZvcmUgYmVpbmcgdXNlZC5cbiAgICogQHNlZSBTZWUgdGhlIHtAbGluayBodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvdGltZXpvbmUvIHRpbWV6b25lcyBkb2N1bWVudGF0aW9ufSBmb3IgbW9yZSBkZXRhaWxzLlxuICAgKiBAZGVmYXVsdCBUaGUgdGltZXpvbmUgb2YgdGhlIGB2YWx1ZWAgb3IgYGRlZmF1bHRWYWx1ZWAgcHJvcCBpcyBkZWZpbmVkLCAnZGVmYXVsdCcgb3RoZXJ3aXNlLlxuICAgKi9cbiAgdGltZXpvbmU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIC8qKlxuICAgKiBUaGUgc2VsZWN0ZWQgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIGNvbnRyb2xsZWQuXG4gICAqL1xuICB2YWx1ZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIFRoZSB2aXNpYmxlIHZpZXcuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IHZpZXcgaXMgY29udHJvbGxlZC5cbiAgICogTXVzdCBiZSBhIHZhbGlkIG9wdGlvbiBmcm9tIGB2aWV3c2AgbGlzdC5cbiAgICovXG4gIHZpZXc6IFByb3BUeXBlcy5vbmVPZihbJ2RheScsICdtb250aCcsICd5ZWFyJ10pLFxuICAvKipcbiAgICogRGVmaW5lIGN1c3RvbSB2aWV3IHJlbmRlcmVycyBmb3IgZWFjaCBzZWN0aW9uLlxuICAgKiBJZiBgbnVsbGAsIHRoZSBzZWN0aW9uIHdpbGwgb25seSBoYXZlIGZpZWxkIGVkaXRpbmcuXG4gICAqIElmIGB1bmRlZmluZWRgLCBpbnRlcm5hbGx5IGRlZmluZWQgdmlldyB3aWxsIGJlIHVzZWQuXG4gICAqL1xuICB2aWV3UmVuZGVyZXJzOiBQcm9wVHlwZXMuc2hhcGUoe1xuICAgIGRheTogUHJvcFR5cGVzLmZ1bmMsXG4gICAgbW9udGg6IFByb3BUeXBlcy5mdW5jLFxuICAgIHllYXI6IFByb3BUeXBlcy5mdW5jXG4gIH0pLFxuICAvKipcbiAgICogQXZhaWxhYmxlIHZpZXdzLlxuICAgKi9cbiAgdmlld3M6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5vbmVPZihbJ2RheScsICdtb250aCcsICd5ZWFyJ10pLmlzUmVxdWlyZWQpLFxuICAvKipcbiAgICogWWVhcnMgYXJlIGRpc3BsYXllZCBpbiBhc2NlbmRpbmcgKGNocm9ub2xvZ2ljYWwpIG9yZGVyIGJ5IGRlZmF1bHQuXG4gICAqIElmIGBkZXNjYCwgeWVhcnMgYXJlIGRpc3BsYXllZCBpbiBkZXNjZW5kaW5nIG9yZGVyLlxuICAgKiBAZGVmYXVsdCAnYXNjJ1xuICAgKi9cbiAgeWVhcnNPcmRlcjogUHJvcFR5cGVzLm9uZU9mKFsnYXNjJywgJ2Rlc2MnXSksXG4gIC8qKlxuICAgKiBZZWFycyByZW5kZXJlZCBwZXIgcm93LlxuICAgKiBAZGVmYXVsdCBgNGAgd2hlbiBgZGlzcGxheVN0YXRpY1dyYXBwZXJBcyA9PT0gJ2Rlc2t0b3AnYCwgYDNgIG90aGVyd2lzZS5cbiAgICovXG4gIHllYXJzUGVyUm93OiBQcm9wVHlwZXMub25lT2YoWzMsIDRdKVxufSA6IHZvaWQgMDtcbmV4cG9ydCB7IFN0YXRpY0RhdGVQaWNrZXIgfTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZXh0ZW5kcyBmcm9tIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZXh0ZW5kc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IHVzZVRpbWVQaWNrZXJEZWZhdWx0aXplZFByb3BzIH0gZnJvbSBcIi4uL1RpbWVQaWNrZXIvc2hhcmVkLm1qc1wiO1xuaW1wb3J0IHsgcmVuZGVyVGltZVZpZXdDbG9jayB9IGZyb20gXCIuLi90aW1lVmlld1JlbmRlcmVycy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHNpbmdsZUl0ZW1WYWx1ZU1hbmFnZXIgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3V0aWxzL3ZhbHVlTWFuYWdlcnMubWpzXCI7XG5pbXBvcnQgeyB1c2VTdGF0aWNQaWNrZXIgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL2hvb2tzL3VzZVN0YXRpY1BpY2tlci9pbmRleC5tanNcIjtcbmltcG9ydCB7IHZhbGlkYXRlVGltZSB9IGZyb20gXCIuLi92YWxpZGF0aW9uL2luZGV4Lm1qc1wiO1xuLyoqXG4gKiBEZW1vczpcbiAqXG4gKiAtIFtUaW1lUGlja2VyXShodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvdGltZS1waWNrZXIvKVxuICogLSBbVmFsaWRhdGlvbl0oaHR0cHM6Ly9tdWkuY29tL3gvcmVhY3QtZGF0ZS1waWNrZXJzL3ZhbGlkYXRpb24vKVxuICpcbiAqIEFQSTpcbiAqXG4gKiAtIFtTdGF0aWNUaW1lUGlja2VyIEFQSV0oaHR0cHM6Ly9tdWkuY29tL3gvYXBpL2RhdGUtcGlja2Vycy9zdGF0aWMtdGltZS1waWNrZXIvKVxuICovXG5jb25zdCBTdGF0aWNUaW1lUGlja2VyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU3RhdGljVGltZVBpY2tlcihpblByb3BzLCByZWYpIHtcbiAgY29uc3QgZGVmYXVsdGl6ZWRQcm9wcyA9IHVzZVRpbWVQaWNrZXJEZWZhdWx0aXplZFByb3BzKGluUHJvcHMsICdNdWlTdGF0aWNUaW1lUGlja2VyJyk7XG4gIGNvbnN0IGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPSBkZWZhdWx0aXplZFByb3BzLmRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPz8gJ21vYmlsZSc7XG4gIGNvbnN0IGFtcG1JbkNsb2NrID0gZGVmYXVsdGl6ZWRQcm9wcy5hbXBtSW5DbG9jayA/PyBkaXNwbGF5U3RhdGljV3JhcHBlckFzID09PSAnZGVza3RvcCc7XG4gIGNvbnN0IHZpZXdSZW5kZXJlcnMgPSBfZXh0ZW5kcyh7XG4gICAgaG91cnM6IHJlbmRlclRpbWVWaWV3Q2xvY2ssXG4gICAgbWludXRlczogcmVuZGVyVGltZVZpZXdDbG9jayxcbiAgICBzZWNvbmRzOiByZW5kZXJUaW1lVmlld0Nsb2NrXG4gIH0sIGRlZmF1bHRpemVkUHJvcHMudmlld1JlbmRlcmVycyk7XG5cbiAgLy8gUHJvcHMgd2l0aCB0aGUgZGVmYXVsdCB2YWx1ZXMgc3BlY2lmaWMgdG8gdGhlIHN0YXRpYyB2YXJpYW50XG4gIGNvbnN0IHByb3BzID0gX2V4dGVuZHMoe30sIGRlZmF1bHRpemVkUHJvcHMsIHtcbiAgICB2aWV3UmVuZGVyZXJzLFxuICAgIGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMsXG4gICAgYW1wbUluQ2xvY2ssXG4gICAgc2xvdFByb3BzOiBfZXh0ZW5kcyh7fSwgZGVmYXVsdGl6ZWRQcm9wcy5zbG90UHJvcHMsIHtcbiAgICAgIHRvb2xiYXI6IF9leHRlbmRzKHtcbiAgICAgICAgaGlkZGVuOiBkaXNwbGF5U3RhdGljV3JhcHBlckFzID09PSAnZGVza3RvcCcsXG4gICAgICAgIGFtcG1JbkNsb2NrXG4gICAgICB9LCBkZWZhdWx0aXplZFByb3BzLnNsb3RQcm9wcz8udG9vbGJhcilcbiAgICB9KVxuICB9KTtcbiAgY29uc3Qge1xuICAgIHJlbmRlclBpY2tlclxuICB9ID0gdXNlU3RhdGljUGlja2VyKHtcbiAgICByZWYsXG4gICAgcHJvcHMsXG4gICAgdmFsdWVNYW5hZ2VyOiBzaW5nbGVJdGVtVmFsdWVNYW5hZ2VyLFxuICAgIHZhbHVlVHlwZTogJ3RpbWUnLFxuICAgIHZhbGlkYXRvcjogdmFsaWRhdGVUaW1lLFxuICAgIHN0ZXBzOiBudWxsXG4gIH0pO1xuICByZXR1cm4gcmVuZGVyUGlja2VyKCk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFN0YXRpY1RpbWVQaWNrZXIuZGlzcGxheU5hbWUgPSBcIlN0YXRpY1RpbWVQaWNrZXJcIjtcbnByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFN0YXRpY1RpbWVQaWNrZXIucHJvcFR5cGVzIC8qIHJlbW92ZS1wcm9wdHlwZXMgKi8gPSB7XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFdhcm5pbmcgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gfCBUaGVzZSBQcm9wVHlwZXMgYXJlIGdlbmVyYXRlZCBmcm9tIHRoZSBUeXBlU2NyaXB0IHR5cGUgZGVmaW5pdGlvbnMgfFxuICAvLyB8IFRvIHVwZGF0ZSB0aGVtIGVkaXQgdGhlIFR5cGVTY3JpcHQgdHlwZXMgYW5kIHJ1biBcInBucG0gcHJvcHR5cGVzXCIgIHxcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogMTJoLzI0aCB2aWV3IGZvciBob3VyIHNlbGVjdGlvbiBjbG9jay5cbiAgICogQGRlZmF1bHQgYWRhcHRlci5pczEySG91ckN5Y2xlSW5DdXJyZW50TG9jYWxlKClcbiAgICovXG4gIGFtcG06IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogRGlzcGxheSBhbXBtIGNvbnRyb2xzIHVuZGVyIHRoZSBjbG9jayAoaW5zdGVhZCBvZiBpbiB0aGUgdG9vbGJhcikuXG4gICAqIEBkZWZhdWx0IHRydWUgb24gZGVza3RvcCwgZmFsc2Ugb24gbW9iaWxlXG4gICAqL1xuICBhbXBtSW5DbG9jazogUHJvcFR5cGVzLmJvb2wsXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSBtYWluIGVsZW1lbnQgaXMgZm9jdXNlZCBkdXJpbmcgdGhlIGZpcnN0IG1vdW50LlxuICAgKiBUaGlzIG1haW4gZWxlbWVudCBpczpcbiAgICogLSB0aGUgZWxlbWVudCBjaG9zZW4gYnkgdGhlIHZpc2libGUgdmlldyBpZiBhbnkgKGkuZTogdGhlIHNlbGVjdGVkIGRheSBvbiB0aGUgYGRheWAgdmlldykuXG4gICAqIC0gdGhlIGBpbnB1dGAgZWxlbWVudCBpZiB0aGVyZSBpcyBhIGZpZWxkIHJlbmRlcmVkLlxuICAgKi9cbiAgYXV0b0ZvY3VzOiBQcm9wVHlwZXMuYm9vbCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAvKipcbiAgICogVGhlIGRlZmF1bHQgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIG5vdCBjb250cm9sbGVkLlxuICAgKi9cbiAgZGVmYXVsdFZhbHVlOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogSWYgYHRydWVgLCB0aGUgY29tcG9uZW50IGlzIGRpc2FibGVkLlxuICAgKiBXaGVuIGRpc2FibGVkLCB0aGUgdmFsdWUgY2Fubm90IGJlIGNoYW5nZWQgYW5kIG5vIGludGVyYWN0aW9uIGlzIHBvc3NpYmxlLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZWQ6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBkaXNhYmxlIHZhbHVlcyBhZnRlciB0aGUgY3VycmVudCBkYXRlIGZvciBkYXRlIGNvbXBvbmVudHMsIHRpbWUgZm9yIHRpbWUgY29tcG9uZW50cyBhbmQgYm90aCBmb3IgZGF0ZSB0aW1lIGNvbXBvbmVudHMuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBkaXNhYmxlRnV0dXJlOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIERvIG5vdCBpZ25vcmUgZGF0ZSBwYXJ0IHdoZW4gdmFsaWRhdGluZyBtaW4vbWF4IHRpbWUuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBkaXNhYmxlSWdub3JpbmdEYXRlUGFydEZvclRpbWVWYWxpZGF0aW9uOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZSB2YWx1ZXMgYmVmb3JlIHRoZSBjdXJyZW50IGRhdGUgZm9yIGRhdGUgY29tcG9uZW50cywgdGltZSBmb3IgdGltZSBjb21wb25lbnRzIGFuZCBib3RoIGZvciBkYXRlIHRpbWUgY29tcG9uZW50cy5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGRpc2FibGVQYXN0OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIEZvcmNlIHN0YXRpYyB3cmFwcGVyIGlubmVyIGNvbXBvbmVudHMgdG8gYmUgcmVuZGVyZWQgaW4gbW9iaWxlIG9yIGRlc2t0b3AgbW9kZS5cbiAgICogQGRlZmF1bHQgXCJtb2JpbGVcIlxuICAgKi9cbiAgZGlzcGxheVN0YXRpY1dyYXBwZXJBczogUHJvcFR5cGVzLm9uZU9mKFsnZGVza3RvcCcsICdtb2JpbGUnXSksXG4gIC8qKlxuICAgKiBMb2NhbGUgZm9yIGNvbXBvbmVudHMgdGV4dHMuXG4gICAqIEFsbG93cyBvdmVycmlkaW5nIHRleHRzIGNvbWluZyBmcm9tIGBMb2NhbGl6YXRpb25Qcm92aWRlcmAgYW5kIGB0aGVtZWAuXG4gICAqL1xuICBsb2NhbGVUZXh0OiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogTWF4aW1hbCBzZWxlY3RhYmxlIHRpbWUuXG4gICAqIFRoZSBkYXRlIHBhcnQgb2YgdGhlIG9iamVjdCB3aWxsIGJlIGlnbm9yZWQgdW5sZXNzIGBwcm9wcy5kaXNhYmxlSWdub3JpbmdEYXRlUGFydEZvclRpbWVWYWxpZGF0aW9uID09PSB0cnVlYC5cbiAgICovXG4gIG1heFRpbWU6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBNaW5pbWFsIHNlbGVjdGFibGUgdGltZS5cbiAgICogVGhlIGRhdGUgcGFydCBvZiB0aGUgb2JqZWN0IHdpbGwgYmUgaWdub3JlZCB1bmxlc3MgYHByb3BzLmRpc2FibGVJZ25vcmluZ0RhdGVQYXJ0Rm9yVGltZVZhbGlkYXRpb24gPT09IHRydWVgLlxuICAgKi9cbiAgbWluVGltZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIFN0ZXAgb3ZlciBtaW51dGVzLlxuICAgKiBAZGVmYXVsdCAxXG4gICAqL1xuICBtaW51dGVzU3RlcDogUHJvcFR5cGVzLm51bWJlcixcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gdGhlIHZhbHVlIGlzIGFjY2VwdGVkLlxuICAgKiBAdGVtcGxhdGUgVFZhbHVlIFRoZSB2YWx1ZSB0eXBlLiBJdCB3aWxsIGJlIHRoZSBzYW1lIHR5cGUgYXMgYHZhbHVlYCBvciBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHRlbXBsYXRlIFRFcnJvciBUaGUgdmFsaWRhdGlvbiBlcnJvciB0eXBlLiBJdCB3aWxsIGJlIGVpdGhlciBgc3RyaW5nYCBvciBhIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAcGFyYW0ge1RWYWx1ZX0gdmFsdWUgVGhlIHZhbHVlIHRoYXQgd2FzIGp1c3QgYWNjZXB0ZWQuXG4gICAqIEBwYXJhbSB7RmllbGRDaGFuZ2VIYW5kbGVyQ29udGV4dDxURXJyb3I+fSBjb250ZXh0IENvbnRleHQgYWJvdXQgdGhpcyBhY2NlcHRhbmNlOlxuICAgKiAtIGB2YWxpZGF0aW9uRXJyb3JgOiB2YWxpZGF0aW9uIHJlc3VsdCBvZiB0aGUgY3VycmVudCB2YWx1ZVxuICAgKiAtIGBzb3VyY2VgOiBzb3VyY2Ugb2YgdGhlIGFjY2VwdGFuY2UuIE9uZSBvZiAnZmllbGQnIHwgJ3ZpZXcnIHwgJ3Vua25vd24nXG4gICAqIC0gYHNob3J0Y3V0YCAob3B0aW9uYWwpOiB0aGUgc2hvcnRjdXQgbWV0YWRhdGEgaWYgdGhlIHZhbHVlIHdhcyBhY2NlcHRlZCB2aWEgYSBzaG9ydGN1dCBzZWxlY3Rpb25cbiAgICovXG4gIG9uQWNjZXB0OiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gdGhlIHZhbHVlIGNoYW5nZXMuXG4gICAqIEB0ZW1wbGF0ZSBUVmFsdWUgVGhlIHZhbHVlIHR5cGUuIEl0IHdpbGwgYmUgdGhlIHNhbWUgdHlwZSBhcyBgdmFsdWVgIG9yIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAdGVtcGxhdGUgVEVycm9yIFRoZSB2YWxpZGF0aW9uIGVycm9yIHR5cGUuIEl0IHdpbGwgYmUgZWl0aGVyIGBzdHJpbmdgIG9yIGEgYG51bGxgLiBJdCBjYW4gYmUgaW4gYFtzdGFydCwgZW5kXWAgZm9ybWF0IGluIGNhc2Ugb2YgcmFuZ2UgdmFsdWUuXG4gICAqIEBwYXJhbSB7VFZhbHVlfSB2YWx1ZSBUaGUgbmV3IHZhbHVlLlxuICAgKiBAcGFyYW0ge0ZpZWxkQ2hhbmdlSGFuZGxlckNvbnRleHQ8VEVycm9yPn0gY29udGV4dCBDb250ZXh0IGFib3V0IHRoaXMgY2hhbmdlOlxuICAgKiAtIGB2YWxpZGF0aW9uRXJyb3JgOiB2YWxpZGF0aW9uIHJlc3VsdCBvZiB0aGUgY3VycmVudCB2YWx1ZVxuICAgKiAtIGBzb3VyY2VgOiBzb3VyY2Ugb2YgdGhlIGNoYW5nZS4gT25lIG9mICdmaWVsZCcgfCAndmlldycgfCAndW5rbm93bidcbiAgICogLSBgc2hvcnRjdXRgIChvcHRpb25hbCk6IHRoZSBzaG9ydGN1dCBtZXRhZGF0YSBpZiB0aGUgY2hhbmdlIHdhcyB0cmlnZ2VyZWQgYnkgYSBzaG9ydGN1dCBzZWxlY3Rpb25cbiAgICovXG4gIG9uQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gY29tcG9uZW50IHJlcXVlc3RzIHRvIGJlIGNsb3NlZC5cbiAgICogQ2FuIGJlIGZpcmVkIHdoZW4gc2VsZWN0aW5nIChieSBkZWZhdWx0IG9uIGBkZXNrdG9wYCBtb2RlKSBvciBjbGVhcmluZyBhIHZhbHVlLlxuICAgKiBAZGVwcmVjYXRlZCBQbGVhc2UgYXZvaWQgdXNpbmcgYXMgaXQgd2lsbCBiZSByZW1vdmVkIGluIG5leHQgbWFqb3IgdmVyc2lvbi5cbiAgICovXG4gIG9uQ2xvc2U6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogQ2FsbGJhY2sgZmlyZWQgd2hlbiB0aGUgZXJyb3IgYXNzb2NpYXRlZCB3aXRoIHRoZSBjdXJyZW50IHZhbHVlIGNoYW5nZXMuXG4gICAqIFdoZW4gYSB2YWxpZGF0aW9uIGVycm9yIGlzIGRldGVjdGVkLCB0aGUgYGVycm9yYCBwYXJhbWV0ZXIgY29udGFpbnMgYSBub24tbnVsbCB2YWx1ZS5cbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byByZW5kZXIgYW4gYXBwcm9wcmlhdGUgZm9ybSBlcnJvci5cbiAgICogQHRlbXBsYXRlIFRFcnJvciBUaGUgdmFsaWRhdGlvbiBlcnJvciB0eXBlLiBJdCB3aWxsIGJlIGVpdGhlciBgc3RyaW5nYCBvciBhIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAdGVtcGxhdGUgVFZhbHVlIFRoZSB2YWx1ZSB0eXBlLiBJdCB3aWxsIGJlIHRoZSBzYW1lIHR5cGUgYXMgYHZhbHVlYCBvciBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHBhcmFtIHtURXJyb3J9IGVycm9yIFRoZSByZWFzb24gd2h5IHRoZSBjdXJyZW50IHZhbHVlIGlzIG5vdCB2YWxpZC5cbiAgICogQHBhcmFtIHtUVmFsdWV9IHZhbHVlIFRoZSB2YWx1ZSBhc3NvY2lhdGVkIHdpdGggdGhlIGVycm9yLlxuICAgKi9cbiAgb25FcnJvcjogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCBvbiB2aWV3IGNoYW5nZS5cbiAgICogQHRlbXBsYXRlIFRWaWV3IFR5cGUgb2YgdGhlIHZpZXcuIEl0IHdpbGwgdmFyeSBiYXNlZCBvbiB0aGUgUGlja2VyIHR5cGUgYW5kIHRoZSBgdmlld3NgIGl0IHVzZXMuXG4gICAqIEBwYXJhbSB7VFZpZXd9IHZpZXcgVGhlIG5ldyB2aWV3LlxuICAgKi9cbiAgb25WaWV3Q2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIFRoZSBkZWZhdWx0IHZpc2libGUgdmlldy5cbiAgICogVXNlZCB3aGVuIHRoZSBjb21wb25lbnQgdmlldyBpcyBub3QgY29udHJvbGxlZC5cbiAgICogTXVzdCBiZSBhIHZhbGlkIG9wdGlvbiBmcm9tIGB2aWV3c2AgbGlzdC5cbiAgICovXG4gIG9wZW5UbzogUHJvcFR5cGVzLm9uZU9mKFsnaG91cnMnLCAnbWludXRlcycsICdzZWNvbmRzJ10pLFxuICAvKipcbiAgICogRm9yY2UgcmVuZGVyaW5nIGluIHBhcnRpY3VsYXIgb3JpZW50YXRpb24uXG4gICAqL1xuICBvcmllbnRhdGlvbjogUHJvcFR5cGVzLm9uZU9mKFsnbGFuZHNjYXBlJywgJ3BvcnRyYWl0J10pLFxuICAvKipcbiAgICogSWYgYHRydWVgLCB0aGUgY29tcG9uZW50IGlzIHJlYWQtb25seS5cbiAgICogV2hlbiByZWFkLW9ubHksIHRoZSB2YWx1ZSBjYW5ub3QgYmUgY2hhbmdlZCBidXQgdGhlIHVzZXIgY2FuIGludGVyYWN0IHdpdGggdGhlIGludGVyZmFjZS5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRPbmx5OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZSBoZWF2eSBhbmltYXRpb25zLlxuICAgKiBAZGVmYXVsdCBgQG1lZGlhKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSlgIHx8IGBuYXZpZ2F0b3IudXNlckFnZW50YCBtYXRjaGVzIEFuZHJvaWQgPDEwIG9yIGlPUyA8MTNcbiAgICovXG4gIHJlZHVjZUFuaW1hdGlvbnM6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogVGhlIGRhdGUgdXNlZCB0byBnZW5lcmF0ZSB0aGUgbmV3IHZhbHVlIHdoZW4gYm90aCBgdmFsdWVgIGFuZCBgZGVmYXVsdFZhbHVlYCBhcmUgZW1wdHkuXG4gICAqIEBkZWZhdWx0IFRoZSBjbG9zZXN0IHZhbGlkIGRhdGUtdGltZSB1c2luZyB0aGUgdmFsaWRhdGlvbiBwcm9wcywgZXhjZXB0IGNhbGxiYWNrcyBsaWtlIGBzaG91bGREaXNhYmxlPC4uLj5gLlxuICAgKi9cbiAgcmVmZXJlbmNlRGF0ZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIERpc2FibGUgc3BlY2lmaWMgdGltZS5cbiAgICogQHBhcmFtIHtQaWNrZXJWYWxpZERhdGV9IHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiAgICogQHBhcmFtIHtUaW1lVmlld30gdmlldyBUaGUgY2xvY2sgdHlwZSBvZiB0aGUgdGltZVZhbHVlLlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gSWYgYHRydWVgIHRoZSB0aW1lIHdpbGwgYmUgZGlzYWJsZWQuXG4gICAqL1xuICBzaG91bGREaXNhYmxlVGltZTogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBUaGUgcHJvcHMgdXNlZCBmb3IgZWFjaCBjb21wb25lbnQgc2xvdC5cbiAgICogQGRlZmF1bHQge31cbiAgICovXG4gIHNsb3RQcm9wczogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE92ZXJyaWRhYmxlIGNvbXBvbmVudCBzbG90cy5cbiAgICogQGRlZmF1bHQge31cbiAgICovXG4gIHNsb3RzOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogVGhlIHN5c3RlbSBwcm9wIHRoYXQgYWxsb3dzIGRlZmluaW5nIHN5c3RlbSBvdmVycmlkZXMgYXMgd2VsbCBhcyBhZGRpdGlvbmFsIENTUyBzdHlsZXMuXG4gICAqL1xuICBzeDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLmFycmF5T2YoUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLmZ1bmMsIFByb3BUeXBlcy5vYmplY3QsIFByb3BUeXBlcy5ib29sXSkpLCBQcm9wVHlwZXMuZnVuYywgUHJvcFR5cGVzLm9iamVjdF0pLFxuICAvKipcbiAgICogQ2hvb3NlIHdoaWNoIHRpbWV6b25lIHRvIHVzZSBmb3IgdGhlIHZhbHVlLlxuICAgKiBFeGFtcGxlOiBcImRlZmF1bHRcIiwgXCJzeXN0ZW1cIiwgXCJVVENcIiwgXCJBbWVyaWNhL05ld19Zb3JrXCIuXG4gICAqIElmIHlvdSBwYXNzIHZhbHVlcyBmcm9tIG90aGVyIHRpbWV6b25lcyB0byBzb21lIHByb3BzLCB0aGV5IHdpbGwgYmUgY29udmVydGVkIHRvIHRoaXMgdGltZXpvbmUgYmVmb3JlIGJlaW5nIHVzZWQuXG4gICAqIEBzZWUgU2VlIHRoZSB7QGxpbmsgaHR0cHM6Ly9tdWkuY29tL3gvcmVhY3QtZGF0ZS1waWNrZXJzL3RpbWV6b25lLyB0aW1lem9uZXMgZG9jdW1lbnRhdGlvbn0gZm9yIG1vcmUgZGV0YWlscy5cbiAgICogQGRlZmF1bHQgVGhlIHRpbWV6b25lIG9mIHRoZSBgdmFsdWVgIG9yIGBkZWZhdWx0VmFsdWVgIHByb3AgaXMgZGVmaW5lZCwgJ2RlZmF1bHQnIG90aGVyd2lzZS5cbiAgICovXG4gIHRpbWV6b25lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAvKipcbiAgICogVGhlIHNlbGVjdGVkIHZhbHVlLlxuICAgKiBVc2VkIHdoZW4gdGhlIGNvbXBvbmVudCBpcyBjb250cm9sbGVkLlxuICAgKi9cbiAgdmFsdWU6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBUaGUgdmlzaWJsZSB2aWV3LlxuICAgKiBVc2VkIHdoZW4gdGhlIGNvbXBvbmVudCB2aWV3IGlzIGNvbnRyb2xsZWQuXG4gICAqIE11c3QgYmUgYSB2YWxpZCBvcHRpb24gZnJvbSBgdmlld3NgIGxpc3QuXG4gICAqL1xuICB2aWV3OiBQcm9wVHlwZXMub25lT2YoWydob3VycycsICdtaW51dGVzJywgJ3NlY29uZHMnXSksXG4gIC8qKlxuICAgKiBEZWZpbmUgY3VzdG9tIHZpZXcgcmVuZGVyZXJzIGZvciBlYWNoIHNlY3Rpb24uXG4gICAqIElmIGBudWxsYCwgdGhlIHNlY3Rpb24gd2lsbCBvbmx5IGhhdmUgZmllbGQgZWRpdGluZy5cbiAgICogSWYgYHVuZGVmaW5lZGAsIGludGVybmFsbHkgZGVmaW5lZCB2aWV3IHdpbGwgYmUgdXNlZC5cbiAgICovXG4gIHZpZXdSZW5kZXJlcnM6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgaG91cnM6IFByb3BUeXBlcy5mdW5jLFxuICAgIG1pbnV0ZXM6IFByb3BUeXBlcy5mdW5jLFxuICAgIHNlY29uZHM6IFByb3BUeXBlcy5mdW5jXG4gIH0pLFxuICAvKipcbiAgICogQXZhaWxhYmxlIHZpZXdzLlxuICAgKi9cbiAgdmlld3M6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5vbmVPZihbJ2hvdXJzJywgJ21pbnV0ZXMnLCAnc2Vjb25kcyddKS5pc1JlcXVpcmVkKVxufSA6IHZvaWQgMDtcbmV4cG9ydCB7IFN0YXRpY1RpbWVQaWNrZXIgfTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZXh0ZW5kcyBmcm9tIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZXh0ZW5kc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IHVzZURhdGVUaW1lUGlja2VyRGVmYXVsdGl6ZWRQcm9wcyB9IGZyb20gXCIuLi9EYXRlVGltZVBpY2tlci9zaGFyZWQubWpzXCI7XG5pbXBvcnQgeyByZW5kZXJEaWdpdGFsQ2xvY2tUaW1lVmlldywgcmVuZGVyTXVsdGlTZWN0aW9uRGlnaXRhbENsb2NrVGltZVZpZXcgfSBmcm9tIFwiLi4vdGltZVZpZXdSZW5kZXJlcnMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyByZW5kZXJEYXRlVmlld0NhbGVuZGFyIH0gZnJvbSBcIi4uL2RhdGVWaWV3UmVuZGVyZXJzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgc2luZ2xlSXRlbVZhbHVlTWFuYWdlciB9IGZyb20gXCIuLi9pbnRlcm5hbHMvdXRpbHMvdmFsdWVNYW5hZ2Vycy5tanNcIjtcbmltcG9ydCB7IHVzZVN0YXRpY1BpY2tlciB9IGZyb20gXCIuLi9pbnRlcm5hbHMvaG9va3MvdXNlU3RhdGljUGlja2VyL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdmFsaWRhdGVEYXRlVGltZSB9IGZyb20gXCIuLi92YWxpZGF0aW9uL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VTeCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvdXRpbHMvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyBtdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2tDbGFzc2VzLCBtdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2tTZWN0aW9uQ2xhc3NlcyB9IGZyb20gXCIuLi9NdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2svaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBESUFMT0dfV0lEVEgsIFZJRVdfSEVJR0hUIH0gZnJvbSBcIi4uL2ludGVybmFscy9jb25zdGFudHMvZGltZW5zaW9ucy5tanNcIjtcbmltcG9ydCB7IGRpZ2l0YWxDbG9ja0NsYXNzZXMgfSBmcm9tIFwiLi4vRGlnaXRhbENsb2NrL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgREFURV9WSUVXUyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvdXRpbHMvZGF0ZS11dGlscy5tanNcIjtcbmltcG9ydCB7IEVYUE9SVEVEX1RJTUVfVklFV1MgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3V0aWxzL3RpbWUtdXRpbHMubWpzXCI7XG5jb25zdCBTVEVQUyA9IFt7XG4gIHZpZXdzOiBEQVRFX1ZJRVdTXG59LCB7XG4gIHZpZXdzOiBFWFBPUlRFRF9USU1FX1ZJRVdTXG59XTtcbi8qKlxuICogRGVtb3M6XG4gKlxuICogLSBbRGF0ZVRpbWVQaWNrZXJdKGh0dHBzOi8vbXVpLmNvbS94L3JlYWN0LWRhdGUtcGlja2Vycy9kYXRlLXRpbWUtcGlja2VyLylcbiAqIC0gW1ZhbGlkYXRpb25dKGh0dHBzOi8vbXVpLmNvbS94L3JlYWN0LWRhdGUtcGlja2Vycy92YWxpZGF0aW9uLylcbiAqXG4gKiBBUEk6XG4gKlxuICogLSBbU3RhdGljRGF0ZVRpbWVQaWNrZXIgQVBJXShodHRwczovL211aS5jb20veC9hcGkvZGF0ZS1waWNrZXJzL3N0YXRpYy1kYXRlLXRpbWUtcGlja2VyLylcbiAqL1xuY29uc3QgU3RhdGljRGF0ZVRpbWVQaWNrZXIgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTdGF0aWNEYXRlVGltZVBpY2tlcihpblByb3BzLCByZWYpIHtcbiAgY29uc3QgZGVmYXVsdGl6ZWRQcm9wcyA9IHVzZURhdGVUaW1lUGlja2VyRGVmYXVsdGl6ZWRQcm9wcyhpblByb3BzLCAnTXVpU3RhdGljRGF0ZVRpbWVQaWNrZXInKTtcbiAgY29uc3QgZGlzcGxheVN0YXRpY1dyYXBwZXJBcyA9IGRlZmF1bHRpemVkUHJvcHMuZGlzcGxheVN0YXRpY1dyYXBwZXJBcyA/PyAnbW9iaWxlJztcbiAgY29uc3QgYW1wbUluQ2xvY2sgPSBkZWZhdWx0aXplZFByb3BzLmFtcG1JbkNsb2NrID8/IGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPT09ICdkZXNrdG9wJztcbiAgY29uc3QgcmVuZGVyVGltZVZpZXcgPSBkZWZhdWx0aXplZFByb3BzLnNob3VsZFJlbmRlclRpbWVJbkFTaW5nbGVDb2x1bW4gPyByZW5kZXJEaWdpdGFsQ2xvY2tUaW1lVmlldyA6IHJlbmRlck11bHRpU2VjdGlvbkRpZ2l0YWxDbG9ja1RpbWVWaWV3O1xuICBjb25zdCB2aWV3UmVuZGVyZXJzID0gX2V4dGVuZHMoe1xuICAgIGRheTogcmVuZGVyRGF0ZVZpZXdDYWxlbmRhcixcbiAgICBtb250aDogcmVuZGVyRGF0ZVZpZXdDYWxlbmRhcixcbiAgICB5ZWFyOiByZW5kZXJEYXRlVmlld0NhbGVuZGFyLFxuICAgIGhvdXJzOiByZW5kZXJUaW1lVmlldyxcbiAgICBtaW51dGVzOiByZW5kZXJUaW1lVmlldyxcbiAgICBzZWNvbmRzOiByZW5kZXJUaW1lVmlldyxcbiAgICBtZXJpZGllbTogcmVuZGVyVGltZVZpZXdcbiAgfSwgZGVmYXVsdGl6ZWRQcm9wcy52aWV3UmVuZGVyZXJzKTtcblxuICAvLyBOZWVkIHRvIGF2b2lkIGFkZGluZyB0aGUgYG1lcmlkaWVtYCB2aWV3IHdoZW4gdW5leHBlY3RlZCByZW5kZXJlciBpcyBzcGVjaWZpZWRcbiAgY29uc3Qgc2hvdWxkSG91cnNSZW5kZXJlckNvbnRhaW5NZXJpZGllbVZpZXcgPSB2aWV3UmVuZGVyZXJzLmhvdXJzPy5uYW1lID09PSByZW5kZXJNdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2tUaW1lVmlldy5uYW1lO1xuICBjb25zdCB2aWV3cyA9ICFzaG91bGRIb3Vyc1JlbmRlcmVyQ29udGFpbk1lcmlkaWVtVmlldyA/IGRlZmF1bHRpemVkUHJvcHMudmlld3MuZmlsdGVyKHZpZXcgPT4gdmlldyAhPT0gJ21lcmlkaWVtJykgOiBkZWZhdWx0aXplZFByb3BzLnZpZXdzO1xuXG4gIC8vIFByb3BzIHdpdGggdGhlIGRlZmF1bHQgdmFsdWVzIHNwZWNpZmljIHRvIHRoZSBzdGF0aWMgdmFyaWFudFxuICBjb25zdCBwcm9wcyA9IF9leHRlbmRzKHt9LCBkZWZhdWx0aXplZFByb3BzLCB7XG4gICAgdmlld1JlbmRlcmVycyxcbiAgICBkaXNwbGF5U3RhdGljV3JhcHBlckFzLFxuICAgIHZpZXdzLFxuICAgIGFtcG1JbkNsb2NrLFxuICAgIHllYXJzUGVyUm93OiBkZWZhdWx0aXplZFByb3BzLnllYXJzUGVyUm93ID8/IChkaXNwbGF5U3RhdGljV3JhcHBlckFzID09PSAnbW9iaWxlJyA/IDMgOiA0KSxcbiAgICBzbG90UHJvcHM6IF9leHRlbmRzKHt9LCBkZWZhdWx0aXplZFByb3BzLnNsb3RQcm9wcywge1xuICAgICAgdGFiczogX2V4dGVuZHMoe1xuICAgICAgICBoaWRkZW46IGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPT09ICdkZXNrdG9wJ1xuICAgICAgfSwgZGVmYXVsdGl6ZWRQcm9wcy5zbG90UHJvcHM/LnRhYnMpLFxuICAgICAgdG9vbGJhcjogX2V4dGVuZHMoe1xuICAgICAgICBoaWRkZW46IGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPT09ICdkZXNrdG9wJyxcbiAgICAgICAgYW1wbUluQ2xvY2tcbiAgICAgIH0sIGRlZmF1bHRpemVkUHJvcHMuc2xvdFByb3BzPy50b29sYmFyKVxuICAgIH0pLFxuICAgIHN4OiBtZXJnZVN4KFt7XG4gICAgICBbYCYgLiR7bXVsdGlTZWN0aW9uRGlnaXRhbENsb2NrQ2xhc3Nlcy5yb290fWBdOiB7XG4gICAgICAgIHdpZHRoOiBESUFMT0dfV0lEVEhcbiAgICAgIH0sXG4gICAgICBbYCYgLiR7bXVsdGlTZWN0aW9uRGlnaXRhbENsb2NrU2VjdGlvbkNsYXNzZXMucm9vdH1gXToge1xuICAgICAgICBmbGV4OiAxLFxuICAgICAgICAvLyBhY2NvdW50IGZvciB0aGUgYm9yZGVyIG9uIGBNdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2tgXG4gICAgICAgIG1heEhlaWdodDogVklFV19IRUlHSFQgLSAxLFxuICAgICAgICBbYC4ke211bHRpU2VjdGlvbkRpZ2l0YWxDbG9ja1NlY3Rpb25DbGFzc2VzLml0ZW19YF06IHtcbiAgICAgICAgICB3aWR0aDogJ2F1dG8nXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBbYCYgLiR7ZGlnaXRhbENsb2NrQ2xhc3Nlcy5yb290fWBdOiB7XG4gICAgICAgIHdpZHRoOiBESUFMT0dfV0lEVEgsXG4gICAgICAgIG1heEhlaWdodDogVklFV19IRUlHSFQsXG4gICAgICAgIGZsZXg6IDEsXG4gICAgICAgIFtgLiR7ZGlnaXRhbENsb2NrQ2xhc3Nlcy5pdGVtfWBdOiB7XG4gICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XSwgZGVmYXVsdGl6ZWRQcm9wcz8uc3gpXG4gIH0pO1xuICBjb25zdCB7XG4gICAgcmVuZGVyUGlja2VyXG4gIH0gPSB1c2VTdGF0aWNQaWNrZXIoe1xuICAgIHJlZixcbiAgICBwcm9wcyxcbiAgICB2YWx1ZU1hbmFnZXI6IHNpbmdsZUl0ZW1WYWx1ZU1hbmFnZXIsXG4gICAgdmFsdWVUeXBlOiAnZGF0ZS10aW1lJyxcbiAgICB2YWxpZGF0b3I6IHZhbGlkYXRlRGF0ZVRpbWUsXG4gICAgc3RlcHM6IFNURVBTXG4gIH0pO1xuICByZXR1cm4gcmVuZGVyUGlja2VyKCk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFN0YXRpY0RhdGVUaW1lUGlja2VyLmRpc3BsYXlOYW1lID0gXCJTdGF0aWNEYXRlVGltZVBpY2tlclwiO1xucHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gU3RhdGljRGF0ZVRpbWVQaWNrZXIucHJvcFR5cGVzIC8qIHJlbW92ZS1wcm9wdHlwZXMgKi8gPSB7XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFdhcm5pbmcgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gfCBUaGVzZSBQcm9wVHlwZXMgYXJlIGdlbmVyYXRlZCBmcm9tIHRoZSBUeXBlU2NyaXB0IHR5cGUgZGVmaW5pdGlvbnMgfFxuICAvLyB8IFRvIHVwZGF0ZSB0aGVtIGVkaXQgdGhlIFR5cGVTY3JpcHQgdHlwZXMgYW5kIHJ1biBcInBucG0gcHJvcHR5cGVzXCIgIHxcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogMTJoLzI0aCB2aWV3IGZvciBob3VyIHNlbGVjdGlvbiBjbG9jay5cbiAgICogQGRlZmF1bHQgYWRhcHRlci5pczEySG91ckN5Y2xlSW5DdXJyZW50TG9jYWxlKClcbiAgICovXG4gIGFtcG06IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogRGlzcGxheSBhbXBtIGNvbnRyb2xzIHVuZGVyIHRoZSBjbG9jayAoaW5zdGVhZCBvZiBpbiB0aGUgdG9vbGJhcikuXG4gICAqIEBkZWZhdWx0IHRydWUgb24gZGVza3RvcCwgZmFsc2Ugb24gbW9iaWxlXG4gICAqL1xuICBhbXBtSW5DbG9jazogUHJvcFR5cGVzLmJvb2wsXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSBtYWluIGVsZW1lbnQgaXMgZm9jdXNlZCBkdXJpbmcgdGhlIGZpcnN0IG1vdW50LlxuICAgKiBUaGlzIG1haW4gZWxlbWVudCBpczpcbiAgICogLSB0aGUgZWxlbWVudCBjaG9zZW4gYnkgdGhlIHZpc2libGUgdmlldyBpZiBhbnkgKGkuZTogdGhlIHNlbGVjdGVkIGRheSBvbiB0aGUgYGRheWAgdmlldykuXG4gICAqIC0gdGhlIGBpbnB1dGAgZWxlbWVudCBpZiB0aGVyZSBpcyBhIGZpZWxkIHJlbmRlcmVkLlxuICAgKi9cbiAgYXV0b0ZvY3VzOiBQcm9wVHlwZXMuYm9vbCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAvKipcbiAgICogRm9ybWF0cyB0aGUgZGF5IG9mIHdlZWsgZGlzcGxheWVkIGluIHRoZSBjYWxlbmRhciBoZWFkZXIuXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSBkYXRlIFRoZSBkYXRlIG9mIHRoZSBkYXkgb2Ygd2VlayBwcm92aWRlZCBieSB0aGUgYWRhcHRlci5cbiAgICogQHJldHVybnMge3N0cmluZ30gVGhlIG5hbWUgdG8gZGlzcGxheS5cbiAgICogQGRlZmF1bHQgKGRhdGU6IFBpY2tlclZhbGlkRGF0ZSkgPT4gYWRhcHRlci5mb3JtYXQoZGF0ZSwgJ3dlZWtkYXlTaG9ydCcpLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpXG4gICAqL1xuICBkYXlPZldlZWtGb3JtYXR0ZXI6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogVGhlIGRlZmF1bHQgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIG5vdCBjb250cm9sbGVkLlxuICAgKi9cbiAgZGVmYXVsdFZhbHVlOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogSWYgYHRydWVgLCB0aGUgY29tcG9uZW50IGlzIGRpc2FibGVkLlxuICAgKiBXaGVuIGRpc2FibGVkLCB0aGUgdmFsdWUgY2Fubm90IGJlIGNoYW5nZWQgYW5kIG5vIGludGVyYWN0aW9uIGlzIHBvc3NpYmxlLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZWQ6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBkaXNhYmxlIHZhbHVlcyBhZnRlciB0aGUgY3VycmVudCBkYXRlIGZvciBkYXRlIGNvbXBvbmVudHMsIHRpbWUgZm9yIHRpbWUgY29tcG9uZW50cyBhbmQgYm90aCBmb3IgZGF0ZSB0aW1lIGNvbXBvbmVudHMuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBkaXNhYmxlRnV0dXJlOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgdG9kYXkncyBkYXkgaXMgbm90IGhpZ2hsaWdodGVkLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZUhpZ2hsaWdodFRvZGF5OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIERvIG5vdCBpZ25vcmUgZGF0ZSBwYXJ0IHdoZW4gdmFsaWRhdGluZyBtaW4vbWF4IHRpbWUuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBkaXNhYmxlSWdub3JpbmdEYXRlUGFydEZvclRpbWVWYWxpZGF0aW9uOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZSB2YWx1ZXMgYmVmb3JlIHRoZSBjdXJyZW50IGRhdGUgZm9yIGRhdGUgY29tcG9uZW50cywgdGltZSBmb3IgdGltZSBjb21wb25lbnRzIGFuZCBib3RoIGZvciBkYXRlIHRpbWUgY29tcG9uZW50cy5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGRpc2FibGVQYXN0OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIEZvcmNlIHN0YXRpYyB3cmFwcGVyIGlubmVyIGNvbXBvbmVudHMgdG8gYmUgcmVuZGVyZWQgaW4gbW9iaWxlIG9yIGRlc2t0b3AgbW9kZS5cbiAgICogQGRlZmF1bHQgXCJtb2JpbGVcIlxuICAgKi9cbiAgZGlzcGxheVN0YXRpY1dyYXBwZXJBczogUHJvcFR5cGVzLm9uZU9mKFsnZGVza3RvcCcsICdtb2JpbGUnXSksXG4gIC8qKlxuICAgKiBJZiBgdHJ1ZWAsIHRoZSB3ZWVrIG51bWJlciB3aWxsIGJlIGRpc3BsYXkgaW4gdGhlIGNhbGVuZGFyLlxuICAgKi9cbiAgZGlzcGxheVdlZWtOdW1iZXI6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogVGhlIGRheSB2aWV3IHdpbGwgc2hvdyBhcyBtYW55IHdlZWtzIGFzIG5lZWRlZCBhZnRlciB0aGUgZW5kIG9mIHRoZSBjdXJyZW50IG1vbnRoIHRvIG1hdGNoIHRoaXMgdmFsdWUuXG4gICAqIFB1dCBpdCB0byA2IHRvIGhhdmUgYSBmaXhlZCBudW1iZXIgb2Ygd2Vla3MgaW4gR3JlZ29yaWFuIGNhbGVuZGFyc1xuICAgKi9cbiAgZml4ZWRXZWVrTnVtYmVyOiBQcm9wVHlwZXMubnVtYmVyLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBjYWxscyBgcmVuZGVyTG9hZGluZ2AgaW5zdGVhZCBvZiByZW5kZXJpbmcgdGhlIGRheSBjYWxlbmRhci5cbiAgICogQ2FuIGJlIHVzZWQgdG8gcHJlbG9hZCBpbmZvcm1hdGlvbiBhbmQgc2hvdyBpdCBpbiBjYWxlbmRhci5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGxvYWRpbmc6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogTG9jYWxlIGZvciBjb21wb25lbnRzIHRleHRzLlxuICAgKiBBbGxvd3Mgb3ZlcnJpZGluZyB0ZXh0cyBjb21pbmcgZnJvbSBgTG9jYWxpemF0aW9uUHJvdmlkZXJgIGFuZCBgdGhlbWVgLlxuICAgKi9cbiAgbG9jYWxlVGV4dDogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE1heGltYWwgc2VsZWN0YWJsZSBkYXRlLlxuICAgKiBAZGVmYXVsdCAyMDk5LTEyLTMxXG4gICAqL1xuICBtYXhEYXRlOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogTWF4aW1hbCBzZWxlY3RhYmxlIG1vbWVudCBvZiB0aW1lIHdpdGggYmluZGluZyB0byBkYXRlLCB0byBzZXQgbWF4IHRpbWUgaW4gZWFjaCBkYXkgdXNlIGBtYXhUaW1lYC5cbiAgICovXG4gIG1heERhdGVUaW1lOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogTWF4aW1hbCBzZWxlY3RhYmxlIHRpbWUuXG4gICAqIFRoZSBkYXRlIHBhcnQgb2YgdGhlIG9iamVjdCB3aWxsIGJlIGlnbm9yZWQgdW5sZXNzIGBwcm9wcy5kaXNhYmxlSWdub3JpbmdEYXRlUGFydEZvclRpbWVWYWxpZGF0aW9uID09PSB0cnVlYC5cbiAgICovXG4gIG1heFRpbWU6IFByb3BUeXBlcy5vYmplY3QsXG4gIC8qKlxuICAgKiBNaW5pbWFsIHNlbGVjdGFibGUgZGF0ZS5cbiAgICogQGRlZmF1bHQgMTkwMC0wMS0wMVxuICAgKi9cbiAgbWluRGF0ZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE1pbmltYWwgc2VsZWN0YWJsZSBtb21lbnQgb2YgdGltZSB3aXRoIGJpbmRpbmcgdG8gZGF0ZSwgdG8gc2V0IG1pbiB0aW1lIGluIGVhY2ggZGF5IHVzZSBgbWluVGltZWAuXG4gICAqL1xuICBtaW5EYXRlVGltZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE1pbmltYWwgc2VsZWN0YWJsZSB0aW1lLlxuICAgKiBUaGUgZGF0ZSBwYXJ0IG9mIHRoZSBvYmplY3Qgd2lsbCBiZSBpZ25vcmVkIHVubGVzcyBgcHJvcHMuZGlzYWJsZUlnbm9yaW5nRGF0ZVBhcnRGb3JUaW1lVmFsaWRhdGlvbiA9PT0gdHJ1ZWAuXG4gICAqL1xuICBtaW5UaW1lOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogU3RlcCBvdmVyIG1pbnV0ZXMuXG4gICAqIEBkZWZhdWx0IDFcbiAgICovXG4gIG1pbnV0ZXNTdGVwOiBQcm9wVHlwZXMubnVtYmVyLFxuICAvKipcbiAgICogTW9udGhzIHJlbmRlcmVkIHBlciByb3cuXG4gICAqIEBkZWZhdWx0IDNcbiAgICovXG4gIG1vbnRoc1BlclJvdzogUHJvcFR5cGVzLm9uZU9mKFszLCA0XSksXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCB3aGVuIHRoZSB2YWx1ZSBpcyBhY2NlcHRlZC5cbiAgICogQHRlbXBsYXRlIFRWYWx1ZSBUaGUgdmFsdWUgdHlwZS4gSXQgd2lsbCBiZSB0aGUgc2FtZSB0eXBlIGFzIGB2YWx1ZWAgb3IgYG51bGxgLiBJdCBjYW4gYmUgaW4gYFtzdGFydCwgZW5kXWAgZm9ybWF0IGluIGNhc2Ugb2YgcmFuZ2UgdmFsdWUuXG4gICAqIEB0ZW1wbGF0ZSBURXJyb3IgVGhlIHZhbGlkYXRpb24gZXJyb3IgdHlwZS4gSXQgd2lsbCBiZSBlaXRoZXIgYHN0cmluZ2Agb3IgYSBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHBhcmFtIHtUVmFsdWV9IHZhbHVlIFRoZSB2YWx1ZSB0aGF0IHdhcyBqdXN0IGFjY2VwdGVkLlxuICAgKiBAcGFyYW0ge0ZpZWxkQ2hhbmdlSGFuZGxlckNvbnRleHQ8VEVycm9yPn0gY29udGV4dCBDb250ZXh0IGFib3V0IHRoaXMgYWNjZXB0YW5jZTpcbiAgICogLSBgdmFsaWRhdGlvbkVycm9yYDogdmFsaWRhdGlvbiByZXN1bHQgb2YgdGhlIGN1cnJlbnQgdmFsdWVcbiAgICogLSBgc291cmNlYDogc291cmNlIG9mIHRoZSBhY2NlcHRhbmNlLiBPbmUgb2YgJ2ZpZWxkJyB8ICd2aWV3JyB8ICd1bmtub3duJ1xuICAgKiAtIGBzaG9ydGN1dGAgKG9wdGlvbmFsKTogdGhlIHNob3J0Y3V0IG1ldGFkYXRhIGlmIHRoZSB2YWx1ZSB3YXMgYWNjZXB0ZWQgdmlhIGEgc2hvcnRjdXQgc2VsZWN0aW9uXG4gICAqL1xuICBvbkFjY2VwdDogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCB3aGVuIHRoZSB2YWx1ZSBjaGFuZ2VzLlxuICAgKiBAdGVtcGxhdGUgVFZhbHVlIFRoZSB2YWx1ZSB0eXBlLiBJdCB3aWxsIGJlIHRoZSBzYW1lIHR5cGUgYXMgYHZhbHVlYCBvciBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHRlbXBsYXRlIFRFcnJvciBUaGUgdmFsaWRhdGlvbiBlcnJvciB0eXBlLiBJdCB3aWxsIGJlIGVpdGhlciBgc3RyaW5nYCBvciBhIGBudWxsYC4gSXQgY2FuIGJlIGluIGBbc3RhcnQsIGVuZF1gIGZvcm1hdCBpbiBjYXNlIG9mIHJhbmdlIHZhbHVlLlxuICAgKiBAcGFyYW0ge1RWYWx1ZX0gdmFsdWUgVGhlIG5ldyB2YWx1ZS5cbiAgICogQHBhcmFtIHtGaWVsZENoYW5nZUhhbmRsZXJDb250ZXh0PFRFcnJvcj59IGNvbnRleHQgQ29udGV4dCBhYm91dCB0aGlzIGNoYW5nZTpcbiAgICogLSBgdmFsaWRhdGlvbkVycm9yYDogdmFsaWRhdGlvbiByZXN1bHQgb2YgdGhlIGN1cnJlbnQgdmFsdWVcbiAgICogLSBgc291cmNlYDogc291cmNlIG9mIHRoZSBjaGFuZ2UuIE9uZSBvZiAnZmllbGQnIHwgJ3ZpZXcnIHwgJ3Vua25vd24nXG4gICAqIC0gYHNob3J0Y3V0YCAob3B0aW9uYWwpOiB0aGUgc2hvcnRjdXQgbWV0YWRhdGEgaWYgdGhlIGNoYW5nZSB3YXMgdHJpZ2dlcmVkIGJ5IGEgc2hvcnRjdXQgc2VsZWN0aW9uXG4gICAqL1xuICBvbkNoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCB3aGVuIGNvbXBvbmVudCByZXF1ZXN0cyB0byBiZSBjbG9zZWQuXG4gICAqIENhbiBiZSBmaXJlZCB3aGVuIHNlbGVjdGluZyAoYnkgZGVmYXVsdCBvbiBgZGVza3RvcGAgbW9kZSkgb3IgY2xlYXJpbmcgYSB2YWx1ZS5cbiAgICogQGRlcHJlY2F0ZWQgUGxlYXNlIGF2b2lkIHVzaW5nIGFzIGl0IHdpbGwgYmUgcmVtb3ZlZCBpbiBuZXh0IG1ham9yIHZlcnNpb24uXG4gICAqL1xuICBvbkNsb3NlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIENhbGxiYWNrIGZpcmVkIHdoZW4gdGhlIGVycm9yIGFzc29jaWF0ZWQgd2l0aCB0aGUgY3VycmVudCB2YWx1ZSBjaGFuZ2VzLlxuICAgKiBXaGVuIGEgdmFsaWRhdGlvbiBlcnJvciBpcyBkZXRlY3RlZCwgdGhlIGBlcnJvcmAgcGFyYW1ldGVyIGNvbnRhaW5zIGEgbm9uLW51bGwgdmFsdWUuXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gcmVuZGVyIGFuIGFwcHJvcHJpYXRlIGZvcm0gZXJyb3IuXG4gICAqIEB0ZW1wbGF0ZSBURXJyb3IgVGhlIHZhbGlkYXRpb24gZXJyb3IgdHlwZS4gSXQgd2lsbCBiZSBlaXRoZXIgYHN0cmluZ2Agb3IgYSBgbnVsbGAuIEl0IGNhbiBiZSBpbiBgW3N0YXJ0LCBlbmRdYCBmb3JtYXQgaW4gY2FzZSBvZiByYW5nZSB2YWx1ZS5cbiAgICogQHRlbXBsYXRlIFRWYWx1ZSBUaGUgdmFsdWUgdHlwZS4gSXQgd2lsbCBiZSB0aGUgc2FtZSB0eXBlIGFzIGB2YWx1ZWAgb3IgYG51bGxgLiBJdCBjYW4gYmUgaW4gYFtzdGFydCwgZW5kXWAgZm9ybWF0IGluIGNhc2Ugb2YgcmFuZ2UgdmFsdWUuXG4gICAqIEBwYXJhbSB7VEVycm9yfSBlcnJvciBUaGUgcmVhc29uIHdoeSB0aGUgY3VycmVudCB2YWx1ZSBpcyBub3QgdmFsaWQuXG4gICAqIEBwYXJhbSB7VFZhbHVlfSB2YWx1ZSBUaGUgdmFsdWUgYXNzb2NpYXRlZCB3aXRoIHRoZSBlcnJvci5cbiAgICovXG4gIG9uRXJyb3I6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogQ2FsbGJhY2sgZmlyZWQgb24gbW9udGggY2hhbmdlLlxuICAgKiBAcGFyYW0ge1BpY2tlclZhbGlkRGF0ZX0gbW9udGggVGhlIG5ldyBtb250aC5cbiAgICovXG4gIG9uTW9udGhDaGFuZ2U6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogQ2FsbGJhY2sgZmlyZWQgb24gdmlldyBjaGFuZ2UuXG4gICAqIEB0ZW1wbGF0ZSBUVmlldyBUeXBlIG9mIHRoZSB2aWV3LiBJdCB3aWxsIHZhcnkgYmFzZWQgb24gdGhlIFBpY2tlciB0eXBlIGFuZCB0aGUgYHZpZXdzYCBpdCB1c2VzLlxuICAgKiBAcGFyYW0ge1RWaWV3fSB2aWV3IFRoZSBuZXcgdmlldy5cbiAgICovXG4gIG9uVmlld0NoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBDYWxsYmFjayBmaXJlZCBvbiB5ZWFyIGNoYW5nZS5cbiAgICogQHBhcmFtIHtQaWNrZXJWYWxpZERhdGV9IHllYXIgVGhlIG5ldyB5ZWFyLlxuICAgKi9cbiAgb25ZZWFyQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIFRoZSBkZWZhdWx0IHZpc2libGUgdmlldy5cbiAgICogVXNlZCB3aGVuIHRoZSBjb21wb25lbnQgdmlldyBpcyBub3QgY29udHJvbGxlZC5cbiAgICogTXVzdCBiZSBhIHZhbGlkIG9wdGlvbiBmcm9tIGB2aWV3c2AgbGlzdC5cbiAgICovXG4gIG9wZW5UbzogUHJvcFR5cGVzLm9uZU9mKFsnZGF5JywgJ2hvdXJzJywgJ21lcmlkaWVtJywgJ21pbnV0ZXMnLCAnbW9udGgnLCAnc2Vjb25kcycsICd5ZWFyJ10pLFxuICAvKipcbiAgICogRm9yY2UgcmVuZGVyaW5nIGluIHBhcnRpY3VsYXIgb3JpZW50YXRpb24uXG4gICAqL1xuICBvcmllbnRhdGlvbjogUHJvcFR5cGVzLm9uZU9mKFsnbGFuZHNjYXBlJywgJ3BvcnRyYWl0J10pLFxuICAvKipcbiAgICogSWYgYHRydWVgLCB0aGUgY29tcG9uZW50IGlzIHJlYWQtb25seS5cbiAgICogV2hlbiByZWFkLW9ubHksIHRoZSB2YWx1ZSBjYW5ub3QgYmUgY2hhbmdlZCBidXQgdGhlIHVzZXIgY2FuIGludGVyYWN0IHdpdGggdGhlIGludGVyZmFjZS5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRPbmx5OiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZSBoZWF2eSBhbmltYXRpb25zLlxuICAgKiBAZGVmYXVsdCBgQG1lZGlhKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSlgIHx8IGBuYXZpZ2F0b3IudXNlckFnZW50YCBtYXRjaGVzIEFuZHJvaWQgPDEwIG9yIGlPUyA8MTNcbiAgICovXG4gIHJlZHVjZUFuaW1hdGlvbnM6IFByb3BUeXBlcy5ib29sLFxuICAvKipcbiAgICogVGhlIGRhdGUgdXNlZCB0byBnZW5lcmF0ZSB0aGUgbmV3IHZhbHVlIHdoZW4gYm90aCBgdmFsdWVgIGFuZCBgZGVmYXVsdFZhbHVlYCBhcmUgZW1wdHkuXG4gICAqIEBkZWZhdWx0IFRoZSBjbG9zZXN0IHZhbGlkIGRhdGUtdGltZSB1c2luZyB0aGUgdmFsaWRhdGlvbiBwcm9wcywgZXhjZXB0IGNhbGxiYWNrcyBsaWtlIGBzaG91bGREaXNhYmxlPC4uLj5gLlxuICAgKi9cbiAgcmVmZXJlbmNlRGF0ZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIENvbXBvbmVudCBkaXNwbGF5aW5nIHdoZW4gcGFzc2VkIGBsb2FkaW5nYCB0cnVlLlxuICAgKiBAcmV0dXJucyB7UmVhY3QuUmVhY3ROb2RlfSBUaGUgbm9kZSB0byByZW5kZXIgd2hlbiBsb2FkaW5nLlxuICAgKiBAZGVmYXVsdCAoKSA9PiA8c3Bhbj7igKY8L3NwYW4+XG4gICAqL1xuICByZW5kZXJMb2FkaW5nOiBQcm9wVHlwZXMuZnVuYyxcbiAgLyoqXG4gICAqIERpc2FibGUgc3BlY2lmaWMgZGF0ZS5cbiAgICpcbiAgICogV2FybmluZzogVGhpcyBmdW5jdGlvbiBjYW4gYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzIChmb3IgZXhhbXBsZSB3aGVuIHJlbmRlcmluZyBkYXRlIGNhbGVuZGFyLCBjaGVja2luZyBpZiBmb2N1cyBjYW4gYmUgbW92ZWQgdG8gYSBjZXJ0YWluIGRhdGUsIGV0Yy4pLiBFeHBlbnNpdmUgY29tcHV0YXRpb25zIGNhbiBpbXBhY3QgcGVyZm9ybWFuY2UuXG4gICAqXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSBkYXkgVGhlIGRhdGUgdG8gdGVzdC5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IElmIGB0cnVlYCB0aGUgZGF0ZSB3aWxsIGJlIGRpc2FibGVkLlxuICAgKi9cbiAgc2hvdWxkRGlzYWJsZURhdGU6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogRGlzYWJsZSBzcGVjaWZpYyBtb250aC5cbiAgICogQHBhcmFtIHtQaWNrZXJWYWxpZERhdGV9IG1vbnRoIFRoZSBtb250aCB0byB0ZXN0LlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gSWYgYHRydWVgLCB0aGUgbW9udGggd2lsbCBiZSBkaXNhYmxlZC5cbiAgICovXG4gIHNob3VsZERpc2FibGVNb250aDogUHJvcFR5cGVzLmZ1bmMsXG4gIC8qKlxuICAgKiBEaXNhYmxlIHNwZWNpZmljIHRpbWUuXG4gICAqIEBwYXJhbSB7UGlja2VyVmFsaWREYXRlfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gICAqIEBwYXJhbSB7VGltZVZpZXd9IHZpZXcgVGhlIGNsb2NrIHR5cGUgb2YgdGhlIHRpbWVWYWx1ZS5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IElmIGB0cnVlYCB0aGUgdGltZSB3aWxsIGJlIGRpc2FibGVkLlxuICAgKi9cbiAgc2hvdWxkRGlzYWJsZVRpbWU6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogRGlzYWJsZSBzcGVjaWZpYyB5ZWFyLlxuICAgKiBAcGFyYW0ge1BpY2tlclZhbGlkRGF0ZX0geWVhciBUaGUgeWVhciB0byB0ZXN0LlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gSWYgYHRydWVgLCB0aGUgeWVhciB3aWxsIGJlIGRpc2FibGVkLlxuICAgKi9cbiAgc2hvdWxkRGlzYWJsZVllYXI6IFByb3BUeXBlcy5mdW5jLFxuICAvKipcbiAgICogSWYgYHRydWVgLCBkYXlzIG91dHNpZGUgdGhlIGN1cnJlbnQgbW9udGggYXJlIHJlbmRlcmVkOlxuICAgKlxuICAgKiAtIGlmIGBmaXhlZFdlZWtOdW1iZXJgIGlzIGRlZmluZWQsIHJlbmRlcnMgZGF5cyB0byBoYXZlIHRoZSB3ZWVrcyByZXF1ZXN0ZWQuXG4gICAqXG4gICAqIC0gaWYgYGZpeGVkV2Vla051bWJlcmAgaXMgbm90IGRlZmluZWQsIHJlbmRlcnMgZGF5IHRvIGZpbGwgdGhlIGZpcnN0IGFuZCBsYXN0IHdlZWsgb2YgdGhlIGN1cnJlbnQgbW9udGguXG4gICAqXG4gICAqIC0gaWdub3JlZCBpZiBgY2FsZW5kYXJzYCBlcXVhbHMgbW9yZSB0aGFuIGAxYCBvbiByYW5nZSBwaWNrZXJzLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgc2hvd0RheXNPdXRzaWRlQ3VycmVudE1vbnRoOiBQcm9wVHlwZXMuYm9vbCxcbiAgLyoqXG4gICAqIElmIGB0cnVlYCwgZGlzYWJsZWQgZGlnaXRhbCBjbG9jayBpdGVtcyB3aWxsIG5vdCBiZSByZW5kZXJlZC5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHNraXBEaXNhYmxlZDogUHJvcFR5cGVzLmJvb2wsXG4gIC8qKlxuICAgKiBUaGUgcHJvcHMgdXNlZCBmb3IgZWFjaCBjb21wb25lbnQgc2xvdC5cbiAgICogQGRlZmF1bHQge31cbiAgICovXG4gIHNsb3RQcm9wczogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIE92ZXJyaWRhYmxlIGNvbXBvbmVudCBzbG90cy5cbiAgICogQGRlZmF1bHQge31cbiAgICovXG4gIHNsb3RzOiBQcm9wVHlwZXMub2JqZWN0LFxuICAvKipcbiAgICogVGhlIHN5c3RlbSBwcm9wIHRoYXQgYWxsb3dzIGRlZmluaW5nIHN5c3RlbSBvdmVycmlkZXMgYXMgd2VsbCBhcyBhZGRpdGlvbmFsIENTUyBzdHlsZXMuXG4gICAqL1xuICBzeDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLmFycmF5T2YoUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLmZ1bmMsIFByb3BUeXBlcy5vYmplY3QsIFByb3BUeXBlcy5ib29sXSkpLCBQcm9wVHlwZXMuZnVuYywgUHJvcFR5cGVzLm9iamVjdF0pLFxuICAvKipcbiAgICogQW1vdW50IG9mIHRpbWUgb3B0aW9ucyBiZWxvdyBvciBhdCB3aGljaCB0aGUgc2luZ2xlIGNvbHVtbiB0aW1lIHJlbmRlcmVyIGlzIHVzZWQuXG4gICAqIEBkZWZhdWx0IDI0XG4gICAqL1xuICB0aHJlc2hvbGRUb1JlbmRlclRpbWVJbkFTaW5nbGVDb2x1bW46IFByb3BUeXBlcy5udW1iZXIsXG4gIC8qKlxuICAgKiBUaGUgdGltZSBzdGVwcyBiZXR3ZWVuIHR3byB0aW1lIHVuaXQgb3B0aW9ucy5cbiAgICogRm9yIGV4YW1wbGUsIGlmIGB0aW1lU3RlcHMubWludXRlcyA9IDhgLCB0aGVuIHRoZSBhdmFpbGFibGUgbWludXRlIG9wdGlvbnMgd2lsbCBiZSBgWzAsIDgsIDE2LCAyNCwgMzIsIDQwLCA0OCwgNTZdYC5cbiAgICogV2hlbiBzaW5nbGUgY29sdW1uIHRpbWUgcmVuZGVyZXIgaXMgdXNlZCwgb25seSBgdGltZVN0ZXBzLm1pbnV0ZXNgIHdpbGwgYmUgdXNlZC5cbiAgICogQGRlZmF1bHR7IGhvdXJzOiAxLCBtaW51dGVzOiA1LCBzZWNvbmRzOiA1IH1cbiAgICovXG4gIHRpbWVTdGVwczogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICBob3VyczogUHJvcFR5cGVzLm51bWJlcixcbiAgICBtaW51dGVzOiBQcm9wVHlwZXMubnVtYmVyLFxuICAgIHNlY29uZHM6IFByb3BUeXBlcy5udW1iZXJcbiAgfSksXG4gIC8qKlxuICAgKiBDaG9vc2Ugd2hpY2ggdGltZXpvbmUgdG8gdXNlIGZvciB0aGUgdmFsdWUuXG4gICAqIEV4YW1wbGU6IFwiZGVmYXVsdFwiLCBcInN5c3RlbVwiLCBcIlVUQ1wiLCBcIkFtZXJpY2EvTmV3X1lvcmtcIi5cbiAgICogSWYgeW91IHBhc3MgdmFsdWVzIGZyb20gb3RoZXIgdGltZXpvbmVzIHRvIHNvbWUgcHJvcHMsIHRoZXkgd2lsbCBiZSBjb252ZXJ0ZWQgdG8gdGhpcyB0aW1lem9uZSBiZWZvcmUgYmVpbmcgdXNlZC5cbiAgICogQHNlZSBTZWUgdGhlIHtAbGluayBodHRwczovL211aS5jb20veC9yZWFjdC1kYXRlLXBpY2tlcnMvdGltZXpvbmUvIHRpbWV6b25lcyBkb2N1bWVudGF0aW9ufSBmb3IgbW9yZSBkZXRhaWxzLlxuICAgKiBAZGVmYXVsdCBUaGUgdGltZXpvbmUgb2YgdGhlIGB2YWx1ZWAgb3IgYGRlZmF1bHRWYWx1ZWAgcHJvcCBpcyBkZWZpbmVkLCAnZGVmYXVsdCcgb3RoZXJ3aXNlLlxuICAgKi9cbiAgdGltZXpvbmU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIC8qKlxuICAgKiBUaGUgc2VsZWN0ZWQgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IGlzIGNvbnRyb2xsZWQuXG4gICAqL1xuICB2YWx1ZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgLyoqXG4gICAqIFRoZSB2aXNpYmxlIHZpZXcuXG4gICAqIFVzZWQgd2hlbiB0aGUgY29tcG9uZW50IHZpZXcgaXMgY29udHJvbGxlZC5cbiAgICogTXVzdCBiZSBhIHZhbGlkIG9wdGlvbiBmcm9tIGB2aWV3c2AgbGlzdC5cbiAgICovXG4gIHZpZXc6IFByb3BUeXBlcy5vbmVPZihbJ2RheScsICdob3VycycsICdtZXJpZGllbScsICdtaW51dGVzJywgJ21vbnRoJywgJ3NlY29uZHMnLCAneWVhciddKSxcbiAgLyoqXG4gICAqIERlZmluZSBjdXN0b20gdmlldyByZW5kZXJlcnMgZm9yIGVhY2ggc2VjdGlvbi5cbiAgICogSWYgYG51bGxgLCB0aGUgc2VjdGlvbiB3aWxsIG9ubHkgaGF2ZSBmaWVsZCBlZGl0aW5nLlxuICAgKiBJZiBgdW5kZWZpbmVkYCwgaW50ZXJuYWxseSBkZWZpbmVkIHZpZXcgd2lsbCBiZSB1c2VkLlxuICAgKi9cbiAgdmlld1JlbmRlcmVyczogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICBkYXk6IFByb3BUeXBlcy5mdW5jLFxuICAgIGhvdXJzOiBQcm9wVHlwZXMuZnVuYyxcbiAgICBtZXJpZGllbTogUHJvcFR5cGVzLmZ1bmMsXG4gICAgbWludXRlczogUHJvcFR5cGVzLmZ1bmMsXG4gICAgbW9udGg6IFByb3BUeXBlcy5mdW5jLFxuICAgIHNlY29uZHM6IFByb3BUeXBlcy5mdW5jLFxuICAgIHllYXI6IFByb3BUeXBlcy5mdW5jXG4gIH0pLFxuICAvKipcbiAgICogQXZhaWxhYmxlIHZpZXdzLlxuICAgKi9cbiAgdmlld3M6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5vbmVPZihbJ2RheScsICdob3VycycsICdtaW51dGVzJywgJ21vbnRoJywgJ3NlY29uZHMnLCAneWVhciddKS5pc1JlcXVpcmVkKSxcbiAgLyoqXG4gICAqIFllYXJzIGFyZSBkaXNwbGF5ZWQgaW4gYXNjZW5kaW5nIChjaHJvbm9sb2dpY2FsKSBvcmRlciBieSBkZWZhdWx0LlxuICAgKiBJZiBgZGVzY2AsIHllYXJzIGFyZSBkaXNwbGF5ZWQgaW4gZGVzY2VuZGluZyBvcmRlci5cbiAgICogQGRlZmF1bHQgJ2FzYydcbiAgICovXG4gIHllYXJzT3JkZXI6IFByb3BUeXBlcy5vbmVPZihbJ2FzYycsICdkZXNjJ10pLFxuICAvKipcbiAgICogWWVhcnMgcmVuZGVyZWQgcGVyIHJvdy5cbiAgICogQGRlZmF1bHQgYDRgIHdoZW4gYGRpc3BsYXlTdGF0aWNXcmFwcGVyQXMgPT09ICdkZXNrdG9wJ2AsIGAzYCBvdGhlcndpc2UuXG4gICAqL1xuICB5ZWFyc1BlclJvdzogUHJvcFR5cGVzLm9uZU9mKFszLCA0XSlcbn0gOiB2b2lkIDA7XG5leHBvcnQgeyBTdGF0aWNEYXRlVGltZVBpY2tlciB9OyIsIi8qKlxuICogQG11aS94LWRhdGUtcGlja2VycyB2OS4xMS4wXG4gKlxuICogQGxpY2Vuc2UgTUlUXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuLy8gQ2xvY2tzXG5leHBvcnQgKiBmcm9tIFwiLi9UaW1lQ2xvY2svaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9EaWdpdGFsQ2xvY2svaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9NdWx0aVNlY3Rpb25EaWdpdGFsQ2xvY2svaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9Mb2NhbGl6YXRpb25Qcm92aWRlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL1BpY2tlckRheS9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2xvY2FsZXMvdXRpbHMvcGlja2Vyc0xvY2FsZVRleHRBcGkubWpzXCI7XG5cbi8vIEZpZWxkc1xuZXhwb3J0ICogZnJvbSBcIi4vRGF0ZUZpZWxkL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vVGltZUZpZWxkL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vRGF0ZVRpbWVGaWVsZC9pbmRleC5tanNcIjtcblxuLy8gQ2FsZW5kYXJzXG5leHBvcnQgKiBmcm9tIFwiLi9EYXRlQ2FsZW5kYXIvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9Nb250aENhbGVuZGFyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vWWVhckNhbGVuZGFyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vRGF5Q2FsZW5kYXJTa2VsZXRvbi9pbmRleC5tanNcIjtcblxuLy8gTmV3IFBpY2tlcnNcbmV4cG9ydCAqIGZyb20gXCIuL0RhdGVQaWNrZXIvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9EZXNrdG9wRGF0ZVBpY2tlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL01vYmlsZURhdGVQaWNrZXIvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9TdGF0aWNEYXRlUGlja2VyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vVGltZVBpY2tlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL0Rlc2t0b3BUaW1lUGlja2VyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vTW9iaWxlVGltZVBpY2tlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL1N0YXRpY1RpbWVQaWNrZXIvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9EYXRlVGltZVBpY2tlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL0Rlc2t0b3BEYXRlVGltZVBpY2tlci9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL01vYmlsZURhdGVUaW1lUGlja2VyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vU3RhdGljRGF0ZVRpbWVQaWNrZXIvaW5kZXgubWpzXCI7XG5cbi8vIFZpZXcgcmVuZGVyZXJzXG5leHBvcnQgKiBmcm9tIFwiLi9kYXRlVmlld1JlbmRlcmVycy9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3RpbWVWaWV3UmVuZGVyZXJzL2luZGV4Lm1qc1wiO1xuXG4vLyBMYXlvdXRcbmV4cG9ydCAqIGZyb20gXCIuL1BpY2tlcnNMYXlvdXQvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9QaWNrZXJzQWN0aW9uQmFyL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vUGlja2Vyc1Nob3J0Y3V0cy9pbmRleC5tanNcIjtcblxuLy8gT3RoZXIgc2xvdHNcbmV4cG9ydCAqIGZyb20gXCIuL1BpY2tlcnNDYWxlbmRhckhlYWRlci9pbmRleC5tanNcIjtcblxuLy8gRmllbGQgdXRpbGl0aWVzXG5leHBvcnQgKiBmcm9tIFwiLi9QaWNrZXJzVGV4dEZpZWxkL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vUGlja2Vyc1NlY3Rpb25MaXN0L2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgREVGQVVMVF9ERVNLVE9QX01PREVfTUVESUFfUVVFUlkgfSBmcm9tIFwiLi9pbnRlcm5hbHMvdXRpbHMvdXRpbHMubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9tb2RlbHMvaW5kZXgubWpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9pY29ucy9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2hvb2tzL2luZGV4Lm1qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vdmFsaWRhdGlvbi9pbmRleC5tanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL21hbmFnZXJzL2luZGV4Lm1qc1wiOyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlQSxJQUFhLG1CQUFtQixhQUFhLENBQUMsTUFBTTtDQUNsRCxNQUFNLGdCQUFnQix5QkFBeUI7Q0FDL0MsTUFBTSxVQUFVLGlCQUFpQjtDQUNqQyxNQUFNLGVBQWUsc0JBQXNCO0NBQzNDLE1BQU0sa0JBQUEsYUFBd0IsY0FBYyxtQkFBbUIsT0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQ2xGLE1BQU0sRUFDSixTQUFTLGVBQWUsZUFBZSxRQUFRLFFBQVEsYUFDckQ7Q0FDSixPQUFBLGFBQWEsY0FBYztFQWF6QixPQVppQix3QkFBd0I7R0FDdkM7R0FDQTtHQUNBLGVBQWU7R0FHZixPQUFPO0dBQ1AsMkJBQTJCO0dBQzNCLFlBQVk7R0FDWjtHQUNBLE1BQU07RUFDUixDQUNjLENBQUMsQ0FBQyxLQUFJLFlBQVcsR0FBRyxRQUFRLGlCQUFpQixRQUFRLGNBQWMsUUFBUSxjQUFjLENBQUMsQ0FBQyxLQUFLLEVBQUU7Q0FDbEgsR0FBRztFQUFDO0VBQVM7RUFBYztFQUFpQjtDQUFNLENBQUM7QUFDckQ7OztBQ3BDQSxJQUFhLHNDQUFxQyxTQUFRLHFCQUFxQiwwQkFBMEIsSUFBSTtBQUM3RyxJQUFhLDZCQUE2Qix1QkFBdUIsMEJBQTBCO0NBQUM7Q0FBUTtDQUFRO0FBQWEsQ0FBQzs7Ozs7QUNDMUgsSUFBTUEsY0FBWSxDQUFDLGFBQWEsU0FBUztBQVV6QyxJQUFNLHFCQUFvQixZQUFXO0NBTW5DLE9BQU8sZUFBZTtFQUpwQixNQUFNLENBQUMsTUFBTTtFQUNiLE1BQU0sQ0FBQyxNQUFNO0VBQ2IsYUFBYSxDQUFDLGFBQWE7Q0FFSCxHQUFHLG9DQUFvQyxPQUFPO0FBQzFFO0FBQ0EsSUFBTSwwQkFBMEIsT0FBTyxPQUFPO0NBQzVDLE1BQU07Q0FDTixNQUFNO0FBQ1IsQ0FBQyxDQUFDLENBQUMsRUFDRCxXQUFXLFFBQ2IsQ0FBQztBQUNELElBQU0sMEJBQTBCLE9BQU8sT0FBTztDQUM1QyxNQUFNO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQyxDQUFDO0NBQ0QsUUFBUTtDQUNSLFNBQVM7Q0FDVCxnQkFBZ0I7QUFDbEIsQ0FBQztBQUNELElBQU0seUJBQXlCLE9BQU8sVUFBVTtDQUM5QyxNQUFNO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQyxDQUFDO0NBQ0QsUUFBUTtDQUNSLDhCQUE0QixFQUMxQixZQUFZLFNBQ2Q7QUFDRixDQUFDO0FBQ0QsSUFBTSxXQUFXO0NBQUM7RUFBQztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0NBQUc7RUFBQztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0NBQUc7RUFBQztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0NBQUc7RUFBQztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0NBQUc7RUFBQztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0FBQUM7Ozs7Ozs7Ozs7QUFXbkksU0FBUyxvQkFBb0IsU0FBUztDQUNwQyxNQUFNLFFBQVEsY0FBYztFQUMxQixPQUFPO0VBQ1AsTUFBTTtDQUNSLENBQUM7Q0FDRCxNQUFNLEVBQ0YsV0FDQSxTQUFTLGdCQUNQLE9BQ0osUUFBUSw4QkFBOEIsT0FBT0EsV0FBUztDQUN4RCxNQUFNLFVBQVUsa0JBQWtCLFdBQVc7Q0FDN0MsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx5QkFBeUIsU0FBUztFQUN6RCxXQUFXLEtBQUssUUFBUSxNQUFNLFNBQVM7RUFDdkMsWUFBWTtDQUNkLEdBQUcsT0FBTyxFQUNSLFVBQVUsU0FBUyxLQUFLLE1BQU0sVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx5QkFBeUI7RUFDakYsV0FBVyxRQUFRO0VBQ25CLFVBQVUsS0FBSyxLQUFLLFlBQVksV0FBd0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx3QkFBd0I7R0FDbkYsU0FBUztHQUNULE9BQUE7R0FDQSxRQUFBO0dBQ0EsV0FBVyxRQUFRO0dBQ25CLHFCQUFxQjtFQUN2QixHQUFHLE1BQU0sQ0FBQztDQUNaLEdBQUcsS0FBSyxDQUFDLEVBQ1gsQ0FBQyxDQUFDO0FBQ0o7QUFDd0Msb0JBQW9CLFlBQW1DOzs7O0NBUTdGLFNBQVNDLGtCQUFBQSxRQUFVOzs7O0NBSW5CLElBQUlBLGtCQUFBQSxRQUFVLFVBQVU7RUFBQ0Esa0JBQUFBLFFBQVUsUUFBUUEsa0JBQUFBLFFBQVUsVUFBVTtHQUFDQSxrQkFBQUEsUUFBVTtHQUFNQSxrQkFBQUEsUUFBVTtHQUFRQSxrQkFBQUEsUUFBVTtFQUFJLENBQUMsQ0FBQztFQUFHQSxrQkFBQUEsUUFBVTtFQUFNQSxrQkFBQUEsUUFBVTtDQUFNLENBQUM7QUFDeEo7OztBQzVGQSxJQUFNLFlBQVksQ0FBQyxTQUFTLE9BQU87QUFVbkMsSUFBTSxxQkFBcUIsT0FBTyxlQUFlLEVBQy9DLE1BQU0sV0FDUixDQUFDLENBQUMsRUFBRSxFQUNGLGFBQ0s7Q0FDTCxVQUFVO0NBQ1YsVUFBQTtDQUNBLGtCQUFrQixNQUFNLFFBQVEsTUFBQSxDQUFPLFFBQVEsV0FBVztBQUM1RCxFQUFFOzs7Ozs7O0FBUUYsSUFBYSxtQkFBa0IsU0FBUTtDQUNyQyxJQUFJLEVBQ0EsT0FDQSxVQUNFLE1BQ0osZUFBZSw4QkFBOEIsTUFBTSxTQUFTO0NBQzlELE1BQU0sRUFDSixZQUNBLE9BQ0EsV0FDQSx3QkFDQSxjQUNFO0NBQ0osTUFBTSxvQkFBb0IsbUNBQW1DLEVBQzNELE1BQ0YsQ0FBQztDQUNELE1BQU0sRUFDSixlQUNBLHNCQUNFLFVBQVUsU0FBUyxDQUFDLEdBQUcsY0FBYztFQUN2QztFQUNBLFNBQVM7RUFDVCxlQUFlLGFBQWE7RUFDNUIsbUJBQW1CO0VBQ25CO0VBQ0E7Q0FDRixDQUFDLENBQUM7Q0FDRixNQUFNLFNBQVMsT0FBTyxVQUFVO0NBQ2hDLE1BQU0scUJBQWtDLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZ0JBQWdCLFNBQVMsQ0FBQyxHQUFHLGVBQWUsRUFDdkYsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxRQUFRLFNBQVMsQ0FBQyxHQUFHLDBCQUEwQixLQUFLLEdBQUcsV0FBVyxRQUFRO0VBQzdGO0VBQ0k7RUFDWCxJQUFJLFFBQVEsY0FBYyxhQUFhLFFBQVEsV0FBVyxRQUFRLEVBQUU7RUFDcEUsV0FBVyxLQUFLLGNBQWMsYUFBYSxlQUFlLFdBQVcsUUFBUSxTQUFTO0VBQ3RGLEtBQUssY0FBYyxhQUFhO0VBQ2hDLFVBQVUsa0JBQWtCO0NBQzlCLENBQUMsQ0FBQyxFQUNKLENBQUMsQ0FBQztDQUN5QyxhQUFhLGNBQWM7Q0FDdEUsT0FBTyxFQUNMLGFBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7OztBQ3BEQSxJQUFNLG1CQUFnQywyQkFBTSxXQUFXLFNBQVMsaUJBQWlCLFNBQVMsS0FBSztDQUM3RixNQUFNLG1CQUFtQiw4QkFBOEIsU0FBUyxxQkFBcUI7Q0FDckYsTUFBTSx5QkFBeUIsaUJBQWlCLDBCQUEwQjtDQWtCMUUsTUFBTSxFQUNKLGlCQUNFLGdCQUFnQjtFQUNsQjtFQUNBLE9BZFksU0FBUyxDQUFDLEdBQUcsa0JBQWtCO0dBQzNDLGVBUm9CLFNBQVM7SUFDN0IsS0FBSztJQUNMLE9BQU87SUFDUCxNQUFNO0dBQ1IsR0FBRyxpQkFBaUIsYUFJTjtHQUNaO0dBQ0EsYUFBYSxpQkFBaUIsZ0JBQWdCLDJCQUEyQixXQUFXLElBQUk7R0FDeEYsV0FBVyxTQUFTLENBQUMsR0FBRyxpQkFBaUIsV0FBVyxFQUNsRCxTQUFTLFNBQVMsRUFDaEIsUUFBUSwyQkFBMkIsVUFDckMsR0FBRyxpQkFBaUIsV0FBVyxPQUFPLEVBQ3hDLENBQUM7RUFDSCxDQUtNO0VBQ0osY0FBYztFQUNkLFdBQVc7RUFDWCxXQUFXO0VBQ1gsT0FBTztDQUNULENBQUM7Q0FDRCxPQUFPLGFBQWE7QUFDdEIsQ0FBQztBQUMwQyxpQkFBaUIsY0FBYztBQUNsQyxpQkFBaUIsWUFBbUM7Ozs7Ozs7Q0FXMUYsV0FBV0Msa0JBQUFBLFFBQVU7Q0FDckIsV0FBV0Esa0JBQUFBLFFBQVU7Ozs7Ozs7Q0FPckIsb0JBQW9CQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLOUIsY0FBY0Esa0JBQUFBLFFBQVU7Ozs7OztDQU14QixVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLcEIsZUFBZUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3pCLHVCQUF1QkEsa0JBQUFBLFFBQVU7Ozs7O0NBS2pDLGFBQWFBLGtCQUFBQSxRQUFVOzs7OztDQUt2Qix3QkFBd0JBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQyxXQUFXLFFBQVEsQ0FBQzs7OztDQUk3RCxtQkFBbUJBLGtCQUFBQSxRQUFVOzs7OztDQUs3QixpQkFBaUJBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNM0IsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7O0NBS25CLFlBQVlBLGtCQUFBQSxRQUFVOzs7OztDQUt0QixTQUFTQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLbkIsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7O0NBS25CLGNBQWNBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Q0FXcEMsVUFBVUEsa0JBQUFBLFFBQVU7Ozs7Ozs7Ozs7O0NBV3BCLFVBQVVBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNcEIsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7Ozs7Ozs7Q0FVbkIsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7O0NBS25CLGVBQWVBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNekIsY0FBY0Esa0JBQUFBLFFBQVU7Ozs7O0NBS3hCLGNBQWNBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNeEIsUUFBUUEsa0JBQUFBLFFBQVUsTUFBTTtFQUFDO0VBQU87RUFBUztDQUFNLENBQUM7Ozs7Q0FJaEQsYUFBYUEsa0JBQUFBLFFBQVUsTUFBTSxDQUFDLGFBQWEsVUFBVSxDQUFDOzs7Ozs7Q0FNdEQsVUFBVUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3BCLGtCQUFrQkEsa0JBQUFBLFFBQVU7Ozs7O0NBSzVCLGVBQWVBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNekIsZUFBZUEsa0JBQUFBLFFBQVU7Ozs7Ozs7OztDQVN6QixtQkFBbUJBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNN0Isb0JBQW9CQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTTlCLG1CQUFtQkEsa0JBQUFBLFFBQVU7Ozs7Ozs7Ozs7O0NBVzdCLDZCQUE2QkEsa0JBQUFBLFFBQVU7Ozs7O0NBS3ZDLFdBQVdBLGtCQUFBQSxRQUFVOzs7OztDQUtyQixPQUFPQSxrQkFBQUEsUUFBVTs7OztDQUlqQixJQUFJQSxrQkFBQUEsUUFBVSxVQUFVO0VBQUNBLGtCQUFBQSxRQUFVLFFBQVFBLGtCQUFBQSxRQUFVLFVBQVU7R0FBQ0Esa0JBQUFBLFFBQVU7R0FBTUEsa0JBQUFBLFFBQVU7R0FBUUEsa0JBQUFBLFFBQVU7RUFBSSxDQUFDLENBQUM7RUFBR0Esa0JBQUFBLFFBQVU7RUFBTUEsa0JBQUFBLFFBQVU7Q0FBTSxDQUFDOzs7Ozs7OztDQVF0SixVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLcEIsT0FBT0Esa0JBQUFBLFFBQVU7Ozs7OztDQU1qQixNQUFNQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBTztFQUFTO0NBQU0sQ0FBQzs7Ozs7O0NBTTlDLGVBQWVBLGtCQUFBQSxRQUFVLE1BQU07RUFDN0IsS0FBS0Esa0JBQUFBLFFBQVU7RUFDZixPQUFPQSxrQkFBQUEsUUFBVTtFQUNqQixNQUFNQSxrQkFBQUEsUUFBVTtDQUNsQixDQUFDOzs7O0NBSUQsT0FBT0Esa0JBQUFBLFFBQVUsUUFBUUEsa0JBQUFBLFFBQVUsTUFBTTtFQUFDO0VBQU87RUFBUztDQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVU7Ozs7OztDQU03RSxZQUFZQSxrQkFBQUEsUUFBVSxNQUFNLENBQUMsT0FBTyxNQUFNLENBQUM7Ozs7O0NBSzNDLGFBQWFBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyQzs7Ozs7Ozs7Ozs7OztBQ3ZTQSxJQUFNLG1CQUFnQywyQkFBTSxXQUFXLFNBQVMsaUJBQWlCLFNBQVMsS0FBSztDQUM3RixNQUFNLG1CQUFtQiw4QkFBOEIsU0FBUyxxQkFBcUI7Q0FDckYsTUFBTSx5QkFBeUIsaUJBQWlCLDBCQUEwQjtDQUMxRSxNQUFNLGNBQWMsaUJBQWlCLGVBQWUsMkJBQTJCO0NBbUIvRSxNQUFNLEVBQ0osaUJBQ0UsZ0JBQWdCO0VBQ2xCO0VBQ0EsT0FmWSxTQUFTLENBQUMsR0FBRyxrQkFBa0I7R0FDM0MsZUFSb0IsU0FBUztJQUM3QixPQUFPO0lBQ1AsU0FBUztJQUNULFNBQVM7R0FDWCxHQUFHLGlCQUFpQixhQUlOO0dBQ1o7R0FDQTtHQUNBLFdBQVcsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFdBQVcsRUFDbEQsU0FBUyxTQUFTO0lBQ2hCLFFBQVEsMkJBQTJCO0lBQ25DO0dBQ0YsR0FBRyxpQkFBaUIsV0FBVyxPQUFPLEVBQ3hDLENBQUM7RUFDSCxDQUtNO0VBQ0osY0FBYztFQUNkLFdBQVc7RUFDWCxXQUFXO0VBQ1gsT0FBTztDQUNULENBQUM7Q0FDRCxPQUFPLGFBQWE7QUFDdEIsQ0FBQztBQUMwQyxpQkFBaUIsY0FBYztBQUNsQyxpQkFBaUIsWUFBbUM7Ozs7O0NBUzFGLE1BQU1DLGtCQUFBQSxRQUFVOzs7OztDQUtoQixhQUFhQSxrQkFBQUEsUUFBVTs7Ozs7OztDQU92QixXQUFXQSxrQkFBQUEsUUFBVTtDQUNyQixXQUFXQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLckIsY0FBY0Esa0JBQUFBLFFBQVU7Ozs7OztDQU14QixVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLcEIsZUFBZUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3pCLDBDQUEwQ0Esa0JBQUFBLFFBQVU7Ozs7O0NBS3BELGFBQWFBLGtCQUFBQSxRQUFVOzs7OztDQUt2Qix3QkFBd0JBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQyxXQUFXLFFBQVEsQ0FBQzs7Ozs7Q0FLN0QsWUFBWUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3RCLFNBQVNBLGtCQUFBQSxRQUFVOzs7OztDQUtuQixTQUFTQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLbkIsYUFBYUEsa0JBQUFBLFFBQVU7Ozs7Ozs7Ozs7O0NBV3ZCLFVBQVVBLGtCQUFBQSxRQUFVOzs7Ozs7Ozs7OztDQVdwQixVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTXBCLFNBQVNBLGtCQUFBQSxRQUFVOzs7Ozs7Ozs7O0NBVW5CLFNBQVNBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNbkIsY0FBY0Esa0JBQUFBLFFBQVU7Ozs7OztDQU14QixRQUFRQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBUztFQUFXO0NBQVMsQ0FBQzs7OztDQUl2RCxhQUFhQSxrQkFBQUEsUUFBVSxNQUFNLENBQUMsYUFBYSxVQUFVLENBQUM7Ozs7OztDQU10RCxVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLcEIsa0JBQWtCQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLNUIsZUFBZUEsa0JBQUFBLFFBQVU7Ozs7Ozs7Q0FPekIsbUJBQW1CQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLN0IsV0FBV0Esa0JBQUFBLFFBQVU7Ozs7O0NBS3JCLE9BQU9BLGtCQUFBQSxRQUFVOzs7O0NBSWpCLElBQUlBLGtCQUFBQSxRQUFVLFVBQVU7RUFBQ0Esa0JBQUFBLFFBQVUsUUFBUUEsa0JBQUFBLFFBQVUsVUFBVTtHQUFDQSxrQkFBQUEsUUFBVTtHQUFNQSxrQkFBQUEsUUFBVTtHQUFRQSxrQkFBQUEsUUFBVTtFQUFJLENBQUMsQ0FBQztFQUFHQSxrQkFBQUEsUUFBVTtFQUFNQSxrQkFBQUEsUUFBVTtDQUFNLENBQUM7Ozs7Ozs7O0NBUXRKLFVBQVVBLGtCQUFBQSxRQUFVOzs7OztDQUtwQixPQUFPQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTWpCLE1BQU1BLGtCQUFBQSxRQUFVLE1BQU07RUFBQztFQUFTO0VBQVc7Q0FBUyxDQUFDOzs7Ozs7Q0FNckQsZUFBZUEsa0JBQUFBLFFBQVUsTUFBTTtFQUM3QixPQUFPQSxrQkFBQUEsUUFBVTtFQUNqQixTQUFTQSxrQkFBQUEsUUFBVTtFQUNuQixTQUFTQSxrQkFBQUEsUUFBVTtDQUNyQixDQUFDOzs7O0NBSUQsT0FBT0Esa0JBQUFBLFFBQVUsUUFBUUEsa0JBQUFBLFFBQVUsTUFBTTtFQUFDO0VBQVM7RUFBVztDQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDdEY7OztBQzVPQSxJQUFNLFFBQVEsQ0FBQyxFQUNiLE9BQU8sV0FDVCxHQUFHLEVBQ0QsT0FBTyxvQkFDVCxDQUFDOzs7Ozs7Ozs7OztBQVdELElBQU0sdUJBQW9DLDJCQUFNLFdBQVcsU0FBUyxxQkFBcUIsU0FBUyxLQUFLO0NBQ3JHLE1BQU0sbUJBQW1CLGtDQUFrQyxTQUFTLHlCQUF5QjtDQUM3RixNQUFNLHlCQUF5QixpQkFBaUIsMEJBQTBCO0NBQzFFLE1BQU0sY0FBYyxpQkFBaUIsZUFBZSwyQkFBMkI7Q0FDL0UsTUFBTSxpQkFBaUIsaUJBQWlCLGtDQUFrQyw2QkFBNkI7Q0FDdkcsTUFBTSxnQkFBZ0IsU0FBUztFQUM3QixLQUFLO0VBQ0wsT0FBTztFQUNQLE1BQU07RUFDTixPQUFPO0VBQ1AsU0FBUztFQUNULFNBQVM7RUFDVCxVQUFVO0NBQ1osR0FBRyxpQkFBaUIsYUFBYTtDQTRDakMsTUFBTSxFQUNKLGlCQUNFLGdCQUFnQjtFQUNsQjtFQUNBLE9BekNZLFNBQVMsQ0FBQyxHQUFHLGtCQUFrQjtHQUMzQztHQUNBO0dBQ0EsT0FOWSxFQURpQyxjQUFjLE9BQU8sU0FBUyx1Q0FBdUMsUUFDNUQsaUJBQWlCLE1BQU0sUUFBTyxTQUFRLFNBQVMsVUFBVSxJQUFJLGlCQUFpQjtHQU9wSTtHQUNBLGFBQWEsaUJBQWlCLGdCQUFnQiwyQkFBMkIsV0FBVyxJQUFJO0dBQ3hGLFdBQVcsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLFdBQVc7SUFDbEQsTUFBTSxTQUFTLEVBQ2IsUUFBUSwyQkFBMkIsVUFDckMsR0FBRyxpQkFBaUIsV0FBVyxJQUFJO0lBQ25DLFNBQVMsU0FBUztLQUNoQixRQUFRLDJCQUEyQjtLQUNuQztJQUNGLEdBQUcsaUJBQWlCLFdBQVcsT0FBTztHQUN4QyxDQUFDO0dBQ0QsSUFBSSxRQUFRLENBQUM7S0FDVixNQUFNLGdDQUFnQyxTQUFTLEVBQzlDLE9BQUEsSUFDRjtLQUNDLE1BQU0sdUNBQXVDLFNBQVM7S0FDckQsTUFBTTtLQUVOLFdBQUE7TUFDQyxJQUFJLHVDQUF1QyxTQUFTLEVBQ25ELE9BQU8sT0FDVDtJQUNGO0tBQ0MsTUFBTSxvQkFBb0IsU0FBUztLQUNsQyxPQUFBO0tBQ0EsV0FBQTtLQUNBLE1BQU07TUFDTCxJQUFJLG9CQUFvQixTQUFTLEVBQ2hDLGdCQUFnQixTQUNsQjtJQUNGO0dBQ0YsQ0FBQyxHQUFHLGtCQUFrQixFQUFFO0VBQzFCLENBS007RUFDSixjQUFjO0VBQ2QsV0FBVztFQUNYLFdBQVc7RUFDWCxPQUFPO0NBQ1QsQ0FBQztDQUNELE9BQU8sYUFBYTtBQUN0QixDQUFDO0FBQzBDLHFCQUFxQixjQUFjO0FBQ3RDLHFCQUFxQixZQUFtQzs7Ozs7Q0FTOUYsTUFBTUMsa0JBQUFBLFFBQVU7Ozs7O0NBS2hCLGFBQWFBLGtCQUFBQSxRQUFVOzs7Ozs7O0NBT3ZCLFdBQVdBLGtCQUFBQSxRQUFVO0NBQ3JCLFdBQVdBLGtCQUFBQSxRQUFVOzs7Ozs7O0NBT3JCLG9CQUFvQkEsa0JBQUFBLFFBQVU7Ozs7O0NBSzlCLGNBQWNBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNeEIsVUFBVUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3BCLGVBQWVBLGtCQUFBQSxRQUFVOzs7OztDQUt6Qix1QkFBdUJBLGtCQUFBQSxRQUFVOzs7OztDQUtqQywwQ0FBMENBLGtCQUFBQSxRQUFVOzs7OztDQUtwRCxhQUFhQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLdkIsd0JBQXdCQSxrQkFBQUEsUUFBVSxNQUFNLENBQUMsV0FBVyxRQUFRLENBQUM7Ozs7Q0FJN0QsbUJBQW1CQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLN0IsaUJBQWlCQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTTNCLFNBQVNBLGtCQUFBQSxRQUFVOzs7OztDQUtuQixZQUFZQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLdEIsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7Q0FJbkIsYUFBYUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3ZCLFNBQVNBLGtCQUFBQSxRQUFVOzs7OztDQUtuQixTQUFTQSxrQkFBQUEsUUFBVTs7OztDQUluQixhQUFhQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLdkIsU0FBU0Esa0JBQUFBLFFBQVU7Ozs7O0NBS25CLGFBQWFBLGtCQUFBQSxRQUFVOzs7OztDQUt2QixjQUFjQSxrQkFBQUEsUUFBVSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7Ozs7O0NBV3BDLFVBQVVBLGtCQUFBQSxRQUFVOzs7Ozs7Ozs7OztDQVdwQixVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTXBCLFNBQVNBLGtCQUFBQSxRQUFVOzs7Ozs7Ozs7O0NBVW5CLFNBQVNBLGtCQUFBQSxRQUFVOzs7OztDQUtuQixlQUFlQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTXpCLGNBQWNBLGtCQUFBQSxRQUFVOzs7OztDQUt4QixjQUFjQSxrQkFBQUEsUUFBVTs7Ozs7O0NBTXhCLFFBQVFBLGtCQUFBQSxRQUFVLE1BQU07RUFBQztFQUFPO0VBQVM7RUFBWTtFQUFXO0VBQVM7RUFBVztDQUFNLENBQUM7Ozs7Q0FJM0YsYUFBYUEsa0JBQUFBLFFBQVUsTUFBTSxDQUFDLGFBQWEsVUFBVSxDQUFDOzs7Ozs7Q0FNdEQsVUFBVUEsa0JBQUFBLFFBQVU7Ozs7O0NBS3BCLGtCQUFrQkEsa0JBQUFBLFFBQVU7Ozs7O0NBSzVCLGVBQWVBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNekIsZUFBZUEsa0JBQUFBLFFBQVU7Ozs7Ozs7OztDQVN6QixtQkFBbUJBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNN0Isb0JBQW9CQSxrQkFBQUEsUUFBVTs7Ozs7OztDQU85QixtQkFBbUJBLGtCQUFBQSxRQUFVOzs7Ozs7Q0FNN0IsbUJBQW1CQSxrQkFBQUEsUUFBVTs7Ozs7Ozs7Ozs7Q0FXN0IsNkJBQTZCQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLdkMsY0FBY0Esa0JBQUFBLFFBQVU7Ozs7O0NBS3hCLFdBQVdBLGtCQUFBQSxRQUFVOzs7OztDQUtyQixPQUFPQSxrQkFBQUEsUUFBVTs7OztDQUlqQixJQUFJQSxrQkFBQUEsUUFBVSxVQUFVO0VBQUNBLGtCQUFBQSxRQUFVLFFBQVFBLGtCQUFBQSxRQUFVLFVBQVU7R0FBQ0Esa0JBQUFBLFFBQVU7R0FBTUEsa0JBQUFBLFFBQVU7R0FBUUEsa0JBQUFBLFFBQVU7RUFBSSxDQUFDLENBQUM7RUFBR0Esa0JBQUFBLFFBQVU7RUFBTUEsa0JBQUFBLFFBQVU7Q0FBTSxDQUFDOzs7OztDQUt0SixzQ0FBc0NBLGtCQUFBQSxRQUFVOzs7Ozs7O0NBT2hELFdBQVdBLGtCQUFBQSxRQUFVLE1BQU07RUFDekIsT0FBT0Esa0JBQUFBLFFBQVU7RUFDakIsU0FBU0Esa0JBQUFBLFFBQVU7RUFDbkIsU0FBU0Esa0JBQUFBLFFBQVU7Q0FDckIsQ0FBQzs7Ozs7Ozs7Q0FRRCxVQUFVQSxrQkFBQUEsUUFBVTs7Ozs7Q0FLcEIsT0FBT0Esa0JBQUFBLFFBQVU7Ozs7OztDQU1qQixNQUFNQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBTztFQUFTO0VBQVk7RUFBVztFQUFTO0VBQVc7Q0FBTSxDQUFDOzs7Ozs7Q0FNekYsZUFBZUEsa0JBQUFBLFFBQVUsTUFBTTtFQUM3QixLQUFLQSxrQkFBQUEsUUFBVTtFQUNmLE9BQU9BLGtCQUFBQSxRQUFVO0VBQ2pCLFVBQVVBLGtCQUFBQSxRQUFVO0VBQ3BCLFNBQVNBLGtCQUFBQSxRQUFVO0VBQ25CLE9BQU9BLGtCQUFBQSxRQUFVO0VBQ2pCLFNBQVNBLGtCQUFBQSxRQUFVO0VBQ25CLE1BQU1BLGtCQUFBQSxRQUFVO0NBQ2xCLENBQUM7Ozs7Q0FJRCxPQUFPQSxrQkFBQUEsUUFBVSxRQUFRQSxrQkFBQUEsUUFBVSxNQUFNO0VBQUM7RUFBTztFQUFTO0VBQVc7RUFBUztFQUFXO0NBQU0sQ0FBQyxDQUFDLENBQUMsVUFBVTs7Ozs7O0NBTTVHLFlBQVlBLGtCQUFBQSxRQUFVLE1BQU0sQ0FBQyxPQUFPLE1BQU0sQ0FBQzs7Ozs7Q0FLM0MsYUFBYUEsa0JBQUFBLFFBQVUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsN119