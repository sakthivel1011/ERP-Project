import { createHotContext as __vite__createHotContext } from "/ERP-Project/@vite/client";import.meta.hot = __vite__createHotContext("/src/Pages/Dashboard/Dashboard.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/ERP-Project/node_modules/.vite/deps/react.js?v=f54b3fc7";
import SalesChart from "/ERP-Project/src/Pages/chart/Saleschart.jsx";
// import Inventorychart from "./chart/Inventorychart";
import { dashboarddata } from "/ERP-Project/src/Data/Dashboarddata.js";
var _jsxFileName = "D:/ERP Project/ERP-Project/src/Pages/Dashboard/Dashboard.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/ERP-Project/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f54b3fc7";
function Dashboard() {
	const { sales } = dashboarddata.dashboard;
	const { inventory } = dashboarddata.dashboard;
	return /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV(SalesChart, { chartData: sales.monthlySales }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = Dashboard;
export default Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
import * as RefreshRuntime from "/ERP-Project/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/ERP-Project/src/Pages/Dashboard/Dashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/ERP Project/ERP-Project/src/Pages/Dashboard/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/ERP Project/ERP-Project/src/Pages/Dashboard/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/ERP Project/ERP-Project/src/Pages/Dashboard/Dashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sZ0JBQWdCOztBQUV2QixTQUFTLHFCQUFxQjs7O0FBQzlCLFNBQVMsWUFBWTtDQUNuQixNQUFNLEVBQUUsVUFBVSxjQUFjO0NBQ2hDLE1BQU0sRUFBRSxjQUFjLGNBQWM7Q0FDcEMsT0FDRSx3QkFBQyxPQUFELFlBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVcsTUFBTSxhQUFlOzs7O1VBRXpDOzs7OztBQUVUOztBQUNBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTYWxlc0NoYXJ0IGZyb20gXCIuLi9jaGFydC9TYWxlc2NoYXJ0XCI7XHJcbi8vIGltcG9ydCBJbnZlbnRvcnljaGFydCBmcm9tIFwiLi9jaGFydC9JbnZlbnRvcnljaGFydFwiO1xyXG5pbXBvcnQgeyBkYXNoYm9hcmRkYXRhIH0gZnJvbSBcIi4uLy4uL0RhdGEvRGFzaGJvYXJkZGF0YVwiO1xyXG5mdW5jdGlvbiBEYXNoYm9hcmQoKSB7XHJcbiAgY29uc3QgeyBzYWxlcyB9ID0gZGFzaGJvYXJkZGF0YS5kYXNoYm9hcmQ7XHJcbiAgY29uc3QgeyBpbnZlbnRvcnkgfSA9IGRhc2hib2FyZGRhdGEuZGFzaGJvYXJkO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8U2FsZXNDaGFydCBjaGFydERhdGE9e3NhbGVzLm1vbnRobHlTYWxlc30gLz5cclxuICAgICAgey8qIDxJbnZlbnRvcnljaGFydCBjaGFydERhdGExPXtpbnZlbnRvcnkuc3RvY2tDYXRlZ29yaWVzfS8+ICovfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQ7XHJcbiJdfQ==